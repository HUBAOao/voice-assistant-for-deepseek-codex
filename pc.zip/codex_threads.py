# -*- coding: utf-8 -*-
"""Compatibility facade for Codex thread discovery and management."""
from __future__ import annotations

import sys

from features.codex_app_server import (
    _AppServerClient,
    _client,
    _close_rpc,
    _rpc,
    _rpc_once,
    _find_codex_exe,
    find_codex_exe,
    poll_events,
    probe_app_server,
    respond_server_request,
    server_request_pending,
    set_server_request_handler,
)
from features.codex_thread_actions import (
    _open_deeplink,
    available,
    current_name,
    current_thread_id,
    move_to_project,
    open_new_thread,
    open_thread,
    rename_thread,
    set_pinned,
    set_read_state,
    thread_action,
)
from features.codex_thread_lifecycle import (
    _restore_thread,
    _row_by_id,
    _ui_manage,
    archive_thread,
    delete_thread,
)
from features.codex_thread_catalog import (
    DB,
    HERE,
    INDEX,
    _fallback_threads,
    _index_titles,
    _paged,
    _sections,
    list_projects,
    list_threads,
    ui_current_title,
)
from features.codex_ui_bridge import SCRIPT, run, run_with_name


_ui_current_title = ui_current_title
_run = run
_run_with_name = run_with_name


__all__ = [
    "_AppServerClient",
    "_client",
    "_close_rpc",
    "_rpc",
    "_rpc_once",
    "archive_thread",
    "available",
    "current_name",
    "current_thread_id",
    "delete_thread",
    "find_codex_exe",
    "list_projects",
    "list_threads",
    "move_to_project",
    "open_new_thread",
    "open_thread",
    "poll_events",
    "probe_app_server",
    "rename_thread",
    "respond_server_request",
    "server_request_pending",
    "set_pinned",
    "set_read_state",
    "set_server_request_handler",
    "thread_action",
]


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    rows = list_threads()
    print("Codex 里的会话一共 %d 个：" % len(rows))
    for row in rows:
        print(
            "   %s%s%s"
            % (
                row["name"],
                "   [置顶]" if row.get("pinned") else "",
                "   ← 当前" if row.get("current") else "",
            )
        )
