# -*- coding: utf-8 -*-
"""Own answer monitoring and phone-page hot reload independently of ``main()``."""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeReplyDependencies:
    reply_reader_module: Any
    speak: Callable[..., Any]
    syslog: Callable[[str, str], Any]
    on_raw_reply: Callable[[str], Any]
    busy: dict
    page_path: Callable[[], Path]
    reload_module: Callable[[], Any]
    emit: Callable[..., Any]
    clock: Callable[[], float] = time.time


class RuntimeReplyAssembly:
    """Keep reply callbacks and the two-second page reload debounce intact."""

    def __init__(self, deps: RuntimeReplyDependencies) -> None:
        self.deps = deps
        self.page_watch: dict[str, float] = {"mtime": 0.0, "next": 0.0}
        self.reader = deps.reply_reader_module.ReplyReader(
            lambda text: deps.speak(text, wait=True),
            record=lambda text: deps.syslog(
                "答", text.replace("\n", " ")[:300]
            ),
            on_raw=deps.on_raw_reply,
            done=self._done,
            on_end=lambda: deps.busy.__setitem__("on", False),
            on_ready=lambda: deps.busy.__setitem__("on", False),
        )

    def _done(self, who: str) -> None:
        self.deps.busy["on"] = False
        stream_owns_completion = False
        try:
            import phone_stream

            stream_owns_completion = phone_stream.GLOBAL_WATCHER.is_running()
        except Exception:
            pass
        if not stream_owns_completion:
            self.deps.syslog(
                "完", f"（{who or '对话'}）这段回答处理完了"
            )

    def hot_reload_page(self) -> None:
        deps = self.deps
        now = deps.clock()
        if now < self.page_watch["next"]:
            return
        self.page_watch["next"] = now + 2.0
        try:
            modified = deps.page_path().stat().st_mtime
        except Exception:
            return
        if not self.page_watch["mtime"]:
            self.page_watch["mtime"] = modified
            return
        if modified == self.page_watch["mtime"]:
            return
        self.page_watch["mtime"] = modified
        try:
            deps.reload_module()
            deps.emit("🔄 手机网页已热重载（没重启程序）", flush=True)
            deps.syslog("检", "手机网页热重载")
        except Exception as exc:  # noqa: BLE001
            deps.emit(f"（手机网页热重载失败：{exc}）", flush=True)


__all__ = [
    "RuntimeReplyAssembly",
    "RuntimeReplyDependencies",
]
