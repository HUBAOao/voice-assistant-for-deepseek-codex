# -*- coding: utf-8 -*-
"""Local delivery and restart commands for the STT main loop."""
from __future__ import annotations

from collections.abc import Callable
from typing import Any


_RESTART_WORDS = ("重启语音程序", "重启一下程序", "重新启动程序")
_READ_SELECTED_WORDS = ("念一下我选中的", "朗读选中", "念选中的字")


def parse_control_command(command: str) -> tuple[str, Any] | None:
    """Return a stable control action for one standalone local command."""
    plain = str(command or "").replace(" ", "")
    if not plain:
        return None
    if any(word in plain for word in _RESTART_WORDS):
        return "restart", None
    if "只粘贴" in plain and "回车" in plain:
        return "send_mode", "paste"
    if any(word in plain for word in ("当打字机", "用打字方式", "别用剪贴板")):
        return "send_mode", "type"
    if any(word in plain for word in (
        "粘贴并回车",
        "改回正常发送",
        "正常发送方式",
    )):
        return "send_mode", "paste_enter"
    if any(word in plain for word in (
        "确认再发",
        "发送前确认",
        "问我一下再发",
    )):
        enabled = not any(word in plain for word in ("关", "不要", "取消"))
        return "confirm_send", enabled
    if any(word in plain for word in _READ_SELECTED_WORDS):
        return "read_selected", None
    return None


def dispatch_control_command(
    command: str,
    *,
    set_config: Callable[[str, Any], Any],
    speak: Callable[[str], Any],
    schedule_restart: Callable[[], Any],
    read_selected: Callable[[], Any],
    done: Callable[[], bool],
) -> bool | None:
    """Execute a matched control command, preserving the legacy wording."""
    parsed = parse_control_command(command)
    if parsed is None:
        return None
    action, value = parsed
    if action == "restart":
        speak("好，三秒后重启")
        schedule_restart()
        return done()
    if action == "send_mode":
        set_config("send_mode", value)
        speak({
            "paste": "好，以后只粘贴不回车",
            "type": "好，以后一个字一个字敲进去",
            "paste_enter": "好，改回粘贴并回车",
        }[value])
        return done()
    if action == "confirm_send":
        set_config("confirm_send", bool(value))
        speak("好，以后发之前先问你一声" if value else "好，发之前不问了")
        return done()
    if action == "read_selected":
        read_selected()
        return done()
    return None
