# -*- coding: utf-8 -*-
"""Low-level microphone stream and sample conversion helpers."""
from __future__ import annotations

import numpy as np
import sounddevice as sd

TARGET_SR = 16000


def open_stream(device, samplerate: int = TARGET_SR):
    """Return (stream, actual_rate), falling back to the device default rate."""
    last: Exception | None = None
    for sr in (samplerate, None):
        try:
            rate = int(sr or sd.query_devices(device)["default_samplerate"])
            stream = sd.InputStream(
                samplerate=rate,
                channels=1,
                dtype="float32",
                blocksize=1024,
                device=device,
            )
            stream.start()
            return stream, rate
        except Exception as exc:  # noqa: BLE001
            last = exc
    raise SystemExit(f"打不开录音设备：{last}")


def resample_to_16k(audio: np.ndarray, sr: int) -> np.ndarray:
    if sr == TARGET_SR or audio.size == 0:
        return audio
    count = int(round(audio.size * TARGET_SR / sr))
    return np.interp(
        np.linspace(0, audio.size - 1, count),
        np.arange(audio.size),
        audio,
    ).astype(np.float32)


def rms(block: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(block)) + 1e-12))
