# -*- coding: utf-8 -*-
"""Tutorial navigation for standalone local voice commands."""
from __future__ import annotations

import re
from collections.abc import Callable
from pathlib import Path
from typing import Any


def dispatch_tutorial_command(
    *,
    plain_text: str,
    tutorial: dict,
    document: Path,
    speak: Callable[[str], Any],
    say: Callable[[int], Any],
    syslog: Callable[[str, str], Any],
    status: Any,
    done: Callable[[], bool],
    open_document: Callable[[Path], Any] | None = None,
    parse_number: Callable[[str], int | None] | None = None,
) -> bool | None:
    """Handle tutorial file, lesson, next and previous commands.

    ``plain_text`` must already have passed the standalone-command guard.
    Return ``None`` when this is not a tutorial command.
    """
    if any(word in plain_text for word in (
        "打开教程", "图文教程", "教程文件", "看看教程",
    )):
        if document.exists():
            try:
                if open_document is None:
                    raise OSError("no opener")
                open_document(document)
                speak("图文教程在这儿，双击它才会用浏览器打开")
                syslog("教", "指出图文教程（没自动开浏览器）")
            except Exception:
                speak("教程文件打不开")
        else:
            speak("没找到教程文件")
        return done()

    if any(word in plain_text for word in (
        "使用教程", "教程", "教我怎么用", "怎么用这个",
    )):
        if any(word in plain_text for word in (
            "退出", "结束", "别讲了", "不看了",
        )):
            tutorial["on"] = False
            speak("好，教程结束")
            status.set("idle")
            return done()
        match = re.search(
            r"第\s*([0-9一二三四五六七八九十]+)\s*[课步节]", plain_text
        )
        if match:
            raw = match.group(1)
            if raw.isdigit():
                number = int(raw)
            else:
                number = int((parse_number(raw) if parse_number else None) or 1)
            say(max(0, number - 1))
            return done()
        say(int(tutorial.get("step") or 0) if tutorial.get("on") else 0)
        return done()

    if tutorial.get("on") and any(word in plain_text for word in (
        "下一步", "继续", "然后呢", "下一个",
    )):
        say(int(tutorial.get("step") or 0) + 1)
        return done()

    if tutorial.get("on") and any(word in plain_text for word in (
        "上一步", "回去", "前一个",
    )):
        say(max(0, int(tutorial.get("step") or 0) - 1))
        return done()
    return None
