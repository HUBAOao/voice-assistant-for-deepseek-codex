# -*- coding: utf-8 -*-
"""Small runtime helpers kept out of the stt.py main-loop container."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable

import numpy as np

import wake_levels
from voice_feature.audio_io import resample_to_16k


def build_test_summary(result: dict, level_name: str) -> str:
    total, passed = result.get("total", 0), result.get("passed", 0)
    if not total:
        return "自检没有可用的测试项"
    if passed == total:
        return f"唤醒自检：{total} 项全部通过，当前档位「{level_name}」"
    cases = result.get("cases") or []
    missed = {c.get("kind") for c in cases if not c["hit"]}
    names = list(wake_levels.LEVELS)
    tip = ""
    if level_name in names and names.index(level_name) < len(names) - 1:
        tip = f"，可以把档位调到「{names[names.index(level_name) + 1]}」"
    if "干净" in missed:
        return (f"唤醒自检：{total} 项里 {passed} 项通过。安静环境下都认不出来，"
                f"这个唤醒词可能不好念，换个词、或者多写几个用逗号隔开{tip}")
    if "吞字" in missed:
        return (f"唤醒自检：{total} 项里 {passed} 项通过。当前档位关掉了「开头吞字」容错，"
                f"录音开头少半个字就认不出来{tip}")
    if "小声" in missed:
        return f"唤醒自检：{total} 项里 {passed} 项通过，小声说的时候接不住{tip}"
    return f"唤醒自检：{total} 项里 {passed} 项通过，有底噪时不太稳{tip}"


def append_log(path: Path, text: str,
               sanitize: Callable[[str], str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    clean = sanitize or (lambda value: value)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with path.open("a", encoding="utf-8") as fh:
        fh.write(f"- {stamp} {clean(text)}\n")
    (path.parent / "last.txt").write_text(clean(text) + "\n", encoding="utf-8")


def wait_for_enter(prompt: str) -> None:
    print(prompt, end="", flush=True)
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        raise SystemExit(0) from None


def record_ptt(recorder) -> np.ndarray:
    """Enter to start / Enter to stop, using msvcrt non-blocking input."""
    import msvcrt

    recorder.flush()
    wait_for_enter("\n按回车开始说话…")
    print("● 录音中（再按回车结束）…", end="", flush=True)
    frames: list[np.ndarray] = []
    while True:
        frames.append(recorder._read())
        while msvcrt.kbhit():
            if msvcrt.getwch() in ("\r", "\n"):
                print(" 停", flush=True)
                audio = np.concatenate(frames) if frames else np.array([], dtype=np.float32)
                return resample_to_16k(audio, recorder.sr)
