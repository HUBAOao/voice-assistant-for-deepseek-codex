"""Pure timing rules shared by microphone capture and recognition."""

from __future__ import annotations


MIN_UTTERANCE_SECONDS = 0.25
NOT_HEARD_COOLDOWN_SECONDS = 30.0
MAX_JOINED_CAPTURE_SECONDS = 120.0


def has_utterance(audio, sample_rate: int,
                  minimum_seconds: float = MIN_UTTERANCE_SECONDS) -> bool:
    """Whether a captured buffer is long enough to attempt recognition."""
    if audio is None or sample_rate <= 0:
        return False
    try:
        samples = int(audio.size)
    except Exception:
        return False
    return samples >= int(float(sample_rate) * minimum_seconds)


def not_heard_due(
    audio,
    sample_rate: int,
    *,
    previous_at: float,
    now: float,
    minimum_seconds: float = 0.45,
    cooldown: float = NOT_HEARD_COOLDOWN_SECONDS,
) -> bool:
    """Rate-limit the spoken 'I did not catch that' side effect."""
    if audio is None or sample_rate <= 0:
        return False
    try:
        long_enough = int(audio.size) > float(sample_rate) * float(minimum_seconds)
    except Exception:
        return False
    return long_enough and float(now) - float(previous_at) > float(cooldown)


def continue_long_capture(
    last_cut: bool,
    total_samples: int,
    sample_rate: int,
    *,
    maximum_seconds: float = MAX_JOINED_CAPTURE_SECONDS,
) -> bool:
    """Continue joining chunks only when the recorder cut a sentence and the cap is open."""
    if sample_rate <= 0:
        return False
    return bool(last_cut) and int(total_samples) <= int(float(sample_rate) * maximum_seconds)
