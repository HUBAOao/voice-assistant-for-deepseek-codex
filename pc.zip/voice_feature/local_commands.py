# -*- coding: utf-8 -*-
"""Local voice commands that touch files, screenshots and phone attachments."""
from __future__ import annotations

import re
import time
from collections.abc import Callable
from typing import Any


def dispatch_screen_command(
    command: str,
    *,
    cfg: dict,
    speak: Callable[[str], Any],
    done: Callable[[], bool],
    syslog: Callable[[str, str], Any],
    status: Any,
    busy: dict,
    resolve_target: Callable[[], tuple[int, str]],
    paste_clipboard: Callable[..., Any],
    grab_screen: Callable[[], bool],
    reply_reader: Any = None,
    current_conversation: Callable[[], str] | None = None,
    from_phone: bool = False,
) -> bool | None:
    """Run one standalone screen/file command, or return None when unmatched.

    ``command`` must already have passed the standalone-command gate. This
    module deliberately contains no microphone or model state.
    """
    plain = str(command or "").replace(" ", "")
    if not plain:
        return None

    wanted_file = ""
    for head in ("把", "将"):
        match = re.search(
            head + r"(.{1,60}?)(发到手机|发给手机|发手机|发给我|传到手机)",
            plain,
        )
        if match:
            wanted_file = match.group(1).strip("的 ")
            break
    if wanted_file:
        if not cfg.get("screen_share", True):
            speak("发文件我在设置里关掉了")
            return done()
        import file_share

        source = file_share.find_file(wanted_file)
        if source:
            destination = file_share.add_file(source)
            print(
                f"   ↳ 📁 已放进手机入口：{destination.name if destination else '（失败）'}",
                flush=True,
            )
            syslog("动", f"发文件给手机：{source.name}")
            speak(f"把{source.name}发过去了，手机上能下载")
            status.set("sent", text=f"📁 已发到手机：{source.name[:18]}")
        else:
            print(f"   ↳ 📁 没找到「{wanted_file}」", flush=True)
            speak(f"没找到{wanted_file}，你可以说全一点的文件名")
            status.set("sent", text=f"📁 没找到 {wanted_file[:16]}")
        return done()

    if any(word in plain for word in (
        "发手机", "手机上看看", "发到手机", "给我看看屏幕",
        "看看电脑屏幕", "看看我电脑",
    )):
        if not cfg.get("screen_share", True):
            speak("屏幕发手机我在设置里关掉了")
            print("   ↳ 📱 屏幕发手机已关（设置 → 功能）", flush=True)
            return done()
        import screen_share

        seconds = 0.0
        match = re.search(r"录\s*(\d{1,2})\s*秒", plain)
        if match:
            seconds = float(match.group(1))
        elif any(word in plain for word in ("录屏", "录一段", "录像", "录制")):
            seconds = 8.0
        if seconds:
            speak(f"好，录 {int(seconds)} 秒，录完手机上就能看")
            path = screen_share.record_screen(seconds=seconds)
            if path:
                print(f"   ↳ 📱 录屏已放进手机入口：{path.name}", flush=True)
                syslog("动", f"录屏 {int(seconds)} 秒发手机：{path.name}")
                speak("录好了，手机上刷新一下就能看")
            else:
                speak("录屏没成功")
        else:
            path = screen_share.take_shot()
            if path:
                print(f"   ↳ 📱 截图已放进手机入口：{path.name}", flush=True)
                syslog("动", f"截图发手机：{path.name}")
                speak("截好了，手机上能看到")
            else:
                speak("截图没成功")
        status.set("sent", text="📱 屏幕已发到手机")
        return done()

    if any(word in plain for word in (
        "看屏幕", "看看屏幕", "看下屏幕", "看看这个",
        "看这个", "这个报错", "截个屏", "截屏",
    )):
        if not cfg.get("screenshot_enabled", True):
            speak("看屏幕截图我在设置里关掉了")
            print("   ↳ 📸 看屏幕截图已关（设置 → 功能 → 看屏幕截图）", flush=True)
            syslog("动", "看屏幕截图：设置里关着，没截")
            status.set("sent", text="📸 截图功能已关")
            return done()
        if grab_screen():
            hwnd, title = resolve_target()
            paste_clipboard(hwnd, press_enter=True, clear_first=False)
            speak("截好图发过去了")
            syslog("动", "截图并贴进聊天窗口")
            print("   ↳ 📸 已截图并粘贴", flush=True)
            if reply_reader is not None and cfg.get("read_reply", True) and hwnd:
                conversation = title
                if current_conversation is not None:
                    try:
                        conversation = current_conversation() or title
                    except Exception:
                        conversation = title
                reply_reader.watch(
                    hwnd, "[截图]", seconds=900, max_chars=20000,
                    title=conversation or title, speak=not from_phone,
                )
                busy["on"] = True
                busy["at"] = time.time()
                print("   ↳ 🔊 已开始监听这张截图引出的回答", flush=True)
            status.set("sent", text="📸 截图已发")
        else:
            speak("截图没成功")
        return done()
    return None
