"""Ordered local-command dispatch without owning UI or assistant state."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class LocalCommandStage:
    """One local command group.

    A handler returns ``None`` when the phrase does not belong to that group,
    or a boolean when it handled the phrase.  The boolean is the existing
    "should the outer loop stop" result, not a success flag.
    """

    name: str
    handler: Callable[[], bool | None]


@dataclass(frozen=True)
class LocalCommandOutcome:
    """Result of the ordered local-command pass."""

    handled: bool
    terminate: bool
    stage: str = ""


def dispatch_local_command_stages(
    stages: list[LocalCommandStage] | tuple[LocalCommandStage, ...],
) -> LocalCommandOutcome:
    """Run stages in order and stop at the first group that handles the text."""
    names: set[str] = set()
    for stage in stages:
        if not stage.name or stage.name in names:
            raise ValueError("local command stage names must be non-empty and unique")
        names.add(stage.name)
        result = stage.handler()
        if result is not None:
            return LocalCommandOutcome(
                handled=True,
                terminate=bool(result),
                stage=stage.name,
            )
    return LocalCommandOutcome(handled=False, terminate=False)
