# -*- coding: utf-8 -*-
"""faster-whisper model ownership, fallback, and transcript cleanup."""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np


class Transcriber:
    def __init__(
        self,
        model_name: str,
        device: str,
        compute_type: str | None,
        language: str,
        hotwords: str = "",
        *,
        model_root: Path,
        cuda_ready_fn: Callable[[], bool],
        asr_prompt: str,
        asr_lock,
        hallucination_fn: Callable[[str], bool],
        normalize_fn: Callable[[str], str],
        target_sr: int = 16000,
        log: Callable[[str], None] = print,
    ):
        cuda_ready = cuda_ready_fn()
        from faster_whisper import WhisperModel

        self.language = language
        self.hotwords = " ".join((hotwords or "").split())
        self.beam = 5
        self._model_name = model_name
        self._requested = (device, compute_type)
        self._asr_prompt = asr_prompt
        self._asr_lock = asr_lock
        self._hallucination_fn = hallucination_fn
        self._normalize_fn = normalize_fn
        self._target_sr = target_sr
        self._log = log

        local = Path(model_root) / "models" / f"faster-whisper-{model_name}"
        if local.is_dir():
            model_ref, where = str(local), f"本地 {local.name}"
        else:
            model_ref, where = model_name, f"{model_name}（首次会联网下载）"
        self._model_ref = model_ref
        attempts: list[tuple[str, str]] = []
        if device == "cuda" and not cuda_ready:
            log("  提示：没找到 cuBLAS/cuDNN，改用 CPU（想要显卡加速见 README 的 GPU 一节）")
        if device in ("auto", "cuda") and cuda_ready:
            attempts.append(("cuda", compute_type or "float16"))
        if device == "cpu" or device == "auto" or not cuda_ready:
            attempts.append(("cpu", compute_type or "int8"))

        self.model = None
        for dev, ctype in attempts:
            try:
                log(f"  加载模型 {where}（{dev}/{ctype}）…")
                self.model = WhisperModel(model_ref, device=dev, compute_type=ctype)
                self.device, self.compute_type = dev, ctype
                break
            except Exception as exc:  # noqa: BLE001
                log(f"  {dev} 不可用（{type(exc).__name__}: {str(exc)[:120]}）")
        if self.model is None:
            raise SystemExit("模型加载失败。试试 --device cpu 或者 --model small。")

    def transcribe(self, audio: np.ndarray) -> str:
        with self._asr_lock:
            try:
                return self._run(audio)
            except RuntimeError as exc:
                if self.device != "cuda":
                    raise
                self._log(f"\n  （显卡推理失败：{str(exc)[:80]}，改用 CPU）")
                from faster_whisper import WhisperModel

                self.model = WhisperModel(
                    self._model_ref, device="cpu", compute_type="int8"
                )
                self.device, self.compute_type = "cpu", "int8"
                return self._run(audio)

    def _run(self, audio: np.ndarray) -> str:
        segments, _info = self.model.transcribe(
            audio,
            language=self.language,
            beam_size=self.beam,
            vad_filter=True,
            condition_on_previous_text=False,
            initial_prompt=self._asr_prompt,
            hotwords=self.hotwords or None,
        )
        parts = []
        for segment in segments:
            if getattr(segment, "no_speech_prob", 0.0) > 0.55:
                continue
            if getattr(segment, "avg_logprob", 0.0) < -1.2:
                continue
            try:
                if (
                    float(getattr(segment, "end", 0) or 0)
                    - float(getattr(segment, "start", 0) or 0)
                    < 0.25
                ):
                    continue
            except Exception:
                pass
            if self._hallucination_fn(segment.text):
                continue
            parts.append(segment.text)
        text = "".join(parts).strip()
        if self.language.startswith("zh"):
            text = self._normalize_fn(text)
        return text

    def transcribe_file(self, path: str) -> str:
        from faster_whisper.audio import decode_audio

        audio = decode_audio(path, sampling_rate=self._target_sr)
        return self.transcribe(audio)
