# -*- coding: utf-8 -*-
"""Standalone voice commands for games, notes, utilities and reminders.

The callers in ``stt.py`` own microphone state and all user-facing callbacks.
This module only decides whether one already-validated short command was
handled, keeping the legacy command order and responses unchanged.
"""
from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any


def dispatch_game_command(
    command: str,
    *,
    game_feed: Callable[[str], bool],
    parse_game: Callable[[str], tuple[str, str] | None],
    game_start: Callable[[str, str], Any],
    done: Callable[[], bool],
) -> bool | None:
    """Continue an active game or start a new one."""
    if game_feed(command):
        return done()
    opening = parse_game(command)
    if opening:
        game_start(*opening)
        return done()
    return None


def dispatch_note_command(
    command: str,
    *,
    query_ledger: tuple[str, ...],
    query_note: tuple[str, ...],
    parse_ledger: Callable[[str], tuple[str, float] | None],
    parse_note: Callable[[str], str | None],
    say_ledger: Callable[[], Any],
    say_notes: Callable[[], Any],
    add_ledger: Callable[[str, float], Any],
    add_note: Callable[[str], Any],
    beep: Callable[[], Any],
    done: Callable[[], bool],
) -> bool | None:
    """Handle note and ledger queries before their write parsers."""
    if any(word in command for word in query_ledger):
        say_ledger()
        return done()
    if any(word in command for word in query_note):
        say_notes()
        return done()
    ledger_hit = parse_ledger(command)
    if ledger_hit:
        add_ledger(*ledger_hit)
        beep()
        return done()
    note_body = parse_note(command)
    if note_body:
        add_note(note_body)
        beep()
        return done()
    return None


def dispatch_utility_command(
    command: str,
    *,
    parse_calc: Callable[[str], tuple[str, float] | None],
    parse_convert: Callable[[str], str | None],
    parse_media: Callable[[str], tuple[str, int] | None],
    parse_open: Callable[[str], str | None],
    speak: Callable[[str], Any],
    status: Any,
    beep: Callable[[], Any],
    press_key: Callable[..., Any],
    open_named: Callable[[str], str | None],
    done: Callable[[], bool],
) -> bool | None:
    """Handle calculations, conversion, media keys and local app opening."""
    calc = parse_calc(command)
    if calc:
        show, value = calc
        answer = (
            f"{show} 等于 {value:g}"
            if abs(value - round(value)) < 1e-9
            else f"{show} 等于 {value:.4f}".rstrip("0").rstrip(".")
        )
        speak(answer)
        print(f"   ↳ 🧮 {answer}", flush=True)
        status.set("sent", text=f"🧮 {answer}")
        return done()

    converted = parse_convert(command)
    if converted:
        speak(converted)
        print(f"   ↳ 📐 {converted}", flush=True)
        status.set("sent", text=f"📐 {converted}")
        return done()

    media = parse_media(command)
    if media:
        name, key = media
        press_key(key)
        press_key(key, up=True)
        print(f"   ↳ 🎵 媒体键：{name}", flush=True)
        status.set("sent", text=f"🎵 {name}")
        beep()
        return done()

    wanted = parse_open(command)
    if wanted:
        opened = open_named(wanted)
        if opened:
            speak(f"打开了{opened}")
            print(f"   ↳ 📂 打开：{opened}", flush=True)
            status.set("sent", text=f"📂 {opened}")
            return done()
        print(f"   ↳ （没找到「{wanted}」，交给 AI 处理）", flush=True)
    return None


def dispatch_reminder_command(
    command: str,
    *,
    enabled: bool,
    parse_reminder: Callable[[str], tuple[float, str] | None],
    start_reminder: Callable[..., Any],
    paste_to_window: bool,
    target_hwnd: int,
    speak: Callable[[str], Any],
    status: Any,
    beep: Callable[[], Any],
    arm_followup: Callable[[], Any],
    once: bool,
) -> bool | None:
    """Start a timed reminder while preserving the old acknowledgement."""
    if not enabled:
        return None
    reminder = parse_reminder(command)
    if not reminder:
        return None
    seconds, what = reminder
    start_reminder(seconds, what, bool(paste_to_window), target_hwnd)
    when = (
        f"{int(seconds / 3600)} 小时"
        if seconds >= 3600
        else f"{int(seconds / 60)} 分钟"
        if seconds >= 60
        else f"{int(seconds)} 秒"
    )
    acknowledgement = f"好，{when}后提醒你{what}"
    speak(acknowledgement)
    print(f"   ↳ ⏰ {acknowledgement}", flush=True)
    status.set("sent", text=f"⏰ {acknowledgement}")
    beep()
    arm_followup()
    time.sleep(0.6)
    return bool(once)
