"""Command-line options for the STT runtime."""
from __future__ import annotations

import argparse
from collections.abc import Mapping


def build_argument_parser(
    cfg: Mapping[str, object],
    *,
    default_input: str | None = None,
    default_out: str | None = None,
    prog: str | None = None,
) -> argparse.ArgumentParser:
    """Build the existing CLI without reading config or touching the runtime."""
    parser = argparse.ArgumentParser(
        prog=prog,
        description="本地语音转文字（faster-whisper）",
    )
    parser.add_argument(
        "--model",
        default=cfg.get("model") or "small",
        help="模型：tiny/base/small/medium/large-v3/large-v3-turbo（默认 small）",
    )
    parser.add_argument(
        "--lang",
        default=cfg.get("lang") or "zh",
        help="语言代码，默认 zh；英文用 en",
    )
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cuda", "cpu"],
    )
    parser.add_argument(
        "--compute-type",
        default=None,
        help="默认 cuda=float16, cpu=int8",
    )
    parser.add_argument(
        "--input",
        default=default_input,
        help=(
            "麦克风序号或名字片段"
            f"（config.json 里现在是 {default_input or '系统默认设备'}）"
        ),
    )
    parser.add_argument(
        "--default-input",
        action="store_true",
        help="用系统默认麦克风，忽略上面的设定",
    )
    parser.add_argument("--list-devices", action="store_true")
    parser.add_argument(
        "--mode",
        default=cfg.get("input_mode") or "hold",
        choices=["hold", "auto", "enter", "talk"],
        help=(
            "hold=按住键说话（默认），talk=说完自动发送给 AI，"
            "auto=只识别不发送，enter=回车开始/结束"
        ),
    )
    parser.add_argument(
        "--key",
        default=cfg.get("hold_key") or "*",
        help="按住说话的键，默认 * （也支持 f9 / space / a-z 等）",
    )
    parser.add_argument(
        "--pause-key",
        default="-",
        help="对话模式里暂停/继续的键，默认 - （主键盘和小键盘都认）",
    )
    parser.add_argument(
        "--target",
        default=cfg.get("target") or None,
        help=(
            "对话模式：固定发到这个窗口（标题关键字，比如 ChatGPT）；"
            "默认跟着你上一个用过的窗口"
        ),
    )
    parser.add_argument(
        "--test-paste",
        action="store_true",
        help="只做一次粘贴测试，不录音（排错用）",
    )
    parser.add_argument(
        "--feed",
        action="append",
        default=None,
        help="不录音，用现成的音频文件跑一遍完整流程（可重复给多个文件，测试用）",
    )
    parser.add_argument(
        "--wake-word",
        "--send-word",
        dest="wake_word",
        default=cfg.get("wake_word") or "大肥鱼",
        help="对话模式：唤醒词，先说它再说话（默认「大肥鱼」，可写成 大肥鱼,喂喂）",
    )
    parser.add_argument(
        "--cancel-word",
        default=cfg.get("cancel_word") or "取消",
        help="唤醒后说这个词就取消这次（默认「取消」）",
    )
    parser.add_argument(
        "--wake-timeout",
        type=float,
        default=12.0,
        help="唤醒后等你说多久，默认 12 秒",
    )
    parser.add_argument(
        "--immediate",
        action="store_true",
        help="对话模式：不用唤醒词，识别完立刻发送（Siri 那种唤醒逻辑的关闭版）",
    )
    parser.add_argument(
        "--beep",
        dest="beep",
        action="store_true",
        default=True,
        help="开始/结束提示音（默认开）",
    )
    parser.add_argument("--no-beep", dest="beep", action="store_false")
    parser.add_argument("--ptt", action="store_true", help="等价于 --mode enter")
    parser.add_argument("--once", action="store_true", help="只识别一句就退出")
    parser.add_argument(
        "--no-send",
        action="store_true",
        help="talk 模式：粘上去但不按回车",
    )
    parser.add_argument(
        "--keep-draft",
        action="store_true",
        help="talk 模式：保留输入框里原有的内容，不和这次的话一起发",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="talk 模式：只打印，不碰任何窗口",
    )
    parser.add_argument(
        "--silence",
        type=float,
        default=None,
        help="停顿多少秒算说完（talk 默认 1.0，其它 0.8）",
    )
    parser.add_argument(
        "--max-seconds",
        type=float,
        default=25.0,
        help="单句最长录音秒数",
    )
    parser.add_argument(
        "--out",
        default=default_out,
        help="识别日志文件",
    )
    parser.add_argument(
        "--file",
        default=None,
        help="识别一个现成的音频文件，而不是用麦克风",
    )
    parser.add_argument("--no-clipboard", action="store_true")
    parser.add_argument(
        "--no-overlay",
        action="store_true",
        help="不显示悬浮窗",
    )
    parser.add_argument(
        "--no-greeting",
        action="store_true",
        help="这次启动不念开机问候",
    )
    parser.add_argument(
        "--allow-multiple",
        action="store_true",
        help="允许同时开多个语音程序（默认不允许）",
    )
    return parser
