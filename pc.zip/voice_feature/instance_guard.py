# -*- coding: utf-8 -*-
"""Acquire the main-process singleton without duplicating startup code."""
from __future__ import annotations

import ctypes
import os
import time
from pathlib import Path
from typing import Callable


class SingleInstanceGuard:
    """Hold a named mutex and a PID lock for one live main process.

    Windows uses the mutex as the primary gate and the PID file as recovery
    evidence when a previous process left a stale lock behind. Other platforms
    still use the atomic lock file, which keeps tests and development runs
    deterministic without changing the Windows production path.
    """

    def __init__(
        self,
        *,
        name: str,
        lock_path: Path,
        platform_name: str | None = None,
        pid_alive: Callable[[int], bool] | None = None,
    ) -> None:
        self.name = str(name)
        self.lock_path = Path(lock_path)
        self.platform_name = platform_name or os.name
        self._pid_alive = pid_alive or self._default_pid_alive
        self._mutex_handle: int | None = None
        self._owned = False

    @property
    def owned(self) -> bool:
        return self._owned

    def acquire(self) -> bool:
        if self._owned:
            return True
        mutex_available = self._acquire_mutex()
        if not mutex_available:
            self._release_mutex()
            return False
        lock_available = self._acquire_pid_file()
        self._owned = bool(lock_available)
        if not self._owned:
            self._release_mutex()
        return self._owned

    def release(self) -> None:
        if not self._owned:
            return
        try:
            contents = self.lock_path.read_text(encoding="utf-8").strip()
            if contents == str(os.getpid()):
                self.lock_path.unlink()
        except OSError:
            pass
        self._release_mutex()
        self._owned = False

    def _acquire_mutex(self) -> bool:
        if self.platform_name != "nt":
            return True
        try:
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CreateMutexW.restype = ctypes.c_void_p
            kernel.CreateMutexW.argtypes = [
                ctypes.c_void_p,
                ctypes.c_bool,
                ctypes.c_wchar_p,
            ]
            handle = kernel.CreateMutexW(None, False, self.name)
            if not handle:
                return True
            self._mutex_handle = int(handle)
            return ctypes.get_last_error() != 183
        except Exception:
            return True

    def _release_mutex(self) -> None:
        if self.platform_name != "nt" or not self._mutex_handle:
            self._mutex_handle = None
            return
        try:
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.CloseHandle.argtypes = [ctypes.c_void_p]
            kernel.CloseHandle(ctypes.c_void_p(self._mutex_handle))
        except Exception:
            pass
        self._mutex_handle = None

    def _acquire_pid_file(self) -> bool:
        try:
            fd = os.open(
                str(self.lock_path),
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
            )
            try:
                os.write(fd, str(os.getpid()).encode("utf-8"))
            finally:
                os.close(fd)
            return True
        except FileExistsError:
            previous = self._read_previous_pid()
            if not previous:
                try:
                    # Another process can briefly create an empty lock while it
                    # is starting. Give it time to publish its PID.
                    if time.time() - self.lock_path.stat().st_mtime < 120:
                        return False
                except OSError:
                    return False
            if previous and previous != os.getpid() and self._pid_alive(previous):
                return False
            try:
                self.lock_path.write_text(str(os.getpid()), encoding="utf-8")
                return True
            except OSError:
                return False
        except OSError:
            return True
        return False

    def _read_previous_pid(self) -> int:
        for _ in range(12):
            try:
                raw = self.lock_path.read_text(encoding="utf-8").strip()
                if raw:
                    return int(raw)
            except (OSError, ValueError):
                pass
            time.sleep(0.05)
        return 0

    @staticmethod
    def _default_pid_alive(pid: int) -> bool:
        try:
            if os.name == "nt":
                kernel = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel.OpenProcess.restype = ctypes.c_void_p
                kernel.CloseHandle.argtypes = [ctypes.c_void_p]
                handle = kernel.OpenProcess(0x1000, False, int(pid))
                if handle:
                    kernel.CloseHandle(ctypes.c_void_p(handle))
                    return True
                return False
            os.kill(int(pid), 0)
            return True
        except (OSError, ValueError):
            return False
