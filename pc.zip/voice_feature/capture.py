# -*- coding: utf-8 -*-
"""Microphone capture, sleep recovery, VAD, and utterance boundaries."""
from __future__ import annotations

import collections
import sys
import time
from typing import Any, Callable

import numpy as np

from voice_feature.audio_io import (
    open_stream as default_open_stream,
    resample_to_16k as default_resample,
    rms as default_rms,
)


class Recorder:
    """Read blocks from a stream and use rolling energy to find speech."""

    def __init__(
        self,
        stream,
        samplerate: int,
        silence: float,
        max_seconds: float,
        min_voiced: float = 0.45,
        noise_mult: float = 6.0,
        confirm: int = 3,
        device=None,
        *,
        open_stream_fn: Callable[..., Any] | None = None,
        resample_fn: Callable[..., np.ndarray] | None = None,
        rms_fn: Callable[[np.ndarray], float] | None = None,
        syslog_fn: Callable[[str, str], None] | None = None,
    ):
        self.stream = stream
        self.device = device
        self.sr = samplerate
        self.blocksize = 1024
        self.noise_mult = max(1.0, float(noise_mult))
        self.confirm = max(1, int(confirm))
        self.noise_hist: collections.deque = collections.deque(maxlen=220)
        self.last_cut = False
        self.silence_blocks = max(1, int(silence * samplerate / self.blocksize))
        self.max_blocks = int(max_seconds * samplerate / self.blocksize)
        self.preroll_blocks = max(1, int(0.3 * samplerate / self.blocksize))
        self.min_voiced_blocks = max(1, int(min_voiced * samplerate / self.blocksize))
        self.open_stream_fn = open_stream_fn or default_open_stream
        self.resample_fn = resample_fn or default_resample
        self.rms_fn = rms_fn or default_rms
        self.syslog_fn = syslog_fn or (lambda _tag, _text: None)

    def _read(self) -> np.ndarray:
        now = time.monotonic()
        gap = now - getattr(self, "_last_read", now)
        if gap > 20.0:
            self.after_sleep(gap)
        self._last_read = now
        try:
            data, _overflowed = self.stream.read(self.blocksize)
        except Exception as exc:  # noqa: BLE001
            if self.reopen_stream(f"读不到音频（{type(exc).__name__}）"):
                data, _overflowed = self.stream.read(self.blocksize)
            else:
                raise
        return data[:, 0].copy()

    def reopen_stream(self, why: str = "") -> bool:
        """Reopen the microphone after sleep or a dead device."""
        if getattr(self, "_reopening", False):
            return False
        self._reopening = True
        try:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            for attempt in (1, 2, 3):
                try:
                    stream, rate = self.open_stream_fn(
                        getattr(self, "device", None), self.sr
                    )
                except (Exception, SystemExit) as exc:  # noqa: BLE001
                    print(f"   ↳ 第 {attempt} 次重开麦克风没成：{exc}", flush=True)
                    time.sleep(1.5)
                    continue
                self.stream = stream
                if rate != self.sr:
                    self.sr = rate
                    self.blocksize = max(256, int(round(0.064 * rate)))
                    self.silence_blocks = max(1, int(0.75 * rate / self.blocksize))
                    self.max_blocks = int(30 * rate / self.blocksize)
                    self.preroll_blocks = max(1, int(0.3 * rate / self.blocksize))
                    self.min_voiced_blocks = max(1, int(0.18 * rate / self.blocksize))
                try:
                    self.flush()
                except Exception:
                    pass
                self.noise_hist.clear()
                self._last_read = time.monotonic()
                who = why or "睡醒恢复"
                print(f"   ↳ 🔌 麦克风已经重开好了（{who}）", flush=True)
                self.syslog_fn("检", f"麦克风重开成功（{who}）")
                return True
            return False
        finally:
            self._reopening = False

    def after_sleep(self, gap: float) -> None:
        print(f"\n😴 刚才睡了大约 {gap:.0f} 秒，检查一下麦克风…", flush=True)
        self.syslog_fn("检", f"检测到睡眠约 {gap:.0f} 秒，正在检查麦克风")
        self.noise_hist.clear()
        try:
            self.stream.read(self.blocksize)
            print("   ↳ 麦克风还在，继续听", flush=True)
            self.syslog_fn("检", "睡醒后麦克风正常")
        except Exception as exc:  # noqa: BLE001
            print(f"   ↳ 麦克风死了（{type(exc).__name__}），重开", flush=True)
            self.reopen_stream(f"睡醒后音频流坏了（{type(exc).__name__}）")

    def flush(self) -> None:
        for _ in range(3):
            self._read()

    def calibrate(self, seconds: float = 0.5) -> float:
        levels = [
            self.rms_fn(self._read())
            for _ in range(max(1, int(seconds * self.sr / self.blocksize)))
        ]
        self.noise_hist.extend(levels)
        if self.noise_hist:
            noise = float(
                np.percentile(np.fromiter(self.noise_hist, dtype=float), 15)
            )
        else:
            noise = float(np.median(levels)) if levels else 0.0
        return max(noise * self.noise_mult, 0.012)

    def record_utterance(
        self,
        threshold: float,
        on_speech=None,
        tick=None,
        on_level=None,
        on_partial=None,
        partial_every: float = 0.6,
    ) -> np.ndarray | None:
        preroll: list[np.ndarray] = []
        frames: list[np.ndarray] = []
        silent_run = 0
        above = 0
        voiced = 0
        partial_at = 0.0
        peak = 0.0
        speaking = False

        while True:
            block = self._read()
            if tick is not None and tick():
                return None
            level = self.rms_fn(block)
            self.noise_hist.append(level)
            if on_level:
                try:
                    on_level(level, block)
                except TypeError:
                    on_level(level)
            if not speaking:
                preroll.append(block)
                if len(preroll) > self.preroll_blocks:
                    preroll.pop(0)
                above = above + 1 if level > threshold else 0
                if above >= self.confirm:
                    speaking = True
                    frames = list(preroll)
                    voiced = sum(
                        1 for item in frames if self.rms_fn(item) > threshold
                    )
                    if on_speech:
                        on_speech()
                continue

            frames.append(block)
            peak = max(peak, level)
            if on_partial is not None:
                seconds = len(frames) * self.blocksize / self.sr
                if seconds >= 0.7 and seconds - partial_at >= partial_every:
                    partial_at = seconds
                    try:
                        on_partial(np.concatenate(frames))
                    except Exception:
                        pass
            if level > threshold:
                voiced += 1
                silent_run = 0
            else:
                silent_run += 1
            if silent_run >= self.silence_blocks or len(frames) >= self.max_blocks:
                audio = (
                    np.concatenate(frames)
                    if frames else np.array([], dtype=np.float32)
                )
                self.last_cut = len(frames) >= self.max_blocks
                if voiced < self.min_voiced_blocks:
                    return None
                if (
                    len(frames) * self.blocksize / self.sr >= 4.0
                    and peak < threshold * 1.8
                ):
                    return None
                return self.resample_fn(audio, self.sr)

    def record_hold(
        self,
        key_down,
        min_seconds: float = 0.25,
        tail_blocks: int = 2,
        on_start=None,
        on_stop=None,
        meter: bool = False,
        on_level=None,
        tick=None,
    ) -> np.ndarray | None:
        preroll: list[np.ndarray] = []
        while not key_down():
            preroll.append(self._read())
            if tick is not None:
                tick()
            if len(preroll) > self.preroll_blocks:
                preroll.pop(0)

        if on_start:
            on_start()
        frames = list(preroll)
        peak = max((self.rms_fn(item) for item in frames), default=0.0)
        started = time.time()
        while key_down() or time.time() - started < min_seconds:
            block = self._read()
            if tick is not None:
                tick()
            frames.append(block)
            level = self.rms_fn(block)
            peak = max(peak, level)
            if on_level:
                on_level(level)
            if meter:
                count = min(24, int(level * 240))
                tip = "  （声音偏小）" if level < 0.02 else " " * 12
                sys.stdout.write(
                    "\r🎙 录音中 " + "█" * count + "·" * (24 - count) + tip
                )
                sys.stdout.flush()
        for _ in range(tail_blocks):
            frames.append(self._read())
        if on_stop:
            on_stop()
        if meter:
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()
            if peak < 0.02:
                print(
                    "  （麦克风几乎没收到声音：换个设备试试 --list-devices / "
                    "--input USB，或者凑近点）"
                )

        audio = (
            np.concatenate(frames)
            if frames else np.array([], dtype=np.float32)
        )
        if audio.size < int(min_seconds * self.sr):
            return None
        return self.resample_fn(audio, self.sr)
