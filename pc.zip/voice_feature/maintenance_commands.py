# -*- coding: utf-8 -*-
"""Privacy, backup, update and self-check commands outside the STT main loop."""
from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any


def dispatch_maintenance_command(
    plain_text: str,
    *,
    cfg: dict,
    private: dict,
    speak: Callable[[str], Any],
    syslog: Callable[[str, str], Any],
    status: Any,
    done: Callable[[], bool],
    clear_all_data: Callable[[], int],
    undo_last: Callable[[], Any],
    do_export: Callable[[], Any],
    do_import: Callable[[], Any],
    do_update: Callable[[], Any],
    apply_update_now: Callable[[], Any],
    diag_pack: Callable[[], Any],
    self_check: Callable[..., list[str]],
    now: Callable[[], float] = time.time,
    log: Callable[[str], Any] = print,
) -> bool | None:
    """Run one local maintenance command, or return ``None`` when unmatched."""
    if any(word in plain_text for word in (
        "别记这段", "别记了", "不要记录", "别记录",
    )):
        private["until"] = now() + float(cfg.get("private_minutes") or 5) * 60
        speak("好，这几分钟我说过的话都不记")
        log("   ↳ 🕶 进入隐私静默期")
        status.set("sent", text="🕶 暂不记录")
        return done()

    if any(word in plain_text for word in ("可以记了", "恢复记录")):
        private["until"] = 0.0
        speak("好，恢复记录")
        status.set("sent", text="✍️ 恢复记录")
        return done()

    if "确定清空" in plain_text:
        try:
            armed = float(private.get("clear_ask") or 0.0) > now()
        except Exception:
            armed = False
        if armed:
            count = clear_all_data()
            private["clear_ask"] = 0.0
            speak(f"清掉了 {count} 个文件")
            status.set("sent", text=f"🧹 已清空 {count} 个文件")
        else:
            speak("先说要清空，我再问你一次")
        return done()

    if any(word in plain_text for word in (
        "清空所有记录", "清空数据", "删除所有记录", "清空日志",
    )):
        private["clear_ask"] = now() + 30
        speak("这会删掉便签、记账、记忆、日志和成就。确定就说「确定清空」")
        status.set("sent", text="🧹 等你确认")
        return done()

    if any(word in plain_text for word in ("撤销", "撤回", "撤消")) and len(plain_text) <= 6:
        undo_last()
        return done()
    if any(word in plain_text for word in ("导出数据", "备份数据", "导出备份")):
        do_export()
        return done()
    if any(word in plain_text for word in ("打包诊断", "上报问题", "诊断包")):
        output = diag_pack()
        speak(
            f"诊断包好了，藏在导出文件夹里：{output.name}" if output
            else "诊断包没打出来"
        )
        syslog("诊", f"生成诊断包：{output.name if output else '失败'}")
        return done()
    if any(word in plain_text for word in ("导入数据", "恢复数据", "导入备份")):
        do_import()
        return done()
    if any(word in plain_text for word in ("检查更新", "有没有新版本")):
        do_update()
        return done()
    if "开始更新" in plain_text:
        apply_update_now()
        return done()
    if any(word in plain_text for word in ("自检", "检查一下自己")):
        problems = self_check(speak_it=False)
        speak("自检都正常" if not problems else "自检发现：" + "；".join(problems))
        status.set("sent", text="🩺 " + ("正常" if not problems else "有问题"))
        return done()
    return None
