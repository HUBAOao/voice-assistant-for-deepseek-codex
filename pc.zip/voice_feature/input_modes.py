"""Persisted voice-input mode and process launch arguments."""
from __future__ import annotations

from collections.abc import Mapping

VALID_INPUT_MODES = ("talk", "hold")
DEFAULT_INPUT_MODE = "talk"
DEFAULT_HOLD_KEY = "*"


def selected_input_mode(config: Mapping | None) -> str:
    """Return one supported voice mode, defaulting safely for old configs."""
    mode = str((config or {}).get("input_mode") or DEFAULT_INPUT_MODE)
    return mode if mode in VALID_INPUT_MODES else DEFAULT_INPUT_MODE


def selected_hold_key(config: Mapping | None) -> str:
    key = str((config or {}).get("hold_key") or DEFAULT_HOLD_KEY).strip()
    return key or DEFAULT_HOLD_KEY


def input_mode_args(config: Mapping | None) -> list[str]:
    """Arguments shared by startup, update and watchdog restarts."""
    mode = selected_input_mode(config)
    args = ["--mode", mode]
    if mode == "hold":
        args.extend(["--key", selected_hold_key(config)])
    return args


__all__ = [
    "DEFAULT_HOLD_KEY",
    "DEFAULT_INPUT_MODE",
    "VALID_INPUT_MODES",
    "input_mode_args",
    "selected_hold_key",
    "selected_input_mode",
]
