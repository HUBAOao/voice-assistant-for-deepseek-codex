"""Keep local command preflight outside the main runtime closure."""
from __future__ import annotations

import re
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeCommandGateDependencies:
    speaking_now: Callable[[], bool]
    shut_up: Callable[[], Any]
    stop_words: Iterable[str]
    is_stop_word: Callable[[str, Iterable[str]], bool]
    last_unsent: dict
    pick_send_target: Callable[[], tuple[int, str]]
    send: Callable[[str, int], bool]
    busy: dict
    status: Any
    speak: Callable[[str], Any]
    syslog: Callable[[str, str], Any]
    emit: Callable[[str], Any]
    mute: dict
    mute_command: Callable[..., str]
    dispatch_mute: Callable[..., bool]
    self_speech: dict
    self_voice_miss: dict
    self_spoken_text: Callable[[], str]
    recent_spoken: Callable[[], Iterable[str]]
    sounds_like: Callable[[str, str], bool]
    repeated_after_miss: Callable[[str, dict], bool]
    extract_word: Callable[..., tuple[str, str]]
    wake_words: list[str]
    wake_level: dict
    dictation: Any
    is_standalone_command: Callable[[str], bool]
    dispatch_dictation: Callable[..., bool]
    beep: Callable[[int, int], Any]
    type_text: Callable[[str], Any]
    syslog_file: Path
    record_resend: Callable[[str, int, str, float], Any] | None = None
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], Any] = time.sleep


@dataclass(frozen=True)
class RuntimeCommandGateOutcome:
    """Only short local commands need an early exit from the main handler."""

    handled: bool


class RuntimeCommandGateAssembly:
    """Apply local commands in their established, user-visible order."""

    def __init__(self, deps: RuntimeCommandGateDependencies) -> None:
        self.deps = deps

    def evaluate(
        self,
        text: str,
        *,
        from_phone: bool = False,
    ) -> RuntimeCommandGateOutcome:
        deps = self.deps

        if deps.speaking_now() and deps.is_stop_word(text, deps.stop_words):
            deps.shut_up()

        if any(
            word in text.replace(" ", "")
            for word in ("重发一遍", "再发一遍", "重发一下")
        ):
            if (
                deps.last_unsent.get("text")
                and deps.clock() - float(deps.last_unsent.get("at") or 0.0) < 600
            ):
                try:
                    hwnd, title = deps.pick_send_target()
                except Exception:
                    hwnd, title = 0, ""
                started_at = deps.clock()
                if hwnd and deps.send(str(deps.last_unsent["text"]), hwnd):
                    deps.syslog(
                        "发",
                        f"（重发）{str(deps.last_unsent['text'])[:40]}",
                    )
                    deps.busy["on"] = True
                    deps.busy["at"] = deps.clock()
                    deps.status.set("sent", text="🔁 又发了一遍")
                    deps.speak("好，又发了一遍")
                    if deps.record_resend is not None:
                        deps.record_resend(
                            str(deps.last_unsent["text"]),
                            hwnd,
                            title,
                            started_at,
                        )
                    return RuntimeCommandGateOutcome(handled=True)
            deps.speak("我这儿没有待重发的话")
            return RuntimeCommandGateOutcome(handled=True)

        mute_action = deps.mute_command(
            text,
            muted=bool(deps.mute["on"]),
        )
        if deps.dispatch_mute(
            mute_action,
            set_muted=lambda value: deps.mute.update(on=bool(value)),
            speak=deps.speak,
            status=deps.status,
            syslog=deps.syslog,
            shut_up=deps.shut_up,
        ):
            if mute_action == "mute":
                deps.emit("\n   ↳ 🔇 静音中：说话、语音输入照常")
            return RuntimeCommandGateOutcome(handled=True)

        if not from_phone and (
            deps.self_speech["on"] or deps.speaking_now()
        ):
            candidates = [deps.self_spoken_text(), *deps.recent_spoken()]
            mine = next(
                (
                    sentence
                    for sentence in candidates
                    if sentence and deps.sounds_like(text, sentence)
                ),
                "",
            )
            if mine:
                repeated = bool(
                    deps.self_voice_miss["text"]
                    and deps.repeated_after_miss(
                        text,
                        deps.self_voice_miss,
                    )
                )
                if repeated:
                    deps.emit(
                        "   ↳ 🔁 这句你刚说过一遍（上次被当成我的声音丢了），"
                        "这次算你说的"
                    )
                    deps.syslog("听", f"（重复第二遍，当你说的话）{text[:40]}")
                    deps.self_voice_miss.update(text="", at=0.0)
                else:
                    deps.emit("   ↳ （这句是它自己念的，忽略）")
                    deps.syslog("噪", f"（自己的声音）{text[:40]}")
                    deps.self_voice_miss.update(
                        text=text,
                        at=deps.clock(),
                    )
                    deps.status.set_mood("")
                    return RuntimeCommandGateOutcome(handled=True)
            else:
                head_hit = deps.extract_word(
                    text[:4],
                    deps.wake_words,
                    fuzzy=deps.wake_level["fuzzy"],
                    leading=False,
                )[1]
                whole_hit = len(text) <= 6 and deps.extract_word(
                    text,
                    deps.wake_words,
                    fuzzy=deps.wake_level["fuzzy"],
                    leading=deps.wake_level["leading"],
                )[1]
                if head_hit or whole_hit:
                    deps.shut_up()
                    deps.emit("   ↳ 🔇 你打断了它，接着听你说")
                    deps.syslog("听", f"（抢话）{text}")
                    deps.sleep(0.15)
                else:
                    deps.emit("   ↳ （这句像是我自己说的，忽略）")
                    deps.status.set_mood("")
                    return RuntimeCommandGateOutcome(handled=True)

        plain_text = (
            text.replace(" ", "") if deps.is_standalone_command(text) else ""
        )
        dictation_action = deps.dictation.command(
            plain_text,
            stop_requested=deps.is_stop_word(text, deps.stop_words),
        )
        if deps.dispatch_dictation(
            dictation_action,
            text,
            speak=deps.speak,
            status=deps.status,
            beep=deps.beep,
            type_text=deps.type_text,
        ):
            return RuntimeCommandGateOutcome(handled=True)

        if plain_text in (
            "状态",
            "现在的状态",
            "现在状态",
            "什么状态",
            "进度",
            "现在怎么样",
            "你在干嘛",
            "在干什么",
            "在干嘛呢",
        ):
            tail = ""
            try:
                rows = deps.syslog_file.read_text(
                    encoding="utf-8",
                    errors="replace",
                ).splitlines()
                for line in reversed(rows):
                    match = re.match(
                        r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[(.+?)\] (.*)$",
                        line,
                    )
                    if not match:
                        continue
                    tag, body = match.group(1), match.group(2)
                    if tag in ("听", "答") and body and "（手机）" not in body:
                        tail = (
                            f"最近一条是{'你说的' if tag == '听' else '它念的'}："
                            f"{body[:40]}。"
                        )
                        break
            except Exception:
                tail = ""
            hint_text = str(
                (getattr(deps.status, "_last", {}) or {}).get("text") or ""
            )
            answer = (
                f"现在状态是 {deps.status.state}"
                + (f"，{hint_text}" if hint_text else "")
                + (f"。{tail}" if tail else "。")
            )
            deps.speak(answer)
            deps.emit(f"   ↳ 📊 {answer}")
            deps.syslog("动", f"问状态：{answer[:60]}")
            deps.status.set("sent", text="📊 已报状态")
            return RuntimeCommandGateOutcome(handled=True)

        return RuntimeCommandGateOutcome(handled=False)


__all__ = [
    "RuntimeCommandGateAssembly",
    "RuntimeCommandGateDependencies",
    "RuntimeCommandGateOutcome",
]
