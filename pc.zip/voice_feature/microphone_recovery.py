# -*- coding: utf-8 -*-
"""Recover microphone streams and protect short capture operations."""
from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any


def is_disconnect_error(exc: BaseException) -> bool:
    """Return whether an exception is consistent with a lost audio device."""
    text = f"{type(exc).__name__} {exc}".lower()
    return "device" in text or "portaudio" in text or "stream" in text


class MicrophoneRecovery:
    """Own the active stream and recover it without closing a stale instance."""

    def __init__(
        self,
        *,
        stream: Any,
        rate: int,
        recorder: Any,
        device: Any,
        reopen: Callable[[], tuple[Any, int, Any, Any]],
        close_stream: Callable[[Any], None] | None = None,
        wait: Callable[[float], None] | None = None,
        retries: int = 6,
        retry_delay: float = 2.0,
        on_reconnecting: Callable[[], None] | None = None,
        on_reconnected: Callable[[int], None] | None = None,
        on_failed: Callable[[], None] | None = None,
        on_interrupted: Callable[[], None] | None = None,
    ) -> None:
        self.stream = stream
        self.rate = int(rate)
        self.recorder = recorder
        self.device = device
        self.available = True
        self._reopen = reopen
        self._close_stream_fn = close_stream or self._close_device
        self._wait = wait or time.sleep
        self._retries = max(1, int(retries))
        self._retry_delay = max(0.0, float(retry_delay))
        self._on_reconnecting = on_reconnecting
        self._on_reconnected = on_reconnected
        self._on_failed = on_failed
        self._on_interrupted = on_interrupted

    @staticmethod
    def _close_device(stream: Any) -> None:
        try:
            stream.stop()
        except Exception:
            pass
        try:
            stream.close()
        except Exception:
            pass

    @staticmethod
    def _safe_call(callback: Callable[..., None] | None, *args: Any) -> None:
        if callback is None:
            return
        try:
            callback(*args)
        except Exception:
            pass

    def _mark_interrupted(self) -> None:
        self.available = False
        self._safe_call(self._on_interrupted)

    def recover(self) -> bool:
        """Try to reopen the configured device and atomically replace the state."""
        if self.available:
            return True
        self._safe_call(self._on_reconnecting)
        try:
            self._close_stream_fn(self.stream)
        except Exception:
            pass
        for attempt in range(1, self._retries + 1):
            self._wait(self._retry_delay)
            try:
                stream, rate, recorder, device = self._reopen()
            except Exception:
                continue
            self.stream = stream
            self.rate = int(rate)
            self.recorder = recorder
            self.device = device
            self.available = True
            self._safe_call(self._on_reconnected, attempt)
            return True
        self._safe_call(self._on_failed)
        return False

    def safe_calibrate(self, fallback: float = 0.05) -> float:
        try:
            return float(self.recorder.calibrate())
        except Exception as exc:
            if not is_disconnect_error(exc):
                raise
            self._mark_interrupted()
            return float(fallback)

    def safe_record(self, *args: Any, **kwargs: Any) -> Any:
        try:
            return self.recorder.record_utterance(*args, **kwargs)
        except Exception as exc:
            if not is_disconnect_error(exc):
                raise
            self._mark_interrupted()
            return None
