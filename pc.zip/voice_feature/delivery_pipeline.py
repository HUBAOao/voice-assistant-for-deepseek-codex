"""Apply the final voice-message delivery path without owning app globals."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from voice_feature.talk_state import (
    DELIVERY_CLIPBOARD,
    DELIVERY_DRY_RUN,
    DELIVERY_OFFLINE,
    DELIVERY_SEND,
    plan_delivery,
)


@dataclass(frozen=True)
class DeliveryOutcome:
    """Observable result of one final delivery attempt."""

    action: str
    sent: bool = False
    copied: bool = False


def deliver_text(
    text: str,
    *,
    hwnd: int,
    title: str,
    dry_run: bool,
    editing_settings: bool,
    send: Callable[[str, int], bool],
    copy: Callable[[str], bool],
    status,
    syslog: Callable[..., object],
    print_line: Callable[..., object] = print,
    confirm: Callable[[str], bool] | None = None,
    on_sent: Callable[[], object] | None = None,
    before_send: Callable[[], object] | None = None,
    sent_suffix: str = "",
) -> DeliveryOutcome:
    """Copy or send a recognized message while keeping the order deterministic.

    Confirmation is requested only when the original path is a real send.  A
    failed paste falls back to the clipboard and is never retried automatically.
    """
    value = str(text)
    action = plan_delivery(
        dry_run=bool(dry_run),
        has_window=bool(hwnd),
        editing_settings=bool(editing_settings),
    )
    if action == DELIVERY_SEND and confirm is not None and not confirm(value):
        action = DELIVERY_CLIPBOARD

    if action == DELIVERY_DRY_RUN:
        copied = bool(copy(value))
        print_line(f"   ↳ （dry-run：本来要发「{value}」，只复制了剪贴板）")
        status.set("sent", text=f"（试跑）{value}")
        return DeliveryOutcome(action, copied=copied)

    if action == DELIVERY_OFFLINE:
        copied = bool(copy(value))
        print_line("   ↳ ⚠️ 没有可用的目标窗口：先点一下聊天窗口，文字已放剪贴板，手动 Ctrl+V")
        status.set("offline", text=f"没找到窗口，已复制：{value}")
        return DeliveryOutcome(action, copied=copied)

    if action == DELIVERY_CLIPBOARD:
        copied = bool(copy(value))
        print_line(
            f"   ↳ ✏️ 你在改设置，先不抢键盘：文字已放剪贴板（{value[:20]}…）",
            flush=True,
        )
        syslog("听", value)
        syslog("发", f"（你在改设置，只放了剪贴板）{value[:40]}")
        status.set("sent", text="📋 已复制（改设置中不抢键盘）")
        return DeliveryOutcome(action, copied=copied)

    if before_send is not None:
        before_send()
    if send(value, hwnd):
        who = str(title or "前台窗口")
        print_line(f"   ↳ 已发到「{who}」：{value}{sent_suffix}")
        syslog("听", value)
        syslog("发", f"{who}：{value[:60]}")
        if on_sent is not None:
            on_sent()
        status.set("sent", text=value)
        return DeliveryOutcome(action, sent=True)

    copied = bool(copy(value))
    print_line(f"   ↳ ⚠️ 没能把「{title}」切到前台，文字已放剪贴板，手动 Ctrl+V")
    status.set("offline", text=f"没切到窗口，已复制：{value}")
    return DeliveryOutcome(action, copied=copied)
