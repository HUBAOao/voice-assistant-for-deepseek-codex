"""Startup-only runtime policy kept separate from the main voice loop."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping


LOW_PROFILE_DEFAULTS = (
    ("caption_enabled", False),
    ("perf_mode", "eco"),
    ("anim_fps", 30),
    ("fx_trail", False),
    ("fx_glow", False),
    ("fx_sparkles", False),
    ("fx_reflection", False),
    ("fx_sweep", False),
    ("fx_ripple", False),
    ("fx_orbit", False),
    ("fx_rotor", False),
    ("fx_starflare", False),
    ("fx_aurora", False),
    ("fx_heartbeat", False),
    ("fx_burst", False),
    ("karaoke", False),
    ("big_caption", False),
    ("wave_spectrum", False),
)


@dataclass(frozen=True)
class LowProfileResult:
    changed: tuple[str, ...]
    persisted: bool


def start_enabled_plugins(
    host: object | None = None,
    emit: Callable[[str], None] = print,
) -> dict:
    """Start the plugin host without allowing a plugin failure to block STT."""
    try:
        if host is None:
            from features.plugin_registry import PLUGIN_HOST

            host = PLUGIN_HOST
        state = host.start()
        if not isinstance(state, dict):
            state = {}
        plugins = state.get("plugins") or []
        if plugins:
            emit(
                "   插件：%d 个已安装，%d 个已启用"
                % (len(plugins), sum(1 for item in plugins if item.get("enabled")))
            )
        return state
    except Exception as exc:  # noqa: BLE001
        emit(f"   （插件管理器没起来：{exc}）")
        return {}


def apply_low_profile(
    cfg: dict,
    profile: str,
    hardware: Mapping,
    config_file: Path,
    *,
    emit: Callable[[str], None] = print,
    persist: Callable[[Path, dict], None] | None = None,
) -> LowProfileResult:
    """Apply the automatic lite preset once and report whether it was saved."""
    if profile != "lite" or not cfg.get("auto_tune", True):
        return LowProfileResult((), False)

    changed: list[str] = []
    if str(cfg.get("model") or "small") not in ("tiny", "base", "small"):
        cfg["model"] = "small"
        changed.append("模型换成 small")
    for key, want in LOW_PROFILE_DEFAULTS:
        if cfg.get(key) != want:
            cfg[key] = want
            changed.append(key)

    persisted = False
    if changed and not cfg.get("auto_tuned"):
        cfg["auto_tuned"] = True
        cfg["auto_profile"] = "lite"
        try:
            if persist is not None:
                persist(config_file, cfg)
            else:
                config_file.write_text(
                    json.dumps(cfg, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            persisted = True
            emit("（低配模式：已自动调低设置 — " + "、".join(changed[:6]) + "）")
        except Exception:
            pass
    elif changed:
        emit("（低配模式：本次按低配参数运行）")

    ram = hardware.get("ram", 0)
    cores = hardware.get("cores", 0)
    try:
        ram_text = f"{float(ram):.0f}G"
    except (TypeError, ValueError):
        ram_text = f"{ram}G"
    emit(
        f"（原因：{hardware.get('why', '')}；内存 {ram_text} / {cores} 核 "
        f"/ 显卡 {'有' if hardware.get('cuda') else '无'}）"
    )
    return LowProfileResult(tuple(changed), persisted)
