# -*- coding: utf-8 -*-
"""Own external TTS playback processes so barge-in and exit can stop them."""
from __future__ import annotations

import atexit
import subprocess
import threading
import time
from collections.abc import Callable, Sequence
from typing import Any


class SpeechProcesses:
    """Track spawned readers and terminate all of them on interruption."""

    def __init__(
        self,
        *,
        spawn: Callable[..., Any] | None = None,
        grace: float = 0.75,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._spawn = spawn or subprocess.Popen
        self._grace = max(0.0, float(grace))
        self._clock = clock
        self._lock = threading.RLock()
        self._processes: dict[int, Any] = {}

    @staticmethod
    def _alive(process: Any) -> bool:
        try:
            return process.poll() is None
        except Exception:
            return False

    def _prune_locked(self) -> None:
        self._processes = {
            key: process
            for key, process in self._processes.items()
            if self._alive(process)
        }

    def spawn(self, command: Sequence[str], **kwargs: Any) -> Any:
        """Start one reader and remember it until it finishes or is stopped."""
        process = self._spawn(list(command), **kwargs)
        with self._lock:
            self._prune_locked()
            self._processes[id(process)] = process
        return process

    def forget(self, process: Any) -> None:
        with self._lock:
            self._processes.pop(id(process), None)

    def wait(self, process: Any, timeout: float | None = None) -> Any:
        """Wait for one reader and release its registry entry in every case."""
        try:
            return process.wait(timeout=timeout)
        finally:
            self.forget(process)

    def active_count(self) -> int:
        with self._lock:
            self._prune_locked()
            return len(self._processes)

    def interrupt(self) -> int:
        """Gracefully stop every reader, killing only those that outlive grace."""
        with self._lock:
            self._prune_locked()
            processes = list(self._processes.values())

        for process in processes:
            if not self._alive(process):
                continue
            try:
                process.terminate()
            except Exception:
                pass

        deadline = self._clock() + self._grace
        for process in processes:
            if not self._alive(process):
                continue
            remaining = max(0.0, deadline - self._clock())
            try:
                process.wait(timeout=remaining)
            except Exception:
                pass
            if self._alive(process):
                try:
                    process.kill()
                except Exception:
                    pass

        with self._lock:
            for process in processes:
                self._processes.pop(id(process), None)
        return len(processes)


SPEECH_PROCESSES = SpeechProcesses()
atexit.register(SPEECH_PROCESSES.interrupt)


__all__ = ["SPEECH_PROCESSES", "SpeechProcesses"]
