# -*- coding: utf-8 -*-
"""Process one recognized utterance without embedding business in ``main()``."""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from features.voice_actions import parse_voice_action
from voice_feature.action_dispatch import dispatch as dispatch_action
from voice_feature.delivery_pipeline import deliver_text
from voice_feature.local_command_assembly import (
    LocalCommandDependencies,
    dispatch_local_commands,
)


@dataclass(frozen=True)
class RuntimeUtteranceDependencies:
    """Live callbacks shared by transcription, command routing and delivery."""

    args: Any
    config: dict
    config_file: Path
    app_dir: Path
    mode: str
    rate: int
    transcriber: Any
    status: Any
    not_heard: dict
    voiceprint: dict
    editing: dict
    last_sent: dict
    music: dict
    private: dict
    tutorial: dict
    busy: dict
    target: str | None
    tracker: Any
    command_gate: Any
    wake_gate: Any
    send_gate: Any
    delivery_tracking: Any
    task_store: Any
    cancel_reference_echo: Callable[[Any, int], Any]
    not_heard_due: Callable[..., bool]
    speak: Callable[..., Any]
    syslog: Callable[[str, str], None]
    emit: Callable[..., Any]
    append_log: Callable[[Path, str], None]
    guess_mood: Callable[[Any, int, str], str]
    canonize: Callable[[str], str]
    apply_corrections: Callable[[str, Any], str]
    is_hallucination: Callable[[str], bool]
    voice_enroll: Callable[[Any, int], bool]
    voice_score: Callable[[Any, int], float | None]
    is_standalone_command: Callable[[str], bool]
    phone_new_thread: Callable[[str], Any]
    set_phone_window: Callable[[str, str], Any]
    done: Callable[[], bool]
    arm_followup: Callable[[], None]
    load_config: Callable[[], dict]
    beep: Callable[[int, int], Any]
    run_shortcut: Callable[..., Any]
    parse_repeat: Callable[[str], Any]
    syslog_search: Callable[..., Any]
    weekly_report: Callable[[], str]
    find_window: Callable[..., Any]
    press_key: Callable[..., Any]
    open_named: Callable[..., Any]
    paste_clipboard: Callable[..., Any]
    grab_screen: Callable[..., Any]
    get_reply_reader: Callable[[], Any]
    focus_active: Callable[[], bool]
    focus_left: Callable[[], float]
    focus_start: Callable[..., Any]
    focus_stop: Callable[[], Any]
    transform: Callable[[], Any]
    brief_now: Callable[[], Any]
    say_diary: Callable[[], Any]
    tutorial_say: Callable[..., Any]
    game_feed: Callable[[str], bool]
    game_start: Callable[..., Any]
    say_ledger: Callable[[], Any]
    say_notes: Callable[[], Any]
    add_ledger: Callable[..., Any]
    add_note: Callable[..., Any]
    clear_all_data: Callable[[], Any]
    undo_last: Callable[[], Any]
    do_export: Callable[[], Any]
    do_import: Callable[[], Any]
    do_update: Callable[[], Any]
    apply_update_now: Callable[..., Any]
    diag_pack: Callable[[], Any]
    self_check: Callable[..., Any]
    train_wake_voice: Callable[[], Any]
    set_config: Callable[..., Any]
    schedule_restart: Callable[[], Any]
    read_selected: Callable[[], Any]
    start_reminder: Callable[..., Any]
    copy_to_clipboard: Callable[[str], bool]
    send_it: Callable[[str, int], bool]
    confirm_ok: Callable[[str], bool]
    soft_pet_notify: Callable[[bool], Any]
    ack_phrase: Callable[[dict], str]
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], Any] = time.sleep


class RuntimeUtteranceAssembly:
    """Own the historical ``handle()`` pipeline as one testable boundary."""

    def __init__(self, deps: RuntimeUtteranceDependencies) -> None:
        self.deps = deps

    def _dispatch_local(
        self,
        *,
        text_to_send: str,
        local_text: str,
        plain_text: str,
        from_phone: bool,
    ):
        deps = self.deps
        return dispatch_local_commands(
            LocalCommandDependencies(
                config=deps.config,
                config_file=deps.config_file,
                local_text=local_text,
                plain_text=plain_text,
                text_to_send=text_to_send,
                tutorial=deps.tutorial,
                tutorial_document=deps.app_dir / "使用教程.html",
                memory_file=deps.app_dir / "memory.jsonl",
                last_sent=deps.last_sent,
                music=deps.music,
                busy=deps.busy,
                voiceprint=deps.voiceprint,
                private=deps.private,
                target=deps.target,
                tracker=deps.tracker,
                from_phone=from_phone,
                once=bool(deps.args.once),
                speak=deps.speak,
                status=deps.status,
                syslog=deps.syslog,
                emit=lambda text: deps.emit(text, flush=True),
                load_config=deps.load_config,
                arm_followup=deps.arm_followup,
                beep=deps.beep,
                run_shortcut=deps.run_shortcut,
                parse_repeat=deps.parse_repeat,
                syslog_search=deps.syslog_search,
                weekly_report=deps.weekly_report,
                find_window=deps.find_window,
                press_key=deps.press_key,
                open_named=deps.open_named,
                paste_clipboard=deps.paste_clipboard,
                grab_screen=deps.grab_screen,
                get_reply_reader=deps.get_reply_reader,
                focus_active=deps.focus_active,
                focus_left=deps.focus_left,
                focus_start=deps.focus_start,
                focus_stop=deps.focus_stop,
                transform=deps.transform,
                brief_now=deps.brief_now,
                say_diary=deps.say_diary,
                tutorial_say=deps.tutorial_say,
                game_feed=deps.game_feed,
                game_start=deps.game_start,
                say_ledger=deps.say_ledger,
                say_notes=deps.say_notes,
                add_ledger=deps.add_ledger,
                add_note=deps.add_note,
                clear_all_data=deps.clear_all_data,
                undo_last=deps.undo_last,
                do_export=deps.do_export,
                do_import=deps.do_import,
                do_update=deps.do_update,
                apply_update_now=deps.apply_update_now,
                diag_pack=deps.diag_pack,
                self_check=deps.self_check,
                train_wake_voice=deps.train_wake_voice,
                set_config=deps.set_config,
                schedule_restart=deps.schedule_restart,
                read_selected=deps.read_selected,
                start_reminder=deps.start_reminder,
            )
        )

    def process(
        self,
        audio: Any | None,
        sr: int | None = None,
        pre_text: str | None = None,
        from_phone: bool = False,
    ) -> bool:
        """Recognize and route one utterance; return True when the app exits."""
        deps = self.deps
        sr = sr or deps.rate
        if audio is not None and not from_phone:
            try:
                audio = deps.cancel_reference_echo(audio, sr)
            except Exception:
                pass

        deps.status.set("thinking")
        started = deps.clock()
        text = (
            pre_text
            if pre_text is not None
            else deps.transcriber.transcribe(audio)
        )
        if not text:
            deps.emit(
                "\r（识别不到内容，继续）" + " " * 20,
                flush=True,
            )
            deps.status.set("idle")
            if deps.not_heard_due(
                audio,
                sr,
                previous_at=deps.not_heard["at"],
                now=deps.clock(),
            ):
                deps.not_heard["at"] = deps.clock()
                deps.syslog("听", "（这段没听清）")
                if deps.config.get("not_heard_reply", True):
                    deps.speak("没听清，再说一遍")
            return False

        mood = (
            deps.guess_mood(audio, sr, text)
            if audio is not None
            else ""
        )
        deps.status.mood = ""
        text = deps.canonize(text)
        text = deps.apply_corrections(
            text,
            deps.config.get("corrections"),
        )
        if audio is not None and deps.is_hallucination(text):
            deps.emit(
                "\r（这句像是电视/杂音里编出来的，丢掉）" + " " * 10,
                flush=True,
            )
            deps.syslog("噪", f"（疑似幻觉）{text[:30]}")
            deps.status.set("idle")
            return False

        deps.emit(f"\n📝 {text}")
        if audio is not None:
            deps.emit(
                f"   （{len(audio) / sr:.1f}s 语音，"
                f"识别耗时 {deps.clock() - started:.1f}s）"
            )
        else:
            deps.emit(
                f"   （手机发来的命令，耗时 {deps.clock() - started:.2f}s）",
                flush=True,
            )
        deps.append_log(Path(deps.args.out), text)

        if deps.mode == "talk":
            if audio is not None and deps.voiceprint["enroll"]:
                deps.voiceprint["enroll"] = False
                ok = deps.voice_enroll(audio, sr)
                deps.syslog(
                    "声",
                    "声纹注册" + (
                        "成功" if ok else "失败（声音太短或太轻）"
                    ),
                )
                deps.speak(
                    "记住你的声音了" if ok else "没听清，等下再说一次"
                )
                deps.emit(
                    f"   ↳ 🎙 声纹注册{'成功' if ok else '失败'}",
                    flush=True,
                )
                deps.status.set(
                    "sent",
                    text="🎙 声纹已注册" if ok else "🎙 没听清",
                )
                return False

            score = (
                deps.voice_score(audio, sr)
                if audio is not None
                else None
            )
            deps.voiceprint["last_score"] = score
            deps.voiceprint["wake_score"] = None
            if score is not None and audio is not None:
                deps.syslog("声", f"声纹相似度 {score:.2f}")
                if (
                    deps.config.get("voiceprint_warn", False)
                    and score < 0.55
                ):
                    deps.status.set(
                        "sent",
                        text=f"⚠️ 这次不太像你的声音（{score:.2f}）",
                    )
                    deps.emit(
                        f"   ↳ 🎙 声纹相似度偏低：{score:.2f}",
                        flush=True,
                    )

            command_outcome = deps.command_gate.evaluate(
                text,
                from_phone=from_phone,
            )
            if command_outcome.handled:
                return False

            wake_outcome = deps.wake_gate.evaluate(
                text,
                audio=audio,
                mood=mood,
                from_phone=from_phone,
            )
            if not wake_outcome.allowed:
                return False
            text_to_send = wake_outcome.text
            local_text = (
                text_to_send
                if deps.is_standalone_command(text_to_send)
                else ""
            )
            plain_text = local_text.replace(" ", "")

            action = parse_voice_action(local_text)
            if action.kind == "send_message":
                text_to_send = action.text
                deps.syslog(
                    "动",
                    "语音动作：发送消息到当前会话"
                    f"（风险 {action.risk}）",
                )
            elif action.kind != "unknown":
                outcome = dispatch_action(
                    action,
                    task_store=deps.task_store,
                    new_thread=deps.phone_new_thread,
                    set_target=deps.set_phone_window,
                )
                deps.syslog(
                    "动",
                    f"语音动作 {action.kind}"
                    f"（风险 {action.risk}）：{outcome.message}",
                )
                deps.emit(
                    f"   ↳ 🎛 {action.kind}：{outcome.message}",
                    flush=True,
                )
                deps.status.set(
                    "sent" if outcome.ok else "offline",
                    text=outcome.message,
                )
                if outcome.message:
                    deps.speak(outcome.message)
                if outcome.terminate:
                    return bool(deps.done())

            local_result = self._dispatch_local(
                text_to_send=text_to_send,
                local_text=local_text,
                plain_text=plain_text,
                from_phone=from_phone,
            )
            text_to_send = local_result.text_to_send
            if local_result.handled:
                return local_result.terminate

            gate = deps.send_gate.prepare(
                text_to_send,
                from_phone=from_phone,
            )
            if not gate.allowed:
                return False
            deliver_text(
                text_to_send,
                hwnd=gate.hwnd,
                title=gate.title,
                dry_run=bool(deps.args.dry_run),
                editing_settings=bool(deps.editing["on"]),
                send=deps.send_it,
                copy=deps.copy_to_clipboard,
                status=deps.status,
                syslog=deps.syslog,
                print_line=deps.emit,
                confirm=deps.confirm_ok,
                before_send=lambda: deps.delivery_tracking.before_send(
                    text_to_send
                ),
                on_sent=lambda: deps.delivery_tracking.after_sent(
                    text=text_to_send,
                    hwnd=gate.hwnd,
                    title=gate.title,
                    audio=audio,
                    sr=sr,
                    from_phone=from_phone,
                    mood=mood,
                ),
                sent_suffix=(
                    "（并回车）"
                    if not deps.args.no_send
                    else "（未回车，自己按一下）"
                ),
            )
            deps.soft_pet_notify(bool(deps.args.beep))
            if deps.config.get("ack_enabled", True) and not from_phone:
                deps.speak(deps.ack_phrase(deps.config))
            deps.arm_followup()
            deps.sleep(1.2)
        elif not deps.args.no_clipboard and deps.copy_to_clipboard(text):
            deps.emit("   ↳ 已复制到剪贴板，Ctrl+V 就能贴进对话框")
            deps.status.set("copied", text=text)
        return bool(deps.args.once)


def assemble_utterance_runtime(
    deps: RuntimeUtteranceDependencies,
) -> RuntimeUtteranceAssembly:
    return RuntimeUtteranceAssembly(deps)


__all__ = [
    "RuntimeUtteranceAssembly",
    "RuntimeUtteranceDependencies",
    "assemble_utterance_runtime",
]
