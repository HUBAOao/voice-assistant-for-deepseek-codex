# -*- coding: utf-8 -*-
"""Small lifecycle boundary for daemon work and repeatable shutdown."""
from __future__ import annotations

import threading
import time
from collections.abc import Callable


class RuntimeLifecycle:
    """Start named daemon jobs and close runtime resources in reverse order.

    The boundary deliberately knows nothing about STT, Tk or Windows. Callers
    provide already-bound callbacks, which keeps startup and shutdown testable
    without opening a microphone or a window.
    """

    def __init__(
        self,
        thread_factory: Callable[..., object] | None = None,
    ) -> None:
        self._thread_factory = thread_factory or threading.Thread
        self._threads: dict[str, object] = {}
        self._closers: list[tuple[str, Callable[[], object]]] = []
        self._closed = False

    @property
    def closed(self) -> bool:
        return self._closed

    def start_daemon(
        self,
        name: str,
        target: Callable[[], object],
        *,
        delay: float = 0.0,
        sleep: Callable[[float], object] = time.sleep,
    ) -> object:
        """Start one named daemon thread, reusing a still-live job by name."""
        if self._closed:
            raise RuntimeError("runtime lifecycle is already closed")
        current = self._threads.get(name)
        if current is not None:
            try:
                alive = bool(current.is_alive())
            except Exception:
                alive = False
            if alive:
                return current

        def runner() -> None:
            if delay > 0:
                sleep(delay)
            target()

        thread = self._thread_factory(
            target=runner,
            name=name,
            daemon=True,
        )
        thread.start()
        self._threads[name] = thread
        return thread

    def register_closeable(
        self,
        name: str,
        closer: Callable[[], object],
    ) -> None:
        """Register one cleanup callback; each callback runs at most once."""
        if self._closed:
            raise RuntimeError("runtime lifecycle is already closed")
        self._closers.append((name, closer))

    def close(self) -> list[tuple[str, Exception]]:
        """Run cleanup in reverse registration order and collect failures."""
        if self._closed:
            return []
        self._closed = True
        errors: list[tuple[str, Exception]] = []
        while self._closers:
            name, closer = self._closers.pop()
            try:
                closer()
            except Exception as exc:  # noqa: BLE001
                errors.append((name, exc))
        return errors

    def thread_names(self) -> list[str]:
        """Return registered daemon names for diagnostics and tests."""
        return list(self._threads)
