# -*- coding: utf-8 -*-
"""Execute structured voice actions without the main speech-loop code."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from features.voice_actions import VoiceAction


@dataclass(frozen=True)
class ActionOutcome:
    ok: bool
    message: str
    terminate: bool = False


def dispatch(
    action: VoiceAction,
    *,
    task_store: Any = None,
    new_thread: Callable[[], tuple[bool, str]] | None = None,
    set_target: Callable[[str, str], tuple[bool, str]] | None = None,
) -> ActionOutcome:
    """Run approve/reject/task/thread actions with the existing local surfaces.

    The caller remains responsible for speaking the returned message and for
    deciding whether normal chat should stop after the action.
    """
    try:
        if action.kind in {"approve", "reject", "cancel_task", "task_status"}:
            return _task_action(action, task_store)
        if action.kind == "switch_thread":
            return _switch_thread(action, set_target)
        if action.kind == "new_thread":
            if new_thread is None:
                raise RuntimeError("新对话入口还没接上")
            ok, message = new_thread()
            return ActionOutcome(bool(ok), str(message or ""))
        return ActionOutcome(False, "这个语音动作还没有接上")
    except Exception as exc:  # noqa: BLE001
        return ActionOutcome(False, str(exc)[:160])


def _task_action(action: VoiceAction, task_store: Any) -> ActionOutcome:
    from features.tasks import TaskStore

    store = task_store or TaskStore()
    if action.kind == "task_status":
        items = store.list(limit=5)
        waiting = [item for item in items
                   if item.get("status") == "waiting_approval"]
        message = (f"最近 {len(items)} 个任务"
                   + (f"，{len(waiting)} 个等你批准" if waiting else ""))
        return ActionOutcome(True, message)

    if action.kind in {"approve", "reject"}:
        pending = next((item for item in store.list(status="waiting_approval")
                        if item.get("approval")), None)
        if not pending:
            return ActionOutcome(False, "没有待批准的任务", terminate=True)
        approved = action.kind == "approve"
        store.decide(
            pending["id"],
            approved,
            "语音批准" if approved else "语音拒绝",
        )
        return ActionOutcome(
            True,
            "已批准当前任务" if approved else "已拒绝当前任务",
            terminate=True,
        )

    running = next((item for item in store.list(status="running")), None)
    if not running:
        return ActionOutcome(False, "没有正在运行的任务", terminate=True)
    store.update(running["id"], status="cancelled")
    return ActionOutcome(True, "已取消当前任务", terminate=True)


def _switch_thread(
    action: VoiceAction,
    set_target: Callable[[str, str], tuple[bool, str]] | None,
) -> ActionOutcome:
    import codex_threads

    rows = codex_threads.list_threads()
    target = action.target
    if target == "recent" and len(rows) > 1:
        row = rows[1]
    else:
        row = next((item for item in rows if target and (
            target in str(item.get("name") or "")
            or str(item.get("name") or "") in target
        )), None)
    if not row:
        return ActionOutcome(False, "没找到那个会话")

    name = str(row.get("name") or "")
    thread_id = str(row.get("id") or "")
    ok, message = codex_threads.open_thread(name, thread_id)
    if ok and set_target is not None:
        set_target(name, thread_id)
    return ActionOutcome(bool(ok), str(message or ""))
