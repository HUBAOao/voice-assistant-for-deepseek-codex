"""Persistent mute switch and its side effects."""

from __future__ import annotations

import time
from typing import Callable


MUTE_WORDS = (
    "静音",
    "别出声",
    "不用出声",
    "别说话",
    "先别念",
    "只打字",
)
UNMUTE_WORDS = (
    "恢复出声",
    "可以说话",
    "出声吧",
    "解除静音",
    "说话吧",
    "恢复语音",
)


def mute_command(text: str, *, muted: bool) -> str:
    """Return ``mute``, ``unmute`` or an empty string for this sentence."""
    compact = str(text or "").replace(" ", "")
    if any(word in compact for word in MUTE_WORDS):
        return "mute"
    if muted and any(word in compact for word in UNMUTE_WORDS):
        return "unmute"
    return ""


def dispatch_mute_command(
    command: str,
    *,
    set_muted: Callable[[bool], object],
    speak: Callable[[str], object],
    status,
    syslog: Callable[[str, str], object],
    shut_up: Callable[[], object],
    sleep: Callable[[float], object] = time.sleep,
) -> bool:
    """Apply one mute transition in the same order as the legacy handler."""
    if command == "mute":
        speak("好，不出声了。要说话就喊一句「恢复出声」")
        sleep(1.2)
        set_muted(True)
        shut_up()
        status.set("sent", text="🔇 已静音（你说你的，我不出声）")
        syslog("静", "你说「静音」：它不念了，但还听着")
        return True
    if command == "unmute":
        set_muted(False)
        status.set("sent", text="🔊 恢复出声")
        syslog("静", "你说「恢复出声」")
        speak("好，我说话了")
        return True
    return False
