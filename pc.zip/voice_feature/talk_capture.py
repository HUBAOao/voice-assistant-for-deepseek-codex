"""Talk-mode capture with injected status, duplex and partial-caption effects."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

from voice_feature.audio_capture import continue_long_capture, has_utterance


@dataclass(frozen=True)
class TalkCaptureDependencies:
    recorder: Any
    rate: int
    cfg: dict
    self_speech: dict
    music: dict
    spoken_flag: dict
    status: Any
    syslog: Callable[[str, str], None]
    shut_up: Callable[[], None]
    speaking_now: Callable[[], bool]
    duplex: Any
    cancel_reference_echo: Callable[[np.ndarray, int], np.ndarray]
    spectrum_bands: Callable[[np.ndarray, int], list[float]]
    transcriber: Any
    safe_calibrate: Callable[[], float]
    safe_record: Callable[..., np.ndarray | None]
    checked_pause: Callable[[], bool]
    on_speech: Callable[[], None]
    hint: str
    wake_enabled: bool


def capture_talk_utterance(deps: TalkCaptureDependencies) -> np.ndarray | None:
    """Capture one talk-mode utterance, including barge-in and long joins."""
    recorder = deps.recorder
    rate = deps.rate
    status = deps.status

    if deps.checked_pause():
        recorder._read()
        return None

    deps.self_speech["on"] = deps.speaking_now()
    threshold = deps.safe_calibrate()
    if deps.self_speech["on"]:
        threshold *= 1.8
    deps.spoken_flag["first"] = True
    status.set(
        "idle" if deps.wake_enabled else "listening",
        hint=deps.hint,
    )
    print("\r⌛ 在听你说话…" + " " * 24, flush=True)

    partial = {"text": "", "busy": False, "at": 0.0}

    def show_partial(chunk: np.ndarray) -> None:
        """Recognize a bounded partial clip without blocking capture."""
        if not deps.cfg.get("caption_enabled", True):
            return
        if chunk.size > 7 * rate:
            return
        now = time.time()
        if partial["busy"] or now - partial["at"] < 0.35:
            return
        partial["busy"] = True
        partial["at"] = now

        def job() -> None:
            try:
                got = deps.transcriber.transcribe(chunk)
                if got and len(got) >= len(partial["text"]):
                    partial["text"] = got
                    status.set(
                        "hearing",
                        text=got,
                        level=status_level["v"],
                    )
            except Exception:
                pass
            finally:
                partial["busy"] = False

        threading.Thread(target=job, daemon=True).start()

    status_level = {"v": 0.0}
    status_bands = {"b": []}
    speech_tick = {"n": 0}

    def on_level_partial(v: float, block=None) -> None:
        try:
            barge_level = v
            if block is not None:
                clean = deps.cancel_reference_echo(block, rate)
                barge_level = float(
                    np.sqrt(np.mean(clean ** 2) + 1e-12)
                )
            if deps.duplex.audio_frame(barge_level) is not None:
                deps.shut_up()
                deps.syslog("检", "检测到用户插话，已立即停止播报")
        except Exception:
            pass
        status_level["v"] = v
        speech_tick["n"] += 1
        if speech_tick["n"] % 5 == 0 and deps.speaking_now():
            deps.self_speech["on"] = True
        if deps.music.get("on") and block is not None:
            status_bands["b"] = deps.spectrum_bands(block, rate)
        status.level(
            v,
            "hearing",
            text=partial["text"],
            bands=status_bands["b"] if deps.music.get("on") else None,
        )

    audio = deps.safe_record(
        threshold,
        deps.on_speech,
        tick=deps.checked_pause,
        on_level=on_level_partial,
        on_partial=show_partial,
    )
    if not has_utterance(audio, rate):
        return None

    if not recorder.last_cut:
        return audio

    parts = [audio]
    total = int(audio.size)
    print("\r✍️ 还没说完，接着录…" + " " * 20, flush=True)
    status.set("hearing", text="（还在说，接着说…）")
    for _ in range(5):
        more = deps.safe_record(
            threshold,
            None,
            tick=deps.checked_pause,
            on_level=on_level_partial,
        )
        if more is None or more.size == 0:
            break
        parts.append(more)
        total += int(more.size)
        if not continue_long_capture(recorder.last_cut, total, rate):
            break
    joined = np.concatenate(parts)
    print(
        f"\r✍️ 拼好了，共 {joined.size / rate:.0f} 秒" + " " * 10,
        flush=True,
    )
    return joined
