"""Pure state rules for FinDeck's wake, dictation and delivery paths.

The main speech loop still owns audio capture, voiceprints, window focus and
side effects.  This module only decides which path the next recognized sentence
should take, which makes the rules repeatable without loading a speech model.
"""

from __future__ import annotations

import time
from dataclasses import dataclass


WAKE_SEND = "send"
WAKE_LISTEN = "listen"
WAKE_LISTEN_AGAIN = "listen_again"
WAKE_CANCEL = "cancel"
WAKE_IGNORE = "ignore"
WAKE_IGNORE_VOICE = "ignore_voice"

DELIVERY_DRY_RUN = "dry_run"
DELIVERY_OFFLINE = "offline"
DELIVERY_CLIPBOARD = "clipboard"
DELIVERY_SEND = "send"

DICTATION_IDLE = "idle"
DICTATION_START = "start"
DICTATION_STOP = "stop"
DICTATION_TYPE = "type"


@dataclass(frozen=True)
class WakeDecision:
    """Result of applying the wake word and follow-up window rules."""

    action: str
    text: str = ""


class TalkState:
    """Tracks the short-lived state of one talk-mode session.

    Timing uses a monotonic clock by default because wall-clock adjustment must
    not extend or shorten the wake/follow-up windows.
    """

    def __init__(self, *, wake_timeout: float = 12.0,
                 followup_seconds: float = 0.0) -> None:
        self.wake_timeout = max(0.0, float(wake_timeout))
        self.followup_seconds = max(0.0, float(followup_seconds))
        self._armed_until = 0.0

    def arm_followup(self, *, now: float | None = None) -> bool:
        """Open the no-wake-word window after a successful local action."""
        if self.followup_seconds <= 0:
            return False
        current = self._now(now)
        self._armed_until = current + self.followup_seconds
        return True

    def is_armed(self, *, now: float | None = None) -> bool:
        return self._armed_until > 0 and self._now(now) <= self._armed_until

    def clear(self) -> None:
        self._armed_until = 0.0

    def decide(
        self,
        text: str,
        *,
        wake_enabled: bool,
        woke: bool = False,
        body: str = "",
        cancel: bool = False,
        voice_ok: bool = True,
        followup_echo: bool = False,
        now: float | None = None,
    ) -> WakeDecision:
        """Decide whether a sentence is sent, starts listening, or is ignored.

        ``followup_echo`` means an already-armed sentence looked like the wake
        word again.  It restarts the listening window without sending the
        misheard wake word as chat text.
        """
        if not wake_enabled:
            return WakeDecision(WAKE_SEND, text)
        if cancel:
            self.clear()
            return WakeDecision(WAKE_CANCEL)
        if woke:
            if not voice_ok:
                self.clear()
                return WakeDecision(WAKE_IGNORE_VOICE)
            if body:
                self.clear()
                return WakeDecision(WAKE_SEND, body)
            self._armed_until = self._now(now) + self.wake_timeout
            return WakeDecision(WAKE_LISTEN)
        if self.is_armed(now=now):
            self.clear()
            if followup_echo:
                self._armed_until = self._now(now) + self.wake_timeout
                return WakeDecision(WAKE_LISTEN_AGAIN)
            if not voice_ok:
                return WakeDecision(WAKE_IGNORE_VOICE)
            return WakeDecision(WAKE_SEND, text)
        self.clear()
        return WakeDecision(WAKE_IGNORE)

    @staticmethod
    def _now(value: float | None) -> float:
        return time.monotonic() if value is None else float(value)


class DictationState:
    """Small state machine for typing recognized speech into the focused field."""

    START_WORDS = ("开始听写", "进入听写", "打开听写", "开启听写")
    STOP_WORDS = ("停止听写", "结束听写", "关闭听写", "退出听写")

    def __init__(self) -> None:
        self.on = False

    def command(self, plain_text: str, *, stop_requested: bool = False) -> str:
        compact = str(plain_text or "").replace(" ", "")
        if any(word in compact for word in self.START_WORDS):
            self.on = True
            return DICTATION_START
        if self.on and (
            stop_requested or any(word in compact for word in self.STOP_WORDS)
        ):
            self.on = False
            return DICTATION_STOP
        return DICTATION_TYPE if self.on else DICTATION_IDLE


def dispatch_dictation_action(
    action: str,
    text: str,
    *,
    speak,
    status,
    beep,
    type_text,
    print_line=print,
) -> bool:
    """Apply dictation UI/side effects while keeping rules in DictationState."""
    if action == DICTATION_START:
        speak("好，开始听写，你说的话直接打进光标")
        print_line("   ↳ ⌨️ 进入听写模式", flush=True)
        status.set(
            "listening",
            text="⌨️ 听写中",
            hint="说完直接打进光标，说「停止听写」结束",
        )
        beep(1180, 80)
        return True
    if action == DICTATION_STOP:
        speak("好，听写结束")
        print_line("   ↳ ⌨️ 退出听写模式", flush=True)
        status.set("idle")
        beep(620, 90)
        return True
    if action == DICTATION_TYPE:
        type_text(text)
        status.set(
            "listening",
            text=f"⌨️ {text}",
            hint="听写中，说「停止听写」结束",
        )
        return True
    return False


def plan_delivery(
    *,
    dry_run: bool,
    has_window: bool,
    editing_settings: bool,
    confirm_allowed: bool = True,
) -> str:
    """Choose the pre-send path without touching clipboard or window focus."""
    if dry_run:
        return DELIVERY_DRY_RUN
    if not has_window:
        return DELIVERY_OFFLINE
    if editing_settings:
        return DELIVERY_CLIPBOARD
    if not confirm_allowed:
        return DELIVERY_CLIPBOARD
    return DELIVERY_SEND
