"""Verify that a delivered sentence really reached the active conversation."""

from __future__ import annotations

import time


def verify_sent_delivery(
    sent: str,
    window: int,
    *,
    silent: bool = False,
    wait: float = 6.0,
    syslog,
    status,
    speak,
    last_unsent: dict,
    has_user_text=None,
    document_text=None,
    sleep=time.sleep,
    clock=time.time,
    print_line=print,
) -> bool:
    """Confirm through the Codex history first, then the visible window.

    A miss is reported but never resent automatically: an unseen window may be
    stale even when Codex has already accepted the message.
    """
    sleep(wait)
    if has_user_text is None:
        try:
            import codex_replies
            if codex_replies.available():
                has_user_text = codex_replies.has_user_text
        except Exception:
            has_user_text = None
    if has_user_text is not None:
        try:
            if has_user_text(sent, since_ms=int((clock() - 120) * 1000)):
                syslog("验", "发送已确认（会话库里能看到那句话）")
                return True
        except Exception:
            pass
    if not window:
        return False
    if document_text is None:
        try:
            import reply_reader
            document_text = lambda win: reply_reader.document_text(win, limit=300000) or ""
        except Exception:
            return False
    try:
        document = document_text(window) or ""
    except Exception:
        return False
    key = "".join(str(sent).split())[:10]
    if key and key in "".join(document.split()):
        syslog("验", "发送已确认（窗口里能看到那句话）")
        return True
    last_unsent["text"] = str(sent)
    last_unsent["at"] = clock()
    status.set("sent", text="⚠️ 刚才那句可能没进去（说「重发一遍」我再来一次）")
    syslog("验", f"发了 {wait:g} 秒没在窗口里看到「{str(sent)[:20]}」（只提示，没重发）")
    print_line("\n   ↳ ⚠️ 刚才那句好像没发出去（没自动重发，说「重发一遍」我就再来一次）",
               flush=True)
    if not silent:
        speak("刚才那句好像没发出去。要我再发一遍就说：重发一遍")
    return False
