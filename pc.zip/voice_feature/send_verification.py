"""Verify that a delivered sentence really reached the active conversation."""

from __future__ import annotations

import time

from voice_feature.delivery_receipts import (
    DeliveryAttempt,
    DeliveryReceiptTracker,
)


def verify_sent_delivery(
    sent: str,
    window: int,
    *,
    silent: bool = False,
    wait: float = 6.0,
    syslog,
    status,
    speak,
    last_unsent: dict,
    has_user_text=None,
    document_text=None,
    sent_at_ms: int | None = None,
    receipt: DeliveryReceiptTracker | None = None,
    attempt: DeliveryAttempt | None = None,
    retry_intervals: tuple[float, ...] = (4.0, 6.0, 8.0),
    sleep=time.sleep,
    clock=time.time,
    print_line=print,
) -> bool:
    """Confirm through the timestamped Codex history, then the visible window.

    A miss is reported but never resent automatically: an unseen window may be
    stale even when Codex has already accepted the message. When the history
    database is available it is authoritative; the visible window is only a
    fallback for installations where that database cannot be read.
    """
    if has_user_text is None:
        try:
            import codex_replies
            if codex_replies.available():
                has_user_text = codex_replies.has_user_text
        except Exception:
            has_user_text = None
    def history_confirmed() -> bool:
        if has_user_text is None:
            return False
        try:
            since = (
                int(sent_at_ms)
                if sent_at_ms is not None
                else int((clock() - 120) * 1000)
            )
            return bool(has_user_text(sent, since_ms=since))
        except Exception:
            return False

    if document_text is None:
        try:
            import reply_reader
            document_text = lambda win: reply_reader.document_text(win, limit=300000) or ""
        except Exception:
            document_text = None

    def window_confirmed() -> bool:
        if has_user_text is not None or not window or document_text is None:
            return False
        try:
            document = document_text(window) or ""
        except Exception:
            return False
        key = "".join(str(sent).split())[:10]
        return bool(key and key in "".join(document.split()))

    intervals = (0.0, *retry_intervals)
    total_wait = float(wait)
    for extra in intervals:
        step = float(extra)
        if step:
            sleep(step)
            total_wait += step
        if receipt is not None and attempt is not None and not receipt.is_current(attempt):
            return False
        if history_confirmed():
            if receipt is not None and attempt is not None:
                return receipt.confirmed(attempt, "会话库")
            syslog("验", "发送已确认（会话库里能看到那句话）")
            return True
        if window_confirmed():
            if receipt is not None and attempt is not None:
                return receipt.confirmed(attempt, "窗口")
            syslog("验", "发送已确认（窗口里能看到那句话）")
            return True

    if receipt is not None and attempt is not None:
        receipt.missed(attempt, total_wait)
        return False

    last_unsent["text"] = str(sent)
    last_unsent["at"] = clock()
    status.set("sent", text="⚠️ 刚才那句可能没进去（说「重发一遍」我再来一次）")
    syslog(
        "验",
        f"等了 {total_wait:g} 秒没看到「{str(sent)[:20]}」（只提示，没重发）",
    )
    print_line(
        "\n   ↳ ⚠️ 刚才那句好像没发出去"
        "（没自动重发，说「重发一遍」我就再来一次）",
        flush=True,
    )
    if not silent:
        speak("刚才那句好像没发出去。要我再发一遍就说：重发一遍")
    return False


__all__ = [
    "DeliveryAttempt",
    "DeliveryReceiptTracker",
    "verify_sent_delivery",
]
