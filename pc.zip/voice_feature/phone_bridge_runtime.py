# -*- coding: utf-8 -*-
"""Build the phone HTTP bridge without importing the STT entrypoint."""
from __future__ import annotations

import importlib
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PhoneBridgeDependencies:
    enabled: bool
    suppressed: bool
    port: int
    phone_link_module: Any
    runtime_lifecycle: Any
    ingress: Any
    on_command: Callable
    get_state: Callable
    get_log: Callable
    on_stop: Callable
    on_voice: Callable
    get_info: Callable
    on_image: Callable
    get_schedule: Callable
    on_schedule: Callable
    get_replies: Callable
    get_codex_control: Callable
    get_target: Callable
    get_target_id: Callable
    on_target: Callable
    on_thread_action: Callable
    on_new_thread: Callable
    fallback_get_windows: Callable
    worker: Callable[[], None]
    log: Callable[..., object] = print
    syslog: Callable[[str, str], None] | None = None
    threads_module: Any | None = None
    phone_stream_module: Any | None = None


def start_phone_bridge(deps: PhoneBridgeDependencies):
    """Start PhoneLink and its worker; return None with the old fallback logs."""
    if not deps.enabled or deps.suppressed:
        return None
    server = None
    started = False
    try:
        server = deps.phone_link_module.PhoneLink(
            on_command=deps.on_command,
            get_state=deps.get_state,
            get_log=deps.get_log,
            on_stop=deps.on_stop,
            port=int(deps.port),
        )
        if deps.syslog is not None:
            server.on_client = lambda ip: deps.syslog(
                "动", f"手机入口有设备连上：{ip}"
            )
        server.on_voice = deps.on_voice
        server.get_info = deps.get_info
        server.on_image = deps.on_image
        server.on_submit = deps.ingress.request_submit
        server.on_media_command = deps.ingress.push_media
        server.get_schedule = deps.get_schedule
        server.on_schedule = deps.on_schedule
        server.get_replies = deps.get_replies
        server.get_codex_control = deps.get_codex_control

        try:
            threads = deps.threads_module or importlib.import_module(
                "codex_threads"
            )
            server.get_windows = threads.list_threads
            server.get_projects = threads.list_projects
            deps.log("   （手机上的「对话会话」= Codex 里的会话，实时同步）")
        except Exception as exc:  # noqa: BLE001
            deps.log(f"   （读 Codex 会话列表失败，退回电脑窗口：{exc}）")
            server.get_windows = deps.fallback_get_windows
        server.get_target = deps.get_target
        server.get_target_id = deps.get_target_id
        server.on_target = deps.on_target
        server.on_thread_action = deps.on_thread_action
        server.on_new_thread = deps.on_new_thread

        if not server.start():
            return None
        started = True
        deps.log(f"📱 手机入口已开：{server.url()}")
        deps.log(
            "   （手机连同一个 Wi-Fi，用浏览器打开上面这条网址；"
            "出门在外面用就开设置 → 智能 → 外网访问，点「一键开启」）"
        )
        deps.runtime_lifecycle.start_daemon(
            "phone-command-worker",
            deps.worker,
        )
        try:
            stream = deps.phone_stream_module or importlib.import_module(
                "phone_stream"
            )

            def stream_marker(conv, marker, event_id=""):
                if deps.syslog is None:
                    return
                deps.syslog("流终", f"{conv}\x1f{marker}")
                deps.syslog(
                    "完", f"（{conv or '对话'}）这段回答处理完了"
                )

            stream.GLOBAL_WATCHER.start(
                emit=lambda conv, text: (
                    deps.syslog("流", f"{conv}\x1f{text}")
                    if deps.syslog is not None else None
                ),
                marker=stream_marker,
            )
            deps.log(
                "   （已常驻观察所有近期 Codex 会话，"
                "按 thread_id 分流到手机）"
            )
        except Exception as exc:  # noqa: BLE001
            deps.log(f"   （多会话流式监听没起来：{exc}）")
        return server
    except Exception as exc:  # noqa: BLE001
        deps.log(f"   （手机入口没起来：{exc}）")
        if started and server is not None:
            try:
                server.stop()
            except Exception:
                pass
        return None
