"""Pure hard limits for joining one long spoken utterance."""
from __future__ import annotations


MAX_JOINED_CAPTURE_SECONDS = 120.0


def trim_capture_to_limit(
    audio,
    total_samples: int,
    sample_rate: int,
    *,
    maximum_seconds: float = MAX_JOINED_CAPTURE_SECONDS,
):
    """Trim one chunk so joined speech never exceeds the hard capture cap."""
    if audio is None or sample_rate <= 0:
        return audio
    remaining = int(float(sample_rate) * maximum_seconds) - max(
        0, int(total_samples)
    )
    return audio[:max(0, remaining)]
