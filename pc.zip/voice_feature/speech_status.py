"""Authoritative speaking state shared by playback and transcript gating."""
from __future__ import annotations

import json
import time
from collections.abc import Callable
from pathlib import Path


def mark_speaking_stopped(
    path: Path,
    *,
    clock: Callable[[], float] = time.time,
) -> bool:
    """Make barge-in immediately visible to every status-file reader."""
    try:
        Path(path).write_text(
            json.dumps(
                {"active": False, "level": 0.0, "ts": float(clock())},
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        return True
    except Exception:
        return False
