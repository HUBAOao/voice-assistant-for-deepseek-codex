"""Race-safe delivery attempts and user-visible receipt state."""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class DeliveryAttempt:
    """One send occurrence, independent of older messages with the same text."""

    generation: int
    text: str
    started_at: float
    silent: bool

    @property
    def since_ms(self) -> int:
        # Database timestamps can precede the input helper's return by a few ms.
        return max(0, int(self.started_at * 1000) - 1000)


class DeliveryReceiptTracker:
    """Own race-safe receipt state and user-visible delivery messages."""

    def __init__(
        self,
        *,
        last_unsent: dict[str, Any],
        status: Any,
        speak: Callable[[str], Any],
        syslog: Callable[[str, str], Any],
        clock: Callable[[], float] = time.time,
        print_line: Callable[..., Any] = print,
    ) -> None:
        self.last_unsent = last_unsent
        self.status = status
        self.speak = speak
        self.syslog = syslog
        self.clock = clock
        self.print_line = print_line
        self._generation = 0
        self._warning_generation = 0

    def begin(
        self,
        text: str,
        *,
        started_at: float,
        silent: bool = False,
    ) -> DeliveryAttempt:
        """Start a newer send and retire every older pending failure."""
        self._generation += 1
        # "重发一遍" always refers to the latest send; an older miss must not
        # remain eligible after a newer message has superseded it.
        self.last_unsent.clear()
        return DeliveryAttempt(
            generation=self._generation,
            text=str(text),
            started_at=float(started_at),
            silent=bool(silent),
        )

    def is_current(self, attempt: DeliveryAttempt) -> bool:
        return attempt.generation == self._generation

    def confirmed(self, attempt: DeliveryAttempt, source: str) -> bool:
        """Accept a confirmation only for the newest send attempt."""
        if not self.is_current(attempt):
            return False
        if str(self.last_unsent.get("text") or "") == attempt.text:
            self.last_unsent.clear()
        if self._warning_generation == attempt.generation:
            current_text = str(
                (getattr(self.status, "_last", {}) or {}).get("text") or ""
            )
            if "可能没进去" in current_text:
                self.status.set(
                    "sent",
                    text="✅ 已确认发送（会话里稍后才出现）",
                )
                if not attempt.silent:
                    self.speak("刚才那句其实已经送到了")
            self._warning_generation = 0
        self.syslog("验", f"发送已确认（{source}）")
        return True

    def missed(self, attempt: DeliveryAttempt, wait: float) -> bool:
        """Publish a miss only when no newer message superseded this attempt."""
        if not self.is_current(attempt):
            return False
        self._warning_generation = attempt.generation
        self.last_unsent["text"] = attempt.text
        self.last_unsent["at"] = self.clock()
        self.status.set(
            "sent",
            text="⚠️ 刚才那句可能没进去（说「重发一遍」我再来一次）",
        )
        self.syslog(
            "验",
            f"等了 {wait:g} 秒没看到「{attempt.text[:20]}」（只提示，没重发）",
        )
        self.print_line(
            "\n   ↳ ⚠️ 刚才那句好像没发出去"
            "（没自动重发，说「重发一遍」我就再来一次）",
            flush=True,
        )
        if not attempt.silent:
            self.speak("刚才那句好像没发出去。要我再发一遍就说：重发一遍")
        return True


__all__ = ["DeliveryAttempt", "DeliveryReceiptTracker"]
