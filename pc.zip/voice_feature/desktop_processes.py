"""Launch and verify optional desktop helper processes.

The voice runtime owns the public compatibility functions, while this module
owns process flags, readiness checks and failure attribution. Dependencies are
injected so the startup and retry paths can be tested without spawning a GUI.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any


CREATE_NO_WINDOW = 0x08000000


class DesktopProcessLauncher:
    def __init__(
        self,
        root: Path,
        *,
        executable: str | Path | None = None,
        ready_file: Path | None = None,
        popen: Callable[..., Any] = subprocess.Popen,
        now: Callable[[], float] = time.time,
        sleep: Callable[[float], None] = time.sleep,
        platform_name: str | None = None,
        speak: Callable[[str], Any] | None = None,
        syslog: Callable[[str, str], Any] | None = None,
        emit: Callable[[str], Any] = print,
    ) -> None:
        self.root = Path(root)
        self.executable = Path(executable or sys.executable)
        self.ready_file = Path(ready_file or self.root / "overlay_ready.json")
        self._popen = popen
        self._now = now
        self._sleep = sleep
        self._platform_name = platform_name or os.name
        self._speak = speak
        self._syslog = syslog
        self._emit = emit

    @property
    def runner(self) -> Path:
        pythonw = self.executable.with_name("pythonw.exe")
        return pythonw if pythonw.exists() else self.executable

    @property
    def creation_flags(self) -> int:
        return CREATE_NO_WINDOW if self._platform_name == "nt" else 0

    def _say(self, text: str) -> None:
        if self._speak is None:
            return
        try:
            self._speak(text)
        except Exception:
            pass

    def _log(self, tag: str, text: str) -> None:
        if self._syslog is None:
            return
        try:
            self._syslog(tag, text)
        except Exception:
            pass

    def _spawn(self, argv: list[str], *, cwd: Path, stderr: Any = None):
        return self._popen(
            argv,
            cwd=str(cwd),
            creationflags=self.creation_flags,
            stderr=stderr,
        )

    def start_overlay(self):
        """Start the overlay and retry once when it exits or stays invisible."""
        script = self.root / "overlay.py"
        if not script.exists():
            return None

        detail = ""
        for attempt in (1, 2):
            started = self._now()
            err_fh = None
            try:
                err_fh = open(
                    self.root / "overlay-error.log",
                    "a",
                    encoding="utf-8",
                    errors="replace",
                )
                err_fh.write(
                    "\n=== 启动悬浮窗 "
                    f"{time.strftime('%Y-%m-%d %H:%M:%S')} ===\n"
                )
                err_fh.flush()
            except Exception:
                err_fh = None

            try:
                proc = self._spawn(
                    [str(self.runner), str(script)],
                    cwd=self.root,
                    stderr=err_fh,
                )
            except Exception as exc:
                self._emit(f"（悬浮窗没起来：{exc}）")
                return None
            finally:
                if err_fh is not None:
                    try:
                        err_fh.close()
                    except Exception:
                        pass

            detail = self.wait_overlay_ready(
                started,
                20.0 if attempt == 1 else 25.0,
                proc,
            )
            if not detail:
                return proc

            detail = self.overlay_failure_reason(detail)
            self._emit(f"（悬浮窗第 {attempt} 次没起来：{detail}）")
            try:
                proc.kill()
            except Exception:
                pass
            self._sleep(0.6)

        if any(
            marker in detail
            for marker in ("No module named", "ImportError", "DLL load failed")
        ):
            self._say(
                "缺一个运行库，双击程序目录里的「修复依赖」就能装好，语音还能用"
            )
        else:
            self._say(
                "悬浮窗起不来，语音还能用。日志在程序目录，文件名是 "
                "overlay-error 点 log"
            )
        self._log("浮", f"悬浮窗起不来：{detail}")
        self._emit(
            "   （如果是缺运行库：双击程序目录里的「修复依赖.cmd」就能补上）"
        )
        return None

    def wait_overlay_ready(
        self,
        started: float,
        timeout: float = 12.0,
        proc=None,
    ) -> str:
        """Return an empty string only for a fresh, visible overlay receipt."""
        deadline = self._now() + timeout
        while self._now() < deadline:
            if proc is not None and proc.poll() is not None:
                self._sleep(0.4)
                return f"它起来后就退了（退出码 {proc.returncode}）"
            try:
                data = json.loads(self.ready_file.read_text(encoding="utf-8"))
                if float(data.get("ts") or 0) >= started:
                    if not data.get("visible", True):
                        return "窗口建出来了，但是没显示（可能在屏幕外面）"
                    return ""
            except Exception:
                pass
            self._sleep(0.25)
        return f"{timeout:.0f} 秒之内没把窗口显示出来"

    def overlay_failure_reason(self, fallback: str) -> str:
        """Prefer the last non-empty overlay or exit log line."""
        for name in ("overlay-error.log", "overlay-exit.log"):
            try:
                lines = [
                    line.strip()
                    for line in (self.root / name).read_text(
                        encoding="utf-8",
                        errors="replace",
                    ).splitlines()
                    if line.strip()
                ]
            except Exception:
                lines = []
            if lines:
                return lines[-1][:200]
        return fallback

    def start_pet(self):
        """Start the Live2D pet only when its packaged assets are complete."""
        live_dir = self.root / "pet_live"
        live_exe = (
            live_dir / "node_modules" / "electron" / "dist" / "electron.exe"
        )
        if not live_exe.exists() or not (live_dir / "main.js").exists():
            return None
        try:
            proc = self._spawn(
                [str(live_exe), str(live_dir)],
                cwd=live_dir,
            )
            self._emit("桌宠已就位（大肥鱼 Live2D）")
            return proc
        except Exception as exc:
            self._emit(f"（Live2D 桌宠没起来：{exc}）")
            return None

    def _start_script(
        self,
        script_name: str,
        success_message: str,
        failure_label: str,
    ):
        script = self.root / script_name
        if not script.exists():
            return None
        try:
            proc = self._spawn(
                [str(self.runner), str(script)],
                cwd=self.root,
            )
            self._emit(success_message)
            return proc
        except Exception as exc:
            self._emit(f"（{failure_label}没起来：{exc}）")
            return None

    def start_tray(self):
        """Start the tray recovery entry point when available."""
        return self._start_script(
            "tray.py",
            "托盘图标已就位（右下角）",
            "托盘",
        )

    def start_watchdog(self):
        """Start the single-instance watchdog when available."""
        return self._start_script(
            "watchdog.py",
            "看门狗已就位（主程序挂掉会自动重启）",
            "看门狗",
        )
