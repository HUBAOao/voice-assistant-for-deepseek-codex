"""Shared FinDeck core services."""

