# -*- coding: utf-8 -*-
"""Shared desktop-platform boundary for the gradual cross-platform port."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PlatformInfo:
    system: str
    family: str
    display_name: str
    executable: str
    process_submit_flags: int
    secure_store: str
    legacy_data_root: str
    portable_data_root: str
    ready: bool
    limitations: tuple[str, ...]

    def public(self) -> dict[str, Any]:
        value = asdict(self)
        value["limitations"] = list(self.limitations)
        return value


def _portable_data_root() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "FinDeck"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "FinDeck"
    return Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "findeck"


def info() -> PlatformInfo:
    """Return capabilities without assuming Windows-only modules are importable."""
    system = sys.platform
    if system == "win32":
        family = "windows"
        display = "Windows"
        flags = 0x08000000
        secure = "Windows DPAPI"
        legacy = Path(r"E:\语音助手")
        limits = (
            "UI Automation、全局热键和透明悬浮窗仍需逐项验证",
        )
        ready = True
    elif system == "darwin":
        family = "macos"
        display = "macOS"
        flags = 0
        secure = "macOS Keychain" if shutil.which("security") else "unavailable"
        legacy = Path.home() / "FinDeck"
        limits = (
            "窗口捕获、热键、托盘和悬浮窗尚未实现",
            "Codex Desktop 自动化路径需要单独适配",
        ) if secure != "unavailable" else (
            "系统缺少 security 命令，安全存储不可用",
            "窗口捕获、热键、托盘和悬浮窗尚未实现",
            "Codex Desktop 自动化路径需要单独适配",
        )
        ready = secure != "unavailable"
    else:
        family = "linux"
        display = "Linux"
        flags = 0
        secure = (
            "Linux Secret Service"
            if shutil.which("secret-tool") else "unavailable"
        )
        legacy = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share") / "FinDeck"
        limits = (
            "X11/Wayland 捕获、热键、托盘和悬浮窗尚未实现",
            "Codex Desktop 自动化路径需要单独适配",
        ) if secure != "unavailable" else (
            "系统缺少 secret-tool，安全存储不可用",
            "X11/Wayland 捕获、热键、托盘和悬浮窗尚未实现",
            "Codex Desktop 自动化路径需要单独适配",
        )
        ready = secure != "unavailable"
    return PlatformInfo(
        system=system,
        family=family,
        display_name=display,
        executable=sys.executable,
        process_submit_flags=flags,
        secure_store=secure,
        legacy_data_root=str(legacy),
        portable_data_root=str(_portable_data_root()),
        ready=ready,
        limitations=limits,
    )


def subprocess_kwargs(**extra: Any) -> dict[str, Any]:
    """Stable process launch boundary shared by future platform adapters."""
    value = dict(extra)
    flags = info().process_submit_flags
    if flags:
        value["creationflags"] = int(value.get("creationflags") or 0) | flags
    return value


def open_path(path: str | Path) -> None:
    """Open a local file or folder through the host desktop shell."""
    target = str(Path(path).resolve())
    if sys.platform == "win32":
        os.startfile(target)  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])


def diagnostics() -> dict[str, Any]:
    return {"ok": bool(info().ready), **info().public()}
