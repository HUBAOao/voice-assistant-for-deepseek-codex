#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把聊天窗口里 AI 的回答读出来（念给你听）。

怎么读的：用 Windows 的 UI Automation 把窗口里的文字抠出来（ChatGPT / Codex /
Claude 这些桌面版的对话内容都能读到），再按它自己的格式找到"最新一条回答"，
然后一句一句念出来 —— 回答还在往外蹦的时候，它也是蹦一句念一句。

窗口里的字长这样（这是真实抠出来的顺序）：
    你说： / 我发的那句 / 21:06 / 已处理 1分钟 36秒 / ChatGPT 说： / 回答正文
    …再往后是输入框和消息操作栏： 最新一条回复 / 随心输入 / 添加文件等内容 /
      完全访问 / 跳转到用户消息 1 / 跳转到用户消息 2 / …（几百条）
    …最后还有"查看已更改的文件"面板，里面是代码 diff。

所以规矩是：**先在输入框那一行截断**（后面全是界面），只留"你说：…"这一段，
取最后一条「你说：」后面第一条「XX 说：」往下的内容，再把界面按钮、工具回显
（已运行/正在运行/编辑了文件…）整行剔掉。认不出「XX 说：」这种标记就宁可不念 ——
以前就是在这里退回"从你发的那句之后开始取"，把几百条"跳转到用户消息"念了一遍。

不想要就关掉：设置 → 智能 → 发送 → 「自动念回答」。
"""

from __future__ import annotations

import re
import subprocess
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "read_window_text.ps1"
RAW_DUMP = HERE / "reply-raw.txt"      # 真念错东西时的现场：把窗口原文留一份（下次好查）
NO_WINDOW = 0x08000000 if __import__("os").name == "nt" else 0

# 一次读多少字：窗口里的文字很多（夹着代码 diff、几百个按钮），少了就读不到最新的回答
READ_LIMIT = 300000

# 一条消息的抬头：「你说：」「ChatGPT 说：」——单独占一行，名字不长
MARKER_RE = re.compile(r"^[\w\u4e00-\u9fff·\-\.]{1,20}\s*说：$")
USER_NAMES = ("你", "您", "用户")

# 输入框上的字：「最新一条回复」是下一条消息的跳转按钮，跟着就是输入框和操作栏。
# 碰到这些整行就停 —— 后面全是界面（几百条「跳转到用户消息」+ 文件 diff）。
COMPOSER_STOP = ("随心输入", "添加文件等内容", "完全访问", "最新一条回复")

# 界面上单独的按钮 / 状态 / 工具回显：整行丢掉，不是回答
JUNK_EXACT = {
    "正在思考", "思考过程", "已思考", "停止生成", "重新生成", "复制", "复制代码",
    "复制表格", "展开表格", "展开", "收起", "展开代码", "折叠代码", "查看变更",
    "查看已更改的文件", "查看活动", "撤销", "重试", "分享", "引用", "反馈",
    "朗读此消息", "更多操作", "应用更改", "隐藏侧边栏", "显示侧边栏",
    "进入完整视图", "隐藏标签页", "关闭来源标签页", "关闭变更标签页", "新标签页",
    "编辑了文件", "运行了命令", "编辑了文件运行了命令", "上下文已自动压缩",
    "启用自动换行", "禁用自动换行", "来源", "变更", "跳转到内容", "跳转到最新",
    "高", "中", "低", "赞", "踩", "不喜欢", "已复制", "排序方式",
}

# 同上，但是带数字 / 全是符号的行
JUNK_RES = (
    re.compile(r"^跳转到用户消息\s*\d*$"),
    re.compile(r"^\d+\s*个文件已更改$"),
    re.compile(r"^再显示\s*\d+\s*个文件$"),
    re.compile(r"^[+\-]\s*\d+$"),
    re.compile(r"^用时\s*.+$"),
    re.compile(r"^已处理\s*.+$"),
    re.compile(r"^\d{1,2}:\d{2}$"),
    re.compile(r"^\d+$"),
    re.compile(r"^[^\w\u4e00-\u9fff]+$"),
)

# 一行里同时出现好几个这种词，说明这行是界面拼接出来的（比如日志里粘进来的），不是回答
UI_JUNK_WORDS = ("跳转到用户消息", "正在思考", "随心输入", "添加文件等内容", "完全访问",
                 "编辑了文件", "运行了命令", "个文件已更改", "最新一条回复", "隐藏侧边栏",
                 "朗读此消息", "复制代码", "查看变更", "来源", "变更", "上一页", "下一页")
NOISE = ("\ufffc", "\u200b", "\ufeff", "\ufffd")

# 界面上"我干了什么"的状态行 —— 夹在回答里念出来就是噪音。
# 真机念错的原文：「已在 25s 内运行 $log = 'C:\Users\…' if (Test-Path $log) { Move-Item …」
# 还有粘在句子尾巴上的：「…不用再等你工程。正在编辑文件」
ACTIVITY_LINE = re.compile(
    r"^(?:已|正在|刚刚)?(?:在\s*\d+\s*[s秒]\s*内)?"
    r"(?:运行|执行|编辑|创建|删除|更新|写入|修改|读取|搜索|查看|调用|编译|安装|下载)"
    r"(?:了|过)?[\s\d，,、:：]*(?:个)?"
    r"(?:文件|命令|代码|脚本|目录|项目|插件|程序|内容|功能)?[\s，,、。.!！?？]*$")

# 尾巴上粘着的状态词（界面加的），从句子末尾削掉
TAIL_STATUS = ("正在编辑文件", "正在运行命令", "正在运行代码", "正在思考", "正在生成",
               "编辑了文件", "运行了命令", "创建了文件", "删除了文件", "更新了文件",
               "已编辑文件", "已运行命令", "停止生成", "已思考", "上下文已自动压缩")

# 命令行 / 路径味儿太重的行：那是给我看的，不是念给人听的。
# 分两档，免得把「我把 reply_reader.py 改好了」这种正经话也误伤：
#   STRONG —— 一看就是命令行（盘符路径、$变量、cd 、powershell 那些常用命令）
#   WEAK   —— 只是有点代码味儿（文件后缀、--参数、括号分号），要凑够两条、
#             或者整句一个中文字都没有，才判成"不是给人念的"
STRONG_CMD = re.compile(
    r"[A-Za-z]:\\|\\\\|(?:\$[A-Za-z_])|(?:^|\s)cd\s|"
    r"\b(?:Test-Path|Move-Item|Select-String|Get-ChildItem|Copy-Item|Remove-Item|"
    r"Start-Process|Popen|pip|npm|git)\b")
WEAK_CMD = re.compile(r"\.(?:exe|ps1|cmd|bat|py|json|log)\b|--[A-Za-z]|\|\s*\w")
CODISH = re.compile(r"[{}();]|==|!=|->|\bdef\b|\bself\b|\breturn\b")
_HAN_RE = re.compile(r"[\u4e00-\u9fff]")


def _trim_tail_status(s: str) -> str:
    """把句子尾巴上的「正在编辑文件」这种界面状态削掉。"""
    changed = True
    while changed and s:
        changed = False
        for word in TAIL_STATUS:
            if s.endswith(word):
                s = s[: -len(word)].rstrip("。，,、；;：:!！?？ \u3000")
                changed = True
    return s


# 工具卡片：界面在回答里插的"我刚跑了什么"。它出现的地方就是"上一段是过程话"的分界
TOOL_LINE = re.compile(
    r"^(?:已|正在|刚刚)?(?:在\s*\d+\s*[s秒]\s*内)?"
    r"(?:运行|执行|编辑|创建|删除|更新|写入|修改|编译|安装|下载)")


def _is_tool_line(s: str) -> bool:
    """这一行是不是"工具卡片"（已运行 xxx / 正在编辑文件 / 已在 25s 内运行 …）。"""
    if not s:
        return False
    if s in ("编辑了文件运行了命令", "正在编辑文件", "运行了命令", "编辑了文件"):
        return True
    if TOOL_LINE.match(s):
        return True
    return bool(STRONG_CMD.search(s) and len(s) >= 12)


def looks_like_ui(got: str) -> bool:
    """念之前最后一道闸：这段还是像界面拼接的，就别念。"""
    if not got:
        return True
    if got.count("跳转到用户消息") >= 2:
        return True
    junk = sum(1 for w in UI_JUNK_WORDS if w in got)
    if junk >= 5:
        return True
    return False


_FLAT = re.compile(r"[\s，,。.!！?？~～…\-—_*·、「」“”\"'（）()\[\]【】:：;；]+")


def looks_like_my_message(got: str, sent_text: str) -> bool:
    """念出来的这截是不是我自己刚发出去的那句？是就别念。

    真出过这个 bug：窗口还没画出回答，兜底逻辑把"你刚说的那句"当成了回答念出来 ——
    你听到自己的话被念了一遍。所以发出去之前再比一次。
    """
    a = _FLAT.sub("", got or "")
    b = _FLAT.sub("", sent_text or "")
    if not a or not b:
        return False
    if a == b:
        return True
    # 我发的那句被截了一半，也是同一句（窗口里有时只画出前半句）
    if len(a) >= 6 and a in b:
        return True
    # 反过来：念出来的这截比我发的那句只多一点点 —— 那也是我的话，不是回答
    # （回答里引用我那句是常有的事，所以只在"多出几个字"时才判成回声）
    if len(a) <= len(b) + 4 and b in a:
        return True
    return False


# 界面上那层"回复已完成：…"的浮层提示：正文已经有了，前缀不用念
TOAST_HEADS = ("回复已完成", "已完成回复", "已发送", "正在发送", "已复制", "正在生成")


def _strip_toast(s: str) -> str:
    for head in TOAST_HEADS:
        if s.startswith(head):
            return s[len(head):].lstrip("：: ，,")
    return s


def _is_marker(line: str) -> bool:
    """这一行是不是「你说：」「ChatGPT 说：」这种消息抬头。"""
    s = (line or "").strip()
    return bool(s) and bool(MARKER_RE.match(s))


def _name_of(line: str) -> str:
    s = (line or "").strip()
    return s[:-2].strip() if s.endswith("说：") else ""


def _is_junk_line(s: str) -> bool:
    """界面上的一行字（按钮 / 状态 / 工具回显 / 行号碎片）→ 丢掉。"""
    if not s:
        return True
    if "\ufffc" in s:
        return True
    if len(s) <= 24 and s in JUNK_EXACT:
        return True
    for rx in JUNK_RES:
        if rx.match(s):
            return True
    if ACTIVITY_LINE.match(s):          # 「已编辑 2 个文件」「正在运行」这类状态行
        return True
    if STRONG_CMD.search(s):            # 一看就是命令行，念了也没法听
        return True
    if WEAK_CMD.search(s) and (len(WEAK_CMD.findall(s)) >= 2 or not _HAN_RE.search(s)):
        return True
    if not _HAN_RE.search(s) and CODISH.search(s):   # 整行没中文、又有代码符号
        return True
    if "ChatGPT 说：" in s:              # 整行里嵌着对话标记 = 引用日志原文，不是给人念的
        return True
    # 工具回显：已运行 <命令行> / 正在运行 <命令行>（认得出来的都是命令，不是回答）
    if s.startswith("已运行") or s.startswith("正在运行"):
        rest = s[3:]
        if len(s) >= 30 or re.search(r"[\\/\"$]|\.exe|\.ps1|\bcd |\bpython\b|-Path|-File", rest):
            return True
    # 「跳转到用户消息 1 跳转到用户消息 2 …」这种一整条按钮列表
    if s.count("跳转到用户消息") >= 2:
        return True
    # 一行里堆了好几个界面词 → 是界面拼出来的
    if sum(1 for w in UI_JUNK_WORDS if w in s) >= 3:
        return True
    return False


def document_text(hwnd: int, limit: int = READ_LIMIT, timeout: int = 40) -> str:
    """读某个窗口里的文字；读不到就返回空串。"""
    if not hwnd or not SCRIPT.exists():
        return ""
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
             str(SCRIPT), "-Hwnd", str(int(hwnd)), "-Limit", str(int(limit))],
            capture_output=True, timeout=timeout, creationflags=NO_WINDOW)
        return out.stdout.decode("utf-8", errors="replace") or ""
    except Exception:
        return ""


def clean(text: str) -> str:
    """去掉界面噪点：标记符号、连续空白、markdown 符号。"""
    t = text or ""
    for junk in NOISE:
        t = t.replace(junk, " ")
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{2,}", "\n", t)
    t = re.sub(r"[*_`#>]+", "", t)
    return t.strip()


def extract_reply(doc: str, sent_text: str = "", my_texts: tuple = ()) -> str:
    """从窗口全文里找出"最新一条 AI 回答"。认不出格式就返回空串（宁可不念）。"""
    if not doc:
        return ""
    lines = doc.replace("\r", "\n").split("\n")

    # ① 先在输入框那行截断：后面是消息操作栏（几百条"跳转到用户消息"）和文件 diff
    cut = len(lines)
    for i, ln in enumerate(lines):
        if ln.strip() in COMPOSER_STOP:
            cut = i
            break
    lines = lines[:cut]

    # ② 从最后往前找「你说：」，取它后面第一条「XX 说：」——就是最新回答。
    #    （回答里偶尔会引用「你说：」这种字，所以往前找第一个真能接上回答的。）
    start = -1
    for user_at in range(len(lines) - 1, -1, -1):
        if not (_is_marker(lines[user_at]) and _name_of(lines[user_at]) in USER_NAMES):
            continue
        for i in range(user_at + 1, len(lines)):
            if _is_marker(lines[i]):
                start = i + 1
                break
        if start >= 0:
            break
    if start < 0:
        # 有的应用不写「你说：」→ 认最后一个「XX 说：」，它后面就是最新回答。
        # 注意必须排除「你说：」自己 —— 以前没排除，窗口还没画出回答时就把你刚说的那句
        # 当最新回答念了出来（"你刚刚还念了我给你发送的消息"就是这个）。
        for i in range(len(lines) - 1, -1, -1):
            if _is_marker(lines[i]) and _name_of(lines[i]) not in USER_NAMES:
                start = i + 1
                break
    if start < 0:
        return ""

    # ③ 回答到"下一条你说"为止。
    #    这条是今天真机 bug 的根：新消息刚发出去、回答还没画出来的时候，第②步会往回退到
    #    「上一条你说」，于是把你**刚发的那句**也框进了"回答"里 —— 它就把你的话念了回来
    #    （你听到的"他学我说话"）。现在碰到下一条「你说：」就截断，宁可这一轮先不念。
    end = len(lines)
    for i in range(start, len(lines)):
        if _is_marker(lines[i]) and _name_of(lines[i]) in USER_NAMES:
            end = i
            break
    lines = lines[:end]

    # ④ 一行行收拾：界面上的按钮 / 状态 / 工具回显整行丢掉
    # 一段一段收：段与段之间夹着工具卡片（已运行 xxx / 正在编辑文件 …）的那些"领起句"，
    # 比如「让我先看看它到底念了什么：」，是过程话，不是我要念的东西。
    blocks: list[tuple[str, bool]] = []       # (这一段的话, 后面是不是跟着工具/状态行)
    cur: list[str] = []
    junk_after = False
    for ln in lines[start:]:
        s = _trim_tail_status(_strip_toast(ln.strip()))   # 削掉句尾状态 / 浮层提示前缀
        if not s:
            continue
        if _is_marker(s):                    # 「ChatGPT 说：」分段标记 → 这一段到此为止
            if cur:
                blocks.append((" ".join(cur), junk_after))
                cur, junk_after = [], False
            continue
        if _is_junk_line(s):
            if _is_tool_line(s):             # 工具卡片 → 说明上一段是"过程话"
                if cur:
                    blocks.append((" ".join(cur), True))
                    cur = []
                junk_after = True
            continue                         # 其它界面字（图片占位、时间戳、按钮）直接跳过，不切段
        if junk_after:                       # 新一段开始了，重置标记
            junk_after = False
        cur.append(s)
    if cur:
        blocks.append((" ".join(cur), junk_after))

    keep: list[str] = []
    for text, tool_after in blocks:
        # 后面还接着工具/状态行的，而且要么很短、要么是个"领起句"（以冒号/破折号收尾），
        # 那就是"我准备这么做…"的过程话，不念。成段的正文（>40 字、正常收尾）留着。
        if tool_after and (
                len(text) <= 40 or (len(text) <= 60
                                    and text.rstrip().endswith(("：", ":", "——", "—")))):
            continue
        keep.append(text)
    got = clean("\n".join(keep))
    if looks_like_ui(got):
        return ""
    # 我自己发出去的话（这一句 + 前几句）都不能当成回答念 —— 真出过"它把我的话念回来"
    for mine in (sent_text,) + tuple(my_texts or ()):
        if mine and looks_like_my_message(got, mine):
            return ""
    return got


def sentences(text: str, min_len: int = 4) -> list:
    """切成一句一句的：方便一句一句念，也方便随时喊「停」。"""
    parts = re.split(r"(?<=[。！？!?；;])|\n", text or "")
    return [p.strip() for p in parts if len(p.strip()) >= min_len]


def _norm_sentence(s: str) -> str:
    """句子的"指纹"：去掉标点、空格、句尾界面状态之后用来判重。"""
    return _FLAT.sub("", _trim_tail_status(s or ""))


# 侧边栏里那些"不是对话名"的固定字样（猜当前对话名时要跳过）
_NOT_CHAT_NAMES = {
    "置顶", "置顶选项", "取消置顶聊天", "归档聊天", "取消归档", "聊天操作", "聊天侧边栏选项",
    "项目", "项目侧边栏选项", "没有项目", "最近", "新聊天", "搜索", "首页", "插件", "探索",
    "代码审查", "定时任务", "有可用更新", "查看活动", "隐藏侧边栏", "显示侧边栏", "文件",
    "编辑", "视图", "帮助", "跳转到内容", "切换模式", "设置", "置顶聊天", "已归档",
}

# 浏览器/网页那种界面文字（标签栏、页脚链接…）绝不是会话名：
# 真机反馈过手机上出现「（关闭Sign in to GitHub · GitHub标签页）回答完了」这种怪名字。
_WEBISH_WORDS = ("关闭", "标签页", "Sign in", "GitHub", "Terms", "Privacy",
                 "Cookies", "Docs", "Contact", "刷新", "地址栏", "后退", "前进",
                 "窗口", ".com", ".cn", "http")


def _looks_webish(s: str) -> bool:
    return any(w.lower() in s.lower() for w in _WEBISH_WORDS)


def guess_chat_name(doc: str, fallback: str = "") -> str:
    """猜"这是哪个对话"——侧边栏里当前对话是紧挨着聊天区的那一条。

    真窗口上核对过：……置顶选项 / 学习 UV5 蓝图知识 / 取消置顶聊天 / 归档聊天 /
    **添加语音对话功能** / 取消置顶聊天 / 归档聊天 / 你说：…… 取不到就用窗口标题。
    """
    if not doc:
        return (fallback or "").strip()
    lines = doc.replace("\r", "\n").split("\n")
    stop = len(lines)
    for i, ln in enumerate(lines):
        s = ln.strip()
        if s in ("你说：", "ChatGPT 说：") or s in COMPOSER_STOP:
            stop = i
            break
    title = ""
    for ln in lines[:stop]:
        s = ln.strip()
        if not s or s in _NOT_CHAT_NAMES or "\ufffc" in s:
            continue
        if len(s) > 40 or s.endswith("："):
            continue
        if _is_junk_line(s):
            continue
        if _looks_webish(s):
            continue               # 标签栏/网页那些字，不是会话名
        title = s          # 一路往后取，最后一条就是当前对话
    return title or (fallback or "").strip()


class ReplyReader:
    """盯着一个窗口：回答一出来就念。同一时间只盯一个。"""

    def __init__(self, speak_func, log=print, record=None, poll_seconds: float = 3.5,
                 done=None):
        self.speak = speak_func
        # done(name)：这条回答念完了（= 电脑这边活干完了）→ 手机那边要提醒
        self.done = done
        self.poll_seconds_default = float(poll_seconds)
        # record(tag, text)：念出来的回答顺手记进"共享记忆"（系统日志）
        self.record = record
        self.poll_seconds = float(poll_seconds)
        self.log = log
        self._stop = threading.Event()
        self._thread = None
        self._threads: dict[int, tuple] = {}   # 窗口 → (线程, 停止事件, 回答编号)
        self.hwnd = 0
        self._baseline = ""          # 开始盯的时候，"上一条回答"长什么样
        self._recent_sent: list[str] = []   # 我最近发出去的那几句（别把用户自己的话念回来）
        # ---- 念回答的排队（多少个对话都能排）----
        # 同一时间只念一条：先念到的先念完，后面的排队等着；报不报对话名看"有没有别人在排"。
        self._queue_lock = threading.Lock()
        self._queue: list[tuple[int, str, str, bool]] = []   # (回答编号, 对话名, 文字, 是否这段的头一句)
        self._speaker: threading.Thread | None = None
        self._reply_seq = 0
        self._live_replies: dict[int, str] = {}   # 回答编号 → 对话名（还活着的监视）
        self._last_name = ""                      # 上一条念的是哪个对话
        self._last_name_at = 0.0

    def stop(self) -> None:
        """全停：盯着的不盯了，排着队的不念了（说「停」的时候用）。"""
        self._stop.set()
        with self._queue_lock:
            self._queue.clear()
            self._live_replies.clear()
            for _th, ev, _rid in getattr(self, "_threads", {}).values():
                ev.set()

    def clear_queue(self) -> None:
        """（说「停」的时候用）排着的回答全别念了。"""
        with self._queue_lock:
            self._queue.clear()

    # ---------------------------------------------------------------- 排队念
    def _enqueue(self, rid: int, name: str, text: str, first: bool) -> None:
        with self._queue_lock:
            self._queue.append((rid, name, text, first))
        self._ensure_speaker()

    def _ensure_speaker(self) -> None:
        # 加锁：两个回答几乎同时进队时会同时来这儿，不锁就会起**两个嘴**，又叠着念了
        with self._queue_lock:
            if self._speaker is None or not self._speaker.is_alive():
                self._speaker = threading.Thread(target=self._speak_loop, daemon=True)
                self._speaker.start()

    def _speak_loop(self) -> None:
        idle_from = time.time()
        while True:
            item = None
            with self._queue_lock:
                if self._queue:
                    item = self._queue.pop(0)
            if item is None:
                # 没得念了、也没人在盯着，就收工（下次要念再起来）
                with self._queue_lock:
                    empty = not self._queue
                if empty and not self._live_replies and time.time() - idle_from > 20:
                    return
                time.sleep(0.05)
                continue
            idle_from = time.time()
            rid, name, text, first = item
            if first:
                with self._queue_lock:
                    others = [o for o, _n, _t, _f in self._queue if o != rid]
                need_name = bool(others) or any(o != rid for o in self._live_replies) or (
                    bool(self._last_name) and time.time() - self._last_name_at < 90)
                if need_name and name and name != self._last_name:
                    try:
                        self.speak(f"{name}，这条回答是：")
                    except Exception:
                        return
                self._last_name, self._last_name_at = name or self._last_name, time.time()
            try:
                self.speak(text)
            except Exception:
                return

    def busy(self) -> bool:
        return any(t.is_alive() for t, _e, _r in getattr(self, "_threads", {}).values())

    def watch(self, hwnd: int, sent_text: str, seconds: int = 150,
              max_chars: int = 1800, title: str = "") -> None:
        """开始盯这个窗口。

        多少个对话都能同时盯：**不同窗口各盯各的**，回答进同一个排队，由同一个"嘴"
        一个念完再念下一个（以前是新的直接把旧的停了，两个回答会重叠在一起念）。
        """
        hwnd = int(hwnd or 0)
        # 同一个窗口再发消息 = 同一个对话又一句 → 老的监视停掉（不然它还在等上一条）
        old = self._threads.pop(hwnd, None) if hasattr(self, "_threads") else None
        if old:
            old[1].set()
            with self._queue_lock:
                self._live_replies.pop(old[2], None)
        self._stop = threading.Event()
        self.hwnd = hwnd
        if sent_text:
            self._recent_sent = [t for t in self._recent_sent if t != sent_text][-4:]
            self._recent_sent.append(sent_text)
        # 先拍个基线：此刻窗口里的那条回答（多半是上一条）。
        # 不拍的话，你一发新消息它就会把上一条从头再念一遍 —— 因为新回答还没出现，
        # 它就把旧的当成新的了。
        try:
            doc0 = document_text(hwnd)
            base = extract_reply(doc0, sent_text, tuple(self._recent_sent))
            name = guess_chat_name(doc0, title)
        except Exception:
            base, name = "", (title or "").strip()
        self._baseline = base
        self._reply_seq += 1
        rid = self._reply_seq
        stop_ev = threading.Event()
        with self._queue_lock:
            self._live_replies[rid] = name
        th = threading.Thread(
            target=self._loop,
            args=(hwnd, sent_text, seconds, max_chars, rid, stop_ev, name, base),
            daemon=True)
        self._threads[hwnd] = (th, stop_ev, rid)
        th.start()

    def _loop(self, hwnd: int, sent_text: str, seconds: int, max_chars: int,
              rid: int, stop_ev: threading.Event, name: str, base: str) -> None:
        deadline = time.time() + seconds
        base = base or ""
        # 已经念过的句子（按句子去重，不按字数）。上一条回答里的话一开始就全算"念过了"，
        # 这样窗口内容怎么变都不会把上一条再念一遍。
        # 为什么要按句子而不是按字数：为了让"过程话"不念，回答的提取结果会**变形**
        # （早先当成回答的段落，后面会因为它后面跟着工具卡片而被剔掉），
        # 一变形，按字数的"接着往下念"就对不上了，于是从头再念一遍 —— 真机出过这个毛病。
        spoken_parts = {_norm_sentence(p) for p in sentences(base, min_len=1)}
        spoken_len = 0
        ever_changed = False
        idle = 0
        dumped = False
        last_seen = None
        spoken_any = False

        def done(*_a) -> None:
            with self._queue_lock:
                self._live_replies.pop(rid, None)

        def finished() -> None:
            """这条回答念完了 = 电脑这边活干完了 → 告诉外面（手机上要响一下）。"""
            if self.done:
                try:
                    self.done(name)
                except Exception:
                    pass

        while not stop_ev.is_set() and not self._stop.is_set() and time.time() < deadline:
            time.sleep(self.poll_seconds)   # 每 3.5 秒看一眼就够（每次都要起一个 PowerShell）
            if stop_ev.is_set() or self._stop.is_set():
                done()
                return
            raw = document_text(hwnd)
            reply = extract_reply(raw, sent_text, tuple(self._recent_sent))
            if reply == base:        # 还停在上一条回答上 → 界面还没更新，别念
                idle += 1
                if ever_changed and spoken_len and idle >= 3:
                    self.log("   ↳ ✅ 回答念完了")
                    finished()
                    done()
                    return
                continue
            # 还在往外蹦就先不念：等它稳住一轮再念。这样"过程话"（后面还跟着工具调用的
            # 那种领起句）会在下一眼被识别出来、直接跳过；正经回答只是晚几秒开口。
            if reply != last_seen:
                last_seen = reply
                idle = 0
                continue
            if not dumped and raw:
                # 留住现场：万一以后还念错，这条能直接看出窗口里当时是什么
                try:
                    RAW_DUMP.write_text(raw[:60000], encoding="utf-8")
                except Exception:
                    pass
                dumped = True
            if not ever_changed and base and reply.startswith(base):
                spoken_parts.update(_norm_sentence(p) for p in sentences(base, min_len=1))
            ever_changed = True
            if not reply:
                idle += 1
                if spoken_len and idle >= 3:     # 念过了、三次没变化 → 回答说完了，收工
                    self.log("   ↳ ✅ 回答念完了")
                    finished()
                    done()
                    return
                continue
            pieces = sentences(reply)
            fresh = [p for p in pieces if _norm_sentence(p) not in spoken_parts]
            # 最后一句可能还没蹦完（没有标点），留着下一轮再念
            if fresh and not re.search(r"[。！？!?；;]\s*$", fresh[-1]):
                fresh = fresh[:-1]
            if not fresh:
                idle += 1
                if spoken_len and idle >= 3:
                    self.log("   ↳ ✅ 回答念完了")
                    finished()
                    done()
                    return
                continue
            idle = 0
            chunk = "".join(fresh)
            spoken_parts.update(_norm_sentence(p) for p in fresh)
            spoken_len += len(chunk)
            if spoken_len > max_chars:
                done()
                return
            if self.record is not None:
                try:
                    self.record(chunk)
                except Exception:
                    pass
            # 交给"排队的那张嘴"：一个念完再念下一个（多少个对话都排得上）
            self._enqueue(rid, name, chunk, first=not spoken_any)
            spoken_any = True
        done()
