#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compatibility facade for desktop reply extraction and monitoring."""
from __future__ import annotations

import os
import re
from pathlib import Path

from voice_feature.reply_extraction import (
    NOT_CHAT_NAMES,
    READ_LIMIT,
    WEBISH_WORDS,
    _looks_webish,
    document_text,
    extract_reply,
    guess_chat_name,
    pick_reply,
    sentences,
)
from voice_feature.reply_filters import (
    ACTIVITY_LINE,
    CODISH,
    COMPOSER_STOP,
    FLAT,
    JUNK_EXACT,
    JUNK_RES,
    MARKER_RE,
    NOISE,
    STRONG_CMD,
    TAIL_STATUS,
    TOAST_HEADS,
    TOOL_LINE,
    UI_JUNK_WORDS,
    USER_NAMES,
    WEAK_CMD,
    clean,
    is_junk_line,
    is_marker,
    is_tool_line,
    looks_like_my_message,
    looks_like_ui,
    name_of,
    norm_sentence,
    strip_toast,
    trim_tail_status,
)
from voice_feature.reply_watcher import RAW_DUMP, ReplyReader


HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "read_window_text.ps1"
NO_WINDOW = 0x08000000 if os.name == "nt" else 0

# Historical private names remain available to existing scripts and tests.
_trim_tail_status = trim_tail_status
_is_tool_line = is_tool_line
_is_marker = is_marker
_name_of = name_of
_is_junk_line = is_junk_line
_strip_toast = strip_toast
_norm_sentence = norm_sentence
_FLAT = FLAT
_HAN_RE = re.compile(r"[\u4e00-\u9fff]")
_NOT_CHAT_NAMES = NOT_CHAT_NAMES
_WEBISH_WORDS = WEBISH_WORDS


__all__ = [
    "READ_LIMIT",
    "ReplyReader",
    "clean",
    "document_text",
    "extract_reply",
    "guess_chat_name",
    "pick_reply",
    "sentences",
]


if __name__ == "__main__":
    print("reply_reader 已拆分；请通过语音助手主程序启动回复朗读。")
