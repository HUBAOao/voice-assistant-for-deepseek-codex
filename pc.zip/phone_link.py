#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""手机入口：手机浏览器直接连到这台电脑上的语音助手。

为什么这么做：语音助手本来就会"把文字发到聊天窗口 / 执行本地动作"，
那就给它开一个 HTTP 小门（只用 Python 标准库，不装任何东西、不连任何第三方服务）：

    手机浏览器 → http://<电脑IP>:8765/?k=<令牌>
        ├─ POST /api/cmd   把一句话交给主程序（跟你在电脑上说话走同一条管线）
        ├─ GET  /api/log   把最近的对话（[听]/[发]/[答]…）拉回去显示
        ├─ POST /api/stop  让它闭嘴（等于喊「停」）
        └─ GET  /          手机网页界面（加到主屏幕就是个 APP）

安全：所有请求都要带令牌（?k= 或 X-Token 头），令牌存在 phone-token.txt，
第一次自动生成。默认只监听内网；要在外面也能用，就用 Tailscale 之类的内网穿透，
不要把 8765 直接映射到公网。
"""

from __future__ import annotations

import json
import hashlib
import mimetypes
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HERE = Path(__file__).resolve().parent
APK_FILE = HERE / "语音助手-手机端.apk"      # 手机页面上那个"下载安装包"给的就是它
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif"}


def safe_local_image(raw: str) -> Path | None:
    """手机页展示 Codex 返回的本地图片：只允许读取本机图片文件。"""
    text = str(raw or "").strip().strip('"').strip("'")
    if text.startswith("file://"):
        text = text[7:]
    if text.startswith("/") and len(text) > 2 and text[2:3] == ":":
        text = text[1:]
    try:
        p = Path(text).expanduser().resolve(strict=True)
        if not p.is_file() or p.suffix.lower() not in IMAGE_SUFFIXES:
            return None
        if p.stat().st_size > 80 * 1024 * 1024:
            return None
        if not p.is_relative_to(Path.home().resolve()):
            return None
        return p
    except Exception:
        return None

# 手机网页还有一个"外挂文件"版本：手机页.html。
# 有它就用它（每次请求现读、带 mtime 缓存）—— 这样我改完网页存个盘，
# 正在跑的服务下一刷就是新页面，**不用重启程序**（用户嫌重启二十多秒太慢）。
PAGE_FILE = HERE / "phone_page.html"
LEGACY_PAGE_FILE = HERE / "phone_feature" / "legacy_page.html"
PHONE_UI_ROOT = HERE / "phone_feature" / "ui"
PET_ROOT = HERE / "pet_live"
PET_WEB = PET_ROOT / "web"
_page_cache = {"mtime_ns": 0, "html": ""}


def current_page() -> str:
    """当前该发出去的那张网页：优先读 phone_page.html，其次用源码里的 PAGE。"""
    try:
        if PAGE_FILE.exists():
            mt = PAGE_FILE.stat().st_mtime_ns
            if mt != _page_cache["mtime_ns"] or not _page_cache["html"]:
                raw = PAGE_FILE.read_text(encoding="utf-8")
                _page_cache["html"] = raw.replace("__PAGE_REV__", str(mt))
                _page_cache["mtime_ns"] = mt
            if _page_cache["html"]:
                return _page_cache["html"]
    except Exception:
        pass
    return PAGE
PHONE_VER_FILE = HERE / "phone-version.txt"  # 打包时写下的"手机端自己是哪个版本"
DEFAULT_PORT = 8765


from phone_feature.security import (
    ACCESS_FILE,
    ACCESS_MAX,
    DEV_CODE_TTL,
    DEV_COOKIE,
    DEV_DENY_TTL,
    DEV_FILE,
    GUARD_BLOCK,
    GUARD_FAILS,
    GUARD_WINDOW,
    TOKEN_MIN_CHARS,
    _access_lock,
    _dev_find,
    _dev_fp,
    _dev_id_new,
    _dev_load,
    _dev_save,
    _dev_touch,
    _guard,
    _guard_lock,
    _ip_group,
    _tok_cache,
    access_clear,
    access_log,
    access_recent,
    current_token,
    device_allow,
    device_allow_by_code,
    device_credentials_valid,
    device_deny,
    device_epoch,
    device_forget_all,
    device_groups,
    device_name,
    device_revoke,
    device_trusted,
    devices,
    group_allow,
    group_deny,
    group_revoke,
    guard_blocked,
    guard_note,
    guard_reset,
    guard_stats,
    known_devices,
    load_token,
    pending_devices,
    rotate_token,
)

def lan_ip() -> str:
    """本机在局域网里的地址（连不上外网也能拿到，用 UDP 探一下路由）。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.2)
        s.connect(("192.168.1.1", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def phone_url(port: int = DEFAULT_PORT) -> str:
    """手机上要打开的那条网址（设置页也用它）。"""
    return f"http://{lan_ip()}:{int(port)}/?k={load_token()}"


def pc_version() -> str:
    """电脑端现在这个版本号（手机 APP 靠它判断要不要更新）。"""
    try:
        import version as ver_mod

        return str(ver_mod.APP_VERSION)
    except Exception:
        return ""


def phone_app_version() -> str:
    """电脑上这份手机端 APP 的版本（不是电脑端版本）。

    只有这个变了才提示手机更新 —— 电脑端做美化、调小功能的时候它不动。
    优先读打包时写的纸条，读不到就退回 version.py 里的 PHONE_VERSION。
    """
    try:
        got = PHONE_VER_FILE.read_text(encoding="utf-8").strip()
        if got:
            return got
    except Exception:
        pass
    try:
        import version as ver_mod

        return str(getattr(ver_mod, "PHONE_VERSION", ""))
    except Exception:
        return ""


def _load_legacy_page() -> str:
    """Keep the built-in fallback page as a real asset instead of 2,100 lines in code."""
    try:
        return LEGACY_PAGE_FILE.read_text(encoding="utf-8")
    except Exception:
        return "<!doctype html><meta charset='utf-8'><title>鳍舱</title><p>手机页资源缺失。</p>"


PAGE = _load_legacy_page()


class PhoneLink:
    """那个小 HTTP 门。回调都是外面（stt.py）传进来的。"""

    def __init__(self, on_command, get_state, get_log, on_stop=None,
                 port: int = DEFAULT_PORT, log=print, pairing: bool = True,
                 token: str | None = None) -> None:
        self.on_command = on_command
        self.get_state = get_state
        self.get_log = get_log
        self.on_stop = on_stop
        self.on_voice = None                 # 手机录的一段语音 → 交给主程序识别
        self.on_image = None                 # 手机发来的图片 → 交给主程序贴进对话窗口
        self.on_submit = None                # 图片只有附件时，提交当前输入框
        self.on_media_command = None         # 图片附件已放入输入框后，补文字并提交
        self.get_info = None                 # 电脑上这个助手叫什么、什么版本
        self.get_windows = None              # 电脑上现在有哪些聊天窗口（手机上来挑）
        self.get_projects = None             # Codex 项目（会话移动/项目分组用）
        self.get_codex_control = None         # 真实批准、diff、回合注入和恢复
        self.get_target = None               # 手机上次挑的是哪个窗口
        self.get_target_id = None             # 手机上次挑的稳定 thread_id
        self.on_target = None                # 手机切窗口 → 交给主程序
        self.on_thread_action = None         # 重命名/置顶/已读/归档/移动项目/删除
        self.on_new_thread = None            # 新建 Codex 会话
        self.get_schedule = None             # 电脑上的日程表（手机「日程」页要）
        self.on_schedule = None              # 手机上加/改/删日程 → 交给主程序
        self.get_replies = None              # 手机「看原话」：最近几条回答的原文
        self.port = int(port)
        self.log = log
        # pairing=False 只给自动化测试用（免掉"新设备要在电脑上点允许"这一道）
        self.pairing = bool(pairing)
        # token 也是给测试指定用的；不传就跟着 phone-token.txt 走（换令牌不用重启）
        self.token_forced = token is not None
        self.token = token or load_token()
        self._httpd: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._icons: dict[int, bytes] = {}
        self._seen_clients: dict[str, float] = {}   # 见过的手机/浏览器，用来报"连上了"
        self.on_client = None                       # 外面可以挂一个"有设备连上"的回调

    def _hello(self, ip: str) -> None:
        """第一次见到这个设备就说一声（电脑上立刻能看出手机连上没有）。"""
        now = time.time()
        last = self._seen_clients.get(ip, 0.0)
        self._seen_clients[ip] = now
        if now - last < 60:                          # 同一台设备一分钟内只报一次
            return
        self.log(f"📱 有设备连上了：{ip}")
        access_log("连上", "", ip, "", "")
        if self.on_client:
            try:
                self.on_client(ip)
            except Exception:
                pass

    # ---------------------------------------------------------------- 图标/清单
    def icon_png(self, size: int) -> bytes:
        """把程序自己的 voice.ico 缩成手机图标（有缓存，只生成一次）。"""
        size = 192 if size not in (192, 512) else size
        if size in self._icons:
            return self._icons[size]
        try:
            import io

            from PIL import Image

            ico = HERE / "voice.ico"
            if ico.exists():
                im = Image.open(ico).convert("RGBA")
            else:
                im = Image.new("RGBA", (size, size), (61, 220, 132, 255))
            im = im.resize((size, size), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, "PNG")
            data = buf.getvalue()
        except Exception:
            data = b""
        self._icons[size] = data
        return data

    def manifest(self) -> bytes:
        """PWA 清单：安卓 Chrome 靠它把网页"安装"成应用（图标、全屏、名字）。"""
        try:
            import version

            app_name = version.PRODUCT_FULL_NAME
        except Exception:
            app_name = "鳍舱 · FinDeck"
        data = {
            "name": app_name,
            "short_name": "鳍舱",
            "start_url": f"/?k={self.token}",
            "scope": "/",
            "display": "standalone",
            "background_color": "#1b1b1f",
            "theme_color": "#1b1b1f",
            "icons": [
                {"src": f"icon-192.png?k={self.token}", "sizes": "192x192", "type": "image/png"},
                {"src": f"icon-512.png?k={self.token}", "sizes": "512x512", "type": "image/png"},
            ],
        }
        return json.dumps(data, ensure_ascii=False).encode("utf-8")

    # ---------------------------------------------------------------- 启停
    def start(self) -> bool:
        outer = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "VoiceAssistantPhone/1.0"

            def log_message(self, *_a) -> None:      # 别往控制台刷日志
                pass

            # ---- 小工具 ----
            def _auth(self, q: dict) -> bool:
                got = (q.get("k") or [""])[0] or self.headers.get("X-Token") or ""
                want = outer.token if getattr(outer, "token_forced", False) else current_token()
                return bool(got) and secrets.compare_digest(str(got), str(want))

            def _who(self) -> tuple[str, bool]:
                """这个请求是谁发的；第二个值表示"是不是从公网转发进来的"。

                Funnel 转发进来的时候，连接其实是本机 127.0.0.1 发起的，
                真实来源在 X-Forwarded-For 里（Tailscale 会填上）。所以本机来的
                就看那个头，取最后一段（那是代理亲手加的，前面的可能是伪造的）。
                """
                peer = self.client_address[0] if self.client_address else "?"
                if peer in ("127.0.0.1", "::1"):
                    fwd = [x.strip() for x in
                           (self.headers.get("X-Forwarded-For") or "").split(",") if x.strip()]
                    if fwd:
                        return fwd[-1], True
                return peer, False

            def _gate(self, q: dict) -> bool:
                """三道门，过了才返回 True；没过会自己把响应写掉。

                ① 限速：**只管**从公网转发进来的那批（连接的来源是本机、真实来源在
                   X-Forwarded-For 里）—— 扫描机器人就是从那儿来的。自己手机走
                   Tailscale / 局域网直连的，令牌本来就不会错；万一哪天错了，也不能把
                   人锁在自己家门外（这坑真踩过：手机页面在轮询，令牌一换，几十次 401
                   就把手机自己封了 30 分钟）。
                ② 令牌：对不对。
                ③ 设备：这台设备你点头了吗（见上面的"新设备要配对"）。
                """
                who, public = self._who()
                if public:
                    left = guard_blocked(who)
                    if left > 0:
                        self._json({"ok": False, "err": "blocked",
                                    "retry_after": int(left)}, 429)
                        return False
                if not self._auth(q):
                    if public:
                        guard_note(who, False)
                    self._json({"ok": False, "err": "token"}, 401)
                    return False
                guard_note(who, True)
                # 本机进程（大肥鱼桌宠面板）用令牌直连，不再要求“设备配对”；
                # 公网转发进来的 public=True，仍然要走设备确认。
                if not public and who in ("127.0.0.1", "::1"):
                    return True
                return self._gate_device(who)

            def _secure(self) -> bool:
                """Require the rotating capability for mutating control actions."""
                try:
                    from features.app_security import verify

                    who, public = self._who()
                    local = not public and who in ("127.0.0.1", "::1")
                    if local:
                        verify(self.headers.get("X-FinDeck-Capability", ""))
                        return True
                    dev_id, _fresh = self._cookie_dev()
                    epoch = device_epoch(dev_id)
                    if not device_credentials_valid(dev_id, epoch):
                        self._json({"ok": False, "err": "设备授权已吊销",
                                    "need_capability": True}, 403)
                        return False
                    verify(
                        self.headers.get("X-FinDeck-Capability", ""),
                        device_id=dev_id,
                        device_epoch=epoch,
                        require_device=True,
                    )
                    return True
                except Exception as exc:  # noqa: BLE001
                    self._json({"ok": False, "err": str(exc)[:120],
                                "need_capability": True}, 403)
                    return False

            def _cookie_dev(self) -> tuple[str, bool]:
                """这台设备是谁；第二个值表示"这次是刚发的新 cookie"。

                有 cookie 就按 cookie 认；没有（APP 里那个后台轮询就不带 cookie）
                就按 UA + 来源认脸 —— 认到老面孔就复用它的记录，**不能每次当新设备**，
                不然一会儿就攒一堆"待确认"、还一直弹窗（真踩过）。
                """
                raw = self.headers.get("Cookie") or ""
                for part in raw.split(";"):
                    k, _, v = part.strip().partition("=")
                    if k == DEV_COOKIE and v.strip():
                        return v.strip(), False
                ua = self.headers.get("User-Agent") or ""
                ip = self._who()[0]
                got = _dev_find(ua, ip)
                if got:
                    return got, False
                return _dev_id_new(), True

            def _current_device_id(self) -> str:
                who, public = self._who()
                if not public and who in ("127.0.0.1", "::1"):
                    return ""
                return self._cookie_dev()[0]

            def _gate_device(self, who: str) -> bool:
                """设备这道门：没确认过的设备只给它"等电脑上点允许"那一页。"""
                if not getattr(outer, "pairing", True):
                    return True                     # 自动化测试专用
                dev_id, fresh = self._cookie_dev()
                if fresh:
                    self._extra_headers = [
                        ("Set-Cookie",
                         "%s=%s; Path=/; Max-Age=31536000; SameSite=Lax; HttpOnly"
                         % (DEV_COOKIE, dev_id))]
                if device_trusted(dev_id):
                    return True
                rec = _dev_touch(dev_id, self.headers.get("User-Agent") or "", who,
                                 _dev_fp(self.headers.get("User-Agent") or "", who))
                self._dev_id_now = dev_id
                code = str(rec.get("code") or "")
                if rec.get("is_new"):
                    access_log("新设备", dev_id, who,
                               self.headers.get("User-Agent") or "",
                               "配对码 %s（等你允许）" % code)
                if self.path.startswith("/api/"):
                    self._send(json.dumps({"ok": False, "err": "pairing", "code": code},
                                          ensure_ascii=False).encode("utf-8"),
                               "application/json; charset=utf-8", 403)
                    return False
                self._pending_page(code)
                return False

            def _issue_for_caller(self) -> dict:
                """Issue a local or device-bound capability for the current caller."""
                from features.app_security import issue

                who, public = self._who()
                local = not public and who in ("127.0.0.1", "::1")
                if local:
                    return issue()
                dev_id, _fresh = self._cookie_dev()
                epoch = device_epoch(dev_id)
                if not device_credentials_valid(dev_id, epoch):
                    raise ValueError("设备授权已吊销")
                return issue(device_id=dev_id, device_epoch=epoch)

            def _pending_page(self, code: str) -> None:
                """还没确认的设备看到的就是这一页（每 5 秒自己看一眼好了没有）。"""
                html = (
                    "<!doctype html><meta charset=utf-8>"
                    "<meta name=viewport content='width=device-width,initial-scale=1'>"
                    "<meta http-equiv=refresh content=5>"
                    "<style>body{margin:0;background:#1b1b1f;color:#f2f2f5;padding:26px;"
                    "font-family:-apple-system,'Microsoft YaHei UI',sans-serif;text-align:center}"
                    "h3{font-size:18px;margin:22px 0 6px}"
                    ".c{font-size:46px;letter-spacing:10px;font-weight:700;color:#3ddc84;"
                    "margin:16px 0 10px}"
                    ".m{color:#9a9aa5;font-size:13.5px;line-height:1.85}"
                    "button{display:block;width:100%%;margin:10px 0;padding:14px;border:0;"
                    "border-radius:12px;font-size:15px;background:#2a2a34;color:#f2f2f5}"
                    "button.main{background:#3ddc84;color:#08130c;font-weight:700}</style>"
                    "<h3>等你在电脑上点一下「允许」</h3>"
                    "<div class=c>%s</div>"
                    "<div class=m>电脑上会弹出「有台新设备想连进来」，把这个号码对一下再点允许。<br>"
                    "点过之后这台设备就不用再确认了。<br>这页每 5 秒自己看一眼。</div>"
                    "<button class=main onclick=\"location.reload()\">我已经点了「允许」，进去</button>"
                    "<button onclick=\"if(window.VoiceApp&&window.VoiceApp.back){window.VoiceApp.back()}else{history.back()}\">"
                    "不用了，关掉这页</button>"
                    % code)
                self._send(html.encode("utf-8"), "text/html; charset=utf-8", 200)

            def _json(self, obj: dict, code: int = 200) -> None:
                self._send(json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                           "application/json; charset=utf-8", code)

            def _alog(self, ev: str, detail: str = "") -> None:
                """记一笔连接记录（谁、什么时候、干了什么）。"""
                try:
                    who, _ = self._who()
                    access_log(ev, getattr(self, "_dev_id_now", ""), who,
                               self.headers.get("User-Agent") or "", detail)
                except Exception:                                # noqa: BLE001
                    pass

            def _html(self, page: str) -> None:
                self._send(page.encode("utf-8"), "text/html; charset=utf-8", 200)

            def _send(self, body: bytes, ctype: str, code: int = 200) -> None:
                """发一段文本；能压就压。

                手机在外面那条路带宽很窄（实测 1~3 Mbps）：这一页原始 76KB，
                gzip 之后只有 22KB —— 手机上少等一大截。
                """
                enc = ""
                try:
                    want = "gzip" in (self.headers.get("Accept-Encoding") or "").lower()
                    if want and len(body) > 600:
                        import gzip
                        body = gzip.compress(body, 6)
                        enc = "gzip"
                except Exception:                                # noqa: BLE001
                    enc = ""
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                extra = getattr(self, "_extra_headers", None)
                if extra:                       # 给新设备发 cookie 那一手
                    for _k, _v in extra:
                        self.send_header(_k, _v)
                    self._extra_headers = []
                if enc:
                    self.send_header("Content-Encoding", enc)
                    self.send_header("Vary", "Accept-Encoding")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            # ---- 路由 ----
            def do_GET(self) -> None:                # noqa: N802
                u = urlparse(self.path)
                q = parse_qs(u.query)
                # ---- 手机桌宠：只发形象素材，不含聊天数据，所以不走聊天令牌 ----
                # （页面里的 /api/state、/api/speak 仍然要令牌）
                pet_file = None
                if u.path in ("/pet", "/pet/"):
                    pet_file = PET_WEB / "pet_mobile.html"
                elif u.path == "/packs.json":
                    pet_file = PET_ROOT / "packs.json"
                elif u.path in ("/figure-frame", "/figure-frame.html"):
                    pet_file = PET_WEB / "figure-frame.html"
                elif u.path.startswith("/pet/"):
                    rel = u.path[len("/pet/"):]
                    try:
                        base = PET_WEB.resolve()
                        cand = (PET_WEB / rel).resolve()
                        cand.relative_to(base)
                        pet_file = cand
                    except Exception:
                        pet_file = None
                elif u.path.startswith("/web/"):
                    rel = u.path[len("/web/"):]
                    try:
                        base = PET_WEB.resolve()
                        cand = (PET_WEB / rel).resolve()
                        cand.relative_to(base)
                        pet_file = cand
                    except Exception:
                        pet_file = None
                if pet_file is not None:
                    try:
                        if pet_file.is_file():
                            ctype = (mimetypes.guess_type(str(pet_file))[0]
                                     or "application/octet-stream")
                            # 形象包在 sandbox iframe（不透明源）里跑，取脚本/贴图算跨域
                            self._extra_headers = [("Access-Control-Allow-Origin", "*")]
                            self._send(pet_file.read_bytes(), ctype, 200)
                        else:
                            self._json({"ok": False, "err": "not found"}, 404)
                    except Exception:
                        self._json({"ok": False, "err": "not found"}, 404)
                    return
                # ---- 下载页：故意不要令牌 ----
                # 这一页是给"别人"看的（发给朋友、同一个 Wi-Fi 里想装的同事），
                # 上面只有两个安装包和更新信息，没有对话内容、也没有控制入口。
                # （这里以前挂着一整套"局域网下载页"：/dl 页面、/dl/app.apk、/dl/pc.zip、
                #   二维码、更新清单、下载量统计）。用户要求"只留 GitHub 网址这一种下载方式"，
                #   所以整套都拆掉了 —— 下载和更新都走那个公网网址。
                if not self._gate(q):
                    return
                outer._hello(self.client_address[0] if self.client_address else "?")
                if u.path in ("/", "/index.html"):
                    self._html(current_page().replace("__TOKEN__", outer.token))
                    return
                if u.path == "/manifest.webmanifest":
                    body = outer.manifest()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/manifest+json; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                from phone_feature.static_routes import get_route as static_get

                static_result = static_get(
                    u.path,
                    q,
                    page_bytes=lambda: b"",
                    phone_ui_root=PHONE_UI_ROOT,
                    icon_png=outer.icon_png,
                    apk_file=APK_FILE,
                    shot_path=lambda name: __import__(
                        "screen_share"
                    ).shot_path(name),
                    local_image_path=safe_local_image,
                    audio_path=lambda name: __import__(
                        "file_share"
                    ).audio_path(name),
                    file_path=lambda name: __import__(
                        "file_share"
                    ).file_path(name),
                    upload_path=lambda name: __import__(
                        "file_share"
                    ).upload_path(name),
                )
                if static_result is not None:
                    if static_result.audit:
                        self._alog(*static_result.audit)
                    self._extra_headers = list(static_result.headers)
                    self._send(
                        static_result.body,
                        static_result.content_type,
                        static_result.status,
                    )
                    return
                from phone_feature.basic_routes import get_route as basic_get

                basic_result = basic_get(
                    u.path, q,
                    get_log=outer.get_log,
                    get_state=outer.get_state,
                    speak_file=HERE / "speak.json",
                    balance_file=HERE / "balance-latest.json",
                    page_file=PAGE_FILE,
                    apk_file=APK_FILE,
                    pc_version=pc_version,
                    phone_version=phone_app_version,
                    get_info=outer.get_info,
                )
                if basic_result is not None:
                    status, body, allow_cors = basic_result
                    if allow_cors:
                        self._extra_headers = [("Access-Control-Allow-Origin", "*")]
                    self._json(body, status)
                    return
                if u.path == "/api/security/session":
                    try:
                        self._json({"ok": True, **self._issue_for_caller()})
                    except Exception as exc:  # noqa: BLE001
                        self._json({"ok": False, "err": str(exc)[:160]}, 500)
                    return
                from phone_feature.media_routes import get_route as media_get

                media_result = media_get(u.path)
                if media_result is not None:
                    self._json(media_result[1], media_result[0])
                    return
                from phone_feature.session_schedule_routes import (
                    get_route as session_schedule_get,
                )

                session_result = session_schedule_get(
                    u.path,
                    get_windows=outer.get_windows,
                    get_target=outer.get_target,
                    get_target_id=outer.get_target_id,
                    get_projects=outer.get_projects,
                    get_schedule=outer.get_schedule,
                    get_replies=outer.get_replies,
                )
                if session_result is not None:
                    self._json(session_result[1], session_result[0])
                    return
                from phone_feature.console_routes import get_route as console_get

                console_result = console_get(
                    u.path, q,
                    transport=outer.get_codex_control,
                    current_device=self._current_device_id,
                )
                if console_result is not None:
                    self._json(console_result[1], console_result[0])
                    return
                from phone_feature.history_routes import get_route as history_get

                history_result = history_get(u.path, q)
                if history_result is not None:
                    self._json(history_result[1], history_result[0])
                    return
                self._json({"ok": False, "err": "not found"}, 404)

            def do_POST(self) -> None:               # noqa: N802
                u = urlparse(self.path)
                q = parse_qs(u.query)
                if not self._gate(q):
                    return
                outer._hello(self.client_address[0] if self.client_address else "?")
                from phone_feature.console_routes import (
                    SECURE_POST_PATHS as CONSOLE_SECURE_POST_PATHS,
                )
                from phone_feature.session_schedule_routes import (
                    SECURE_POST_PATHS as ACTION_SECURE_POST_PATHS,
                )
                from phone_feature.basic_routes import (
                    BASIC_SECURE_POST_PATHS,
                )
                from phone_feature.history_routes import (
                    SECURE_POST_PATHS as HISTORY_SECURE_POST_PATHS,
                )

                secure_paths = (
                    CONSOLE_SECURE_POST_PATHS
                    | ACTION_SECURE_POST_PATHS
                    | BASIC_SECURE_POST_PATHS
                    | HISTORY_SECURE_POST_PATHS
                )
                if u.path in secure_paths and not self._secure():
                    return
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except Exception:
                    n = 0
                # 先把 body **原样**读出来：上传文件时它是二进制，不能被 JSON 解析吃掉
                # （以前这里先 json.loads，body 就被消费了，再读就卡住 → 一直等到超时）
                raw = self.rfile.read(n) if 0 < n <= 200 * 1024 * 1024 else b""
                try:
                    data = json.loads(raw or b"{}")
                except Exception:
                    data = {}
                from phone_feature.basic_routes import post_route as basic_post

                basic_result = basic_post(
                    u.path, data,
                    on_command=outer.on_command,
                    on_stop=outer.on_stop,
                    on_submit=outer.on_submit,
                    on_media_command=outer.on_media_command,
                )
                if basic_result is not None:
                    status, body, audit = basic_result
                    if audit:
                        self._alog(*audit)
                    self._json(body, status)
                    return
                from phone_feature.console_routes import post_route as console_post

                console_result = console_post(
                    u.path, data,
                    raw=raw,
                    headers=dict(self.headers.items()),
                    transport=outer.get_codex_control,
                    current_device=self._current_device_id,
                )
                if console_result is not None:
                    status, body, audit = console_result
                    if audit:
                        self._alog(*audit)
                    self._json(body, status)
                    return
                from phone_feature.session_schedule_routes import (
                    post_route as session_schedule_post,
                )

                session_result = session_schedule_post(
                    u.path,
                    data,
                    on_thread_action=outer.on_thread_action,
                    on_new_thread=outer.on_new_thread,
                    on_target=outer.on_target,
                    get_target=outer.get_target,
                    on_schedule=outer.on_schedule,
                )
                if session_result is not None:
                    status, body, audit = session_result
                    if audit:
                        self._alog(*audit)
                    self._json(body, status)
                    return
                from phone_feature.history_routes import post_route as history_post

                history_result = history_post(u.path, data)
                if history_result is not None:
                    self._json(history_result[1], history_result[0])
                    return
                from phone_feature.media_routes import post_route as media_post

                media_result = media_post(
                    u.path, q, raw,
                    on_image=outer.on_image,
                    on_voice=outer.on_voice,
                )
                if media_result is not None:
                    status, body, audit = media_result
                    if audit:
                        self._alog(*audit)
                    self._json(body, status)
                    return
                self._json({"ok": False, "err": "not found"}, 404)

        for attempt in range(2):
            try:
                self._httpd = ThreadingHTTPServer(("0.0.0.0", self.port), Handler)
                break
            except OSError as exc:
                if attempt == 0 and self.port != 0:
                    self.log(f"   （手机入口：{self.port} 端口被占，换一个试试）")
                    self.port += 1
                    continue
                self.log(f"   （手机入口没起来：{exc}）")
                return False
        self._httpd.daemon_threads = True
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        try:
            if self._httpd is not None:
                self._httpd.shutdown()
                self._httpd.server_close()
        except Exception:
            pass
        self._httpd = None

    def url(self) -> str:
        return f"http://{lan_ip()}:{self.port}/?k={self.token}"

    def alive(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

