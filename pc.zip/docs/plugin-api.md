# 鳍舱插件 API 1

插件包是一个 ZIP，顶层只能有一个目录，目录里有 `plugin.json` 和入口 Python 文件。

```text
hello-findeck/
  plugin.json
  main.py
```

`plugin.json` 示例：

```json
{
  "id": "hello.findeck",
  "name": "Hello FinDeck",
  "version": "1.0.0",
  "api": 1,
  "entrypoint": "main.py",
  "description": "最小示例",
  "capabilities": ["stt"],
  "permissions": ["microphone"]
}
```

入口可以实现这些钩子：

```python
class DemoSTT:
    name = "demo-stt"

    def transcribe(self, audio, sample_rate=16000):
        return ""


def register(context):
    context.register_stt(DemoSTT())


def activate(context):
    pass


def deactivate(context):
    pass


def unregister(context):
    pass
```

能力白名单是 `command / page / stt / tts / task-provider`。注册接口只有在清单声明对应能力后才可用。权限白名单是 `clipboard / codex / filesystem-read / filesystem-write / microphone / network / notifications / playback / tasks`。

安装流程会先展示清单、能力和权限，用户确认后才写入。插件安装后会生成设备本机 HMAC 安装签名，文件被修改、安装密钥已轮换或清单版本不一致时都不能启用。安装本身绝不执行代码；启用、重载、停用和移除都必须由已授权设备发起。

插件是本地 Python 代码，不是安全沙箱。权限字段用于安装前告知，不能阻止恶意代码访问当前用户可访问的资源。只安装自己审核过的插件。

移除插件时目录会移动到 `<插件根目录>/.trash/`，便于人工恢复；不要在插件启用时直接改目录里的文件，先停用。
