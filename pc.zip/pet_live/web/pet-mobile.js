// 手机端桌宠：复用桌面同一套 body/kit/whale，跑在手机 WebView 里。
import { loadBody } from './body-host.js';

const q = new URLSearchParams(location.search);
const KEY = q.get('k') || '';
const OVERLAY = q.get('overlay') === '1';
const BASE = (q.get('base') || '').replace(/\/?$/, '/');
let petScale = Number(q.get('scale')) || Math.max(1.25, Math.min(2.0, innerWidth / 300));
const stage = document.getElementById('stage');
const errBox = document.getElementById('err');
const hint = document.getElementById('hint');

let body = null;
let pack = null;
let layout = null;
let floorY = innerHeight - 4;
let speaking = false;
let listening = false;
let thinking = false;
let lastStatus = '';
let lastT = performance.now();
let dragging = false;
let lastPointer = { x: 0, y: 0, t: 0 };
const walletEl = document.getElementById('wallet');
let walletVisible = false;

function showError(msg) {
  errBox.style.display = 'block';
  errBox.textContent = String(msg || '').slice(0, 220);
}

function playSound(name) {
  try {
    const s = pack && pack.sounds && pack.sounds[name];
    if (!s) return;
    const a = new Audio(pack.base + s.file);
    a.volume = Math.min(1, 0.35 * (s.volume == null ? 1 : s.volume));
    a.play().catch(() => {});
  } catch (e) {}
}

const bounds = () => ({
  W: innerWidth, H: innerHeight, floorY,
  S: 0.42 * petScale,
});

function fmtMoney(v, cur) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  const sym = String(cur || '').toUpperCase() === 'USD' ? '$'
    : String(cur || '').toUpperCase() === 'CNY' ? '¥' : '';
  return sym + n.toFixed(2);
}

function fmtTokens(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(Math.round(n));
}

async function pollWallet() {
  if (!OVERLAY || !BASE) return;
  try {
    const r = await fetch(BASE + 'api/balance?k=' + encodeURIComponent(KEY) + '&t=' + Date.now(),
                          { cache: 'no-store' });
    if (!r.ok) throw new Error('http ' + r.status);
    const d = await r.json();
    walletEl.classList.remove('hidden');
    if (!d || d.ok === false || !d.balance || !Number.isFinite(Number(d.balance.total))) {
      document.getElementById('walletBalance').textContent =
        d && d.enabled === false ? '饭碗已关' : '未连接';
      document.getElementById('walletToday').textContent = '今日 —';
      document.getElementById('walletStep').textContent = '最近一步 —';
      document.getElementById('wallet7d').textContent = '近 7 天 —';
      return;
    }
    const bal = d.balance;
    const spend = d.spend || {};
    const usage = (d.usage && d.usage.tokens) || {};
    const turn = d.lastTurn || {};
    document.getElementById('walletBalance').textContent =
      fmtMoney(bal.total, bal.currency);
    document.getElementById('walletToday').textContent =
      '今日 ' + fmtMoney(spend.today, bal.currency);
    document.getElementById('walletStep').textContent =
      '最近一步 ' + fmtTokens(turn.total);
    document.getElementById('wallet7d').textContent =
      '近 7 天 ' + fmtTokens(usage.last7Days || usage.total);
    document.getElementById('walletTime').textContent =
      new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  } catch (e) {
    walletEl.classList.remove('hidden');
    document.getElementById('walletBalance').textContent = '未连接';
  }
}

window.__petWalletToggle = () => {
  walletVisible = !walletVisible;
  walletEl.classList.toggle('hidden', !walletVisible);
  if (walletVisible) pollWallet();
};

window.__petPoke = () => {
  if (!body) return;
  try { body.do('happy'); body.cue('cheer'); } catch (e) {}
};

window.__petSetScale = (s) => {
  const n = Number(s);
  if (!Number.isFinite(n)) return;
  petScale = Math.max(0.6, Math.min(2.2, n));
  if (body) {
    try { body.set({ bounds: bounds() }); } catch (e) {}
  }
};

async function boot() {
  if (!KEY) {
    showError('没有连接令牌，请从手机入口的「＋ → 桌宠」打开。');
    return;
  }
  const packsUrl = OVERLAY ? './packs.json' : '/packs.json';
  const packs = await (await fetch(packsUrl + '?t=' + Date.now(), { cache: 'no-store' })).json();
  pack = (Array.isArray(packs) ? packs : []).find((p) => p.id === 'whale') || packs[0];
  if (!pack) throw new Error('没读到形象包');
  if (OVERLAY) pack.base = new URL('./whale/', location.href).href;
  body = await loadBody({
    layer: stage,
    pack,
    theme: 'dark',
    bounds: bounds(),
    start: {
      x: innerWidth * 0.5,
      facing: 1,
      enter: 'drop',
      skin: { figure: 'whale', scheme: 'deepseek', outfit: 'maid' },
      scheme: 'deepseek',
    },
    onEvent: (kind) => { if (kind === 'touch') playSound('pat'); },
    onSound: (name) => playSound(name),
    onError: (e) => showError(e && e.message ? e.message : e),
  });
  body.set({ roam: true, bounds: bounds() });
  requestAnimationFrame(tick);
  setInterval(pollStatus, 400);
  setInterval(pollSpeak, 250);
  setInterval(() => { if (walletVisible) pollWallet(); }, 20000);
  setTimeout(() => hint.classList.add('gone'), 4200);
}

function tick(t) {
  const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000));
  lastT = t;
  try {
    if (speaking && body) {
      try { body.talk(); } catch (e) {}
    }
    body.tick(dt);
    layout = body.layout;
  } catch (e) {
    showError(e && e.message ? e.message : e);
  }
  requestAnimationFrame(tick);
}

async function pollStatus() {
  if (OVERLAY && !BASE) return;
  try {
    const path = (OVERLAY ? BASE : '') + 'api/state?k=' + encodeURIComponent(KEY) + '&t=' + Date.now();
    const r = await fetch(path,
                          { cache: 'no-store' });
    if (!r.ok) {
      if (r.status === 401) showError('令牌失效，回手机入口重新扫码。');
      return;
    }
    const s = await r.json();
    const st = String(s.state_text || s.state || '').split('·')[0].trim();
    const hear = st === 'hearing';
    const think = !!s.busy || st === 'thinking';
    if (hear !== listening || think !== thinking) {
      listening = hear;
      thinking = think;
      if (body) {
        body.set({ listening, thinking, roam: (thinking || speaking) ? 'off' : 'free' });
        if (thinking) { try { body.do('stand'); } catch (e) {} }
      }
    }
    if (st && st !== lastStatus) {
      lastStatus = st;
      if (body) {
        if (st === 'sent' || st === 'copied') body.cue('cheer');
        else if (st === 'paused' || st === 'offline') body.do('sleep');
      }
    }
  } catch (e) {}
}

async function pollSpeak() {
  if (OVERLAY && !BASE) return;
  try {
    const path = (OVERLAY ? BASE : '') + 'api/speak?k=' + encodeURIComponent(KEY) + '&t=' + Date.now();
    const r = await fetch(path,
                          { cache: 'no-store' });
    if (!r.ok) return;
    const s = await r.json();
    const active = !!s.active && (Date.now() / 1000 - Number(s.ts || 0) < 6);
    if (active === speaking) return;
    speaking = active;
    if (!body) return;
    body.set({ roam: (speaking || thinking) ? 'off' : 'free' });
    if (speaking) { try { body.do('stand'); } catch (e) {} }
  } catch (e) {}
}

function point(e) {
  const t = e.touches ? e.touches[0] : e;
  return { x: t.clientX, y: t.clientY, t: performance.now() };
}

stage.addEventListener('pointerdown', (e) => {
  const p = point(e);
  lastPointer = p;
  if (!body || !body.hit(p)) return;
  dragging = true;
  e.preventDefault();
  try { body.pointer('down', p); } catch (err) {}
}, { passive: false });

stage.addEventListener('pointermove', (e) => {
  const p = point(e);
  lastPointer = p;
  if (!body) return;
  if (dragging) {
    e.preventDefault();
    try { body.pointer('move', p); } catch (err) {}
  }
}, { passive: false });

function endDrag(e) {
  if (!dragging) return;
  dragging = false;
  try { body.pointer('up', lastPointer); } catch (err) {}
}
stage.addEventListener('pointerup', endDrag);
stage.addEventListener('pointercancel', endDrag);
window.addEventListener('blur', () => {
  if (dragging && body) {
    dragging = false;
    try { body.pointer('cancel', lastPointer); } catch (e) {}
  }
});

addEventListener('resize', () => {
  floorY = innerHeight - 4;
  if (body) {
    try { body.set({ bounds: bounds() }); } catch (e) {}
  }
});

boot().catch((e) => showError(e && e.message ? e.message : e));
