// 桌宠宿主页：把形象包装进来、每帧驱动、读语音助手的状态换表情。
import { loadBody } from './body-host.js';
import { createSfx } from './sound.js';

const layer = document.getElementById('figureLayer');
const errBox = document.getElementById('err');
const sfx = createSfx({ volume: 0.55 });
console.log('pet-host: start');
addEventListener('error', (e) => {
  console.log('pet-host: error', e.message);
});
addEventListener('unhandledrejection', (e) => {
  console.log('pet-host: rejection', String(e.reason));
});

let SCALE = 1.25;                       // 1.0 = 助手原来的大小（256 单位 × 0.42）
let floorY = innerHeight - 10;          // 脚踩在哪：默认屏幕底，之后按 x 查"下面窗口的顶边"
const bounds = () => ({ W: innerWidth, H: innerHeight, floorY, S: 0.42 * SCALE });

let body = null;
let pack = null;
let petSettings = {
  scale: 1.25, roam: 'free', sound: true, soundVolume: 0.5,
  bubble: true, bubbleSeconds: 6, bubbleFont: 12, bubbleWidth: 250,
  night: false, interact: true,
  rememberPos: true, hideFullscreen: false, x: null,
  soundKinds: { move: true, touch: true, face: true, snore: true, talk: true, ui: true },
};
let lastSavedX = null;
let savePosAt = 0;
// 自检用：让桌宠进入思考姿势，方便截图检查（日常不会调用）
window.__petSetThinking = (on) => {
  if (!body) return;
  body.set({ thinking: !!on, roam: on ? 'off' : 'free' });
  if (on) { try { body.do('stand'); } catch (e) {} }
};
let lastT = performance.now();
let hover = null;
let layout = null;
const bw = document.getElementById('balanceWidget');
const eatToast = document.getElementById('eatToast');
const typeBox = document.getElementById('typeBox');
const typeInput = document.getElementById('typeInput');
const petBubble = document.getElementById('petBubble');
let balanceVisible = false;
let bwExpanded = false;
let prevStepAt = 0;
let speaking = false;
let eatToastUntil = 0;
let debugFreeze = false;
window.__petFreeze = (on) => { debugFreeze = !!on; };
window.__petState = () => ({ layout, bodyDragging, hover, pointer: lastPointer });
window.__petTest = {
  showType: () => showTypeBox(),
  hideType: () => hideTypeBox(),
  typeVisible: () => !!typeBox && !typeBox.classList.contains('va-hidden'),
  focusInBox: () => document.activeElement === typeInput,
  settings: () => ({ ...petSettings, scale: SCALE }),
  apply: (patch) => applyPetSettings(patch),
  sound: (name = 'happy', kind = 'face') => { try { sfx.unlock(); sfx.play(name, kind); return true; } catch (e) { return false; } },
  words: () => (body && body.words ? body.words.slice() : []),
  do: (word) => { try { body && body.do(String(word)); } catch (e) {} },
};
let bodyDragging = false;
let lastPointer = { x: 0, y: 0, t: 0 };
let lastButtons = 0;
let bubbleUntil = 0;
let pressAt = null;
let pressMoved = false;
let lastSpokenText = '';
let lastReplyTs = 0;
const VA_LINES = [
  '我在呢。', '摸摸头。', '今天也要加油呀。', '要不要聊两句？',
  '大肥鱼，随时待命。', '叫我干嘛？', '我听着呢。'
];
const pickLine = (list) => list[Math.floor(Math.random() * list.length)] || '';

function fmtMoney(value, currency) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  const sym = String(currency || '').toUpperCase() === 'USD' ? '$'
    : String(currency || '').toUpperCase() === 'CNY' ? '¥' : '';
  return sym + n.toFixed(2);
}

function fmtTokens(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(Math.round(n));
}

function clockText(ts) {
  try {
    return new Date(ts).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

function balanceRect() {
  if (!balanceVisible || !bw || bw.classList.contains('hidden')) return null;
  return bw.getBoundingClientRect();
}

function pointInRect(p, r) {
  return !!r && p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;
}

function positionBalance() {
  if (!balanceVisible || !bw || bw.classList.contains('hidden')) return;
  const box = layout && layout.box;
  const w = bw.offsetWidth || 200;
  const h = bw.offsetHeight || 90;
  let x = box ? box.x + box.w + 14 : innerWidth * 0.64;
  let y = box ? box.y + 8 : innerHeight * 0.55;
  if (x + w > innerWidth - 8) x = box ? box.x - w - 14 : innerWidth - w - 8;
  if (x < 8) x = 8;
  if (y + h > innerHeight - 8) y = innerHeight - h - 8;
  if (y < 8) y = 8;
  bw.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
}

function positionEatToast() {
  if (!eatToast || !balanceVisible) return;
  const box = layout && layout.box;
  if (!box) return;
  let x = box.x + box.w / 2;
  let y = box.y - 6;
  if (y < 54) y = box.y + box.h + 16;
  eatToast.style.left = Math.round(x) + 'px';
  eatToast.style.top = Math.round(y) + 'px';
}

function showEatToast(tokenDelta, cnyDelta, currency, totalTokens = 0) {
  if (!eatToast || !balanceVisible) return;
  const parts = [];
  if (tokenDelta > 0) {
    let label = fmtTokens(tokenDelta) + ' token';
    if (totalTokens > tokenDelta * 1.5) {
      label += '（含缓存共 ' + fmtTokens(totalTokens) + '）';
    }
    parts.push(label);
  }
  if (cnyDelta >= 0.000001) parts.push('≈' + fmtMoney(cnyDelta, currency));
  if (!parts.length) return;
  eatToast.textContent = '吃掉 ' + parts.join(' · ');
  positionEatToast();
  eatToast.classList.remove('show');
  void eatToast.offsetWidth;          // 重启动画
  eatToast.classList.add('show');
  eatToastUntil = performance.now() + 5200;
}

async function pollSpeak() {
  try {
    const r = await fetch('/speak.json?t=' + Date.now(), { cache: 'no-store' });
    const s = await r.json();
    const active = !!s.active && (Date.now() / 1000 - Number(s.ts || 0) < 6);
    if (active && s.text && s.text !== lastSpokenText) {
      lastSpokenText = String(s.text);
      showBubble(lastSpokenText, 7000);
    }
    if (!active) {
      try {
        const lr = await fetch('/last-reply.json?t=' + Date.now(), { cache: 'no-store' }).then((x) => x.json());
        const ts = Number(lr.ts || 0);
        const text = String(lr.text || '').trim();
        if (ts > lastReplyTs && text && Date.now() / 1000 - ts < 600) {
          lastReplyTs = ts;
          showBubble(text.slice(0, 500) + (text.length > 500 ? '…' : ''), 12000);
        }
      } catch (e) {}
    }
    if (active === speaking) return;
    speaking = active;
    if (!body) return;
    body.set({ roam: desiredRoam() });
    if (active) {
      try { body.do('stand'); } catch (e) {}
    }
  } catch (e) {}
}
// 自检用：直接弹一条“吃掉”提示
window.__petEatToast = (tokens, cny) =>
  showEatToast(Number(tokens) || 0, Number(cny) || 0, 'CNY');

function positionTypeBox() {
  const box = layout && layout.box;
  if (!box) return;
  const tw = typeBox.offsetWidth || 270;
  const th = typeBox.offsetHeight || 42;
  let tx = box.x - 20;
  let ty = box.y + box.h + 12;
  if (tx + tw > innerWidth - 8) tx = innerWidth - tw - 8;
  if (tx < 8) tx = 8;
  if (ty + th > innerHeight - 8) ty = box.y - th - 12;
  if (ty < 8) ty = 8;
  typeBox.style.transform = `translate(${Math.round(tx)}px, ${Math.round(ty)}px)`;

  let bx = box.x + box.w / 2;
  let by = box.y - 6;
  if (by < 70) by = box.y + box.h + 14;
  petBubble.style.transform =
    `translate(${Math.round(bx)}px, ${Math.round(by)}px) translate(-50%,-100%)`;
}

function desiredRoam() {
  if (motion || speaking || thinking) return 'off';
  if (typeBox && !typeBox.classList.contains('va-hidden')) return 'off';
  return petSettings.roam || 'free';
}

function applyPetSettings(next) {
  if (next && typeof next === 'object') petSettings = { ...petSettings, ...next };
  const scale = Number(petSettings.scale);
  SCALE = Math.max(0.6, Math.min(2.2, Number.isFinite(scale) ? scale : 1.25));
  layer.classList.toggle('night', !!petSettings.night);
  if (petBubble) {
    petBubble.style.fontSize = Math.max(9, Math.min(22, Number(petSettings.bubbleFont) || 12)) + 'px';
    petBubble.style.maxWidth = Math.max(160, Math.min(420, Number(petSettings.bubbleWidth) || 250)) + 'px';
  }
  try {
    sfx.set(!!petSettings.sound);
    sfx.volume(Math.max(0, Math.min(1, Number(petSettings.soundVolume) || 0.5)));
    sfx.configure({ kinds: petSettings.soundKinds || {} });
  } catch (e) {}
  if (body) {
    try {
      body.set({
        bounds: bounds(),
        roam: desiredRoam(),
        dialogOpen: typeBox && !typeBox.classList.contains('va-hidden'),
      });
    } catch (e) {}
  }
}

function showBubble(text, ms = null) {
  if (!petSettings.bubble) return;
  const s = String(text || '').trim();
  if (!s) return;
  petBubble.textContent = s.length > 180 ? s.slice(0, 179) + '…' : s;
  petBubble.classList.add('show');
  bubbleUntil = performance.now() + (Number(ms) || Number(petSettings.bubbleSeconds) * 1000 || 6000);
  positionTypeBox();
}

if (window.petHost) {
  if (window.petHost.onPetStyle) window.petHost.onPetStyle((s) => {
    if (body && s) {
      try { body.setScheme(`${s.scheme || 'deepseek'}-${s.outfit || 'maid'}`); }
      catch (e) {}
    }
  });
  if (window.petHost.onPetSettings) window.petHost.onPetSettings(applyPetSettings);
  if (window.petHost.onPetDo) window.petHost.onPetDo((word) => {
    if (!body || !word) return;
    try { body.do(String(word)); } catch (e) {}
  });
  if (window.petHost.onPetType) window.petHost.onPetType(showTypeBox);
  if (window.petHost.onPetBlur) window.petHost.onPetBlur(() => {
    if (typeBox && !typeBox.classList.contains('va-hidden')) hideTypeBox();
  });
}

function showTypeBox() {
  if (!typeBox) return;
  typeBox.classList.remove('va-hidden');
  if (body) {
    try { body.set({ dialogOpen: true, roam: 'off' }); } catch (e) {}
  }
  positionTypeBox();
  setTimeout(() => { try { typeInput.focus(); } catch (e) {} }, 30);
}

function hideTypeBox() {
  if (!typeBox) return;
  typeBox.classList.add('va-hidden');
  try { typeInput.blur(); } catch (e) {}
  if (body) {
    try { body.set({ dialogOpen: false, roam: desiredRoam() }); } catch (e) {}
  }
}

async function sendTypeText() {
  if (!typeInput) return;
  const text = (typeInput.value || '').trim();
  if (!text) return;
  typeInput.value = '';
  hideTypeBox();
  showBubble('发送中…', 3000);
  try {
    const r = await window.petHost.vaSend(text);
    if (r && r.ok === false) showBubble('没发出去，语音助手可能没在跑', 5000);
    else showBubble('发出去啦，等它回你。', 3500);
  } catch (e) {
    showBubble('没发出去，语音助手可能没在跑', 5000);
  }
}
if (typeInput) {
  typeInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendTypeText();
    else if (e.key === 'Escape') hideTypeBox();
  });
}

function renderBalance(data) {
  if (!data) return;
  balanceVisible = data.enabled !== false;
  bw.classList.toggle('hidden', !balanceVisible);
  if (!balanceVisible) {
    prevStepAt = 0;
    if (eatToast) eatToast.classList.remove('show');
    return;
  }
  const bal = data.balance || {};
  const spend = data.spend || {};
  const usage = (data.usage && data.usage.tokens) || {};
  const turn = data.lastTurn || null;
  const ok = !!data.ok && bal.ok !== false && Number.isFinite(Number(bal.total));
  const mainKey = (data.settings && data.settings.mainBalance) || 'total';
  const mainValue = mainKey === 'toppedUp' ? bal.toppedUp
    : mainKey === 'granted' ? bal.granted : bal.total;
  const stepAt = turn ? Number(turn.at) || 0 : 0;
  if (ok && stepAt && prevStepAt && stepAt !== prevStepAt && Number(turn.total) > 0) {
    // 单次 = 这一条 token_count（一次模型调用）。主数字只算"新增"：
    // 未命中缓存的输入 + 输出；缓存上下文另写在括号里，免得看起来像累计。
    const input = Number(turn.input) || 0;
    const cached = Math.min(input, Number(turn.cached) || 0);
    const output = Number(turn.output) || 0;
    const fresh = Math.max(0, input - cached) + output;
    showEatToast(fresh, Number(turn.costCNY) || 0,
                 bal.currency || spend.lastCurrency, Number(turn.total) || 0);
  }
  if (stepAt) prevStepAt = stepAt;
  const dot = document.getElementById('bwDot');
  dot.className = 'bw-dot';

  if (ok) {
    document.getElementById('bwBalance').textContent = fmtMoney(mainValue, bal.currency);
    document.getElementById('bwCurrency').textContent = bal.currency || '';
    document.getElementById('bwState').textContent = clockText(data.updatedAt || Date.now());
  } else {
    document.getElementById('bwBalance').textContent =
      spend.lastBalance != null ? fmtMoney(spend.lastBalance, spend.lastCurrency) : '—';
    document.getElementById('bwCurrency').textContent = spend.lastCurrency || '';
    document.getElementById('bwState').textContent = '余额读取失败';
    dot.classList.add('bad');
  }
  const moneyOrDash = (v) => (Number.isFinite(Number(v)) ? fmtMoney(v, bal.currency) : '—');
  document.getElementById('bwBreak').textContent =
    `充值 ${moneyOrDash(bal.toppedUp)} · 赠金 ${moneyOrDash(bal.granted)}`;
  document.getElementById('bwTopped').textContent = moneyOrDash(bal.toppedUp);
  document.getElementById('bwGranted').textContent = moneyOrDash(bal.granted);
  const low = Number(data.settings && data.settings.lowBalance) || 0;
  const balanceEl = document.getElementById('bwBalance');
  balanceEl.classList.toggle('bw-bad', ok && low > 0 && Number(bal.total) <= low);

  const today = Number(spend.today);
  const todayText = Number.isFinite(today) ? fmtMoney(today, bal.currency || spend.lastCurrency) : '—';
  document.getElementById('bwToday').textContent = '今日 ' + todayText;
  const budget = Number(data.settings && data.settings.budgetToday) || 0;
  document.getElementById('bwToday').classList.toggle(
    'bw-warn', Number.isFinite(today) && budget > 0 && today >= budget);
  document.getElementById('bwTurn').textContent =
    '最近一步 ' + (turn && Number.isFinite(Number(turn.total)) ? fmtTokens(turn.total) : '—');

  const complete = usage.complete !== false;
  document.getElementById('bw7d').textContent =
    fmtTokens(usage.last7Days || usage.total || 0) + (complete ? '' : '（部分）');
  document.getElementById('bw5h').textContent = fmtTokens(usage.last5Hours || 0);
  document.getElementById('bwIo').textContent = turn
    ? `${fmtTokens(turn.input)} / ${fmtTokens(turn.output)}` : '—';
  document.getElementById('bwTotal').textContent =
    fmtMoney(spend.total || 0, bal.currency || spend.lastCurrency);
  document.getElementById('bwSource').textContent = bal.provider
    ? `${bal.provider}${bal.host ? ' · ' + bal.host : ''}`
    : (data.ok === false ? '仅本机用量' : '本机');

  const windows = Array.isArray(data.usage && data.usage.windows) ? data.usage.windows : [];
  const quotaLine = document.getElementById('bwQuotaLine');
  if (windows.length) {
    quotaLine.style.display = '';
    document.getElementById('bwQuota').textContent = windows
      .map((w) => `${w.label || ''} ${Number(w.usedPercent).toFixed(0)}%`)
      .join(' · ');
  } else {
    quotaLine.style.display = 'none';
  }
  positionBalance();
}

if (window.petHost) {
  if (window.petHost.onBalance) window.petHost.onBalance(renderBalance);
  if (window.petHost.onBalanceEnabled) {
    window.petHost.onBalanceEnabled((on) => {
      balanceVisible = !!on;
      bw.classList.toggle('hidden', !balanceVisible);
      if (balanceVisible && window.petHost.balanceGet) {
        prevStepAt = 0;
        window.petHost.balanceGet().then(renderBalance).catch(() => {});
      }
    });
  }
  if (window.petHost.onBalanceOpen) {
    window.petHost.onBalanceOpen(() => {
      balanceVisible = true;
      bw.classList.remove('hidden');
      bwExpanded = true;
      bw.classList.add('expanded');
      positionBalance();
    });
  }
}

if (bw) {
  bw.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('button')) return;
    e.stopPropagation();
    bwExpanded = !bwExpanded;
    bw.classList.toggle('expanded', bwExpanded);
    positionBalance();
  });
  bw.addEventListener('mousedown', (e) => e.stopPropagation());
  const btn = (id, fn) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', (e) => {
      e.stopPropagation();
      try { fn(); } catch (err) {}
    });
  };
  btn('bwRefresh', () => window.petHost && window.petHost.balanceRefresh
    && window.petHost.balanceRefresh().then(renderBalance).catch(() => {}));
  btn('bwSet', () => window.petHost && window.petHost.balanceOpenSettings
    && window.petHost.balanceOpenSettings());
  btn('bwHide', () => window.petHost && window.petHost.balanceSetEnabled
    && window.petHost.balanceSetEnabled(false));
}
// 自检用：把状态写进 <html data-pet="...">（executeJavaScript 的上下文读得到）
setInterval(() => {
  document.documentElement.dataset.pet = JSON.stringify({
    ready: !!body,
    mode: layout ? layout.mode : '',
    box: layout ? layout.box : null,
    floorY,
    frames: document.querySelectorAll('iframe').length,
    err: errBox.textContent,
  });
}, 500);

function showError(msg) {
  errBox.style.display = 'block';
  errBox.textContent = String(msg).slice(0, 240);
}

async function boot() {
  if (window.petHost && window.petHost.petSettingsGet) {
    try { applyPetSettings(await window.petHost.petSettingsGet()); } catch (e) {}
  }
  const packs = await (await fetch('/packs.json', { cache: 'no-store' })).json();
  console.log('pet-host: packs', Array.isArray(packs) ? packs.length : typeof packs);
  pack = (Array.isArray(packs) ? packs : []).find((p) => p.id === 'whale') || packs[0];
  if (!pack) throw new Error('没读到形象包');
  try { sfx.usePack(pack.base, pack.sounds || {}); } catch (e) {}
  await refreshSurface(true);           // 先问一次地面，别从半空掉下来
  const startX = Number.isFinite(Number(petSettings.x))
    ? Math.max(80, Math.min(innerWidth - 80, Number(petSettings.x)))
    : innerWidth * 0.62;
  body = await loadBody({
    layer,
    pack,
    theme: 'dark',
    bounds: bounds(),
    start: {
      x: startX,
      facing: 1,
      enter: 'drop',
      skin: { figure: 'whale', scheme: 'deepseek', outfit: 'maid' },
      scheme: 'deepseek',
    },
    onEvent: (kind, detail) => {
      if (kind !== 'touch') return;
      const what = detail && detail.kind;
      if (what === 'pet') {
        if (petSettings.interact) showBubble(pickLine(['嘿嘿，好舒服。', '再摸一下嘛。', '唔…头被你摸乱了。']), 2600);
      } else if (what === 'poke') {
        if (petSettings.interact) showBubble(pickLine(VA_LINES), 4200);
      } else if (what === 'throw') {
        showBubble('哇——轻点扔！', 2200);
      } else if (what === 'drop') {
        showBubble(pickLine(['稳稳落地。', '我回来啦。']), 2200);
      }
    },
    onSound: (name, kind, ...args) => {
      try { sfx.play(name, kind, ...args); } catch (e) {}
    },
    onError: (e) => showError(e && e.message ? e.message : e),
  });
  body.set({ roam: petSettings.roam, bounds: bounds() });   // 自己会走动（原作本来就有的功能）
  if (window.petHost && window.petHost.petStyleGet) {
    window.petHost.petStyleGet().then((s) => {
      if (body && s) {
        try { body.setScheme(`${s.scheme || 'deepseek'}-${s.outfit || 'maid'}`); }
        catch (e) {}
      }
    }).catch(() => {});
  }
  requestAnimationFrame(tick);
  if (window.petHost && window.petHost.balanceGet) {
    window.petHost.balanceGet().then(renderBalance).catch(() => {});
  }
  setInterval(poll, 300);
  setInterval(pollSpeak, 250);
  setInterval(() => refreshSurface(false), 400);
}

// ---- 地面：按它当前 x 找"脚下的窗沿"和"上面能爬的窗沿" ----
let floorBusy = false;
let motion = null;                  // 'fall' | 'climb'
let motionFrom = 0, motionTo = 0, motionStart = 0, motionDur = 0;
let floorSettledAt = performance.now() + 2000;
let climbCooldownUntil = performance.now() + 3000;

function setFloor(y) {
  floorY = Number(y);
  if (body) body.set({ bounds: bounds() });
}

function beginFall(target) {
  motion = 'fall';
  motionFrom = floorY;
  motionTo = target;
  motionStart = performance.now();
  motionDur = Math.min(520, 240 + Math.abs(target - floorY) * 0.55);
  if (body) {
    body.set({ roam: 'off' });
    body.do('surprised');
  }
}

function beginClimb(target) {
  motion = 'climb';
  motionFrom = floorY;
  motionTo = target;
  motionStart = performance.now();
  motionDur = Math.min(1800, 520 + Math.abs(target - floorY) * 0.9);
  if (body) {
    body.set({ roam: 'off' });
    body.do('stand');
    body.do('climbing');
  }
}

function updateMotion(now) {
  if (!motion) return;
  const p = Math.min(1, Math.max(0, (now - motionStart) / motionDur));
  const e = motion === 'climb' ? p * p * (3 - 2 * p) : p * p;
  floorY = motionFrom + (motionTo - motionFrom) * e;
  if (body) body.set({ bounds: bounds() });
  if (p >= 1) {
    const kind = motion;
    motion = null;
    floorY = motionTo;
    floorSettledAt = now;
    climbCooldownUntil = now + 6000;
    if (body) {
      body.set({ roam: desiredRoam(), bounds: bounds() });
      body.do(kind === 'climb' ? 'happy' : 'neutral');
    }
  }
}

async function refreshSurface(force) {
  if (!window.petHost || !window.petHost.surface || floorBusy || motion || bodyDragging) return;
  const box = layout && layout.box;
  const x = Math.round(layout ? layout.x : innerWidth * 0.62);
  const feet = Math.round(box ? box.y + box.h : innerHeight - 10);
  floorBusy = true;
  try {
    const s = await window.petHost.surface(x, feet);
    if (!s || !Number.isFinite(Number(s.floor))) return;
    const nf = Number(s.floor);
    if (force) {
      setFloor(nf);
      floorSettledAt = performance.now();
      return;
    }
    if (Math.abs(nf - floorY) > 2) {
      if (nf > floorY + 6) {
        beginFall(nf);                  // 从窗口上走下来：落下去
      } else {
        setFloor(nf);                   // 地面自己升高（窗口移动）：先跟上
        floorSettledAt = performance.now();
      }
    } else if (s.climb && performance.now() > climbCooldownUntil
               && performance.now() > floorSettledAt + 1200
               && !(layout && layout.busy)) {
      const cy = Number(s.climb.y);
      if (Number.isFinite(cy) && floorY - cy > 24) {
        beginClimb(cy);                 // 自己爬到上面的窗沿
      }
    }
  } catch (e) {
  } finally {
    floorBusy = false;
  }
}

function tick(t) {
  const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000));
  lastT = t;
  try {
    updateMotion(t);
    if (speaking && body) {
      try { body.talk(); } catch (e) {}
    }
    body.tick(dt);
    layout = body.layout;
    // 以前鼠标一离开角色的像素，窗口就变穿透，mouseup 收不到 → 一直卡在 drag。
    // 这里兜底：没有按键还停在 drag，就取消掉。
    if (layout && layout.mode === 'drag' && !bodyDragging) {
      try { body.pointer('cancel', lastPointer); } catch (e) {}
    }
    positionBalance();
    positionEatToast();
    positionTypeBox();
    if (petSettings.rememberPos && layout && !layout.moving && t > savePosAt) {
      savePosAt = t + 2000;
      const x = Math.round(layout.x);
      if (lastSavedX === null || Math.abs(x - lastSavedX) > 2) {
        lastSavedX = x;
        if (window.petHost && window.petHost.saveX) window.petHost.saveX(x).catch(() => {});
      }
    }
    if (bubbleUntil && t > bubbleUntil) {
      petBubble.classList.remove('show');
      bubbleUntil = 0;
    }
  } catch (e) {
    showError(e && e.message ? e.message : e);
  }
  requestAnimationFrame(tick);
}

// ---- 鼠标：在角色身上才接收点击，别的地方让窗口穿透 ----
addEventListener('mousemove', (e) => {
  const p = { x: e.clientX, y: e.clientY, t: performance.now() };
  lastPointer = p;
  lastButtons = e.buttons || 0;
  const onPet = !!(body && body.hit(p));
  if (bodyDragging && pressAt && Math.hypot(p.x - pressAt.x, p.y - pressAt.y) > 6) {
    pressMoved = true;
  }
  const on = onPet || bodyDragging
    || pointInRect(p, balanceRect())
    || (!typeBox.classList.contains('va-hidden')
        && pointInRect(p, typeBox.getBoundingClientRect()));
  if (on !== hover) {
    hover = on;
    if (window.petHost) window.petHost.hover(on);
  }
  if (body && (onPet || bodyDragging)) {
    try { body.pointer('move', p); } catch (err) {}
  }
});

let dragging = false, lastPt = null;
addEventListener('mousedown', (e) => {
  const p = { x: e.clientX, y: e.clientY, t: performance.now() };
  lastPointer = p;
  try { sfx.unlock(); } catch (err) {}
  const inBox = !typeBox.classList.contains('va-hidden')
    && pointInRect(p, typeBox.getBoundingClientRect());
  if (!inBox && !typeBox.classList.contains('va-hidden')) hideTypeBox();
  if (inBox || pointInRect(p, balanceRect())) return;
  if (body) {
    if (body.hit(p)) {
      bodyDragging = true;
      pressAt = p;
      pressMoved = false;
      hover = true;
      if (window.petHost) window.petHost.hover(true);
    }
    try { body.pointer('down', p); } catch (err) {}
  }
});

addEventListener('mouseup', (e) => {
  lastButtons = 0;
  if (dragging) {
    dragging = false;
    if (window.petHost) window.petHost.dragEnd();
    return;
  }
  if (body) {
    try { body.pointer('up', { x: e.clientX, y: e.clientY, t: performance.now() }); } catch (err) {}
  }
  bodyDragging = false;
  pressAt = null;
  pressMoved = false;
});

addEventListener('blur', () => {
  if (bodyDragging) {
    bodyDragging = false;
    try { body.pointer('cancel', lastPointer); } catch (e) {}
  }
  if (typeBox && !typeBox.classList.contains('va-hidden')) hideTypeBox();
});

// 双击鱼：弹出打字框（跟语音助手对话）
addEventListener('dblclick', (e) => {
  const p = { x: e.clientX, y: e.clientY };
  if (pointInRect(p, balanceRect())) return;
  if (!body || !body.hit(p)) return;
  showTypeBox();
});

addEventListener('contextmenu', (e) => {
  e.preventDefault();
  // 右键出菜单（以前是直接退出，误触一次桌宠就没了）
  if (window.petHost && window.petHost.menu) window.petHost.menu();
});

addEventListener('resize', () => {
  if (body) {
    try { body.set({ bounds: bounds() }); } catch (e) {}
  }
});

// ---- 跟着语音助手的状态走 ----
let lastState = '';
let listening = null, thinking = null;

async function poll() {
  if (debugFreeze) return;
  try {
    const r = await fetch('/status.json?t=' + Date.now(), { cache: 'no-store' });
    const s = await r.json();
    const st = String(s.state || '');
    // 只有"真听到你说话"才竖耳朵；平时别一直挂着"在听"
    // 只在真的出声时才竖耳朵（底噪也能把 state 写成 hearing，所以再看一眼电平）
    const nowListening = st === 'hearing' && Number(s.level || 0) >= 0.05;
    const nowThinking = st === 'thinking';
    if (nowListening !== listening || nowThinking !== thinking) {
      listening = nowListening;
      thinking = nowThinking;
      if (body) {
        body.set({
          listening: nowListening,
          thinking: nowThinking,
          roam: desiredRoam(),
        });
        // 思考时先站定，别一边跑一边摸下巴
        if (nowThinking) {
          try { body.do('stand'); } catch (e) {}
        }
      }
    }
    if (st && st !== lastState) {
      lastState = st;
      if (body) {
        if (st === 'sent' || st === 'copied') body.cue('cheer');
        else if (st === 'paused' || st === 'offline') body.do('sleep');
      }
      if (!speaking) {
        if (st === 'thinking') showBubble('让我想想…', 15000);
        else if (st === 'hearing') showBubble('我在听…', 2500);
        else if (st === 'sent') showBubble('发出去啦。', 1800);
        else if (st === 'paused') showBubble('语音输入暂停中。', 2500);
      }
    }
  } catch (e) {}
}

boot().catch((e) => showError(e && e.message ? e.message : e));
