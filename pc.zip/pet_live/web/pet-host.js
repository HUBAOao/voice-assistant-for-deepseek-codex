// 桌宠宿主页：把形象包装进来、每帧驱动、读语音助手的状态换表情。
import { loadBody } from './body-host.js';

const layer = document.getElementById('figureLayer');
const errBox = document.getElementById('err');
console.log('pet-host: start');
addEventListener('error', (e) => {
  console.log('pet-host: error', e.message);
});
addEventListener('unhandledrejection', (e) => {
  console.log('pet-host: rejection', String(e.reason));
});

const SCALE = 1.25;                     // 1.0 = 助手原来的大小（256 单位 × 0.42）
let floorY = innerHeight - 10;          // 脚踩在哪：默认屏幕底，之后按 x 查"下面窗口的顶边"
const bounds = () => ({ W: innerWidth, H: innerHeight, floorY, S: 0.42 * SCALE });

let body = null;
let pack = null;
// 自检用：让桌宠进入思考姿势，方便截图检查（日常不会调用）
window.__petSetThinking = (on) => {
  if (!body) return;
  body.set({ thinking: !!on, roam: on ? 'off' : 'free' });
  if (on) { try { body.do('stand'); } catch (e) {} }
};
let lastT = performance.now();
let hover = null;
let layout = null;
const bw = document.getElementById('balanceWidget');
const eatToast = document.getElementById('eatToast');
let balanceVisible = false;
let bwExpanded = false;
let prevStepAt = 0;
let speaking = false;
let eatToastUntil = 0;
let debugFreeze = false;
window.__petFreeze = (on) => { debugFreeze = !!on; };
window.__petState = () => ({ layout, bodyDragging, hover, pointer: lastPointer });
let bodyDragging = false;
let lastPointer = { x: 0, y: 0, t: 0 };
let lastButtons = 0;

function fmtMoney(value, currency) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  const sym = String(currency || '').toUpperCase() === 'USD' ? '$'
    : String(currency || '').toUpperCase() === 'CNY' ? '¥' : '';
  return sym + n.toFixed(2);
}

function fmtTokens(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(Math.round(n));
}

function clockText(ts) {
  try {
    return new Date(ts).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

function balanceRect() {
  if (!balanceVisible || !bw || bw.classList.contains('hidden')) return null;
  return bw.getBoundingClientRect();
}

function pointInRect(p, r) {
  return !!r && p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;
}

function positionBalance() {
  if (!balanceVisible || !bw || bw.classList.contains('hidden')) return;
  const box = layout && layout.box;
  const w = bw.offsetWidth || 200;
  const h = bw.offsetHeight || 90;
  let x = box ? box.x + box.w + 14 : innerWidth * 0.64;
  let y = box ? box.y + 8 : innerHeight * 0.55;
  if (x + w > innerWidth - 8) x = box ? box.x - w - 14 : innerWidth - w - 8;
  if (x < 8) x = 8;
  if (y + h > innerHeight - 8) y = innerHeight - h - 8;
  if (y < 8) y = 8;
  bw.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px)`;
}

function positionEatToast() {
  if (!eatToast || !balanceVisible) return;
  const box = layout && layout.box;
  if (!box) return;
  let x = box.x + box.w / 2;
  let y = box.y - 6;
  if (y < 54) y = box.y + box.h + 16;
  eatToast.style.left = Math.round(x) + 'px';
  eatToast.style.top = Math.round(y) + 'px';
}

function showEatToast(tokenDelta, cnyDelta, currency, totalTokens = 0) {
  if (!eatToast || !balanceVisible) return;
  const parts = [];
  if (tokenDelta > 0) {
    let label = fmtTokens(tokenDelta) + ' token';
    if (totalTokens > tokenDelta * 1.5) {
      label += '（含缓存共 ' + fmtTokens(totalTokens) + '）';
    }
    parts.push(label);
  }
  if (cnyDelta >= 0.000001) parts.push('≈' + fmtMoney(cnyDelta, currency));
  if (!parts.length) return;
  eatToast.textContent = '吃掉 ' + parts.join(' · ');
  positionEatToast();
  eatToast.classList.remove('show');
  void eatToast.offsetWidth;          // 重启动画
  eatToast.classList.add('show');
  eatToastUntil = performance.now() + 5200;
}

async function pollSpeak() {
  try {
    const r = await fetch('/speak.json?t=' + Date.now(), { cache: 'no-store' });
    const s = await r.json();
    const active = !!s.active && (Date.now() / 1000 - Number(s.ts || 0) < 6);
    if (active === speaking) return;
    speaking = active;
    if (!body) return;
    body.set({ roam: (active || motion) ? 'off' : 'free' });
    if (active) {
      try { body.do('stand'); } catch (e) {}
    }
  } catch (e) {}
}
// 自检用：直接弹一条“吃掉”提示
window.__petEatToast = (tokens, cny) =>
  showEatToast(Number(tokens) || 0, Number(cny) || 0, 'CNY');

function renderBalance(data) {
  if (!data) return;
  balanceVisible = data.enabled !== false;
  bw.classList.toggle('hidden', !balanceVisible);
  if (!balanceVisible) {
    prevStepAt = 0;
    if (eatToast) eatToast.classList.remove('show');
    return;
  }
  const bal = data.balance || {};
  const spend = data.spend || {};
  const usage = (data.usage && data.usage.tokens) || {};
  const turn = data.lastTurn || null;
  const ok = !!data.ok && bal.ok !== false && Number.isFinite(Number(bal.total));
  const mainKey = (data.settings && data.settings.mainBalance) || 'total';
  const mainValue = mainKey === 'toppedUp' ? bal.toppedUp
    : mainKey === 'granted' ? bal.granted : bal.total;
  const stepAt = turn ? Number(turn.at) || 0 : 0;
  if (ok && stepAt && prevStepAt && stepAt !== prevStepAt && Number(turn.total) > 0) {
    // 单次 = 这一条 token_count（一次模型调用）。主数字只算"新增"：
    // 未命中缓存的输入 + 输出；缓存上下文另写在括号里，免得看起来像累计。
    const input = Number(turn.input) || 0;
    const cached = Math.min(input, Number(turn.cached) || 0);
    const output = Number(turn.output) || 0;
    const fresh = Math.max(0, input - cached) + output;
    showEatToast(fresh, Number(turn.costCNY) || 0,
                 bal.currency || spend.lastCurrency, Number(turn.total) || 0);
  }
  if (stepAt) prevStepAt = stepAt;
  const dot = document.getElementById('bwDot');
  dot.className = 'bw-dot';

  if (ok) {
    document.getElementById('bwBalance').textContent = fmtMoney(mainValue, bal.currency);
    document.getElementById('bwCurrency').textContent = bal.currency || '';
    document.getElementById('bwState').textContent = clockText(data.updatedAt || Date.now());
  } else {
    document.getElementById('bwBalance').textContent =
      spend.lastBalance != null ? fmtMoney(spend.lastBalance, spend.lastCurrency) : '—';
    document.getElementById('bwCurrency').textContent = spend.lastCurrency || '';
    document.getElementById('bwState').textContent = '余额读取失败';
    dot.classList.add('bad');
  }
  const moneyOrDash = (v) => (Number.isFinite(Number(v)) ? fmtMoney(v, bal.currency) : '—');
  document.getElementById('bwBreak').textContent =
    `充值 ${moneyOrDash(bal.toppedUp)} · 赠金 ${moneyOrDash(bal.granted)}`;
  document.getElementById('bwTopped').textContent = moneyOrDash(bal.toppedUp);
  document.getElementById('bwGranted').textContent = moneyOrDash(bal.granted);
  const low = Number(data.settings && data.settings.lowBalance) || 0;
  const balanceEl = document.getElementById('bwBalance');
  balanceEl.classList.toggle('bw-bad', ok && low > 0 && Number(bal.total) <= low);

  const today = Number(spend.today);
  const todayText = Number.isFinite(today) ? fmtMoney(today, bal.currency || spend.lastCurrency) : '—';
  document.getElementById('bwToday').textContent = '今日 ' + todayText;
  const budget = Number(data.settings && data.settings.budgetToday) || 0;
  document.getElementById('bwToday').classList.toggle(
    'bw-warn', Number.isFinite(today) && budget > 0 && today >= budget);
  document.getElementById('bwTurn').textContent =
    '最近一步 ' + (turn && Number.isFinite(Number(turn.total)) ? fmtTokens(turn.total) : '—');

  const complete = usage.complete !== false;
  document.getElementById('bw7d').textContent =
    fmtTokens(usage.last7Days || usage.total || 0) + (complete ? '' : '（部分）');
  document.getElementById('bw5h').textContent = fmtTokens(usage.last5Hours || 0);
  document.getElementById('bwIo').textContent = turn
    ? `${fmtTokens(turn.input)} / ${fmtTokens(turn.output)}` : '—';
  document.getElementById('bwTotal').textContent =
    fmtMoney(spend.total || 0, bal.currency || spend.lastCurrency);
  document.getElementById('bwSource').textContent = bal.provider
    ? `${bal.provider}${bal.host ? ' · ' + bal.host : ''}`
    : (data.ok === false ? '仅本机用量' : '本机');

  const windows = Array.isArray(data.usage && data.usage.windows) ? data.usage.windows : [];
  const quotaLine = document.getElementById('bwQuotaLine');
  if (windows.length) {
    quotaLine.style.display = '';
    document.getElementById('bwQuota').textContent = windows
      .map((w) => `${w.label || ''} ${Number(w.usedPercent).toFixed(0)}%`)
      .join(' · ');
  } else {
    quotaLine.style.display = 'none';
  }
  positionBalance();
}

if (window.petHost) {
  if (window.petHost.onBalance) window.petHost.onBalance(renderBalance);
  if (window.petHost.onBalanceEnabled) {
    window.petHost.onBalanceEnabled((on) => {
      balanceVisible = !!on;
      bw.classList.toggle('hidden', !balanceVisible);
      if (balanceVisible && window.petHost.balanceGet) {
        prevStepAt = 0;
        window.petHost.balanceGet().then(renderBalance).catch(() => {});
      }
    });
  }
  if (window.petHost.onBalanceOpen) {
    window.petHost.onBalanceOpen(() => {
      balanceVisible = true;
      bw.classList.remove('hidden');
      bwExpanded = true;
      bw.classList.add('expanded');
      positionBalance();
    });
  }
}

if (bw) {
  bw.addEventListener('click', (e) => {
    if (e.target && e.target.closest && e.target.closest('button')) return;
    e.stopPropagation();
    bwExpanded = !bwExpanded;
    bw.classList.toggle('expanded', bwExpanded);
    positionBalance();
  });
  bw.addEventListener('mousedown', (e) => e.stopPropagation());
  const btn = (id, fn) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', (e) => {
      e.stopPropagation();
      try { fn(); } catch (err) {}
    });
  };
  btn('bwRefresh', () => window.petHost && window.petHost.balanceRefresh
    && window.petHost.balanceRefresh().then(renderBalance).catch(() => {}));
  btn('bwSet', () => window.petHost && window.petHost.balanceOpenSettings
    && window.petHost.balanceOpenSettings());
  btn('bwHide', () => window.petHost && window.petHost.balanceSetEnabled
    && window.petHost.balanceSetEnabled(false));
}
// 自检用：把状态写进 <html data-pet="...">（executeJavaScript 的上下文读得到）
setInterval(() => {
  document.documentElement.dataset.pet = JSON.stringify({
    ready: !!body,
    mode: layout ? layout.mode : '',
    box: layout ? layout.box : null,
    floorY,
    frames: document.querySelectorAll('iframe').length,
    err: errBox.textContent,
  });
}, 500);

function showError(msg) {
  errBox.style.display = 'block';
  errBox.textContent = String(msg).slice(0, 240);
}

// ---- 声音：形象包自带的小音效 ----
function playSound(name) {
  try {
    const s = pack && pack.sounds && pack.sounds[name];
    if (!s) return;
    const a = new Audio(pack.base + s.file);
    a.volume = Math.min(1, 0.35 * (s.volume == null ? 1 : s.volume));
    a.play().catch(() => {});
  } catch (e) {}
}

async function boot() {
  const packs = await (await fetch('/packs.json', { cache: 'no-store' })).json();
  console.log('pet-host: packs', Array.isArray(packs) ? packs.length : typeof packs);
  pack = (Array.isArray(packs) ? packs : []).find((p) => p.id === 'whale') || packs[0];
  if (!pack) throw new Error('没读到形象包');
  await refreshSurface(true);           // 先问一次地面，别从半空掉下来
  body = await loadBody({
    layer,
    pack,
    theme: 'dark',
    bounds: bounds(),
    start: {
      x: innerWidth * 0.62,
      facing: 1,
      enter: 'drop',
      skin: { figure: 'whale', scheme: 'deepseek', outfit: 'maid' },
      scheme: 'deepseek',
    },
    onEvent: (kind) => { if (kind === 'touch') playSound('pat'); },
    onSound: (name) => playSound(name),
    onError: (e) => showError(e && e.message ? e.message : e),
  });
  body.set({ roam: true, bounds: bounds() });   // 自己会走动（原作本来就有的功能）
  requestAnimationFrame(tick);
  if (window.petHost && window.petHost.balanceGet) {
    window.petHost.balanceGet().then(renderBalance).catch(() => {});
  }
  setInterval(poll, 300);
  setInterval(pollSpeak, 250);
  setInterval(() => refreshSurface(false), 400);
}

// ---- 地面：按它当前 x 找"脚下的窗沿"和"上面能爬的窗沿" ----
let floorBusy = false;
let motion = null;                  // 'fall' | 'climb'
let motionFrom = 0, motionTo = 0, motionStart = 0, motionDur = 0;
let floorSettledAt = performance.now() + 2000;
let climbCooldownUntil = performance.now() + 3000;

function setFloor(y) {
  floorY = Number(y);
  if (body) body.set({ bounds: bounds() });
}

function beginFall(target) {
  motion = 'fall';
  motionFrom = floorY;
  motionTo = target;
  motionStart = performance.now();
  motionDur = Math.min(520, 240 + Math.abs(target - floorY) * 0.55);
  if (body) {
    body.set({ roam: 'off' });
    body.do('surprised');
  }
}

function beginClimb(target) {
  motion = 'climb';
  motionFrom = floorY;
  motionTo = target;
  motionStart = performance.now();
  motionDur = Math.min(1800, 520 + Math.abs(target - floorY) * 0.9);
  if (body) {
    body.set({ roam: 'off' });
    body.do('stand');
    body.do('climbing');
  }
}

function updateMotion(now) {
  if (!motion) return;
  const p = Math.min(1, Math.max(0, (now - motionStart) / motionDur));
  const e = motion === 'climb' ? p * p * (3 - 2 * p) : p * p;
  floorY = motionFrom + (motionTo - motionFrom) * e;
  if (body) body.set({ bounds: bounds() });
  if (p >= 1) {
    const kind = motion;
    motion = null;
    floorY = motionTo;
    floorSettledAt = now;
    climbCooldownUntil = now + 6000;
    if (body) {
      body.set({ roam: speaking ? 'off' : 'free', bounds: bounds() });
      body.do(kind === 'climb' ? 'happy' : 'neutral');
    }
  }
}

async function refreshSurface(force) {
  if (!window.petHost || !window.petHost.surface || floorBusy || motion || bodyDragging) return;
  const box = layout && layout.box;
  const x = Math.round(layout ? layout.x : innerWidth * 0.62);
  const feet = Math.round(box ? box.y + box.h : innerHeight - 10);
  floorBusy = true;
  try {
    const s = await window.petHost.surface(x, feet);
    if (!s || !Number.isFinite(Number(s.floor))) return;
    const nf = Number(s.floor);
    if (force) {
      setFloor(nf);
      floorSettledAt = performance.now();
      return;
    }
    if (Math.abs(nf - floorY) > 2) {
      if (nf > floorY + 6) {
        beginFall(nf);                  // 从窗口上走下来：落下去
      } else {
        setFloor(nf);                   // 地面自己升高（窗口移动）：先跟上
        floorSettledAt = performance.now();
      }
    } else if (s.climb && performance.now() > climbCooldownUntil
               && performance.now() > floorSettledAt + 1200
               && !(layout && layout.busy)) {
      const cy = Number(s.climb.y);
      if (Number.isFinite(cy) && floorY - cy > 24) {
        beginClimb(cy);                 // 自己爬到上面的窗沿
      }
    }
  } catch (e) {
  } finally {
    floorBusy = false;
  }
}

function tick(t) {
  const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000));
  lastT = t;
  try {
    updateMotion(t);
    if (speaking && body) {
      try { body.talk(); } catch (e) {}
    }
    body.tick(dt);
    layout = body.layout;
    // 以前鼠标一离开角色的像素，窗口就变穿透，mouseup 收不到 → 一直卡在 drag。
    // 这里兜底：没有按键还停在 drag，就取消掉。
    if (layout && layout.mode === 'drag' && !bodyDragging) {
      try { body.pointer('cancel', lastPointer); } catch (e) {}
    }
    positionBalance();
    positionEatToast();
  } catch (e) {
    showError(e && e.message ? e.message : e);
  }
  requestAnimationFrame(tick);
}

// ---- 鼠标：在角色身上才接收点击，别的地方让窗口穿透 ----
addEventListener('mousemove', (e) => {
  const p = { x: e.clientX, y: e.clientY, t: performance.now() };
  lastPointer = p;
  lastButtons = e.buttons || 0;
  const onPet = !!(body && body.hit(p));
  const on = onPet || bodyDragging || pointInRect(p, balanceRect());
  if (on !== hover) {
    hover = on;
    if (window.petHost) window.petHost.hover(on);
  }
  if (body && (onPet || bodyDragging)) {
    try { body.pointer('move', p); } catch (err) {}
  }
});

let dragging = false, lastPt = null;
addEventListener('mousedown', (e) => {
  const p = { x: e.clientX, y: e.clientY, t: performance.now() };
  lastPointer = p;
  if (pointInRect(p, balanceRect())) return;
  if (body) {
    if (body.hit(p)) {
      bodyDragging = true;
      hover = true;
      if (window.petHost) window.petHost.hover(true);
    }
    try { body.pointer('down', p); } catch (err) {}
  }
});

addEventListener('mouseup', (e) => {
  lastButtons = 0;
  if (dragging) {
    dragging = false;
    if (window.petHost) window.petHost.dragEnd();
    return;
  }
  if (body) {
    try { body.pointer('up', { x: e.clientX, y: e.clientY, t: performance.now() }); } catch (err) {}
  }
  bodyDragging = false;
});

addEventListener('blur', () => {
  if (bodyDragging) {
    bodyDragging = false;
    try { body.pointer('cancel', lastPointer); } catch (e) {}
  }
});

// 双击：换个花样（跳舞/挥手/转圈…）
const FUN = ['dance', 'wave', 'spin', 'hop', 'nod', 'shiver', 'flap', 'bow'];
addEventListener('dblclick', (e) => {
  if (pointInRect({ x: e.clientX, y: e.clientY }, balanceRect())) return;
  if (!body) return;
  try { body.do(FUN[Math.floor(Math.random() * FUN.length)]); } catch (e) {}
});

addEventListener('contextmenu', (e) => {
  e.preventDefault();
  // 右键出菜单（以前是直接退出，误触一次桌宠就没了）
  if (window.petHost && window.petHost.menu) window.petHost.menu();
});

addEventListener('resize', () => {
  if (body) {
    try { body.set({ bounds: bounds() }); } catch (e) {}
  }
});

// ---- 跟着语音助手的状态走 ----
let lastState = '';
let listening = null, thinking = null;

async function poll() {
  if (debugFreeze) return;
  try {
    const r = await fetch('/status.json?t=' + Date.now(), { cache: 'no-store' });
    const s = await r.json();
    const st = String(s.state || '');
    // 只有"真听到你说话"才竖耳朵；平时别一直挂着"在听"
    // 只在真的出声时才竖耳朵（底噪也能把 state 写成 hearing，所以再看一眼电平）
    const nowListening = st === 'hearing' && Number(s.level || 0) >= 0.05;
    const nowThinking = st === 'thinking';
    if (nowListening !== listening || nowThinking !== thinking) {
      listening = nowListening;
      thinking = nowThinking;
      if (body) {
        body.set({
          listening: nowListening,
          thinking: nowThinking,
          roam: nowThinking ? 'off' : 'free',
        });
        // 思考时先站定，别一边跑一边摸下巴
        if (nowThinking) {
          try { body.do('stand'); } catch (e) {}
        }
      }
    }
    if (st && st !== lastState) {
      lastState = st;
      if (body) {
        if (st === 'sent' || st === 'copied') body.cue('cheer');
        else if (st === 'paused' || st === 'offline') body.do('sleep');
      }
    }
  } catch (e) {}
}

boot().catch((e) => showError(e && e.message ? e.message : e));
