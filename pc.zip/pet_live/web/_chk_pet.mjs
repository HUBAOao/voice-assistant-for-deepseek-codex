// 桌宠宿主页：把形象包装进来、每帧驱动、读语音助手的状态换表情。
import { loadBody, readLayout, onBody } from './body-host.js';

const layer = document.getElementById('figureLayer');
const errBox = document.getElementById('err');
console.log('pet-host: start');
addEventListener('error', (e) => {
  console.log('pet-host: error', e.message);
});
addEventListener('unhandledrejection', (e) => {
  console.log('pet-host: rejection', String(e.reason));
});

const SCALE = 1.25;                     // 1.0 = 助手原来的大小（256 单位 × 0.42）
const bounds = () => ({
  W: innerWidth,
  H: innerHeight,
  floorY: innerHeight - 10,
  S: 0.42 * SCALE,
});

let body = null;
let lastT = performance.now();
let hover = null;
let layout = null;

function showError(msg) {
  errBox.style.display = 'block';
  errBox.textContent = String(msg).slice(0, 240);
}

async function boot() {
  const packs = await (await fetch('/packs.json', { cache: 'no-store' })).json();
  console.log('pet-host: packs', Array.isArray(packs) ? packs.length : typeof packs);
  const pack = (Array.isArray(packs) ? packs : []).find((p) => p.id === 'whale') || packs[0];
  if (!pack) throw new Error('没读到形象包');
  body = await loadBody({
    layer,
    pack,
    theme: 'dark',
    bounds: bounds(),
    start: {
      x: innerWidth * 0.5,
      facing: 1,
      enter: 'drop',
      skin: { figure: 'whale', scheme: 'deepseek', outfit: 'maid' },
      scheme: 'deepseek',
    },
    onEvent: () => {},
    onSound: () => {},
    onError: (e) => showError(e && e.message ? e.message : e),
  });
  requestAnimationFrame(tick);
  setInterval(poll, 350);
}

function tick(t) {
  const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000));
  lastT = t;
  try {
    body.step(dt);
    layout = body.layout();
  } catch (e) {
    showError(e && e.message ? e.message : e);
  }
  requestAnimationFrame(tick);
}

// ---- 鼠标：在角色身上才接收点击，别的地方让窗口穿透 ----
addEventListener('mousemove', (e) => {
  const p = { x: e.clientX, y: e.clientY };
  const on = !!(layout && onBody(layout, p));
  if (on !== hover) {
    hover = on;
    if (window.petHost) window.petHost.hover(on);
  }
  if (body) {
    try { body.pointer('move', p); } catch (err) {}
  }
});

let dragging = false, lastPt = null;
addEventListener('mousedown', (e) => {
  const p = { x: e.clientX, y: e.clientY };
  if (e.altKey && window.petHost) {          // 按住 Alt 拖动整个窗口
    dragging = true;
    lastPt = { x: e.screenX, y: e.screenY };
    window.petHost.dragStart();
    e.preventDefault();
    return;
  }
  if (body) {
    try { body.pointer('down', p); } catch (err) {}
  }
});

addEventListener('mouseup', (e) => {
  if (dragging) {
    dragging = false;
    if (window.petHost) window.petHost.dragEnd();
    return;
  }
  if (body) {
    try { body.pointer('up', { x: e.clientX, y: e.clientY }); } catch (err) {}
  }
});

addEventListener('mousemove', (e) => {
  if (!dragging || !lastPt || !window.petHost) return;
  const dx = e.screenX - lastPt.x;
  const dy = e.screenY - lastPt.y;
  lastPt = { x: e.screenX, y: e.screenY };
  window.petHost.dragMove(dx, dy);
});

addEventListener('contextmenu', (e) => {
  e.preventDefault();
  if (window.petHost) window.petHost.close();
});

addEventListener('resize', () => {
  if (body) {
    try { body.set({ bounds: bounds() }); } catch (e) {}
  }
});

// ---- 跟着语音助手的状态走 ----
let lastState = '';
let listening = null, thinking = null;

async function poll() {
  try {
    const r = await fetch('/status.json?t=' + Date.now(), { cache: 'no-store' });
    const s = await r.json();
    const st = String(s.state || '');
    const nowListening = st === 'listening' || st === 'hearing';
    const nowThinking = st === 'thinking';
    if (nowListening !== listening || nowThinking !== thinking) {
      listening = nowListening;
      thinking = nowThinking;
      if (body) body.set({ listening: nowListening, thinking: nowThinking });
    }
    if (st && st !== lastState) {
      lastState = st;
      if (body) {
        if (st === 'sent' || st === 'copied') body.cue('cheer');
        else if (st === 'paused' || st === 'offline') body.do('sleep');
      }
    }
  } catch (e) {}
}

boot().catch((e) => showError(e && e.message ? e.message : e));
