#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把一段文字用语音念出来（给 AI 的回答配音）。

    python say.py "你好，这是要念的内容"
    echo "从管道读也行" | python say.py
    python say.py --list-voices
    python say.py --sapi "没网的时候用系统自带音色"

优先用 edge-tts（微软在线音色，自然）；没网或失败就退回系统自带 SAPI 音色。
"""

from __future__ import annotations

import argparse
import asyncio
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import json as _json

SPEAK_STATUS = Path(__file__).resolve().parent / "speak.json"
SPEAK_STOP = Path(__file__).resolve().parent / "speak_stop.json"
SPEAK_REFERENCE = Path(__file__).resolve().parent / "speak_reference.npy"
SPEAK_REFERENCE_META = Path(__file__).resolve().parent / "speak_reference.json"


def publish_speaking(active: bool, level: float = 0.0, text: str = "",
                     progress: float = 0.0) -> None:
    """把"我正在说话"、当前音量、念到哪儿了写给悬浮窗。

    悬浮窗拿 text + progress 画"逐字跟读"：前面 progress 那部分字高亮。
    """
    try:
        SPEAK_STATUS.write_text(
            _json.dumps({"active": bool(active), "level": round(min(1.0, level), 3),
                         "text": text, "progress": round(min(1.0, max(0.0, progress)), 3),
                         "ts": time.time()}, ensure_ascii=False),
            encoding="utf-8")
    except Exception:
        pass


def stop_requested(after: float) -> bool:
    """主程序写了 speak_stop.json（比开始念还新）就表示"闭嘴"。"""
    try:
        return SPEAK_STOP.stat().st_mtime > after
    except OSError:
        return False


def _atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def publish_reference(audio: np.ndarray, sample_rate: int, text: str = "",
                      offset: int = 0, active: bool = True) -> None:
    """Publish the exact playback waveform for microphone echo cancellation."""
    try:
        if active:
            tmp = SPEAK_REFERENCE.with_name(SPEAK_REFERENCE.name + ".tmp")
            with tmp.open("wb") as handle:
                np.save(handle, np.asarray(audio, dtype=np.float32).reshape(-1),
                        allow_pickle=False)
            os.replace(tmp, SPEAK_REFERENCE)
        meta = {
            "active": bool(active),
            "rate": int(sample_rate),
            "samples": int(np.asarray(audio).size),
            "offset": max(0, int(offset)),
            "text": str(text or ""),
            "ts": time.time(),
        }
        _atomic_write(SPEAK_REFERENCE_META,
                      json.dumps(meta, ensure_ascii=False).encode("utf-8"))
    except Exception:
        pass

HERE = Path(__file__).resolve().parent


def _config() -> dict:
    path = HERE / "config.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:  # noqa: BLE001
            pass
    return {}


_CFG = _config()
DEFAULT_VOICE = os.environ.get("STT_SPEAK_VOICE") or _CFG.get("voice") or "zh-CN-XiaoxiaoNeural"
EDGE_RATE = os.environ.get("STT_SPEAK_EDGE_RATE") or _CFG.get("rate") or "+8%"
DEFAULT_VOLUME = int(_CFG.get("volume") or 80)
_out_dev = _CFG.get("output_device")
DEFAULT_DEVICE = str(_out_dev) if _out_dev not in (None, "") else None
# 音色预设里带的变调和特效（设置 → 声音 → 音色，比如"机器人""卡通高音"）
DEFAULT_PITCH = str(_CFG.get("voice_pitch") or "")
DEFAULT_FX = str(_CFG.get("voice_fx") or "")


def setup_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def clean_for_speech(text: str) -> str:
    """把 Markdown、代码、链接这些念出来很怪的东西去掉。"""
    text = re.sub(r"```.*?```", " 代码块略过 ", text, flags=re.S)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text)          # 图片
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)        # 链接只念文字
    text = re.sub(r"https?://\S+", " 链接 ", text)
    text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.M)   # 标题
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.M)        # 列表符号
    text = re.sub(r"^\s*\d+[.、)]\s+", "", text, flags=re.M)
    text = re.sub(r"^\s*>\s?", "", text, flags=re.M)            # 引用
    text = text.replace("**", "").replace("__", "").replace("*", "").replace("~~", "")
    text = re.sub(r"^\s*\|.*\|\s*$", "", text, flags=re.M)      # 表格行
    text = re.sub(r"^\s*[-—=]{3,}\s*$", "", text, flags=re.M)
    # 这些符号 GPT-SoVITS 的中文前端会报 400（实测 ¥ / ≈ 会把整段打回旧音色）
    text = re.sub(r"[¥￥]\s*([0-9]+(?:\.[0-9]+)?)", r"\1元", text)
    text = text.replace("¥", "元").replace("￥", "元").replace("≈", "大约")
    text = re.sub(r"[\U0001F300-\U0001FAFF\u2600-\u27BF\uFE0F]", "", text)  # emoji
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "。", text)
    return text.strip()


def split_chunks(text: str, limit: int = 90) -> list[str]:
    """按句号切段。段大一点、少几次网络往返，句子之间就不会空太久。"""
    limit = max(80, limit)
    parts = re.split(r"(?<=[。！？!?；;\n])", text)
    chunks: list[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        while len(part) > limit:
            chunks.append(part[:limit])
            part = part[limit:]
        if part:
            chunks.append(part)
    return chunks or [text]


# ------------------------------------------------------------------ 在线音色

async def _edge_bytes(text: str, voice: str, rate: str, pitch: str = "") -> bytes:
    import edge_tts

    tts = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch or "+0Hz")
    buf = bytearray()
    try:
        async for chunk in tts.stream():
            if chunk["type"] == "audio":
                buf.extend(chunk["data"])
    except Exception:
        # 网络中途断掉时，已经收到的音频still能播；实在一句都没有就让上层退回系统音色
        if not buf:
            raise
    return bytes(buf)


def edge_mp3(text: str, voice: str, rate: str) -> bytes:
    try:
        data = asyncio.run(_edge_bytes(text, voice, rate, pitch=PITCH[0]))
    except Exception:
        data = b""
    if not data:                      # 一句都没拿到 → 让调用方退回系统音色
        raise RuntimeError("在线音色没取到音频")
    return data


def baidu_mp3(text: str, rate: str = "+0%") -> bytes:
    """备用的在线音色：百度翻译那个免费朗读口（国内直连、不用登录、不用加速器）。

    为什么加它：微软的 edge 朗读接口现在对第三方客户端一律 403（我们路由都绕开了直连它
    还是拒），用户原来的"小伊/晓晓"那批在线音色就全哑了。百度这个口子还能用，
    女声、自然度够，而且不挑网络。
    """
    import urllib.parse as _up
    import urllib.request as _ur

    spd = 5
    try:
        pct = int(str(rate).replace("%", "").replace("+", "") or 0)
        spd = max(1, min(9, int(round(5 + pct / 25.0))))
    except Exception:
        pass
    url = ("https://fanyi.baidu.com/gettts?lan=zh&spd=%d&source=web&text=" % spd
           + _up.quote((text or "")[:900]))
    req = _ur.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131",
        "Referer": "https://fanyi.baidu.com/"})
    data = _ur.urlopen(req, timeout=25).read()
    if len(data) < 500:
        raise RuntimeError("百度那边没给音频")
    return data


# 变声：音调（edge-tts 自己支持，单位 Hz，例如 "+30Hz" 就是卡通高音、"-25Hz" 就是闷低音）
PITCH: list[str] = [""]
FX: list[str] = [""]


def apply_fx(audio: np.ndarray, sr: int, name: str) -> np.ndarray:
    """给声音加点味儿：robot=电子机器人、echo=山谷回音、radio=老电台。

    为什么这么做：曼波/奶龙/高松灯那些是**特定人物的音源**，微软免费语音库里没有；
    但用"换音色 + 变调 + 加点特效"，能做出那种味道（不是原版音源，我不会冒充）。
    """
    if not name or not audio.size:
        return audio
    try:
        t = np.arange(audio.size) / float(sr)
        if name == "robot":
            # 环形调制 + 轻微比特压缩：经典"电子音"
            audio = audio * (0.55 + 0.45 * np.cos(2 * np.pi * 42.0 * t))
            audio = np.round(audio * np.float32(9.0)) / np.float32(9.0)
        elif name == "echo":
            delay = int(sr * 0.16)
            out = audio.copy()
            if audio.size > delay:
                out[delay:] += audio[:-delay] * np.float32(0.32)
            audio = out / max(1.0, float(np.max(np.abs(out)) or 1.0))
        elif name == "radio":
            audio = np.tanh(audio * np.float32(2.2)) * np.float32(0.9)   # 压得扁一点
            hiss = (np.random.rand(audio.size).astype(np.float32) - 0.5) * np.float32(0.012)
            audio = audio + hiss
        peak = float(np.max(np.abs(audio)) or 1.0)
        if peak > 1.0:
            audio = audio / peak
    except Exception:
        pass
    return audio


def decode_audio(data: bytes) -> tuple[np.ndarray, int]:
    """MP3/WAV 字节流 -> (float32 单声道, 采样率)。"""
    import av

    with av.open(io.BytesIO(data)) as container:
        stream = next(s for s in container.streams if s.type == "audio")
        sr = 24000
        resampler = av.AudioResampler(format="s16", layout="mono", rate=sr)
        blocks: list[np.ndarray] = []
        for frame in container.decode(stream):
            for out in resampler.resample(frame):
                blocks.append(out.to_ndarray())
        for out in resampler.resample(None):
            blocks.append(out.to_ndarray())
    if not blocks:
        return np.zeros(0, dtype=np.float32), sr
    audio = np.concatenate([b.reshape(-1) for b in blocks]).astype(np.float32) / 32768.0
    return audio, sr


def read_wav(path) -> tuple[np.ndarray, int]:
    """读一个 16bit wav（克隆音色那边吐出来的就是这个格式）。"""
    import wave

    with wave.open(str(path), "rb") as w:
        sr, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
        raw = w.readframes(n)
    audio = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    if ch > 1:
        audio = audio.reshape(-1, ch).mean(axis=1)
    return audio, sr


def is_clone(voice: str) -> bool:
    return str(voice or "").startswith("clone:")


# ---------------------------------------------------------------- 本地克隆音（GPT-SoVITS）
# 用 B 站那条「大肥鱼声线」视频里截出来的 7.4 秒当参考，本机 GPT-SoVITS 直接念。
TTS_URL = "http://127.0.0.1:9880/tts"
TS_DIR = Path(r"F:\voice-clone")
TS_REF = TS_DIR / "dfy-voice" / "ref_raw2.wav"      # 没去伴奏那版：音高和原声最贴（313Hz vs 310Hz）
TS_PROMPT = "哈哈，克隆大肥鱼声线，取得小阶段胜利。我是在网络上抽卡抽到自己想要的声线卡。"
_TS_SERVER = {"proc": None, "warmed": False}
_TS_LOCK = __import__("threading").Lock()   # 同一时刻只允许一路去合成，免得并发把服务打崩

# 克隆声线对个别词会咬不准（实测「记事本」总被念成「计时本」）。
# 只在“送去合成”的文字里换成同义、发音稳定的说法；屏幕上的原文和字幕不动。
SPEECH_FIXES = (("记事本", "文本编辑器"),)


def fix_speech(text: str) -> str:
    for old, new in SPEECH_FIXES:
        text = text.replace(old, new)
    return text


def is_ts_voice(voice: str) -> bool:
    return str(voice or "").startswith("dfy:")


def _tts_port_open() -> bool:
    import socket

    s = socket.socket()
    s.settimeout(0.4)
    try:
        return s.connect_ex(("127.0.0.1", 9880)) == 0
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def ensure_tts_server(wait: float = 150.0) -> bool:
    """GPT-SoVITS 没起来就拉起来（第一次要 30~60 秒加载模型）。"""
    if _tts_port_open():
        return True
    exe = TS_DIR / "env" / "Scripts" / "python.exe"
    root = TS_DIR / "gpt-sovits" / "GPT-SoVITS"
    if not exe.exists() or not (root / "api_v2.py").exists():
        return False
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        _TS_SERVER["proc"] = subprocess.Popen(
            [str(exe), "api_v2.py", "-a", "127.0.0.1", "-p", "9880",
             "-c", "GPT_SoVITS/configs/tts_infer.yaml"],
            cwd=str(root), creationflags=flags,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("  （正在启动本地克隆音服务，第一次要几十秒…）", file=sys.stderr)
    except Exception:
        return False
    t0 = time.time()
    while time.time() - t0 < wait:
        if _tts_port_open():
            return True
        time.sleep(0.5)
    return False


def ts_audio(text: str, voice: str, rate: str) -> tuple[np.ndarray, int] | None:
    """用本机 GPT-SoVITS 念一句（大肥鱼声线）。失败返回 None，调用方退回原声。"""
    with _TS_LOCK:
        return _ts_audio_locked(text, voice, rate)


def _ts_audio_locked(text: str, voice: str, rate: str) -> tuple[np.ndarray, int] | None:
    if not TS_REF.exists() or not ensure_tts_server():
        return None
    text = fix_speech(text)
    speed = 1.0
    try:
        pct = int(str(rate).replace("%", "").replace("+", "") or 0)
        speed = max(0.7, min(1.3, 1.0 + pct / 100.0))
    except Exception:
        pass
    if not _TS_SERVER["warmed"]:
        # 第一次用：确保挂的是 v4（零样本音色还原比 v2 强一大截：0.75 → 0.88）
        try:
            import urllib.parse as _up
            import urllib.request as _ur

            for _ep, _wp in (
                ("set_gpt_weights", "GPT_SoVITS/pretrained_models/s1v3.ckpt"),
                ("set_sovits_weights",
                 "GPT_SoVITS/pretrained_models/gsv-v4-pretrained/s2Gv4.pth"),
            ):
                _u = ("http://127.0.0.1:9880/" + _ep + "?"
                      + _up.urlencode({"weights_path": _wp}))
                try:
                    _ur.urlopen(_ur.Request(_u, headers={"User-Agent": "voice-assistant"}),
                                timeout=300).read()
                except Exception:
                    pass
            _TS_SERVER["warmed"] = True
        except Exception:
            pass
    payload = {
        "text": text, "text_lang": "zh", "ref_audio_path": str(TS_REF),
        "prompt_text": TS_PROMPT, "prompt_lang": "zh",
        "text_split_method": "cut5", "batch_size": 1, "media_type": "wav",
        "streaming_mode": False, "seed": 42, "top_k": 10, "top_p": 1.0,
        "temperature": 0.8, "speed_factor": speed, "repetition_penalty": 1.35,
    }
    # 用标准库，不依赖 requests（项目 venv 里没装它，之前就是因为这个一直悄悄退回老音色）
    import json as _json
    import urllib.request as _ur

    last_err = None
    for attempt in range(3):              # 合成失败重试两次，尽量别退回别的音色
        try:
            _req = _ur.Request(
                TTS_URL,
                data=_json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json",
                         "User-Agent": "voice-assistant"},
                method="POST")
            with _ur.urlopen(_req, timeout=600) as _resp:
                raw = _resp.read()
            if not raw:
                raise RuntimeError("空音频")
            polished = polish_wav(raw)
            if polished is not None:
                return polished
            # 用项目里本来就有的 PyAV 解码（不能依赖 soundfile —— venv 里没装）
            return decode_audio(raw)
        except Exception as exc:                               # noqa: BLE001
            last_err = exc
            if attempt < 2:
                time.sleep(0.6 * (attempt + 1))
    print(f"  （克隆音连续 3 次没念出来：{last_err}）", file=sys.stderr)
    # 记一笔，方便事后查"为什么这一段换了声音"（pythonw 下 stderr 看不到）
    try:
        with (HERE / "say-errors.log").open("a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {text[:60]!r} -> {last_err}\n")
    except Exception:
        pass
    return None


# 音质打磨：掐掉 60Hz 以下的轰鸣、补一点 3.2kHz 的清晰度、压掉 180Hz 的闷、最后限幅到 0.9。
# 实测：频谱重心 2631Hz → 2779Hz（原声 2841Hz，更贴），底噪几乎不变。
POLISH_CHAIN = ("highpass=f=60,"
                "equalizer=f=3200:t=q:w=1.3:g=1.6,"
                "equalizer=f=180:t=q:w=1.0:g=-1.0,"
                "alimiter=limit=0.9:level=disabled")


def _ffmpeg_exe() -> str:
    import shutil as _sh

    cands = [_sh.which("ffmpeg") or "",
             r"C:\Users\HuBao\AppData\Local\Microsoft\WinGet\Packages"
             r"\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe"
             r"\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"]
    for c in cands:
        try:
            if c and Path(c).exists():
                return c
        except Exception:
            pass
    return ""


def polish_wav(raw: bytes) -> tuple[np.ndarray, int] | None:
    """给克隆音做一道轻量音质处理；失败就返回 None（上层用原样音频）。"""
    ff = _ffmpeg_exe()
    if not ff:
        return None
    try:
        d = Path(tempfile.gettempdir())
        src = d / "stt_ts_in.wav"
        dst = d / "stt_ts_out.wav"
        src.write_bytes(raw)
        flags = 0x08000000 if os.name == "nt" else 0
        subprocess.run([ff, "-hide_banner", "-loglevel", "error", "-y",
                        "-i", str(src), "-af", POLISH_CHAIN, "-ar", "48000", str(dst)],
                       check=True, creationflags=flags)
        out = read_wav(dst)
        try:
            src.unlink(missing_ok=True)
            dst.unlink(missing_ok=True)
        except Exception:
            pass
        return out
    except Exception:
        return None


def clone_audio(text: str, voice: str, rate: str) -> tuple[np.ndarray, int] | None:
    """克隆音色：先用在线音色念一句打底，再让本机的 RVC 把它换成那个嗓子。

    这台机器上没装克隆环境（或者那个模型没了）就返回 None，调用方退回原声。
    """
    try:
        import clone_voice
    except Exception:
        return None
    if not clone_voice.available():
        return None
    # 打底优先用在线音色；在线被拒（微软 403 / 没网）就改用本地 piper 打底 ——
    # 这样"克隆音色"完全离线也能出声音（用户原来卡在这：一断在线就只能听老系统音色）。
    try:
        mp3 = edge_mp3(text, clone_voice.BASE_VOICE, rate)
    except Exception:
        mp3 = b""
    if mp3:
        ok, out, why = clone_voice.synth_to_wav(mp3, voice)
    else:
        tmpdir = Path(tempfile.gettempdir())
        base = tmpdir / "stt_clone_base.wav"
        dst = tmpdir / "stt_clone_out.wav"
        if not piper_to_wav(text, base):
            return None
        ok2, why = clone_voice.convert(base, dst, voice)
        ok, out = bool(ok2), dst
    if not ok:
        print(f"  （克隆音色没换成，先用原声：{why}）", file=sys.stderr)
        return None
    try:
        return read_wav(out)
    finally:
        try:
            Path(out).unlink(missing_ok=True)
        except Exception:
            pass


def play(audio: np.ndarray, sr: int, device=None, caption: str = "",
         span: tuple[float, float] = (0.0, 1.0)) -> bool:
    """放一段音频；中途发现"闭嘴"就立刻停，返回 False。"""
    if not audio.size:
        return True
    # 边播边把音量发出去（悬浮窗拿它做"说话时"的动画）
    block = max(256, int(sr * 0.05))
    started = time.time()
    finished = True
    publish_reference(audio, sr, caption, offset=0, active=True)
    try:
        with sd.OutputStream(samplerate=sr, channels=1, dtype="float32",
                             device=device) as stream:
            for i in range(0, audio.size, block):
                if stop_requested(started):
                    finished = False
                    break
                chunk = np.asarray(audio[i:i + block], dtype="float32")
                stream.write(chunk.reshape(-1, 1))
                rms = float(np.sqrt(np.mean(chunk ** 2) + 1e-9))
                done = (i + chunk.size) / audio.size
                publish_speaking(True, min(1.0, rms * 3.6), text=caption,
                                 progress=span[0] + (span[1] - span[0]) * done)
                publish_reference(audio, sr, caption, offset=i, active=True)
    except Exception:
        # 实时流打不开就退回普通播放，别把话说丢了
        sd.play(audio, sr, device=device)
        sd.wait()
    finally:
        # 保留下最后念的那句：主程序要靠它判断"这句是不是我自己在念"
        publish_speaking(False, 0.0, text=caption)
        publish_reference(audio, sr, caption, offset=audio.size, active=False)
    return finished


_MUTEX_HANDLE = None            # 故意存在模块级：握到进程结束，别让句柄被回收


def wait_turn(timeout: float = 180.0) -> bool:
    """同一时间只让一个朗读进程出声。

    以前这里只是"问一下锁在不在"：拿到句柄的函数一返回，句柄就被回收、锁也放了，
    于是两个 say.py 还是**同时在出声**（用户反复反馈"语音会重叠"就是这个原因）。
    现在把句柄留在模块级变量里 —— 一直握到本进程结束（退出时系统自动释放），
    后面的朗读进程会在 WaitForSingleObject 上老老实实排队。
    超时给 180 秒：够念完一长段回答，又不至于被一个卡死的进程永远堵住。
    """
    global _MUTEX_HANDLE
    if os.name != "nt":
        return True
    import ctypes

    k = ctypes.windll.kernel32
    k.CreateMutexW.restype = ctypes.c_void_p
    k.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    handle = k.CreateMutexW(None, False, "VoiceAssistantSpeak_v1")
    if not handle:
        return True
    _MUTEX_HANDLE = handle          # 关键：留着不放
    res = k.WaitForSingleObject(handle, int(timeout * 1000))
    return res in (0x0, 0x80)       # WAIT_OBJECT_0 / WAIT_ABANDONED


# ------------------------------------------------------- 离线音色（系统自带）

# ---- 本地神经网络音色（piper）：完全离线，不靠微软服务器 ----
# 为什么加它：edge-tts（在线）走的是 speech.platform.bing.com，被加速器带到美国机房后
# 微软直接 403 拒掉 → 只能退回系统那个老音色（用户听到的"音色变了"就是这个）。
# piper 的模型文件放在程序目录 piper-voices\ 下，永远能用。
PIPER_DIR = HERE / "piper-voices"
_PIPER: dict = {"voice": None, "tried": False}


def _piper_voice():
    if _PIPER["tried"]:
        return _PIPER["voice"]
    _PIPER["tried"] = True
    try:
        from piper import PiperVoice

        cands = sorted(str(p) for p in PIPER_DIR.glob("*.onnx"))
        if not cands:
            return None
        # 优先 medium（音质好），没有就随便挑一个
        pick = next((c for c in cands if "medium" in c), cands[0])
        _PIPER["voice"] = PiperVoice.load(pick)
    except Exception:
        _PIPER["voice"] = None
    return _PIPER["voice"]


def speak_piper(text: str, device=None, volume: int = 100,
                fx: str = "") -> bool:
    """用本地 piper 音色念一句；不可用就返回 False（上层会退回系统音色）。"""
    try:
        out = Path(tempfile.gettempdir()) / "stt_piper.wav"
        if not piper_to_wav(text, out):
            return False
        audio, sr = read_wav(out)
        if not audio.size:
            return False
        audio = apply_fx(audio, sr, fx)
        if volume < 100:
            audio = audio * max(0.0, min(1.0, volume / 100))
        return play(audio, sr, device, caption=text, span=(0.0, 1.0))
    except Exception:
        return False


def piper_to_wav(text: str, out: Path) -> bool:
    """本地 piper 合成到 wav 文件（给 say 用，也给"克隆音色打底"用）。"""
    voice = _piper_voice()
    if voice is None:
        return False
    try:
        import wave

        with wave.open(str(out), "wb") as wf:
            voice.synthesize_wav(text, wf)
        return out.exists() and out.stat().st_size > 1000
    except Exception:
        return False

def speak_sapi(text: str, voice: str | None = None, rate: int = 0, device=None) -> bool:
    if os.name != "nt":
        return False
    wav = Path(tempfile.gettempdir()) / "stt_say.wav"
    # 把要念的字写成一个 UTF-8 小文件再让 PowerShell 读 —— 别走 stdin：
    # stdin 会被控制台按 GBK 解码，中文就变成乱码，系统音色就会念出一团烂码（真踩过）。
    txt = Path(tempfile.gettempdir()) / "stt_say.txt"
    try:
        txt.write_text(text or "", encoding="utf-8")
    except Exception:
        return False
    voice_arg = f"$s.SelectVoice('{voice}');" if voice else ""
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        f"{voice_arg}"
        f"$s.Rate = {rate};"
        f"$s.SetOutputToWaveFile('{wav}');"
        f"$t = [IO.File]::ReadAllText('{txt}', [Text.Encoding]::UTF8);"
        "$s.Speak($t);"
        "$s.Dispose()"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            check=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        data = wav.read_bytes()
        audio, sr = decode_audio(data)
        play(audio, sr, device)
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  （系统音色也失败了：{exc}）", file=sys.stderr)
        return False


def list_voices() -> int:
    # 用户要求只留大肥鱼这一种声线；这里也只列它一个。
    print("可用音色（只有这一种）：")
    print("  dfy:大肥鱼      本地克隆音（GPT-SoVITS v4 + 视频参考）")
    print("\n（以前的晓伊/晓晓/方言/外语/RVC 克隆音色都已删除，"
          "需要恢复的话见交接文档）")
    return 0


def main() -> int:
    setup_console()
    ap = argparse.ArgumentParser(description="把文字念出来")
    ap.add_argument("text", nargs="*", help="要念的内容；不填就从标准输入读")
    ap.add_argument("--voice", default=DEFAULT_VOICE, help=f"音色，默认 {DEFAULT_VOICE}")
    ap.add_argument("--rate", default=EDGE_RATE, help="语速，默认 +8%%（edge 音色用）")
    ap.add_argument("--pitch", default=None,
                    help='音调，例如 "+30Hz"（卡通高音）/"-25Hz"（闷低音）')
    ap.add_argument("--fx", default=None,
                    help="特效：robot（机器人）/ echo（回音）/ radio（老电台）")
    ap.add_argument("--volume", type=int, default=DEFAULT_VOLUME,
                    help=f"音量百分比，默认 {DEFAULT_VOLUME}（config.json 里的 volume）")
    ap.add_argument("--device", default=DEFAULT_DEVICE,
                    help="输出设备序号；config.json 的 output_device 也能设")
    ap.add_argument("--sapi", action="store_true", help="强制用系统自带音色（离线）")
    ap.add_argument("--list-voices", action="store_true")
    ap.add_argument("--show", action="store_true", help="只打印清洗后的文本，不出声")
    args = ap.parse_args()
    if args.device not in (None, ""):
        try:
            args.device = int(args.device)
        except Exception:
            pass
    PITCH[0] = args.pitch if args.pitch is not None else DEFAULT_PITCH
    FX[0] = args.fx if args.fx is not None else DEFAULT_FX

    if args.list_voices:
        return list_voices()

    raw = " ".join(args.text) if args.text else sys.stdin.read()
    text = clean_for_speech(raw)
    if not text:
        return 0
    if args.show:
        print(text)
        return 0

    wait_turn()          # 排队，别和别的朗读进程抢音频设备
    chunks = split_chunks(text)
    # 预取下一段：一边播当前段，一边把下一段合成好，句子之间几乎没有空档
    prefetched: dict[str, tuple] = {}
    use_clone = (not args.sapi) and is_clone(args.voice)
    # 克隆音先预热：把服务拉起来、v4 权重切好、模型热一遍。
    # 不做的话第一段又要切权重又要合成，容易超时 → 退回别的音色（用户听到"新旧音交替"）。
    if is_ts_voice(args.voice):
        try:
            ensure_tts_server()
            ts_audio("好的。", args.voice, args.rate)
        except Exception:
            pass

    def render(chunk: str) -> tuple:
        """一段话 → 能直接播的 (波形, 采样率)。克隆音色就在这一步换嗓子。"""
        if is_ts_voice(args.voice):
            got_ts = ts_audio(chunk, args.voice, args.rate)
            if got_ts is not None:
                return got_ts
        if use_clone:
            got = clone_audio(chunk, args.voice, args.rate)
            if got is not None:
                return got
        try:
            return decode_audio(edge_mp3(chunk, args.voice, args.rate))
        except Exception:
            # 微软那边被拒（403）→ 换百度那个免费口（国内直连、不用登录）
            return decode_audio(baidu_mp3(chunk, args.rate))

    def prefetch(index: int) -> None:
        if index >= len(chunks) or index in prefetched:
            return
        try:
            if not args.sapi:
                prefetched[index] = render(chunks[index])
        except Exception:
            pass

    import threading

    total_chars = max(1, sum(len(c) for c in chunks))
    done_chars = 0
    for i, chunk in enumerate(chunks):
        if i + 1 < len(chunks):
            threading.Thread(target=prefetch, args=(i + 1,), daemon=True).start()
        ok = False
        if not args.sapi:
            # 在线音色偶尔会抖（网络断一下），先自己重试一次再退回系统音色 ——
            # 少让你听到那个"没听过的机器声"
            for attempt in (1, 2):
                try:
                    got = prefetched.pop(i, None) if attempt == 1 else None
                    audio, sr = got if got is not None else render(chunk)
                    audio = apply_fx(audio, sr, FX[0])       # 机器人/回音这类特效
                    if args.volume < 100:      # 音量调节：直接缩放波形
                        audio = audio * max(0.0, min(1.0, args.volume / 100))
                    span = (done_chars / total_chars, (done_chars + len(chunk)) / total_chars)
                    if not play(audio, sr, args.device, caption=chunk, span=span):
                        print("（被打断）", flush=True)
                        return 0
                    ok = True
                    break
                except Exception as exc:  # noqa: BLE001
                    if attempt == 2:
                        print(f"  （在线音色不可用，改用系统音色：{exc}）", file=sys.stderr)
                    else:
                        time.sleep(0.4)
        done_chars += len(chunk)
        if not ok:
            # 微软在线音色不可用时的退路：**先试本地 piper**（音质接近），
            # 实在没有模型才退回系统那个老音色（用户听得出区别）。
            if not speak_piper(chunk, args.device, args.volume, FX[0]):
                speak_sapi(chunk, "Microsoft Huihui Desktop" if args.sapi else None,
                           device=args.device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
