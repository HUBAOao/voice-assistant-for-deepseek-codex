#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把一段文字用语音念出来（给 AI 的回答配音）。

    python say.py "你好，这是要念的内容"
    echo "从管道读也行" | python say.py
    python say.py --list-voices
    python say.py --sapi "没网的时候用系统自带音色"

优先用 edge-tts（微软在线音色，自然）；没网或失败就退回系统自带 SAPI 音色。
"""

from __future__ import annotations

import argparse
import asyncio
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import json as _json

SPEAK_STATUS = Path(__file__).resolve().parent / "speak.json"
SPEAK_STOP = Path(__file__).resolve().parent / "speak_stop.json"


def publish_speaking(active: bool, level: float = 0.0, text: str = "",
                     progress: float = 0.0) -> None:
    """把"我正在说话"、当前音量、念到哪儿了写给悬浮窗。

    悬浮窗拿 text + progress 画"逐字跟读"：前面 progress 那部分字高亮。
    """
    try:
        SPEAK_STATUS.write_text(
            _json.dumps({"active": bool(active), "level": round(min(1.0, level), 3),
                         "text": text, "progress": round(min(1.0, max(0.0, progress)), 3),
                         "ts": time.time()}, ensure_ascii=False),
            encoding="utf-8")
    except Exception:
        pass


def stop_requested(after: float) -> bool:
    """主程序写了 speak_stop.json（比开始念还新）就表示"闭嘴"。"""
    try:
        return SPEAK_STOP.stat().st_mtime > after
    except OSError:
        return False

HERE = Path(__file__).resolve().parent


def _config() -> dict:
    path = HERE / "config.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:  # noqa: BLE001
            pass
    return {}


_CFG = _config()
DEFAULT_VOICE = os.environ.get("STT_SPEAK_VOICE") or _CFG.get("voice") or "zh-CN-XiaoxiaoNeural"
EDGE_RATE = os.environ.get("STT_SPEAK_EDGE_RATE") or _CFG.get("rate") or "+8%"
DEFAULT_VOLUME = int(_CFG.get("volume") or 80)
# 音色预设里带的变调和特效（设置 → 声音 → 音色，比如"机器人""卡通高音"）
DEFAULT_PITCH = str(_CFG.get("voice_pitch") or "")
DEFAULT_FX = str(_CFG.get("voice_fx") or "")


def setup_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def clean_for_speech(text: str) -> str:
    """把 Markdown、代码、链接这些念出来很怪的东西去掉。"""
    text = re.sub(r"```.*?```", " 代码块略过 ", text, flags=re.S)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text)          # 图片
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)        # 链接只念文字
    text = re.sub(r"https?://\S+", " 链接 ", text)
    text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.M)   # 标题
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.M)        # 列表符号
    text = re.sub(r"^\s*\d+[.、)]\s+", "", text, flags=re.M)
    text = re.sub(r"^\s*>\s?", "", text, flags=re.M)            # 引用
    text = text.replace("**", "").replace("__", "").replace("*", "").replace("~~", "")
    text = re.sub(r"^\s*\|.*\|\s*$", "", text, flags=re.M)      # 表格行
    text = re.sub(r"^\s*[-—=]{3,}\s*$", "", text, flags=re.M)
    text = re.sub(r"[\U0001F300-\U0001FAFF\u2600-\u27BF\uFE0F]", "", text)  # emoji
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "。", text)
    return text.strip()


def split_chunks(text: str, limit: int = 90) -> list[str]:
    """按句号切段。段大一点、少几次网络往返，句子之间就不会空太久。"""
    limit = max(80, limit)
    parts = re.split(r"(?<=[。！？!?；;\n])", text)
    chunks: list[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        while len(part) > limit:
            chunks.append(part[:limit])
            part = part[limit:]
        if part:
            chunks.append(part)
    return chunks or [text]


# ------------------------------------------------------------------ 在线音色

async def _edge_bytes(text: str, voice: str, rate: str, pitch: str = "") -> bytes:
    import edge_tts

    tts = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch or "+0Hz")
    buf = bytearray()
    try:
        async for chunk in tts.stream():
            if chunk["type"] == "audio":
                buf.extend(chunk["data"])
    except Exception:
        # 网络中途断掉时，已经收到的音频still能播；实在一句都没有就让上层退回系统音色
        if not buf:
            raise
    return bytes(buf)


def edge_mp3(text: str, voice: str, rate: str) -> bytes:
    try:
        data = asyncio.run(_edge_bytes(text, voice, rate, pitch=PITCH[0]))
    except Exception:
        data = b""
    if not data:                      # 一句都没拿到 → 让调用方退回系统音色
        raise RuntimeError("在线音色没取到音频")
    return data


# 变声：音调（edge-tts 自己支持，单位 Hz，例如 "+30Hz" 就是卡通高音、"-25Hz" 就是闷低音）
PITCH: list[str] = [""]
FX: list[str] = [""]


def apply_fx(audio: np.ndarray, sr: int, name: str) -> np.ndarray:
    """给声音加点味儿：robot=电子机器人、echo=山谷回音、radio=老电台。

    为什么这么做：曼波/奶龙/高松灯那些是**特定人物的音源**，微软免费语音库里没有；
    但用"换音色 + 变调 + 加点特效"，能做出那种味道（不是原版音源，我不会冒充）。
    """
    if not name or not audio.size:
        return audio
    try:
        t = np.arange(audio.size) / float(sr)
        if name == "robot":
            # 环形调制 + 轻微比特压缩：经典"电子音"
            audio = audio * (0.55 + 0.45 * np.cos(2 * np.pi * 42.0 * t))
            audio = np.round(audio * np.float32(9.0)) / np.float32(9.0)
        elif name == "echo":
            delay = int(sr * 0.16)
            out = audio.copy()
            if audio.size > delay:
                out[delay:] += audio[:-delay] * np.float32(0.32)
            audio = out / max(1.0, float(np.max(np.abs(out)) or 1.0))
        elif name == "radio":
            audio = np.tanh(audio * np.float32(2.2)) * np.float32(0.9)   # 压得扁一点
            hiss = (np.random.rand(audio.size).astype(np.float32) - 0.5) * np.float32(0.012)
            audio = audio + hiss
        peak = float(np.max(np.abs(audio)) or 1.0)
        if peak > 1.0:
            audio = audio / peak
    except Exception:
        pass
    return audio


def decode_audio(data: bytes) -> tuple[np.ndarray, int]:
    """MP3/WAV 字节流 -> (float32 单声道, 采样率)。"""
    import av

    with av.open(io.BytesIO(data)) as container:
        stream = next(s for s in container.streams if s.type == "audio")
        sr = 24000
        resampler = av.AudioResampler(format="s16", layout="mono", rate=sr)
        blocks: list[np.ndarray] = []
        for frame in container.decode(stream):
            for out in resampler.resample(frame):
                blocks.append(out.to_ndarray())
        for out in resampler.resample(None):
            blocks.append(out.to_ndarray())
    if not blocks:
        return np.zeros(0, dtype=np.float32), sr
    audio = np.concatenate([b.reshape(-1) for b in blocks]).astype(np.float32) / 32768.0
    return audio, sr


def read_wav(path) -> tuple[np.ndarray, int]:
    """读一个 16bit wav（克隆音色那边吐出来的就是这个格式）。"""
    import wave

    with wave.open(str(path), "rb") as w:
        sr, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
        raw = w.readframes(n)
    audio = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    if ch > 1:
        audio = audio.reshape(-1, ch).mean(axis=1)
    return audio, sr


def is_clone(voice: str) -> bool:
    return str(voice or "").startswith("clone:")


def clone_audio(text: str, voice: str, rate: str) -> tuple[np.ndarray, int] | None:
    """克隆音色：先用在线音色念一句打底，再让本机的 RVC 把它换成那个嗓子。

    这台机器上没装克隆环境（或者那个模型没了）就返回 None，调用方退回原声。
    """
    try:
        import clone_voice
    except Exception:
        return None
    if not clone_voice.available():
        return None
    mp3 = edge_mp3(text, clone_voice.BASE_VOICE, rate)
    ok, out, why = clone_voice.synth_to_wav(mp3, voice)
    if not ok:
        print(f"  （克隆音色没换成，先用原声：{why}）", file=sys.stderr)
        return None
    try:
        return read_wav(out)
    finally:
        try:
            Path(out).unlink(missing_ok=True)
        except Exception:
            pass


def play(audio: np.ndarray, sr: int, device=None, caption: str = "",
         span: tuple[float, float] = (0.0, 1.0)) -> bool:
    """放一段音频；中途发现"闭嘴"就立刻停，返回 False。"""
    if not audio.size:
        return True
    # 边播边把音量发出去（悬浮窗拿它做"说话时"的动画）
    block = max(256, int(sr * 0.05))
    started = time.time()
    finished = True
    try:
        with sd.OutputStream(samplerate=sr, channels=1, dtype="float32",
                             device=device) as stream:
            for i in range(0, audio.size, block):
                if stop_requested(started):
                    finished = False
                    break
                chunk = np.asarray(audio[i:i + block], dtype="float32")
                stream.write(chunk.reshape(-1, 1))
                rms = float(np.sqrt(np.mean(chunk ** 2) + 1e-9))
                done = (i + chunk.size) / audio.size
                publish_speaking(True, min(1.0, rms * 3.6), text=caption,
                                 progress=span[0] + (span[1] - span[0]) * done)
    except Exception:
        # 实时流打不开就退回普通播放，别把话说丢了
        sd.play(audio, sr, device=device)
        sd.wait()
    finally:
        # 保留下最后念的那句：主程序要靠它判断"这句是不是我自己在念"
        publish_speaking(False, 0.0, text=caption)
    return finished


def wait_turn(timeout: float = 20.0) -> None:
    """同一时间只让一个朗读进程出声：抢不到就排队，避免两句话打架/丢声音。"""
    if os.name != "nt":
        return
    import ctypes

    k = ctypes.windll.kernel32
    k.CreateMutexW.restype = ctypes.c_void_p
    k.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint]
    handle = k.CreateMutexW(None, False, "VoiceAssistantSpeak_v1")
    if handle:
        k.WaitForSingleObject(handle, int(timeout * 1000))


# ------------------------------------------------------- 离线音色（系统自带）

def speak_sapi(text: str, voice: str | None = None, rate: int = 0, device=None) -> bool:
    if os.name != "nt":
        return False
    wav = Path(tempfile.gettempdir()) / "stt_say.wav"
    # 把要念的字写成一个 UTF-8 小文件再让 PowerShell 读 —— 别走 stdin：
    # stdin 会被控制台按 GBK 解码，中文就变成乱码，系统音色就会念出一团烂码（真踩过）。
    txt = Path(tempfile.gettempdir()) / "stt_say.txt"
    try:
        txt.write_text(text or "", encoding="utf-8")
    except Exception:
        return False
    voice_arg = f"$s.SelectVoice('{voice}');" if voice else ""
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        f"{voice_arg}"
        f"$s.Rate = {rate};"
        f"$s.SetOutputToWaveFile('{wav}');"
        f"$t = [IO.File]::ReadAllText('{txt}', [Text.Encoding]::UTF8);"
        "$s.Speak($t);"
        "$s.Dispose()"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps],
            check=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        data = wav.read_bytes()
        audio, sr = decode_audio(data)
        play(audio, sr, device)
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"  （系统音色也失败了：{exc}）", file=sys.stderr)
        return False


def list_voices() -> int:
    try:
        import edge_tts

        voices = asyncio.run(edge_tts.list_voices())
        zh = [v for v in voices if v["Locale"].startswith("zh-")]
        print("在线中文音色（--voice 后面填 ShortName）：")
        for v in sorted(zh, key=lambda x: x["ShortName"]):
            print(f"  {v['ShortName']:<34} {v.get('Gender',''):<7} {v.get('FriendlyName','')}")
    except Exception as exc:  # noqa: BLE001
        print(f"拉不到在线音色列表：{exc}")
    if os.name == "nt":
        print("\n系统自带音色（--sapi --voice 名字）：")
        import winreg

        key = r"SOFTWARE\Microsoft\Speech\Voices\Tokens"
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
                for i in range(winreg.QueryInfoKey(k)[0]):
                    name = winreg.EnumKey(k, i)
                    print(f"  {name}")
        except OSError as exc:
            print(f"  读取失败：{exc}")
    return 0


def main() -> int:
    setup_console()
    ap = argparse.ArgumentParser(description="把文字念出来")
    ap.add_argument("text", nargs="*", help="要念的内容；不填就从标准输入读")
    ap.add_argument("--voice", default=DEFAULT_VOICE, help=f"音色，默认 {DEFAULT_VOICE}")
    ap.add_argument("--rate", default=EDGE_RATE, help="语速，默认 +8%%（edge 音色用）")
    ap.add_argument("--pitch", default=None,
                    help='音调，例如 "+30Hz"（卡通高音）/"-25Hz"（闷低音）')
    ap.add_argument("--fx", default=None,
                    help="特效：robot（机器人）/ echo（回音）/ radio（老电台）")
    ap.add_argument("--volume", type=int, default=DEFAULT_VOLUME,
                    help=f"音量百分比，默认 {DEFAULT_VOLUME}（config.json 里的 volume）")
    ap.add_argument("--device", default=None, help="输出设备序号（--list-devices 看）")
    ap.add_argument("--sapi", action="store_true", help="强制用系统自带音色（离线）")
    ap.add_argument("--list-voices", action="store_true")
    ap.add_argument("--show", action="store_true", help="只打印清洗后的文本，不出声")
    args = ap.parse_args()
    PITCH[0] = args.pitch if args.pitch is not None else DEFAULT_PITCH
    FX[0] = args.fx if args.fx is not None else DEFAULT_FX

    if args.list_voices:
        return list_voices()

    raw = " ".join(args.text) if args.text else sys.stdin.read()
    text = clean_for_speech(raw)
    if not text:
        return 0
    if args.show:
        print(text)
        return 0

    wait_turn()          # 排队，别和别的朗读进程抢音频设备
    chunks = split_chunks(text)
    # 预取下一段：一边播当前段，一边把下一段合成好，句子之间几乎没有空档
    prefetched: dict[str, tuple] = {}
    use_clone = (not args.sapi) and is_clone(args.voice)

    def render(chunk: str) -> tuple:
        """一段话 → 能直接播的 (波形, 采样率)。克隆音色就在这一步换嗓子。"""
        if use_clone:
            got = clone_audio(chunk, args.voice, args.rate)
            if got is not None:
                return got
        return decode_audio(edge_mp3(chunk, args.voice, args.rate))

    def prefetch(index: int) -> None:
        if index >= len(chunks) or index in prefetched:
            return
        try:
            if not args.sapi:
                prefetched[index] = render(chunks[index])
        except Exception:
            pass

    import threading

    total_chars = max(1, sum(len(c) for c in chunks))
    done_chars = 0
    for i, chunk in enumerate(chunks):
        if i + 1 < len(chunks):
            threading.Thread(target=prefetch, args=(i + 1,), daemon=True).start()
        ok = False
        if not args.sapi:
            # 在线音色偶尔会抖（网络断一下），先自己重试一次再退回系统音色 ——
            # 少让你听到那个"没听过的机器声"
            for attempt in (1, 2):
                try:
                    got = prefetched.pop(i, None) if attempt == 1 else None
                    audio, sr = got if got is not None else render(chunk)
                    audio = apply_fx(audio, sr, FX[0])       # 机器人/回音这类特效
                    if args.volume < 100:      # 音量调节：直接缩放波形
                        audio = audio * max(0.0, min(1.0, args.volume / 100))
                    span = (done_chars / total_chars, (done_chars + len(chunk)) / total_chars)
                    if not play(audio, sr, args.device, caption=chunk, span=span):
                        print("（被打断）", flush=True)
                        return 0
                    ok = True
                    break
                except Exception as exc:  # noqa: BLE001
                    if attempt == 2:
                        print(f"  （在线音色不可用，改用系统音色：{exc}）", file=sys.stderr)
                    else:
                        time.sleep(0.4)
        done_chars += len(chunk)
        if not ok:
            speak_sapi(chunk, "Microsoft Huihui Desktop" if args.sapi else None, device=args.device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
