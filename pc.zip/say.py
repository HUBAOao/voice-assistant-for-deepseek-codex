#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compatibility CLI and export facade for speech synthesis."""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path

from voice_feature.speech_audio import apply_fx, decode_audio, play, read_wav, wait_turn
from voice_feature.speech_clone import clone_audio, is_clone
from voice_feature.speech_local import PIPER_DIR, list_voices, piper_to_wav
from voice_feature.speech_local import speak_piper, speak_sapi
from voice_feature.speech_online import PITCH, baidu_mp3, edge_mp3
from voice_feature.speech_state import SPEAK_REFERENCE, SPEAK_REFERENCE_META
from voice_feature.speech_state import SPEAK_STATUS, SPEAK_STOP
from voice_feature.speech_state import publish_reference, publish_speaking, stop_requested
from voice_feature.speech_text import SPEECH_FIXES, clean_for_speech
from voice_feature.speech_text import fix_speech, setup_console, split_chunks
from voice_feature.speech_tts import polish_wav, ts_audio
from voice_feature.speech_tts_service import TS_DIR, TS_PROMPT, TS_REF, TTS_URL
from voice_feature.speech_tts_service import ensure_tts_server, is_ts_voice


HERE = Path(__file__).resolve().parent
FX: list[str] = [""]


def _config() -> dict:
    path = HERE / "config.json"
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


_CFG = _config()
DEFAULT_VOICE = os.environ.get("STT_SPEAK_VOICE") or _CFG.get("voice") or "zh-CN-XiaoxiaoNeural"
EDGE_RATE = os.environ.get("STT_SPEAK_EDGE_RATE") or _CFG.get("rate") or "+8%"
DEFAULT_VOLUME = int(_CFG.get("volume") or 80)
_out_dev = _CFG.get("output_device")
DEFAULT_DEVICE = str(_out_dev) if _out_dev not in (None, "") else None
DEFAULT_PITCH = str(_CFG.get("voice_pitch") or "")
DEFAULT_FX = str(_CFG.get("voice_fx") or "")


def main() -> int:
    setup_console()
    parser = argparse.ArgumentParser(description="把文字念出来")
    parser.add_argument("text", nargs="*", help="要念的内容；不填就从标准输入读")
    parser.add_argument("--voice", default=DEFAULT_VOICE)
    parser.add_argument("--rate", default=EDGE_RATE)
    parser.add_argument("--pitch", default=None)
    parser.add_argument("--fx", default=None)
    parser.add_argument("--volume", type=int, default=DEFAULT_VOLUME)
    parser.add_argument("--device", default=DEFAULT_DEVICE)
    parser.add_argument("--sapi", action="store_true")
    parser.add_argument("--list-voices", action="store_true")
    parser.add_argument("--show", action="store_true")
    args = parser.parse_args()
    if args.device not in (None, ""):
        try:
            args.device = int(args.device)
        except Exception:
            pass
    PITCH[0] = args.pitch if args.pitch is not None else DEFAULT_PITCH
    FX[0] = args.fx if args.fx is not None else DEFAULT_FX
    if args.list_voices:
        return list_voices()

    raw = " ".join(args.text) if args.text else sys.stdin.read()
    text = clean_for_speech(raw)
    if not text:
        return 0
    if args.show:
        print(text)
        return 0

    wait_turn()
    chunks = split_chunks(text)
    prefetched: dict[int, tuple] = {}
    use_clone = (not args.sapi) and is_clone(args.voice)
    if is_ts_voice(args.voice):
        try:
            ensure_tts_server()
            ts_audio("好的。", args.voice, args.rate)
        except Exception:
            pass

    def render(chunk: str) -> tuple:
        if is_ts_voice(args.voice):
            got_ts = ts_audio(chunk, args.voice, args.rate)
            if got_ts is not None:
                return got_ts
        if use_clone:
            got_clone = clone_audio(chunk, args.voice, args.rate)
            if got_clone is not None:
                return got_clone
        try:
            return decode_audio(edge_mp3(chunk, args.voice, args.rate))
        except Exception:
            return decode_audio(baidu_mp3(chunk, args.rate))

    def prefetch(index: int) -> None:
        if index >= len(chunks) or index in prefetched:
            return
        try:
            if not args.sapi:
                prefetched[index] = render(chunks[index])
        except Exception:
            pass

    total_chars = max(1, sum(len(chunk) for chunk in chunks))
    done_chars = 0
    for index, chunk in enumerate(chunks):
        if index + 1 < len(chunks):
            threading.Thread(target=prefetch, args=(index + 1,), daemon=True).start()
        ok = False
        if not args.sapi:
            for attempt in (1, 2):
                try:
                    got = prefetched.pop(index, None) if attempt == 1 else None
                    audio, sr = got if got is not None else render(chunk)
                    audio = apply_fx(audio, sr, FX[0])
                    if args.volume < 100:
                        audio = audio * max(0.0, min(1.0, args.volume / 100))
                    span = (
                        done_chars / total_chars,
                        (done_chars + len(chunk)) / total_chars,
                    )
                    if not play(audio, sr, args.device, caption=chunk, span=span):
                        print("（被打断）", flush=True)
                        return 0
                    ok = True
                    break
                except Exception as error:
                    if attempt == 2:
                        print(f"  （在线音色不可用，改用系统音色：{error}）", file=sys.stderr)
                    else:
                        time.sleep(0.4)
        done_chars += len(chunk)
        if not ok:
            if not speak_piper(chunk, args.device, args.volume, FX[0]):
                speak_sapi(chunk, "Microsoft Huihui Desktop" if args.sapi else None,
                           device=args.device)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
