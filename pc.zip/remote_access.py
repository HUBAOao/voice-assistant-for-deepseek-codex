# -*- coding: utf-8 -*-
"""外网访问（Tailscale）—— 直接长在语音助手里，不用你自己去官网找它。

电脑端（就是这个文件）能干的：
  · 认出装没装 / 登没登录 / 固定地址是多少（100.x 的 IP 和固定域名都给）
  · 没装就帮它装（先试 winget，不行就下官方 msi 静默装）
  · 没登录就帮它登录（跑 tailscale up，登录网址直接开在浏览器里）
  · 一条龙 enable()：装 → 登 → 拿地址 —— 设置里那个「一键开启外网访问」就是它

手机端不需要这个文件：手机 APP 的「外网」那一栏里，我把"下载安装 Tailscale、
打开登录、把地址切成固定地址"都做进 APP 自己了。安卓从系统层面规定 VPN 必须是
独立应用（得用户亲手授权那一条），所以那个官方 APK 还是得装一个，但全程在 APP
里点一下就行 —— 不用去应用商店找，也不用抄地址。

为什么用它：地址固定不变，而且只有你自己登录的设备能连，别人连端口都看不见。
"""
from __future__ import annotations

import ctypes
import json
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
PORT_DEFAULT = 8765

EXE_CANDIDATES = (
    r"C:\Program Files\Tailscale\tailscale.exe",
    r"C:\Program Files (x86)\Tailscale\tailscale.exe",
    r"C:\Program Files\Tailscale IPN\tailscale.exe",
)
WINGET_ID = "Tailscale.Tailscale"
MSI_URL = "https://pkgs.tailscale.com/stable/tailscale-setup-latest-amd64.msi"
RELEASE_BASE = ("https://github.com/HUBAOao/voice-assistant-for-deepseek-codex"
                "/releases/latest/download")
TAILSCALE_APK_URL = RELEASE_BASE + "/tailscale.apk"

CACHE_SECONDS = 6.0
_cache = {"at": 0.0, "value": None}
_lock = threading.Lock()


def _exe() -> Path | None:
    """Tailscale 的命令行程序在哪（没有就 None）。"""
    for p in EXE_CANDIDATES:
        try:
            if Path(p).exists():
                return Path(p)
        except Exception:
            pass
    w = shutil.which("tailscale")
    if w:
        try:
            return Path(w)
        except Exception:
            pass
    return None


def find_exe():
    """新名字（老代码还认 _exe）。"""
    return _exe()


def _run_raw(argv, timeout: float = 12.0) -> tuple[bool, str]:
    flags = 0x08000000 if sys.platform == "win32" else 0
    try:
        p = subprocess.run([str(a) for a in argv], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=timeout,
                           creationflags=flags)
        return p.returncode == 0, ((p.stdout or "") + (p.stderr or "")).strip()
    except Exception as exc:                                 # noqa: BLE001
        return False, str(exc)


def _run(args: list[str], timeout: float = 12.0) -> tuple[bool, str]:
    exe = _exe()
    if not exe:
        return False, ""
    return _run_raw([exe, *args], timeout=timeout)


def _run_elevated(args: list[str], wait_s: float = 240.0) -> tuple[bool, str]:
    """用管理员身份跑一条命令（会弹一次 UAC）。输出写到临时文件里读回来。

    为什么绕这一下：装 Tailscale、改它的登录状态都要管理员权限，而语音助手本身
    是普通权限跑的 —— 它不能自己提权，只能请系统弹那个「是 / 否」。
    """
    if sys.platform != "win32":
        return False, ""
    tmp = Path(tempfile.mkdtemp(prefix="va_ts_"))
    out = tmp / "out.txt"
    bat = tmp / "run.cmd"
    quoted = " ".join('"%s"' % str(a) for a in args)
    text = ("@echo off\r\n"
            "chcp 65001 >nul\r\n"
            + quoted + ' > "' + str(out) + '" 2>&1\r\n'
            + 'echo EXIT=%ERRORLEVEL%>> "' + str(out) + '"\r\n')
    try:
        bat.write_text(text, encoding="ascii", errors="replace")   # .cmd 必须纯 ASCII
    except Exception:                                        # noqa: BLE001
        return False, ""
    try:
        rc = ctypes.windll.shell32.ShellExecuteW(            # type: ignore[attr-defined]
            None, "runas", "cmd.exe", '/c "%s"' % bat, None, 0)
    except Exception:                                        # noqa: BLE001
        return False, ""
    if rc <= 32:                       # 用户点了「否」，或者窗口弹不出来
        return False, "没点同意（装 / 登录都要管理员点一下「是」）"
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if out.exists():
            got = out.read_text(encoding="utf-8", errors="replace")
            if "EXIT=" in got:
                return "EXIT=0" in got, got
        time.sleep(0.4)
    try:
        return False, out.read_text(encoding="utf-8", errors="replace")
    except Exception:                                        # noqa: BLE001
        return False, ""


def _download(url: str, dest: Path, progress=None) -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": "VoiceAssistant"})
    with urllib.request.urlopen(req, timeout=60) as r:       # noqa: S310
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if progress and total:
                    try:
                        progress("正在下安装包 %d%%" % (got * 100 // total))
                    except Exception:                        # noqa: BLE001
                        pass
    return dest


def _open(url: str) -> None:
    try:
        if sys.platform == "win32":
            ctypes.windll.shell32.ShellExecuteW(None, "open", url, None, None, 0)
        else:
            import webbrowser
            webbrowser.open(url)
    except Exception:                                        # noqa: BLE001
        pass


# ------------------------------------------------------------------ 地址
def _port() -> int:
    try:
        got = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
        return int(got.get("phone_port") or PORT_DEFAULT)
    except Exception:
        return PORT_DEFAULT


def _token() -> str:
    try:
        import phone_link
        return phone_link.load_token()
    except Exception:                                        # noqa: BLE001
        return ""


def build_url(host: str) -> str:
    """手机在外面该填的那条地址（IP 或固定域名都能这么拼）。"""
    if not host:
        return ""
    return "http://%s:%d/?k=%s" % (host, _port(), _token())


def _store(value):
    with _lock:
        _cache["at"] = time.time()
        _cache["value"] = dict(value)
    return value


# ------------------------------------------------------------------ 状态
def detail(fresh: bool = False) -> dict:
    """现在的状态：装了吗 / 登录了吗 / 固定地址是多少 / 没通的话为什么。"""
    if not fresh:
        with _lock:
            if _cache["value"] and time.time() - _cache["at"] < CACHE_SECONDS:
                return dict(_cache["value"])

    out = {"installed": False, "logged_in": False, "ip": "", "url": "",
           "alt_url": "", "why": "", "account": "", "device": "", "dns": "",
           "state": "", "version": ""}
    exe = _exe()
    out["installed"] = exe is not None
    if not out["installed"]:
        out["why"] = "这台电脑还没装 Tailscale —— 点「一键开启」，我帮你装"
        return _store(out)

    ok, text = _run(["status", "--json"], timeout=15.0)
    try:
        data = json.loads(text)
    except Exception:
        data = None
    if not isinstance(data, dict):
        out["why"] = "Tailscale 没在跑（点「一键开启」把它叫起来）"
        return _store(out)

    state = str(data.get("BackendState") or "")
    out["state"] = state
    me = data.get("Self") or {}
    uid = str(me.get("UserID") or "")
    users = data.get("User") or {}
    who = users.get(uid) or {}
    out["account"] = str(who.get("LoginName") or who.get("DisplayName") or "")
    out["device"] = str(me.get("HostName") or "")
    out["dns"] = str(me.get("DNSName") or "").rstrip(".")
    ips = [str(x) for x in (me.get("TailscaleIPs") or [])]
    ip = next((x for x in ips if x.startswith("100.")), "")
    out["ip"] = ip

    okv, vtext = _run(["version"], timeout=8.0)
    if okv and vtext:
        out["version"] = vtext.splitlines()[0].strip()

    if not ip or state in ("NeedsLogin", "Stopped", "NoState"):
        out["why"] = ("Tailscale 装了但还没登录 —— 点「一键开启」，"
                      "浏览器里登一次")
        return _store(out)
    if state != "Running":
        out["why"] = "Tailscale 状态是 %s —— 点「一键开启」试试" % (state or "未知")
        return _store(out)

    out["logged_in"] = True
    out["url"] = build_url(ip)
    if out["dns"]:
        out["alt_url"] = build_url(out["dns"])
    return _store(out)


def status() -> dict:
    """老接口（装了吗 / 登录了吗 / IP / 网址 / 为什么），内容跟 detail 一样。"""
    return detail()


def fixed_url() -> str:
    return detail().get("url", "")


def alt_url() -> str:
    """备用地址：Tailscale 给的那条固定域名（MagicDNS 开着就能用）。"""
    return detail().get("alt_url", "")


def apk_url() -> str:
    """手机在外面用的那个官方 APK（挂在 GitHub Release 上）。"""
    return TAILSCALE_APK_URL


def hint() -> str:
    """给界面用的一句话。"""
    st = detail()
    if st["logged_in"]:
        return f"外网固定地址：{st['url']}"
    return st["why"] or "外网访问不可用"


def phone_hint() -> str:
    """手机上那一栏的说明：一句话讲清怎么在外网用。"""
    st = detail()
    if st["logged_in"]:
        return ("手机装上 Tailscale、登电脑上那个账号（%s），再把地址换成上面的固定"
                "地址，出门用流量也能连。" % (st["account"] or "同一个账号"))
    return st["why"] or "电脑那边外网访问还没开"


# ------------------------------------------------------------------ 装 / 登 / 一键
def install(progress=None) -> tuple[bool, str]:
    """没装就装。先试 winget，不行就下官方 msi 静默装。"""
    def say(msg: str) -> None:
        if progress:
            try:
                progress(msg)
            except Exception:                                # noqa: BLE001
                pass

    if _exe():
        return True, "电脑上已经有 Tailscale 了"

    winget = shutil.which("winget")
    if winget:
        say("正在用 winget 装 Tailscale（可能弹一次「是」）…")
        _run_raw([winget, "install", "--id", WINGET_ID, "-e", "--silent",
                  "--accept-package-agreements", "--accept-source-agreements",
                  "--disable-interactivity"], timeout=1200.0)
        time.sleep(2)
        if _exe():
            return True, "Tailscale 装好了"
        say("winget 这条路没走通，改用官方安装包…")

    msi = Path(tempfile.gettempdir()) / "tailscale-setup-latest-amd64.msi"
    try:
        say("正在下载官方安装包…")
        _download(MSI_URL, msi, progress=progress)
    except Exception as exc:                                 # noqa: BLE001
        return False, "下安装包没成功：%s" % exc
    say("正在静默安装（会弹一次「是」）…")
    ok, text = _run_elevated(["msiexec", "/i", str(msi), "/qn", "/norestart"],
                             wait_s=900.0)
    time.sleep(3)
    if _exe():
        return True, "Tailscale 装好了"
    tail = " ".join((text or "").split())[-200:]
    return False, ("装是跑完了但还是没找到 Tailscale" if ok else "没装上：%s" % tail)


_LOGIN_URL = re.compile("https://login[.]tailscale[.]com/[A-Za-z0-9/_.-]+")


def _extract_login_url(text: str) -> str:
    m = _LOGIN_URL.search(text or "")
    return m.group(0) if m else ""


def login(hostname=None, unattended: bool = True, progress=None) -> tuple[bool, str]:
    """登录 / 把 Tailscale 叫起来。要登录就把登录网址开在浏览器里。"""
    exe = _exe()
    if not exe:
        return False, "电脑上还没装 Tailscale"
    args = ["up"]
    if unattended:
        args.append("--unattended")        # 不开机登录 Windows 也让它跑着
    if hostname:
        args += ["--hostname", str(hostname)]
    ok, text = _run(args, timeout=45.0)
    low = (text or "").lower()
    if not ok and any(w in low for w in ("access is denied", "accessdenied",
                                         "administrator", "elevat", "permission")):
        if progress:
            try:
                progress("要管理员权限，弹个窗问一下…")
            except Exception:                                # noqa: BLE001
                pass
        ok, text = _run_elevated([str(exe)] + args, wait_s=180.0)
    url = _extract_login_url(text)
    if url:
        _open(url)
        return True, "已经帮你把登录页开在浏览器里了，登完回来点「刷新」"
    if ok:
        return True, "Tailscale 连上了"
    return False, (" ".join((text or "").split())[-160:] or "没成功，再点一次试试")


def enable(progress=None) -> tuple[bool, str]:
    """一键：没装就装 → 没登就登 → 返回固定地址。"""
    def say(msg: str) -> None:
        if progress:
            try:
                progress(msg)
            except Exception:                                # noqa: BLE001
                pass

    st = detail(fresh=True)
    if not st["installed"]:
        say("电脑上还没装 Tailscale，我帮你装")
        ok, msg = install(progress=progress)
        if not ok:
            return False, msg
        time.sleep(2)
        st = detail(fresh=True)
        if not st["installed"]:
            return False, "Tailscale 装完了但还没认出来，等几秒再点一次「一键开启」"

    if not st["logged_in"]:
        say("要登录一下 Tailscale（浏览器会弹出来）")
        login(progress=progress)
        st = detail(fresh=True)
        if not st["logged_in"]:
            return False, "还没登进去 —— 浏览器里登完，回来再点一次「一键开启」就行"

    st = detail(fresh=True)
    return True, "外网访问通了，手机在外面用这条：%s" % st["url"]


def voice_line() -> str:
    """念给用户听的一句话（设置里点完之后用）。"""
    st = detail(fresh=True)
    if st["logged_in"]:
        return ("外网访问已经开着，手机在外面也能连。固定地址我显示在设置里了。")
    return st["why"] or "外网访问现在还用不了。"


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    st = detail(fresh=True)
    print("装了：", st["installed"], "| 登录了：", st["logged_in"],
          "| IP：", st["ip"], "| 状态：", st["state"])
    print("设备名：", st["device"], "| 固定域名：", st["dns"], "| 账号：", st["account"])
    print("版本：", st["version"])
    print("手机该填的地址：", st["url"] or "（还没有）")
    print("备用（固定域名）：", st["alt_url"] or "（还没有）")
    print("提示：", st["why"] or "一切正常")
