# -*- coding: utf-8 -*-
"""手机回复不再等朗读：单句无标点也要投递，电脑不出声也要结束 busy。"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("rr", APP / "reply_reader.py")
    rr = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rr)

    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    answer = "这是一整句没有句号的回答但手机也必须收到"
    raw = []
    ready = []
    ended = []
    spoken = []
    rr.document_text = lambda *a, **k: ""
    rr.pick_reply = lambda *a, **k: answer

    reader = rr.ReplyReader(
        lambda text: spoken.append(text),
        log=lambda *a, **k: None,
        record=lambda text: None,
        on_raw=lambda name, text: raw.append((name, text)),
        on_ready=lambda: ready.append(True),
        on_end=lambda: ended.append(True),
        poll_seconds=0.05,
    )
    # 手机有时拿不到窗口句柄；靠会话库也应该能收回答。
    reader.watch(0, "手机发来的问题", seconds=2, title="手机对话", speak=False)
    time.sleep(0.45)

    check(len(raw) == 1 and raw[0][1] == answer, "单句无标点也投递给手机")
    check(len(ready) == 1, "原文到手立即通知手机结束思考")
    check(reader.busy() is False, "手机已拿到回答 → 不再 busy")
    check(spoken == [], "手机命令不在电脑上朗读")
    check(bool(ended), "监视线程正常收尾")

    reader.stop()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
