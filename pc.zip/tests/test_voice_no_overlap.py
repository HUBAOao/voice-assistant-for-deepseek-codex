# -*- coding: utf-8 -*-
"""验收"语音不会重叠"：两个朗读进程必须**排队**，不能同时出声。

原理：say.py 里那把 Windows 互斥锁以前只锁了"拿锁那一瞬间"（句柄一出函数就被回收），
所以两个 say.py 会真的同时在放音。现在句柄留在模块级、握到进程结束 —— 后一个必须等。
"""
from __future__ import annotations

import subprocess
import sys
import time
import json
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
PY = APP / ".venv" / "Scripts" / "python.exe"

def hold_cmd(seconds: float) -> str:
    return ("import json, sys, time; sys.path.insert(0, r'%s'); import say;"
            "t = time.time(); ok = say.wait_turn(10);"
            "print(json.dumps({'ok': ok, 'waited': time.time() - t}), flush=True);"
            "time.sleep(%s)"
            % (APP, seconds))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 起两个：第一个拿到锁并占住，第二个必须真实等待")
    p1 = subprocess.Popen([str(PY), "-c", hold_cmd(1.5)],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True, encoding="utf-8")
    first_line = p1.stdout.readline()
    first = json.loads(first_line)
    p2 = subprocess.Popen([str(PY), "-c", hold_cmd(1.5)],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True, encoding="utf-8")
    p1_rest, p1_error = p1.communicate(timeout=60)
    p2_output, p2_error = p2.communicate(timeout=60)
    second = json.loads(p2_output)
    check(first["ok"] and first["waited"] < 0.5,
          f"第一个进程直接拿到锁（等待 {first['waited']:.2f}s）")
    check(second["ok"] and second["waited"] >= 1.1,
          f"第二个进程等到第一个释放（等待 {second['waited']:.2f}s）")

    print("③ 关键的那句握着不放还在不在")
    src = (APP / "say.py").read_text(encoding="utf-8")
    check("_MUTEX_HANDLE = handle" in src, "拿了锁就存到模块级（不会提前释放）")
    check("_MUTEX_HANDLE = None" in src, "确实有个模块级变量接着它")
    reply_runtime = (
        APP / "voice_feature" / "runtime_reply_assembly.py"
    ).read_text(encoding="utf-8")
    check("lambda text: deps.speak(text, wait=True)" in reply_runtime,
          "朗读排队用的是念完再返回那个 speak")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
