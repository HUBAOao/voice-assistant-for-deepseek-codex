# -*- coding: utf-8 -*-
"""Static checks for the multi-monitor animated desktop wallpaper."""
from __future__ import annotations

import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PET = ROOT / "outputs" / "voice-to-text" / "pet_live"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    main_js = (PET / "main.js").read_text(encoding="utf-8")
    preload = (PET / "preload.js").read_text(encoding="utf-8")
    page = (PET / "web" / "wallpaper" / "index.html").read_text(
        encoding="utf-8"
    )
    control_page = (
        PET / "web" / "wallpaper" / "control.html"
    ).read_text(encoding="utf-8")
    whale_page = (
        PET / "web" / "wallpaper" / "whale" / "index.html"
    ).read_text(encoding="utf-8")
    engine = (PET / "web" / "wallpaper" / "engine.js").read_text(
        encoding="utf-8"
    )
    whale_engine = (
        PET / "web" / "wallpaper" / "whale" / "engine.js"
    ).read_text(encoding="utf-8")
    pet_host = (PET / "web" / "pet-host.js").read_text(encoding="utf-8")

    print("① Windows 桌面层")
    check(
        "virtualDesktopBounds()" in main_js
        and "screen.getAllDisplays()" in main_js
        and "width: right - left" in main_js,
        "双屏合并成一张完整虚拟桌面",
    )
    check(
        "FindWindowExW(worker, 0, 'SHELLDLL_DefView'" in main_js
        and "win32.SetParent(hwnd, host)" in main_js
        and "WS_CHILD" in main_js,
        "壁纸窗口挂到 Windows 桌面 WorkerW，不盖住桌面图标",
    )
    check(
        "WS_BORDER" in main_js
        and "WS_DLGFRAME" in main_js
        and "WS_EX_WINDOWEDGE" in main_js
        and "WS_EX_CLIENTEDGE" in main_js,
        "壁纸最外层不保留 Windows 白色窗口边框",
    )
    check(
        "restoreDesktopWallpaper()" in main_js
        and "SystemParametersInfoW(20, 0, wallpaper, 3)" in main_js
        and "TranscodedWallpaper" not in main_js
        and "HKCU\\\\Control Panel\\\\Desktop" in main_js,
        "关闭动态壁纸后重新应用系统原壁纸，避免灰底残留",
    )
    check(
        main_js.count("let wallpaperWindow = null;") == 1
        and main_js.count("function createWallpaperWindow(port)") == 1
        and "createWallpaperWindow(appServerPort)" in main_js,
        "双屏只创建一个持续绘制的壁纸窗口",
    )
    check(
        "focusable: false" in main_js
        and "skipTaskbar: true" in main_js
        and "backgroundThrottling: false" in main_js,
        "壁纸不抢焦点、不占任务栏并保持动画计时",
    )

    print("② 保留的交互")
    check(
        "recentTaps.length >= 7" in page
        and "summonWhale()" in page
        and "startWhaleVisit(" in page,
        "连续点七下召唤蓝色巨鲸",
    )
    check(
        "createWallpaperControlWindow" in main_js
        and "wallpaperControlBounds()" in main_js
        and "area.x + area.width - size - 14" in main_js
        and "area.y + area.height - size - 14" in main_js
        and "focusable: false" in main_js,
        "昼夜开关是右侧屏幕右下角独立可点击的小控制窗",
    )
    check(
        "wallpaperThemeSet" in preload
        and "wallpaper-theme-set" in main_js
        and "BroadcastChannel('findeck-wallpaper-theme')" in page
        and "BroadcastChannel('findeck-wallpaper-theme')" in control_page
        and "animateTheme(day)" in page
        and "FillType" not in page,
        "保留手动昼夜切换并持久化",
    )
    check(
        "class=\"sun\"" in control_page
        and "class=\"moon\"" in control_page
        and "requestAnimationFrame(frame)" in page
        and "clearRect(left, y, right - left, cellH)" in page,
        "昼夜切换沿真实字符格逐格扩散",
    )
    check(
        "wallpaper-runtime.json" in main_js
        and "window.getFinDeckWallpaperGrid" in main_js,
        "运行时会回读实际 cols、cw、ch，便于核对格子尺寸",
    )
    check(
        len(re.findall(r"<button\b", control_page)) == 1
        and len(re.findall(r"<button\b", page)) == 0
        and "what's on your mind" not in page
        and "Ask anything" not in page,
        "壁纸只保留一个昼夜按钮，没有聊天页控件",
    )

    print("③ 常驻性能")
    check(
        "fps=20&dpr=1&cell=11&square=1" in main_js
        and "hammerhead:1.58" in main_js
        and "maxFps = Math.max(15" in engine
        and "maxDpr = Math.max(0.5" in engine
        and "lastPaint" in engine,
        "主壁纸限制 20 帧和 1 倍内部像素",
    )
    check(
        "cell=11&square=1" in main_js
        and "this.requestedCell" in engine
        and "this.requestedCell = Math.max(2" in engine
        and "this.renderer.requestedCell = this.requestedCell" in engine
        and "this.renderer.squareCells = params.get(\"square\") === \"1\"" in engine
        and "this.ch = this.squareCells ? this.cw" in engine
        and "this.motionScale = clamp(cellH / 19" in engine
        and "const baseLength = clamp(minSide * 0.44, 170, 430)" in engine
        and 'g.fillStyle = "rgba(158,174,194,0.13)"' in engine
        and "g.strokeStyle" not in engine
        and "g.fillRect(x, y, 1, 1)" in engine,
        "背景改成无白边的方格点阵，格高约为 32px 鼠标指针的一半",
    )
    check(
        "fps=30&dpr=1" in whale_page
        and "setFinDeckPaused" in page
        and "setFinDeckPaused" in whale_engine
        and "powerMonitor.on('lock-screen'" in main_js
        and "powerMonitor.on('suspend'" in main_js,
        "鲸鱼层同样限帧，锁屏和休眠时暂停",
    )
    check(
        "display-metrics-changed" in main_js
        and "relayoutWallpaperWindow" in main_js
        and "desktopWorkerHandle()" in main_js,
        "分辨率、缩放和 Explorer 重启后会重新贴合双屏",
    )
    check(
        "const PET_FRAME_INTERVAL = 1000 / 30;" in pet_host
        and "t - lastPaintT < PET_FRAME_INTERVAL" in pet_host,
        "关闭动态壁纸后，常驻桌宠限制为 30 帧以降低拖动负担",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
