# -*- coding: utf-8 -*-
"""Round 124 plugin, market and acceptance task-card parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
PLUGINS_JS = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "plugins.js"
MANAGEMENT_JS = (
    ROOT
    / "outputs"
    / "voice-to-text"
    / "phone_feature"
    / "ui"
    / "management.js"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    activity = ACTIVITY.read_text(encoding="utf-8")
    plugins_js = PLUGINS_JS.read_text(encoding="utf-8")
    management_js = MANAGEMENT_JS.read_text(encoding="utf-8")
    plugin_start = activity.index("private void loadPluginsInto(")
    plugin_end = activity.index("private String joinJsonArray(", plugin_start)
    plugins = activity[plugin_start:plugin_end]
    market_start = activity.index("private void renderPluginMarket(")
    market_end = activity.index("private void installMarketPlugin(", market_start)
    market = activity[market_start:market_end]
    acceptance_start = activity.index("private void showAcceptance(")
    acceptance_end = activity.index("private void addAcceptanceTools(", acceptance_start)
    acceptance = activity[acceptance_start:acceptance_end]

    print("① 旧页面规格")
    check(
        plugins_js.count('card.className = "taskCard";') >= 2
        and 'row.className = "taskCard";' in plugins_js,
        "旧插件、市场源和市场内插件都使用 taskCard",
    )
    check(
        'card.className = "taskCard";' in management_js
        and 'actions.className = "taskActions three";' in management_js,
        "旧验收记录使用 taskCard 和 taskActions three",
    )
    check(
        ".taskCard {" in (ROOT / "outputs" / "voice-to-text" / "phone_page.html").read_text(
            encoding="utf-8"
        )
        and "margin:0 0 8px; padding:12px;" in (
            ROOT / "outputs" / "voice-to-text" / "phone_page.html"
        ).read_text(encoding="utf-8"),
        "旧任务卡为 12px 内边距和 8px 底间距",
    )

    print("\n② 原生插件与市场卡")
    check(
        "NativeTheme.card(this)" not in plugins
        and "parityTaskCard(" in plugins
        and plugins.count("taskCardParams()") >= 1,
        "已安装插件改用直角 taskCard 和固定底间距",
    )
    check(
        "NativeTheme.card(this)" not in market
        and market.count("parityTaskCard(") >= 2
        and market.count("taskCardParams()") >= 2,
        "市场源与市场内插件都改用嵌套 taskCard",
    )

    print("\n③ 原生验收记录卡")
    check(
        "NativeTheme.card(this)" not in acceptance
        and "parityTaskCard(" in acceptance
        and "taskCardParams()" in acceptance,
        "验收记录改用直角 taskCard",
    )
    check(
        "flatActionGrid(3, pass, fail, reset)" in acceptance
        and "NativeTheme.chip(this, \"通过\"" not in acceptance
        and "NativeTheme.chip(this, \"未通过\"" not in acceptance,
        "验收三动作改为 40px 直角零间隙网格",
    )
    check(
        "private LinearLayout parityTaskCard()" in activity
        and "taskCardBackground(\"\")" in activity
        and "bottomMargin = NativeTheme.dp(this, 8)" in activity,
        "共享 taskCard 构造与 8px 底间距已落地",
    )

    spec = importlib.util.spec_from_file_location(
        "round124_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any(
            "插件与验收卡" in item
            for item in version.PHONE_CHANGELOG
        ),
        f"手机端 v{version.PHONE_VERSION} 变更表记录本轮卡片收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"parityTaskCard" in dex
            and b"taskCardParams" in dex
            and b"flatActionGrid" in dex,
            "APK/DEX 包含共享卡片与验收动作网格",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
