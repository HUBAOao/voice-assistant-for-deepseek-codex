# -*- coding: utf-8 -*-
"""验收「看屏幕截图」的总开关：设置里有这一项、关掉之后不会截屏。"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    features = (
        APP / "overlay_feature" / "settings_features_mixin.py"
    ).read_text(encoding="utf-8")
    collect = (
        APP / "overlay_feature" / "settings_feature_collect_mixin.py"
    ).read_text(encoding="utf-8")
    commands = (
        APP / "voice_feature" / "local_commands.py"
    ).read_text(encoding="utf-8")

    print("① 出厂默认里有这一项，默认开着")
    spec = importlib.util.spec_from_file_location("ov", APP / "overlay.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    check("screenshot_enabled" in mod.DEFAULTS, "DEFAULTS 里有 screenshot_enabled")
    check(mod.DEFAULTS.get("screenshot_enabled") is True, "默认是开着的")

    print("\n② 设置界面里有开关，而且保存时会写进配置")
    check('"看屏幕截图"' in features, "功能页里有「看屏幕截图」这一行")
    check('self.sw_shot = self._switch_row(' in features
          and '"看屏幕截图"' in features,
          "挂在功能页的开关组里")
    check('"screenshot_enabled": self.sw_shot.get()' in collect,
          "保存时会把开关状态写进 config.json")

    print("\n③ 关掉之后真的不截屏（只回一句说明）")
    gate = commands.find('if not cfg.get("screenshot_enabled", True):')
    grab = commands.find("if grab_screen():", gate)
    check(gate > 0, "主程序里读了这个开关")
    check(grab > 0 and gate < grab, "开关的判断在截图之前（关着就不会走到 grab_screen）")
    check("看屏幕截图我在设置里关掉了" in commands,
          "关掉时会说一声，不会静悄悄没反应")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
