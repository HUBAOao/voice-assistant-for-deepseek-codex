# -*- coding: utf-8 -*-
"""Round 100 touch-entry, history containment and chrome seam contracts."""
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
NATIVE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "NativeFinDeckActivity.java"
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    gestures = (UI / "page_core.js").read_text(encoding="utf-8")
    conversations = (UI / "conversations.js").read_text(encoding="utf-8")
    chat = (UI / "chat.js").read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    native = NATIVE.read_text(encoding="utf-8")
    checks = [
        (
            "浏览器两个入口手势共用 42px 死区和 1.25 方向比",
            "const ARM_DISTANCE = 42;" in gestures
            and "const AXIS_RATIO = 1.25;" in gestures
            and "window.FinDeckGesture = Object.freeze" in gestures,
        ),
        (
            "全屏右滑只在实际越过死区后接管",
            'FinDeckGesture.axisIntent(dx, dy) !== "right"' in conversations
            and "FinDeckGesture.travelPastArm(dx)" in conversations
            and "const gesArea = document.body" not in conversations,
        ),
        (
            "气泡只有左向入口使用死区，起手不再立即吞事件",
            "active:false" in chat
            and 'const intent = FinDeckGesture.axisIntent(dx, dy);' in chat
            and 'intent !== (convDrag.open ? "right" : "left")' in chat
            and "e.stopPropagation();\n  const travel" in chat
            and "function convSwipeStart(e, row, title) {\n"
            "  if (e.touches.length !== 1) return;\n"
            "  e.stopPropagation();" not in chat,
        ),
        (
            "历史筛选层阻止触摸冒泡到背后聊天",
            'const historyGestureSurface = document.getElementById("historyPanel");'
            in conversations
            and 'event => event.stopPropagation()' in conversations
            and ".chat-group + .chat-group { margin-top:-.5px !important; }"
            in page,
        ),
        (
            "原生全屏与左边缘右滑共用 42dp/1.25 入口判据",
            "GESTURE_ARM_DP = 42f" in native
            and "GESTURE_AXIS_RATIO = 1.25f" in native
            and "private boolean isHorizontalGestureEntry(" in native
            and native.count("isHorizontalGestureEntry(dx, dy, 1)") >= 3,
        ),
        (
            "原生气泡左滑入口使用同一判据，右滑交给全屏抽屉",
            "isHorizontalGestureEntry(dx, dy, -1)" in native
            and "conversationMessageGroupAt(" in native
            and "beginExternalPeekGesture(" in native
            and "moveExternalPeekGesture(" in native
            and "finishExternalPeekGesture(" in native,
        ),
        (
            "气泡右滑由左抽屉独占，不再同时当成点按打开右侧层",
            "bubbleRightHandled = true;" in native
            and "if (bubbleRightHandled) return true;" in native
            and "showConversations();\n                    }\n"
            "                    return true;\n                }\n"
            "                bubbleAtDown = null;" in native
            and "if (!convDrag.active) {" in chat
            and 'b.addEventListener("click"' not in chat,
        ),
        (
            "气泡普通点按不打开右侧层，只有明确左滑才进入",
            'b.addEventListener("click"' not in chat
            and "showConversationPeekAt(" in native
            and "group.setOnClickListener" not in native,
        ),
        (
            "原生顶栏和底栏按真实屏幕位置重绘实时模糊",
            "blurNode.setRenderEffect(" in native
            and "canvas.isHardwareAccelerated()" in native
            and "canvas.drawRenderNode(blurNode);" in native
            and "new Canvas(blurredBitmap).drawRenderNode(blurNode)"
            not in native
            and "int rootTop = selfAt[1] - rootAt[1];" in native
            and "headerFrostedBackdrop.invalidate();" in native
            and "footerFrostedBackdrop.invalidate();" in native,
        ),
        (
            "原生相邻消息组和高 DPI 栏体接缝有像素级遮盖",
            "messageList.getChildCount() == 0 ? 0 : -1" in native
            and "surface.setClipChildren(false);" in native
            and "surface.setClipToPadding(false);" in native,
        ),
        (
            "原生历史面板在空白区域吞掉触摸且不允许背景抽屉抢手势",
            "panel.setClickable(true);" in native
            and "panel.setFocusable(true);" in native
            and "&& historyPanel == null" in native,
        ),
    ]
    bad = 0
    for text, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + text)
        if not ok:
            bad += 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
