# -*- coding: utf-8 -*-
"""Focused tests for voice local screen/file command dispatch."""
from __future__ import annotations

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from voice_feature.local_commands import dispatch_screen_command  # noqa: E402


class FakeStatus:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state, text=""):
        self.calls.append((state, text))


def main() -> int:
    spoken: list[str] = []
    logged: list[tuple[str, str]] = []
    status = FakeStatus()

    def done() -> bool:
        return False

    result = dispatch_screen_command(
        "把报表.xlsx发到手机",
        cfg={"screen_share": False},
        speak=spoken.append,
        done=done,
        syslog=lambda tag, text: logged.append((tag, text)),
        status=status,
        busy={},
        resolve_target=lambda: (0, ""),
        paste_clipboard=lambda *a, **k: True,
        grab_screen=lambda: True,
    )
    assert result is False and spoken[-1] == "发文件我在设置里关掉了"

    added: list[str] = []
    fake_files = types.SimpleNamespace(
        find_file=lambda name: Path("C:/tmp/报表.xlsx"),
        add_file=lambda source: added.append(source.name) or Path("upload-报表.xlsx"),
    )
    sys.modules["file_share"] = fake_files
    result = dispatch_screen_command(
        "把报表.xlsx发到手机",
        cfg={"screen_share": True},
        speak=spoken.append,
        done=done,
        syslog=lambda tag, text: logged.append((tag, text)),
        status=status,
        busy={},
        resolve_target=lambda: (0, ""),
        paste_clipboard=lambda *a, **k: True,
        grab_screen=lambda: True,
    )
    assert result is False and added == ["报表.xlsx"]
    assert status.calls[-1][1].startswith("📁 已发到手机")

    pasted: list[tuple] = []
    watched: list[dict] = []
    reply_reader = types.SimpleNamespace(watch=lambda *a, **k: watched.append(k))
    busy: dict = {}
    result = dispatch_screen_command(
        "看看这个",
        cfg={"screenshot_enabled": True, "read_reply": True},
        speak=spoken.append,
        done=done,
        syslog=lambda tag, text: logged.append((tag, text)),
        status=status,
        busy=busy,
        resolve_target=lambda: (77, "Codex"),
        paste_clipboard=lambda *a, **k: pasted.append((a, k)),
        grab_screen=lambda: True,
        reply_reader=reply_reader,
        current_conversation=lambda: "鳍舱",
        from_phone=True,
    )
    assert result is False and pasted and watched
    assert watched[0]["title"] == "鳍舱" and watched[0]["speak"] is False
    assert busy["on"] is True

    assert dispatch_screen_command(
        "今天天气怎么样",
        cfg={},
        speak=spoken.append,
        done=done,
        syslog=lambda tag, text: logged.append((tag, text)),
        status=status,
        busy={},
        resolve_target=lambda: (0, ""),
        paste_clipboard=lambda *a, **k: True,
        grab_screen=lambda: True,
    ) is None
    print("test_local_commands: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
