# -*- coding: utf-8 -*-
"""Focused tests for extracted tutorial and maintenance voice commands."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.maintenance_commands import (  # noqa: E402
    dispatch_maintenance_command,
)
from voice_feature.tutorial_commands import dispatch_tutorial_command  # noqa: E402


class FakeStatus:
    def __init__(self) -> None:
        self.calls: list[tuple] = []

    def set(self, state: str, text: str = "") -> None:
        self.calls.append((state, text))


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="findeck-local-maintenance-") as raw:
        document = Path(raw) / "使用教程.html"
        document.write_text("教程", encoding="utf-8")
        spoken: list[str] = []
        logged: list[tuple[str, str]] = []
        lessons: list[int] = []
        opened: list[Path] = []
        status = FakeStatus()
        tutorial = {"on": True, "step": 2}

        common = dict(
            tutorial=tutorial,
            document=document,
            speak=spoken.append,
            say=lessons.append,
            syslog=lambda tag, text: logged.append((tag, text)),
            status=status,
            done=lambda: False,
            open_document=opened.append,
            parse_number=lambda text: {"十二": 12}.get(text),
        )
        assert dispatch_tutorial_command(
            plain_text="今天教程讲什么", **common
        ) is False
        assert lessons == [2]
        assert dispatch_tutorial_command(
            plain_text="教程第十二课", **common
        ) is False
        assert lessons[-1] == 11
        assert dispatch_tutorial_command(plain_text="下一步", **common) is False
        assert lessons[-1] == 3
        assert dispatch_tutorial_command(plain_text="退出教程", **common) is False
        assert tutorial["on"] is False
        assert dispatch_tutorial_command(
            plain_text="打开教程文件", **common
        ) is False
        assert opened and opened[-1].name == "使用教程.html"
        assert dispatch_tutorial_command(plain_text="今天天气", **common) is None

        now = [1000.0]
        called: list[tuple] = []
        private = {"until": 0.0, "clear_ask": 0.0}
        maintenance = dict(
            cfg={"private_minutes": 5},
            private=private,
            speak=spoken.append,
            syslog=lambda tag, text: logged.append((tag, text)),
            status=status,
            done=lambda: False,
            clear_all_data=lambda: called.append(("clear",)) or 7,
            undo_last=lambda: called.append(("undo",)),
            do_export=lambda: called.append(("export",)),
            do_import=lambda: called.append(("import",)),
            do_update=lambda: called.append(("update",)),
            apply_update_now=lambda: called.append(("apply",)),
            diag_pack=lambda: called.append(("diag",)) or Path("诊断.zip"),
            self_check=lambda speak_it=False: ["测试失败"],
            now=lambda: now[0],
            log=lambda text: None,
        )
        assert dispatch_maintenance_command("别记这段", **maintenance) is False
        assert private["until"] == 1300.0
        assert dispatch_maintenance_command("可以记了", **maintenance) is False
        assert private["until"] == 0.0

        assert dispatch_maintenance_command("清空所有记录", **maintenance) is False
        assert private["clear_ask"] == 1030.0 and not called
        assert dispatch_maintenance_command("确定清空", **maintenance) is False
        assert called == [("clear",)] and status.calls[-1][1].endswith("7 个文件")
        called.clear()
        assert dispatch_maintenance_command("确定清空", **maintenance) is False
        assert not called and spoken[-1] == "先说要清空，我再问你一次"

        assert dispatch_maintenance_command("撤销", **maintenance) is False
        assert dispatch_maintenance_command("导出数据", **maintenance) is False
        assert dispatch_maintenance_command("诊断包", **maintenance) is False
        assert dispatch_maintenance_command("导入数据", **maintenance) is False
        assert dispatch_maintenance_command("检查更新", **maintenance) is False
        assert dispatch_maintenance_command("开始更新", **maintenance) is False
        assert dispatch_maintenance_command("自检", **maintenance) is False
        assert called == [
            ("undo",), ("export",), ("diag",), ("import",),
            ("update",), ("apply",),
        ]
        assert spoken[-1] == "自检发现：测试失败"
        assert dispatch_maintenance_command("今天天气", **maintenance) is None

    print("test_local_maintenance_commands: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
