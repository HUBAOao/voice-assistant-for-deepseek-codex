# -*- coding: utf-8 -*-
"""Round 112 native main-chat state, queueing and stale-response contracts."""
from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))
import version as app_version  # noqa: E402

JAVA = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant"
)
ACTIVITY = JAVA / "NativeFinDeckActivity.java"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    native = ACTIVITY.read_text(encoding="utf-8")
    version = (APP / "version.py").read_text(encoding="utf-8")
    page_runtime = (APP / "phone_feature" / "ui" / "page_runtime.js").read_text(
        encoding="utf-8"
    )
    media = (APP / "phone_feature" / "ui" / "media.js").read_text(
        encoding="utf-8"
    )
    page_tools = (APP / "phone_feature" / "ui" / "page_tools.js").read_text(
        encoding="utf-8"
    )

    banner = native.split(
        "private LinearLayout buildUpdateBanner()", 1
    )[-1].split("private void checkForNativeUpdate()", 1)[0]
    check_update = native.split(
        "private void checkForNativeUpdate()", 1
    )[-1].split("private void startNativeBannerUpdate()", 1)[0]
    banner_update = native.split(
        "private void startNativeBannerUpdate()", 1
    )[-1].split("private boolean nativeVersionIsNewer(", 1)[0]
    send = native.split(
        "private void sendComposer()", 1
    )[-1].split("private void drainOutgoingQueue()", 1)[0]
    drain = native.split(
        "private void drainOutgoingQueue()", 1
    )[-1].split("private void retryOutgoing(", 1)[0]
    merge = native.split(
        "private JSONObject mergeLocalEcho(", 1
    )[-1].split("private boolean unknownConversation(", 1)[0]
    resume = native.split(
        "protected void onResume()", 1
    )[-1].split("protected void onPause()", 1)[0]
    back = native.split(
        "public void onBackPressed()", 1
    )[-1].split("protected void onDestroy()", 1)[0]
    recording = native.split(
        "private void startNativeRecording()", 1
    )[-1].split("private void writeNativeRecording(", 1)[0]
    voice = native.split(
        "private void stopNativeRecording(", 1
    )[-1].split("private void releaseNativeRecorder(", 1)[0]
    tts = native.split(
        "private void speakLatest()", 1
    )[-1].split("private void startNativeRecording()", 1)[0]
    balance = native.split(
        "private void loadBalance()", 1
    )[-1].split("private String shortTokens(", 1)[0]
    identity = native.split(
        "private void loadDesktopIdentity()", 1
    )[-1].split("private void poll()", 1)[0]
    conversations = native.split(
        "private void refreshActiveConversation()", 1
    )[-1].split("private void setOnlinePulse(", 1)[0]
    stop = native.split(
        "private void stopSpeech()", 1
    )[-1].split("private void newConversation()", 1)[0]

    check(
        "startNativeBannerUpdate();" in banner
        and 'api.absoluteUrl("app.apk")' not in banner
        and "resolveNativeUpdate(" in banner_update
        and 'snapshot.optString(' in banner_update
        and '"download_url", ""' in banner_update
        and "if (!nativeVersionIsNewer(latest))" in banner_update,
        "顶部更新按钮从公网清单解析真实 APK，不再固定下载旧 app.apk",
    )
    check(
        "resolveNativeUpdate(new UpdateSnapshotCallback()" in check_update
        and "lastUpdateCheckAt = System.currentTimeMillis();" in check_update
        and "if (recoveredFromOffline)" in native
        and "checkForNativeUpdate();" in native.split(
            "if (recoveredFromOffline) {", 1
        )[-1].split("JSONArray lines", 1)[0]
        and "System.currentTimeMillis() - lastUpdateCheckAt > 30000L"
        in resume,
        "顶部更新与设置共用清单，重连和回前台会重查",
    )
    check(
        "ArrayDeque<OutgoingDraft> outgoingQueue" in native
        and "if (historyFilterActive) {" in send
        and "setHistoryFilterButtonActive(false);" in send
        and "outgoingQueue.addLast(draft);" in send
        and "drainOutgoingQueue();" in send
        and "if (outboxRunning || isFinishing()) return;" in drain
        and "outgoingQueue.pollFirst();" in drain
        and "drainOutgoingQueue();" in drain
        and "filesUi.post(new Runnable()" in drain
        and "filesUi.removeCallbacksAndMessages(null);" in native,
        "连续发送进入单一队列并串行提交，避免并发抢会话与重复下单",
    )
    check(
        all(
            marker in native
            for marker in (
                '"queued"', '"sending"', '"accepted"', '"failed"',
                '"delivered"', '"stopped"',
            )
        )
        and '"排队中"' in native
        and '"发送中"' in native
        and '"已交给电脑"' in native
        and '"失败 · 重试"' in native
        and "retryOutgoing(messageData);" in native,
        "发送气泡显示排队、发送、受理、失败与重试的真实状态",
    )
    check(
        "if (attachment.uploaded) continue;" in drain
        and "attachment.uploaded = true;" in drain
        and 'item.put("uploaded", attachment.uploaded);' in native
        and "attachmentsFromMessage(message);" in native
        and "restoreStagedAttachments" not in native,
        "附件失败重试从首个未完成项继续，不重复上传已经成功的文件",
    )
    check(
        "LocalEcho" in native
        and "localEchoes.add(new LocalEcho(" in native
        and "unknownConversation(" in merge
        and "sameText == 1" in merge
        and 'item.put("state", "delivered");' in merge
        and 'echo.put("message", item.message);' in native,
        "本地回声带真实会话与消息身份，跨会话相同文字不会被吞",
    )
    check(
        "private int balanceRequestGeneration;" in native
        and "if (generation != balanceRequestGeneration" in balance
        and '!balance.has("total")' in balance
        and '"余额关"' in balance
        and "balanceRequestGeneration++;" in native,
        "余额请求带代际，缺字段或关闭时不把 0 当真实余额",
    )
    check(
        "private int identityRequestGeneration;" in native
        and "if (generation != identityRequestGeneration" in identity
        and "private int conversationRefreshGeneration;" in native
        and "if (generation != conversationRefreshGeneration" in conversations
        and "refreshActiveConversation();" in native,
        "电脑名称和当前会话刷新都丢弃旧响应，避免会话标题串页",
    )
    check(
        "if (stopRequestInFlight) return;" in stop
        and "停止请求已送达，等电脑回执" in stop
        and 'status.setText("正在等它停…");' in stop
        and "if (generation != stopRequestGeneration" in stop,
        "停止操作防重复提交，只报告请求送达并等待真实状态回执",
    )
    check(
        "if (nativeRecording)" in recording
        and "if (voiceRequestInFlight)" in recording
        and "voiceRequestInFlight = true;" in voice
        and "if (generation != voiceRequestGeneration" in voice
        and 'toast("录音没送出去："' in voice,
        "录音防止重复开始与并发识别，迟到结果不写回新页面",
    )
    check(
        "nativeRecordDialog = showNativeDialog(" in recording
        and "dismissNativeDialog(recordDialog, null, null)" in voice,
        "8 秒采样和手动停止都会关闭录音对话层",
    )
    check(
        "ttsInitializing" in tts
        and "pendingSpeechText" in tts
        and "speakPendingText();" in tts
        and "TextToSpeech.LANG_MISSING_DATA" in tts
        and "ui.postDelayed(" not in tts,
        "TTS 初始化完成后再朗读，失败会释放实例且不靠固定延时假成功",
    )
    check(
        "if (conversationDrawerOverlay != null) {" in back
        and "if (isHistoryKeyboardVisible())" in back
        and "&& composer.hasFocus()" in back
        and "hideRootKeyboard();" in back
        and back.index("conversationDrawerOverlay != null")
        < back.index("conversationPeek != null")
        < back.index("pendingAttachments > 0")
        < back.index("overlayActive != null"),
        "返回键先收当前键盘，再按换会话、附件、子页层级关闭且保留 Activity",
    )
    check(
        "retainReadPermission(" in native
        and "releaseReadPermission(attachment.uri);" in native
        and "Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION" in native
        and "getContentResolver().releasePersistableUriPermission(" in native
        and "loadIncomingText(uri);" in native
        and "filesUi.post(new Runnable()" in native
        and "incomingTextGeneration++;" in native
        and "handleIncoming(getIntent());" in native,
        "分享/附件异步读取授权内容，发送成功后释放临时持久授权",
    )
    check(
        "addMessageAttachments(bubble, messageData);" in native
        and '"附件 · " + name' in native
        and "preview.setImageURI(Uri.parse(uriValue));" in native
        and "loadNetworkBitmap(" in native,
        "主聊天用户气泡显示本地图片或文件附件，并支持上传后回读",
    )
    check(
        "还没有对话。\\n说「大肥鱼」或直接发一句话。" in native
        and "没发出去：" in native
        and "result.error(\"连不上电脑\")" in native
        and "SwipeRefresh" not in native,
        "主聊天保留旧空态，发送、停止、余额和连接错误都有实际原因",
    )
    check(
        "pulling = false;" in page_runtime
        and "function catchUp()" in page_tools
        and "visibilitychange" in page_tools
        and "mergeLocalEcho" in page_runtime
        and "uploadAttachment(item)" in media
        and '"/api/stop"' in media,
        "旧 chat/page_runtime/page_tools/media 仍是发送、补拉和回声合并规格",
    )
    check(
        "鳍舱第一百一十二轮原生主聊天整页收口" in version
        and 'PHONE_VERSION = f"1.{len(PHONE_CHANGELOG)}"' in version,
        "手机端版本表新增第一百一十二轮，版本继续由 PHONE_CHANGELOG 计算",
    )

    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    with zipfile.ZipFile(apk) as archive:
        dex = archive.read("classes.dex")
    check(
        b"outgoingQueue" in dex
        and b"sendComposer" in dex
        and b"balanceRequestGeneration" in dex
        and b"startNativeBannerUpdate" in dex,
        "最终 APK 确实包含发送队列、主聊天请求代际和顶部更新修复",
    )
    manifest = subprocess.run(
        [
            r"F:\android-dev\sdk\build-tools\34.0.0\aapt2.exe",
            "dump", "xmltree", "--file", "AndroidManifest.xml", str(apk),
        ],
        check=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    check(
        f'versionName(0x0101021c)="{app_version.PHONE_VERSION}"'
        in manifest.stdout
        and "versionCode(0x0101021b)="
        f"{1000 + len(app_version.PHONE_CHANGELOG)}" in manifest.stdout,
        "最终 APK 版本与当前手机版本表一致",
    )

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
