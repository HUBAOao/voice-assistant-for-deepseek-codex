# -*- coding: utf-8 -*-
"""验收：点「恢复默认」之后，配置是不是就变成出厂那套（＝我现在的设置）。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "defaults-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402
from _overlay_test_support import isolate_overlay  # noqa: E402


def main() -> int:
    scratch = S / "config.json"
    isolate_overlay(overlay, S, {
        "name": "乱改的", "wake_word": "小黑", "overlay_color": "#ff00ff",
        "voice": "zh-CN-YunxiNeural", "overlay_alpha": 0.2, "volume": 5,
        "weather_city": "上海", "pet_enabled": True, "not_heard_reply": True,
    }, app_dir=APP)

    o = overlay.Overlay()
    o.alpha_override = 0.95
    o.set_expanded(True)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    o.reset_defaults()
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    o.root.destroy()

    got = json.loads(scratch.read_text(encoding="utf-8"))
    bad = []
    for key, want in overlay.DEFAULTS.items():
        if key not in got:
            continue        # 新加的设置项，用户还没保存过就不会在文件里，不算不一致
        if got.get(key) != want:
            bad.append((key, want, got.get(key)))
    print(f"比对了 {len(overlay.DEFAULTS)} 项出厂默认值")
    for key, want, have in bad:
        print(f"  ✗ {key}: 期望 {want!r} 实际 {have!r}")
    print("恢复默认 = 出厂设置：", "✓" if not bad else f"✗ 有 {len(bad)} 项不对")
    print("运行中的用户配置可能不同于出厂值；本测试只验收恢复默认本身。")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
