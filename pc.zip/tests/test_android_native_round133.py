# -*- coding: utf-8 -*-
"""Round 133 native chat row and continuous grouping parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
CHAT_JS = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "chat.js"
RUNTIME_JS = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "page_runtime.js"
)
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    chat = CHAT_JS.read_text(encoding="utf-8")
    runtime = RUNTIME_JS.read_text(encoding="utf-8")
    source = ACTIVITY.read_text(encoding="utf-8")
    render = method_block(
        source,
        "private void renderMessages()",
        "private GradientDrawable groupBackground(",
    )
    append = method_block(
        source,
        "private void appendMessagesFrom(",
        "private void addMessageRow(",
    )
    row = method_block(
        source,
        "private void addMessageRow(",
        "private CharSequence historyKeywordSpan(",
    )
    group = method_block(
        source,
        "private GradientDrawable groupBackground(",
        "private boolean isOtherConversation(",
    )

    print("① 旧页消息行与连续分组最终规格")
    check(
        "#log {\n    padding:0 !important; width:100% !important;"
        in page
        and 'margin:2px 0 !important; padding:10px 14px !important'
        in page,
        "旧页聊天区无外层内边距，消息行 2px 上下距和 10/14px 行内距",
    )
    check(
        ".row.group-cont .av { display:none !important; }" in page
        and ".row[data-kind=\"ai\"].group-cont" in page
        and "padding-left:52px !important" in page,
        "连续 AI 行隐藏后续头像并使用 52px 左缩进",
    )
    check(
        ".row[data-kind=\"me\"] .av { display:none !important; }" in page
        and ".row[data-kind=\"me\"] .bubble .btext { width:100%;"
        " text-align:right !important; }" in page,
        "用户行不显示头像且文字靠右",
    )
    check(
        ".bubble .btext, header .name, textarea" in page
        and "font-size:var(--fs-mid) !important;" in page
        and ".bubble .btext { line-height:1.65 !important; }" in page,
        "正文使用 14px 和 1.65 行高",
    )
    check(
        ".bubble .bmeta" in page
        and "margin-top:6px; min-width:0" in page
        and "appearance:none; border:0; background:rgba(255,255,255,.08)"
        in page,
        "底部元信息距正文 6px，复制按钮为独立淡底控件",
    )
    check(
        ".chat-group.current::before" in page
        and "color-mix(in srgb,var(--accent) 34%,transparent)" in page
        and ".chat-group.other::before" in page
        and "rgba(0,0,0,.74)" in page
        and ".chat-group.kind-me::before" in page,
        "AI 分组只有一层顶部向下光晕，用户组没有光晕",
    )
    check(
        ".bubble .t" in page
        and "font-size:11px; opacity:.55" in page
        and "const t = document.createElement(\"span\")" in chat
        and "const copyButton = document.createElement(\"button\")" in chat,
        "每句独立时间与显式复制控件保留",
    )
    check(
        "sameGroupEl.appendChild(row)" in chat
        and "function regroupChatRows()" in runtime
        and "row.dataset.kind !== kind" in runtime
        and "row.dataset.conv || \"\"\" ) !== conv" not in runtime
        and 'String(row.dataset.conv || "") !== conv' in runtime,
        "只合并连续同发言方、同会话且同当前/其他状态的组",
    )

    print("\n② 原生连续分组与消息行")
    check(
        "new ConversationMessageGroup(" in render
        and "kind.equals(next.optString(\"kind\", \"\"))" in render
        and "conversation.equals(next.optString(\"conv\", \"\"))" in render,
        "原生保留同发言方、同会话的连续分组条件",
    )
    check(
        "group.setPadding(NativeTheme.dp(this, 14), NativeTheme.dp(this, 9),"
        not in render
        and "group.setPadding(NativeTheme.dp(this, 14), NativeTheme.dp(this, 9),"
        not in append
        and "group.setPadding(0, 0, 0, 0)" in render,
        "原生分组取消旧 14/9/14/8px 双重内边距",
    )
    check(
        'NativeTheme.dp(this, 28), NativeTheme.dp(this, 28)'
        in row
        and "avatarParams.rightMargin = NativeTheme.dp(this, 10);" in row
        and "avatarParams.gravity = Gravity.BOTTOM;" in row
        and "avatarParams.bottomMargin = NativeTheme.dp(this, 2);" in row,
        "原生组首头像恢复 28px、10px 间距和底部对齐",
    )
    check(
        'if ("ai".equals(kind) && !firstInGroup) leftPadding = 52;'
        in row
        and "verticalPadding = firstInGroup ? 10 : 3;" in row
        and "row.setPadding(" in row,
        "原生活泼/连续行恢复 14px 与 52px 左缩进及 10/3px 纵向距",
    )
    check(
        "NativeTheme.BODY_FONT,\n                    mine" not in row
        and "14," in row
        and "body.setLineSpacing(0f, 1.65f);" in row
        and "widthPixels\n                            * (mine ? .82f : .86f)"
        not in row,
        "原生正文恢复 14px、1.65 行高并取消 82/86% 硬限宽",
    )
    check(
        "footerRow.setPadding(0, NativeTheme.dp(this, 6), 0, 0);" in row
        and 'NativeTheme.text(\n                    this,\n                    metaText,' not in row
        and "messageConversationName(" not in row
        and 'time == null ? "" : time,' in row
        and "                    11," in row,
        "原生底栏只显示独立 11px 时间，真实会话名保留在消息数据中",
    )
    check(
        "Color.argb(20, 255, 255, 255)" in row
        and '"复制"' in row
        and "copyParams.leftMargin = NativeTheme.dp(this, 7);" in row,
        "原生显式复制按钮继续独占右侧操作位",
    )
    check(
        "Color.argb(189, 0, 0, 0)" in group
        and "Color.argb(77, 0, 0, 0)" in group
        and "NativeTheme.AI_BUBBLE" in group
        and "NativeTheme.ME_BUBBLE" in group
        and "Color.argb(184, 16, 38, 26)" in row
        and "otherConversation ? 107 : 140" in row,
        "其他会话 AI 渐隐、用户文字与时间降透明，用户组保持纯色底",
    )
    check(
        "historyFilterActive" in render
        and "isOtherConversation(conversation)" in render
        and "isOtherConversation(conversation)" in append
        and "historyKeywordSpan(" in row
        and "if (historyFilterActive) return;" in append,
        "筛选、其他会话、关键词和增量追加语义保持不变",
    )

    spec = importlib.util.spec_from_file_location("round133_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十三轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录消息行收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"ConversationMessageGroup" in dex
            and b"historyKeywordSpan" in dex,
            "APK/DEX 含消息分组与关键词高亮实现",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
