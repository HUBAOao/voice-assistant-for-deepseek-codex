# -*- coding: utf-8 -*-
"""Middle runtime services keep legacy order while leaving ``main()``."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature import runtime_service_assembly as module  # noqa: E402


class Adapter:
    def __init__(self) -> None:
        self.raw_replies_file = Path("replies.jsonl")
        self.last_reply_file = Path("last.json")

    def current_thread_id(self):
        return "thread"

    def current_thread_name(self):
        return "会话"

    def switch_thread(self, title, thread_id):
        return True

    def public_update_url(self):
        return "https://example.invalid/"

    def reply_busy(self):
        return False

    def process_command(self, text):
        return text


class Phone:
    def __init__(self) -> None:
        self.pause = {"prev": False, "paused": False}
        self.ingress = object()
        self.task_store = object()
        self.live_codex = object()
        self.commands = object()
        self.state_runtime = object()
        self.info_runtime = object()
        self.history_deps = object()
        self.raw_reply = object()

    def start(self):
        events.append("phone-start")
        return "server"


events = []


def fake_factory(name):
    class Fake:
        def __init__(self, deps):
            self.deps = deps
            self.restart_program = lambda: None
            self.remote_action = lambda action: None
            self.hot_reload_page = lambda: None
            self.keep_alive = lambda: None
            self.check_hotkey = lambda: None
            events.append(name)

    return Fake


def values(phone):
    return dict(
        args=object(),
        config={"phone_port": 8765},
        config_file=Path("config.json"),
        app_dir=Path("app"),
        syslog_file=Path("syslog.md"),
        voiceprint_file=Path("voiceprint.json"),
        said_file=Path("said.md"),
        manual_exit=Path("manual-exit.json"),
        status=object(),
        busy={},
        mute={},
        editing={},
        hotkey={},
        level_state=lambda value: "ok",
        phone_window_state={},
        voiceprint={},
        wake_words=["大肥鱼"],
        rate=16000,
        transcriber=object(),
        cancel_reference_echo=lambda audio, sr: audio,
        handle_lock=object(),
        handle_command=lambda text: text,
        speech_context=object(),
        phone_window=lambda: (0, ""),
        pick_send_target=lambda: (0, ""),
        focus_window=lambda hwnd: True,
        press_enter=lambda: None,
        paste_into=lambda *args, **kwargs: True,
        paste_clipboard=lambda *args, **kwargs: True,
        image_to_clipboard=lambda path: True,
        set_phone_window=lambda title, thread_id="": (True, ""),
        phone_thread_action=lambda action, thread_id, payload: (True, ""),
        phone_new_thread=lambda project_id="": (True, ""),
        on_stop=lambda: None,
        calibrate=lambda: 0.1,
        record=lambda *args, **kwargs: None,
        has_utterance=lambda audio, rate: True,
        voice_features=lambda audio, rate: [1.0],
        copy_to_clipboard=lambda text: True,
        type_text_hwnd=lambda *args, **kwargs: True,
        is_paused=lambda: bool(phone.pause["paused"]),
        python_executable="python.exe",
        load_config=lambda: {},
        syslog=lambda tag, text: None,
        speak=lambda *args, **kwargs: None,
        shut_up=lambda: None,
        beep=lambda freq, ms: None,
        read_selected=lambda: None,
        do_export=lambda: None,
        do_import=lambda: None,
        do_diagnose=lambda: None,
        start_wake_test=lambda why: None,
        runtime_lifecycle=object(),
        get_reply_reader=lambda: None,
        reply_reader_module=object(),
        reload_phone_link=lambda: None,
        phone_link_module=type("PhoneLink", (), {
            "DEFAULT_PORT": 8765,
            "pc_version": staticmethod(lambda: "1.276"),
            "phone_app_version": staticmethod(lambda: "1.95"),
            "__file__": str(APP / "phone_link.py"),
        }),
        version_module=object(),
        remote_access_module=object(),
        chat_history_module=object(),
        remote_factory=lambda callback: events.append("remote") or type(
            "Remote", (), {"poll": lambda self: None}
        )(),
        self_who=lambda cfg: "大肥鱼",
        ack_phrases=("嗯",),
        list_chat_windows=lambda: [],
        last_sent={},
        fatigue={},
        last_unsent={},
        chars_per_second=lambda audio, sr, text: 4.0,
        privacy_clean=lambda text: text,
        verify_delivery=lambda *args, **kwargs: True,
        datetime_factory=object,
        background_noise=lambda *args, **kwargs: False,
        reload_wake_settings=lambda: None,
        focus_tick=lambda: None,
        night_diary=lambda: None,
        reminders=lambda: None,
        overlay_process=None,
        ticker={},
        start_overlay=lambda: None,
        no_overlay=False,
        feed=False,
        test_paste=False,
        mic_capture={},
        clock=lambda: 1.0,
        emit=lambda text, **kwargs: None,
    )


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    events.clear()
    phone = Phone()
    adapter = Adapter()
    factories = {
        "RuntimeInteractionAssembly": fake_factory("interaction"),
        "ControlRuntime": fake_factory("control"),
        "RuntimeReplyAssembly": fake_factory("reply"),
        "RuntimeDeliveryAssembly": fake_factory("delivery"),
        "RuntimeSendGateAssembly": fake_factory("send-gate"),
        "RuntimeOverlayLiveness": fake_factory("overlay"),
        "RuntimePeriodicAssembly": fake_factory("periodic"),
    }
    with patch.object(module, "assemble_phone_adapter", return_value=adapter), \
            patch.object(module, "assemble_phone_runtime", return_value=phone), \
            patch.multiple(module, **factories):
        result = module.assemble_runtime_services(
            module.RuntimeServiceDependencies(**values(phone))
        )

    check(events == [
        "phone-start", "interaction", "control", "remote", "reply",
        "delivery", "send-gate", "overlay", "periodic",
    ], "手机服务、交互、控制、回答、送达与周期检查保持旧顺序")
    check(result.phone_server == "server", "手机服务启动结果继续由装配返回")
    check(result.phone_adapter is adapter and result.phone is phone,
          "主流程只消费手机装配实例")
    interaction_deps = result.interaction.deps
    check(interaction_deps.is_paused() is False,
          "交互运行时绑定手机服务的真实暂停状态")
    phone.pause["paused"] = True
    check(interaction_deps.is_paused() is True,
          "暂停状态变化立即传递到交互运行时")
    check(result.control_runtime.deps.pause is phone.pause,
          "控制运行时和手机入口共用同一个暂停对象")
    check(result.send_gate.deps.pick_send_target is not None
          and result.periodic_runtime.deps.reminders is not None,
          "发送闸门和周期任务依赖保持可用")

    source = (
        APP / "voice_feature" / "runtime_application_services.py"
    ).read_text(encoding="utf-8")
    check("services = assemble_runtime_services(" in source,
          "main() 只调用统一服务装配入口")
    for old in (
        "RuntimeInteractionAssembly(",
        "ControlRuntime(",
        "RuntimeReplyAssembly(",
        "RuntimeDeliveryAssembly(",
        "RuntimeSendGateAssembly(",
        "RuntimePeriodicAssembly(",
    ):
        check(old not in source, f"main() 不再内联 {old[:-1]}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
