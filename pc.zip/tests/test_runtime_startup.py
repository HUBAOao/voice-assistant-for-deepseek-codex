# -*- coding: utf-8 -*-
"""Startup policy remains isolated, testable and fail-open for plugins."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_startup import (  # noqa: E402
    LOW_PROFILE_DEFAULTS,
    apply_low_profile,
    start_enabled_plugins,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    lines: list[str] = []

    class Host:
        def start(self) -> dict:
            return {
                "plugins": [
                    {"name": "safe", "enabled": True},
                    {"name": "off", "enabled": False},
                ]
            }

    state = start_enabled_plugins(Host(), emit=lines.append)
    check(state["plugins"][0]["name"] == "safe", "插件状态原样返回")
    check(lines and "1 个已启用" in lines[-1], "启动只报告启用数量")

    class BrokenHost:
        def start(self) -> dict:
            raise RuntimeError("bad plugin")

    lines.clear()
    state = start_enabled_plugins(BrokenHost(), emit=lines.append)
    check(state == {} and lines and "bad plugin" in lines[-1],
          "单个插件启动失败不会阻断语音主程序")

    normal = {"model": "large-v3", "auto_tune": True}
    result = apply_low_profile(
        normal,
        "standard",
        {"why": "test", "ram": 32, "cores": 12, "cuda": True},
        Path("unused.json"),
        emit=lines.append,
    )
    check(result.changed == () and normal["model"] == "large-v3",
          "非低配机器不改用户设置")

    disabled = {"model": "large-v3", "auto_tune": False}
    result = apply_low_profile(
        disabled,
        "lite",
        {"why": "test", "ram": 8, "cores": 4, "cuda": False},
        Path("unused.json"),
        emit=lines.append,
    )
    check(not result.changed and disabled["model"] == "large-v3",
          "用户关闭自动调优后低配策略不生效")

    with tempfile.TemporaryDirectory(prefix="findeck_startup_") as raw:
        config = Path(raw) / "config.json"
        cfg = {
            "model": "large-v3",
            "auto_tune": True,
            "caption_enabled": True,
            "perf_mode": "quality",
            "anim_fps": 60,
            "fx_glow": True,
            "wave_spectrum": True,
        }
        lines.clear()
        result = apply_low_profile(
            cfg,
            "lite",
            {"why": "低内存", "ram": 7.5, "cores": 4, "cuda": False},
            config,
            emit=lines.append,
        )
        check(result.persisted and config.exists(), "首次低配调优持久化配置")
        check(cfg["model"] == "small" and cfg["auto_profile"] == "lite",
              "低配策略保留模型与档位标记")
        check(all(cfg.get(key) == value for key, value in LOW_PROFILE_DEFAULTS),
              "所有低配特效与帧率项一致")
        saved = json.loads(config.read_text(encoding="utf-8"))
        check(saved["auto_tuned"] is True and saved["perf_mode"] == "eco",
              "落盘内容与运行时快照一致")

        again = {"model": "large-v3", "auto_tune": True, "auto_tuned": True,
                 "auto_profile": "lite"}
        lines.clear()
        result = apply_low_profile(
            again,
            "lite",
            {"why": "低内存", "ram": 8, "cores": 4, "cuda": False},
            config,
            emit=lines.append,
        )
        check(result.changed and not result.persisted,
              "已标记低配的后续启动不再重复落盘")
        check(any("本次按低配参数运行" in line for line in lines),
              "后续启动明确说明只按本次参数运行")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
