# -*- coding: utf-8 -*-
"""Round 134 display-name restoration and legacy WebView retirement."""
from __future__ import annotations

import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
MANIFEST = ANDROID / "AndroidManifest.xml"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
ACTIVITY = JAVA / "NativeFinDeckActivity.java"
MAIN = JAVA / "MainActivity.java"
VER_JAVA = JAVA / "Ver.java"
PET = JAVA / "PetOverlayService.java"
NOTIFY = JAVA / "NotifyService.java"
WIDGET = JAVA / "FinDeckWidgetProvider.java"
SHORTCUTS = ANDROID / "res" / "xml" / "shortcuts.xml"
CONFIG = ROOT / "outputs" / "voice-to-text" / "config.json"
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"

ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

SEND_MIMES = {
    "text/plain",
    "text/csv",
    "application/json",
    "application/rtf",
    "application/epub+zip",
    "text/markdown",
    "text/calendar",
    "application/calendar",
    "text/x-vcard",
    "text/directory",
    "image/*",
    "application/pdf",
    "application/zip",
    "audio/*",
    "video/*",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}
VIEW_MIMES = {
    "text/*",
    "application/json",
    "application/rtf",
    "application/epub+zip",
    "text/markdown",
    "text/calendar",
    "application/calendar",
    "application/pdf",
    "application/zip",
    "audio/*",
    "video/*",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}


def activity_element(root: ET.Element, suffix: str) -> ET.Element | None:
    for node in root.iter("activity"):
        if node.get(ANDROID_NS + "name") == suffix:
            return node
    return None


def filters(activity: ET.Element | None) -> list[ET.Element]:
    return [] if activity is None else list(activity.findall("intent-filter"))


def actions(activity: ET.Element | None) -> set[str]:
    return {
        action.get(ANDROID_NS + "name", "")
        for intent_filter in filters(activity)
        for action in intent_filter.findall("action")
    }


def typed_filters(activity: ET.Element | None, action: str) -> list[ET.Element]:
    return [
        intent_filter
        for intent_filter in filters(activity)
        if any(
            node.get(ANDROID_NS + "name") == action
            for node in intent_filter.findall("action")
        )
    ]


def typed_mimes(activity: ET.Element | None, action: str) -> set[str]:
    return {
        data.get(ANDROID_NS + "mimeType")
        for intent_filter in typed_filters(activity, action)
        for data in intent_filter.findall("data")
        if data.get(ANDROID_NS + "mimeType")
    }


def has_view_scheme(
    activity: ET.Element | None,
    scheme: str,
    mime: str,
) -> bool:
    return any(
        data.get(ANDROID_NS + "scheme") == scheme
        and data.get(ANDROID_NS + "mimeType") == mime
        for intent_filter in typed_filters(activity, "android.intent.action.VIEW")
        for data in intent_filter.findall("data")
    )


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    activity_source = ACTIVITY.read_text(encoding="utf-8")
    main_source = MAIN.read_text(encoding="utf-8")
    pet_source = PET.read_text(encoding="utf-8")
    notify_source = NOTIFY.read_text(encoding="utf-8")
    widget_source = WIDGET.read_text(encoding="utf-8")
    shortcut_source = SHORTCUTS.read_text(encoding="utf-8")
    manifest_source = MANIFEST.read_text(encoding="utf-8")
    manifest = ET.fromstring(manifest_source)
    native = activity_element(manifest, ".NativeFinDeckActivity")
    legacy = activity_element(manifest, ".MainActivity")

    print("① 助手显示名")
    check(config.get("name") == "大肥鱼", "电脑配置显示名为“大肥鱼”")
    check(
        "private String headerDisplayName()" in activity_source
        and 'currentLook.optString("name", "")' in activity_source
        and '"大肥鱼"' in activity_source,
        "原生标题优先本地名，并保留“大肥鱼”默认回退",
    )
    check(
        'STALE_TEST_DISPLAY_NAME = "档位测试"' in activity_source
        and 'STALE_TEST_DISPLAY_NAME.equals(' in activity_source
        and 'currentLook.optString("name", "").trim()' in activity_source
        and 'currentLook.remove("name");' in activity_source
        and "saveNativeLook(currentLook, false);" in activity_source,
        "只对精确的旧测试名清空本地覆盖并回退电脑显示名",
    )

    print("\n② 旧 WebView 界面入口")
    check(
        "打开旧版完整设置" not in activity_source,
        "设置→关于不再暴露旧版 WebView 按钮",
    )
    check(
        "openCompatibility(" not in activity_source
        and "new Intent(this, MainActivity.class)" not in activity_source,
        "原生活动没有打开 MainActivity 的用户路径",
    )
    check(
        'EXTRA_EMERGENCY_ROLLBACK =' in main_source
        and "!source.getBooleanExtra(EXTRA_EMERGENCY_ROLLBACK, false)" in main_source
        and "target.setClass(this, NativeFinDeckActivity.class);" in main_source
        and "startActivity(target);" in main_source
        and "finish();" in main_source,
        "MainActivity 的普通或旧 PendingIntent 入口原样转交原生页",
    )
    check(
        "NativeFinDeckActivity.class" in pet_source
        and "MainActivity.class" not in pet_source,
        "桌宠通知点击进入原生页",
    )
    check(
        "NativeFinDeckActivity.class" in notify_source
        and "MainActivity.class" not in notify_source,
        "完成通知点击进入原生页",
    )
    check(
        "NativeFinDeckActivity.class" in widget_source
        and "NativeFinDeckActivity.SHORTCUT_OPEN" in widget_source
        and "MainActivity" not in widget_source,
        "桌面小组件进入原生页",
    )
    check(
        "MainActivity" not in shortcut_source
        and shortcut_source.count(
            'android:targetClass="com.hubao.voiceassistant.NativeFinDeckActivity"'
        ) == 3,
        "三个静态快捷方式继续目标原生页",
    )

    print("\n③ Manifest 日常入口")
    check(legacy is not None, "MainActivity 仍保留为紧急回滚实现")
    check(
        legacy is not None
        and legacy.get(ANDROID_NS + "exported") == "false",
        "MainActivity 不导出",
    )
    check(
        legacy is not None
        and not filters(legacy)
        and legacy.find("meta-data") is None,
        "MainActivity 没有分享、文件、文本、launcher 或快捷方式入口",
    )
    check(native is not None, "NativeFinDeckActivity 在 Manifest 中声明")
    check(
        native is not None
        and native.get(ANDROID_NS + "exported") == "true"
        and native.get(ANDROID_NS + "launchMode") == "singleTop",
        "原生活动导出并以 singleTop 接收日常意图",
    )
    check(
        native is not None
        and "android.intent.action.MAIN" in actions(native)
        and "android.intent.category.LAUNCHER"
        in {
            category.get(ANDROID_NS + "name", "")
            for intent_filter in filters(native)
            for category in intent_filter.findall("category")
        },
        "默认 launcher 指向原生活动",
    )
    check(
        native is not None
        and SEND_MIMES <= typed_mimes(native, "android.intent.action.SEND")
        and SEND_MIMES <= typed_mimes(native, "android.intent.action.SEND_MULTIPLE"),
        "原生承接全部单条/多条文字与附件分享类型",
    )
    check(
        native is not None
        and "android.intent.action.PROCESS_TEXT" in actions(native)
        and "text/plain" in typed_mimes(
            native, "android.intent.action.PROCESS_TEXT"
        ),
        "原生承接系统选中文字",
    )
    check(
        native is not None
        and VIEW_MIMES <= typed_mimes(native, "android.intent.action.VIEW")
        and all(
            has_view_scheme(native, scheme, mime)
            for mime in VIEW_MIMES
            for scheme in ("content", "file")
        ),
        "原生承接全部 content/file 文件打开类型",
    )
    check(
        native is not None
        and native.find("meta-data") is not None
        and "@xml/shortcuts" in manifest_source,
        "原生活动持有系统快捷方式元数据",
    )
    check(
        "Intent.ACTION_SEND.equals(action)" in activity_source
        and "Intent.ACTION_SEND_MULTIPLE.equals(action)" in activity_source
        and "Intent.ACTION_PROCESS_TEXT.equals(action)" in activity_source
        and "Intent.ACTION_VIEW.equals(action)" in activity_source
        and "protected void onNewIntent(Intent intent)" in activity_source,
        "原生沿用分享、文件、选中文字和新意图处理",
    )
    check(
        "SHORTCUT_SCAN" in activity_source
        and "SHORTCUT_WATCH" in activity_source
        and "ScanActivity.class" in activity_source
        and "startNotifyService()" in activity_source,
        "原生保留扫码和后天完成提醒快捷动作",
    )
    check(
        "手机朗读" not in activity_source
        and "speakLatest();" not in activity_source
        and activity_source.count("startNativeRecording();") == 1
        and "startNativeRecording();" in activity_source.split(
            "if (request == REQ_AUDIO)", 1
        )[1].split("} else if", 1)[0],
        "原生入口没有新增或暴露手机语音入口",
    )

    spec = importlib.util.spec_from_file_location("round134_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十四轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录本轮修复",
    )
    check(
        int(version.PHONE_VERSION.split(".")[-1]) >= 169,
        f"当前 v{version.PHONE_VERSION} 保留第 134 轮能力",
    )
    check(
        VER_JAVA.is_file()
        and f'VERSION_NAME = "{version.PHONE_VERSION}"'
        in VER_JAVA.read_text(encoding="utf-8"),
        f"构建版本常量已写到 v{version.PHONE_VERSION}",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"NativeFinDeckActivity" in dex
            and b"MainActivity" in dex
            and b"com.hubao.voiceassistant.EMERGENCY_ROLLBACK" in dex,
            "APK 同时保留原生主界面和受保护的紧急回滚闸",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
