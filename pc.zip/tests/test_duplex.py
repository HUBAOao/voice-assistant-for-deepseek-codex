# -*- coding: utf-8 -*-
"""Tests for barge-in state and self-audio transcript rejection."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from features.duplex import DuplexController, likely_echo  # noqa: E402


def main() -> int:
    state = DuplexController(barge_threshold=0.05, speech_frames=3)
    state.assistant_start("我来解释一下搜索选择和缓存命中率的区别")
    assert state.audio_frame(0.01) is None
    assert state.audio_frame(0.08) is None
    assert state.audio_frame(0.09) is None
    event = state.audio_frame(0.10)
    assert event and event.kind == "barge_in"
    assert not state.assistant_speaking and state.user_speaking

    assert likely_echo("我来解释一下搜索选择", "我来解释一下搜索选择和缓存命中率的区别")
    assert not likely_echo("下一首歌", "我来解释一下搜索选择")

    state.assistant_start("这是电脑上正在播放的回答")
    accepted, reason = state.accept_transcript("这是电脑上正在播放的回答")
    assert not accepted and reason == "echo"
    accepted, reason = state.accept_transcript("帮我打开设置")
    assert accepted and reason == "accepted"
    print("test_duplex: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
