# -*- coding: utf-8 -*-
"""Publisher signatures, trust decisions, and market install enforcement."""
from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def manifest(plugin_id: str) -> dict:
    return {
        "id": plugin_id,
        "name": plugin_id,
        "version": "1.0.0",
        "api": 1,
        "entrypoint": "main.py",
        "capabilities": ["stt"],
        "permissions": ["microphone"],
    }


def build_plugin(base: Path, plugin_id: str, private: dict, publisher: str) -> bytes:
    from features.plugin_signing import sign_plugin

    folder = base / plugin_id
    folder.mkdir()
    (folder / "plugin.json").write_text(
        json.dumps(manifest(plugin_id), ensure_ascii=False), encoding="utf-8"
    )
    (folder / "main.py").write_text(
        "def register(context):\n    context.register_stt(type('T', (), "
        "{'name': 'signed-stt', 'transcribe': lambda self, a, sample_rate=16000: 'ok'})())\n",
        encoding="utf-8",
    )
    sign_plugin(folder, private, publisher_id=publisher, publisher_name=publisher)
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                zf.write(path, f"{plugin_id}/{path.relative_to(folder).as_posix()}")
    return archive.getvalue()


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        os.environ["FIN_DECK_SECURITY_KEY"] = str(base / "security-key.bin")
        os.environ["FIN_DECK_SECURITY_POLICY"] = str(base / "security-policy.json")
        os.environ["FIN_DECK_SECURITY_META"] = str(base / "security-meta.json")
        os.environ["FIN_DECK_MARKET_ALLOW_HTTP"] = "1"

        from features.plugin_market import PluginMarket
        from features.plugin_registry import PluginHost
        from features.plugin_signing import (
            canonical_json,
            generate_private_key,
            public_from_private,
            sign_bytes,
            verify_bytes,
            verify_plugin,
        )

        private = generate_private_key(2048)
        public = public_from_private(private)
        probe = b"FinDeck publisher signature"
        signature = sign_bytes(private, probe)
        assert verify_bytes(public, probe, signature)
        assert not verify_bytes(public, probe + b"!", signature)

        direct = base / "direct.plugin"
        direct.mkdir()
        (direct / "plugin.json").write_text(
            json.dumps(manifest("direct.signed")), encoding="utf-8"
        )
        (direct / "main.py").write_text("def register(context): pass\n", encoding="utf-8")
        from features.plugin_signing import sign_plugin

        sign_plugin(direct, private, publisher_id="acme", publisher_name="Acme")
        checked = verify_plugin(direct)
        assert checked["signed"] and checked["valid"] and not checked["error"]
        (direct / "main.py").write_text("raise RuntimeError('tampered')\n", encoding="utf-8")
        assert not verify_plugin(direct)["valid"]

        payload = build_plugin(base, "signed.demo", private, "acme")
        managed = base / "managed"
        host = PluginHost(managed)
        preview = host.install_archive(payload)
        assert preview["needs_confirmation"]
        assert preview["plugin"]["publisher_signature"]["valid"]
        needs_trust = host.install_archive(
            payload,
            confirmed_permissions={"microphone"},
            require_signature=True,
            allowed_publishers={"acme"},
        )
        assert needs_trust["needs_trust"] is True
        assert not (managed / "signed.demo").exists()
        host.trust_publisher(public_owner := {
            "id": "acme",
            "name": "Acme",
            "public_key": public,
        }, confirm=True)
        installed = host.install_archive(
            payload,
            confirmed_permissions={"microphone"},
            require_signature=True,
            allowed_publishers={"acme"},
        )
        assert installed["installed"] and installed["publisher_signature"]["trusted"]
        assert host.publishers()[0]["key_id"] == public["key_id"]
        _ = public_owner
        signature_path = managed / "signed.demo" / ".findeck-signature.json"
        signature_bytes = signature_path.read_bytes()
        signature_path.unlink()
        removed_signature = next(
            row for row in host.snapshot()["plugins"]
            if row["id"] == "signed.demo"
        )
        assert removed_signature["sealed"] is False
        signature_path.write_bytes(signature_bytes)
        restored_signature = next(
            row for row in host.snapshot()["plugins"]
            if row["id"] == "signed.demo"
        )
        assert restored_signature["sealed"] is True

        market_payload = build_plugin(base, "market.demo", private, "acme")
        catalog = {
            "format": "FINDECK-PLUGIN-CATALOG-1",
            "name": "Test Market",
            "updated_at": int(time.time()),
            "plugins": [{
                "id": "market.demo",
                "name": "Market Demo",
                "version": "1.0.0",
                "publisher": "acme",
                "key_id": public["key_id"],
                "description": "signed market package",
                "permissions": ["microphone"],
                "url": "https://market.invalid/market.demo.zip",
                "sha256": __import__("hashlib").sha256(market_payload).hexdigest(),
            }],
        }

        import features.plugin_market as market_module

        original_fetch = market_module._fetch

        def fake_fetch(url: str, limit: int) -> bytes:
            if url.endswith("catalog.json"):
                return json.dumps(catalog).encode("utf-8")
            if url.endswith("market.demo.zip"):
                return market_payload
            raise ValueError("unexpected market URL")

        market_module._fetch = fake_fetch
        try:
            market = PluginMarket(host)
            added = market.add_source(
                "http://127.0.0.1/catalog.json", name="Local Test", confirm=True
            )
            source_id = added["source"]["id"]
            result = market.install(
                source_id,
                "market.demo",
                confirmed_permissions={"microphone"},
                confirm=True,
            )
            assert result["installed"] is True
            assert result["market"]["sha256"] == catalog["plugins"][0]["sha256"]
            tampered_catalog = canonical_json({
                **catalog,
                "plugins": [{**catalog["plugins"][0], "sha256": "0" * 64}],
            })

            def tampered_fetch(url: str, limit: int) -> bytes:
                if url.endswith("catalog.json"):
                    return tampered_catalog
                return market_payload

            market_module._fetch = tampered_fetch
            market.refresh(source_id)
            try:
                market.install(
                    source_id,
                    "market.demo",
                    confirmed_permissions={"microphone"},
                    confirm=True,
                )
            except ValueError as exc:
                assert "校验值" in str(exc)
            else:
                raise AssertionError("tampered market package was installed")
        finally:
            market_module._fetch = original_fetch
        print("test_plugin_signing: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
