# -*- coding: utf-8 -*-
"""Native activity owns all daily entry points; WebView is emergency-only."""
from __future__ import annotations

import sys
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
MANIFEST = ANDROID / "AndroidManifest.xml"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
NS = "{http://schemas.android.com/apk/res/android}"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    tree = ET.parse(MANIFEST)
    application = tree.getroot().find("application")
    activities = {
        node.get(NS + "name"): node
        for node in application.findall("activity")
    }
    legacy = activities[".MainActivity"]
    native = activities[".NativeFinDeckActivity"]
    launchers = []
    for name, activity in activities.items():
        for intent in activity.findall("intent-filter"):
            actions = {
                item.get(NS + "name") for item in intent.findall("action")
            }
            if "android.intent.action.MAIN" in actions:
                launchers.append(name)

    check(launchers == [".NativeFinDeckActivity"],
          "原生 Activity 是唯一系统 launcher")
    check(native.get(NS + "exported") == "true"
          and native.get(NS + "label") == "鳍舱",
          "原生 launcher 已导出并使用主名称")
    legacy_actions = {
        item.get(NS + "name")
        for intent in legacy.findall("intent-filter")
        for item in intent.findall("action")
    }
    check(legacy.get(NS + "exported") == "false"
          and not legacy_actions,
          "旧 WebView 不导出且没有日常入口")
    native_actions = {
        item.get(NS + "name")
        for intent in native.findall("intent-filter")
        for item in intent.findall("action")
    }
    check("android.intent.action.SEND" in native_actions
          and "android.intent.action.VIEW" in native_actions,
          "系统分享和文件打开入口由 NativeFinDeckActivity 接收")
    source = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    legacy_source = (JAVA / "MainActivity.java").read_text(
        encoding="utf-8"
    )
    check("openCompatibility" not in source
          and "MainActivity.class" not in source
          and "EXTRA_EMERGENCY_ROLLBACK" in legacy_source,
          "旧 WebView 只能通过受保护的紧急回滚参数进入")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
