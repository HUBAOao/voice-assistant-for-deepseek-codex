# -*- coding: utf-8 -*-
"""Round 126 native raw-reply card and text hierarchy parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
TOOLS_JS = (
    ROOT
    / "outputs"
    / "voice-to-text"
    / "phone_feature"
    / "ui"
    / "page_tools.js"
)
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    tools = TOOLS_JS.read_text(encoding="utf-8")
    pull_start = tools.index("async function pullRaws(")
    pull_end = tools.index("// ---- 日程页", pull_start)
    pull_raws = tools[pull_start:pull_end]
    activity = ACTIVITY.read_text(encoding="utf-8")
    load_start = activity.index("private void loadRawRepliesInto(")
    tools_start = activity.index("private void addRawRepliesTools(", load_start)
    render_start = activity.index("private void renderRawReplies(", tools_start)
    render_end = activity.index("private void shareCurrentConversation(", render_start)
    render = activity[render_start:render_end]
    tools_source = activity[tools_start:render_start]

    print("① 旧看原话最终规格")
    check(
        "#page-sched .f, #page-raws .f {" in page
        and "background:var(--panel); border:1px solid var(--line);"
        in page
        and "border-radius:12px;" in page
        and "padding:10px 12px; margin:8px 0; font-size:14px;" in page,
        "旧原话卡为 PANEL、1px 边框、12px 圆角、10/12px 内边距和 8px 外边距",
    )
    check(
        "这里是电脑回答的<b>原话</b>" in pull_raws
        and 'class="f"' in pull_raws
        and "font-size:11.5px" in pull_raws
        and "margin-top:5px;white-space:pre-wrap;line-height:1.7"
        in pull_raws,
        "旧页只有顶部说明，卡内为 11.5px 元信息和 5px 后 1.7 行高正文",
    )
    check(
        "刷新" not in pull_raws
        and "复制" not in pull_raws,
        "旧最终页原话卡内无复制 chip，页面无刷新 chip",
    )

    print("\n② 原生看原话结构")
    check(
        "刷新" not in tools_source
        and "NativeTheme.chip" not in tools_source,
        "原生移除多余刷新 chip，保留进入页面自动读取",
    )
    check(
        "NativeTheme.card(this)" not in render
        and "rawReplyCard(" in render,
        "原生原话卡不再使用通用圆角 16 卡",
    )
    check(
        "NativeTheme.chip(this, \"复制\"" not in render
        and "copyText(text)" not in render,
        "原生移除卡内常驻复制 chip",
    )
    check(
        'item.optString("at", "") + " · "' in render
        and "11.5f," in render,
        "原生时间与名称恢复 11.5px",
    )
    check(
        "NativeTheme.text(this, text, 14, NativeTheme.TEXT)" in render
        and "setLineSpacing(NativeTheme.dp(this, 2), 1.7f);" in render
        and "matchWidthTop(5)" in render,
        "原生正文恢复 14px、1.7 行高和 5px 顶部间距",
    )
    check(
        "setTextIsSelectable(true)" in render
        and "lastRawReplies" in render
        and "rawRepliesPageCurrent(" in activity,
        "选择文本、缓存保留与请求代际语义继续保留",
    )

    spec = importlib.util.spec_from_file_location(
        "round126_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any(
            "看原话" in item
            for item in version.PHONE_CHANGELOG
        ),
        f"手机端 v{version.PHONE_VERSION} 变更表记录本轮看原话收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"rawReplyCard" in dex
            and "原话已复制".encode("utf-8") not in dex,
            "APK/DEX 含新原话卡且不含旧复制提示",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
