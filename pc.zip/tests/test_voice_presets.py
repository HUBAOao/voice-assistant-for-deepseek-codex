# -*- coding: utf-8 -*-
"""验收单一本地克隆音色策略；在线音色仅按显式开关做重放。"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import numpy as np

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    import say

    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 产品策略：只保留大肥鱼本地克隆音色")
    import overlay

    names = [v[1] for v in overlay.VOICES]
    check(len(overlay.VOICES) == 1, f"音色列表只有一项（实际 {len(overlay.VOICES)}）")
    check(overlay.VOICES[0][0] == "dfy:大肥鱼"
          and "大肥鱼" in overlay.VOICES[0][1],
          "唯一音色仍是大肥鱼本地克隆")
    check(all(len(v) == 4 for v in overlay.VOICES),
          "每套音色仍保持（音色, 名字, 变调, 特效）四元组")

    print("\n② 本地特效：robot / echo / radio 不能爆音")
    sr = 16000
    seconds = np.arange(sr, dtype=np.float32) / sr
    base = (0.2 * np.sin(2 * np.pi * 220 * seconds)).astype(np.float32)
    for fx in ("", "robot", "echo", "radio"):
        out = say.apply_fx(base.copy(), sr, fx)
        check(out.size > 0 and float(abs(out).max()) <= 1.001,
              f"{fx or '（无特效）':10s} 峰值 {float(abs(out).max()):.2f}、"
              f"{out.size / sr:.2f} 秒")

    print("\n③ 外部在线音色（默认跳过，显式开关才重放）")
    if os.environ.get("FIN_DECK_ONLINE_TTS") != "1":
        print("    SKIP：在线音色不是离线交付依赖。")
        print("    重放：$env:FIN_DECK_ONLINE_TTS='1'; "
              ".\\test_voice_presets.py")
    else:
        try:
            for pitch in ("+0Hz", "+34Hz", "-30Hz"):
                say.PITCH[0] = pitch
                started = time.time()
                mp3 = say.edge_mp3("测试一二三。", "zh-CN-XiaoyiNeural", "+8%")
                audio, decoded_sr = say.decode_audio(mp3)
                check(audio.size > 0 and mp3,
                      f"{pitch} → {audio.size / decoded_sr:.2f} 秒"
                      f"（{time.time() - started:.1f}s）")
        except Exception as exc:
            print(f"    SKIP：在线音色当前不可用：{str(exc)[:80]}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
