# -*- coding: utf-8 -*-
"""Round 113 contracts for the legacy WebView serial send queue."""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
UI = APP / "phone_feature" / "ui"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    outbox_source = (UI / "outbox.js").read_text(encoding="utf-8")
    media = (UI / "media.js").read_text(encoding="utf-8")
    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    node = shutil.which("node")

    check(
        'root.FinDeckSendQueue = FinDeckSendQueue;' in outbox_source
        and 'item.state = "sending";' in outbox_source
        and 'item.state = "failed";' in outbox_source
        and 'item.state = "queued";' in outbox_source
        and "this.items.splice(index, 1);" in outbox_source,
        "发送队列模块提供排队、发送、失败、重试和完成状态",
    )
    check(
        "const webSendQueue = new FinDeckSendQueue(20);" in media
        and "async function drainWebSendQueue()" in media
        and "if (webSendDraining) return;" in media
        and "webSendQueue.start();" in media
        and "webSendQueue.complete(draft.id);" in media
        and "webSendQueue.fail(" in media,
        "默认 WebView 使用单队列串行发送，不并发抢顺序",
    )
    check(
        "if (item.uploaded) continue;" in media
        and "await uploadAttachment(item);" in media
        and "webSendQueue.markUploaded(" in media
        and "if (!result || !result.ok)" in media
        and media.index("await uploadAttachment(item);")
        < media.index("const result = await securePost(path"),
        "附件全部成功后才提交主请求，失败不会把文字冒充成功",
    )
    check(
        "stateView.textContent = \"排队中\";" in media
        and "stateView.textContent = \"发送中\";" in media
        and "stateView.textContent = \"已交给电脑\";" in media
        and "stateView.textContent = \"失败 · 重试\";" in media
        and "retryWebDraft(draft.id);" in media,
        "失败气泡保留现场并可点按重试，四类状态可见",
    )
    check(
        page.index("/phone-assets/outbox.js")
        < page.index("/phone-assets/media.js"),
        "outbox.js 在 media.js 之前加载",
    )

    if node:
        script = r"""
const fs = require("fs");
const vm = require("vm");
const source = fs.readFileSync(process.argv[1], "utf8");
vm.runInThisContext(source, {filename: "outbox.js"});
function assert(value, message) {
  if (!value) throw new Error(message);
}
const q = new FinDeckSendQueue(2);
const firstA = {id: "a", uploaded: false, file: {name: "a.txt"}};
const firstB = {id: "b", uploaded: false, file: {name: "b.txt"}};
const one = q.enqueue({text: "first", attachments: [firstA, firstB], row: {id: 1}});
const two = q.enqueue({text: "second", row: {id: 2}});
let active = q.start();
assert(active.id === one.id && active.state === "sending", "first item is active");
assert(q.start() === null, "second item cannot start concurrently");
q.markUploaded(one.id, "a", "a.txt", "/uploaded/a.txt");
q.fail(one.id, "b failed");
assert(q.snapshot()[0].attachments[0].uploaded, "first attachment uploaded");
assert(q.nextAttachment(one.id).id === "b", "retry resumes at b, not a");
assert(q.retry(one.id).state === "queued", "failed item can be retried");
active = q.start();
assert(active.id === one.id, "retry keeps original order");
q.complete(one.id);
active = q.start();
assert(active.id === two.id, "second item starts only after first completes");
q.complete(two.id);
assert(q.items.length === 0, "accepted items leave the queue");
try {
  q.enqueue({text: "x"});
  q.enqueue({text: "y"});
  q.enqueue({text: "z"});
  throw new Error("queue limit was not enforced");
} catch (error) {
  assert(String(error.message).includes("最多同时排队"), "bounded queue");
}
console.log("queue-contract-ok");
"""
        result = subprocess.run(
            [node, "-e", script, str(UI / "outbox.js")],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
        )
        check(
            result.returncode == 0 and "queue-contract-ok" in result.stdout,
            "Node 行为测试：串行、重试续传、完成后出队和有界队列"
            + ("" if result.returncode == 0 else f"：{result.stderr[:200]}"),
        )
    else:
        print("  - 没有 node，跳过队列行为测试")

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
