# -*- coding: utf-8 -*-
"""Default WebView bridge lifecycle and ActivityResult regressions."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
APP = ROOT / "outputs" / "voice-to-text"
PAGE = APP / "phone_page.html"
SETTINGS = APP / "phone_feature" / "ui" / "settings.js"
APK = ROOT / "outputs" / "语音助手-手机端.apk"
VERSION = APP / "version.py"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = (JAVA / "MainActivity.java").read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    settings = SETTINGS.read_text(encoding="utf-8")

    print("① 页面重载与新导航不能互相串页")
    check("private volatile int navigationGeneration" in source
          and "private boolean isCurrentNavigation(" in source,
          "WebView 导航有单调代际和当前代际判定")
    check("private volatile String activeNavigationUrl" in source
          and "private boolean isCurrentPageUrl(" in source
          and source.count("!isCurrentPageUrl(") >= 4,
          "迟到页面错误、提交与完成回调还会核对当前端点")
    check("private void loadRoute(" in source
          and "navigationGeneration++" in source,
          "扫码、改地址、重试和新路由走同一条带代际的加载入口")
    start_load = source[
        source.index("private void startSmartLoad()"):
        source.index("private void startNotifyService()")
    ]
    check("final int navigationGeneration = beginNavigation(" in start_load
          and start_load.count("isCurrentNavigation(navigationGeneration)") >= 2,
          "启动探路线程和 12 秒兜底都只对本次导航生效")
    check("if (!isCurrentNavigation(navigationGeneration))" in start_load,
          "后台探路结果迟到时不会把用户刚选的地址切回去")
    check("loadRoute(url);" in source
          and "loadRoute(DEFAULT_URL);" in source,
          "扫码和恢复出厂地址都作废旧导航")

    print("\n② commitVisible 与 finished 不能重复交付同一次分享")
    check("private boolean sharedTextPumpInFlight" in source
          and "private boolean sharedAttachmentPumpInFlight" in source,
          "分享文字和附件各有独立在途锁")
    text_pump = source[
        source.index("private void pumpSharedText()"):
        source.index("@Override\n    protected void onNewIntent")
    ]
    file_pump = source[
        source.index("private void pumpSharedAttachment()"):
        source.index("private static boolean isOpenableTextMime")
    ]
    check("sharedTextPumpInFlight" in text_pump
          and "sharedTextPumpInFlight = true;" in text_pump
          and "sharedTextPumpInFlight = false;" in text_pump,
          "分享文字同一时刻只有一个 evaluateJavascript 在途")
    check("sharedAttachmentPumpInFlight" in file_pump
          and "sharedAttachmentPumpInFlight = true;" in file_pump
          and "sharedAttachmentPumpInFlight = false;" in file_pump,
          "分享附件同一时刻只读取并交付一项")
    check("pumpSharedText();" in source.split(
        "public void onPageCommitVisible", 1
    )[1].split("public void onPageFinished", 1)[0]
          and "pumpSharedText();" in source.split(
        "public void onPageFinished", 1
    )[1].split("web.setBackgroundColor", 1)[0],
          "两个页面完成回调仍都尝试交付，但由在途锁去重")

    print("\n③ 默认 WebView 的多选附件保持多选")
    check('id="imgfile" accept="image/*" multiple' in page
          and 'id="sendfile" multiple' in page,
          "页面图片和普通文件输入框本身都是多选")
    chooser = source[
        source.index("public boolean onShowFileChooser"):
        source.index("web.addJavascriptInterface", source.index(
            "public boolean onShowFileChooser"))
    ]
    check("FileChooserParams.MODE_OPEN_MULTIPLE" in source
          and "Intent.EXTRA_ALLOW_MULTIPLE" in chooser,
          "file chooser 按网页 mode 打开系统多选")
    result = source[
        source.index("if (code == REQ_FILE)"):
        source.index("if (code == 9 && result == RESULT_OK")
    ]
    check("selectedFileUris(data)" in result
          and "getClipData()" in source,
          "ActivityResult 同时读取单项与 ClipData 多项结果")
    check("filePathCallback = null;" in result,
          "取消、多选和单项结果都会释放 chooser 回调")

    print("\n④ 页面失败、HTTP 错误与外网兜底不互相覆盖")
    check("onReceivedHttpError(" in source,
          "主页面 HTTP 4xx/5xx 不再当作连接成功")
    check("private boolean maybeAutoFallback()" in source
          and "return true;" in source[source.index(
              "private boolean maybeAutoFallback()"):
              source.index("private void toast(")],
          "自动切外网会明确报告已开始新导航")
    offline = source[
        source.index("private void showOfflinePage("):
        source.index("private String vpnDiagnosisHtml(")
    ]
    check("maybeAutoFallback();" not in offline,
          "离线页不会在启动外网导航后又把它覆盖成离线页")

    print("\n⑤ 系统权限页返回和销毁生命周期")
    check("private boolean startPetAfterOverlayPermission" in source
          and "resumePendingPetStart()" in source,
          "桌宠授权页返回后自动继续用户刚才的开启动作")
    check("onNativeResume" in source and "onNativeResume" in settings,
          "通知、桌宠和更新相关系统页返回后刷新旧 WebView 现场")
    destroy = source[source.index("protected void onDestroy()"):
                     source.index("/** 改地址：")]
    check("stopActiveRecording();" in destroy,
          "销毁时停止并释放正在使用的麦克风，不发送半段录音")
    check("filePathCallback.onReceiveValue(null)" in destroy
          and "web.removeJavascriptInterface(\"VoiceApp\")" in destroy
          and "web.stopLoading()" in destroy
          and "web.destroy()" in destroy,
          "销毁时释放文件选择回调、JS 桥、WebView 加载与渲染")
    check("ui.removeCallbacksAndMessages(null)" in destroy,
          "销毁时清掉探路、分享泵和启动页延时")

    print("\n⑥ 版本、JS 语法与 APK")
    spec = importlib.util.spec_from_file_location("round116_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    phone_parts = tuple(
        int(part) for part in version.PHONE_VERSION.split(".")
    )
    check(phone_parts >= (1, 150),
          f"手机端版本不低于 v1.150（当前 v{version.PHONE_VERSION}）")
    check(APK.is_file(), "当前手机端 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for marker in (
            b"android.intent.extra.ALLOW_MULTIPLE",
            b"selectedFileUris",
            b"sharedAttachmentPumpInFlight",
            b"onNativeResume",
            b"startPetAfterOverlayPermission",
            b"removeJavascriptInterface",
        ):
            check(marker in dex, f"APK/DEX 包含 {marker.decode('ascii')}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
