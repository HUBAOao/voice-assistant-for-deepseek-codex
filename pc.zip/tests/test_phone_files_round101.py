# -*- coding: utf-8 -*-
"""Round 101 file-transfer page parity and lifecycle contracts."""
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "NativeFinDeckActivity.java"
)
API = ACTIVITY.with_name("NativeApiClient.java")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    native = ACTIVITY.read_text(encoding="utf-8")
    api = API.read_text(encoding="utf-8")
    media = (APP / "phone_feature" / "ui" / "media.js").read_text(
        encoding="utf-8"
    )
    media_routes = (
        APP / "phone_feature" / "media_routes.py"
    ).read_text(encoding="utf-8")

    render = native.split("private void renderFiles(", 1)[1].split(
        "private void addRemoteFile(", 1
    )[0]
    loader = native.split("private void loadFilesInto(", 1)[1].split(
        "private void setFilesNotice(", 1
    )[0]
    request = native.split("private void requestFilesPart(", 1)[1].split(
        "private void setFilesNotice(", 1
    )[0]
    upload = native.split("private void uploadFileDirect(", 1)[1].split(
        "private String filePageSizeText(", 1
    )[0]
    player = native.split("private void addAudioFile(", 1)[1].split(
        "private void downloadRemoteMedia(", 1
    )[0]
    close_page = native.split("private void closePageOverlay()", 1)[1].split(
        "private void discardClosingPageOverlay()", 1
    )[0]
    back = native.split("public void onBackPressed()", 1)[1].split(
        "protected void onDestroy()", 1
    )[0]
    pause = native.split("protected void onPause()", 1)[1].split(
        "public void onBackPressed()", 1
    )[0]

    checks = [
        (
            "文件页先显示读取现场，再并行请求文件和试听列表",
            'buildLoadingPage("正在读取文件…")' in native
            and "AtomicInteger remaining = new AtomicInteger(2);" in loader
            and 'requestFilesPart(list, generation, responses, remaining, 0, true);'
            in loader
            and 'requestFilesPart(list, generation, responses, remaining, 1, false);'
            in loader,
        ),
        (
            "文件与试听各自显示错误卡和空态，不因一边失败提前截断整页",
            "if (!files.ok() && !audios.ok())" not in render
            and '"试听列表没读出来"' in render
            and '"电脑文件没读出来"' in render
            and "还没有试听文件" in render
            and "还没有文件" in render
            and render.index('"试听列表没读出来"')
            < render.index('"电脑文件没读出来"'),
        ),
        (
            "断线时仍保留传到电脑和跟电脑要文件入口",
            '"传到电脑"' in render
            and '"刷新"' in render
            and "跟电脑要文件" in render
            and "if (files.ok())" in render,
        ),
        (
            "文件和试听请求绑定列表与代际，关闭重开后旧响应不能写回",
            "generation != filesRequestGeneration || list != filesActiveList"
            in render
            and request.count("generation != filesRequestGeneration") >= 1
            and request.count("list != filesActiveList") >= 1
            and "filesActiveList = list;" in loader,
        ),
        (
            "文件回写使用独立主线程队列，退后台不会丢掉加载完成现场",
            "private final Handler filesUi" in native
            and "filesUi.post(" in loader
            and "filesUi.removeCallbacksAndMessages(null);" not in pause
            and "filesUi.removeCallbacksAndMessages(null);" in native,
        ),
        (
            "上传使用系统文件选择器并在每次选择时锁定文件页代际",
            "new Intent(Intent.ACTION_OPEN_DOCUMENT)" in render
            and "pendingFilesList = list;" in render
            and "pendingFilesGeneration = filesRequestGeneration;" in render
            and "REQ_UPLOAD_FILE" in native,
        ),
        (
            "上传防重复提交，取消不误报，成功页内提示并从零刷新",
            "if (filesMutationInFlight)" in render
            and "if (filesMutationInFlight) return;" in loader
            and "已取消选择，没有上传文件。" in native
            and 'filesNotice = "传好了：" + savedName' in upload
            and "loadFilesInto(target);" in upload,
        ),
        (
            "文件页按旧服务端上限流式上传 200 MB，不再把整文件读进内存",
            "MAX_FILE_PAGE_UPLOAD = 200L * 1024L * 1024L" in native
            and "api.postStream(" in upload
            and "NativeApiClient.StreamSource" in upload
            and "readLimited(uri, MAX_ATTACHMENT)" not in upload
            and "interface StreamSource" in api
            and "setFixedLengthStreamingMode(length);" in api
            and 'MAX_UPLOAD_BYTES = 200 * 1024 * 1024' in media_routes,
        ),
        (
            "试听状态按播放代际隔离，切换、刷新和离页都归位按钮",
            "final int playbackGeneration = ++filePlayerGeneration;" in player
            and player.count("playbackGeneration != filePlayerGeneration") >= 3
            and "filePlayerPlayingState" in native
            and "filePlayerButton.setText(\"▶ 试听\");" in native
            and "stopFilePlayer();" in pause,
        ),
        (
            "文件页输入法可见时第一次返回只收键盘，第二次才关页面",
            "if (isHistoryKeyboardVisible()) {\n                hideRootKeyboard();"
            in back
            and "closePageOverlay();" in back
            and "hideRootKeyboard();" in close_page,
        ),
        (
            "关闭或切到另一子页会取消文件回写、上传锁、试听和旧状态",
            "filesUi.removeCallbacksAndMessages(null);" in close_page
            and "filesRequestGeneration++;" in close_page
            and "filesMutationGeneration++;" in close_page
            and "filesMutationInFlight = false;" in close_page
            and "filesActiveList = null;" in close_page
            and "stopFilePlayer();" in close_page
            and "filesNotice = \"\";" in native,
        ),
        (
            "旧 media.js 的文件、试听、上传接口仍由原生页完整覆盖",
            all(token in media for token in (
                'pullFiles()', 'pullAudios()', 'securePostRaw("/api/upload',
                'getElementById("askbtn")', 'getElementById("upfile")',
            ))
            and all(route in media_routes for route in (
                'path == "/api/files"', 'path == "/api/audios"',
                'path == "/api/upload"',
            ))
            and all(text in native for text in (
                "文件收发", "电脑文件", "跟电脑要文件", "传到电脑",
                "刷新试听",
            )),
        ),
    ]

    bad = 0
    for text, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + text)
        if not ok:
            bad += 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
