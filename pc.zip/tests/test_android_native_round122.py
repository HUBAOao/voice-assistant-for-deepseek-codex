# -*- coding: utf-8 -*-
"""Round 122 native child-page header and body geometry parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    def ordered(source: str, *parts: str) -> bool:
        indexes = [source.find(part) for part in parts]
        return all(index >= 0 for index in indexes) and indexes == sorted(indexes)

    page = PAGE.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    start = activity.index("private void pageOverlay(")
    end = activity.index("private void closePageOverlay()", start)
    overlay = activity[start:end]
    tile_start = activity.index("private int tileIcon(String label)")
    tile_end = activity.index("private void addQuick(", tile_start)
    tiles = activity[tile_start:tile_end]
    header_start = activity.index("private View buildHeader()")
    header_end = activity.index("private View buildFooter()", header_start)
    main_header = activity[header_start:header_end]
    shots_start = activity.index("private void renderShots(")
    shots_end = activity.index("private void durationOptionsAdd(", shots_start)
    shots = activity[shots_start:shots_end]

    print("① 旧页面最终子页规格")
    check(
        ".phead { display:flex; align-items:center; gap:10px; padding:12px 14px;"
        in page,
        "旧子页头为 10px 间距和 12/14px 内边距",
    )
    check(
        ".phead b { font-size:15px; }" in page
        and ".page .phead b" in page
        and "font-size:var(--fs-mid) !important;" in page,
        "旧子页标题最终字号为 14px",
    )
    check(
        '<span class="back" data-back>← 返回</span><span class="x" data-back>✕</span>'
        in page,
        "旧子页头标题在左、返回和关闭在右",
    )
    check(
        ".phead .x { color:var(--fg); background:var(--line);"
        in page
        and "border-radius:8px; font-size:14px" in page,
        "旧关闭按钮为正文色、主题分隔线底色和 8px 圆角",
    )
    check(
        ".pbody { flex:1; overflow-y:auto; padding:10px 12px 20px; }" in page,
        "旧子页正文内边距为 10/12/20px",
    )

    print("\n② 原生子页结构")
    check(
        "ImageView pageIcon" in overlay
        and "pageIcon.setImageResource(tileIcon(title));" in overlay,
        "原生标题左侧恢复旧页对应的页面图标",
    )
    check(
        ordered(overlay, "header.addView(titleGroup)", "header.addView(back)")
        and '"← 返回"' in overlay,
        "原生顺序恢复为标题在左、返回在右",
    )
    check(
        "NativeTheme.text(this, title, 14, NativeTheme.TEXT)" in overlay,
        "原生子页标题字号与旧页 14px 对齐",
    )
    check(
        "header.setPadding(NativeTheme.dp(this, 14), NativeTheme.dp(this, 12),\n"
        "                NativeTheme.dp(this, 14), NativeTheme.dp(this, 12));"
        in overlay,
        "原生子页头内边距与旧页一致",
    )
    check(
        "NativeTheme.PANEL" in overlay
        and "pageDivider.setBackgroundColor(NativeTheme.LINE);" in overlay,
        "原生子页头恢复旧页背景色和 1px 底部分隔线",
    )
    check(
        'NativeTheme.text(this, "✕", 14, NativeTheme.TEXT)' in overlay
        and "NativeTheme.LINE, 8, this" in overlay,
        "原生关闭按钮恢复旧页字号、颜色、底色和圆角",
    )
    check(
        "list.setPadding(NativeTheme.dp(this, 12), NativeTheme.dp(this, 10),"
        in overlay
        and "NativeTheme.dp(this, 12), NativeTheme.dp(this, 20)"
        in overlay,
        "原生子页正文内边距与旧页一致",
    )
    check(
        'if ("文件收发".equals(label)) return R.drawable.ic_findeck_folder;'
        in tiles
        and 'if ("连接状态".equals(label)) return R.drawable.ic_findeck_status;'
        in tiles,
        "文件与连接状态子页也使用旧页对应图标",
    )

    print("\n③ 主聊天页头")
    check(
        "height:52px !important;" in page
        and "header { padding:10px 14px;"
        in page,
        "旧主聊天页头固定 52px 高、10/14px 内边距",
    )
    check(
        "header .av { width:30px; height:30px;"
        in page
        and "#filterbtn svg" in page
        and "width:18px; height:18px;" in page,
        "旧页头头像为 30px、漏斗图标为 18px",
    )
    check(
        "header.setMinimumHeight(NativeTheme.dp(this, 52));" in main_header
        and "header.setPadding(NativeTheme.dp(this, 14), NativeTheme.dp(this, 10),"
        in main_header,
        "原生页头恢复 52px 高度与 10/14px 内边距",
    )
    check(
        "currentLook.optString(\"avAi\", \"icon\"), 30"
        in main_header
        and "NativeTheme.dp(this, 30), NativeTheme.dp(this, 30)"
        in main_header,
        "原生页头头像恢复 30px",
    )
    check(
        'NativeTheme.text(this, "连接中", 11, NativeTheme.DIM)'
        in main_header,
        "原生状态文字恢复旧页 11px",
    )
    check(
        "headerFilter.setPadding(NativeTheme.dp(this, 6), NativeTheme.dp(this, 6),"
        in main_header,
        "原生漏斗保留旧页 18px 图标可见尺寸",
    )

    print("\n④ 电脑屏幕页")
    check(
        "#screenres {" in page
        and "font:9px/1.3 ui-monospace,Consolas,monospace;" in page,
        "旧屏幕信息为右对齐 9px 等宽小字",
    )
    check(
        "#shotstage {" in page
        and "aspect-ratio:2/1; min-height:140px; max-height:58vh;" in page
        and "border:1px solid rgba(255,255,255,.08); background:#0b0d11;"
        in page,
        "旧预览区为 2:1、最小 140px 的直角细边框舞台",
    )
    check(
        "#shotcontrols button {" in page
        and "height:52px; padding:0 12px; border:0; border-radius:0;"
        in page,
        "旧截图/录屏为 52px 直角连续操作",
    )
    check(
        'display.optInt("count", 1) + " 屏 · "' in shots
        and "9,\n                NativeTheme.DIM"
        in shots
        and "screenInfo.setGravity(Gravity.END);" in shots,
        "原生屏幕信息恢复 9px 右对齐",
    )
    check(
        "private int shotStageHeightDp()" in activity
        and "shotStageHeightDp()" in shots
        and "new GradientDrawable()" in shots
        and "setStroke(" in shots
        and "NativeTheme.dp(this, 1)," in shots,
        "原生预览区恢复 2:1 高度、直角细边框",
    )
    check(
        ordered(
            shots,
            "list.addView(stage",
            "list.addView(controls",
            "list.addView(meta",
        ),
        "原生录像信息移到操作区之后",
    )
    check(
        "shotControlButton(" in activity
        and '"shot-control-label"' in activity
        and "NativeTheme.dp(this, 52)" in shots,
        "原生截图/录屏恢复 52px 图标文字控件",
    )
    check(
        "option.setBackground(NativeTheme.rounded(" in shots
        and "value == seconds[0]" in shots
        and ": Color.TRANSPARENT," in shots
        and "NativeTheme.ACCENT_SOFT" in shots,
        "原生 5/8/15 秒选项恢复直角连续选中态",
    )

    print("\n⑤ 聊天历史搜索关闭按钮")
    check(
        "#historyClose {" in page
        and "height:44px; padding:0; border:0; border-radius:0;" in page
        and "font-size:17px;" in page,
        "旧历史关闭按钮为 44px、17px 方形按钮",
    )
    history_start = activity.index("private void showHistory()")
    history_end = activity.index("private void animateHistoryPanel(", history_start)
    history = activity[history_start:history_end]
    check(
        'NativeTheme.text(this, "✕", 17, NativeTheme.DIM)' in history,
        "原生历史关闭按钮恢复旧页 ✕ 和 17px 字号",
    )

    spec = importlib.util.spec_from_file_location("round122_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any(
            "原生布局组收口" in item
            for item in version.PHONE_CHANGELOG
        ),
        f"手机端 v{version.PHONE_VERSION} 变更表记录本轮布局收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"shotStageHeightDp" in dex
            and b"shotControlButton" in dex
            and b"shot-control-label" in dex,
            "APK/DEX 包含屏幕舞台和连续操作控件",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
