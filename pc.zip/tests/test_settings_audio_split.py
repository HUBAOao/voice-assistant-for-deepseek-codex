# -*- coding: utf-8 -*-
"""Sound controls stay behind the historical settings composition."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    from overlay_feature.settings_audio_mixin import OverlaySettingsAudioMixin
    from overlay_feature.settings_content_mixin import OverlaySettingsContentMixin

    for name in (
        "build_sound",
        "_output_devices",
        "choose_output_device",
        "set_output_device",
        "toggle_voice_drawer",
        "select_voice",
        "refresh_voice_rows",
    ):
        assert hasattr(OverlaySettingsContentMixin, name), name
        assert getattr(OverlaySettingsContentMixin, name) is getattr(
            OverlaySettingsAudioMixin, name
        ), name

    class DummyRow:
        def config(self, **kwargs):
            self.last = kwargs

    class Probe(OverlaySettingsContentMixin):
        def __init__(self):
            self.voice_rows = {0: DummyRow(), 1: DummyRow()}
            self.voice_index = 1
            self.button_color = "#123456"

    probe = Probe()
    probe.refresh_voice_rows()
    assert probe.voice_rows[0].last["bg"] != probe.button_color
    assert probe.voice_rows[1].last["bg"] == probe.button_color

    print("test_settings_audio_split: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
