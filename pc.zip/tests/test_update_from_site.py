# -*- coding: utf-8 -*-
"""验收「更新以下载页为准」+「手机气泡无入场动画」。

更新的规矩：两边的 APP 都读**下载页那份清单**（/dl/version.json），
网页那边一刷新，两边的"该更新了"提示就跟着变 —— 不是两边各记一套。
气泡的规矩：不淡入、不缩放、不位移；新消息直接以最终状态出现。
"""
from __future__ import annotations

import importlib.util
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(module: str, path: Path):
    spec = importlib.util.spec_from_file_location(module, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import version
    import self_update

    print("① 更新清单里该有的东西")
    dp = load("download_page_mod", APP / "download_page.py")
    mf = dp.manifest()
    check(mf["pc"]["version"] == version.APP_VERSION,
          f"电脑端版本对上（{mf['pc']['version']}）")
    check(mf["phone"]["version"] == version.PHONE_VERSION,
          f"手机端版本对上（{mf['phone']['version']}）")
    check(mf["pc"]["url"] and mf["phone"]["url"], "两个下载地址都在")
    check(bool(mf["pc"]["notes"]) and bool(mf["phone"]["notes"]), "两边都带最近的更新说明")
    check(mf["pc"]["update_url"] != "" or dp.find_update_zip() is None,
          "有更新包时会给电脑端一个 update_url（一键更新用）")

    print("② 电脑端：读到新版要提示，没新版就说已是最新")
    got = self_update.check({"phone_port": 8765})
    check(got["src"].endswith("version.json") and "hubaoao.github.io" in got["src"],
          f"默认读的是 GitHub 那个网站：{got['src']}")
    check(not got["pc_new"], f"跟本机同版本时不提示（现在 v{version.APP_VERSION}）")
    old = list(version.CHANGELOG)
    version.CHANGELOG.append("测试用的假更新")
    try:
        fake = {"ok": True, "pc": {"version": version.APP_VERSION}, "phone": {}}
        newer = self_update._num(version.APP_VERSION) > self_update._num("1.0")
        check(newer, "版本比较用最后那一段数字（1.128 > 1.0）")
        notes = self_update.notes_text({"notes": [{"version": "1.999", "text": "假的新版"}]})
        check("假的新版" in notes, "改动说明能摆进弹窗")
    finally:
        version.CHANGELOG[:] = old

    print("③ 相对地址要能拼成完整地址（不然下不到更新包）")
    r = self_update.resolve("https://hubaoao.github.io/x/version.json", "update.zip")
    check(r == "https://hubaoao.github.io/x/update.zip", f"拼出来：{r}")
    r2 = self_update.resolve("https://例子.com/dl/version.json", "app.apk")
    check(r2.startswith("https://") and r2.endswith("/dl/app.apk"), f"远程也一样：{r2}")
    check(self_update.resolve("http://a/b.json", "http://c/d.zip") == "http://c/d.zip",
          "清单里直接给完整地址也认")

    print("④ 公网清单与发布阈值")
    try:
        mf = self_update.fetch(
            "https://hubaoao.github.io/voice-assistant-for-deepseek-codex/"
            f"version.json?audit={int(time.time())}",
            timeout=20)
        check(mf.get("ok") and (mf.get("pc") or {}).get("version"),
              f"网站上的版本：{(mf.get('pc') or {}).get('version')}")
        import site_publish

        due = site_publish.pending() >= site_publish.every()
        public_pc = str((mf.get("pc") or {}).get("version") or "")
        public_phone = str((mf.get("phone") or {}).get("version") or "")
        if due:
            check(public_pc == version.APP_VERSION,
                  f"达到发布阈值后公网电脑端应与本地一致（v{version.APP_VERSION}）")
        elif public_pc == version.APP_VERSION:
            check(site_publish.published_version() == version.APP_VERSION,
                  "公网电脑端已与本地一致，发布状态也同步")
        else:
            check(public_pc == site_publish.published_version(),
                  "未到阈值时公网保持上次正式发布版本")
        if public_phone == version.PHONE_VERSION:
            check(True, f"公网手机端与本地一致（v{version.PHONE_VERSION}）")
        else:
            check(self_update._num(public_phone)
                  <= self_update._num(version.PHONE_VERSION),
                  f"公网手机端停在旧版 v{public_phone}，本机 {version.PHONE_VERSION} "
                  "按发布策略尚未上站")
        check("stats" not in mf, "清单里不再有下载量那种东西（已清掉）")
    except Exception as exc:
        print("     （这次没连上公网，跳过：%s）" % str(exc)[:60])

    print("⑤ 手机也读同一份清单")
    core_js = (APP / "phone_feature" / "ui" / "page_core.js").read_text(
        encoding="utf-8"
    )
    tools_js = (APP / "phone_feature" / "ui" / "page_tools.js").read_text(
        encoding="utf-8"
    )
    media_js = (APP / "phone_feature" / "ui" / "media.js").read_text(
        encoding="utf-8"
    )
    check("updateManifest" in media_js and '/version.json' in media_js,
          "手机那个「检查更新」读的是下载页清单（公网那份优先，退回本机那份）")
    check("siteBase" in tools_js and "d.update_url" in tools_js,
          "电脑设置里填了网站网址的话，手机也去读那个网站")
    check('fetch("/api/version?k="' in core_js,
          "清单读不到时还有老接口兜底（不会因为一个接口哑掉）")

    print("⑥ 手机气泡：新消息直接以最终状态出现")
    page_src = (APP / "phone_page.html").read_text(encoding="utf-8")
    chat_js = (APP / "phone_feature" / "ui" / "chat.js").read_text(
        encoding="utf-8"
    )
    core_js = (APP / "phone_feature" / "ui" / "page_core.js").read_text(
        encoding="utf-8"
    )
    check("@keyframes born" not in page_src,
          "已移除旧的出生缩放关键帧")
    check(".row.born" not in page_src
          and 'classList.add("born")' not in chat_js,
          "新消息不再挂 born 类或注册无用的动画定时器")
    check("look.anim !== false" in core_js and "noanim" in core_js,
          "外观设置仍保留动画偏好，避免误删设置状态")
    check("playPushIn" in chat_js,
          "旧消息上推仍使用现有 FLIP 过渡，不靠逐气泡入场动画")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
