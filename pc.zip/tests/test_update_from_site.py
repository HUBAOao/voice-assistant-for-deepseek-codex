# -*- coding: utf-8 -*-
"""验收「更新以下载页为准」+「新消息的出生动画」。

更新的规矩：两边的 APP 都读**下载页那份清单**（/dl/version.json），
网页那边一刷新，两边的"该更新了"提示就跟着变 —— 不是两边各记一套。
气泡动画的规矩：从小点长到**正常大小**，不铺满屏幕，而且能被"气泡动画"开关关掉。
"""
from __future__ import annotations

import importlib.util
import json
import re
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(module: str, path: Path):
    spec = importlib.util.spec_from_file_location(module, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import version
    import self_update

    print("① 更新清单里该有的东西")
    dp = load("download_page_mod", APP / "download_page.py")
    mf = dp.manifest()
    check(mf["pc"]["version"] == version.APP_VERSION,
          f"电脑端版本对上（{mf['pc']['version']}）")
    check(mf["phone"]["version"] == version.PHONE_VERSION,
          f"手机端版本对上（{mf['phone']['version']}）")
    check(mf["pc"]["url"] and mf["phone"]["url"], "两个下载地址都在")
    check(bool(mf["pc"]["notes"]) and bool(mf["phone"]["notes"]), "两边都带最近的更新说明")
    check(mf["pc"]["update_url"] != "" or dp.find_update_zip() is None,
          "有更新包时会给电脑端一个 update_url（一键更新用）")

    print("② 电脑端：读到新版要提示，没新版就说已是最新")
    got = self_update.check({"phone_port": 8765})
    check(got["src"].endswith("/dl/version.json"),
          f"默认读的是下载页那份：{got['src']}")
    check(not got["pc_new"], f"跟本机同版本时不提示（现在 v{version.APP_VERSION}）")
    old = list(version.CHANGELOG)
    version.CHANGELOG.append("测试用的假更新")
    try:
        fake = {"ok": True, "pc": {"version": version.APP_VERSION}, "phone": {}}
        newer = self_update._num(version.APP_VERSION) > self_update._num("1.0")
        check(newer, "版本比较用最后那一段数字（1.128 > 1.0）")
        notes = self_update.notes_text({"notes": [{"version": "1.999", "text": "假的新版"}]})
        check("假的新版" in notes, "改动说明能摆进弹窗")
    finally:
        version.CHANGELOG[:] = old

    print("③ 相对地址要能拼成完整地址（不然下不到更新包）")
    r = self_update.resolve("http://127.0.0.1:8765/dl/version.json", "update.zip")
    check(r == "http://127.0.0.1:8765/dl/update.zip", f"拼出来：{r}")
    r2 = self_update.resolve("https://例子.com/dl/version.json", "app.apk")
    check(r2.startswith("https://") and r2.endswith("/dl/app.apk"), f"远程也一样：{r2}")
    check(self_update.resolve("http://a/b.json", "http://c/d.zip") == "http://c/d.zip",
          "清单里直接给完整地址也认")

    print("④ 真机接口：清单和更新包都下得下来")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8815)
    if link.start():
        try:
            time.sleep(0.2)
            with urllib.request.urlopen("http://127.0.0.1:8815/dl/version.json",
                                        timeout=10) as r:
                live = json.loads(r.read().decode("utf-8"))
            check(live.get("ok") and live["pc"]["version"] == version.APP_VERSION,
                  "不带令牌就能读到更新清单")
            if dp.find_update_zip():
                with urllib.request.urlopen("http://127.0.0.1:8815/dl/update.zip",
                                            timeout=60) as r:
                    body = r.read()
                check(body[:2] == b"PK" and len(body) > 100 * 1024,
                      f"电脑端更新包下得下来（{len(body) / 1024:.0f} KB）")
            # 两份数据必须是一回事（页面和清单不能各说各话）
            with urllib.request.urlopen("http://127.0.0.1:8815/dl", timeout=10) as r:
                page = r.read().decode("utf-8", "replace")
            check(version.APP_VERSION in page and live["pc"]["version"] in page,
                  "下载页上写的版本 == 清单里的版本")
        finally:
            link.stop()
    else:
        check(False, "手机入口起不来")

    print("⑤ 手机也读同一份清单")
    page_src = (APP / "phone_link.py").read_text(encoding="utf-8")
    check('fetch("/dl/version.json")' in page_src,
          "手机那个「检查更新」读的是下载页清单")
    check('fetch("/api/version?k="' in page_src,
          "清单读不到时还有老接口兜底（不会因为一个接口哑掉）")

    print("⑥ 新气泡的出生动画：小点 → 正常大小")
    check("@keyframes born" in page_src, "有 born 动画")
    body = page_src.split("@keyframes born")[1].split("}")[0] + page_src.split("@keyframes born")[1][:400]
    moves = [float(x) for x in re.findall(r"scale\(([\d.]+)\)", body)]
    check(moves and abs(moves[-1] - 1.0) < 1e-6,
          f"最后停在正常大小 scale({moves[-1] if moves else '?'})（不是铺满屏幕）")
    check(max(moves) <= 1.03, f"最大只放到 scale({max(moves)})，长句也不撑出边框")
    check(min(moves) <= 0.1, f"从一个小点开始 scale({min(moves)})")
    check("row.classList.add(\"born\")" in page_src, "新消息才会触发这个动画")
    check("look.anim !== false" in page_src, "设置里的「气泡动画」关掉就不做")
    check("body.noanim .row.born" in page_src, "关掉动画时 CSS 也不再动")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
