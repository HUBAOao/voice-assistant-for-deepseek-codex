# -*- coding: utf-8 -*-
"""Round 131 native plus panel and footer geometry parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
RUNTIME_JS = (
    ROOT
    / "outputs"
    / "voice-to-text"
    / "phone_feature"
    / "ui"
    / "page_runtime.js"
)
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    runtime = RUNTIME_JS.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    footer = method_block(
        activity,
        "private View buildFooter()",
        "private boolean isComposerComposing()",
    )
    panel = method_block(
        activity,
        "private LinearLayout buildPlusPanel()",
        "private void setPlusOpen(",
    )
    toggle = method_block(
        activity,
        "private void setPlusOpen(",
        "private int tileIcon(",
    )

    print("① 旧页功能面板与底栏最终规格")
    check(
        "grid-template-columns:repeat(4,minmax(0,1fr)) !important"
        in page
        and "gap:0 !important; padding:0 !important" in page,
        "功能格为四列满铺、零格缝和零内部间距",
    )
    check(
        "min-height:86px !important" in page
        and "padding:10px 0 9px !important" in page
        and "gap:5px !important" in page,
        "功能格为 86px 高、10/9px 内边距和 5px 图文间距",
    )
    check(
        "height:43px !important; min-height:43px !important" in page
        and "border-radius:0 !important" in page
        and "background:transparent !important" in page
        and "svg { width:24px !important; height:24px !important; }"
        in page,
        "图标框为 43px 透明直角，图标 24px",
    )
    check(
        "grid-template-columns:minmax(0,1fr) 48px 48px 48px !important"
        in page
        and "gap:0 !important; column-gap:0 !important; row-gap:0 !important"
        in page,
        "底栏为输入加三个 48px 方角动作的零缝隙四段",
    )
    check(
        "padding:11px 13px !important" in page
        and "left:9px; top:18px; width:8px; height:8px" in page,
        "输入为 11/13px 内边距，自绘光标为 8px",
    )
    check(
        "width:48px !important; min-width:48px !important; height:48px !important"
        in page
        and "border-radius:0 !important" in page,
        "发送、停止、展开均为 48px 直角无文字按钮",
    )
    check(
        ".stop-glyph { width:12px; height:12px" in page
        and "border-top:11px solid var(--accent)" in page,
        "停止符为 12px 实心方块，展开键为 16×11px ACCENT 三角",
    )
    check(
        "padding-bottom:calc(82px + env(safe-area-inset-bottom)) !important"
        in page
        and "#pluspanel { z-index:13 !important; }" in page
        and "footer { z-index:14 !important; }" in page,
        "功能面板底部留 82px，层级为面板 13、底栏 14",
    )
    check(
        "function togglePlus(on)" in runtime
        and 'const p = document.getElementById("pluspanel")' in runtime
        and 'p.classList.toggle("open", open)' in runtime
        and "togglePlus(false)" in runtime
        and "b.classList.toggle(\"on\", open)" in runtime,
        "旧页面板保持占位展开、返回关闭和按钮状态同步",
    )

    print("\n② 原生功能面板与底栏")
    check(
        "grid-template-columns" not in panel
        and "addTileRow(panel" in panel
        and panel.count("addTileRow(panel") == 6,
        "原生保留六行既有能力与顺序，不新增或移除入口",
    )
    check(
        "Color.argb(22, 255, 255, 255)" not in panel
        and "Color.argb(13, 255, 255, 255)" not in panel
        and "tile.setBackgroundColor(Color.TRANSPARENT)" in panel,
        "功能格取消奇偶交替底色并改为透明",
    )
    check(
        "NativeTheme.dp(this, 10), 0" in panel
        and "NativeTheme.dp(this, 9)" in panel
        and "NativeTheme.dp(this, 5), 0, 0" in panel,
        "原生功能格恢复 10/9px 内边距和 5px 图文间距",
    )
    check(
        "ViewGroup.LayoutParams.MATCH_PARENT, NativeTheme.dp(this, 43)"
        in panel
        and "NativeTheme.dp(this, 24), NativeTheme.dp(this, 24)"
        in panel
        and "box.setBackgroundColor(Color.TRANSPARENT)" in panel,
        "原生图标框恢复满格 43px 透明底和 24px 图标",
    )
    check(
        "boxParams" not in panel
        and "NativeTheme.dp(this, 52)" not in panel,
        "原生移除旧 52px 图标框",
    )
    check(
        "panel.setPadding(" in panel
        and "NativeTheme.dp(this, 8), 0," in panel
        and "panel.setBackgroundColor(NativeTheme.PANEL)" in panel
        and "PlusTriangleView" in footer,
        "原生面板恢复 8px 侧距、PANEL 底和 ACCENT 几何三角",
    )
    check(
        "NativeTheme.dp(this, 14)" in toggle
        and "NativeTheme.dp(this, 82)" in toggle
        and "Math.round(getResources().getDisplayMetrics().heightPixels * .52f)"
        in toggle,
        "原生展开恢复 14px 顶距、82px 底距和 52vh 高度",
    )
    check(
        "composer.setPadding(NativeTheme.dp(this, 13), NativeTheme.dp(this, 11),"
        in footer
        and "caretLayers.setLayerInset(" in activity
        and "NativeTheme.dp(this, 2)," in activity,
        "原生输入恢复 13/11px，光标保留 8px 核心与 2px 光晕层",
    )
    check(
        "stopGlyph" in footer
        and "NativeTheme.dp(this, 12), NativeTheme.dp(this, 12)" in footer
        and "plusTriangle" in footer
        and "NativeTheme.dp(this, 16), NativeTheme.dp(this, 11)" in footer,
        "原生停止符和展开三角恢复旧页尺寸与实心层",
    )
    check(
        "NativeTheme.dp(this, 23), NativeTheme.dp(this, 23)" in footer
        and "sendButton.addView(sendGlyph, sendGlyphParams)" in footer,
        "原生发送图标恢复 23px，不再铺满整个按钮",
    )
    check(
        "addAction(footer, sendButton)" in footer
        and "addAction(footer, stop)" in footer
        and "addAction(footer, plusButton)" in footer
        and "sendComposer();" in footer
        and "stopSpeech();" in footer,
        "发送、停止、展开动作和零缝隙顺序保持不变",
    )

    spec = importlib.util.spec_from_file_location("round131_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十一轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录功能面板与底栏收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"PlusTriangleView" in dex
            and b"buildPlusPanel" in dex,
            "APK/DEX 含新功能面板和底栏控件",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
