# -*- coding: utf-8 -*-
"""验收"悬浮窗到底有没有显示出来"这套回执：
正常的要认；崩了的要能说出原因并重试；窗口没显示出来也算失败。
"""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "ready-test"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))
from voice_feature.desktop_processes import DesktopProcessLauncher  # noqa: E402


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    stt = load_stt()
    sandbox = S / "app"
    sandbox.mkdir(parents=True, exist_ok=True)
    stt.HERE = sandbox
    stt.OVERLAY_READY = sandbox / "overlay_ready.json"
    spoken = []
    stt.speak = lambda t: spoken.append(t)      # 别真念出来
    logged = []
    stt.syslog = lambda tag, t: logged.append((tag, t))

    print("① 悬浮窗正常：应该认它")
    (sandbox / "overlay.py").write_text(
        "import json, os, time\n"
        "from pathlib import Path\n"
        "p = Path(__file__).with_name('overlay_ready.json')\n"
        "p.write_text(json.dumps({'pid': os.getpid(), 'ts': time.time(),"
        " 'size': [344, 112], 'visible': True}), encoding='utf-8')\n"
        "time.sleep(20)\n", encoding="utf-8")
    proc = stt.start_overlay()
    check(proc is not None, "起得来（返回了进程）")
    check(stt.OVERLAY_READY.exists(), "回执文件写出来了")
    if proc:
        proc.kill()

    print("② 悬浮窗崩了：要说出原因，还要重试")
    spoken.clear()
    (sandbox / "overlay.py").write_text(
        "from pathlib import Path\n"
        "Path(__file__).with_name('overlay-error.log').write_text(\n"
        "    'Traceback (most recent call last):\\n"
        "ImportError: DLL load failed while importing _imaging\\n', encoding='utf-8')\n"
        "raise SystemExit(3)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    t0 = time.time()
    proc = stt.start_overlay()
    took = time.time() - t0
    check(proc is None, "两次都不行 → 返回 None（不再假装成功）")
    check(any("DLL load failed" in s for s in spoken)
          or any("DLL load failed" in str(x) for x in logged),
          f"把日志里的原因说出来了：{(spoken or logged)[-1]}")
    # 它一崩就立刻能看出来，不该干等到超时（超时那条路见 ④）
    check(took < 9, f"崩了立刻就看出来，没干等（花了 {took:.0f} 秒）")

    print("③ 窗口建了但没显示（visible=False）：也算失败")
    (sandbox / "overlay.py").write_text(
        "import json, os, time\n"
        "from pathlib import Path\n"
        "Path(__file__).with_name('overlay_ready.json').write_text(json.dumps(\n"
        "    {'pid': os.getpid(), 'ts': time.time(), 'size': [344, 112],"
        " 'visible': False}), encoding='utf-8')\n"
        "time.sleep(20)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    import subprocess
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    started = time.time()
    proc3 = subprocess.Popen([str(runner), str(sandbox / "overlay.py")],
                             creationflags=0x08000000)
    reason = stt.wait_overlay_ready(started, 3.0)
    proc3.kill()
    check("没显示" in reason, f"识别为失败：{reason}")

    print("④ 没人写回执：等超时")
    (sandbox / "overlay.py").write_text("import time\ntime.sleep(30)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    t0 = time.time()
    reason = stt.wait_overlay_ready(time.time() - 1, 2.0)
    check("没把窗口显示出来" in reason and time.time() - t0 >= 1.8,
          f"超时后给了说法：{reason}")

    print("⑤ 桌面辅助进程边界：可注入、可归因、兼容入口保留")

    class Clock:
        def __init__(self) -> None:
            self.value = 1000.0
            self.sleeps = []

        def now(self):
            return self.value

        def sleep(self, seconds):
            self.sleeps.append(seconds)
            self.value += seconds

    class Process:
        def __init__(self, returncode=None):
            self.returncode = returncode
            self.kills = 0

        def poll(self):
            return self.returncode

        def kill(self):
            self.kills += 1
            self.returncode = -9

    with tempfile.TemporaryDirectory(prefix="findeck_processes_") as raw:
        root = Path(raw)
        clock = Clock()
        emitted = []
        logged = []
        calls = []
        processes = []
        ready_file = root / "overlay_ready.json"
        (root / "overlay.py").write_text("", encoding="utf-8")

        def ready_popen(argv, **kwargs):
            calls.append({"argv": argv, **kwargs})
            proc = Process()
            processes.append(proc)
            ready_file.write_text(
                json.dumps({"ts": clock.now(), "visible": True}),
                encoding="utf-8",
            )
            return proc

        launcher = DesktopProcessLauncher(
            root,
            executable=root / "python.exe",
            ready_file=ready_file,
            popen=ready_popen,
            now=clock.now,
            sleep=clock.sleep,
            platform_name="nt",
            speak=lambda _text: None,
            syslog=lambda tag, text: logged.append((tag, text)),
            emit=emitted.append,
        )
        proc = launcher.start_overlay()
        check(proc is processes[0], "正常回执返回本次悬浮窗进程")
        check(
            calls[0]["argv"] == [
                str(root / "python.exe"),
                str(root / "overlay.py"),
            ]
            and calls[0]["creationflags"] == 0x08000000
            and calls[0]["cwd"] == str(root),
            "解释器、隐藏窗口标志和程序目录保持原语义",
        )
        check(
            "启动悬浮窗" in (root / "overlay-error.log").read_text(
                encoding="utf-8",
            ),
            "每次启动前写入带日期的 stderr 日志分隔",
        )

        ready_file.write_text(
            json.dumps({"ts": clock.now(), "visible": False}),
            encoding="utf-8",
        )
        invisible = launcher.wait_overlay_ready(clock.now(), 1.0)
        check("没显示" in invisible, "visible=false 判为失败")
        ready_file.unlink()
        exited = Process(3)
        exit_reason = launcher.wait_overlay_ready(0, 2.0, exited)
        check(
            "退出码 3" in exit_reason and clock.sleeps[-1] == 0.4,
            "子进程刚退出时立即报告退出码",
        )

        retry_clock = Clock()
        retry_calls = []
        retry_processes = []

        def retry_popen(argv, **kwargs):
            retry_calls.append({"argv": argv, **kwargs})
            process = Process(4)
            retry_processes.append(process)
            return process

        retry_launcher = DesktopProcessLauncher(
            root,
            executable=root / "python.exe",
            ready_file=ready_file,
            popen=retry_popen,
            now=retry_clock.now,
            sleep=retry_clock.sleep,
            platform_name="nt",
            syslog=lambda tag, text: logged.append((tag, text)),
            emit=emitted.append,
        )
        check(
            retry_launcher.start_overlay() is None
            and len(retry_calls) == 2
            and all(process.kills == 1 for process in retry_processes),
            "连续退出时精确重试一次并清理两个进程",
        )
        check(
            any("悬浮窗第 2 次没起来" in text for text in emitted)
            and any(tag == "浮" for tag, _text in logged),
            "失败过程保留逐次提示和最终系统日志",
        )

        helper_calls = []

        def helper_popen(argv, **kwargs):
            helper_calls.append({"argv": argv, **kwargs})
            return Process()

        helper = DesktopProcessLauncher(
            root,
            executable=root / "python.exe",
            popen=helper_popen,
            platform_name="nt",
            emit=emitted.append,
        )
        check(
            helper.start_pet() is None
            and helper.start_tray() is None
            and helper.start_watchdog() is None,
            "可选辅助程序和素材缺失时安静跳过",
        )
        (root / "tray.py").write_text("", encoding="utf-8")
        (root / "watchdog.py").write_text("", encoding="utf-8")
        check(
            helper.start_tray() is not None
            and helper.start_watchdog() is not None,
            "托盘和看门狗存在时返回进程供诊断",
        )

    stt_source = (APP / "stt.py").read_text(encoding="utf-8")
    process_source = (
        APP / "voice_feature" / "desktop_processes.py"
    ).read_text(encoding="utf-8")
    health_source = (APP / "core" / "health.py").read_text(encoding="utf-8")
    check(
        "def _desktop_process_launcher()" in stt_source
        and 'script = HERE / "overlay.py"' not in stt_source
        and 'script = HERE / "watchdog.py"' not in stt_source,
        "主程序只保留桌面进程兼容入口",
    )
    check(
        "class DesktopProcessLauncher" in process_source
        and "def start_overlay(" in process_source
        and "def start_watchdog(" in process_source,
        "桌面辅助进程边界位于独立模块",
    )
    check(
        'check_path("voice_desktop_processes"' in health_source,
        "启动自检覆盖新的桌面进程模块",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
