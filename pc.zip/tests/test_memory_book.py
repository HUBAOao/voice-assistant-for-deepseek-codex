# -*- coding: utf-8 -*-
"""Read-only shared-memory book renderer and desktop entry."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PET = ROOT / "outputs" / "voice-to-text" / "pet_live"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_memory_book_") as raw:
        root = Path(raw)
        sections = root / "sections"
        sections.mkdir()
        memory = root / "memory.md"
        memory.write_text(
            "# 测试记忆\n\n"
            "## 一、人格\n\n"
            "### 表达\n\n"
            "- 先给结论，再说依据。\n\n"
            "## 二、重要知识\n\n"
            "- 只读展示。\n\n"
            "## 三、写入约定\n\n"
            "- 由确认内容组成。\n",
            encoding="utf-8",
        )
        (root / "INDEX.md").write_text(
            "# 索引\n\n"
            "| 内容 | 位置 | 用途 |\n"
            "|---|---|---|\n"
            "| 人格与表达 | `memory.md` 第 3 行起 | 语气和改错原则 |\n"
            "| 重要知识 | `memory.md` 第 11 行起 | 长期规则 |\n"
            "| 写入约定 | `memory.md` 第 15 行起 | 记忆生命周期 |\n"
            "| 历史 | `sections/history.md` | 版本记录 |\n",
            encoding="utf-8",
        )
        (sections / "history.md").write_text(
            "# 历史\n\n## 第一章\n\n- 旧版本内容。\n",
            encoding="utf-8",
        )
        module = (PET / "memory-book.js").as_posix()
        script = (
            f"const m=require({json.dumps(module)});"
            f"const p=m.findMemoryRoot([{json.dumps(str(root / 'missing'))},"
            f"{json.dumps(str(root))}]);"
            "process.stdout.write(JSON.stringify(m.loadMemoryBook(p)));"
        )
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=20,
        )
        check(result.returncode == 0, "记忆解析器可执行")
        data = json.loads(result.stdout or "{}")
        chapters = data.get("chapters") or []
        print("   ->", [item.get("title") for item in chapters])
        check(data.get("ok") is True and data.get("root") == str(root),
              "首选位置缺失时按顺序回退到下一份完整记忆")
        check([item.get("title") for item in chapters[:3]] == [
            "一、人格", "二、重要知识", "三、写入约定"
        ], "Markdown 二级标题按书籍章节拆分")
        check(any(item.get("title") == "第一章"
                  and item.get("external") is True for item in chapters),
              "INDEX.md 引用的外部章节也进入书册")
        check(chapters[0].get("subheadings")
              and chapters[0]["subheadings"][0]["title"] == "表达",
              "三级标题保留为章内小节")
        check(chapters[0].get("summary") == "语气和改错原则",
              "索引用途文本进入章节摘要")

    source = (PET / "memory-book.js").read_text(encoding="utf-8")
    html = (PET / "web" / "memory-book.html").read_text(encoding="utf-8")
    main_js = (PET / "main.js").read_text(encoding="utf-8")
    preload = (PET / "preload.js").read_text(encoding="utf-8")
    check("writeFileSync" not in source and "appendFileSync" not in source,
          "记忆书册只读取文件，不写回共享记忆")
    for label in ("coverView", "tocView", "chapterView",
                  "chapterPrev", "chapterNext", "chapterToc",
                  "tocList"):
        check(f'id="{label}"' in html, f"书页包含 {label}")
    check("openChapter(index)" in html and "scrollIntoView" in html,
          "点目录和章内小节可以直接定位")
    check("label: '鱼的记忆'" in main_js
          and "memory-book.html" in main_js
          and "memoryBook.loadMemoryBook()" in main_js,
          "桌宠右键菜单打开独立记忆书窗口")
    check("memoryBookLoad" in preload
          and "memoryBookClose" in preload,
          "书页窗口使用隔离的只读 IPC")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
