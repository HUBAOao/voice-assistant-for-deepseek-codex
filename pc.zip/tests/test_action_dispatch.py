# -*- coding: utf-8 -*-
"""Focused tests for the extracted structured-action dispatcher."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from features.voice_actions import VoiceAction  # noqa: E402
from voice_feature.action_dispatch import dispatch  # noqa: E402


class FakeTasks:
    def __init__(self) -> None:
        self.items = [
            {"id": "run", "status": "running"},
            {"id": "wait", "status": "waiting_approval",
             "approval": {"id": "approval"}},
        ]
        self.decisions = []
        self.updates = []

    def list(self, status=None, limit=10):
        rows = [item for item in self.items if status is None or item["status"] == status]
        return rows[:limit]

    def decide(self, task_id, approved, note):
        self.decisions.append((task_id, approved, note))

    def update(self, task_id, **changes):
        self.updates.append((task_id, changes))


def main() -> int:
    tasks = FakeTasks()
    status = dispatch(VoiceAction("task_status"), task_store=tasks)
    assert status.ok and "2 个任务" in status.message and "1 个等你批准" in status.message

    approved = dispatch(VoiceAction("approve", risk="high"), task_store=tasks)
    assert approved.ok and approved.terminate
    assert tasks.decisions == [("wait", True, "语音批准")]

    rejected = dispatch(VoiceAction("reject", risk="high"), task_store=tasks)
    assert rejected.ok and rejected.terminate
    assert tasks.decisions[-1] == ("wait", False, "语音拒绝")

    cancelled = dispatch(VoiceAction("cancel_task", risk="high"), task_store=tasks)
    assert cancelled.ok and cancelled.terminate
    assert tasks.updates == [("run", {"status": "cancelled"})]

    calls = []
    new = dispatch(
        VoiceAction("new_thread"),
        new_thread=lambda: calls.append("new") or (True, "新会话"),
    )
    assert new.ok and new.message == "新会话" and calls == ["new"]

    failed = dispatch(
        VoiceAction("new_thread"),
        new_thread=lambda: (_ for _ in ()).throw(RuntimeError("桥没接上")),
    )
    assert not failed.ok and "桥没接上" in failed.message
    print("test_action_dispatch: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
