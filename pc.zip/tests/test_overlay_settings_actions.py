# -*- coding: utf-8 -*-
"""Verify settings actions live outside the overlay window implementation."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import settings_actions_mixin as actions  # noqa: E402
from overlay_feature import settings_persistence_mixin as persistence  # noqa: E402
from overlay_feature.settings_actions_mixin import (  # noqa: E402
    OverlaySettingsActionsMixin,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Root:
        def __init__(self) -> None:
            self.cancelled = []
            self.scheduled = []

        def after_cancel(self, job) -> None:
            self.cancelled.append(job)

        def after(self, delay, callback):
            self.scheduled.append((delay, callback))
            return 99

    class Switch:
        def __init__(self, value: bool) -> None:
            self.value = value

        def get(self) -> bool:
            return self.value

    class Hint(Switch):
        def __init__(self) -> None:
            super().__init__(False)
            self.options = []

        def config(self, **options) -> None:
            self.options.append(options)

    class Dummy(OverlaySettingsActionsMixin):
        def __init__(self) -> None:
            self._push_job = 7
            self.root = Root()
            self.hint_label = Hint()
            self.fx_switches = {"trail": Switch(True), "glow": Switch(True)}
            self._auto_low = True
            self._fx_before_low = {"trail": False, "glow": True}
            self.panel = None
            self.panel_win = None
            self.expanded = False
            self.flash_calls = []
            self.applied = 0

        def flash(self, text, seconds) -> None:
            self.flash_calls.append((text, seconds))

        def apply_saved(self) -> None:
            self.applied += 1

    dummy = Dummy()
    check(dummy._fx_to_save() == {"trail": False, "glow": True},
          "自动降级时不把临时关闭的特效写进配置")
    dummy.on_change()
    check(dummy.root.cancelled == [7], "改动会取消旧的即时预览任务")
    check(dummy.root.scheduled and dummy.root.scheduled[0][0] == 120,
          "改动合并成 120ms 后的预览")
    check(dummy._push_job == 99, "保存预览任务句柄")

    with tempfile.TemporaryDirectory(prefix="findeck_settings_") as raw:
        config = Path(raw) / "config.json"
        config.write_text(json.dumps({"keep": 1, "x": {"a": 99}}), encoding="utf-8")
        persistence.CONFIG = config
        persistence.DEFAULTS = {"x": {"a": 1}, "items": [1, 2]}
        dummy.cfg = {"old": True}
        dummy.reset_defaults()
        saved = json.loads(config.read_text(encoding="utf-8"))
        check(saved["keep"] == 1 and saved["x"] == {"a": 1},
              "恢复默认保留未知配置并深拷贝字典")
        check(saved["items"] == [1, 2], "恢复默认深拷贝列表")
        check(dummy.applied == 1 and dummy.flash_calls[-1][0] == "已恢复默认设置",
              "恢复默认立即刷新预览和提示")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("OverlaySettingsActionsMixin" in overlay,
          "Overlay 组合设置交互边界")
    for marker in (
        "def collect(self)",
        "def _fx_to_save(self)",
        "def reset_defaults(self)",
    ):
        check(marker not in overlay, f"overlay.py 不再内联 {marker}")
    check("SettingsActionsMixin" in Path(actions.__file__).read_text(encoding="utf-8"),
          "设置交互实现可独立加载")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
