# -*- coding: utf-8 -*-
"""Platform boundary reports honest support and preserves Windows behavior."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from core.platform_adapter import diagnostics, info, subprocess_kwargs


def main() -> int:
    current = info()
    assert current.system == sys.platform
    assert current.display_name
    assert current.portable_data_root
    assert isinstance(current.limitations, tuple)
    report = diagnostics()
    assert "secure_store" in report and "ready" in report
    if sys.platform == "win32":
        assert current.family == "windows"
        assert current.ready is True
        assert current.process_submit_flags == 0x08000000
        assert current.secure_store == "Windows DPAPI"
        assert current.legacy_data_root == r"E:\语音助手"
        assert subprocess_kwargs()["creationflags"] == 0x08000000
    print("test_platform_adapter: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
