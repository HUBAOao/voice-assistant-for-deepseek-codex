# -*- coding: utf-8 -*-
"""Protocol-level tests for approval responses, diff, and turn steering."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from features.codex_control import CodexControl  # noqa: E402
from features.tasks import TaskStore  # noqa: E402


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        store = TaskStore(Path(raw) / "tasks.json")
        bridge = CodexControl(store)
        task = store.create("批准测试", thread_id="thread-live")
        store.update(task["id"], source="codex_turn", source_id="turn-live",
                     active_turn_id="turn-live", status="running")
        bridge._server_request({
            "id": 91,
            "method": "item/commandExecution/requestApproval",
            "params": {
                "threadId": "thread-live",
                "turnId": "turn-live",
                "itemId": "item-1",
                "startedAtMs": 1,
                "command": "pytest -q",
                "cwd": "C:/repo",
                "reason": "运行测试",
                "availableDecisions": ["accept", "decline"],
            },
        })
        pending = store.get(task["id"])
        assert pending["status"] == "waiting_approval"
        assert pending["approval"]["request_id"] == 91
        assert pending["approval"]["live"] is True
        sent = []
        with patch("codex_threads.server_request_pending", return_value=True), \
             patch("codex_threads.respond_server_request",
                   side_effect=lambda rid, result: sent.append((rid, result))):
            decided = bridge.resolve(task["id"], True, "只批准这一次")
        assert sent == [(91, {"decision": "accept"})]
        assert decided["approval"]["response_sent"] is True
        assert decided["status"] == "running"

        with patch("codex_threads._rpc_once", return_value={"turnId": "turn-live"}):
            steered = bridge.inject_message(task["id"], "补一条测试")
        assert steered["messages"][-1]["status"] == "sent"
        bridge._handle_event({
            "method": "turn/diff/updated",
            "params": {"threadId": "thread-live", "turnId": "turn-live",
                       "diff": "diff --git a/a.py b/a.py\n+ok"},
        })
        changed = store.get(task["id"])
        assert "diff --git" in changed["diff"]
        print("test_codex_control: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
