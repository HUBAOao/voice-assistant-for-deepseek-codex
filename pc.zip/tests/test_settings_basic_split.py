# -*- coding: utf-8 -*-
"""Basic settings composition is isolated from the settings shell and actions."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_basic_mixin import (  # noqa: E402
    OverlaySettingsBasicMixin,
)
from overlay_feature.settings_wake_mixin import (  # noqa: E402
    OverlaySettingsWakeMixin,
)
from overlay_feature.settings_caption_mixin import (  # noqa: E402
    OverlaySettingsCaptionMixin,
)
from overlay_feature.settings_reminders_mixin import (  # noqa: E402
    OverlaySettingsRemindersMixin,
)


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Chip:
        def __init__(self) -> None:
            self.options = None

        def config(self, **options) -> None:
            self.options = options

    class Label:
        def __init__(self) -> None:
            self.options = None

        def config(self, **options) -> None:
            self.options = options

    class Probe(
        OverlaySettingsBasicMixin,
        OverlaySettingsWakeMixin,
        OverlaySettingsCaptionMixin,
    ):
        def __init__(self) -> None:
            self.cfg = {"wake_level": "标准"}
            self.button_color = "#00aa88"
            self.level_chips = {"标准": Chip(), "宽松": Chip()}
            self.level_info = Label()

    probe = Probe()
    check(probe.custom_levels() == {},
          "唤醒档位从配置读取且返回独立字典")
    probe.refresh_level_colors()
    check(probe.level_chips["标准"].options["bg"] == "#00aa88"
          and probe.level_chips["宽松"].options["bg"] == "#24242a",
          "当前唤醒档位保留主题色高亮")
    probe.update_level_info("测试结果")
    check(probe.level_info.options == {"text": "测试结果", "fg": "#7f7f8a"},
          "唤醒自检结果仍写回同一条说明控件")

    basic = (APP / "overlay_feature" / "settings_basic_mixin.py").read_text(
        encoding="utf-8"
    )
    shell = (APP / "overlay_feature" / "settings_mixin.py").read_text(
        encoding="utf-8"
    )
    shell_builder = (
        APP / "overlay_feature" / "settings_shell_mixin.py"
    ).read_text(encoding="utf-8")
    wake = (APP / "overlay_feature" / "settings_wake_mixin.py").read_text(
        encoding="utf-8"
    )
    caption = (APP / "overlay_feature" / "settings_caption_mixin.py").read_text(
        encoding="utf-8"
    )
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("def build_basic(" in basic,
          "基本页只负责身份、称呼和预设入口组合")
    for marker in (
        "def build_wake_level(",
        "def refresh_level_chips(",
        "def poll_wake_test(",
    ):
        check(marker in wake and marker not in basic and marker not in shell,
              f"唤醒业务 {marker} 已迁入独立边界")
    for marker in ("def make_big_caption(", "def sync_big_caption("):
        check(marker in caption and marker not in basic and marker not in shell,
              f"大字幕业务 {marker} 已迁入独立边界")
    check("OverlaySettingsBasicMixin" in overlay
          and "OverlaySettingsWakeMixin" in overlay
          and "OverlaySettingsCaptionMixin" in overlay
          and "self.build_basic(self.tab_frames[\"基本\"])" in shell_builder,
          "设置总页仍通过一次 build_basic 调用组装三类业务")
    check("def save_settings(self)" in (
        APP / "overlay_feature" / "settings_persistence_mixin.py"
    ).read_text(encoding="utf-8"),
          "配置保存交互仍留在独立动作边界")
    reminders = (APP / "overlay_feature" / "settings_reminders_mixin.py").read_text(
        encoding="utf-8"
    )
    features = (APP / "overlay_feature" / "settings_features_mixin.py").read_text(
        encoding="utf-8"
    )
    check(OverlaySettingsRemindersMixin.__name__ in overlay
          and "def build_reminders(" in reminders,
          "提醒、快捷指令从功能页迁入独立业务边界")
    check("self.build_reminders(parent)" in features
          and "self.sw_reminder =" not in features,
          "功能页只组合提醒业务，不再内联其控件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
