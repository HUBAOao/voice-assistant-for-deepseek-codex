# -*- coding: utf-8 -*-
"""验收电脑屏幕共享：DPI、多显示器、原画截图和高清 MP4 录屏。"""
from __future__ import annotations
from pathlib import Path

import pathlib
import sys

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import av  # noqa: E402
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402

import screen_share  # noqa: E402


def main() -> int:
    info = screen_share.screen_info()
    shot = screen_share.take_shot("自动测试-原画")
    video = screen_share._record_mp4(1.0, 3, 1920)
    bad = []
    try:
        print("显示器", info)
        if not info.get("count") or not info.get("width") or not info.get("height"):
            bad.append("display-info")
        if not shot:
            print("截图失败")
            bad.append("screenshot")
        else:
            im = Image.open(shot)
            lum = np.asarray(im.convert("L"))
            print("截图尺寸", im.size, "文件", shot.stat().st_size)
            if im.size != (info["width"], info["height"]):
                bad.append("screenshot-size")
            if float((lum < 8).mean()) > 0.60:
                bad.append("screenshot-mostly-black")
        if not video:
            print("录屏失败")
            bad.append("record")
        else:
            con = av.open(str(video))
            stream = con.streams.video[0]
            print("录像尺寸", stream.width, stream.height, "文件", video.stat().st_size)
            if stream.width != 1920:
                bad.append("record-size")
            con.close()
    finally:
        for p in (shot, video):
            if p:
                try:
                    p.unlink(missing_ok=True)
                except Exception:
                    pass
    print("失败项", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
