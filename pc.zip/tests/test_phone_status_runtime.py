# -*- coding: utf-8 -*-
"""Phone status metadata is assembled without the STT entrypoint."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.phone_status_runtime import (  # noqa: E402
    PhoneInfoDependencies,
    PhoneInfoRuntime,
    PhoneStateDependencies,
    PhoneStateRuntime,
)


class Status:
    state = "listening"
    hint = "等你说"
    _last = {"text": "正在听"}


class Remote:
    detail_calls = 0

    def detail(self):
        type(self).detail_calls += 1
        return {"funnel_on": True, "account": "account"}

    def fixed_url(self):
        return "fixed"

    def alt_url(self):
        return "alt"

    def hint(self):
        return "hint"

    def phone_hint(self):
        return "phone-hint"

    def public_url(self):
        return "public"

    def apk_url(self):
        return "apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    busy = {"on": False, "at": 0.0}
    mute = {"on": True}
    pause = {"paused": True}
    state = PhoneStateRuntime(
        PhoneStateDependencies(
            status=Status(),
            busy=busy,
            mute=mute,
            pause=pause,
            reply_busy=lambda: False,
            clock=lambda: 900.0,
        )
    )
    check(
        state.snapshot()
        == {
            "state_text": "listening · 正在听",
            "busy": False,
            "mute": True,
            "paused": True,
        },
        "手机状态保留原字段与状态文字格式",
    )

    busy.update(on=True, at=100.0)
    stale = state.snapshot()
    check(
        not stale["busy"] and not busy["on"],
        "卡住超过 12 分钟的忙标志仍会被兜底清除",
    )
    busy.update(on=True, at=800.0)
    check(
        state.snapshot()["busy"],
        "正常时长内的忙标志不会被误清",
    )

    version = SimpleNamespace(
        AUTHOR="A",
        CONTACT="C",
        COPYRIGHT="R",
        FREE_LINE="F",
        NOTICE="N",
    )
    info = PhoneInfoRuntime(
        PhoneInfoDependencies(
            config={"name": "鳍舱", "update_url": "https://updates.example/"},
            pc_version=lambda: "1.259",
            phone_version=lambda: "1.78",
            version_module=version,
            public_update_url=lambda: "https://public.example/",
            remote_access=Remote(),
        )
    ).snapshot()
    check(
        info["pc"] == "1.259"
        and info["phone"] == "1.78"
        and info["update_url"] == "https://updates.example",
        "手机元数据继续回读实际版本并优先使用自定义更新源",
    )
    check(
        info["fixed_url"] == "fixed"
        and info["public_url"] == "public"
        and info["funnel_on"]
        and info["remote_account"] == "account",
        "外网访问与署名元数据字段保持兼容",
    )

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    services = (
        APP / "voice_feature" / "runtime_service_assembly.py"
    ).read_text(encoding="utf-8")
    application_services = (
        APP / "voice_feature" / "runtime_application_services.py"
    ).read_text(encoding="utf-8")
    check(
        "PhoneStateRuntime(" in assembly
        and "PhoneInfoRuntime(" in assembly
        and "assemble_phone_runtime(" in services
        and "assemble_runtime_services(" in application_services
        and 'busy = bool(BUSY["on"]) or bool(REPLY_READER.busy())' not in stt,
        "手机业务装配持有状态运行时，主流程不再内联忙标志业务",
    )
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
