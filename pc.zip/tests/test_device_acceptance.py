# -*- coding: utf-8 -*-
"""Real-device acceptance evidence stays explicit and device-scoped."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        path = Path(raw) / "acceptance.json"
        os.environ["FIN_DECK_ACCEPTANCE_FILE"] = str(path)
        from phone_feature.device_acceptance import snapshot, update

        before = snapshot(current_device="android-test-device")
        assert before["passed"] == 0 and before["complete"] is False
        assert len(before["checks"]) == 4
        assert before["device"] != "android-test-device"
        try:
            update(
                current_device="android-test-device",
                data={
                    "id": "acoustic_echo", "status": "passed",
                    "platform": {"sdk": 36, "model": "SM-F9660"},
                },
            )
        except ValueError as exc:
            assert "确认" in str(exc)
        else:
            raise AssertionError("unconfirmed acceptance was recorded")
        try:
            update(
                current_device="android-test-device",
                data={
                    "id": "false_wake", "status": "passed", "confirm": True,
                },
            )
        except ValueError as exc:
            assert "Android APK" in str(exc)
        else:
            raise AssertionError("a browser-only acceptance was recorded")
        result = update(
            current_device="android-test-device",
            data={
                "id": "acoustic_echo",
                "status": "passed",
                "note": "扬声器连续朗读后未出现自听发送",
                "platform": {"sdk": 36, "model": "SM-F9660", "android": "16"},
                "confirm": True,
            },
        )
        row = next(item for item in result["checks"] if item["id"] == "acoustic_echo")
        assert row["status"] == "passed" and "自听" in row["note"]
        assert result["platform"]["model"] == "SM-F9660"
        assert "android-test-device" not in path.read_text(encoding="utf-8")
        print("test_device_acceptance: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
