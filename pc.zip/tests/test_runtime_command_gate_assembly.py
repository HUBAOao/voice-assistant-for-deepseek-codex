# -*- coding: utf-8 -*-
"""Local command preflight keeps its order and never swallows normal chat."""
from __future__ import annotations

import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_command_gate_assembly import (  # noqa: E402
    RuntimeCommandGateAssembly,
    RuntimeCommandGateDependencies,
)


class Status:
    def __init__(self) -> None:
        self.state = "idle"
        self._last = {"text": "等你说"}
        self.calls = []
        self.mood_calls = []

    def set(self, state, **kwargs) -> None:
        self.state = state
        self._last = kwargs
        self.calls.append((state, kwargs))

    def set_mood(self, mood) -> None:
        self.mood_calls.append(mood)


class Dictation:
    def __init__(self, action="") -> None:
        self.action = action
        self.calls = []

    def command(self, text, stop_requested=False):
        self.calls.append((text, stop_requested))
        return self.action


def deps(**overrides):
    values = dict(
        speaking_now=lambda: False,
        shut_up=lambda: None,
        stop_words=["停"],
        is_stop_word=lambda text, words: text.strip() in words,
        last_unsent={"text": "", "at": 0.0},
        pick_send_target=lambda: (101, "ChatGPT"),
        send=lambda text, hwnd: True,
        busy={"on": False, "at": 0.0},
        status=Status(),
        speak=lambda text: None,
        syslog=lambda tag, text: None,
        emit=lambda text: None,
        mute={"on": False},
        mute_command=lambda text, muted=False: "",
        dispatch_mute=lambda action, **kwargs: False,
        self_speech={"on": False},
        self_voice_miss={"text": "", "at": 0.0},
        self_spoken_text=lambda: "",
        recent_spoken=lambda: [],
        sounds_like=lambda left, right: left == right,
        repeated_after_miss=lambda text, missed: text == missed["text"],
        extract_word=lambda text, words, fuzzy=True, leading=True: (
            text,
            "大肥鱼" if text.startswith("大肥鱼") else "",
        ),
        wake_words=["大肥鱼"],
        wake_level={"fuzzy": True, "leading": True},
        dictation=Dictation(),
        is_standalone_command=lambda text: len(text) <= 8,
        dispatch_dictation=lambda *args, **kwargs: False,
        beep=lambda freq, ms: None,
        type_text=lambda text: None,
        syslog_file=Path("missing-syslog.md"),
        clock=lambda: 1000.0,
        sleep=lambda seconds: None,
    )
    values.update(overrides)
    return RuntimeCommandGateDependencies(**values)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    gate = RuntimeCommandGateAssembly(deps())
    outcome = gate.evaluate("大肥鱼，帮我查天气", from_phone=True)
    check(not outcome.handled, "普通聊天继续交给发送管线")

    calls = []
    speaking = {"on": True}
    gate = RuntimeCommandGateAssembly(deps(
        speaking_now=lambda: speaking["on"],
        shut_up=lambda: (
            calls.append("stop"),
            speaking.update(on=False),
        ),
    ))
    outcome = gate.evaluate("停")
    check(calls == ["stop"] and not outcome.handled,
          "停止词先闭嘴，但仍允许后续本地命令判定")

    sent = []
    resent = []
    busy = {"on": False, "at": 0.0}
    gate = RuntimeCommandGateAssembly(deps(
        last_unsent={"text": "上一次没发进去", "at": 990.0},
        send=lambda text, hwnd: sent.append((text, hwnd)) or True,
        busy=busy,
        record_resend=lambda *args: resent.append(args),
    ))
    outcome = gate.evaluate("重发一遍")
    check(outcome.handled and sent == [("上一次没发进去", 101)]
          and busy["on"] is True,
          "重发成功标记忙碌并使用原目标")
    check(
        resent == [("上一次没发进去", 101, "ChatGPT", 1000.0)],
        "重发成功继续进入送达核验并保留发送起始时刻",
    )

    mute = {"on": False}
    gate = RuntimeCommandGateAssembly(deps(
        mute=mute,
        mute_command=lambda text, muted=False: "mute",
        dispatch_mute=lambda action, **kwargs: kwargs["set_muted"](True) or True,
    ))
    outcome = gate.evaluate("静音")
    check(outcome.handled and mute["on"] is True,
          "静音动作仍走统一静音分发")

    status = Status()
    gate = RuntimeCommandGateAssembly(deps(
        self_speech={"on": True},
        speaking_now=lambda: True,
        self_spoken_text=lambda: "这是它刚念的回答",
        status=status,
    ))
    outcome = gate.evaluate("这是它刚念的回答")
    check(outcome.handled and status.mood_calls == [""],
          "自听回声被丢弃并清空临时语气")

    gate = RuntimeCommandGateAssembly(deps(
        self_speech={"on": True},
        speaking_now=lambda: True,
        self_spoken_text=lambda: "这是它刚念的回答",
        self_voice_miss={"text": "这是它刚念的回答", "at": 1.0},
    ))
    outcome = gate.evaluate("这是它刚念的回答")
    check(not outcome.handled,
          "用户重复第二遍时不再误吃这句")

    shut = []
    slept = []
    gate = RuntimeCommandGateAssembly(deps(
        self_speech={"on": True},
        speaking_now=lambda: True,
        shut_up=lambda: shut.append(True),
        sleep=lambda seconds: slept.append(seconds),
    ))
    outcome = gate.evaluate("大肥鱼等一下")
    check(not outcome.handled and shut and slept == [0.15],
          "带唤醒词的抢话先闭嘴且继续处理用户正文")

    gate = RuntimeCommandGateAssembly(deps(
        dictation=Dictation("start"),
        dispatch_dictation=lambda action, *args, **kwargs: action == "start",
    ))
    outcome = gate.evaluate("听写")
    check(outcome.handled, "听写动作仍由命令闸门提前收口")

    log_file = ROOT / "work" / "command-gate-syslog.test.md"
    log_file.write_text(
        "2026-10-24 10:00:00 [听] 刚才那句\n",
        encoding="utf-8",
    )
    answers = []
    gate = RuntimeCommandGateAssembly(deps(
        status=status,
        syslog_file=log_file,
        speak=lambda text: answers.append(text),
    ))
    outcome = gate.evaluate("状态")
    log_file.unlink()
    check(outcome.handled and answers
          and "最近一条是你说的" in answers[0],
          "状态查询仍在本地回答并读取最近真实记录")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    utterance = (
        APP / "voice_feature" / "runtime_utterance_assembly.py"
    ).read_text(encoding="utf-8")
    check("assemble_runtime_gate_wiring(" in source
          and "command_gate.evaluate(" in utterance,
          "单句处理运行时只调用统一命令闸门")
    check("repeated_after_miss," in source
          and "from voice_feature.parsing import" in source,
          "主流程显式导入重复回声判定依赖")
    check("delivery_tracking=delivery_tracking" in source,
          "运行装配把手动重发接到回执跟踪")
    check('any(w in text.replace(" ", "") for w in '
          '("重发一遍", "再发一遍", "重发一下"))' not in source,
          "main() 不再内联重发判定")
    module = APP / "voice_feature" / "runtime_command_gate_assembly.py"
    ast.parse(module.read_text(encoding="utf-8"))
    check(module.exists(), "命令闸门是独立可编译模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
