# -*- coding: utf-8 -*-
"""The main mic loop remains injectable across all capture modes."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.audio_loop import AudioLoop, AudioLoopDependencies  # noqa: E402


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state, **extra) -> None:
        self.calls.append((state, extra))


class Recorder:
    def __init__(self, audio) -> None:
        self.audio = audio
        self.reads = 0
        self.hold_calls = []

    def _read(self) -> None:
        self.reads += 1

    def record_hold(self, key_down, **kwargs):
        self.hold_calls.append((key_down, kwargs))
        kwargs["on_level"](0.75, None)
        kwargs["on_start"]()
        kwargs["on_stop"]()
        return self.audio


class Microphone:
    def __init__(self, audio, *, available=True) -> None:
        self.available = available
        self.recorder = Recorder(audio)
        self.rate = 16000
        self.recoveries = 0
        self.thresholds = 0
        self.record_calls = []

    def recover(self) -> bool:
        self.recoveries += 1
        self.available = True
        return True

    def safe_calibrate(self):
        self.thresholds += 1
        return 0.02

    def safe_record(self, threshold, on_speech, **kwargs):
        self.record_calls.append((threshold, on_speech, kwargs))
        return self.recorder.audio


class Lock:
    def __init__(self, calls) -> None:
        self.calls = calls

    def __enter__(self):
        self.calls.append("lock-enter")

    def __exit__(self, *_exc):
        self.calls.append("lock-exit")
        return False


def build(mode, mic, handle_calls, *, paused_calls=None, talk_audio=None):
    status = Status()
    calls = handle_calls
    pause_values = iter(paused_calls or [False])
    deps = AudioLoopDependencies(
        microphone=mic,
        mode=mode,
        handle_lock=Lock(calls),
        handle_audio=lambda audio: calls.append(("handle", audio)) or True,
        remote_poll=lambda: calls.append("poll"),
        paused=lambda: calls.append("pause-check") or next(pause_values),
        status=status,
        key_down=lambda: True,
        pause_key="F9",
        record_ptt=lambda recorder: calls.append("ptt") or recorder.audio,
        has_utterance=lambda audio, rate: calls.append(
            ("utterance", audio, rate)
        ) or True,
        on_level=lambda value: calls.append(("level", value)),
        on_hold_start=lambda: calls.append("hold-start"),
        on_hold_stop=lambda: calls.append("hold-stop"),
        capture_talk=lambda: calls.append("talk") or talk_audio,
        on_speech=lambda: calls.append("speech"),
        before_fallback_capture=lambda: calls.append("fallback-before"),
        print_line=lambda *args, **kwargs: calls.append(("print", args)),
        sleep=lambda seconds: calls.append(("sleep", seconds)),
    )
    return AudioLoop(deps), status


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    hold_calls = []
    hold_mic = Microphone("hold-audio")
    hold, hold_status = build(
        "hold", hold_mic, hold_calls, paused_calls=[True, False]
    )
    hold.run()
    check(hold_mic.recorder.reads == 1,
          "hold 模式暂停时仍读取并丢弃一个输入块")
    check(any(call == ("level", 0.75) for call in hold_calls),
          "hold 模式保留实时电平回传")
    check(
        hold_calls.index("hold-start")
        < hold_calls.index("hold-stop")
        < hold_calls.index(("handle", "hold-audio")),
        "按住说话在松手后才把整段录音送去识别和发送",
    )
    check(
        hold_mic.recorder.hold_calls
        and hold_mic.recorder.hold_calls[0][1].get("tick") is not None,
        "按住说话待机时仍轮询悬浮窗 TTS 控制",
    )
    check(hold_calls[-2:] == ["lock-enter", ("handle", "hold-audio")]
          or "lock-enter" in hold_calls,
          "所有采集模式统一经过发送锁")
    check(hold_calls[-1] == "lock-exit", "发送完成后释放处理锁")
    check(hold_status.calls[0][0] == "idle", "hold 模式启动提示走原状态入口")

    enter_calls = []
    enter_mic = Microphone("enter-audio", available=False)
    enter, _ = build("enter", enter_mic, enter_calls)
    enter.run()
    check(enter_mic.recoveries == 1,
          "麦克风不可用时先尝试恢复，再进入采集")
    check(("utterance", "enter-audio", 16000) in enter_calls,
          "enter 模式保留最短录音判定")
    check(enter_calls[-1] == "lock-exit", "enter 模式正常收口")

    talk_calls = []
    talk_mic = Microphone("talk-audio")
    talk, _ = build(
        "talk", talk_mic, talk_calls, talk_audio="talk-audio"
    )
    talk.run()
    check("talk" in talk_calls and ("handle", "talk-audio") in talk_calls,
          "talk 模式使用注入的连续采集会话")
    check(talk_calls[-1] == "lock-exit", "talk 模式正常收口")

    fallback_calls = []
    fallback_mic = Microphone("fallback-audio")
    fallback, fallback_status = build("continuous", fallback_mic, fallback_calls)
    fallback.run()
    check(fallback_calls[0] == "fallback-before",
          "普通监听模式先重置首句提示，再进入录音")
    check(fallback_mic.thresholds == 1 and len(fallback_mic.record_calls) == 1,
          "普通监听保留校准和录音流程")
    check(fallback_calls[-1] == "lock-exit", "普通监听模式正常收口")
    check(fallback_status.calls[0][0] == "listening",
          "普通监听模式显示原有等待提示")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    input_setup = (
        APP / "voice_feature" / "runtime_input_loop.py"
    ).read_text(encoding="utf-8")
    run_assembly = (
        APP / "voice_feature" / "runtime_run_assembly.py"
    ).read_text(encoding="utf-8")
    foreground_entry = (
        APP / "voice_feature" / "runtime_application_foreground.py"
    ).read_text(encoding="utf-8")
    check("AudioLoop(" in input_setup
          and "deps.audio_loop.run()" in run_assembly
          and "return run_prepared_foreground(" in foreground_entry,
          "输入运行时装配独立 AudioLoop，主程序只启动录音生命周期")
    check("while True:\n            # 麦克风掉线" not in stt,
          "主程序不再内联整段录音循环")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
