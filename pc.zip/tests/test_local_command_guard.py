# -*- coding: utf-8 -*-
"""验收长段话里的关键词不会触发本地命令，独立短命令仍可用。"""
from __future__ import annotations
from pathlib import Path

import pathlib
import sys

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import memory_archive  # noqa: E402
import stt  # noqa: E402


def main() -> int:
    long_text = (
        "刚才我给你发了一大段话，结果语音助手直接给我打开了记忆归档处理。"
        "我聊天中出现有截取屏幕意思的那两个字，它直接忽略别的给我截了个屏，"
        "那段话就没法发到 Codex 上。"
    )
    short_shot = "截图发手机"
    short_open = "打开微信"
    checks = [
        ("长段话不算命令", stt.is_standalone_command(long_text) is False),
        ("截图命令仍可用", stt.is_standalone_command(short_shot) is True),
        ("打开命令仍可用", stt.parse_open(short_open) == "微信"),
        ("长段话不会解析归档",
         memory_archive.parse_command("" if not stt.is_standalone_command(long_text) else long_text)
         is None),
    ]
    bad = 0
    for name, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + name)
        bad += 0 if ok else 1
    print("失败项", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
