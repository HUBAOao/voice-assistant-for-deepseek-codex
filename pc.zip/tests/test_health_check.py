# -*- coding: utf-8 -*-
"""Unit tests for the read-only FinDeck health checks."""
from __future__ import annotations

import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(ROOT))

from core import health  # noqa: E402


def test_path_checks(tmp: Path) -> None:
    assert health.check_path("present", tmp).ok
    assert not health.check_path("missing", tmp / "missing").ok


def test_tcp_check() -> None:
    server = socket.socket()
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    port = server.getsockname()[1]
    try:
        assert health.check_tcp("local", "127.0.0.1", port).ok
    finally:
        server.close()


def test_report_shape(tmp: Path) -> None:
    (tmp / "stt.py").write_text("", encoding="utf-8")
    (tmp / "phone_link.py").write_text("", encoding="utf-8")
    (tmp / "phone_page.html").write_text("", encoding="utf-8")
    (tmp / "codex_threads.py").write_text("", encoding="utf-8")
    (tmp / "overlay.py").write_text("", encoding="utf-8")
    for relative in (
            "voice_feature/action_dispatch.py",
            "voice_feature/feature_commands.py",
            "phone_feature/media_routes.py",
            "phone_feature/history_routes.py",
            "overlay_feature/settings_pages_mixin.py",
            "overlay_feature/settings_features_mixin.py",
            "voice_feature/microphone_recovery.py",
            "phone_feature/ui/bootstrap.js",
            "phone_feature/ui/chat.js"):
        path = tmp / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")
    report = health.collect(tmp, include_phone=False)
    assert "checks" in report
    assert isinstance(report["ok"], bool)
    assert isinstance(report["error_count"], int)
    names = {item["name"] for item in report["checks"]}
    assert {"voice_action_dispatch", "phone_media_routes",
            "voice_feature_commands", "phone_history_routes",
            "overlay_settings_pages",
            "phone_ui_bootstrap", "phone_ui_chat"} <= names


def test_version_compatibility_logic() -> None:
    assert health.check_codex_compat.__doc__


if __name__ == "__main__":
    import tempfile

    with tempfile.TemporaryDirectory() as raw:
        path = Path(raw)
        test_path_checks(path)
        test_tcp_check()
        test_report_shape(path)
        test_version_compatibility_logic()
    print("test_health_check: PASS")
