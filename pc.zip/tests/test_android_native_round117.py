# -*- coding: utf-8 -*-
"""Round 117 native cold-start and reachability regressions."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
APP = ROOT / "outputs" / "voice-to-text"
APK = ROOT / "outputs" / "语音助手-手机端.apk"
VERSION = APP / "version.py"
HARNESS = ROOT / "work" / "android_native_ui_harness.py"
PAGES = ROOT / "work" / "native-ui-harness" / "pages.json"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    harness = HARNESS.read_text(encoding="utf-8")
    pages = PAGES.read_text(encoding="utf-8")

    print("① Android 12+ 毛玻璃使用独立位图与 GPU RenderEffect")
    check("private final class SnapshotFrostedBackdrop extends ImageView"
          in activity,
          "顶底栏毛玻璃使用独立快照层")
    check("snapshot = Bitmap.createBitmap(" in activity
          and "setRenderEffect(blur <= .01f ? null" in activity,
          "快照位图由 GPU RenderEffect 做实时高斯模糊")
    check("new Canvas(blurredBitmap).drawRenderNode(blurNode)" not in activity,
          "已移除 Bitmap Canvas 绘制 RenderNode 的崩溃路径")
    check("FrostedBarLayout extends FrameLayout" in activity
          and "content.measure(widthMeasureSpec, contentHeightSpec)"
          in activity
          and "setMeasuredDimension(width, height)" in activity,
          "毛玻璃叠层不会把顶底栏撑成整屏高度")

    print("\n② 原生入口与输入法返回可真实到达")
    check('headerFilter.setContentDescription("筛选聊天记录")' in activity,
          "聊天历史筛选有语义入口")
    check('else if ("状态".equals(label)) {' in activity
          and "showStatus();" in activity,
          "＋ 菜单状态入口接到原生连接状态页")
    check("public boolean onKeyPreIme(" in activity
          and "hideHistoryKeyboard();" in activity,
          "历史搜索框第一次返回优先收键盘")
    check('"text": "对话会话"' in pages
          and '"text": "设置"' in pages,
          "设置页走左侧真实抽屉入口")
    check('"action": "swipe"' in pages,
          "被底部裁切的第六行通过受控滑动可达")

    print("\n③ harness 不再用旧 WebView 或历史警告冒充原生证据")
    check("def _launch_native_preview(" in harness
          and 'adb.shell("am", "force-stop"' in harness,
          "每页冷启动前先清理旧 Activity")
    check("native_ready" in harness
          and "NativeFinDeckActivity 未进入前台" in harness,
          "启动后必须确认原生 Activity 真在前台")
    check("def extract_png(" in harness
          and "screenshot_png = extract_png(" in harness,
          "screencap 文本警告后仍提取真实 PNG")
    check('"notification_shade_focus": "notificationshade" in current_focus'
          in harness,
          "锁屏判断只看当前焦点，不吃历史窗口名")
    check("input_shown = re.findall(" in harness
          and 'combined = ime + "\\n"' in harness,
          "键盘判断优先使用 IME 当前输入状态")

    print("\n④ 版本和 APK")
    spec = importlib.util.spec_from_file_location("round117_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(version.PHONE_VERSION == f"1.{len(version.PHONE_CHANGELOG)}",
          f"手机端版本为 v{version.PHONE_VERSION}")
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for marker in (
            b"SnapshotFrostedBackdrop",
            b"RenderEffect",
            b"FrostedBarLayout",
            b"onKeyPreIme",
            b"showStatus",
        ):
            check(marker in dex, f"APK/DEX 包含 {marker.decode('ascii')}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
