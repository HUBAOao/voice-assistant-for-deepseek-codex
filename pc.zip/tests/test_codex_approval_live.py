# -*- coding: utf-8 -*-
"""Live integration: receive a real Codex approval and decline it.

This intentionally starts an ephemeral read-only thread in a temporary
directory.  It may spend one small model turn but leaves no project changes.
"""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import codex_threads  # noqa: E402
from features.codex_control import CodexControl  # noqa: E402
from features.tasks import TaskStore  # noqa: E402


def main() -> int:
    if os.environ.get("FIN_DECK_LIVE_CODEX") != "1":
        print("test_codex_approval_live: SKIP (set FIN_DECK_LIVE_CODEX=1)")
        return 0
    with tempfile.TemporaryDirectory() as raw:
        repo = Path(raw)
        (repo / "README.md").write_text("approval probe\n", encoding="utf-8")
        store = TaskStore(repo / "tasks.json")
        bridge = CodexControl(store)
        bridge.start()
        started = codex_threads._rpc_once("thread/start", {
            "cwd": str(repo),
            "ephemeral": True,
            "approvalPolicy": "untrusted",
            "sandbox": "read-only",
        }, timeout=30)
        thread = started.get("thread") or {}
        thread_id = str(thread.get("id") or "")
        assert thread_id, started
        prompt = (
            "Use the shell tool exactly once to run this command in the current "
            "directory: Set-Content -LiteralPath .findeck-approval-test -Value ok. "
            "Attempt the shell command now. Do not replace it with a prose question. "
            "If approval is denied, reply exactly DENIED and stop."
        )
        turn_started = codex_threads._rpc_once("turn/start", {
            "threadId": thread_id,
            "approvalPolicy": "untrusted",
            "sandboxPolicy": {"type": "readOnly"},
            "input": [{"type": "text", "text": prompt}],
        }, timeout=30)
        turn_id = str((turn_started.get("turn") or {}).get("id") or "")
        assert turn_id, turn_started
        deadline = time.time() + 120
        found = None
        while time.time() < deadline:
            for task in store.list(limit=100):
                approval = task.get("approval") or {}
                if (task.get("source_id") == turn_id
                        and approval.get("decision") == "pending"
                        and approval.get("live")):
                    found = task
                    break
            if found:
                break
            time.sleep(0.5)
        if not found:
            try:
                codex_threads._rpc_once("turn/interrupt", {
                    "threadId": thread_id, "turnId": turn_id,
                }, timeout=10)
            except Exception:
                pass
            raise AssertionError("no live Codex approval request was intercepted")
        print("approval intercepted:", found["approval"].get("method"),
              found["approval"].get("request_id"))
        decided = bridge.resolve(found["id"], False, "自动化验证后拒绝")
        assert decided["approval"]["response_sent"] is True
        assert decided["approval"]["decision"] == "rejected"
        time.sleep(1.0)
        health = bridge.health()
        print("test_codex_approval_live: PASS", health)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
