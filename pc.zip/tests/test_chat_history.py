# -*- coding: utf-8 -*-
"""验收聊天历史：60天分层、关键字/多会话/日期筛选、清除留档、按归档恢复。"""
from __future__ import annotations
from pathlib import Path

import pathlib
import shutil
import sys
import tempfile
import time

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import chat_history  # noqa: E402


def main() -> int:
    root = pathlib.Path(tempfile.mkdtemp(prefix="va-history-"))
    chat_history.HISTORY_DIR = root / "聊天记录"
    chat_history.storage_paths.DATA_ROOT = root
    chat_history.ACTIVE_FILE = chat_history.HISTORY_DIR / "messages.jsonl"
    chat_history.ARCHIVE_DIR = chat_history.HISTORY_DIR / "归档"
    chat_history.CLEARED_DIR = chat_history.HISTORY_DIR / "已清除"
    chat_history.STATE_FILE = chat_history.HISTORY_DIR / "state.json"
    chat_history._IDS = None
    chat_history._LAST_MAINT = 0
    original_mirror = chat_history.storage_paths.mirror_file
    chat_history.storage_paths.mirror_file = lambda *_args, **_kwargs: None
    now = int(time.time() * 1000)
    old = int((time.time() - 70 * 86400) * 1000)
    records = [
        {"kind":"ai", "ts_ms":old, "at":"10:00", "conv":"语音助手", "text":"旧结果"},
        {"kind":"me", "ts_ms":now-1000, "at":"11:00", "conv":"语音助手", "text":"新结果"},
        {"kind":"ai", "ts_ms":now-900, "at":"11:01", "conv":"养鱼", "text":"养鱼结果"},
        {"kind":"ai", "ts_ms":now-800, "at":"11:02", "conv":"其他", "text":"无关内容"},
    ]
    added = chat_history.ingest(records)
    chat_history.maintain()
    hits = chat_history.query("结果", ["语音助手", "养鱼"])
    checks = [
        ("四条入历史", added == 4),
        ("多会话加关键词", {x["conv"] for x in hits} == {"语音助手", "养鱼"} and len(hits) == 3),
        ("旧记录已归档", len(chat_history.archive_list()) >= 1),
        ("对话统计", any(x["title"] == "养鱼" for x in chat_history.conversations())),
    ]
    cleared = chat_history.clear_active()
    checks.append(("清除留档", cleared["ok"] and cleared["count"] >= 3))
    chat_history.ingest(records)
    checks.append(("清除后主历史和筛选均隐藏", len(chat_history.query("")) == 0))
    archives = chat_history.archive_list()
    restored = chat_history.restore_archive(archives[0]["name"]) if archives else {"ok":False}
    checks.append(("按日期归档恢复", bool(restored.get("ok"))))
    checks.append(("恢复后重新可见", len(chat_history.query("")) > 0))
    bad = 0
    for name, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + name)
        bad += 0 if ok else 1
    chat_history.storage_paths.mirror_file = original_mirror
    shutil.rmtree(root, ignore_errors=True)
    print("失败项", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
