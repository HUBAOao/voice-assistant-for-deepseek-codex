# -*- coding: utf-8 -*-
"""Round 98 phone interaction contract for the WebView and native page."""
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
NATIVE = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
THEME = NATIVE.with_name("NativeTheme.java")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    chat = (UI / "chat.js").read_text(encoding="utf-8")
    conversations = (UI / "conversations.js").read_text(encoding="utf-8")
    core = (UI / "page_core.js").read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    native = NATIVE.read_text(encoding="utf-8")
    theme = THEME.read_text(encoding="utf-8")
    native_arrow = native.split(
        "private void animateSendArrow()", 1
    )[-1].split("private void resetSendArrowAnimation()", 1)[0]
    checks = [
        (
            "气泡使用显式复制按钮，不再注册长按复制",
            "contextmenu" not in chat
            and 'copyButton.className = "copy"' in chat
            and 'copyButton.textContent = "复制"' in chat
            and "user-select:none" in page,
        ),
        (
            "每条连续气泡都显示真实会话名",
            ".row.group-cont .conv { display:inline-block !important; }" in page
            and ".bmeta .conv { display:inline-block !important; }" in page,
        ),
        (
            "屏幕任意位置右滑打开左侧会话抽屉",
            'document.addEventListener("touchstart"' in conversations
            and "canStartDrawerSwipe()" in conversations
            and 'FinDeckGesture.axisIntent(dx, dy) !== "right"'
            in conversations,
        ),
        (
            "AI 和用户气泡都可左滑打开右侧换会话层",
            'if (cls === "ai" || cls === "me")' in chat
            and 'return clean.length() > 0\n                    && !"本机".equals(clean)'
            in native,
        ),
        (
            "发送箭头只做垂直位移",
            "transform:translate3d(0,-28px,0)" in page
            and "translationY(-NativeTheme.dp(this, 28))" in native_arrow
            and "NativeTheme.dp(this, 13)" not in native_arrow,
        ),
        (
            "顶栏和底栏分别持久化透明度与模糊度",
            all(
                key in core
                for key in (
                    "topAlpha",
                    "topBlur",
                    "bottomAlpha",
                    "bottomBlur",
                    "--top-alpha",
                    "--bottom-blur",
                )
            )
            and all(
                key in theme
                for key in (
                    "TOP_CHROME_ALPHA",
                    "TOP_CHROME_BLUR",
                    "BOTTOM_CHROME_ALPHA",
                    "BOTTOM_CHROME_BLUR",
                )
            ),
        ),
        (
            "旧外观数据缺字段时仍使用原 .82/20px 默认值",
            'look.topAlpha === undefined ? .82' in core
            and 'look.bottomBlur === undefined ? 20' in core
            and 'look.optDouble("topAlpha", .82)' in theme
            and 'look.optDouble("bottomBlur", 20)' in theme,
        ),
    ]
    bad = 0
    for text, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + text)
        if not ok:
            bad += 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
