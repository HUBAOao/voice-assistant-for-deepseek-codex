# -*- coding: utf-8 -*-
"""Round 136 module boundaries and compatibility export checks."""
from __future__ import annotations

import importlib
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

LIMITS = {
    "stt.py": 2400,
    "overlay.py": 500,
    "codex_threads.py": 350,
    "features/plugin_registry.py": 450,
    "say.py": 200,
    "reply_reader.py": 160,
    "schedule_panel.py": 200,
    "features/tasks.py": 180,
    "voice_feature/speech_text.py": 120,
    "voice_feature/speech_state.py": 120,
    "voice_feature/speech_audio.py": 220,
    "voice_feature/speech_online.py": 100,
    "voice_feature/speech_local.py": 130,
    "voice_feature/speech_clone.py": 100,
    "voice_feature/speech_tts_service.py": 120,
    "voice_feature/speech_tts.py": 240,
    "voice_feature/reply_filters.py": 280,
    "voice_feature/reply_extraction.py": 380,
    "voice_feature/reply_watcher.py": 360,
    "voice_feature/reply_extraction.py": 380,
    "voice_feature/reply_watcher.py": 360,
    "features/codex_app_server.py": 420,
    "features/codex_thread_catalog.py": 280,
    "features/codex_thread_actions.py": 360,
    "features/codex_thread_lifecycle.py": 200,
    "features/codex_ui_bridge.py": 100,
    "features/plugin_loader.py": 320,
    "features/plugin_trust.py": 320,
    "features/plugin_archive.py": 260,
    "features/task_store.py": 380,
    "features/task_sync.py": 260,
    "features/task_policy.py": 200,
    "features/task_messages.py": 120,
    "schedule_feature/calendar_view.py": 340,
    "schedule_feature/editor.py": 260,
    "schedule_feature/table_view.py": 160,
    "schedule_feature/module_dialog.py": 160,
    "schedule_feature/module_list.py": 150,
    "schedule_feature/style.py": 30,
    "overlay_feature/window_state.py": 280,
    "overlay_feature/window_interaction.py": 280,
    "overlay_feature/panel_runtime.py": 220,
    "overlay_feature/window_render.py": 260,
    "overlay_feature/panel_actions_runtime.py": 160,
    "overlay_feature/window_animation.py": 320,
    "overlay_feature/window_render_simple.py": 260,
    "overlay_feature/window_support.py": 120,
    "voice_feature/runtime_privacy.py": 140,
    "voice_feature/runtime_application_assembly.py": 260,
    "voice_feature/runtime_application_entry.py": 180,
    "voice_feature/runtime_application_desktop.py": 240,
    "voice_feature/runtime_application_services.py": 200,
    "voice_feature/runtime_application_gates.py": 240,
    "voice_feature/runtime_application_foreground.py": 100,
    "voice_feature/runtime_status.py": 240,
    "voice_feature/window_automation.py": 380,
}


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    print("① 计划内模块边界")
    for relative, limit in LIMITS.items():
        path = APP / relative
        exists = path.is_file()
        lines = len(path.read_text(encoding="utf-8").splitlines()) if exists else -1
        check(exists and lines <= limit, f"{relative}: {lines} / {limit} 行")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    main_source = method_block(source, "def main() -> int:", "\nif __name__ ==")
    check(len(main_source.splitlines()) <= 120, "stt.main() 不超过 120 行")

    print("\n② 公共 API 兼容")
    say = importlib.import_module("say")
    for name in (
        "clean_for_speech", "split_chunks", "play", "apply_fx",
        "decode_audio", "read_wav", "edge_mp3", "baidu_mp3",
        "ts_audio", "clone_audio", "speak_piper", "speak_sapi",
        "publish_speaking", "publish_reference", "main",
    ):
        check(callable(getattr(say, name, None)), f"say.{name} 保持可调用")

    reader = importlib.import_module("reply_reader")
    for name in (
        "document_text", "extract_reply", "sentences", "guess_chat_name",
        "pick_reply", "ReplyReader",
    ):
        check(hasattr(reader, name), f"reply_reader.{name} 保持兼容")

    threads = importlib.import_module("codex_threads")
    for name in (
        "_AppServerClient", "_client", "_rpc", "_rpc_once", "list_projects",
        "list_threads", "current_name", "current_thread_id", "open_thread",
        "rename_thread", "set_read_state", "set_pinned", "move_to_project",
        "archive_thread", "delete_thread", "thread_action", "available",
    ):
        check(hasattr(threads, name), f"codex_threads.{name} 保持兼容")

    plugins = importlib.import_module("features.plugin_registry")
    for name in ("PluginRecord", "PluginRegistry", "PluginContext", "PluginHost", "PLUGIN_HOST"):
        check(hasattr(plugins, name), f"plugin_registry.{name} 保持兼容")

    tasks = importlib.import_module("features.tasks")
    for name in (
        "TaskStore", "sync_recent_threads", "classify_risk",
        "redact_sensitive", "DEFAULT_RETENTION",
    ):
        check(hasattr(tasks, name), f"tasks.{name} 保持兼容")

    schedule = importlib.import_module("schedule_panel")
    overlay = importlib.import_module("overlay")
    check(hasattr(schedule, "SchedulePanel"), "schedule_panel.SchedulePanel 保持兼容")
    check(hasattr(overlay, "Overlay"), "overlay.Overlay 保持兼容")

    stt = importlib.import_module("stt")
    runtime_modules = sorted(
        (APP / "voice_feature").glob("runtime_application_*.py")
    )
    missing = []
    for path in runtime_modules:
        source_text = path.read_text(encoding="utf-8")
        for name in set(re.findall(r"\bapplication\.([A-Za-z_]\w*)", source_text)):
            if not hasattr(stt, name):
                missing.append(f"{path.name}:{name}")
    check(not missing, "运行装配引用的 stt 依赖全部存在：" + ", ".join(missing))

    print("\n③ 单向依赖")
    for folder in (
        "voice_feature", "features", "overlay_feature", "schedule_feature"
    ):
        changed = False
        for path in sorted((APP / folder).rglob("*.py")):
            text = path.read_text(encoding="utf-8")
            if (
                "from stt import" in text
                or "import stt\n" in text
                or "from overlay import" in text
                or "import overlay\n" in text
            ):
                changed = True
                print(f"  ✗ {path.relative_to(APP)} 反向依赖主入口")
        check(not changed, f"{folder} 不反向依赖 stt/overlay")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
