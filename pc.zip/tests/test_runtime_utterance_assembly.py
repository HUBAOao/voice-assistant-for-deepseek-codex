# -*- coding: utf-8 -*-
"""One-utterance routing stays ordered after leaving ``stt.main()``."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature import runtime_utterance_assembly as module  # noqa: E402


class Status:
    def __init__(self) -> None:
        self.events = []
        self.mood = ""

    def set(self, state, **values) -> None:
        self.events.append((state, values))


class Gate:
    def __init__(self, **result) -> None:
        self.result = SimpleNamespace(**result)

    def evaluate(self, *_args, **_kwargs):
        return self.result

    def prepare(self, *_args, **_kwargs):
        return self.result


def dependencies(events):
    args = SimpleNamespace(
        out="transcripts.md",
        once=False,
        dry_run=False,
        no_send=False,
        no_clipboard=False,
        beep=True,
    )
    status = Status()
    delivered = {}

    class Delivery:
        def before_send(self, text):
            events.append(("before-send", text))

        def after_sent(self, **values):
            delivered.update(values)
            events.append("after-sent")
            return True

    delivery = Delivery()
    deps = module.RuntimeUtteranceDependencies(
        args=args,
        config={},
        config_file=Path("config.json"),
        app_dir=APP,
        mode="talk",
        rate=16000,
        transcriber=SimpleNamespace(
            transcribe=lambda _audio: "普通聊天"
        ),
        status=status,
        not_heard={"at": 0.0},
        voiceprint={
            "enroll": False,
            "last_score": None,
            "wake_score": None,
        },
        editing={"on": False},
        last_sent={},
        music={},
        private={},
        tutorial={},
        busy={},
        target=None,
        tracker=None,
        command_gate=Gate(handled=False),
        wake_gate=Gate(allowed=True, text="普通聊天"),
        send_gate=Gate(allowed=True, hwnd=9, title="Codex"),
        delivery_tracking=delivery,
        task_store=object(),
        cancel_reference_echo=lambda audio, _rate: audio,
        not_heard_due=lambda *_args, **_kwargs: False,
        speak=lambda text: events.append(("speak", text)),
        syslog=lambda kind, text: events.append(
            ("log", kind, text)
        ),
        emit=lambda text, **_kwargs: events.append(("emit", text)),
        append_log=lambda _path, text: events.append(
            ("append", text)
        ),
        guess_mood=lambda *_args: "",
        canonize=lambda text: text,
        apply_corrections=lambda text, _value: text,
        is_hallucination=lambda _text: False,
        voice_enroll=lambda *_args: True,
        voice_score=lambda *_args: 0.9,
        is_standalone_command=lambda _text: False,
        phone_new_thread=lambda _project: (True, ""),
        set_phone_window=lambda _title, _thread: (True, ""),
        done=lambda: True,
        arm_followup=lambda: events.append("followup"),
        load_config=lambda: {},
        beep=lambda *_args: None,
        run_shortcut=lambda *_args: None,
        parse_repeat=lambda _text: False,
        syslog_search=lambda *_args: [],
        weekly_report=lambda: "",
        find_window=lambda *_args: (0, ""),
        press_key=lambda *_args, **_kwargs: None,
        open_named=lambda *_args: None,
        paste_clipboard=lambda *_args, **_kwargs: True,
        grab_screen=lambda: False,
        get_reply_reader=lambda: None,
        focus_active=lambda: False,
        focus_left=lambda: 0.0,
        focus_start=lambda *_args: None,
        focus_stop=lambda: None,
        transform=lambda: None,
        brief_now=lambda: None,
        say_diary=lambda: None,
        tutorial_say=lambda _step: None,
        game_feed=lambda _text: False,
        game_start=lambda *_args: None,
        say_ledger=lambda: None,
        say_notes=lambda: None,
        add_ledger=lambda *_args: None,
        add_note=lambda *_args: None,
        clear_all_data=lambda: 0,
        undo_last=lambda: None,
        do_export=lambda: None,
        do_import=lambda: None,
        do_update=lambda: None,
        apply_update_now=lambda *_args: None,
        diag_pack=lambda: None,
        self_check=lambda **_kwargs: [],
        train_wake_voice=lambda: None,
        set_config=lambda *_args: None,
        schedule_restart=lambda: None,
        read_selected=lambda: None,
        start_reminder=lambda *_args: None,
        copy_to_clipboard=lambda _text: True,
        send_it=lambda _text, _hwnd: True,
        confirm_ok=lambda _text: True,
        soft_pet_notify=lambda _enabled: events.append("pet"),
        ack_phrase=lambda _config: "收到",
        clock=lambda: 100.0,
        sleep=lambda seconds: events.append(("sleep", seconds)),
    )
    return deps, status, delivered


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    events = []
    deps, status, delivered = dependencies(events)
    local_result = SimpleNamespace(
        text_to_send="普通聊天",
        handled=False,
        terminate=False,
    )
    with patch.object(
        module,
        "parse_voice_action",
        return_value=SimpleNamespace(kind="unknown"),
    ), patch.object(
        module,
        "dispatch_local_commands",
        return_value=local_result,
    ), patch.object(
        module,
        "deliver_text",
        side_effect=lambda _text, **kwargs: kwargs["on_sent"](),
    ):
        runtime = module.assemble_utterance_runtime(deps)
        result = runtime.process(None, pre_text="普通聊天", from_phone=True)

    check(result is False, "正常命令完成后继续语音循环")
    check(("append", "普通聊天") in events,
          "手机原始文字直接进入历史")
    check("after-sent" in events and delivered["text"] == "普通聊天",
          "发送成功后仍交给原送达跟踪")
    check(("sleep", 1.2) in events and "followup" in events,
          "发送后的稳定等待与连续对话顺序保持")
    check(all(item != ("speak", "收到") for item in events),
          "手机命令不额外朗读随机应答语")
    check(("thinking", {}) in status.events,
          "处理开始仍设置思考状态")

    events.clear()
    deps, status, _delivered = dependencies(events)
    deps = deps.__class__(
        **{
            **deps.__dict__,
            "is_hallucination": lambda _text: True,
        }
    )
    runtime = module.assemble_utterance_runtime(deps)
    result = runtime.process(object(), sr=16000)
    check(result is False and ("append", "普通聊天") not in events,
          "麦克风幻觉句在历史写入前丢弃")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "runtime_utterance_assembly.py"
    ).read_text(encoding="utf-8")
    check("assemble_utterance_runtime(" in stt
          and "RuntimeUtteranceDependencies(" in stt,
          "main() 只装配单句处理运行时")
    check(
          "finish_structured_action = "
          "gate_runtime.finish_structured_action" in stt
          and "done=finish_structured_action" in stt,
          "结构化动作结束回调由独立装配提供并接入")
    for inline in (
        "dispatch_local_commands(",
        "deliver_text(",
        "parse_voice_action(",
    ):
        check(inline not in stt,
              f"main() 不再内联 {inline[:-1]}")
    check("def process(" in assembly
          and "command_gate.evaluate(" in assembly
          and assembly.index("command_gate.evaluate(")
          < assembly.index("wake_gate.evaluate(")
          < assembly.index("send_gate.prepare(")
          < assembly.index("deliver_text("),
          "命令、唤醒、发送闸门和发送顺序固定")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
