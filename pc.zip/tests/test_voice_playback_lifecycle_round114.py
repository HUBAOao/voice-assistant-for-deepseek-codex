# -*- coding: utf-8 -*-
"""TTS child processes stop on barge-in and runtime shutdown."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.speech_playback import SpeechProcesses  # noqa: E402


class Process:
    def __init__(self, name: str, calls: list[str], *, terminate_works: bool = True):
        self.name = name
        self.calls = calls
        self.alive = True
        self.terminate_works = terminate_works

    def poll(self):
        return None if self.alive else 0

    def terminate(self) -> None:
        self.calls.append(self.name + ".terminate")
        if self.terminate_works:
            self.alive = False

    def kill(self) -> None:
        self.calls.append(self.name + ".kill")
        self.alive = False

    def wait(self, timeout: float | None = None) -> int:
        self.calls.append(f"{self.name}.wait:{timeout}")
        if not self.alive:
            return 0
        raise TimeoutError("still running")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls: list[str] = []
    created: list[Process] = []

    def spawn(command, **kwargs):
        name = Path(str(command[1])).stem + str(len(created))
        calls.append(f"spawn:{Path(str(command[1])).name}:{kwargs.get('cwd')}")
        process = Process(name, calls)
        created.append(process)
        return process

    controller = SpeechProcesses(spawn=spawn, grace=0.01)
    first = controller.spawn(["pythonw.exe", "say.py", "第一句"], cwd="app")
    second = controller.spawn(["pythonw.exe", "say.py", "排队句"], cwd="app")
    check(controller.active_count() == 2,
          "每次朗读启动都登记为可终止子进程")

    first.alive = False
    check(controller.active_count() == 1,
          "自然念完的进程会从活动集合移除")

    controller.interrupt()
    check(second.alive is False and controller.active_count() == 0,
          "插话停止会终止仍合成或排队中的朗读进程")
    check("say1.terminate" in calls,
          "停止顺序先礼貌终止而不是直接强杀")

    stuck = Process("stuck", calls, terminate_works=False)
    controller._spawn = lambda *_args, **_kwargs: stuck
    controller.spawn(["pythonw.exe", "say.py", "卡住"], cwd="app")
    controller.interrupt()
    check(not stuck.alive and "stuck.kill" in calls,
          "超时仍不退出的朗读进程会被强杀")

    waited = Process("waited", calls)
    controller._spawn = lambda *_args, **_kwargs: waited
    controller.spawn(["pythonw.exe", "say.py", "等待"], cwd="app")
    waited.alive = False
    controller.wait(waited)
    check(controller.active_count() == 0,
          "同步朗读结束后释放登记，不留下僵尸引用")

    real = SpeechProcesses(grace=0.8)
    real.spawn([sys.executable, "-c", "import time; time.sleep(30)"])
    stopped = real.interrupt()
    check(stopped == 1 and real.active_count() == 0,
          "真实子进程可被插话停止并在登记中彻底清除")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    workers = (
        APP / "voice_feature" / "runtime_workers.py"
    ).read_text(encoding="utf-8")
    check("SPEECH_PROCESSES.spawn(" in stt
          and "SPEECH_PROCESSES.interrupt(" in stt,
          "STT 的启动和插话停止共用同一进程登记")
    check("lifecycle.register_closeable(" in workers and '"speech"' in workers,
          "主程序退出生命周期会终止剩余 TTS 子进程")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
