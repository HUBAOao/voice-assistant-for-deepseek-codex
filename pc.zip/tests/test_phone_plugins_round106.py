# -*- coding: utf-8 -*-
"""Extension page contract: lifecycle, market trust, generations and fallback UI."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
JAVA = ROOT / "work" / "android-app" / "java" / "com" / "hubao" / "voiceassistant"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    plugins = (APP / "phone_feature" / "ui" / "plugins.js").read_text(
        encoding="utf-8"
    )
    activity = (
        JAVA / "NativeFinDeckActivity.java"
    ).read_text(encoding="utf-8")
    api = (JAVA / "NativeApiClient.java").read_text(encoding="utf-8")
    rollout = (APP / "features" / "plugin_rollback.py").read_text(
        encoding="utf-8"
    )
    console = (APP / "phone_feature" / "plugin_console.py").read_text(
        encoding="utf-8"
    )

    ids = {
        "pluginSummary", "pluginChoose", "pluginRefresh", "pluginFile",
        "pluginStatus", "marketSummary", "marketSource", "marketAdd",
        "marketRefresh", "marketList", "publisherList", "pluginList",
    }
    check(all(f'id="{item}"' in page for item in ids),
          "扩展页加载、空态、状态、ZIP、市场和发布者节点齐全")
    check('id="pluginStatus" class="taskMeta" aria-live="polite"' in page
          and "<details open>" in page
          and "权限是安装前声明，不是安全沙箱" in page,
          "旧 WebView 保留权限声明、市场展开区和可播报状态")
    check("pluginPullGeneration" in plugins
          and "pluginActionGeneration" in plugins
          and "generation !== pluginActionGeneration" in plugins,
          "旧 WebView 的读取、市场、ZIP 和动作响应按代际丢弃旧回写")
    check("setPluginStatus(" in plugins
          and "市场安装失败" in plugins
          and "安装失败" in plugins,
          "旧 WebView 在页内保留成功与失败结果")
    check("权限是声明，不是安全沙箱" in plugins
          and "确认权限后仍需手动启用" in plugins,
          "旧 WebView ZIP 安装先展示能力和权限")
    check('"rollback"' in plugins and "回滚后插件保持关闭" in plugins
          and "rollback_version" in plugins,
          "旧 WebView 显示可校验的上一版并明确确认回滚")
    check("已信任发布者" in plugins
          and '"untrust_publisher"' in plugins
          and "已安装插件保留" in plugins,
          "旧 WebView 显示已信任发布者并支持危险确认撤销")

    check("MAX_PLUGIN_ARCHIVE" in activity
          and "插件包超过 8 MB" in activity
          and "postPluginArchive" in api
          and "X-FinDeck-Plugin-Permissions" in api,
          "原生 ZIP 安装使用后端同口径大小上限并提交确认权限")
    check("pluginActionGeneration" in activity
          and "pluginMutationInFlight" in activity
          and "pendingPluginPageGeneration" in activity
          and "pluginPageCurrent(" in activity,
          "原生加载、动作、市场、信任和 ZIP 都有页面归属与重复提交保护")
    check('"rollback"' in activity
          and '"untrust_publisher"' in activity
          and "pluginNotice" in activity
          and "扩展操作已完成" in activity,
          "原生扩展页包含回滚、发布者撤销和页内持久结果")
    plugin_source = activity.split(
        "private void showPlugins()", 1
    )[-1].split("private void showAcceptance()", 1)[0]
    check("loadPluginsInto(list);" in plugin_source
          and "lastPluginsResponse" in plugin_source
          and "private void closePageOverlay()" not in plugin_source,
          "原生安装后原地刷新，关闭重开不能由旧异步回调触发")
    check("def rollback(" in rollout
          and "回滚插件需要明确确认" in rollout
          and "没有通过本机签名校验的可回滚版本" in rollout,
          "回滚只接受明确确认和通过本机签名校验的上一版")
    check('action == "rollback"' in console,
          "手机接口暴露回滚动作且继续走能力凭据 POST")
    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    with zipfile.ZipFile(apk) as archive:
        dex = archive.read("classes.dex")
    check(
        b"rollback" in dex
        and b"untrust_publisher" in dex
        and b"pluginActionGeneration" in dex
        and b"MAX_PLUGIN_ARCHIVE" in dex,
        "v1.143 APK 确实包含回滚、发布者撤销、动作代际和 ZIP 边界",
    )

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
