# -*- coding: utf-8 -*-
"""验收「手机网页里的 JavaScript 一定是能跑的」。

为什么非要有这一条：手机页整页只有一个 <script>，里面只要有**一个**语法错误，
整个脚本都不执行 —— 表现就是"手机上什么都点不了"（真发生过）。而 Python 这边
检查不出来：PAGE 是普通三引号字符串，我在 JS 字符串里写的 \n 会被 Python 先变成
真换行，JS 字符串就断了。所以必须用 node 真解析一遍。

没装 node 就跳过（不算失败），但要打印出来说明没验成。
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.path.insert(0, str(APP))

import phone_link                                     # noqa: E402


def scripts_of(html: str) -> list:
    return [b for b in re.findall(r"<script[^>]*>(.*?)</script>", html, re.S) if b.strip()]


def check_js(name: str, html: str, node: str, bad: list) -> None:
    blocks = scripts_of(html)
    if not blocks:
        print("  ✗ %s 里一个 <script> 都没找到" % name)
        bad.append(name)
        return
    src = "\n;\n".join(blocks)
    tmp = Path(tempfile.mkdtemp(prefix="vajs_")) / "page.js"
    tmp.write_text(src, encoding="utf-8")
    r = subprocess.run([node, "--check", str(tmp)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    if r.returncode == 0:
        print("  ✓ %s 的 JS 解析通过（%d 个 <script>，%d 字符）"
              % (name, len(blocks), len(src)))
    else:
        first = "\n".join((r.stderr or "").strip().splitlines()[:6])
        print("  ✗ %s 的 JS 有语法错误：\n%s" % (name, first))
        bad.append(name)
    # 顺手抓"字符串被真换行截断"这个经典写法
    for i, line in enumerate(src.splitlines(), 1):
        if line.count('"') % 2 and ("alert(" in line or "= \"" in line):
            print("     （第 %d 行引号不成对，八成是 \\n 被 Python 变成真换行了）：%s"
                  % (i, line.strip()[:70]))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    node = shutil.which("node")
    if not node:
        print("这台机器没有 node，跳过 JS 解析检查（没验成）")
        return 0
    bad: list = []
    print("① 源码里那份（PAGE）")
    check_js("phone_link.PAGE", phone_link.PAGE, node, bad)
    print("② 发出去的那份（phone_page.html，服务优先读它）")
    f = APP / "phone_page.html"
    if f.exists():
        check_js("phone_page.html", f.read_text(encoding="utf-8"), node, bad)
    else:
        print("  （没有 phone_page.html）")
    print("③ 真机上服务真正发给手机的那一份")
    try:
        tok = phone_link.load_token()
        with urllib.request.urlopen("http://127.0.0.1:8765/?k=%s" % tok, timeout=8) as r:
            served = r.read().decode("utf-8", "replace")
        check_js("服务发出去的页面", served, node, bad)
    except Exception as exc:                             # noqa: BLE001
        print("  （服务没在跑，跳过：%s）" % exc)

    print("\n不通过的用例数 = %d" % len(bad))
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
