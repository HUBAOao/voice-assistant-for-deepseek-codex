# -*- coding: utf-8 -*-
"""Focused tests for extracted phone conversation and schedule routes."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from phone_feature import session_schedule_routes as routes  # noqa: E402


def main() -> int:
    assert routes.SECURE_POST_PATHS >= {
        "/api/cmd", "/api/submit", "/api/send-media", "/api/upload", "/api/voice",
        "/api/threads/action", "/api/threads/new", "/api/target", "/api/schedule",
    }
    cleared = []
    status, body = routes.get_route(
        "/api/windows",
        get_windows=lambda: [
            {"title": "当前", "current": True, "id": "a", "project": "鳍舱"},
            "另一个",
            {"name": ""},
        ],
        get_target=lambda: "发送目标",
        get_target_id=lambda: "b",
        clear_target=lambda: cleared.append(True) or (True, "自动"),
        get_projects=lambda: [{"id": "p", "name": "鳍舱"}],
    )
    assert status == 200 and body["current"] == "当前"
    assert [item["name"] for item in body["windows"]] == ["当前", "另一个"]
    assert body["windows"][0]["project"] == "鳍舱"
    assert body["chosen"] == "" and body["chosen_id"] == ""
    assert cleared == [True]
    assert body["projects"][0]["name"] == "鳍舱"

    status, body = routes.get_route(
        "/api/windows",
        get_windows=lambda: [
            {"title": "同一个会话", "current": True, "id": "same"},
        ],
        get_target=lambda: "同一个会话",
        get_target_id=lambda: "same",
    )
    assert body["chosen"] == "同一个会话" and body["chosen_id"] == "same"

    cleared = []
    status, body = routes.get_route(
        "/api/windows",
        get_windows=lambda: [
            {"title": "同名旧目标", "current": True, "id": "current-id"},
        ],
        get_target=lambda: "同名旧目标",
        get_target_id=lambda: "",
        clear_target=lambda: cleared.append(True) or (True, "自动"),
    )
    assert body["chosen"] == "" and body["chosen_id"] == ""
    assert cleared == [True]

    assert routes.get_route(
        "/api/schedule", get_schedule=lambda: [{"text": "开会"}]
    )[1]["items"][0]["text"] == "开会"
    assert routes.get_route(
        "/api/replies", get_replies=lambda: [{"text": "原话"}]
    )[1]["items"][0]["text"] == "原话"

    result = routes.post_route(
        "/api/threads/action", {"action": "rename", "id": "t1"},
        on_thread_action=lambda action, thread_id, data: (True, "改好了"),
    )
    assert result and result[1] == {"ok": True, "msg": "改好了"}
    assert result[2] == ("会话操作", "rename · 改好了")

    result = routes.post_route(
        "/api/threads/new", {"project_id": "p1"},
        on_new_thread=lambda project_id: (True, project_id),
    )
    assert result and result[1]["msg"] == "p1"

    result = routes.post_route(
        "/api/target", {"title": "会话", "id": "t1"},
        on_target=lambda title: (True, title),
        get_target=lambda: "服务端确认",
    )
    assert result and result[1]["current"] == "服务端确认"

    result = routes.post_route(
        "/api/schedule",
        {"action": "toggle", "item": {"text": "开会"}},
        on_schedule=lambda action, data: (True, "已关闭"),
    )
    assert result and result[2] == ("日程开关", "开会")

    assert routes.get_route("/api/other") is None
    assert routes.post_route("/api/other", {}) is None
    print("test_session_schedule_routes: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
