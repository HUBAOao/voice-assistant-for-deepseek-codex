# -*- coding: utf-8 -*-
"""集中记忆归档：只手动生成、覆盖所有对话、能脱敏、能识别两种命令。"""
from __future__ import annotations

import json
import sqlite3
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(SRC))

import memory_archive  # noqa: E402

bad = 0


def check(cond: bool, text: str) -> None:
    global bad
    print(("  ✓ " if cond else "  ✗ ") + text)
    if not cond:
        bad += 1


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    with tempfile.TemporaryDirectory(prefix="va-memory-") as tmp:
        base = Path(tmp)
        (base / "memory.json").write_text(json.dumps([
            {"ts": 1791411470, "date": "2026-10-08", "text": "我喜欢喝美式咖啡"},
        ], ensure_ascii=False), encoding="utf-8")
        (base / "notes.md").write_text("明天买牛奶", encoding="utf-8")
        (base / "ledger.json").write_text(json.dumps([
            {"date": "2026-10-19", "item": "买菜", "amount": 30},
        ], ensure_ascii=False), encoding="utf-8")
        (base / "config.json").write_text(json.dumps({
            "schedules": [{"at": "08:00", "text": "早间播报"}],
        }, ensure_ascii=False), encoding="utf-8")
        (base / "diary.md").write_text("## 2026-10-19\n今天聊了语音助手。", encoding="utf-8")
        (base / "achievements.json").write_text(json.dumps({
            "days": ["2026-10-18", "2026-10-19"],
        }, ensure_ascii=False), encoding="utf-8")
        (base / "transcripts.md").write_text("- 2026-10-19 说了一句\n", encoding="utf-8")
        (base / "said.md").write_text("- 2026-10-19 念了一句\n", encoding="utf-8")
        (base / "phone-token.txt").write_text("SUPERSECRETTOKEN123456", encoding="utf-8")

        thread_db = base / "thread.sqlite"
        con = sqlite3.connect(thread_db)
        con.execute("create table thread_items (thread_id text, item_type text, "
                    "created_at_ms integer, item_json text)")
        con.executemany(
            "insert into thread_items values (?,?,?,?)",
            [
                ("t1", "userMessage", 1792400000000, json.dumps({
                    "content": [{"type": "input_text",
                                 "text": "帮我记一下 token=SUPERSECRETTOKEN123456"}]},
                    ensure_ascii=False)),
                ("t1", "agentMessage", 1792400001000, json.dumps({
                    "phase": "commentary", "text": "过程话不该进正文"},
                    ensure_ascii=False)),
                ("t1", "agentMessage", 1792400002000, json.dumps({
                    "phase": "final_answer", "text": "好的，已经记住了。"},
                    ensure_ascii=False)),
                ("t2", "userMessage", 1792400100000, json.dumps({
                    "content": [{"type": "input_text", "text": "另一个会话"}]},
                    ensure_ascii=False)),
            ])
        con.commit()
        con.close()

        state_db = base / "state.sqlite"
        con = sqlite3.connect(state_db)
        con.execute("create table threads (id text, title text, created_at integer, "
                    "updated_at integer, cwd text)")
        con.executemany("insert into threads values (?,?,?,?,?)", [
            ("t1", "语音助手项目", 1792400000, 1792400002, r"C:\proj\voice"),
            ("t2", "另一个会话", 1792400100, 1792400100, r"C:\proj\other"),
        ])
        con.commit()
        con.close()

        check(memory_archive.summary(base) is None, "没生成之前，摘要为空（不会自动归档）")
        info = memory_archive.build_archive(base_dir=base, thread_db=thread_db,
                                            state_db=state_db)
        md = (base / memory_archive.ARCHIVE_MD.name).read_text(encoding="utf-8-sig")
        data = json.loads((base / memory_archive.ARCHIVE_JSON.name).read_text(
            encoding="utf-8"))

        check(info["stats"]["threads"] == 2, "两个会话都进来了（所有对话，不只是一轮）")
        check("我喜欢喝美式咖啡" in md and "明天买牛奶" in md, "事实记忆和便签都在")
        check("买菜" in md and "早间播报" in md, "记账和日程都在")
        check("好的，已经记住了。" in md, "正经回答在")
        check("过程话不该进正文" not in md, "过程话不混进记忆正文")
        check("SUPERSECRETTOKEN123456" not in md, "令牌被脱敏")
        check("token=***" in md, "明文 token 被替换成 ***")
        check(data["stats"]["user_messages"] == 2, "JSON 统计能对上")
        check(info["md_bytes"] > 100, "归档文件真的写出来了")

        cases = {
            "集中记忆归档": "build",
            "帮我归档记忆": "build",
            "把所有对话归档": "build",
            "整理一下记忆": "build",
            "查看记忆归档": "view",
            "打开集中记忆归档": "view",
            "你还记得我喜欢喝什么吗": None,
            "打开记事本": None,
        }
        for phrase, want in cases.items():
            got = memory_archive.parse_command(phrase)
            check(got == want, f"指令「{phrase}」→ {got}")

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
