# -*- coding: utf-8 -*-
"""Lazy segmentation model lifetime, idle release, and loading races."""
from __future__ import annotations

import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.transcriber import Transcriber  # noqa: E402


class Model:
    def __init__(self, calls: list[str], gate: threading.Event | None = None):
        self.calls = calls

    def transcribe(self, _audio, **_kwargs):
        self.calls.append("transcribe")
        return ([SimpleNamespace(
            text="测试文字",
            no_speech_prob=0.0,
            avg_logprob=-0.1,
            start=0.0,
            end=1.0,
        )], None)


def make(calls: list[str], **changes):
    values = dict(
        model_name="small",
        device="cuda",
        compute_type="float16",
        language="zh",
        model_root=ROOT / "outputs" / "voice-to-text",
        cuda_ready_fn=lambda: True,
        asr_prompt="",
        asr_lock=threading.Lock(),
        hallucination_fn=lambda _text: False,
        normalize_fn=lambda text: text,
        model_factory=lambda *_args, **_kwargs: (
            calls.append("load") or Model(calls)
        ),
        idle_seconds=0.08,
        log=lambda text: calls.append("log:" + text),
    )
    values.update(changes)
    return Transcriber(**values)


def wait_until(predicate, timeout=2.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if predicate():
            return True
        time.sleep(0.01)
    return predicate()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls: list[str] = []
    transcriber = make(calls)
    check(
        transcriber.model is None and transcriber.device == "cuda",
        "初始化只准备设备配置，不加载模型",
    )
    transcriber.prepare_async()
    check(wait_until(lambda: transcriber.loaded), "后台加载成功")
    transcriber.begin_capture()
    time.sleep(0.14)
    check(transcriber.loaded, "按住录音期间超过空闲阈值也不会卸载")
    transcriber.end_capture()
    check(
        wait_until(lambda: transcriber.model is None),
        "录音结束且连续空闲后卸载模型",
    )
    check(transcriber.stats()["load_count"] == 1
          and transcriber.stats()["unload_count"] == 1,
          "一次加载对应一次卸载")

    calls.clear()
    transcriber = make(calls, idle_seconds=0.12)
    transcriber.begin_capture()
    check(
        wait_until(lambda: transcriber.loaded),
        "按下按键后后台加载与录音可同时进行",
    )
    transcriber.end_capture()
    check(transcriber.transcribe([0.0] * 1600) == "测试文字",
          "模型就绪后正常转写")
    time.sleep(0.06)
    check(transcriber.transcribe([0.0] * 1600) == "测试文字",
          "连续使用仍可转写")
    check(transcriber.stats()["load_count"] == 1,
          "连续使用时不会重复加载模型")
    transcriber.close()

    gate = threading.Event()
    calls.clear()

    def slow_factory(*_args, **_kwargs):
        calls.append("load")
        gate.wait(1.0)
        return Model(calls)

    transcriber = make(calls, model_factory=slow_factory, idle_seconds=0.05)
    started = time.monotonic()
    transcriber.begin_capture()
    check(
        time.monotonic() - started < 0.15 and not transcriber.loaded,
        "模型加载没有阻塞开始录音",
    )
    gate.set()
    check(wait_until(lambda: transcriber.loaded), "加载完成后可直接转写")
    transcriber.end_capture()
    transcriber.close()

    calls.clear()
    transcriber = make(calls)
    threads = [
        threading.Thread(target=transcriber.prepare_async)
        for _ in range(8)
    ]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    check(wait_until(lambda: transcriber.loaded) and calls.count("load") == 1,
          "并发请求只发起一次模型加载")
    transcriber.close()

    foreground = (
        APP / "voice_feature" / "runtime_main_foreground.py"
    ).read_text(encoding="utf-8")
    setup = (
        APP / "voice_feature" / "runtime_audio_setup.py"
    ).read_text(encoding="utf-8")
    check(
        "begin_capture()" in foreground
        and "end_capture()" in foreground
        and "识别引擎按需待命" in setup,
        "按住开始/松开结束接入同一模型租约",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
