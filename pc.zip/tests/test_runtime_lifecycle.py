# -*- coding: utf-8 -*-
"""Runtime daemon and shutdown assembly stays independent and idempotent."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_lifecycle import RuntimeLifecycle  # noqa: E402


class FakeThread:
    def __init__(self, *, target, name, daemon) -> None:
        self.target = target
        self.name = name
        self.daemon = daemon
        self.started = False
        self.alive = False

    def start(self) -> None:
        self.started = True
        self.alive = True

    def is_alive(self) -> bool:
        return self.alive


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    created: list[FakeThread] = []

    def factory(**kwargs):
        thread = FakeThread(**kwargs)
        created.append(thread)
        return thread

    lifecycle = RuntimeLifecycle(thread_factory=factory)
    calls: list[str] = []
    first = lifecycle.start_daemon("worker", lambda: calls.append("run"))
    second = lifecycle.start_daemon("worker", lambda: calls.append("duplicate"))
    check(first is second and len(created) == 1,
          "同名常驻任务仍存活时不会重复启动")
    check(created[0].name == "worker" and created[0].daemon is True,
          "后台任务带可诊断名称并保持守护线程")
    created[0].alive = False
    third = lifecycle.start_daemon("worker", lambda: calls.append("restart"))
    check(third is not first and len(created) == 2,
          "上一个任务结束后允许同名任务重新拉起")

    order: list[str] = []
    lifecycle.register_closeable("mic", lambda: order.append("mic"))

    def stop_tracker() -> None:
        order.append("tracker")
        raise RuntimeError("tracker stuck")

    lifecycle.register_closeable("tracker", stop_tracker)
    lifecycle.register_closeable("overlay", lambda: order.append("overlay"))
    errors = lifecycle.close()
    check(order == ["overlay", "tracker", "mic"],
          "退出按反向注册顺序清理悬浮窗、追踪器和麦克风")
    check(errors and errors[0][0] == "tracker"
          and isinstance(errors[0][1], RuntimeError),
          "单个清理失败会保留资源名和异常，不中断后续清理")
    check(lifecycle.closed and lifecycle.close() == [],
          "重复退出不会再次关闭同一批资源")
    try:
        lifecycle.start_daemon("late", lambda: None)
    except RuntimeError:
        pass
    else:
        bad += 1
        print("  ✗ 已退出的生命周期仍允许启动新任务")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    for marker in (
        "runtime_lifecycle.start_daemon(",
        "for resource, error in runtime_lifecycle.close():",
    ):
        check(marker in stt, f"main() 生命周期装配调用 {marker}")
    workers = (APP / "voice_feature" / "runtime_workers.py").read_text(
        encoding="utf-8"
    )
    check("register_shutdown_resources(" in stt
          and "lifecycle.register_closeable(" in workers,
          "main() 通过独立资源计划登记退出清理")
    check("threading.Thread(target=phone_worker" not in stt,
          "手机工作线程不再由 main() 直接拼 threading.Thread")
    check("threading.Thread(target=lambda: (time.sleep(7), self_check(True))"
          not in stt,
          "延迟启动自检不再内联在线程构造里")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
