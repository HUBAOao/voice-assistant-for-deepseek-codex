# -*- coding: utf-8 -*-
"""验收"安装包里该有的模块一个都不少"。

这条是补一个大坑：stt.py 在**模块级别**就 import remote_access / screen_share /
file_share，可 make_package.py 的清单里一直没写它们 —— 装到别人电脑上就是
一启动就 ModuleNotFoundError（表现正是"装了、有声音，但没窗口没悬浮窗"）。

规矩：包里的 .py import 了本项目的模块（开发目录里同名的 .py），那个模块就必须在包里；
真不该进包的（clone_voice，只在本机用）必须 import 在 try 里，不许裸着 import。
"""
from __future__ import annotations

import ast
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "outputs" / "voice-to-text"
PKG = ROOT / "outputs" / "语音助手-安装包"
ZIP = ROOT / "outputs" / "语音助手-安装包.zip"

# 故意不跟着包走的：语音克隆只装在这台开发机上，进包会把个人模型带出去。
MAYBE = {"clone_voice"}


def collect(node, in_try: bool, out: list) -> None:
    """把 import 收出来，顺便记住它在不在 try 里面。"""
    for child in ast.iter_child_nodes(node):
        if isinstance(child, ast.Import):
            for a in child.names:
                out.append((a.name.split(".")[0], in_try, child.lineno))
        elif isinstance(child, ast.ImportFrom):
            if child.level == 0 and child.module:
                out.append((child.module.split(".")[0], in_try, child.lineno))
        else:
            collect(child, in_try or isinstance(child, ast.Try), out)


def imports_of(path: Path) -> list:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    out: list = []
    collect(tree, False, out)
    return out


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    local = {p.stem for p in SRC.glob("*.py")}
    print("① 包里的每个 .py，import 到的本项目模块都必须也在包里")
    missing: dict = {}
    naked: dict = {}
    for p in sorted(PKG.glob("*.py")):
        for name, in_try, line in imports_of(p):
            if name not in local:
                continue
            if name in MAYBE:
                if not in_try:
                    naked.setdefault(name, []).append("%s:%d" % (p.name, line))
                continue
            if not (PKG / (name + ".py")).exists():
                missing.setdefault(name, []).append("%s:%d" % (p.name, line))
    check(not missing, "没有缺的模块" if not missing
          else "缺了 %s" % "; ".join("%s（%s 里 import）" % (k, ",".join(v))
                                    for k, v in sorted(missing.items())))
    check(not naked, "该在本机跑的模块都 import 在 try 里" if not naked
          else "裸着 import 了：%s" % naked)

    print("\n② 这几个以前漏掉的，现在必须在包里")
    for name in ("remote_access.py", "screen_share.py", "file_share.py",
                 "self_update.py", "site_publish.py", "download_page.py"):
        check((PKG / name).exists(), "安装包目录里有 %s" % name)

    print("\n③ zip 里也得真有（清单是从上一版 zip 长的，新文件不写进 ALWAYS_IN_ZIP 就进不去）")
    if not ZIP.exists():
        check(False, "zip 不在：%s" % ZIP)
    else:
        with zipfile.ZipFile(ZIP) as z:
            names = set(z.namelist())
        for name in ("remote_access.py", "screen_share.py", "file_share.py",
                     "self_update.py", "site_publish.py", "download_page.py",
                     "phone_page.html", "codex_threads.py",
                     "phone_feature/history_routes.py",
                     "phone_feature/request_auth.py",
                     "phone_feature/basic_routes.py",
                     "phone_feature/media_routes.py",
                     "phone_feature/static_routes.py",
                     "phone_feature/session_schedule_routes.py",
                     "phone_feature/ui/bootstrap.js",
                     "phone_feature/ui/chat.js",
                     "phone_feature/ui/conversations.js",
                     "phone_feature/ui/outbox.js",
                     "phone_feature/ui/media.js",
                     "phone_feature/ui/page_core.js",
                     "phone_feature/ui/page_runtime.js",
                     "phone_feature/ui/page_tools.js",
                     "phone_feature/ui/settings.js",
                     "phone_feature/ui/history.js",
                     "phone_feature/ui/tasks.js",
                     "phone_feature/ui/management.js",
                     "phone_feature/ui/plugins.js",
                     "phone_feature/ui/native-files.js",
                     "overlay_feature/dialogs.py",
                     "overlay_feature/presets_mixin.py",
                     "overlay_feature/schedule_mixin.py",
                     "overlay_feature/settings_mixin.py",
                     "overlay_feature/settings_content_mixin.py",
                     "overlay_feature/settings_pages_mixin.py",
                     "overlay_feature/settings_features_mixin.py",
                     "overlay_feature/settings_reminders_mixin.py",
                     "overlay_feature/settings_actions_mixin.py",
                     "overlay_feature/settings_collect_mixin.py",
                     "overlay_feature/settings_persistence_mixin.py",
                     "overlay_feature/settings_appearance_mixin.py",
                     "overlay_feature/settings_navigation_mixin.py",
                     "overlay_feature/settings_qr_mixin.py",
                     "overlay_feature/qr_presentation.py",
                     "overlay_feature/qr_save_dialog.py",
                     "overlay_feature/window_control.py",
                     "overlay_feature/window_geometry.py",
                     "voice_feature/action_dispatch.py",
                     "voice_feature/control_commands.py",
                     "voice_feature/talk_state.py",
                     "voice_feature/send_verification.py",
                     "voice_feature/feature_commands.py",
                     "voice_feature/local_commands.py",
                     "voice_feature/maintenance_commands.py",
                     "voice_feature/personal_commands.py",
                     "voice_feature/runtime_workers.py",
                     "voice_feature/runtime_startup.py",
                     "voice_feature/runtime_bootstrap.py",
                     "voice_feature/runtime_audio_setup.py",
                     "voice_feature/runtime_session_state.py",
                     "voice_feature/runtime_startup_callbacks.py",
                     "voice_feature/runtime_utterance_dispatch.py",
                     "voice_feature/runtime_entry_pipeline.py",
                     "voice_feature/runtime_main_foreground.py",
                     "overlay_feature/settings_remote_clipboard_mixin.py",
                     "overlay_feature/settings_remote_network_mixin.py",
                     "overlay_feature/settings_memory_panel_mixin.py",
                     "overlay_feature/settings_data_panel_mixin.py",
                     "overlay_feature/settings_uninstall_panel_mixin.py",
                     "overlay_feature/settings_uninstall_actions_mixin.py",
                     "overlay_feature/settings_uninstall_dialog_mixin.py",
                     "voice_feature/microphone_recovery.py",
                     "voice_feature/speech_playback.py",
                     "phone_feature/phone_ingress.py",
                     "voice_feature/runtime_support.py"):
            check(name in names, "zip 里有 %s" % name)
        check(
            "tests/test_runtime_startup_callbacks.py" in names
            and "tests/test_android_contact_cards.py" in names,
            "zip 里有本轮两个针对性回归",
        )
        check(
            "tests/test_runtime_utterance_dispatch.py" in names
            and "tests/test_android_storage_volumes.py" in names,
            "zip 里有单句调度与存储卷针对性回归",
        )
        check(
            "tests/test_runtime_entry_pipeline.py" in names
            and "tests/test_android_native_tts.py" in names,
            "zip 里有启动管线与手机朗读针对性回归",
        )
        check(
            "tests/test_runtime_foreground_entry.py" in names
            and "tests/test_android_power_context.py" in names,
            "zip 里有前台入口与电源散热针对性回归",
        )
        with zipfile.ZipFile(ZIP) as archive:
            packaged_config = json.loads(
                archive.read("config.json").decode("utf-8")
            )
        check(
            packaged_config.get("voice") == "dfy:大肥鱼"
            and packaged_config.get("perf_mode") == "quality"
            and packaged_config.get("overlay_enabled") is True,
            "出厂音色、性能模式和兼容悬浮窗不被本机偏好覆盖",
        )
        # 包里所有 .py 都该在 zip 里（不然就是漏发）
        pk = {p.name for p in PKG.glob("*.py")}
        lost = sorted(n for n in pk if n not in names)
        check(not lost, "安装包里 %d 个 .py 全在 zip 里" % len(pk)
              if not lost else "zip 里少了：%s" % lost)
        source_apk = ROOT / "outputs" / "语音助手-手机端.apk"
        with zipfile.ZipFile(ZIP) as archive:
            packaged_apk = archive.read("语音助手-手机端.apk")
        check(
            hashlib.sha256(source_apk.read_bytes()).digest()
            == hashlib.sha256(packaged_apk).digest(),
            "安装包内 APK 与当前交付 APK 逐字节一致",
        )

    print("\n④ 不该进包的东西别进去（个人数据 / 模型 / 克隆）")
    if ZIP.exists():
        with zipfile.ZipFile(ZIP) as z:
            names = z.namelist()
        for bad_name in ("clone_voice.py", ".venv", "models", "download-stats.json"):
            # 只认"整个文件 / 整个文件夹"，别把 tests/test_clone_voice.py 这种名字算进去
            hit = [n for n in names
                   if n == bad_name or n.startswith(bad_name + "/")
                   or ("/" + bad_name + "/") in n]
            check(not hit, "zip 里没有 %s" % bad_name)
    for junk in ("clone_voice.py",):
        check(not (PKG / junk).exists(), "安装包目录里没有 %s" % junk)

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
