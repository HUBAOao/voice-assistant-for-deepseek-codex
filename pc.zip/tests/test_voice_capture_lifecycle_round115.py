# -*- coding: utf-8 -*-
"""Talk capture clears barge-in state before the next transcript is gated."""
from __future__ import annotations

import sys
import tempfile
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.audio_capture import (  # noqa: E402
    continue_long_capture,
    trim_capture_to_limit,
)
from voice_feature.talk_capture import (  # noqa: E402
    TalkCaptureDependencies,
    capture_talk_utterance,
)
from voice_feature.speech_status import mark_speaking_stopped  # noqa: E402


class Status:
    def set(self, *_args, **_kwargs) -> None:
        pass

    def level(self, *_args, **_kwargs) -> None:
        pass


class Recorder:
    def __init__(self) -> None:
        self.last_cut = False

    def _read(self) -> np.ndarray:
        return np.zeros(1024, dtype=np.float32)


class Duplex:
    def __init__(self, events: int) -> None:
        self.events = events

    def audio_frame(self, _level: float):
        if self.events <= 0:
            return None
        self.events -= 1
        return "barge"


def build(
    records: list[np.ndarray | None],
    *,
    cuts: list[bool],
    speaking_now: bool,
    duplex_events: int = 0,
    self_speech: dict | None = None,
) -> tuple[TalkCaptureDependencies, dict, list[str], Recorder]:
    recorder = Recorder()
    queue = list(records)
    events: list[str] = []
    speech = self_speech if self_speech is not None else {"on": speaking_now}

    def safe_record(*_args, **kwargs):
        on_level = kwargs.get("on_level")
        if on_level is not None:
            for _ in range(6):
                on_level(
                    0.2,
                    np.ones(1024, dtype=np.float32),
                )
        recorder.last_cut = cuts.pop(0) if cuts else False
        return queue.pop(0) if queue else None

    deps = TalkCaptureDependencies(
        recorder=recorder,
        rate=16000,
        cfg={"caption_enabled": False},
        self_speech=speech,
        music={"on": False},
        spoken_flag={"first": False},
        status=Status(),
        syslog=lambda *_args: None,
        shut_up=lambda: events.append("shut_up"),
        speaking_now=lambda: speaking_now,
        duplex=Duplex(duplex_events),
        cancel_reference_echo=lambda audio, _rate: audio,
        spectrum_bands=lambda _audio, _rate: [],
        transcriber=type(
            "Transcriber",
            (),
            {"transcribe": lambda _self, _audio: "用户的话"},
        )(),
        safe_calibrate=lambda: 0.02,
        safe_record=safe_record,
        checked_pause=lambda: False,
        on_speech=lambda: None,
        hint="测试",
        wake_enabled=True,
    )
    return deps, speech, events, recorder


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    rate = 16000
    one_second = np.ones(rate, dtype=np.float32)

    deps, speech, events, _ = build(
        [one_second],
        cuts=[False],
        speaking_now=True,
        duplex_events=1,
    )
    capture_talk_utterance(deps)
    check(events == ["shut_up"], "插话触发一次停播")
    check(speech["on"] is False,
          "停播状态文件尚未落盘时也不会恢复旧回声标记")

    speech = {"on": True}
    deps, _, events, _ = build(
        [one_second],
        cuts=[False],
        speaking_now=True,
        duplex_events=0,
        self_speech=speech,
    )
    capture_talk_utterance(deps)
    check(not events and speech["on"] is True,
          "没有插话时保留本次回声过滤标记")

    deps, _, _, recorder = build(
        [one_second, np.full(rate, 2.0, dtype=np.float32)],
        cuts=[False, True],
        speaking_now=False,
    )
    audio = capture_talk_utterance(deps)
    check(audio is not None and audio.size == rate,
          "正常静音断句只提交第一段")
    check(not recorder.last_cut,
          "短句提交后不进入长句续录")

    chunk = np.ones(rate * 25, dtype=np.float32)
    deps, _, _, _ = build(
        [chunk, chunk, chunk, chunk, chunk, chunk],
        cuts=[True] * 6,
        speaking_now=False,
    )
    audio = capture_talk_utterance(deps)
    check(audio is not None and audio.size == rate * 120,
          "默认 25 秒硬切长句严格止于 120 秒")
    check(not continue_long_capture(True, rate * 120, rate),
          "到达硬上限后不再请求下一段")
    trimmed = trim_capture_to_limit(
        np.ones(rate * 8, dtype=np.float32),
        rate * 115,
        rate,
    )
    check(trimmed.size == rate * 5,
          "最后一块只保留上限内的 5 秒")
    check(trim_capture_to_limit(
        np.ones(rate, dtype=np.float32),
        rate * 121,
        rate,
    ).size == 0, "已经超限的输入不会继续拼接")

    with tempfile.TemporaryDirectory() as folder:
        status_path = Path(folder) / "speak.json"
        status_path.write_text(
            json.dumps({"active": True, "text": "旧回答", "ts": 1.0}),
            encoding="utf-8",
        )
        check(mark_speaking_stopped(status_path, clock=lambda: 2.0),
              "插话停止会同步写回权威朗读状态")
        stopped = json.loads(status_path.read_text(encoding="utf-8"))
        check(stopped["active"] is False and stopped["ts"] == 2.0,
              "状态文件立即显示已停播，不等待子进程回写")

    source = (APP / "voice_feature" / "talk_capture.py").read_text(
        encoding="utf-8"
    )
    stt_source = (APP / "stt.py").read_text(encoding="utf-8")
    check("interrupted[\"on\"] = True" in source
          and "deps.self_speech[\"on\"] = False" in source,
          "插话状态清理接在真实采集回调内")
    check("trim_capture_to_limit(" in source
          and "while total < limit" in source,
          "长句续录使用同一硬上限而不是固定块数")
    check("mark_speaking_stopped(SPEAK_STATUS_FILE)" in stt_source,
          "真实 shut_up 路径同步清掉朗读状态")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
