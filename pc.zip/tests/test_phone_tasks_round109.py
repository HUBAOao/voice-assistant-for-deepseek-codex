# -*- coding: utf-8 -*-
"""Round 109 native task deck and AgentPool page contracts."""
from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))
import version as app_version  # noqa: E402

JAVA = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant"
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    tasks_js = (APP / "phone_feature" / "ui" / "tasks.js").read_text(
        encoding="utf-8"
    )
    runtime = (APP / "phone_feature" / "ui" / "page_runtime.js").read_text(
        encoding="utf-8"
    )
    routes = (APP / "phone_feature" / "console_routes.py").read_text(
        encoding="utf-8"
    )
    version = (APP / "version.py").read_text(encoding="utf-8")

    task_source = activity.split(
        "private void showTasks()", 1
    )[-1].split("private void showHistorySearchPage()", 1)[0]
    render = activity.split(
        "private void renderTasks(", 1
    )[-1].split("private String taskStatusText(", 1)[0]
    task_action = activity.split(
        "private String taskActionLabel(String action)", 1
    )[-1].split("private void addAgentPool(", 1)[0]
    review = activity.split(
        "private void addTaskReview(", 1
    )[-1].split("private String tail(", 1)[0]
    agent = activity.split(
        "private void addAgentPool(", 1
    )[-1].split("private void showHistorySearchPage()", 1)[0]
    overlay = activity.split(
        "private void pageOverlay(", 1
    )[-1].split("private void discardClosingPageOverlay(", 1)[0]
    back = activity.split(
        "public void onBackPressed()", 1
    )[-1].split("protected void onDestroy()", 1)[0]

    check(
        "taskItems" in tasks_js
        and "after=" in tasks_js
        and "d.reset" in tasks_js
        and "d.ids" in tasks_js
        and "taskCursor" in tasks_js
        and "taskTransportOnline" in tasks_js,
        "旧 tasks.js 继续作为任务列表、游标、reset 与权威 ids 规格",
    )
    check(
        '"/api/tasks?limit=100&sync=1&after="' in task_source
        and "taskFirstLoad ? 0 : taskCursor" in task_source
        and 'result.json.optBoolean("reset", false)' in task_source
        and "taskItems.put(id, task);" in task_source
        and "if (!keep.contains(id)) taskItems.remove(id);" in task_source
        and "taskTransportOnline = transport != null" in task_source,
        "原生任务台按旧页协议增量合并并保留断线现场",
    )
    check(
        "private boolean taskPageCurrent(" in task_source
        and "pageGeneration == taskPageGeneration" in task_source
        and "overlayActive != null" in task_source
        and "list.getParent() != null" in task_source
        and "startTaskPolling(list, pageGeneration)" in task_source
        and task_source.count("!taskPageCurrent(") >= 2,
        "任务轮询与首轮读取同时绑定页面代际、覆盖层归属和列表实例",
    )
    check(
        "taskPageGeneration++;" in overlay
        and "taskRequestGeneration++;" in overlay
        and "agentRequestGeneration++;" in overlay
        and "taskMutationInFlight = false;" in overlay
        and "taskNotice = \"\";" in overlay,
        "换页或关闭任务台会作废旧任务、Agent 请求和操作锁",
    )
    check(
        "if (taskNotice.length() > 0)" in render
        and "taskNoticeDanger" in render
        and '"连接中断，保留当前状态；恢复后自动补齐"' in render
        and '"任务列表没读出来"' in render
        and '"重试"' in activity
        and '"还没有任务。新建一个后，批准、工具、测试和只读 diff 会出现在这里。"'
        in render,
        "任务台保留连接状态、页内结果、断线重试和独立空态",
    )
    check(
        "if (taskMutationInFlight)" in task_action
        and "上一项任务操作还没结束" in task_action
        and "taskRequestGeneration++;" in task_action
        and "final int pageGeneration = taskPageGeneration;" in task_action
        and "if (!taskPageCurrent(list, pageGeneration))" in task_action
        and "taskMutationInFlight = false;" in task_action
        and "taskNoticeDanger = !result.ok();" in task_action
        and "if (result.ok()) {\n                                loadTasksInto(list);"
        in task_action,
        "任务写操作防重复提交，旧页响应不能回写，失败不刷新掉当前现场",
    )
    check(
        'private String taskActionLabel(String action)' in activity
        and 'return "新建任务";' in task_action
        and 'return "批准";' in task_action
        and 'return "拒绝";' in task_action
        and 'return "取消任务";' in task_action
        and 'return "排队消息";' in task_action
        and 'return "编辑排队消息";' in task_action
        and 'return "取消排队消息";' in task_action,
        "新建、批准、拒绝、取消和排队消息都有明确页内操作结果",
    )
    check(
        "confirmTaskApproval(id, approval, list);" in render
        and '"批准执行？"' in task_source
        and 'approval.optString("command", "")' in task_source
        and '"取消这个任务？"' in render
        and '"正在运行的 Codex 回合会停止。"' in render
        and 'taskAction(id, "reject", null, list);' in render,
        "高风险批准与运行任务取消先危险确认，拒绝继续直接提交",
    )
    check(
        '"排队消息"' in task_source
        and '"编辑排队消息"' in task_source
        and '"加入排队"' in task_source
        and '"message_edit"' in task_source
        and '"message_cancel"' in task_source
        and '("queued".equals(' in task_source
        and '"sending".equals(' in task_source
        and '"failed".equals(' in task_source,
        "排队消息可新增、编辑和取消，排队、注入中与失败状态都保留",
    )
    check(
        "(tools == null ? 0 : tools.length()) - 12" in review
        and "(tests == null ? 0 : tests.length()) - 8" in review
        and "changeCount - 40" in review
        and "tail(tool.optString(\"output\", \"\"), 1600)" in review
        and 'task.optString("diff", "")' in review
        and "· diff" in review
        and 'reviewOpen ? "▾ " : "▸ "' in review,
        "任务审查显示最近工具、测试、文件变化与只读 diff，待批准默认展开",
    )
    check(
        "agentCardCurrent(" in agent
        and "generation != agentRequestGeneration" in agent
        and '"AgentPool 没读出来"' in agent
        and '"AgentPool 没读出来；已有 worktree 和任务现场仍保留。"'
        in agent
        and '"agent-load-failure"' in agent
        and "clearAgentDynamicRows(card);" in agent,
        "AgentPool 读取绑定卡片与页面代际，断线保留已有 worktree 和任务",
    )
    check(
        '"新建 worktree"' in agent
        and '"派 Agent"' in agent
        and '"刷新状态"' in agent
        and '"移除 worktree？"' in agent
        and 'extra.put("confirm", true);' in agent
        and '"submit"' in agent
        and 'extra.put("cwd", path);' in agent
        and '"remove-worktree"' in agent,
        "原生 AgentPool 覆盖创建、派 Agent、刷新和危险移除 worktree",
    )
    check(
        "i < Math.min(20, jobs.length())" in agent
        and 'job.optString("error", "")' in agent
        and 'job.optString("output", "")' in agent
        and "tail(output, 600)" in agent
        and '"还没有 Agent 任务。可在受管理的 worktree 上派一个。"' in agent,
        "Agent 任务显示错误、尾部输出和独立空态，与旧页最多 20 条一致",
    )
    check(
        "if (agentMutationInFlight)" in agent
        and "agentMutationInFlight = true;" in agent
        and "agentRequestGeneration++;" in agent
        and "if (!agentCardCurrent(" in agent
        and "agentMutationInFlight = false;" in agent
        and "setAgentNotice(" in agent,
        "AgentPool 写操作防重复提交，页内说明并拒绝旧卡片回写",
    )
    check(
        "if (overlayActive != null) {" in back
        and "if (isHistoryKeyboardVisible())" in back
        and "hideRootKeyboard();" in back
        and back.index("hideRootKeyboard();")
        < back.index("closePageOverlay();", back.index("hideRootKeyboard();")),
        "任务编辑键盘可见时第一次返回只收键盘，第二次才关闭任务台",
    )
    check(
        'action == "submit"' in routes
        and 'ops.submit(' in routes
        and 'action == "remove-worktree"' in routes
        and 'data.get("confirm") is not True' in routes
        and '"message_edit"' in routes
        and '"message_cancel"' in routes,
        "服务端 Agent 提交与 worktree 移除确认边界、任务消息操作保持可用",
    )
    check(
        'id="page-tasks"' in (APP / "phone_page.html").read_text(
            encoding="utf-8"
        )
        and 'document.getElementById("agentRefresh").onclick' in runtime
        and '"给这个 worktree 派一个 Codex 任务"' in runtime
        and 'action: "submit"' in runtime
        and 'action: "create-worktree"' in runtime,
        "旧 WebView 仍保留任务台、AgentPool 刷新、派任务和新建 worktree",
    )
    check(
        "鳍舱第一百零九轮原生任务台整页收口" in version
        and 'PHONE_VERSION = f"1.{len(PHONE_CHANGELOG)}"' in version,
        "手机端版本表新增第一百零九轮",
    )

    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    with zipfile.ZipFile(apk) as archive:
        dex = archive.read("classes.dex")
    check(
        b"taskPageCurrent" in dex
        and b"confirmTaskApproval" in dex
        and b"agentSubmitDialog" in dex
        and b"agentMutationInFlight" in dex
        and b"clearAgentDynamicRows" in dex,
        "最终 APK 含任务页代际、批准确认和 AgentPool 派任务",
    )
    aapt2 = Path(r"F:\android-dev\sdk\build-tools\34.0.0\aapt2.exe")
    manifest_dump = subprocess.run(
        [str(aapt2), "dump", "xmltree", str(apk),
         "--file", "AndroidManifest.xml"],
        check=True, capture_output=True, text=True, encoding="utf-8",
    ).stdout
    check(
        f'versionName(0x0101021c)="{app_version.PHONE_VERSION}"'
        in manifest_dump
        and "versionCode(0x0101021b)="
        f"{1000 + len(app_version.PHONE_CHANGELOG)}" in manifest_dump,
        "最终 APK 版本与当前手机版本表一致",
    )

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
