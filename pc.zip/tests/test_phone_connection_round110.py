# -*- coding: utf-8 -*-
"""Round 110 native connection, replies, update and offline contracts."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
JAVA = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant"
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    download = (APP / "download_page.py").read_text(encoding="utf-8")
    page_core = (APP / "phone_feature" / "ui" / "page_core.js").read_text(
        encoding="utf-8"
    )
    report = (JAVA / "DiagnosticReport.java").read_text(encoding="utf-8")

    status = activity.split(
        "private void showStatus()", 1
    )[-1].split("private void showRawReplies()", 1)[0]
    status_render = activity.split(
        "private void renderStatus(", 1
    )[-1].split("private void addPair(", 1)[0]
    raw = activity.split(
        "private void showRawReplies()", 1
    )[-1].split("private void shareCurrentConversation()", 1)[0]
    update_row = activity.split(
        "private void refreshNativeUpdateRow(", 1
    )[-1].split("private void resolveNativeUpdate(", 1)[0]
    resolver = activity.split(
        "private void resolveNativeUpdate(", 1
    )[-1].split("private JSONObject readUpdateJson(", 1)[0]
    offline = activity.split(
        "private void showNativeOffline()", 1
    )[-1].split("private void openCompatibility()", 1)[0]
    consume = activity.split(
        "private void consume(NativeApiClient.Response result)", 1
    )[-1].split("private JSONObject mergeLocalEcho(", 1)[0]
    install = activity.split(
        "private void installNativeApk(", 1
    )[-1].split("private void openVpnSettingsPage()", 1)[0]
    destroy = activity.split(
        "protected void onDestroy()", 1
    )[-1].split("private static final class MaxHeightScrollView", 1)[0]
    results = activity.split(
        "protected void onActivityResult(", 1
    )[-1].split("private void writeDiagnosticExport(", 1)[0]

    check(
        "statusRequestGeneration" in status
        and "statusActiveList = list" in status
        and "statusPageCurrent(list, generation)" in status
        and "list == statusActiveList" in status
        and "overlayActive != null" in status,
        "连接状态读取绑定请求代际、当前列表和覆盖层归属",
    )
    check(
        '"连接状态只读到一部分"' in status_render
        and "版本读取失败：" in status_render
        and "电脑信息读取失败：" in status_render
        and '"刷新状态"' in status_render,
        "连接状态分别显示版本/电脑信息失败并保留原地刷新",
    )
    check(
        "DiagnosticReport.snapshot(" in status_render
        and "last_transport_error" in status_render
        and '"复制诊断"' in status_render
        and '"分享诊断"' in status_render
        and '"保存诊断快照"' in status_render,
        "连接状态提供隐私受限诊断的复制、分享和保存",
    )
    check(
        "REQ_STATUS_DIAGNOSTIC_SAVE" in activity
        and "request == REQ_STATUS_DIAGNOSTIC_SAVE" in results
        and "已取消系统保存，诊断快照没有写入文件" in results
        and "writeStatusDiagnosticExport(data.getData())" in results
        and "statusPageCurrent(statusActiveList, generation)" in activity,
        "诊断保存区分成功、取消和旧页面返回",
    )
    check(
        "rawRepliesRequestGeneration" in raw
        and "rawRepliesActiveList = list" in raw
        and "rawRepliesPageCurrent(list, generation)" in raw
        and "list == rawRepliesActiveList" in raw
        and "overlayActive != null" in raw,
        "看原话读取绑定请求代际、当前列表和覆盖层归属",
    )
    check(
        "lastRawReplies" in raw
        and '"刷新失败，显示上次加载"' in raw
        and "renderRawReplies(list, result)" in raw
        and "result.ok()" in raw,
        "看原话断线保留上次现场，成功空列表显示独立空态",
    )
    check(
        "addRawRepliesTools(list)" in raw
        and "loadRawRepliesInto(list)" in raw
        and "copyText(text)" in raw
        and '"原话已复制"' in raw,
        "看原话支持原地刷新和逐条显式复制",
    )
    check(
        "phone.optString(\"url\", \"\")" in resolver
        and "resolveHttpDownloadUrl(" in resolver
        and "snapshot.put(\"download_url\", downloadUrl)" in resolver
        and "native_update_base" in resolver,
        "设置更新解析公网清单中的真实 APK 地址并记住下载页",
    )
    check(
        "nativeUpdateDownloadUrl.length() > 0" in activity
        and "nativeUpdateDownloadUrl = snapshot.optString(" in update_row
        and "nativeUpdateDownloadUrl.length() > 0" in
        activity.split("final TextView updateAction", 1)[-1].split(
            "basic.addView(updateAction", 1
        )[0],
        "设置一键更新不再固定下载电脑上的旧 app.apk",
    )
    check(
        "private String resolveHttpDownloadUrl(" in activity
        and '"http".equalsIgnoreCase(scheme)' in activity
        and '"https".equalsIgnoreCase(scheme)' in activity
        and "uri.getHost() == null" in activity,
        "更新下载地址只接受带主机的 http(s) 地址",
    )
    check(
        "nativeInstallReturnPending = true" in install
        and "nativeInstallReturnVersion = Ver.VERSION_NAME" in install
        and "nativeInstallReturnPending = false" in install
        and "这次安装没有完成" in activity
        and "已更新到 v" in activity,
        "安装页返回按真实版本变化反馈，不把取消安装说成成功",
    )
    check(
        '"检查更新"' in offline
        and 'phone.optString("url", "")' in offline
        and "offlineAvailableVersion" in offline
        and "再点一次下载并交给系统安装" in offline,
        "离线页可用记住的公网清单检查并下载真实新版",
    )
    check(
        "retryConnectionFromOffline()" in offline
        and "正在重新连接电脑；成功前会保留这一页" in activity
        and "hideNativeOffline();" not in activity.split(
            "retry.setOnClickListener", 1
        )[1].split("scan.setOnClickListener", 1)[0],
        "离线重试不再先假装成功关闭页面，只有连接成功才隐藏",
    )
    check(
        "offlineRetryState.setText(\"仍然连不上：" in consume
        and "offlineRetryButton.setEnabled(true)" in consume,
        "离线重试失败恢复按钮并保留实际错误",
    )
    check(
        "offlineUpdateGeneration++" in activity
        and "generation != offlineUpdateGeneration" in offline
        and "offlineActive == null" in offline
        and "offlineUpdateGeneration++;" in destroy,
        "离线更新检查绑定代际，关闭或销毁后旧清单不能回写",
    )
    check(
        'statusRequestGeneration++;' in activity.split(
            "private void closePageOverlay()", 1
        )[-1].split("private void discardClosingPageOverlay", 1)[0]
        and 'rawRepliesRequestGeneration++;' in activity.split(
            "private void closePageOverlay()", 1
        )[-1].split("private void discardClosingPageOverlay", 1)[0]
        and "clearPendingStatusDiagnostic();" in activity,
        "关闭、换页或销毁会作废状态、原话和诊断保存",
    )
    check(
        "updDownloadUrl" in page_core
        and "(mf.phone || {}).url" in page_core
        and "window.VoiceApp.openUpdate(updDownloadUrl || apkUrl())" in page_core
        and '"url": url if path and path.exists() else ""' in download,
        "新旧页面都从更新清单取真实 APK，发布器提供相对下载地址",
    )
    check(
        "不含手机令牌、对话正文或文件内容" in report
        and "phone-token" not in report
        and "conversation" not in report.lower(),
        "诊断复制/分享继续沿用隐私受限格式，不携带令牌或对话正文",
    )
    check(
        "private long firstConnectionFailureAt" in activity
        and "12000L" in consume
        and "overlayActive == null" in consume,
        "离线入口延迟出现，状态页打开时不叠加离线覆盖层",
    )

    print("")
    print("不通过的用例数 =", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
