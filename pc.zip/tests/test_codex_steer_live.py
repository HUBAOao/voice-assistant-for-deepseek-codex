# -*- coding: utf-8 -*-
"""Live integration: inject a message into a real running Codex turn."""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import codex_threads  # noqa: E402
from features.codex_control import CodexControl  # noqa: E402
from features.tasks import TaskStore  # noqa: E402


def main() -> int:
    if os.environ.get("FIN_DECK_LIVE_CODEX") != "1":
        print("test_codex_steer_live: SKIP (set FIN_DECK_LIVE_CODEX=1)")
        return 0
    with tempfile.TemporaryDirectory() as raw:
        repo = Path(raw)
        (repo / "README.md").write_text("steer probe\n", encoding="utf-8")
        store = TaskStore(repo / "tasks.json")
        bridge = CodexControl(store)
        started = codex_threads._rpc_once("thread/start", {
            "cwd": str(repo),
            "ephemeral": True,
            "approvalPolicy": "never",
            "sandbox": "read-only",
        }, timeout=30)
        thread_id = str((started.get("thread") or {}).get("id") or "")
        assert thread_id, started
        turn_started = codex_threads._rpc_once("turn/start", {
            "threadId": thread_id,
            "approvalPolicy": "never",
            "sandboxPolicy": {"type": "readOnly"},
            "input": [{"type": "text", "text":
                       "Read README.md, then give a short answer. Start now."}],
        }, timeout=30)
        turn_id = str((turn_started.get("turn") or {}).get("id") or "")
        assert turn_id, turn_started
        task = store.create("inject probe", thread_id=thread_id)
        store.update(task["id"], source="codex_turn", source_id=turn_id,
                     active_turn_id=turn_id, status="running")
        result = bridge.inject_message(
            task["id"], "Additional instruction: include the word BANANA."
        )
        message = result["messages"][-1]
        assert message["status"] == "sent", message
        print("test_codex_steer_live: PASS", message["id"])
        try:
            codex_threads._rpc_once("turn/interrupt", {
                "threadId": thread_id, "turnId": turn_id,
            }, timeout=10)
        except Exception:
            pass
        time.sleep(0.5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
