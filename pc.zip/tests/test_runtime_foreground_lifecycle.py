# -*- coding: utf-8 -*-
"""Foreground greeting, workers, capture and exit share one assembly."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import voice_feature.runtime_foreground_assembly as assembly  # noqa: E402
from voice_feature.runtime_foreground_assembly import (  # noqa: E402
    ForegroundRuntimeDependencies,
    assemble_foreground_runtime,
)


class Status:
    def __init__(self) -> None:
        self.events = []

    def level(self, value, state, **_kwargs) -> None:
        self.events.append(("level", value, state))

    def set(self, state, **_kwargs) -> None:
        self.events.append(("state", state))


class Args:
    no_greeting = False
    target = ""
    default_input = False
    input = ""
    max_seconds = 30


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    events = []
    emitted = []
    status = Status()
    tracker = SimpleNamespace(hwnd=4321)
    scheduler = {}
    reconnected = {}
    run = {}
    registered = {}
    microphone = SimpleNamespace(stream="current-stream")
    capture = SimpleNamespace(
        audio_loop="audio-loop",
        checked_pause="checked-pause",
        tracker_worker="tracker-worker",
    )

    originals = (
        assembly.prepare_microphone_runtime,
        assembly.prepare_capture_runtime,
        assembly.register_shutdown_resources,
        assembly.run_voice_runtime,
    )

    def fake_microphone_runtime(**kwargs):
        events.append("microphone")
        reconnected["callback"] = kwargs["dependencies"].on_reconnected
        microphone.deps = kwargs["dependencies"]
        return SimpleNamespace(recovery=microphone)

    def fake_capture_runtime(deps):
        events.append("capture")
        registered["capture_deps"] = deps
        return capture

    def fake_register(*_args, **kwargs):
        events.append("register")
        registered.update(kwargs)

    def fake_run(deps):
        events.append("run")
        run["deps"] = deps
        return 7

    try:
        assembly.prepare_microphone_runtime = fake_microphone_runtime
        assembly.prepare_capture_runtime = fake_capture_runtime
        assembly.register_shutdown_resources = fake_register
        assembly.run_voice_runtime = fake_run
        deps = ForegroundRuntimeDependencies(
            mode="talk",
            args=Args(),
            tracker=tracker,
            wake_words=["大肥鱼"],
            cancel_words=["取消"],
            silence=1.0,
            runtime_lifecycle="lifecycle",
            instance_guard="guard",
            pause={"paused": False},
            set_paused=lambda value, why: None,
            runtime_tick=lambda: False,
            remote="remote",
            handle_lock="lock",
            handle_audio=lambda *_args, **_kwargs: False,
            status=status,
            cfg={
                "greeting_enabled": True,
                "greeting_delay": 2.5,
            },
            self_speech={},
            music={},
            spoken_flag={},
            stream="stream",
            recorder="recorder",
            device="device",
            rate=16000,
            level={"min_voiced": 2},
            resolve_device=lambda value: value,
            open_stream=lambda value: (value, 16000),
            make_recorder=lambda *args, **kwargs: args,
            find_window=lambda target: (99, target),
            paste_text=lambda *args, **kwargs: events.append(("paste",) + args),
            record_ptt=lambda recorder: recorder,
            has_utterance=lambda audio, rate: True,
            level_state=lambda value: "hearing" if value else "idle",
            on_hold_start=lambda: events.append("hold-start"),
            on_hold_stop=lambda: events.append("hold-stop"),
            on_speech=lambda: None,
            before_fallback_capture=lambda: None,
            syslog=lambda kind, text: events.append(("syslog", kind, text)),
            shut_up=lambda: None,
            speaking_now=lambda: False,
            duplex={},
            cancel_reference_echo=lambda audio, rate: audio,
            spectrum_bands=lambda *_args, **_kwargs: [],
            transcriber="transcriber",
            hint="说唤醒词",
            key_watcher_factory=lambda spec: spec,
            tracker_worker_factory=lambda value: value,
            start_scheduler=lambda target, paste: scheduler.update(
                target=target,
                paste=paste,
            ),
            build_greeting=lambda cfg, wake: f"{wake} - {cfg['greeting_delay']}",
            speak_greeting=lambda text, delay: events.append(
                ("greeting", text, delay)
            ),
            speak=lambda text: events.append(("speak", text)),
            emit=emitted.append,
            crash_file=Path("crash.txt"),
            overlay_process="overlay",
            phone_server="phone",
        )
        code = assemble_foreground_runtime(deps)
        check(code == 7, "最终退出码由前台装配原样返回")
        check(events[:3] == [
            ("greeting", "大肥鱼 - 2.5", 2.5),
            "microphone",
            "capture",
        ], "开机问候、麦克风和采集仍按历史顺序装配")
        check(scheduler["target"]() == 4321,
              "日程目标仍优先跟随当前前台窗口")
        scheduler["paste"]("日程内容", 99)
        check(("paste", "日程内容", 99) in events,
              "日程仍通过原粘贴函数发送")
        reconnected["callback"](2)
        check(("state", "idle") in status.events
              and ("syslog", "检", "麦克风已重连") in events,
              "麦克风重连保留状态、日志与提示")
        check(registered["microphone"]() == "current-stream"
              and registered["tracker_worker"] == "tracker-worker"
              and registered["overlay_process"] == "overlay"
              and registered["phone_server"] == "phone",
              "退出资源读取当前麦克风并登记追踪器、悬浮窗和手机服务")
        run_deps = run["deps"]
        check(run_deps.audio_loop == "audio-loop"
              and run_deps.instance_guard == "guard"
              and run_deps.crash_file == Path("crash.txt"),
              "最终循环消费已准备好的采集与退出依赖")
    finally:
        (
            assembly.prepare_microphone_runtime,
            assembly.prepare_capture_runtime,
            assembly.register_shutdown_resources,
            assembly.run_voice_runtime,
        ) = originals

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "runtime_foreground_assembly.py"
    ).read_text(encoding="utf-8")
    prepared = (
        APP / "voice_feature" / "runtime_main_foreground.py"
    ).read_text(encoding="utf-8")
    health_source = (APP / "core" / "health.py").read_text(encoding="utf-8")
    for inline in (
        "def _sched_target(",
        "def microphone_reconnected(",
        "microphone_runtime = prepare_microphone_runtime(",
        "capture_runtime = prepare_capture_runtime(",
    ):
        check(inline not in stt, f"main() 不再内联 {inline}")
    check("return run_prepared_foreground(" in stt
          and "return assemble_foreground_runtime(" in prepared
          and "def assemble_foreground_runtime(" in module,
          "main() 只调用已准备前台运行装配")
    check("voice_runtime_foreground_assembly" in health_source,
          "启动自检覆盖新的前台生命周期模块")
    module_body = module.split("def assemble_foreground_runtime", 1)[1]
    check(module_body.index("prepare_microphone_runtime(")
          < module_body.index("prepare_capture_runtime(")
          < module_body.index("register_shutdown_resources(")
          < module_body.index("run_voice_runtime("),
          "前台装配的麦克风、采集、清理和运行顺序固定")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
