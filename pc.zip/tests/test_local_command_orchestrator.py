# -*- coding: utf-8 -*-
"""The local command chain must stay ordered, explicit and first-hit-only."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.local_command_orchestrator import (  # noqa: E402
    LocalCommandStage,
    dispatch_local_command_stages,
)


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    order: list[str] = []
    result = dispatch_local_command_stages([
        LocalCommandStage("shortcut", lambda: order.append("shortcut")),
        LocalCommandStage(
            "focus",
            lambda: order.append("focus") or False,
        ),
        LocalCommandStage(
            "memory",
            lambda: order.append("memory") or True,
        ),
        LocalCommandStage(
            "reminder",
            lambda: order.append("reminder") or True,
        ),
    ])
    check(result.handled and result.stage == "focus" and not result.terminate,
          "首个命中组停下，并保留已有的 False 退出语义")
    check(order == ["shortcut", "focus"],
          "命中后不继续执行后续本地命令组")

    try:
        dispatch_local_command_stages([
            LocalCommandStage("same", lambda: None),
            LocalCommandStage("same", lambda: None),
        ])
        duplicate_rejected = False
    except ValueError:
        duplicate_rejected = True
    check(duplicate_rejected, "重复命令组名称在启动前被拒绝")

    stages = [
        LocalCommandStage(f"stage-{index}", lambda: None)
        for index in range(20)
    ]
    result = dispatch_local_command_stages(stages)
    check(not result.handled and result.stage == "",
          "全未命中原样交给 Codex")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "local_command_assembly.py"
    ).read_text(encoding="utf-8")
    check("dispatch_local_command_stages(stages)" in assembly,
          "本地命令装配使用统一编排器")
    check("if game_result is not None" not in stt
          and "if note_result is not None" not in stt
          and "if reminder_result is not None" not in stt,
          "旧的逐段 if/return 总编排已移除")
    check('"reminder",' in assembly
          and "dispatch_reminder_command(" in assembly,
          "提醒仍是本地命令组的最后优先级")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
