# -*- coding: utf-8 -*-
"""Verify real Codex turns can be mirrored into the local task store."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from features.tasks import TaskStore, sync_recent_threads  # noqa: E402


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        store = TaskStore(Path(raw) / "tasks.json")
        changed = sync_recent_threads(store, max_threads=3, max_turns=3)
        items = store.list(limit=100)
        assert changed > 0, "没有从 Codex 同步到任何 turn"
        assert items, "任务存储仍为空"
        assert any(item.get("source") == "codex_turn" for item in items)
        assert any(item.get("tool_calls") for item in items)
        print(f"test_task_sync: PASS ({changed} turns, {len(items)} tasks)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
