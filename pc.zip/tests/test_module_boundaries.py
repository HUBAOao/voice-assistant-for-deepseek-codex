# -*- coding: utf-8 -*-
"""Keep the next refactor from silently rebuilding the giant single-file design."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"

LIMITS = {
    "stt.py": 5860,
    "overlay.py": 3000,
    "phone_link.py": 860,
    "phone_page.html": 3045,
    "features/plugin_registry.py": 900,
    "features/plugin_signing.py": 420,
    "features/plugin_market.py": 360,
}

FORBIDDEN = {
    "voice_feature": {"stt", "overlay", "phone_link"},
    "overlay_feature": {"overlay"},
    "features": {"stt", "overlay", "phone_link"},
    "core": {"stt", "overlay", "phone_link"},
}


def imported_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            found.add(node.module.split(".", 1)[0])
    return found


def main() -> int:
    bad = []
    for relative, limit in LIMITS.items():
        path = APP / relative
        lines = len(path.read_text(encoding="utf-8").splitlines())
        ok = lines <= limit
        print(f"  {'✓' if ok else '✗'} {relative}: {lines} / {limit} 行")
        if not ok:
            bad.append(f"{relative} 超过 {limit} 行")
    for folder, forbidden in FORBIDDEN.items():
        for path in sorted((APP / folder).rglob("*.py")):
            imports = imported_modules(path)
            hit = sorted(imports & forbidden)
            relative = path.relative_to(APP).as_posix()
            ok = not hit
            print(f"  {'✓' if ok else '✗'} {relative}: 反向依赖 {hit or '无'}")
            if not ok:
                bad.append(f"{relative} 反向依赖 {hit}")
    if bad:
        print("\n模块边界失败：")
        for item in bad:
            print("  - " + item)
        return 1
    print("test_module_boundaries: PASS")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    raise SystemExit(main())
