# -*- coding: utf-8 -*-
"""Keep the next refactor from silently rebuilding the giant single-file design."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"

LIMITS = {
    "stt.py": 5550,
    "overlay.py": 2600,
    "phone_link.py": 760,
    "phone_page.html": 3060,
    "voice_feature/talk_state.py": 200,
    "voice_feature/send_verification.py": 80,
    "voice_feature/delivery_pipeline.py": 110,
    "voice_feature/mute_commands.py": 70,
    "voice_feature/audio_capture.py": 60,
    "voice_feature/local_command_orchestrator.py": 60,
    "voice_feature/talk_capture.py": 170,
    "voice_feature/runtime_lifecycle.py": 120,
    "voice_feature/instance_guard.py": 180,
    "voice_feature/runtime_workers.py": 160,
    "voice_feature/runtime_teardown.py": 120,
    "voice_feature/runtime_startup.py": 140,
    "voice_feature/runtime_bootstrap.py": 140,
    "voice_feature/runtime_audio_setup.py": 140,
    "voice_feature/runtime_microphone_setup.py": 120,
    "voice_feature/runtime_input_loop.py": 160,
    "voice_feature/phone_bridge_runtime.py": 160,
    "voice_feature/phone_schedule_runtime.py": 180,
    "voice_feature/phone_history_runtime.py": 360,
    "voice_feature/audio_loop.py": 130,
    "voice_feature/runtime_ticker.py": 100,
    "voice_feature/cli_options.py": 190,
    "voice_feature/microphone_recovery.py": 180,
    "phone_feature/phone_ingress.py": 140,
    "overlay_feature/settings_actions_mixin.py": 30,
    "overlay_feature/settings_collect_mixin.py": 130,
    "overlay_feature/settings_persistence_mixin.py": 120,
    "overlay_feature/settings_basic_mixin.py": 140,
    "overlay_feature/settings_wake_mixin.py": 180,
    "overlay_feature/settings_caption_mixin.py": 100,
    "overlay_feature/panel_controls.py": 260,
    "overlay_feature/settings_delivery_mixin.py": 40,
    "overlay_feature/settings_send_mixin.py": 80,
    "overlay_feature/settings_connection_mixin.py": 220,
    "overlay_feature/settings_features_mixin.py": 180,
    "overlay_feature/settings_reminders_mixin.py": 100,
    "overlay_feature/settings_appearance_mixin.py": 260,
    "overlay_feature/settings_update_mixin.py": 220,
    "overlay_feature/settings_maintenance_mixin.py": 150,
    "overlay_feature/settings_backup_mixin.py": 120,
    "overlay_feature/settings_memory_mixin.py": 180,
    "overlay_feature/settings_navigation_mixin.py": 110,
    "overlay_feature/settings_onboarding_mixin.py": 110,
    "overlay_feature/settings_shell_mixin.py": 220,
    "overlay_feature/settings_visuals_mixin.py": 250,
    "overlay_feature/settings_audio_mixin.py": 220,
    "phone_feature/request_auth.py": 130,
    "phone_feature/route_dispatch.py": 210,
    "features/plugin_registry.py": 900,
    "features/plugin_signing.py": 420,
    "features/plugin_market.py": 360,
}

FORBIDDEN = {
    "voice_feature": {"stt", "overlay", "phone_link"},
    "overlay_feature": {"overlay"},
    "features": {"stt", "overlay", "phone_link"},
    "core": {"stt", "overlay", "phone_link"},
}


def imported_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            found.add(node.module.split(".", 1)[0])
    return found


def main() -> int:
    bad = []
    for relative, limit in LIMITS.items():
        path = APP / relative
        lines = len(path.read_text(encoding="utf-8").splitlines())
        ok = lines <= limit
        print(f"  {'✓' if ok else '✗'} {relative}: {lines} / {limit} 行")
        if not ok:
            bad.append(f"{relative} 超过 {limit} 行")
    for folder, forbidden in FORBIDDEN.items():
        for path in sorted((APP / folder).rglob("*.py")):
            imports = imported_modules(path)
            hit = sorted(imports & forbidden)
            relative = path.relative_to(APP).as_posix()
            ok = not hit
            print(f"  {'✓' if ok else '✗'} {relative}: 反向依赖 {hit or '无'}")
            if not ok:
                bad.append(f"{relative} 反向依赖 {hit}")
    if bad:
        print("\n模块边界失败：")
        for item in bad:
            print("  - " + item)
        return 1
    print("test_module_boundaries: PASS")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    raise SystemExit(main())
