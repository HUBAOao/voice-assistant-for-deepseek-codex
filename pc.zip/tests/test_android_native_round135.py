# -*- coding: utf-8 -*-
"""Round 135 mobile completeness and rotation state retention."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "work" / "android-app" / "java" / "com" / "hubao" / "voiceassistant"
ACTIVITY = JAVA / "NativeFinDeckActivity.java"
MAIN = JAVA / "MainActivity.java"
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
PAGES = ROOT / "work" / "native-ui-harness" / "pages-smoke.json"
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = ACTIVITY.read_text(encoding="utf-8")
    main_source = MAIN.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    pages = PAGES.read_text(encoding="utf-8")
    retain = method_block(
        source,
        "public Object onRetainNonConfigurationInstance()",
        "private void configureWindow()",
    )
    create = method_block(
        source,
        "protected void onCreate(Bundle state)",
        "public Object onRetainNonConfigurationInstance()",
    )
    config = method_block(
        source,
        "public void onConfigurationChanged(Configuration configuration)",
        "protected void onResume()",
    )
    results = method_block(
        source,
        "protected void onActivityResult(int request, int result, Intent data)",
        "private void writeDiagnosticExport(",
    )
    permissions = method_block(
        source,
        "public void onRequestPermissionsResult(",
        "public void onConfigurationChanged(",
    )
    destroy = method_block(
        source,
        "protected void onDestroy()",
        "private final class PlusTriangleView",
    )

    print("① 旋转与字号重建保留当前交互现场")
    check(
        "private String activeSurface = \"\";" in source
        and "private String settingsExpandedCategory = \"\";" in source,
        "原生记录当前子页、抽屉和设置分类",
    )
    check(
        'saved.putString("native_surface", activeSurface);' in retain
        and 'saved.putString("native_settings_category", settingsExpandedCategory);'
        in retain,
        "配置重建保存当前交互现场",
    )
    check(
        'restoredSurface = saved.getString("native_surface", "");' in create
        and 'restoredSettingsCategory = saved.getString('
        in create
        and '"native_settings_category", ""' in create,
        "配置重建读取当前交互现场",
    )
    check(
        "private void restoreRetainedSurface(" in source
        and 'if ("settings".equals(surface))' in source
        and 'showSettings(settingsCategory);' in source
        and all(
            f'"{surface}".equals(surface)' in source
            and f"{method}();" in source
            for surface, method in (
                ("shots", "showShots"),
                ("files", "showFiles"),
                ("schedule", "showSchedule"),
                ("plugins", "showPlugins"),
                ("acceptance", "showAcceptance"),
                ("raw_replies", "showRawReplies"),
                ("status", "showStatus"),
                ("conversations", "showConversations"),
                ("history", "showHistory"),
            )
        ),
        "设置、九个子页和会话/历史层都能跨旋转恢复",
    )
    check(
        "configuration.orientation != lastOrientation" in config
        and "configuration.screenWidthDp != lastScreenWidthDp" in config
        and "lastOrientation = configuration.orientation;" in config
        and "root.requestLayout();" in config
        and "scheduleChatBackdropRefresh();" in config
        and "recreate();" not in config,
        "旋转和宽度变化原地重新布局并保留当前面板",
    )
    check(
        "activeSurface = \"settings\";" in source
        and "settingsExpandedCategory = opening ? title : \"\";" in source,
        "设置分类展开/收起同步保存现场",
    )

    print("\n② 系统往返、权限、文件与更新分支")
    for marker, label in (
        ("REQ_SCAN", "扫码"),
        ("REQ_FILES", "附件选择"),
        ("REQ_UPLOAD_FILE", "文件页上传"),
        ("REQ_PLUGIN", "插件文件"),
        ("REQ_DIAGNOSTIC_EXPORT", "诊断导出"),
        ("REQ_ACCEPT_FILE_OPEN", "真实文件打开"),
        ("REQ_ACCEPT_FILE_SAVE", "真实文件另存"),
        ("REQ_ACCEPT_FOLDER", "文件夹授权"),
        ("REQ_WALLPAPER", "壁纸选择"),
        ("REQ_AVATAR", "头像选择"),
    ):
        check(marker in results, f"{label}返回由原生 ActivityResult 处理")
    check(
        "REQ_ACCEPT_PERMISSIONS" in permissions
        and "markAcceptanceSystemReturn(900);" in permissions
        and "scheduleAcceptanceStatusRefresh(900);" in permissions,
        "权限页返回后恢复验收现场并重读状态",
    )
    check(
        "nativeInstallReturnPending" in source
        and "已从安装页返回，版本仍是 v" in source
        and "canRequestPackageInstalls()" in source,
        "安装/未知来源设置返回区分成功、取消和未授权",
    )
    check(
        "private boolean beginMediaViewerClose(" in source
        and "private void finishMediaViewer(" in source
        and "stopShotStageVideo();" in source
        and "stopFilePlayer();" in source
        and "io.shutdownNow();" in destroy,
        "图片/视频/试听和后台请求在销毁时释放",
    )

    print("\n③ 危险确认、返回层级和入口")
    check(
        "private Dialog showDangerConfirm(" in source
        and "confirmDeleteConversation(" in source
        and "confirmClearHistory()" in source
        and "confirmNotificationSwitch(" in source,
        "删除、清历史、通知关闭和桌面操作走主题危险确认",
    )
    check(
        "if (conversationDrawerOverlay != null)" in source
        and "if (historyPanel != null)" in source
        and "if (conversationPeek != null)" in source
        and "if (offlineActive != null)" in source
        and "if (pendingAttachments > 0)" in source
        and "if (overlayActive != null)" in source
        and "if (plusOpen)" in source,
        "返回键按设置外层的真实层级逐层关闭",
    )
    check(
        '"main_chat"' in pages
        and '"history"' in pages
        and '"screen"' in pages
        and '"files"' in pages
        and '"schedule"' in pages
        and '"tasks"' in pages
        and '"extensions"' in pages
        and '"acceptance"' in pages
        and '"raw_replies"' in pages
        and '"status"' in pages
        and '"conversations"' in pages
        and '"settings"' in pages,
        "真机 harness 覆盖全部 12 个用户页面",
    )
    check(
        'android:name=".MainActivity"' in manifest
        and 'android:exported="false"' in manifest
        and "EXTRA_EMERGENCY_ROLLBACK" in main_source
        and "NativeFinDeckActivity.class" in main_source,
        "旧 WebView 仍只有受保护的紧急回滚入口",
    )

    print("\n④ 语音范围与构建")
    check(
        "手机朗读" not in source
        and "speakLatest();" not in source
        and source.count("startNativeRecording();") == 1
        and "if (request == REQ_AUDIO)" in source,
        "手机语音入口仍不可见且没有主动调用录音/TTS",
    )
    spec = importlib.util.spec_from_file_location("round135_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十五轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 记录本轮移动端完整收口",
    )
    check(version.PHONE_VERSION == "1.170", "手机端版本升到 v1.170")
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"restoreRetainedSurface" in dex
            and b"native_settings_category" in dex,
            "APK/DEX 含交互现场恢复实现",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
