# -*- coding: utf-8 -*-
"""Round 107 native desktop-screen page and media lifecycle contracts."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    media = (APP / "phone_feature" / "ui" / "media.js").read_text(
        encoding="utf-8"
    )
    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    api = (JAVA / "NativeApiClient.java").read_text(encoding="utf-8")
    version = (APP / "version.py").read_text(encoding="utf-8")
    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")
    shots = activity.split("private void showShots()", 1)[1].split(
        "private void durationOptionsAdd(", 1
    )[0]
    action = activity.split("private void startShotAction(", 1)[1].split(
        "private void requestShotActionConfirmation(", 1
    )[0]
    confirmation = activity.split(
        "private void requestShotActionConfirmation(", 1
    )[1].split("private void durationOptionsAdd(", 1)[0]
    stage = activity.split("private void showShotOnStage(", 1)[1].split(
        "private void stopShotStageVideo(", 1
    )[0]
    viewer = activity.split("private void openShot(String name)", 1)[1].split(
        "private void loadShotOriginal(", 1
    )[0]
    original = activity.split("private void loadShotOriginal(", 1)[1].split(
        "private interface BitmapConsumer", 1
    )[0]
    pause = activity.split("protected void onPause()", 1)[1].split(
        "public void onBackPressed()", 1
    )[0]
    destroy = activity.split("protected void onDestroy()", 1)[1].split(
        "private static final class MaxHeightScrollView", 1
    )[0]

    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    check(
        all(token in page for token in (
            'id="screenres"', 'id="shotstage"', 'id="shotimg"',
            'id="shotvideo"', 'id="shotbtn"', 'id="recbtn"',
            'id="shotmeta"', 'id="shotlist"', 'id="recdurations"',
        ))
        and all(token in page for token in ('data-sec="5"', 'data-sec="8"',
                                            'data-sec="15"'))
        and "<video id=\"shotvideo\" controls" in page,
        "旧页规格保留屏幕信息、空舞台、截图、录屏、5/8/15 秒和带控制视频",
    )
    check(
        all(token in media for token in (
            "async function pullShots", "/api/shots", '"shot/"',
            "items.slice(0, 12)", '"mp4"', '"webm"', 'post("/api/cmd"',
        ))
        and "function viewerOpen" in media,
        "旧 media.js 的列表、最近 12 条、录像、命令和原图查看仍是规格",
    )
    check(
        "display.optInt(\"count\", 1)" in shots
        and "display.optInt(\"width\", 0)" in shots
        and "display.optInt(\"height\", 0)" in shots
        and "原画截图 / 录屏≤5120" in shots,
        "原生页显示屏幕数量、完整分辨率和原画/录屏上限",
    )
    check(
        "电脑全屏预览" in shots
        and "还没有" not in shots
        and "最近画面 · " in shots
        and "Math.min(12, total)" in shots
        and "显示最近 12 条" in shots,
        "原生页有独立空态并显示最近画面总数和最近 12 条",
    )
    check(
        "屏幕列表没读出来" in shots
        and "电脑没有屏幕访问权限" in shots
        and "电脑没有返回屏幕信息" in shots
        and shots.count("loadShotsInto(list, true)") >= 2
        and "private LinearLayout nativeLoadFailure(" in activity,
        "断线、权限和屏幕信息失败分别保留页内错误卡与原地重试",
    )
    check(
        "body.put(\"text\", command);" in action
        and 'api.postJson("/api/cmd", body)' in action
        and 'sendCommand("截图发手机")' not in shots
        and 'ui.postDelayed(new Runnable()' not in action,
        "截图和录屏直接读取命令响应，不再发完即固定延时刷新",
    )
    check(
        "if (shotsActionInFlight" in action
        and "final int actionGeneration = ++shotsActionGeneration;" in action
        and "shotsActionMaxAttempts" in action
        and "Math.max(10, seconds[0] + 8)" in shots,
        "截图/录屏有重复提交锁，并与所选录像时长匹配等待次数",
    )
    check(
        "shotItemsSignature" in confirmation
        and "current.equals(baseline)" in confirmation
        and "requestShotActionConfirmation(" in confirmation
        and "}, 900);" in confirmation
        and "没等到新的" in shots
        and "检查电脑端屏幕录制权限" in shots,
        "动作按列表签名确认新画面，超时明确指出屏幕录制权限边界",
    )
    check(
        "list == shotsActiveList" in activity
        and "generation == shotsRequestGeneration" in activity
        and "final int generation = ++shotsRequestGeneration;" in activity
        and "invalidateShotsPage();" in activity,
        "屏幕列表回写绑定页面、列表和请求代际，切页或重开不可复活",
    )
    check(
        "loadShotBitmap(name, 4096" in stage
        and "loadShotBitmap(name, 8192" in original
        and "new FailureConsumer()" in stage
        and "点这里重试" in original
        and "private void showShotPreviewFailure(" in activity,
        "舞台预览限制内存，原图查看使用更高分辨率，两处失败都可原地重试",
    )
    check(
        "player.setMediaController(controller);" in stage
        and "api.openMediaConnection(" in stage
        and "native-shot-preview-" in stage
        and "Uri.fromFile(target)" in stage
        and "这段录像播放不了" in stage,
        "录像经设备授权下载到本地，带播放控制并在解码失败时保留重试",
    )
    check(
        "shotPreviewGeneration++;" in pause
        and "stopShotStageVideo();" in pause
        and "finishMediaViewer(mediaViewerDialog, mediaViewerHolder);" in pause
        and "invalidateShotsPage();" in destroy,
        "退后台、关闭页面和销毁都会停止录像与原图查看并作废旧回调",
    )
    check(
        "mediaViewerGenerationIsCurrent(generation)" in original
        and "KeyEvent.KEYCODE_BACK" in activity
        and "dismissMediaViewer(dialog, holder);" in activity
        and "if (overlayActive != null) {" in activity,
        "全屏查看器先于屏幕页响应返回，旧图片结果不会写进关闭后的查看器",
    )
    check(
        "Handler filesUi" in activity
        and "if (recoverForeground)" in activity
        and "loadShotsInto(shotsActiveList, false);" in activity,
        "从后台回来只重读当前屏幕页，不丢失页面现场",
    )
    check(
        'android:name=".NativeFinDeckActivity"' in manifest
        and 'android:exported="false"' in manifest
        and "openMediaConnection(" in api
        and "mediaHeaders(" in api,
        "原生屏幕页仍为隔离预览，媒体读取复用设备授权连接",
    )
    check(
        "鳍舱第一百零七轮电脑屏幕页整页收口" in version
        and "PHONE_VERSION = f\"1.{len(PHONE_CHANGELOG)}\"" in version,
        "手机端版本表新增第一百零七轮，并继续按 PHONE_CHANGELOG 计算",
    )

    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    with zipfile.ZipFile(apk) as archive:
        dex = archive.read("classes.dex")
    check(
        b"shotsRequestGeneration" in dex
        and b"shotsActionInFlight" in dex
        and b"showShotPreviewFailure" in dex
        and b"loadShotOriginal" in dex
        and b"native-shot-preview-" in dex,
        "v1.144 APK 确实包含屏幕请求代际、动作锁、失败态和原图重试",
    )

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
