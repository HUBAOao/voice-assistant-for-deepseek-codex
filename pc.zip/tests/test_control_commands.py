# -*- coding: utf-8 -*-
"""Local send-mode and restart commands stay outside the STT main loop."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.control_commands import (  # noqa: E402
    dispatch_control_command,
    parse_control_command,
)


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    cases = (
        ("只粘贴不回车", ("send_mode", "paste")),
        ("以后当打字机", ("send_mode", "type")),
        ("改回正常发送", ("send_mode", "paste_enter")),
        ("发送前确认", ("confirm_send", True)),
        ("不要发送前确认", ("confirm_send", False)),
        ("念一下我选中的", ("read_selected", None)),
        ("重启语音程序", ("restart", None)),
    )
    for command, expected in cases:
        check(parse_control_command(command) == expected, f"{command} → {expected}")
    check(parse_control_command("帮我查一下明天的天气") is None,
          "普通聊天不会误进控制命令")

    config: list[tuple[str, object]] = []
    spoken: list[str] = []
    actions: list[str] = []
    done_calls: list[bool] = []

    def dispatch(command: str):
        return dispatch_control_command(
            command,
            set_config=lambda key, value: config.append((key, value)),
            speak=spoken.append,
            schedule_restart=lambda: actions.append("restart"),
            read_selected=lambda: actions.append("read"),
            done=lambda: done_calls.append(True) or True,
        )

    check(dispatch("只粘贴不回车") is True, "发送方式命令走完兼容返回")
    check(config[-1] == ("send_mode", "paste"), "配置键和值保持不变")
    check(spoken[-1] == "好，以后只粘贴不回车", "原回复文字保持不变")
    check(dispatch("不要确认再发") is True, "关闭确认再发命令被识别")
    check(config[-1] == ("confirm_send", False), "关闭值正确")
    check(dispatch("朗读选中") is True and actions[-1] == "read",
          "朗读命令调用原回调")
    check(dispatch("重启一下程序") is True and actions[-1] == "restart",
          "重启命令只调度原回调")
    check(dispatch("普通聊天") is None, "未命中时不吞普通文本")
    check(len(done_calls) == 4, "done 只在命中的命令执行")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check("dispatch_control_command(" in stt, "STT 已接入控制命令模块")
    check('"重启语音程序", "重启一下程序"' not in stt,
          "重启关键词已移出 STT 主文件")
    check("好，以后只粘贴不回车" not in stt,
          "发送偏好回复已移出 STT 主文件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
