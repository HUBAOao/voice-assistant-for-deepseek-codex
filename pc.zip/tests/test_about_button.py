# -*- coding: utf-8 -*-
"""验收「关于」按钮：设置页底部有它，点开只弹一个窗口，里面是署名/版权/联系方式；
其他地方（设置页正文、启动框）不该再出现署名。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "about-test"
S.mkdir(parents=True, exist_ok=True)
SHOT = ROOT / "outputs" / "关于.png"
sys.path.insert(0, str(APP))

import tkinter as tk  # noqa: E402

import overlay  # noqa: E402
import version  # noqa: E402

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMI(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find_window(title: str) -> int:
    found = []
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _l):
        if not u32.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(hwnd, buf, 256)
        if buf.value == title:
            found.append(hwnd)
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return found[0] if found else 0


def grab(hwnd: int, out: Path) -> tuple:
    rect = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMI()
    hdr.biSize = ctypes.sizeof(BMI)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount = 1, 32
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB").save(out)
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return w, h


def tree(widget, out=None):
    out = [] if out is None else out
    for c in widget.winfo_children():
        out.append(c)
        tree(c, out)
    return out


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    (S / "config.json").write_text(json.dumps(
        {"name": "关于测试", "overlay_bg_image": "", "overlay_alpha": 1.0},
        ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 100, "y": 100}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda _t: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    for _ in range(50):
        o.root.update()
        time.sleep(0.01)

    texts = [str(w.cget("text")) for w in tree(o.panel, []) if isinstance(w, tk.Label)]
    check("关于" in texts, "设置页底部有「关于」按钮")
    leaked = [t for t in texts if "胡宝" in t or "18540361319" in t or "保留所有权利" in t]
    check(not leaked, f"设置页正文里不再直接显示署名（发现 {leaked[:2]}）")
    o.show_about()
    for _ in range(30):
        o.root.update()
        time.sleep(0.02)
    hwnd = find_window("关于")
    check(hwnd != 0, "点一下会弹出「关于」窗口")
    dialog = next((w for w in tree(o.root, []) if isinstance(w, tk.Toplevel)
                   and str(w.title()) == "关于"), None)
    if dialog is not None:
        dtexts = " ".join(str(w.cget("text")) for w in tree(dialog, [])
                          if isinstance(w, tk.Label))
        check("胡宝" in dtexts and "18540361319" in dtexts, "窗口里有作者和联系方式")
        check("保留所有权利" in dtexts, "窗口里有版权声明")
        check("随意修改" in dtexts or "免费提供" in dtexts, "窗口里有免费使用说明")
    if hwnd:
        w, h = grab(hwnd, SHOT)
        print(f"   → 截图 {SHOT}（{w}x{h}）")
    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
