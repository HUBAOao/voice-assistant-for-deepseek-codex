# -*- coding: utf-8 -*-
"""验收「手机入口」：起一个真的 HTTP 小服务，像手机那样去调它。

   · 没令牌 → 401（别人扫到端口也发不了命令）
   · 有令牌 → 打开网页、发命令、拉对话、喊停
   · 命令真的进了主程序的队列"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("pl", APP / "phone_link.py")
    pl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pl)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    got: list[str] = []
    stopped: list[int] = []
    log = [{"n": 7, "kind": "ai", "text": "这是电脑上的回答"}]
    link = pl.PhoneLink(on_command=got.append,
                        get_state=lambda: {"state_text": "idle · 等你说"},
                        get_log=lambda since: [x for x in log if x["n"] > since],
                        on_stop=lambda: stopped.append(1),
                        port=8791)
    check(link.start(), f"服务起在 {link.port} 端口")
    base = f"http://127.0.0.1:{link.port}"

    def get(path: str, key: str = "") -> tuple[int, str]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        # 刚起的服务偶尔会有一次"连接被本机掐断"（10053），重试一下 ——
        # 这是测试里的网络抖动，不是程序的问题（跑批时偶发，单独跑从来不出）
        for attempt in (1, 2, 3):
            try:
                with urllib.request.urlopen(url, timeout=5) as r:
                    return r.status, r.read().decode("utf-8", "replace")
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode("utf-8", "replace")
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(0.25)
        return 0, ""

    def post(path: str, body: dict, key: str = "") -> tuple[int, str]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST",
                                     headers={"Content-Type": "application/json"})
        for attempt in (1, 2, 3):
            try:
                with urllib.request.urlopen(req, timeout=5) as r:
                    return r.status, r.read().decode("utf-8", "replace")
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode("utf-8", "replace")
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(0.25)
        return 0, ""

    time.sleep(0.3)
    print("① 没令牌一律拒绝")
    code, _ = get("/")
    check(code == 401, f"打开网页没令牌 → {code}")
    code, _ = post("/api/cmd", {"text": "帮我看看"}, "wrong-token")
    check(code == 401, f"发命令用错令牌 → {code}")
    check(got == [], "拒绝的时候一条命令都没进来")

    print("\n② 带对令牌：网页能开、命令能发、对话能拉")
    code, html = get("/", link.token)
    check(code == 200 and "语音助手" in html and 'id="send"' in html,
          f"手机网页拿得到（{len(html)} 字节，含发送按钮）")
    code, body = post("/api/cmd", {"text": "大肥鱼 帮我查天气"}, link.token)
    check(code == 200 and got == ["大肥鱼 帮我查天气"], f"命令进了队列：{got}")
    code, body = get("/api/log?since=0", link.token)
    data = json.loads(body)
    check(data.get("lines", [{}])[0].get("text") == "这是电脑上的回答",
          f"对话能拉到：{data.get('lines')}")
    check(data.get("state") == "idle · 等你说", f"状态也在：{data.get('state')}")
    code, _ = post("/api/stop", {}, link.token)
    check(stopped == [1], "喊停能传到主程序")
    code, _ = post("/api/cmd", {"text": "   "}, link.token)
    check(code == 400, f"空命令被挡下 → {code}")

    print("\n③ 网址是给手机用的（内网地址 + 令牌）")
    url = link.url()
    check(url.startswith("http://") and f":{link.port}/?k={link.token}" in url,
          f"网址：{url}")

    print("\n④ 主程序里真的接上了")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check("phone_link.PhoneLink(" in src, "启动时把手机入口拉起来")
    check("drain_phone_commands()" in src, "主循环里会取手机发来的命令")
    check("handle(None, pre_text=text, from_phone=True)" in src, "手机命令走同一条 handle 管线")
    check("from_phone" in src and "body, woke = text, True" in src, "手机命令不要求喊唤醒词")
    ov = (APP / "overlay.py").read_text(encoding="utf-8")
    check('"手机入口"' in ov and "copy_phone_url" in ov, "设置里有开关和网址复制")

    link.stop()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
