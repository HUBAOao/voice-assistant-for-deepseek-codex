# -*- coding: utf-8 -*-
"""Verify the post-send confirmation state machine without sleeping."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from voice_feature.send_verification import verify_sent_delivery  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Status:
        def __init__(self) -> None:
            self.calls = []

        def set(self, *args, **kwargs) -> None:
            self.calls.append((args, kwargs))

    common = {
        "wait": 0,
        "sleep": lambda _seconds: None,
        "clock": lambda: 1000.0,
        "syslog": lambda *_args: None,
        "print_line": lambda *_args, **_kwargs: None,
    }
    status = Status()
    result = verify_sent_delivery(
        "已经进库的消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent={},
        has_user_text=lambda text, since_ms: text == "已经进库的消息",
        document_text=lambda _window: (_ for _ in ()).throw(
            AssertionError("会话库确认后不应再读窗口")),
        **common,
    )
    check(result and not status.calls, "会话库确认后直接通过")

    status = Status()
    logs = []
    result = verify_sent_delivery(
        "窗口里能看到的消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent={},
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "前面 窗口里能看到的消息 后面",
        syslog=lambda *args: logs.append(args),
        **{k: v for k, v in common.items() if k != "syslog"},
    )
    check(result and not status.calls and "窗口里能看到" in logs[-1][1],
          "会话库未确认时窗口可见文字兜底")

    status = Status()
    spoken = []
    last_unsent = {}
    result = verify_sent_delivery(
        "没有落地的话",
        123,
        status=status,
        speak=spoken.append,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "窗口里还是旧内容",
        **common,
    )
    check(not result and last_unsent.get("text") == "没有落地的话",
          "未确认时记录待重发文本")
    check(status.calls and "可能没进去" in status.calls[-1][1]["text"],
          "未确认时更新状态提示")
    check(spoken and "重发一遍" in spoken[-1],
          "电脑端失败时出声提示")

    status = Status()
    spoken = []
    verify_sent_delivery(
        "手机静默发送",
        123,
        silent=True,
        status=status,
        speak=spoken.append,
        last_unsent={},
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "",
        **common,
    )
    check(not spoken, "手机发来的命令失败时不语音播报")

    source = (ROOT / "outputs" / "voice-to-text" / "stt.py").read_text(
        encoding="utf-8"
    )
    check("verify_sent_delivery(" in source,
          "STT 已接入独立发送核验")
    check("def _verify_sent" not in source,
          "STT 不再内联发送核验函数")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
