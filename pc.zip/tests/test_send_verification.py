# -*- coding: utf-8 -*-
"""Verify the post-send confirmation state machine without sleeping."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from voice_feature.send_verification import (  # noqa: E402
    DeliveryReceiptTracker,
    verify_sent_delivery,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Status:
        def __init__(self) -> None:
            self.calls = []
            self._last = {}

        def set(self, *args, **kwargs) -> None:
            self.calls.append((args, kwargs))
            self._last = {
                "state": args[0] if args else "",
                **kwargs,
            }

    common = {
        "wait": 0,
        "sleep": lambda _seconds: None,
        "clock": lambda: 1000.0,
        "syslog": lambda *_args: None,
        "print_line": lambda *_args, **_kwargs: None,
    }
    status = Status()
    result = verify_sent_delivery(
        "已经进库的消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent={},
        has_user_text=lambda text, since_ms: text == "已经进库的消息",
        document_text=lambda _window: (_ for _ in ()).throw(
            AssertionError("会话库确认后不应再读窗口")),
        **common,
    )
    check(result and not status.calls, "会话库确认后直接通过")

    status = Status()
    logs = []
    with patch.dict(sys.modules, {"codex_replies": None}):
        result = verify_sent_delivery(
            "窗口里能看到的消息",
            123,
            status=status,
            speak=lambda _text: None,
            last_unsent={},
            document_text=lambda _window: "前面 窗口里能看到的消息 后面",
            syslog=lambda *args: logs.append(args),
            **{k: v for k, v in common.items() if k != "syslog"},
        )
    check(result and not status.calls and "窗口里能看到" in logs[-1][1],
          "会话库未确认时窗口可见文字兜底")

    status = Status()
    window_reads = []
    result = verify_sent_delivery(
        "重复发送但本次没进去",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent={},
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: (
            window_reads.append(True) or "重复发送但本次没进去"
        ),
        **common,
    )
    check(not result and not window_reads,
          "会话库可读时旧窗口里的同文不能冒充本次送达")

    status = Status()
    spoken = []
    last_unsent = {}
    result = verify_sent_delivery(
        "没有落地的话",
        123,
        status=status,
        speak=spoken.append,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "窗口里还是旧内容",
        **common,
    )
    check(not result and last_unsent.get("text") == "没有落地的话",
          "未确认时记录待重发文本")
    check(status.calls and "可能没进去" in status.calls[-1][1]["text"],
          "未确认时更新状态提示")
    check(spoken and "重发一遍" in spoken[-1],
          "电脑端失败时出声提示")

    status = Status()
    spoken = []
    verify_sent_delivery(
        "手机静默发送",
        123,
        silent=True,
        status=status,
        speak=spoken.append,
        last_unsent={},
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "",
        **common,
    )
    check(not spoken, "手机发来的命令失败时不语音播报")

    status = Status()
    receipt = DeliveryReceiptTracker(
        last_unsent={},
        status=status,
        speak=lambda _text: None,
        syslog=lambda *_args: None,
        clock=lambda: 1000.0,
        print_line=lambda *_args, **_kwargs: None,
    )
    attempt = receipt.begin("迟到的消息", started_at=998.75)
    seen_since = []
    results = iter((False, True))
    result = verify_sent_delivery(
        "迟到的消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent={},
        has_user_text=lambda _text, since_ms: (
            seen_since.append(since_ms) or next(results)
        ),
        document_text=lambda _window: "",
        sent_at_ms=attempt.since_ms,
        receipt=receipt,
        attempt=attempt,
        retry_intervals=(2.0,),
        **common,
    )
    check(result and seen_since == [attempt.since_ms, attempt.since_ms],
          "会话库只核验本次发送时间窗，并允许迟到确认")
    check(not status.calls, "迟到后确认不会先留下假失败")

    status = Status()
    last_unsent = {"text": "更早的消息", "at": 10.0}
    receipt = DeliveryReceiptTracker(
        last_unsent=last_unsent,
        status=status,
        speak=lambda _text: None,
        syslog=lambda *_args: None,
        clock=lambda: 1000.0,
        print_line=lambda *_args, **_kwargs: None,
    )
    old_attempt = receipt.begin("旧消息", started_at=900.0)
    verify_sent_delivery(
        "旧消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "",
        sent_at_ms=old_attempt.since_ms,
        receipt=receipt,
        attempt=old_attempt,
        **common,
    )
    check(last_unsent.get("text") == "旧消息",
          "未确认时记录最新待重发文本")
    new_attempt = receipt.begin("新消息", started_at=1000.0)
    check(last_unsent == {} and receipt.is_current(new_attempt),
          "新发送会清掉上一轮待重发状态")
    calls_before = len(status.calls)
    result = verify_sent_delivery(
        "旧消息",
        123,
        status=status,
        speak=lambda _text: None,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "",
        sent_at_ms=old_attempt.since_ms,
        receipt=receipt,
        attempt=old_attempt,
        **common,
    )
    check(not result and len(status.calls) == calls_before,
          "旧校验线程不能覆盖新发送状态")

    status = Status()
    last_unsent = {}
    spoken = []
    receipt = DeliveryReceiptTracker(
        last_unsent=last_unsent,
        status=status,
        speak=spoken.append,
        syslog=lambda *_args: None,
        clock=lambda: 1000.0,
        print_line=lambda *_args, **_kwargs: None,
    )
    attempt = receipt.begin("晚到的确认", started_at=999.0)
    verify_sent_delivery(
        "晚到的确认",
        123,
        status=status,
        speak=spoken.append,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: False,
        document_text=lambda _window: "",
        sent_at_ms=attempt.since_ms,
        receipt=receipt,
        attempt=attempt,
        **common,
    )
    check("可能没进去" in status._last.get("text", ""),
          "超时后先显示可能未送达")
    result = verify_sent_delivery(
        "晚到的确认",
        123,
        status=status,
        speak=spoken.append,
        last_unsent=last_unsent,
        has_user_text=lambda _text, **_: True,
        document_text=lambda _window: "",
        sent_at_ms=attempt.since_ms,
        receipt=receipt,
        attempt=attempt,
        **common,
    )
    check(result and "已确认发送" in status._last.get("text", ""),
          "迟到确认会改写同一轮的误报状态")
    check(last_unsent == {} and spoken[-1] == "刚才那句其实已经送到了",
          "迟到确认会清除待重发并纠正语音提示")

    source = (ROOT / "outputs" / "voice-to-text" / "stt.py").read_text(
        encoding="utf-8"
    )
    delivery = (
        ROOT / "outputs" / "voice-to-text" / "voice_feature"
        / "runtime_delivery_assembly.py"
    ).read_text(encoding="utf-8")
    check("verify_delivery=verify_sent_delivery" in source
          and "deps.verify_delivery(" in delivery,
          "运行装配已接入独立发送核验")
    check("def _verify_sent" not in source,
          "STT 不再内联发送核验函数")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
