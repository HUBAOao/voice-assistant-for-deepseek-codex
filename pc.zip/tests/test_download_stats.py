# -*- coding: utf-8 -*-
"""验收「下载量」：有人真的把包下走了才 +1，数字要在网页上看得见。

规矩：
  * 只统计真的下载（APK / 电脑端安装包被取走），点开页面不算
  * 数字写在 download-stats.json 里，电脑端设置里也能看到
  * 离线单文件版读不到统计就**不显示**这一行（不给假的 0）
"""
from __future__ import annotations

import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import stats

    print("① 统计文件本身")
    backup = stats.COUNTER.read_bytes() if stats.COUNTER.exists() else None
    try:
        stats.COUNTER.write_text(json.dumps(
            {"pc": 0, "phone": 0, "first": "", "last": "", "days": {}},
            ensure_ascii=False), encoding="utf-8")
        check(stats.read()["total"] == 0, "一开始是 0")
        stats.bump("phone")
        stats.bump("phone")
        stats.bump("pc")
        d = stats.read()
        check(d["phone"] == 2 and d["pc"] == 1 and d["total"] == 3,
              f"下手机的 +2、下电脑的 +1 → 手机 {d['phone']} / 电脑 {d['pc']} / 合计 {d['total']}")
        check(d["first"] and d["last"], "记了第一次和最近一次的时间")
        today = time.strftime("%Y-%m-%d")
        check(d["days"].get(today, {}).get("phone") == 2, "按天也分开记了")
        check("3" in stats.text(), f"给人看的一句话：{stats.text()}")
    finally:
        if backup is not None:
            stats.COUNTER.write_bytes(backup)
        else:
            try:
                stats.COUNTER.unlink()
            except Exception:
                pass

    print("② 真的下载了才 +1")
    import phone_link
    import download_page as dp

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8817)
    if not link.start():
        check(False, "手机入口起不来")
        return 1
    backup = stats.COUNTER.read_bytes() if stats.COUNTER.exists() else None
    try:
        time.sleep(0.2)
        base = "http://127.0.0.1:8817"
        with urllib.request.urlopen(base + "/dl/version.json", timeout=10) as r:
            mf = json.loads(r.read().decode("utf-8"))
        before = (mf.get("stats") or {}).get("total", 0)
        with urllib.request.urlopen(base + "/dl", timeout=10) as r:   # 只是打开页面
            page = r.read().decode("utf-8")
        with urllib.request.urlopen(base + "/dl/stats.json", timeout=10) as r:
            after_view = json.loads(r.read().decode("utf-8")).get("total", 0)
        check(after_view == before, "光打开下载页不算下载量")
        with urllib.request.urlopen(base + "/dl/app.apk", timeout=60) as r:
            r.read()
        with urllib.request.urlopen(base + "/dl/stats.json", timeout=10) as r:
            after_apk = json.loads(r.read().decode("utf-8"))
        check(after_apk.get("total") == before + 1, "把 APK 下走 → +1")
        check(after_apk.get("phone", 0) >= 1, f"手机端计数 {after_apk.get('phone')}")
        with urllib.request.urlopen(base + "/dl/pc.zip", timeout=60) as r:
            r.read()
        with urllib.request.urlopen(base + "/dl/stats.json", timeout=10) as r:
            after_pc = json.loads(r.read().decode("utf-8"))
        check(after_pc.get("total") == before + 2, "电脑端安装包下走 → 再 +1")
        check(after_pc.get("pc", 0) >= 1, f"电脑端计数 {after_pc.get('pc')}")
        check("statsline" in page and "已经被下载" in page,
              "页面里有显示下载量的那一行（数字自己加载）")
        with urllib.request.urlopen(base + "/dl/version.json", timeout=10) as r:
            mf2 = json.loads(r.read().decode("utf-8"))
        check((mf2.get("stats") or {}).get("total") == after_pc.get("total"),
              "更新清单里也带着这份数字")
    finally:
        link.stop()
        if backup is not None:
            stats.COUNTER.write_bytes(backup)
        else:
            try:
                stats.COUNTER.unlink()
            except Exception:
                pass

    print("③ 电脑端设置里也看得到")
    ov = (APP / "overlay.py").read_text(encoding="utf-8")
    check("_download_text" in ov and "refresh_download_label" in ov,
          "设置底部有一行「下载 N 次」")
    check("import stats" in ov, "读的就是本机那份统计（不绕网络）")

    print("④ 离线版不会显示假的 0")
    one = ROOT / "outputs" / "下载页-单文件.html"
    if one.exists():
        txt = one.read_text(encoding="utf-8")
        check("statsline" in txt and "d.ok" in txt,
              "单文件版也带着那段代码，但读不到数据就不显示")
    else:
        check(False, "单文件版还没生成")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
