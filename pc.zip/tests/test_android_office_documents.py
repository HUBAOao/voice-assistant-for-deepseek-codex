# -*- coding: utf-8 -*-
"""XLSX/PPTX system targets stay on the bounded attachment pipeline."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)
MIMES = {
    "XLSX": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "PPTX": "application/vnd.openxmlformats-officedocument.presentationml."
            "presentation",
}


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    for label, mime in MIMES.items():
        check(manifest.count(f'android:mimeType="{mime}"') == 4,
              f"{label} 注册单张/多张分享及 content/file 打开四种目标")
        check(mime in activity and mime in media,
              f"{label} 原生白名单与手机页面入口保持一致")

    check(manifest.count('android:name="android.intent.action.SEND"') == 18
          and manifest.count('android:name="android.intent.action.VIEW"') == 28,
          "Office 目标没有挤掉既有系统入口")
    check("isOfficeDocumentMime(type)" in activity
          and "isExcelDocumentMime(type)" in activity
          and "isPowerPointDocumentMime(type)" in activity,
          "三类 Office 文档统一经现有可分享附件判定")
    check("} else if (isOfficeDocumentMime(mime)) {" in activity
          and "cleanMime = mime.trim().toLowerCase" in activity,
          "XLSX/PPTX 清理后的 MIME 原样进入附件队列")
    check("MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "Office 文档继续使用 16 MB 与六个附件上限")
    check("file-staged" in activity
          and "stageFiles([new File([bytes]" in media
          and "sendButton.onclick" in media,
          "Office 文档只进入待发送托盘并等待用户点发送")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
