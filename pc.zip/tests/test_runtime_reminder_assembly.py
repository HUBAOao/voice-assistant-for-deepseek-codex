# -*- coding: utf-8 -*-
"""Reminder ordering and throttles stay outside the main process assembly."""
from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_reminder_assembly import (  # noqa: E402
    ReminderRuntimeDependencies,
    assemble_reminder_runtime,
)


class Status:
    def __init__(self) -> None:
        self.values = []

    def set(self, state, **kwargs) -> None:
        self.values.append((state, kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls = []
    status = Status()
    mute = {"on": False}
    clock = {"now": 100.0}
    current = {"now": datetime(2026, 10, 23, 8, 0)}
    ticker = {"next": 0.0, "meeting": False}
    hourly = {"last": "2026-10-23 07"}
    sit = {"next": 0.0}
    fatigue = {"speeds": [10, 11, 9, 10, 12, 9, 10, 3, 3, 3], "last": -1800.0}
    runtime = assemble_reminder_runtime(
        ReminderRuntimeDependencies(
            config={
                "meeting_mute": True,
                "hourly_chime": True,
                "sit_reminder": True,
                "sit_minutes": 45,
                "fatigue_reminder": True,
            },
            ticker=ticker,
            hourly=hourly,
            sit=sit,
            fatigue=fatigue,
            mute_speak=mute,
            in_meeting=lambda: True,
            last_input_age=lambda: 10,
            speak=lambda text: calls.append(("speak", text)),
            syslog=lambda tag, text: calls.append(("log", tag, text)),
            status=status,
            now=lambda: current["now"],
            clock=lambda: clock["now"],
            emit=lambda text: calls.append(("emit", text)),
        )
    )

    runtime.run()
    check(mute["on"] is True and ticker["meeting"] is True,
          "会议模式在原位置静音并保留状态")
    check(("speak", "现在是 8 点") in calls
          and hourly["last"] == "2026-10-23 08",
          "整点报时只在整点触发一次")
    check(sit["next"] == 100 + 45 * 60,
          "久坐时间按用户的分钟数计算")
    check(any(item[:2] == ("speak", "听你说话好像有点累了，歇一会儿吧")
              for item in calls if len(item) >= 2),
          "疲劳提醒保持原阈值和措辞")
    check(fatigue["last"] == 100.0,
          "疲劳提醒同时更新节流时间")

    calls.clear()
    clock["now"] = 100.5
    runtime.run()
    check(not calls and ticker["next"] == 101.0,
          "一秒节流与历史行为一致")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "runtime_reminder_assembly.py"
    ).read_text(encoding="utf-8")
    desktop = (
        APP / "voice_feature" / "runtime_application_desktop.py"
    ).read_text(encoding="utf-8")
    check("def maybe_reminders()" not in source
          and "maybe_reminders=reminder_runtime.run" in desktop,
          "main() 不再内联提醒调度")
    check("class ReminderRuntime" in module
          and "deps.ticker[\"meeting\"]" in module,
          "提醒顺序、节流和状态更新由独立运行时承接")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
