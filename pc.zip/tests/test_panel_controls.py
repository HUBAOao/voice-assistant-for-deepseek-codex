# -*- coding: utf-8 -*-
"""Overlay widget construction lives outside the main Overlay class."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import panel_controls  # noqa: E402


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    check(callable(panel_controls.row), "通用设置行可独立构建")
    check(callable(panel_controls.chip), "设置文字按钮可独立构建")
    check(callable(panel_controls.switch_row), "设置开关行可独立构建")
    check(callable(panel_controls.swatch), "颜色样本可独立构建")
    check(callable(panel_controls.text_field), "文字设置按钮可独立构建")
    check(callable(panel_controls.text_dialog), "文字编辑窗口可独立构建")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    content = (APP / "overlay_feature" / "settings_content_mixin.py").read_text(
        encoding="utf-8"
    )
    delivery = (
        APP / "overlay_feature" / "settings_delivery_mixin.py"
    ).read_text(encoding="utf-8")
    pages = (
        APP / "overlay_feature" / "settings_pages_mixin.py"
    ).read_text(encoding="utf-8")
    features = (
        APP / "overlay_feature" / "settings_features_mixin.py"
    ).read_text(encoding="utf-8")
    check("_panel_controls.text_field(" in overlay
          and "_panel_controls.text_dialog(" in overlay,
          "overlay.py 的文字控件改为调用独立控件层")
    check("tk.StringVar(value=str(value))" not in overlay,
          "overlay.py 不再重复实现文字设置构建")
    for marker in ("_controls.group(", "_controls.row(", "_controls.chip(",
                   "_controls.switch_row(", "_controls.swatch("):
        check(marker in content, f"设置页使用独立控件 {marker}")
    check("class OverlaySettingsDeliveryMixin" in delivery
          and "def build_delivery_section(" in delivery,
          "发送、手机、外网、安全与识别控件独立成业务构建层")
    check("self.build_delivery_section(parent)" in pages
          and 'self._group(parent, "外网访问' not in pages,
          "主设置页只调用业务构建边界，不再堆叠连接控件")
    check("OverlaySettingsDeliveryMixin" in overlay,
          "Overlay 正式接入发送与连接业务构建层")
    check("class OverlaySettingsFeaturesMixin" in features
          and "def build_features(self, parent)" in features,
          "提醒、快捷指令和功能开关独立成业务构建层")
    check("self.build_features(more)" in pages
          and 'self._group(more, "提醒与日程")' not in pages,
          "功能页只调用独立业务边界")
    check("OverlaySettingsFeaturesMixin" in overlay,
          "Overlay 正式接入功能业务构建层")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
