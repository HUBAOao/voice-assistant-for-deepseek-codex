# -*- coding: utf-8 -*-
"""Overlay widget construction lives outside the main Overlay class."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import panel_controls  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    check(callable(panel_controls.row), "通用设置行可独立构建")
    check(callable(panel_controls.chip), "设置文字按钮可独立构建")
    check(callable(panel_controls.switch_row), "设置开关行可独立构建")
    check(callable(panel_controls.swatch), "颜色样本可独立构建")
    check(callable(panel_controls.text_field), "文字设置按钮可独立构建")
    check(callable(panel_controls.text_dialog), "文字编辑窗口可独立构建")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    content = (APP / "overlay_feature" / "settings_content_mixin.py").read_text(
        encoding="utf-8"
    )
    delivery = (
        APP / "overlay_feature" / "settings_delivery_mixin.py"
    ).read_text(encoding="utf-8")
    sending = (
        APP / "overlay_feature" / "settings_send_mixin.py"
    ).read_text(encoding="utf-8")
    connection = (
        APP / "overlay_feature" / "settings_connection_mixin.py"
    ).read_text(encoding="utf-8")
    pages = (
        APP / "overlay_feature" / "settings_pages_mixin.py"
    ).read_text(encoding="utf-8")
    maintenance = (
        APP / "overlay_feature" / "settings_maintenance_mixin.py"
    ).read_text(encoding="utf-8")
    appearance = (
        APP / "overlay_feature" / "settings_appearance_mixin.py"
    ).read_text(encoding="utf-8")
    text_input = (
        APP / "overlay_feature" / "settings_text_input_mixin.py"
    ).read_text(encoding="utf-8")
    memory_panel = (
        APP / "overlay_feature" / "settings_memory_panel_mixin.py"
    ).read_text(encoding="utf-8")
    data_panel = (
        APP / "overlay_feature" / "settings_data_panel_mixin.py"
    ).read_text(encoding="utf-8")
    uninstall_panel = (
        APP / "overlay_feature" / "settings_uninstall_panel_mixin.py"
    ).read_text(encoding="utf-8")
    features = (
        APP / "overlay_feature" / "settings_features_mixin.py"
    ).read_text(encoding="utf-8")
    check("_controls.text_field(" in text_input
          and "_controls.text_dialog(" in text_input,
          "文字设置动作通过独立控件层构建")
    check("tk.StringVar(value=str(value))" not in overlay,
          "overlay.py 不再重复实现文字设置构建")
    for marker in ("_controls.group(", "_controls.row(", "_controls.chip(",
                   "_controls.switch_row(", "_controls.swatch("):
        check(marker in content, f"设置页使用独立控件 {marker}")
    check("class OverlaySettingsDeliveryMixin" in delivery
          and "def build_delivery_section(" in delivery
          and "class OverlaySettingsSendMixin" in sending
          and "class OverlaySettingsConnectionMixin" in connection,
          "发送、手机、外网、安全与识别控件独立成业务构建层")
    check("self.build_send_controls(parent)" in delivery
          and "self.build_connection_controls(parent)" in delivery,
          "历史投递入口组合发送与连接两个独立业务边界")
    check("self.build_delivery_section(parent)" in pages
          and 'self._group(parent, "外网访问' not in pages,
          "主设置页只调用业务构建边界，不再堆叠连接控件")
    check("OverlaySettingsDeliveryMixin" in overlay,
          "Overlay 正式接入发送与连接业务构建层")
    check("class OverlaySettingsFeaturesMixin" in features
          and "def build_features(self, parent)" in features,
          "提醒、快捷指令和功能开关独立成业务构建层")
    check("self.build_features(more)" in pages
          and 'self._group(more, "提醒与日程")' not in pages,
          "功能页只调用独立业务边界")
    check("self.build_maintenance(more)" in pages
          and 'self._group(parent, "集中记忆")' in memory_panel
          and 'self._group(parent, "数据与排查")' in data_panel
          and 'self._group(parent, "卸载")' in uninstall_panel
          and "self.build_memory_panel(parent)" in maintenance
          and "self.build_data_panel(parent)" in maintenance
          and "self.build_uninstall_panel(parent)" in maintenance,
          "记忆、数据和卸载控件由维护设置业务层统一构建")
    check('self._group(more, "集中记忆")' not in pages
          and 'self._group(more, "卸载")' not in pages,
          "主设置页不再内联维护业务")
    check("OverlaySettingsMaintenanceMixin" in overlay,
          "Overlay 正式接入维护设置业务层")
    check("OverlaySettingsFeaturesMixin" in overlay,
          "Overlay 正式接入功能业务构建层")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
