# -*- coding: utf-8 -*-
"""Short voice interactions stay testable and do not lose microphone safety."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_interaction_assembly import (  # noqa: E402
    RuntimeInteractionAssembly,
    RuntimeInteractionDependencies,
)


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state, **kwargs) -> None:
        self.calls.append((state, kwargs))

    def level(self, value, state) -> None:
        self.calls.append(("level", {"value": value, "state": state}))


class Transcriber:
    def __init__(self, text: str) -> None:
        self.text = text

    def transcribe(self, _audio) -> str:
        return self.text


def deps(tmp: Path, **overrides):
    values = dict(
        args=SimpleNamespace(no_send=False, keep_draft=False),
        config={"send_mode": "paste_enter"},
        config_file=tmp / "config.json",
        voiceprint_file=tmp / "voiceprint.json",
        wake_words=["大肥鱼"],
        rate=16000,
        transcriber=Transcriber("发"),
        calibrate=lambda: 0.05,
        record=lambda *_args, **_kwargs: np.ones(8000, dtype="float32"),
        has_utterance=lambda audio, _rate: len(audio) > 0,
        voice_features=lambda _audio, _rate: [1.0, 0.0],
        voiceprint={},
        speak=lambda *_args, **_kwargs: None,
        status=Status(),
        syslog=lambda *_args: None,
        emit=lambda *_args, **_kwargs: None,
        load_config=lambda: {},
        copy_to_clipboard=lambda _text: True,
        paste_clipboard=lambda *_args, **_kwargs: True,
        paste_into=lambda *_args, **_kwargs: True,
        type_text_hwnd=lambda *_args, **_kwargs: True,
        is_paused=lambda: False,
        level_state=lambda _value: "hearing",
        app_dir=tmp,
        python_executable=sys.executable,
        sleep=lambda _seconds: None,
    )
    values.update(overrides)
    return RuntimeInteractionDependencies(**values)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as raw:
        tmp = Path(raw)
        calls = []
        d = deps(
            tmp,
            config={"send_mode": "paste"},
            copy_to_clipboard=lambda text: calls.append(("copy", text)) or True,
            paste_clipboard=lambda hwnd, **kwargs: (
                calls.append(("paste", hwnd, kwargs)) or True
            ),
        )
        runtime = RuntimeInteractionAssembly(d)
        check(runtime.send_it("测试", 42), "只粘贴模式返回原发送结果")
        check(calls[0] == ("copy", "测试"), "只粘贴模式先复制原文")
        check(calls[1][0] == "paste" and calls[1][1] == 42
              and calls[1][2]["press_enter"] is False,
              "只粘贴模式保持不回车")

        d.config["send_mode"] = "type"
        typed = []
        d = deps(
            tmp,
            config=d.config,
            type_text_hwnd=lambda text, hwnd, **kwargs: (
                typed.append((text, hwnd, kwargs)) or True
            ),
        )
        RuntimeInteractionAssembly(d).send_it("直接打字", 7)
        check(typed == [("直接打字", 7, {"press_enter": True})],
              "打字机模式保留目标窗口与回车设置")

        spoken = []
        d = deps(
            tmp,
            config={"confirm_send": True},
            transcriber=Transcriber("暂时不发"),
            speak=spoken.append,
        )
        check(RuntimeInteractionAssembly(d).confirm_ok("原文") is False,
              "确认回答包含否定词时拒绝发送")
        check(spoken[-1] == "好，不发了", "取消确认保留原回复")

        d = deps(
            tmp,
            config={"confirm_send": True},
            transcriber=Transcriber("确认"),
        )
        check(RuntimeInteractionAssembly(d).confirm_ok("原文") is True,
              "明确确认后允许发送")

        d = deps(tmp, config={"voiceprint_gate": False})
        check(RuntimeInteractionAssembly(d).wake_voice_ok(None) is True,
              "关闭声纹闸时直接放行")

        d = deps(
            tmp,
            config={"voiceprint_gate": True},
            voice_features=lambda _audio, _rate: [0.2, 1.0],
        )
        d.voiceprint_file.write_text(
            json.dumps({"wake_feat": [1.0, 0.0]}),
            encoding="utf-8",
        )
        check(RuntimeInteractionAssembly(d).wake_voice_ok(object()) is False,
              "低声纹相似度拒绝唤醒")
        check(d.voiceprint["wake_score"] == 0.2,
              "记录实际唤醒声纹分数")

        saved = []
        d = deps(
            tmp,
            config={},
            load_config=lambda: {"old": 1},
            syslog=lambda tag, text: saved.append((tag, text)),
        )
        runtime = RuntimeInteractionAssembly(d)
        runtime.set_config("model", "small")
        check(json.loads(d.config_file.read_text(encoding="utf-8"))
              == {"old": 1, "model": "small"},
              "即时配置写入保留旧配置")
        check(d.config["model"] == "small" and saved[-1][0] == "设",
              "运行配置和日志同步更新")

        spoken.clear()
        status = Status()
        d = deps(
            tmp,
            speak=spoken.append,
            status=status,
        )
        RuntimeInteractionAssembly(d).train_wake_voice()
        saved_feature = json.loads(
            d.voiceprint_file.read_text(encoding="utf-8")
        )
        check(saved_feature["wake_feat"] == [1.0, 0.0],
              "三遍唤醒训练保存归一化声纹")
        check(status.calls[-1][0] == "sent"
              and "唤醒词已训练" in status.calls[-1][1]["text"],
              "训练完成更新原状态")

        launched = []
        d = deps(
            tmp,
            spawn=lambda args, **kwargs: launched.append((args, kwargs)),
        )
        try:
            RuntimeInteractionAssembly(d).restart_program()
        except SystemExit as exc:
            check(exc.code == 0, "重启仍以正常退出码结束进程")
        check(bool(launched), "重启调用注入的进程启动器")

        source = (APP / "stt.py").read_text(encoding="utf-8")
        prepared = (
            APP / "voice_feature" / "runtime_main_foreground.py"
        ).read_text(encoding="utf-8")
        check("def train_wake_voice(" not in source
              and "def confirm_ok(" not in source
              and "def restart_program(" not in source,
              "短录音与重启实现已离开 stt.py")
        check("safe_record(safe_calibrate" not in source
              and "tick=checked_pause" not in source,
              "旧拆分遗留的未定义短录音入口已清除")
        check("on_microphone_ready=" in prepared,
              "前台运行装配把真实麦克风恢复器交给短操作")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
