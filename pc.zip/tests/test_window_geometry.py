# -*- coding: utf-8 -*-
"""Pure tests for overlay multi-monitor placement and hit testing."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import window_geometry as geometry  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    viewport = (-1920, -200, 5760, 1440)
    check(geometry.clamp_axis(-2500, -1920, 5760, 344) == -1920,
          "左边界外位置被收进虚拟桌面")
    check(geometry.clamp_axis(9999, -1920, 5760, 344) == 3496,
          "右边界按窗口宽度回收")
    check(geometry.nearest_edge(-1910, 300, 344, 120, viewport, 26) == "left",
          "跨屏虚拟桌面左边缘能被识别")
    check(geometry.nearest_edge(-4000, 300, 344, 120, viewport, 26) == "",
          "离屏幕过远时不误吸附")

    check(geometry.dock_position("right", 300, 400, 132, 20, viewport)
          == (3840 - 132, 400), "右吸附保持纵向位置并按新宽度贴边")
    check(geometry.dock_position("bottom", 300, 9999, 132, 20, viewport)
          == (300, -200 + 1440 - 20), "底吸附按新高度贴底")

    x, y = geometry.clamp_position(9999, -9999, 432, 452, viewport)
    check(x == -1920 + 5760 - 432 and y == -200,
          "面板位置限制在完整虚拟桌面内")
    x, y = geometry.panel_position(
        3600, 900, 120, 344, 432, 452, viewport, margin=8
    )
    check(x + 432 <= -1920 + 5760 - 8 and y + 452 <= -200 + 1440 - 8,
          "靠右下的面板自动左移和上翻")
    x, y = geometry.panel_position(
        300, 300, 120, 344, 432, 452, viewport, margin=8
    )
    check(y == 300 + 120 - 1, "正常位置仍把面板贴在悬浮窗底部")

    switch = geometry.switch_rect(344, -12, 36)
    check(switch[0] == 344 - 12 - 36, "右侧开关仍按负偏移计算")
    arrow = geometry.arrow_rect(344, 120, 22)
    check(geometry.point_in_rect(arrow[0] + 2, arrow[1] + 2, arrow),
          "箭头热区内可点击")
    check(not geometry.point_in_rect(arrow[0] - 1, arrow[1] + 2, arrow),
          "箭头热区外不误触")
    check(geometry.default_position(viewport, 344) == (3456, -140),
          "首次位置落在虚拟桌面右上侧")

    runtime_source = (APP / "overlay_feature" / "runtime.py").read_text(
        encoding="utf-8"
    )
    overlay_source = (APP / "overlay.py").read_text(encoding="utf-8")
    panel_source = (
        APP / "overlay_feature" / "panel_runtime.py"
    ).read_text(encoding="utf-8")
    actions_source = (
        APP / "overlay_feature" / "panel_actions_runtime.py"
    ).read_text(encoding="utf-8")
    check("from overlay_feature.window_control import" in runtime_source,
          "运行时辅助复用独立平台窗口控制")
    check("ctypes.windll.user32" not in runtime_source,
          "runtime.py 不再直接堆 Win32 调用")
    check("_geometry.panel_position" in panel_source
          and "_window_control.window_handles" in actions_source
          and "_window_control" in overlay_source,
          "悬浮窗主类只调用几何与平台边界")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
