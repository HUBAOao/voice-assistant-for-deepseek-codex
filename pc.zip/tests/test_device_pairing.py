# -*- coding: utf-8 -*-
"""验收「新设备要配对」这道门：
   · 拿对新令牌的新设备，第一眼只能看到"等电脑上点允许"那一页 + 一个配对码
   · 电脑上（或按码）允许之后，它才真的进得来
   · 拒绝之后它就出局，再来又是一个新码
   · 令牌还是第一道门：令牌不对照样 401
跑在独立端口上（8795），不碰正在运行的那个手机入口。
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))
_TEST_TMP = tempfile.TemporaryDirectory()
_TEST_DIR = Path(_TEST_TMP.name)
os.environ["FIN_DECK_TOKEN_FILE"] = str(_TEST_DIR / "phone-token.txt")
os.environ["FIN_DECK_DEVICE_FILE"] = str(_TEST_DIR / "phone-devices.json")
os.environ["FIN_DECK_ACCESS_FILE"] = str(_TEST_DIR / "phone-access.jsonl")
os.environ["FIN_DECK_SECURITY_KEY"] = str(_TEST_DIR / "transport-key.bin")
os.environ["FIN_DECK_SECURITY_POLICY"] = str(_TEST_DIR / "policy.json")
os.environ["FIN_DECK_SECURITY_META"] = str(_TEST_DIR / "key-meta.json")

PORT = 8795
GOOD = "pair-test-" + "c" * 28


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("pl", APP / "phone_link.py")
    pl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pl)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    def get(path: str, cookie: str = "", token: str = GOOD, ua: str = "PairTest/1.0"):
        import urllib.error
        import urllib.request
        url = "http://127.0.0.1:%d%s" % (link.port, path)
        req = urllib.request.Request(url + ("&" if "?" in path else "?") + "k=" + token)
        req.add_header("User-Agent", ua)
        req.add_header("X-Forwarded-For", "203.0.113.12")
        if cookie:
            req.add_header("Cookie", cookie)
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                return r.status, r.read().decode("utf-8", "replace"), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), e.headers

    def post(path: str, payload: dict, cookie: str = "", capability: str = ""):
        import urllib.error
        import urllib.request
        url = "http://127.0.0.1:%d%s?k=%s" % (link.port, path, GOOD)
        req = urllib.request.Request(
            url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "PairTest/1.0")
        req.add_header("X-Forwarded-For", "203.0.113.12")
        if cookie:
            req.add_header("Cookie", cookie)
        if capability:
            req.add_header("X-FinDeck-Capability", capability)
        try:
            with urllib.request.urlopen(req, timeout=12) as r:
                return r.status, r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")

    pl.device_forget_all()
    link = pl.PhoneLink(on_command=lambda *_: None,
                        get_state=lambda: {"state_text": "idle"},
                        get_log=lambda since: [], port=PORT, token=GOOD)
    check(link.start(), "服务起在 %d 端口" % link.port)

    print("① 新设备：只能看到「等电脑上点允许」那一页")
    st, body, hdr = get("/")
    check(st == 200, "HTTP %d" % st)
    check("等你在电脑上点一下" in body, "页面是「等确认」那一页")
    sc = hdr.get("Set-Cookie") or ""
    check("va_dev=" in sc, "给这台设备发了 cookie")
    check("HttpOnly" in sc, "cookie 是 HttpOnly（网页脚本读不到）")
    cookie = sc.split(";")[0]
    pend = pl.pending_devices()
    check(len(pend) == 1, "电脑这边登记到 1 台待确认设备")
    code = str(pend[0].get("code") or "")
    check(len(code) == 6 and code.isdigit(), "配对码是 6 位数字：%s" % code)
    check(code in body, "手机上显示的码 = 电脑上登记的码")

    print("② 同一台设备，还没允许之前进不来")
    st, body, _ = get("/", cookie=cookie)
    check(st == 200 and "等你在电脑上点一下" in body, "还是「等确认」那一页")
    st, body, _ = get("/api/version", cookie=cookie)
    check(st == 403 and "pairing" in body, "/api/version 也挡住（403 pairing）")

    print("③ 电脑上点「允许」之后才进得来")
    ok, msg = pl.device_allow_by_code(code)
    check(ok, "按配对码允许：%s" % msg)
    st, body, _ = get("/", cookie=cookie)
    check(st == 200 and "等你在电脑上点一下" not in body and len(body) > 5000,
          "现在是真页面了（%d 字节）" % len(body))
    st, body, _ = get("/api/version", cookie=cookie)
    check(st == 200 and '"ok": true' in body, "/api/version 通了")
    st, body, _ = get("/api/security/session", cookie=cookie)
    session = json.loads(body) if st == 200 else {}
    cap = str(session.get("capability") or "")
    check(st == 200 and bool(cap), "已配对设备领取短时操作凭据")
    st, body = post("/api/security/action", {"action": "policy"}, cookie)
    check(st == 403 and '"need_capability": true' in body,
          "高风险操作缺少能力凭据 -> 403")
    st, body = post("/api/security/action", {
        "action": "policy",
        "capability_ttl_seconds": 600,
        "rotate_days": 30,
        "max_active_devices": 8,
    }, cookie, cap)
    check(st == 200 and '"ok": true' in body, "设备绑定凭据可执行跨设备策略")
    st, body, _ = get("/api/security", cookie=cookie)
    check(st == 200 and '"devices": [' in body, "安全状态返回设备授权列表")
    phrase = "pair-test-portable-passphrase"
    st, body = post("/api/security/action", {
        "action": "backup-key", "passphrase": phrase
    }, cookie, cap)
    backup_payload = json.loads(body).get("backup", {}) if st == 200 else {}
    backup_text = str(backup_payload.get("backup") or "")
    check(st == 200 and "FINSEC-BACKUP-1" in backup_text,
          "跨设备操作密钥恢复包可导出")
    st, body = post("/api/security/action", {"action": "rotate-key"},
                    cookie, cap)
    check(st == 200 and '"ok": true' in body, "操作密钥轮换可用")
    st, body, _ = get("/api/security/session", cookie=cookie)
    cap2 = str(json.loads(body).get("capability") or "") if st == 200 else ""
    check(bool(cap2), "轮换后设备领取新能力凭据")
    st, body = post("/api/security/action", {
        "action": "restore-key", "backup": backup_text, "passphrase": phrase
    }, cookie, cap2)
    check(st == 200 and '"key_id"' in body, "恢复包可回写操作密钥")
    st, body, _ = get("/api/security/session", cookie=cookie)
    cap = str(json.loads(body).get("capability") or "") if st == 200 else ""
    check(bool(cap), "恢复后重新领取短时凭据")

    print("④ 换了台设备（没有 cookie、换了个 UA）：又得重新确认")
    st, body, hdr2 = get("/", ua="Another-Device/2.0")
    check("等你在电脑上点一下" in body, "第二台设备也是「等确认」那一页")
    check(len(pl.pending_devices()) == 1, "待确认列表里是这第二台")

    print("④.5 同一台设备反复来（APP 后台轮询就是这种，不带 cookie）：只算一台")
    for _ in range(3):
        get("/", ua="Another-Device/2.0")
    check(len(pl.pending_devices()) == 1, "连来 3 次还是同一台（不会变成 4 台）")

    print("⑤ 拒绝：它就出局了")
    did2 = pl.pending_devices()[0]["id"]
    check(pl.device_deny(did2)[0], "拒绝掉")
    st, body, hdr3 = get("/", ua="Another-Device/2.0")
    check("等你在电脑上点一下" in body, "再来还是「等确认」那一页（但不该再弹窗骚扰）")
    check(not any(d["id"] == did2 for d in pl.pending_devices()),
          "拒绝过的设备不出现在「待确认」列表里")

    print("⑥ 令牌还是第一道门")
    st, body, _ = get("/", token="wrong-token-wrong-token-wrong-token-wr")
    check(st == 401, "令牌不对 -> HTTP %d" % st)

    print("⑦ 设备级吊销：旧 cookie 和旧短时凭据同时失效")
    st, body, _ = get("/api/security", cookie=cookie)
    groups = json.loads(body).get("devices") or []
    current = next((g for g in groups if g.get("current")), {})
    ids = current.get("ids") or []
    st, body = post("/api/security/action", {
        "action": "revoke-device", "ids": ids, "confirm": True
    }, cookie, cap)
    check(st == 200 and json.loads(body).get("revoked", 0) >= 1,
          "当前设备已即时吊销")
    st, body, _ = get("/api/version", cookie=cookie)
    check(st == 403 and "pairing" in body, "被吊销设备不能继续访问 API")
    st, body = post("/api/security/action", {"action": "prune"}, cookie, cap)
    check(st == 403, "被吊销设备的旧能力凭据也被拒绝")

    link.stop()
    pl.device_forget_all()
    _TEST_TMP.cleanup()
    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
