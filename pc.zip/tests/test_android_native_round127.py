# -*- coding: utf-8 -*-
"""Round 127 native audio preview card parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MEDIA_JS = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "media.js"
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    media = MEDIA_JS.read_text(encoding="utf-8")
    start = media.index("async function pullAudios(")
    end = media.index('document.getElementById("audiorefresh")', start)
    audios = media[start:end]
    activity = ACTIVITY.read_text(encoding="utf-8")
    native_start = activity.index("private void addAudioFile(")
    native_end = activity.index("private void stopFilePlayer(", native_start)
    native = activity[native_start:native_end]

    print("① 旧试听卡最终规格")
    check(
        "margin:8px 0;padding:10px;border:1px solid var(--line);"
        in audios
        and "border-radius:11px;background:var(--panel)" in audios,
        "旧试听卡为 PANEL 底、1px 边框、11px 圆角、10px 内边距和 8px 外边距",
    )
    check(
        "font-size:13px;margin-bottom:8px;word-break:break-all"
        in audios,
        "旧文件名 13px、8px 下间距且可换行",
    )
    check(
        "au.controls = true;" in audios
        and "width:100%;height:36px" in audios,
        "旧播放控件为满宽 36px",
    )

    print("\n② 原生试听卡")
    check(
        "NativeTheme.card(this)" not in native
        and "audioFileCard(" in native,
        "原生试听不再使用通用圆角 16 卡",
    )
    check(
        "private LinearLayout audioFileCard()" in activity
        and "NativeTheme.PANEL, 11, this" in activity
        and "setStroke(NativeTheme.dp(this, 1), NativeTheme.LINE)" in activity,
        "原生试听卡恢复 PANEL、11px 圆角和 1px 边框",
    )
    check(
        "NativeTheme.text(this, filename, 13, NativeTheme.TEXT)"
        in activity
        and "filenameParams.bottomMargin = NativeTheme.dp(this, 8);" in activity,
        "原生文件名恢复 13px 和 8px 下间距",
    )
    check(
        'play.setTag("audio-preview-control");' in native
        and "NativeTheme.dp(this, 36)" in native,
        "原生播放控件恢复 36px 高度",
    )
    check(
        "card.addView(play, new LinearLayout.LayoutParams("
        in native
        and "ViewGroup.LayoutParams.MATCH_PARENT," in native,
        "原生播放控件占满试听卡宽度",
    )
    check(
        "new android.media.MediaPlayer()" in native
        and "prepareAsync();" in native
        and "filePlayerGeneration" in native
        and "stopFilePlayer();" in native,
        "MediaPlayer 播放/停止、页面清理和代际语义保留",
    )

    spec = importlib.util.spec_from_file_location(
        "round127_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("试听卡" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录试听卡收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"audioFileCard" in dex
            and b"audio-preview-control" in dex,
            "APK/DEX 含新试听卡与满宽播放控件",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
