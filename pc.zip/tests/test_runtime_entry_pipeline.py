# -*- coding: utf-8 -*-
"""Entry ordering stays testable outside stt.main()."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature import runtime_entry_pipeline as entry  # noqa: E402


def make_dependencies(*, tracker=None):
    calls = []
    deps = SimpleNamespace(
        raw_args=["--mode", "talk"],
        lifecycle=object(),
        bootstrap=object(),
        cli=SimpleNamespace(
            list_devices=lambda: calls.append("devices"),
        ),
        audio=object(),
        make_tracker=lambda: (
            calls.append("tracker") or tracker or SimpleNamespace()
        ),
        create_session_state=lambda *args: (
            calls.append(("state", args))
            or SimpleNamespace(as_tuple=lambda: ("state-ready",))
        ),
        stop_words=["停", "别说了"],
        emit=lambda text: calls.append(("emit", text)),
    )
    return deps, calls


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    old_prepare_runtime = entry.prepare_runtime
    old_run_cli = entry.run_cli_mode
    old_prepare_audio = entry.prepare_audio_runtime
    try:
        deps, calls = make_dependencies()
        entry.prepare_runtime = lambda *_args: None
        duplicate = entry.prepare_runtime_entry(deps)
        check(duplicate.exit_code == 0 and duplicate.audio is None,
              "单实例退出保留原有的成功返回码 0")
        check(calls == [], "单实例退出后不再运行命令行或音频装配")

        startup = SimpleNamespace(
            instance_guard="guard",
            cfg={"wake_word": "大肥鱼", "model": "small"},
            profile="full",
            hardware={"why": "test"},
            args=SimpleNamespace(wake_timeout=4.5),
        )
        deps, calls = make_dependencies()
        entry.prepare_runtime = lambda *_args: startup
        entry.run_cli_mode = lambda *_args: 7
        cli = entry.prepare_runtime_entry(deps)
        check(cli.exit_code == 7 and cli.startup is startup,
              "命令行工具模式保留原返回码和启动结果")
        check(not any(isinstance(item, tuple) and item[0] == "state" for item in calls),
              "命令行模式不会继续创建语音会话状态")

        audio = SimpleNamespace(
            mode="talk",
            wake_words=["大肥鱼"],
        )
        deps, calls = make_dependencies()
        entry.prepare_runtime = lambda *_args: startup
        entry.run_cli_mode = lambda *_args: None
        entry.prepare_audio_runtime = lambda *_args: audio
        ready = entry.prepare_runtime_entry(deps)
        check(ready.exit_code is None and ready.audio is audio,
              "正常启动返回已准备的音频会话")
        check(ready.tracker is not None and "tracker" in calls,
              "talk 模式仍创建前台窗口跟踪器")
        state_calls = [item[1] for item in calls
                       if isinstance(item, tuple) and item[0] == "state"]
        check(bool(state_calls)
              and state_calls[0][1:] == (
                  "talk",
                  ["大肥鱼"],
                  4.5,
                  ["停", "别说了"],
              ),
              "会话状态仍收到模式、唤醒词、超时和停止词")

        deps, calls = make_dependencies()
        entry.prepare_runtime = lambda *_args: startup
        entry.run_cli_mode = lambda *_args: None
        entry.prepare_audio_runtime = lambda *_args: (_ for _ in ()).throw(
            SystemExit("没有麦克风")
        )
        failed = entry.prepare_runtime_entry(deps)
        check(failed.exit_code == 2 and "devices" in calls,
              "音频打开失败仍列出设备并返回 2")
    finally:
        entry.prepare_runtime = old_prepare_runtime
        entry.run_cli_mode = old_run_cli
        entry.prepare_audio_runtime = old_prepare_audio

    source = (APP / "stt.py").read_text(encoding="utf-8")
    entry_source = (
        APP / "voice_feature" / "runtime_application_entry.py"
    ).read_text(encoding="utf-8")
    check("prepare_runtime(" not in source
          and "prepare_runtime(" not in entry_source,
          "main() 不再直接装配启动流程")
    check("prepare_audio_runtime(" not in source
          and "prepare_audio_runtime(" not in entry_source,
          "main() 不再直接打开音频运行时")
    check("prepare_runtime_entry(" in entry_source
          and "run_runtime_application(" in source,
          "stt.py 继续通过兼容入口消费启动管线")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
