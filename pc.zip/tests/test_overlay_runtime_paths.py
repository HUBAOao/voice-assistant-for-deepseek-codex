# -*- coding: utf-8 -*-
"""Overlay settings modules resolve live paths from one runtime binding."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import runtime  # noqa: E402
from overlay_feature.settings_backup_mixin import (  # noqa: E402
    OverlaySettingsBackupMixin,
)
from overlay_feature.settings_shell_mixin import send_command  # noqa: E402
from overlay_feature.settings_runtime import (  # noqa: E402
    DEFAULT_ALPHA,
    MIN_ALPHA,
    OverlayConfigWatcher,
    build_overlay_settings,
)


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    state = build_overlay_settings({
        "overlay_color": "not-a-color",
        "overlay_accent": "#abc",
        "overlay_alpha": 0.1,
        "perf_mode": "eco",
        "anim_fps": 60,
        "overlay_show_name": False,
        "ov_name_x": "12",
        "fx_glow": False,
    })
    check(state.panel_color == "#1b1b1f",
          "非法窗口色回退默认值，不把 Tk 崩掉")
    check(state.accent == "#abc", "合法三位颜色原样保留")
    check(state.alpha == MIN_ALPHA and DEFAULT_ALPHA > MIN_ALPHA,
          "透明度按运行边界钳制")
    check(state.perf == "eco" and state.fps == 20 and state.frame_ms == 50,
          "节能模式统一收敛到 20 FPS")
    check(state.show_name is False, "显式关闭布尔设置不会被默认值覆盖")
    check(state.layout["name"][0] == 12 and state.fx["fx_glow"] is False,
          "布局与特效开关由独立状态对象归一化")
    target = SimpleNamespace()
    state.apply_to(target)
    target.fx["fx_glow"] = True
    target.layout["name"] = (-1, -1, -1)
    check(state.fx["fx_glow"] is False
          and state.layout["name"][0] == 12,
          "应用状态使用可变副本，不污染下一次配置")

    clock = [10.0]
    mtime = [1.0]
    payload = {"v": 0}
    loads = []

    def load():
        loads.append(payload["v"])
        return dict(payload)

    watcher = OverlayConfigWatcher(
        path_provider=lambda: Path("virtual-config.json"),
        loader=load,
        clock=lambda: clock[0],
        stat_mtime=lambda _path: mtime[0],
        throttle_seconds=0.3,
    )
    check(watcher.load_initial() == {"v": 0} and watcher.mtime == 1.0,
          "配置监视器首次读取并记录 mtime")
    payload["v"] = 1
    mtime[0] = 2.0
    check(watcher.poll() == {"v": 1} and loads == [0, 1],
          "文件变化时只加载一次新配置")
    payload["v"] = 2
    mtime[0] = 3.0
    clock[0] = 10.1
    check(watcher.poll() is None and loads == [0, 1],
          "节流窗口内不重复读取文件")
    clock[0] = 10.31
    check(watcher.poll() == {"v": 2} and loads == [0, 1, 2],
          "节流结束后识别下一次写入")
    mtime[0] = None
    clock[0] = 11.0
    check(watcher.poll() is None and loads == [0, 1, 2],
          "配置文件暂时消失不会清空当前现场")

    with tempfile.TemporaryDirectory(prefix="findeck_overlay_paths_") as raw:
        root = Path(raw)
        old_config = runtime.CONFIG
        old_control = runtime.CONTROL
        old_hide = __import__(
            "overlay_feature.settings_backup_mixin",
            fromlist=["_window_control"],
        )._window_control.hide_path
        try:
            runtime.CONFIG = root / "app" / "config.json"
            runtime.CONFIG.parent.mkdir()
            runtime.CONFIG.write_text(
                json.dumps({"name": "路径测试"}, ensure_ascii=False),
                encoding="utf-8",
            )
            runtime.CONTROL = root / "state" / "control.json"
            runtime.CONTROL.parent.mkdir()

            send_command("diagnose")
            payload = json.loads(runtime.CONTROL.read_text(encoding="utf-8"))
            check(payload.get("action") == "diagnose",
                  "设置命令写到当前 runtime.CONTROL")

            backup_module = __import__(
                "overlay_feature.settings_backup_mixin",
                fromlist=["_window_control"],
            )
            backup_module._window_control.hide_path = lambda _path: True
            fake = object.__new__(OverlaySettingsBackupMixin)
            export = fake.backup_dir()
            check(export == runtime.CONFIG.parent / "导出" and export.is_dir(),
                  "备份目录跟随当前 runtime.CONFIG，不再绑定导入时常量")
        finally:
            runtime.CONFIG = old_config
            runtime.CONTROL = old_control
            backup_module = __import__(
                "overlay_feature.settings_backup_mixin",
                fromlist=["_window_control"],
            )
            backup_module._window_control.hide_path = old_hide

    collect = (
        APP / "overlay_feature" / "settings_collect_mixin.py"
    ).read_text(encoding="utf-8")
    persistence = (
        APP / "overlay_feature" / "settings_persistence_mixin.py"
    ).read_text(encoding="utf-8")
    shell = (
        APP / "overlay_feature" / "settings_shell_mixin.py"
    ).read_text(encoding="utf-8")
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("_runtime.CONFIG" in collect and "from overlay_feature.runtime import CONFIG" not in collect,
          "设置收集每次读取当前 runtime.CONFIG")
    check("_runtime.CONFIG" in persistence
          and "from overlay_feature.runtime import CONFIG" not in persistence,
          "设置持久化写入当前 runtime.CONFIG")
    check("_runtime.CONTROL" in shell
          and "from overlay_feature.runtime import CONTROL" not in shell,
          "设置命令发送到当前 runtime.CONTROL")
    check("OverlayConfigWatcher" in overlay
          and "build_overlay_settings(self.cfg)" in overlay,
          "overlay.py 只保留配置监视与设置应用入口")
    check("CONFIG_MS" not in overlay and "safe_color(" not in overlay,
          "节流、mtime 与颜色归一化依赖已移出巨型文件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
