# -*- coding: utf-8 -*-
"""The live Status instance must not shadow the runtime_status module."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import stt


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="findeck_status_module_") as raw:
        log_path = Path(raw) / "syslog.md"
        stt.SYSLOG_FILE = log_path
        stt._runtime_status = stt.Status(status_file=Path(raw) / "status.json")
        stt.syslog("测", "模块名未被实例覆盖")
        text = log_path.read_text(encoding="utf-8")
        assert "模块名未被实例覆盖" in text
    print("test_runtime_status_module_name_round136: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
