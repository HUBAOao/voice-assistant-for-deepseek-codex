# -*- coding: utf-8 -*-
"""Startup assembly has one deterministic order and keeps escape flags."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_bootstrap import (  # noqa: E402
    RuntimeBootstrapDependencies,
    prepare_runtime,
)
from voice_feature.runtime_lifecycle import RuntimeLifecycle  # noqa: E402


class FakeGuard:
    def __init__(self, acquired: bool = True) -> None:
        self.acquired = acquired
        self.owned = acquired
        self.released = 0
        self.acquire_count = 0

    def acquire(self) -> bool:
        self.acquire_count += 1
        return self.acquired

    def release(self) -> None:
        self.released += 1


class FakeParser:
    def __init__(self, cfg: dict, default_input, default_out, calls) -> None:
        self.cfg = cfg
        self.default_input = default_input
        self.default_out = default_out
        self.calls = calls

    def parse_args(self, args):
        self.calls.append(("parse", tuple(args)))
        return {"parsed_args": list(args), "cfg": self.cfg}


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    def dependencies(calls, guard, manual_exit, atexit_calls):
        cfg = {"phone_target": "saved", "input": "saved-mic"}

        def restore(saved):
            calls.append(("restore", saved.copy()))

        def apply_profile(saved, profile, hardware):
            calls.append(("profile", profile, hardware["why"], saved.copy()))

        def parser(saved, default_input, default_out):
            calls.append(("parser", default_input, default_out))
            return FakeParser(saved, default_input, default_out, calls)

        return RuntimeBootstrapDependencies(
            setup_console=lambda: calls.append("console"),
            make_instance_guard=lambda: guard,
            load_config=lambda: cfg,
            start_plugins=lambda: calls.append("plugins"),
            restore_saved_state=restore,
            detect_profile=lambda: ("lite", {"why": "test", "ram": 8}),
            apply_low_profile=apply_profile,
            build_parser=parser,
            start_heartbeat=lambda lifecycle: calls.append(
                ("heartbeat", lifecycle)
            ),
            register_atexit=lambda callback: atexit_calls.append(callback),
            default_input=lambda saved: "env-mic" if saved.get("input") else None,
            default_out="out.md",
            manual_exit=manual_exit,
            emit=lambda text: calls.append(("emit", text)),
        )

    with tempfile.TemporaryDirectory(prefix="findeck_bootstrap_") as raw:
        manual_exit = Path(raw) / "manual-exit.json"
        manual_exit.write_text("{}", encoding="utf-8")
        lifecycle = RuntimeLifecycle()

        calls = []
        guard = FakeGuard(False)
        atexit_calls = []
        blocked = prepare_runtime(
            ["--mode", "talk"],
            dependencies(calls, guard, manual_exit, atexit_calls),
            lifecycle,
        )
        check(blocked is None, "已有实例时启动入口返回 None")
        check(calls == ["console", ("emit", "已经有一份在跑了，这份退出。")],
              "启动闸拒绝后不再读配置、插件或参数")
        check(manual_exit.exists(), "被单实例闸拒绝时不清理手动退出标记")

        calls = []
        guard = FakeGuard(True)
        atexit_calls = []
        result = prepare_runtime(
            ["--mode", "talk"],
            dependencies(calls, guard, manual_exit, atexit_calls),
            lifecycle,
        )
        order = [item if isinstance(item, str) else item[0] for item in calls]
        check(
            order == ["console", "plugins", "restore", "profile", "parser",
                      "parse", "heartbeat"],
            "配置、插件、持久状态、机器档位、参数和心跳按固定顺序装配",
        )
        check(result is not None and result.cfg["phone_target"] == "saved",
              "启动结果把配置原样交给主流程")
        check(result.profile == "lite" and result.hardware["why"] == "test",
              "启动结果保留机器档位与诊断信息")
        check(calls[2][1]["phone_target"] == "saved",
              "持久状态在插件启动后恢复")
        check(calls[4][1:] == ("env-mic", "out.md"),
              "参数解析使用环境变量优先的输入设备和稳定输出路径")
        heartbeat = next(item for item in calls if item[0] == "heartbeat")
        check(heartbeat[1] is lifecycle, "心跳接入同一个生命周期")
        check(atexit_calls == [guard.release],
              "拥有单实例锁时只登记一次退出释放")
        check(not manual_exit.exists(), "自启动成功后清除手动退出标记")
        check(result.args["parsed_args"] == ["--mode", "talk"],
              "原始参数原样交给命令行解析")

        manual_exit.write_text("{}", encoding="utf-8")
        calls = []
        guard = FakeGuard(False)
        atexit_calls = []
        escaped = prepare_runtime(
            ["--allow-multiple", "--list-devices"],
            dependencies(calls, guard, manual_exit, atexit_calls),
            lifecycle,
        )
        check(escaped is not None and guard.acquire_count == 0,
              "--allow-multiple 在参数解析前仍能绕过单实例闸")
        check(atexit_calls == [], "未持有锁时不登记释放回调")
        check(not manual_exit.exists(), "显式多实例启动也清理旧崩溃标记")

        entry_source = (
            APP / "voice_feature" / "runtime_application_entry.py"
        ).read_text(encoding="utf-8")
        orchestrator = (
            APP / "voice_feature" / "runtime_application_assembly.py"
        ).read_text(encoding="utf-8")
        check("prepare_runtime_entry(" in entry_source
              and "entry.startup" in entry_source
              and "allow_multiple_requested" not in entry_source
              and "prepare_entry(application)" in orchestrator,
              "main() 已改用统一启动装配，不再内联单实例判断")
        check(entry_source.count("start_heartbeat=application.start_heartbeat") == 1,
              "主流程只把心跳服务交给启动装配一次")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
