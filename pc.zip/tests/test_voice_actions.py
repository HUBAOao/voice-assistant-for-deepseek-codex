# -*- coding: utf-8 -*-
"""Unit tests for structured voice actions and routing."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from features.voice_actions import VoiceActionRouter, parse_voice_action  # noqa: E402


def main() -> int:
    cases = {
        "批准这个": "approve",
        "拒绝当前操作": "reject",
        "取消当前任务": "cancel_task",
        "任务状态": "task_status",
        "切换到鳍舱优化": "switch_thread",
        "在当前会话说继续检查测试": "send_message",
        "帮我查天气": "unknown",
        "打开计算器": "unknown",
    }
    for text, kind in cases.items():
        assert parse_voice_action(text).kind == kind, (text, parse_voice_action(text))
    switched = parse_voice_action("切换到鳍舱优化")
    assert switched.target == "鳍舱优化"
    sent = parse_voice_action("在当前会话说继续检查测试")
    assert sent.text == "继续检查测试"

    called = []
    router = VoiceActionRouter({
        "approve": lambda action: called.append("approve") or "批准成功",
        "task_status": lambda action: "2 个任务",
    })
    ok, msg = router.execute(parse_voice_action("批准这个"))
    assert ok and msg == "批准成功" and called == ["approve"]
    ok, msg = router.execute(parse_voice_action("任务状态"))
    assert ok and msg == "2 个任务"
    ok, msg = router.execute(parse_voice_action("帮我查天气"))
    assert not ok and not msg
    print("test_voice_actions: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
