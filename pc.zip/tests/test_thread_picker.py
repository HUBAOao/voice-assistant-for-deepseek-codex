# -*- coding: utf-8 -*-
"""Acceptance checks for the Codex-style phone conversation picker."""
from __future__ import annotations

import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def post(url: str, payload: dict, capability: str = "") -> dict:
    headers = {"Content-Type": "application/json"}
    if capability:
        headers["X-FinDeck-Capability"] = capability
    req = urllib.request.Request(
        url,
        method="POST",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(ok: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if ok else "  ✗ ") + text)
        if not ok:
            bad += 1

    import phone_link

    seen_actions: list[tuple] = []
    seen_new: list[str] = []
    rows = [
        {
            "id": "thread-1",
            "title": "语音助手第四轮",
            "current": True,
            "pinned": False,
            "project": "语音助手",
            "project_id": "project-1",
            "archived": False,
            "unread": True,
            "updated_at": 1_792_720_000_000,
            "preview": "把切换会话页做得完整一点",
            "read_revision": "rev-1",
        },
        {
            "id": "thread-2",
            "title": "养鱼第二轮",
            "current": False,
            "pinned": True,
            "project": "",
            "project_id": "",
            "archived": False,
            "unread": False,
            "updated_at": 1_792_710_000_000,
            "preview": "B 站插件",
        },
    ]
    projects = [{"id": "project-1", "name": "语音助手", "position": 0}]

    link = phone_link.PhoneLink(
        on_command=lambda text: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda *_: [],
        port=8831,
        pairing=False,
        token="t" * 40,
    )
    link.get_windows = lambda: rows
    link.get_projects = lambda: projects
    link.get_target = lambda: "养鱼第二轮"
    link.get_target_id = lambda: "thread-2"

    def on_action(action: str, thread_id: str, data: dict):
        seen_actions.append((action, thread_id, data))
        return True, "已执行 " + action

    def on_new(project_id: str):
        seen_new.append(project_id)
        return True, "新对话"

    link.on_thread_action = on_action
    link.on_new_thread = on_new
    if not link.start():
        check(False, "测试手机入口启动失败")
        return 1
    try:
        time.sleep(0.2)
        q = "?k=" + link.token
        with urllib.request.urlopen("http://127.0.0.1:8831/api/windows" + q,
                                    timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
        check(data.get("ok") is True, "会话接口正常返回")
        check(data.get("chosen_id") == "thread-2", "返回手机指定会话的稳定 ID")
        check(data.get("projects") == projects, "返回完整项目列表")
        check(len(data.get("windows") or []) == 2, "返回两个会话")
        first = (data.get("windows") or [{}])[0]
        check(first.get("preview") == "把切换会话页做得完整一点", "返回会话预览")
        check(first.get("read_revision") == "rev-1", "返回已读状态 revision")
        with urllib.request.urlopen(
                "http://127.0.0.1:8831/api/security/session" + q,
                timeout=10) as response:
            capability = json.loads(
                response.read().decode("utf-8")).get("capability") or ""
        check(bool(capability), "会话操作领取短时能力凭据")

        result = post("http://127.0.0.1:8831/api/threads/action" + q, {
            "action": "rename",
            "id": "thread-1",
            "name": "新名字",
        }, capability)
        check(result.get("ok") is True and seen_actions, "会话操作接口可达")
        check(seen_actions[0][0] == "rename" and seen_actions[0][1] == "thread-1",
              "操作动作和会话 ID 原样传到电脑端")

        result = post("http://127.0.0.1:8831/api/threads/new" + q,
                      {"project_id": "project-1"}, capability)
        check(result.get("ok") is True and seen_new == ["project-1"],
              "项目内新建对话接口可达")
    finally:
        link.stop()

    page = phone_link.current_page()
    page += "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((APP / "phone_feature" / "ui").glob("*.js"))
    )
    for needle, label in [
        ('id="convsearch"', "搜索框"),
        ('id="convnew"', "新建会话按钮"),
        ("function showConvActions", "长按会话操作菜单"),
        ('/api/threads/action', "会话管理接口"),
        ("collapsedGroups", "项目分组折叠"),
        ("convTimeText", "更新时间"),
        ("unread-dot", "未读状态"),
    ]:
        check(needle in page, "手机页包含" + label)

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
