# -*- coding: utf-8 -*-
"""Command/wake assembly keeps wiring and structured completion semantics."""
from __future__ import annotations

import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_gate_assembly import (  # noqa: E402
    RuntimeGateAssemblyDependencies,
    assemble_runtime_gates,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls = []
    command = object()
    wake = object()
    runtime = assemble_runtime_gates(
        RuntimeGateAssemblyDependencies(
            command=command,
            wake=wake,
            arm_followup=lambda: calls.append("followup"),
            once=True,
            sleep=lambda seconds: calls.append(("sleep", seconds)),
        )
    )
    check(runtime.command_gate.deps is command,
          "命令闸门装配原样使用注入依赖")
    check(runtime.wake_gate.deps is wake,
          "唤醒闸门装配原样使用注入依赖")
    check(runtime.finish_structured_action() is True,
          "结构化动作结束继续返回 --once 会话状态")
    check(calls == ["followup", ("sleep", 0.4)],
          "先恢复连续对话，再保留原有 0.4 秒稳定等待")

    calls.clear()
    runtime = assemble_runtime_gates(
        RuntimeGateAssemblyDependencies(
            command=command,
            wake=wake,
            arm_followup=lambda: calls.append("followup"),
            once=False,
            sleep=lambda seconds: calls.append(("sleep", seconds)),
        )
    )
    check(runtime.finish_structured_action() is False,
          "普通会话的状态回调仍返回 False")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    application_gates = (
        APP / "voice_feature" / "runtime_application_gates.py"
    ).read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    main_source = ast.get_source_segment(source, main_node) or ""
    nested = {
        node.name
        for node in ast.walk(main_node)
        if isinstance(node, ast.FunctionDef)
    }
    check("finish_structured_action" not in nested,
          "结束回调不再内联在 main()")
    check("assemble_runtime_gate_wiring(" in application_gates
          and "gate_runtime.finish_structured_action" in application_gates
          and "return run_runtime_application(" in main_source,
          "main() 只消费独立闸门接线结果")
    check("RuntimeCommandGateDependencies(" not in main_source
          and "RuntimeWakeGateDependencies(" not in main_source
          and "RuntimeGateAssemblyDependencies(" not in main_source,
          "main() 不再直接铺开两个闸门和总装配依赖")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
