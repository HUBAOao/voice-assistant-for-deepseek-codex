# -*- coding: utf-8 -*-
"""PC-only process-lifecycle guards for TTS startup and stale PID files."""
from __future__ import annotations

import importlib.util
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_tts_lifecycle_") as raw:
        root = Path(raw)
        fake_exe = root / "env" / "Scripts" / "python.exe"
        fake_root = root / "gpt-sovits" / "GPT-SoVITS"
        fake_exe.parent.mkdir(parents=True)
        fake_root.mkdir(parents=True)
        fake_exe.write_bytes(b"fake")
        (fake_root / "api_v2.py").write_text("# fake", encoding="utf-8")

        service = load("tts_lifecycle", APP / "voice_feature" / "speech_tts_service.py")
        service.TS_DIR = root
        service._tts_port_open = lambda: False
        service.time.sleep = lambda _seconds: None

        class Proc:
            pid = 424242

            def poll(self):
                return None

        killed = []
        service.subprocess.Popen = lambda *_args, **_kwargs: Proc()
        service.subprocess.run = (
            lambda args, **_kwargs: killed.append(int(args[2]))
        )
        result = service.ensure_tts_server(wait=0.01)
        check(not result, "TTS 启动超时明确返回失败")
        check(killed == [424242], "TTS 启动超时会清理整组子进程")
        check(service._TS_SERVER["proc"] is None,
              "失败 TTS 不会继续留在全局状态里")

    quit_all = load("quit_lifecycle", APP / "quit_all.py")
    killed_pids = []
    stale = {"tray.pid": 111, "overlay_ready.json": 222}
    quit_all.pid_from_file = lambda name: stale.get(name, 0)
    quit_all.kill_pid = lambda pid, why: killed_pids.append((pid, why))
    quit_all.kill_known({111})
    check(killed_pids == [(111, "tray.pid")],
          "旧 PID 只在该 PID 仍确属语音助手时才结束")
    check(all(pid != 222 for pid, _why in killed_pids),
          "过期 PID 即使被系统复用也不会误杀")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
