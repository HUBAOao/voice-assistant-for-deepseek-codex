# -*- coding: utf-8 -*-
"""Desktop update checking stays outside the settings shell."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_update_mixin import (  # noqa: E402
    OverlaySettingsUpdateMixin,
)


class Label:
    def __init__(self) -> None:
        self.calls = []

    def config(self, **kwargs) -> None:
        self.calls.append(kwargs)


class Root:
    def after(self, _delay, callback):
        callback()


class Probe(OverlaySettingsUpdateMixin):
    def __init__(self) -> None:
        self.upd_label = Label()
        self.root = Root()
        self.flash_calls = []
        self.dialog = None
        self.accent = "#3ddc84"

    def flash(self, text, seconds) -> None:
        self.flash_calls.append((text, seconds))

    def _update_dialog(self, version, pc, src) -> None:
        self.dialog = (version, pc, src)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    probe = Probe()
    probe._update_result({"ok": False, "err": "offline"})
    check(probe.upd_label.calls[-1]["text"] == "offline",
          "检查失败把真实原因写回版本标签")
    check(probe.flash_calls == [("offline", 3)],
          "检查失败保留原悬浮提示")

    probe = Probe()
    probe._update_result({"ok": True, "pc_new": False, "pc": {}})
    check(probe.upd_label.calls[-1]["text"].startswith("已是最新"),
          "没有新版时显示当前版本")
    check(probe.dialog is None, "没有新版时不弹安装对话框")

    probe = Probe()
    got = {
        "ok": True,
        "pc_new": True,
        "pc": {"version": "9.9"},
        "src": "http://example.test/version.json",
    }
    probe._update_result(got)
    check(probe.upd_label.calls[-1]["text"] == "有新版 v9.9",
          "发现新版时更新标签")
    check(probe.dialog == (
        "9.9", got["pc"], "http://example.test/version.json"
    ), "发现新版时把来源交给独立安装对话框")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    tree = ast.parse(overlay)
    overlay_class = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "Overlay"
    )
    methods = {
        node.name for node in overlay_class.body if isinstance(node, ast.FunctionDef)
    }
    check(not {"check_update", "_update_result", "_update_dialog"} & methods,
          "Overlay 外壳只通过 mixin 组合更新业务")
    check("OverlaySettingsUpdateMixin" in overlay,
          "原 check_update 按钮入口仍由兼容类组合提供")

    module = APP / "overlay_feature" / "settings_update_mixin.py"
    source = module.read_text(encoding="utf-8")
    for marker in (
        "self_update.check(self.cfg)",
        "self_update.resolve(",
        "self_update.apply_update(",
        "threading.Thread(target=work, daemon=True).start()",
    ):
        check(marker in source, f"更新模块保留 {marker}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
