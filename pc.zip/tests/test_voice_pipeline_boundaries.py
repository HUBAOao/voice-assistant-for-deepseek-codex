# -*- coding: utf-8 -*-
"""Unit-test the delivery, mute and capture timing boundaries."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from voice_feature.audio_capture import (  # noqa: E402
    continue_long_capture,
    has_utterance,
    not_heard_due,
)
from voice_feature.delivery_pipeline import deliver_text  # noqa: E402
from voice_feature.mute_commands import (  # noqa: E402
    dispatch_mute_command,
    mute_command,
)
from voice_feature.talk_state import (  # noqa: E402
    DELIVERY_CLIPBOARD,
    DELIVERY_DRY_RUN,
    DELIVERY_OFFLINE,
    DELIVERY_SEND,
)


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, *args, **kwargs) -> None:
        self.calls.append((args, kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    events = []
    status = Status()
    common = dict(
        title="Codex",
        send=lambda text, hwnd: events.append(("send", text, hwnd)) or True,
        copy=lambda text: events.append(("copy", text)) or True,
        status=status,
        syslog=lambda *args: events.append(("log",) + args),
        print_line=lambda *args, **kwargs: events.append(("print", args[0])),
    )
    result = deliver_text(
        "试跑",
        hwnd=1,
        dry_run=True,
        editing_settings=False,
        **common,
    )
    check(result.action == DELIVERY_DRY_RUN
          and events[0] == ("copy", "试跑")
          and all(item[0] != "send" for item in events),
          "dry-run 只复制，不发送")
    events.clear()
    result = deliver_text(
        "离线",
        hwnd=0,
        dry_run=False,
        editing_settings=False,
        **common,
    )
    check(result.action == DELIVERY_OFFLINE and events[0][0] == "copy",
          "无窗口时进入离线复制")
    events.clear()
    result = deliver_text(
        "改设置",
        hwnd=1,
        dry_run=False,
        editing_settings=True,
        **common,
    )
    check(result.action == DELIVERY_CLIPBOARD and all(x[0] != "send" for x in events),
          "改设置时只复制，不抢焦点")
    events.clear()
    sent = []
    result = deliver_text(
        "正常发送",
        hwnd=9,
        dry_run=False,
        editing_settings=False,
        confirm=lambda _text: True,
        on_sent=lambda: sent.append(True),
        sent_suffix="（并回车）",
        **common,
    )
    check(result.action == DELIVERY_SEND and result.sent and sent == [True],
          "真实发送后执行一次发送完成副作用")
    check(("send", "正常发送", 9) in events,
          "实际发送编排保留原窗口和正文")
    events.clear()
    result = deliver_text(
        "不确认",
        hwnd=9,
        dry_run=False,
        editing_settings=False,
        confirm=lambda _text: False,
        **common,
    )
    check(result.action == DELIVERY_CLIPBOARD and all(x[0] != "send" for x in events),
          "用户拒绝确认时不发送")

    order = []

    def speak(text):
        order.append(("speak", text))

    handled = dispatch_mute_command(
        mute_command("先静音", muted=False),
        set_muted=lambda value: order.append(("muted", value)),
        speak=speak,
        status=Status(),
        syslog=lambda *args: order.append(("log",) + args),
        shut_up=lambda: order.append(("shut",)),
        sleep=lambda seconds: order.append(("sleep", seconds)),
    )
    check(handled and order[0][0] == "speak"
          and order.index(("muted", True)) < order.index(("shut",)),
          "语音静音先确认再落状态并立即闭嘴")
    check(("muted", True) in order and ("sleep", 1.2) in order,
          "静音副作用顺序保持")
    check(mute_command("普通静音内容很长", muted=True) in ("", "mute"),
          "静音识别保持兼容")

    rate = 16000
    check(not has_utterance(np.zeros(100, dtype=np.float32), rate),
          "过短录音不送识别")
    check(has_utterance(np.zeros(rate // 2, dtype=np.float32), rate),
          "达到最短时长才进入识别")
    audio = np.zeros(rate, dtype=np.float32)
    check(not not_heard_due(audio, rate, previous_at=90, now=100),
          "没听清提示受 30 秒冷却限制")
    check(not_heard_due(audio, rate, previous_at=0, now=100),
          "超过冷却可提示一次")
    check(continue_long_capture(True, rate * 10, rate),
          "被切断的长句继续拼接")
    check(not continue_long_capture(False, rate * 10, rate),
          "正常断句不继续录音")
    check(not continue_long_capture(True, rate * 121, rate),
          "长句拼接到达 120 秒上限")

    stt = (ROOT / "outputs" / "voice-to-text" / "stt.py").read_text(encoding="utf-8")
    check("deliver_text(" in stt and "delivery_action =" not in stt,
          "STT 最终发送已交给独立管线")
    check("dispatch_mute_command(" in stt and "plain_mute" not in stt,
          "STT 静音副作用已交给独立模块")
    check("has_utterance(" in stt and "audio.size < rate // 4" not in stt,
          "STT 录音时长判断已收口")
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
