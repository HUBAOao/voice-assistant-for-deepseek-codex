# -*- coding: utf-8 -*-
"""Focused regression for desktop companion features moved out of main()."""
from __future__ import annotations

import json
import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.ambient_features import (  # noqa: E402
    AmbientFeatureDependencies,
    AmbientFeatureRuntime,
)


class Status:
    def __init__(self) -> None:
        self.focus = 0.0
        self.calls = []

    def set(self, state, **kwargs):
        self.calls.append((state, kwargs))

    def patch(self, **kwargs):
        self.calls.append(("patch", kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        now = [1000.0]
        spoken, beeps, awards, follows = [], [], [], []
        status = Status()
        config = {
            "theme": "默认",
            "schedules": [],
            "weather_city": "成都",
        }
        saved = []
        runtime = AmbientFeatureRuntime(
            AmbientFeatureDependencies(
                status=status,
                speak=spoken.append,
                beep=lambda freq, ms: beeps.append((freq, ms)),
                arm_followup=lambda: follows.append(True),
                award=awards.append,
                config=config,
                load_config=lambda: dict(config),
                save_config=lambda data: saved.append(dict(data)),
                notes_file=base / "notes.md",
                ledger_file=base / "ledger.json",
                weather_line=lambda city: f"；{city}晴 20°C",
                now=lambda: now[0],
                date_now=lambda: datetime(2026, 10, 23, 9, 5),
                choose=lambda values: values[0],
            )
        )

        runtime.focus_start(25)
        check(runtime.focus_active() and runtime.focus_left() == 1500,
              "番茄钟保留分钟、剩余时间与悬浮窗进度")
        check(awards == ["focus"] and follows,
              "开始专注仍解锁成就并续接监听")
        runtime.focus_stop()
        check(status.focus == 0.0 and spoken[-1] == "好，专注结束",
              "提前结束仍清空进度并保留原文")

        runtime.add_note("买牛奶")
        runtime.add_ledger("午饭", 23.5)
        runtime.say_ledger()
        runtime.say_notes()
        ledger = json.loads((base / "ledger.json").read_text(encoding="utf-8"))
        check(ledger[0]["name"] == "午饭" and ledger[0]["amount"] == 23.5,
              "记账数据与金额原样落盘")
        check(awards[-2:] == ["note", "ledger"],
              "便签和记账仍触发同一组成就")
        check("今天花了 23.5 块" in spoken[-2]
              and "最后几条是：买牛奶" in spoken[-1],
              "查询话术与历史入口保持不变")

        runtime.game_start("guess")
        answer = runtime.game["data"]["answer"]
        runtime.game_feed(str(answer))
        check(runtime.game["kind"] == "" and "猜对了" in spoken[-1],
              "猜数字仍能消费当前输入并结束")
        runtime.game_start("pick", "吃面还是吃饭")
        check(spoken[-1] == "我选：吃面" and runtime.game["kind"] == "",
              "二选一保留原选项解析与指定随机源")

        runtime.brief_now()
        check("星期五" in spoken[-1] and "成都晴 20°C" in spoken[-1],
              "早间播报仍组合日期、日程、花销和天气")
        runtime.transform()
        check(saved[-1]["theme"] == "深海"
              and saved[-1]["overlay_wave_style"] == "siri",
              "主题轮换仍经统一配置保存回调")
        check(beeps and status.calls,
              "提示音和悬浮窗状态仍由主运行时注入")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "desktop_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    check("class AmbientFeatureRuntime" not in stt,
          "伴随业务实现不再回到 stt.py")
    application_desktop = (
        APP / "voice_feature" / "runtime_application_desktop.py"
    ).read_text(encoding="utf-8")
    check("assemble_desktop_runtime(" in application_desktop
          and "AmbientFeatureRuntime(" in assembly,
          "main() 只调用桌面装配，伴随运行时在独立边界创建")
    for marker in (
        'def focus_start(', 'def add_note(', 'def game_start(',
        'def brief_now(', 'def transform(',
    ):
        check(marker not in stt, f"{marker} 已从 main() 迁出")

    status_at = assembly.find("status = deps.status_factory(deps.hint)")
    ambient_at = assembly.find("ambient = AmbientFeatureRuntime(")
    check(0 <= status_at < ambient_at,
          "伴随运行时在 Status 初始化之后装配，避免启动期未赋值")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
