# -*- coding: utf-8 -*-
"""Rendering mixin keeps relative assets and shared constants resolvable."""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.visuals import OverlayVisualMixin  # noqa: E402


class RenderProbe(OverlayVisualMixin):
    def __init__(self) -> None:
        self.cur_w = 344
        self.header_h = 112
        self.panel_color = "#1b1b1f"
        self.bg_image = "assets/default-bg.jpg"
        self.bg_dim = 45
        self.name = "大肥鱼"
        self.show_name = True
        self.layout = {"name": (16, 12, 19), "wave": (14, 42)}
        self.text_color = "#ffffff"
        self.button_color = "#2f7f5a"
        self._base = None
        self._base_key = None
        self._sprites = {}
        self.expanded = False
        self.talk_color = "#4aa3ff"


def main() -> int:
    probe = RenderProbe()
    base = probe.base_image()
    assert base.size == (344, 112)
    assert probe.switch_sprite(0.5).size == (46, 24)
    assert probe.ball_sprite("#ffffff", 6).width >= 12
    canvas = Image.new("RGB", (120, 80), "#1b1b1f")
    probe.draw_arrow(ImageDraw.Draw(canvas), 120)
    assert canvas.getbbox() is not None
    print("test_overlay_visuals_split: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
