# -*- coding: utf-8 -*-
"""One-shot CLI modes preserve startup order and existing result codes."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_cli_modes import (  # noqa: E402
    RuntimeCliModeDependencies,
    run_cli_mode,
)
from voice_feature.cli_options import build_argument_parser  # noqa: E402
from voice_feature.input_modes import input_mode_args  # noqa: E402


class Tracker:
    def __init__(self) -> None:
        self.hwnd = 0
        self.title = "not-ready"
        self.polls = 0

    def poll(self) -> None:
        self.polls += 1
        self.hwnd = 101
        self.title = "Codex"


class Transcriber:
    def __init__(self, *args) -> None:
        self.args = args

    def transcribe_file(self, path):
        return "文件里的话" if path == "ok.wav" else ""


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    parser = build_argument_parser(
        {"input_mode": "hold", "hold_key": "f9"}
    )
    parsed = parser.parse_args([])
    check(parsed.mode == "hold" and parsed.key == "f9",
          "无显式参数时命令行沿用按住说话模式与按键")
    check(input_mode_args({"input_mode": "hold", "hold_key": "space"})
          == ["--mode", "hold", "--key", "space"],
          "桌面重启、看门狗与更新器共享同一模式参数")

    with tempfile.TemporaryDirectory(prefix="findeck_cli_") as raw:
        root = Path(raw)
        calls = []
        tracker = Tracker()
        environment = {}

        def deps(*, paste=True, clipboard=True):
            return RuntimeCliModeDependencies(
                list_devices=lambda: calls.append("devices"),
                foreground_tracker_factory=lambda: tracker,
                find_window=lambda target: (
                    calls.append(("find", target)) or (202, "聊天")
                ),
                paste_into=lambda *args, **kwargs: (
                    calls.append(("paste", args, kwargs)) or paste
                ),
                transcriber_factory=lambda *args: (
                    calls.append(("transcriber", args)) or Transcriber(*args)
                ),
                append_log=lambda path, text: calls.append(
                    ("log", path, text)
                ),
                copy_to_clipboard=lambda text: (
                    calls.append(("clipboard", text)) or clipboard
                ),
                clock=iter([10.0, 11.25]).__next__,
                sleep=lambda seconds: calls.append(("sleep", seconds)),
                emit=calls.append,
                environ=environment,
            )

        result = run_cli_mode(
            SimpleNamespace(
                list_devices=True,
                test_paste=True,
                file=None,
                target=None,
            ),
            deps(),
        )
        check(result == 0 and calls == ["devices"],
              "设备列表模式只列设备并立即返回")
        check("HF_ENDPOINT" not in environment,
              "设备列表不会先触发模型镜像提示")

        calls.clear()
        result = run_cli_mode(
            SimpleNamespace(
                list_devices=False,
                test_paste=True,
                file=None,
                target="聊天",
            ),
            deps(paste=True),
        )
        check(result == 0
              and environment["HF_ENDPOINT"] == "https://hf-mirror.com",
              "粘贴测试在设备列表之后启用默认模型镜像")
        check(tracker.polls == 4
              and sum(1 for item in calls if item == ("sleep", 0.2)) == 4,
              "粘贴测试保留四次前台轮询和 0.2 秒间隔")
        check(("find", "聊天") in calls
              and any(item[0] == "paste" for item in calls
                      if isinstance(item, tuple)),
              "指定目标时仍查找真实窗口且不按回车")
        paste_call = next(
            item for item in calls
            if isinstance(item, tuple) and item[0] == "paste"
        )
        check(paste_call[2].get("press_enter") is False,
              "粘贴测试明确不发送")

        calls.clear()
        result = run_cli_mode(
            SimpleNamespace(
                list_devices=False,
                test_paste=True,
                file=None,
                target=None,
            ),
            deps(paste=False),
        )
        check(result == 1, "粘贴失败保持返回码 1")

        calls.clear()
        environment = {}
        result = run_cli_mode(
            SimpleNamespace(
                list_devices=False,
                test_paste=False,
                file="ok.wav",
                model="small",
                device="cpu",
                compute_type="int8",
                lang="zh",
                out=str(root / "transcripts.md"),
                no_clipboard=False,
            ),
            deps(clipboard=True),
        )
        check(result == 0
              and ("transcriber", ("small", "cpu", "int8", "zh")) in calls,
              "音频文件模式保留模型和设备参数")
        check(any(
            item[0] == "log"
            and item[2] == "[文件: ok.wav] 文件里的话"
            for item in calls
            if isinstance(item, tuple) and len(item) == 3
        ), "音频转写使用历史日志格式")
        check(("clipboard", "文件里的话") in calls,
              "转写成功仍复制到剪贴板")

        calls.clear()
        result = run_cli_mode(
            SimpleNamespace(
                list_devices=False,
                test_paste=False,
                file="empty.wav",
                model="small",
                device="cpu",
                compute_type="int8",
                lang="zh",
                out="out.md",
                no_clipboard=False,
            ),
            deps(),
        )
        check(result == 1 and "没识别到内容。" in calls,
              "空转写保持失败返回码且不写日志")

        calls.clear()
        environment = {}
        result = run_cli_mode(
            SimpleNamespace(
                list_devices=False,
                test_paste=False,
                file=None,
            ),
            deps(),
        )
        check(result is None and calls == [
            "（已默认使用 HF 镜像下载模型）"
        ], "未选择一次性模式时启完模型镜像后继续主语音流程")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    main_body = (
        APP / "voice_feature" / "runtime_application_entry.py"
    ).read_text(encoding="utf-8")
    pipeline = (
        APP / "voice_feature" / "runtime_entry_pipeline.py"
    ).read_text(encoding="utf-8")
    check("prepare_runtime_entry(" in main_body
          and "RuntimeCliModeDependencies(" in main_body
          and "run_cli_mode(startup.args, deps.cli)" in pipeline
          and "run_runtime_application(" in stt,
          "入口管线只调用一次性模式装配")
    check("transcribe_file(args.file)" not in main_body
          and "tracker.poll()" not in main_body,
          "日志格式、粘贴轮询和文件转写不再内联主流程")
    check("HF_ENDPOINT" not in main_body,
          "模型镜像环境变量交给入口模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
