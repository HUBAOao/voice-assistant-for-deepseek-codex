# -*- coding: utf-8 -*-
"""验收「下载页」：一个网址，电脑端和手机端都能下，还带更新信息。

两条路都要能用：
  * 在线：助手跑着的时候 /dl 能打开（**不要令牌**），两个安装包都下得下来
  * 离线：make_package 生成的「下载页」文件夹，相对路径，直接传上网盘就能用
另外盯一件事：页面里的版本号和更新日志必须是从 version.py 现算的
（以后更新了不用手工同步）。
"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(module: str, path: Path):
    spec = importlib.util.spec_from_file_location(module, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import download_page as dp
    import version

    print("① 页面内容：两个包 + 版本号 + 更新信息")
    d = dp.info()
    html = dp.build_html()
    check(d["apk"] is not None, f"找得到手机端 APK（{d['apk_size']}）")
    check(d["zip"] is not None, f"找得到电脑端安装包（{d['zip_size']}）")
    check(version.APP_VERSION in html and version.PHONE_VERSION in html,
          f"页面上写着电脑端 v{version.APP_VERSION} / 手机端 v{version.PHONE_VERSION}")
    check("app.apk" in html and "pc.zip" in html, "两个下载按钮都在")
    # 页面里会把版本记录里的 **加粗** 记号去掉，比的时候也得先去掉
    check(version.CHANGELOG[-1].replace("**", "")[:12] in html,
          "更新日志里有最新那条改动（现算的）")
    check("第三步" in html or "怎么用" in html, "有安装说明")

    print("② 版本信息是现算的（以后更新自己同步）")
    old = list(version.CHANGELOG)
    version.CHANGELOG.append("测试加的一条更新：随便写点什么")
    try:
        h2 = dp.build_html()
        check("测试加的一条更新" in h2 and f"1.{len(old) + 1}" in h2,
              "往 version.py 里加一条，页面立刻跟着变（不用手工改网页）")
    finally:
        version.CHANGELOG[:] = old

    print("③ 在线那条路：/dl 不用令牌就能开")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8811)
    check(link.start(), "手机入口起来了")
    try:
        time.sleep(0.2)
        base = "http://127.0.0.1:8811"
        with urllib.request.urlopen(base + "/dl", timeout=10) as r:
            page = r.read().decode("utf-8", "replace")
        check(r.status == 200 and "下载" in page, "不带令牌也能打开 /dl")
        for path, head, what in (("/dl/app.apk", b"PK", "手机端 APK"),
                                 ("/dl/pc.zip", b"PK", "电脑端安装包"),
                                 ("/dl/qr.png", b"\x89PNG", "二维码")):
            with urllib.request.urlopen(base + path, timeout=60) as r:
                body = r.read()
            check(body[:len(head)] == head and len(body) > 800,
                  f"{what} 下得下来（{len(body) / 1024:.0f} KB）")
        # 下载页不该泄漏控制入口
        with urllib.request.urlopen(base + "/dl", timeout=10) as r:
            page = r.read().decode("utf-8", "replace")
        check(link.token not in page, "下载页里没有令牌（不能拿它去控制电脑）")
        check("/api/cmd" not in page, "下载页上也没有控制接口")
    finally:
        link.stop()

    print("④ 离线那条路：生成的「下载页」文件夹")
    site = ROOT / "outputs" / "下载页"
    if site.is_dir():
        names = {p.name for p in site.glob("*")}
        check("index.html" in names, "有 index.html")
        check("app.apk" in names, "里面有手机端 APK")
        check("pc.zip" in names, "里面有电脑端安装包")
        idx = (site / "index.html").read_text(encoding="utf-8")
        check('href="app.apk"' in idx and 'href="pc.zip"' in idx,
              "页面里用的是相对路径（整套搬到哪儿都能用）")
        check(any("怎么让所有人" in n for n in names), "附了一份「怎么让所有人都能下载」的说明")
        check("version.json" in names, "更新清单也在里面（两边 APP 都能读）")
        # 发给外人的这一版不该出现"你自己电脑的 IP"这种话
        # 注意：更新日志里会出现"电脑的IP"这类词（那是在讲这次改了什么），
        # 所以要盯的是**页面自己的说明**里有没有那句局域网提示。
        check("这个下载页就在电脑自己的网址下" not in idx,
              "对外那一版页面里没有「http://电脑的IP」那句局域网说明")
    else:
        check(False, "还没有生成「下载页」文件夹（先跑一次 make_package.py）")

    print("⑤ 单文件版：一个 html 装下两个安装包，双击就能下")
    one = ROOT / "outputs" / "下载页-单文件.html"
    check(one.exists(), f"单文件在（{one.stat().st_size / 1024 / 1024:.1f} MB）"
          if one.exists() else "单文件没生成")
    if one.exists():
        txt = one.read_text(encoding="utf-8")
        check("B64_PC" in txt and "B64_APK" in txt, "两个包都以 base64 嵌在文件里")
        check(len(txt) > 3_000_000, "文件确实把包装进去了（不是空壳）")
        check('id="grab-apk"' in txt and "createObjectURL" in txt,
              "点按钮从文件内部取出并下载（不需要联网、不需要服务器）")
        check("href=\"app.apk\"" not in txt, "不再依赖外部文件（真正独立）")
        check("</html>" in txt, "是个完整页面")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
