# -*- coding: utf-8 -*-
"""验收「下载页」：一个网址，电脑端和手机端都能下，还带更新信息。

两条路都要能用：
  * 在线：助手跑着的时候 /dl 能打开（**不要令牌**），两个安装包都下得下来
  * 离线：make_package 生成的「下载页」文件夹，相对路径，直接传上网盘就能用
另外盯一件事：页面里的版本号和更新日志必须是从 version.py 现算的
（以后更新了不用手工同步）。
"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(module: str, path: Path):
    spec = importlib.util.spec_from_file_location(module, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[module] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import download_page as dp
    import version

    print("① 页面内容：两个包 + 版本号 + 更新信息")
    d = dp.info()
    html = dp.build_html()
    check(d["apk"] is not None, f"找得到手机端 APK（{d['apk_size']}）")
    check(d["zip"] is not None, f"找得到电脑端安装包（{d['zip_size']}）")
    check(version.APP_VERSION in html and version.PHONE_VERSION in html,
          f"页面上写着电脑端 v{version.APP_VERSION} / 手机端 v{version.PHONE_VERSION}")
    check("app.apk" in html and "pc.zip" in html, "两个下载按钮都在")
    # 页面里会把版本记录里的 **加粗** 记号去掉，比的时候也得先去掉
    check(version.CHANGELOG[-1].replace("**", "")[:12] in html,
          "更新日志里有最新那条改动（现算的）")
    check("第三步" in html or "怎么用" in html, "有安装说明")

    print("② 版本信息是现算的（以后更新自己同步）")
    old = list(version.CHANGELOG)
    version.CHANGELOG.append("测试加的一条更新：随便写点什么")
    try:
        h2 = dp.build_html()
        check("测试加的一条更新" in h2 and f"1.{len(old) + 1}" in h2,
              "往 version.py 里加一条，页面立刻跟着变（不用手工改网页）")
    finally:
        version.CHANGELOG[:] = old

    print("③ 本机不再挂下载页（用户要求只留 GitHub 网址）")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8811)
    check(link.start(), "手机入口起来了")
    try:
        time.sleep(0.2)
        for path in ("/dl", "/dl/app.apk", "/dl/pc.zip", "/dl/version.json"):
            try:
                urllib.request.urlopen("http://127.0.0.1:8811" + path, timeout=8)
                check(False, f"{path} 居然还能开（应该已经拆掉了）")
            except Exception:
                check(True, f"{path} 已经拆掉了（打不开）")
    finally:
        link.stop()

    print("④ 发布用的网站文件夹（F 盘「网站」，也是个 git 仓库）")
    site = Path(r"F:/语音助手/网站")
    if site.is_dir():
        names = {p.name for p in site.glob("*")}
        check("index.html" in names, "有 index.html")
        check("app.apk" in names, "里面有手机端 APK")
        check("pc.zip" in names, "里面有电脑端安装包")
        check("version.json" in names, "更新清单也在里面（两边 APP 都读它）")
        check((site / ".git").is_dir(), "是个 git 仓库（打包时会自动推上去）")
        check((site / ".github" / "workflows" / "release.yml").is_file(),
              "里面带着自动建 Release 的 Actions")
        idx = (site / "index.html").read_text(encoding="utf-8")
        check('href="app.apk"' in idx and 'href="pc.zip"' in idx,
              "页面用的是相对路径（GitHub Pages 上才对得上）")
        check("这个下载页就在电脑自己的网址下" not in idx,
              "页面上没有那句局域网说明")
    else:
        check(False, "F 盘「网站」文件夹不在（先跑一次 make_package.py）")

    print("⑤ 本地那几样已经清掉了")
    check(not (ROOT / "outputs" / "下载页").exists(), "outputs\\下载页 没了")
    check(not (ROOT / "outputs" / "下载页-单文件.html").exists(), "单文件版没了")
    check(not (APP / "stats.py").exists(), "下载量统计（stats.py）没了")
    check(not (APP / "download-stats.json").exists(), "下载量数据文件没了")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
