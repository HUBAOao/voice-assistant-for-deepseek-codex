# -*- coding: utf-8 -*-
"""Verify that the real TTS reference waveform reaches the AEC stage."""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from features.voice_echo import ReferenceEchoGate  # noqa: E402


def delayed_echo_regression() -> None:
    """A 90 ms device delay must still be cancelled before barge-in sees it."""
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        rng = np.random.default_rng(17)
        sample_rate = 48000
        reference = rng.normal(0, 0.08, sample_rate).astype(np.float32)
        delay = int(sample_rate * 0.09)
        echo = np.zeros(reference.size, dtype=np.float32)
        echo[delay:] = reference[:-delay] * 0.55
        microphone = (
            echo + rng.normal(0, 0.0015, reference.size)
        ).astype(np.float32)
        np.save(base / "ref.npy", reference, allow_pickle=False)
        gate = ReferenceEchoGate(base / "ref.npy", base / "ref.json")
        cleaned: list[np.ndarray] = []
        for offset in range(0, 12000, 1024):
            (base / "ref.json").write_text(
                json.dumps({
                    "active": True,
                    "rate": sample_rate,
                    "samples": reference.size,
                    "offset": offset,
                    "ts": time.time(),
                    "text": "延迟回声测试",
                }),
                encoding="utf-8",
            )
            cleaned.append(
                gate.process(microphone[offset : offset + 1024], sample_rate)
            )
        before = float(np.sqrt(np.mean(microphone[: len(cleaned) * 1024] ** 2)))
        after_audio = np.concatenate(cleaned)
        after = float(np.sqrt(np.mean(after_audio ** 2)))
        assert gate.last_used
        assert abs(gate.last_delay_samples) >= int(sample_rate * 0.08)
        assert after < before * 0.4, (before, after)


def unrelated_speech_is_kept() -> None:
    """Alignment searching must not swallow speech unrelated to playback."""
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        rng = np.random.default_rng(23)
        sample_rate = 48000
        reference = rng.normal(0, 0.08, sample_rate).astype(np.float32)
        microphone = rng.normal(0, 0.08, 4096).astype(np.float32)
        np.save(base / "ref.npy", reference, allow_pickle=False)
        (base / "ref.json").write_text(
            json.dumps({
                "active": True,
                "rate": sample_rate,
                "samples": reference.size,
                "offset": 0,
                "ts": time.time(),
                "text": "无关语音测试",
            }),
            encoding="utf-8",
        )
        gate = ReferenceEchoGate(base / "ref.npy", base / "ref.json")
        cleaned = gate.process(microphone, sample_rate)
        before = float(np.sqrt(np.mean(microphone ** 2)))
        after = float(np.sqrt(np.mean(cleaned ** 2)))
        assert after > before * 0.9, (before, after)


def confidence_gate_distinguishes_echo_from_user() -> None:
    """Residual echo may stay above the barge threshold without being a user."""
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        gate = ReferenceEchoGate(base / "ref.npy", base / "ref.json")
        gate.last_used = True
        gate.last_correlation = 0.73
        gate.last_ratio = 0.53
        assert gate.echo_dominates()
        gate.last_ratio = 0.82
        assert not gate.echo_dominates()
        gate.last_ratio = 0.53
        gate.last_correlation = 0.31
        assert not gate.echo_dominates()


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        rng = np.random.default_rng(11)
        sample_rate = 16000
        reference = rng.normal(0, 0.08, sample_rate).astype(np.float32)
        echo = np.convolve(reference, [0.45, -0.17, 0.08], mode="full")[:reference.size]
        microphone = (echo + rng.normal(0, 0.001, reference.size)).astype(np.float32)
        np.save(base / "ref.npy", reference, allow_pickle=False)
        (base / "ref.json").write_text(json.dumps({
            "active": True,
            "rate": sample_rate,
            "samples": reference.size,
            "offset": 0,
            "ts": time.time(),
            "text": "测试参考音频",
        }), encoding="utf-8")
        gate = ReferenceEchoGate(base / "ref.npy", base / "ref.json")
        cleaned = gate.process(microphone, sample_rate)
        before = float(np.sqrt(np.mean(microphone ** 2)))
        after = float(np.sqrt(np.mean(cleaned ** 2)))
        assert gate.last_used
        assert after < before * 0.75, (before, after)
        print(f"test_voice_reference_echo: PASS ({before:.4f} -> {after:.4f})")
    delayed_echo_regression()
    unrelated_speech_is_kept()
    confidence_gate_distinguishes_echo_from_user()
    print("test_voice_reference_echo delayed echo: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
