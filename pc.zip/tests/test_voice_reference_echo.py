# -*- coding: utf-8 -*-
"""Verify that the real TTS reference waveform reaches the AEC stage."""
from __future__ import annotations

import json
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from features.voice_echo import ReferenceEchoGate  # noqa: E402


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        rng = np.random.default_rng(11)
        sample_rate = 16000
        reference = rng.normal(0, 0.08, sample_rate).astype(np.float32)
        echo = np.convolve(reference, [0.45, -0.17, 0.08], mode="full")[:reference.size]
        microphone = (echo + rng.normal(0, 0.001, reference.size)).astype(np.float32)
        np.save(base / "ref.npy", reference, allow_pickle=False)
        (base / "ref.json").write_text(json.dumps({
            "active": True,
            "rate": sample_rate,
            "samples": reference.size,
            "offset": 0,
            "ts": time.time(),
            "text": "测试参考音频",
        }), encoding="utf-8")
        gate = ReferenceEchoGate(base / "ref.npy", base / "ref.json")
        cleaned = gate.process(microphone, sample_rate)
        before = float(np.sqrt(np.mean(microphone ** 2)))
        after = float(np.sqrt(np.mean(cleaned ** 2)))
        assert gate.last_used
        assert after < before * 0.75, (before, after)
        print(f"test_voice_reference_echo: PASS ({before:.4f} -> {after:.4f})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
