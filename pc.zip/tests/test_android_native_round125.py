# -*- coding: utf-8 -*-
"""Round 125 native file page container and row parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
MEDIA_JS = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "media.js"
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    media = MEDIA_JS.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    render_start = activity.index("private void renderFiles(")
    render_end = activity.index("private void addRemoteFile(", render_start)
    files = activity[render_start:render_end]
    remote_start = activity.index("private void addRemoteFile(")
    remote_end = activity.index("private void addAudioFile(", remote_start)
    remote = activity[remote_start:remote_end]
    audio_start = activity.index("private void addAudioFile(")
    audio_end = activity.index("private void stopFilePlayer(", audio_start)
    audio = activity[audio_start:audio_end]

    print("① 旧文件页最终规格")
    check(
        "#files { margin:0 12px 8px; border:1px solid var(--line);"
        in page
        and "border-radius:12px; overflow:hidden;" in page,
        "文件页是单个 12px 圆角、1px 边框容器",
    )
    check(
        "#files .head { display:flex; align-items:center; gap:8px;"
        in page
        and "padding:8px 10px; background:var(--panel);" in page,
        "文件面板头为 PANEL 底和 8/10px 内边距",
    )
    check(
        "#files .body { display:none; padding:8px 10px 10px;"
        in page
        and "background:#1f1f24;" in page,
        "文件正文区为 #1f1f24 和 8/10/10px 内边距",
    )
    check(
        "#files .f {" in page
        and "padding:7px 0; font-size:13px;" in page
        and "border-bottom:1px solid var(--line);" in page
        and "#files .f:last-child { border-bottom:0; }" in page,
        "文件行是 13px、7px 纵向内边距和连续 1px 分隔线",
    )
    check(
        'row.className = "f";' in media
        and 'a.textContent = "📄 " + it.name;' in media,
        "旧 media.js 用连续 .f 行渲染电脑文件",
    )

    print("\n② 原生文件页层级")
    check(
        "filesContainer" in files
        and "filesPanelHeader" in files
        and "filesBody" in files,
        "原生建立单一 filesContainer、面板头和正文区",
    )
    check(
        "new GradientDrawable()" in files
        and "fileContainerBackground.setStroke(" in files
        and "NativeTheme.dp(this, 1), NativeTheme.LINE" in files
        and "setCornerRadius(NativeTheme.dp(this, 12))" in files,
        "原生文件容器恢复 1px 边框和 12px 圆角",
    )
    check(
        "filesPanelHeader.setPadding(NativeTheme.dp(this, 10), NativeTheme.dp(this, 8),"
        in files
        and "NativeTheme.PANEL" in files,
        "原生面板头恢复 PANEL 底和 10/8px 内边距",
    )
    check(
        "filesBody.setPadding(NativeTheme.dp(this, 10), NativeTheme.dp(this, 8),"
        in files
        and "Color.rgb(31, 31, 36)" in files,
        "原生正文区恢复 #1f1f24 和 10/8/10px 内边距",
    )
    check(
        "NativeTheme.card(this)" not in remote
        and "fileRow(" in remote
        and "NativeTheme.dp(this, 7)" in remote
        and "NativeTheme.LINE" in remote,
        "电脑文件改为 7px 连续分隔行，不再是独立圆角卡",
    )
    check(
        "audioFileCard(" in audio
        and "NativeTheme.PANEL, 11, this" in activity,
        "试听文件保留旧页的内部 11px 音频卡样式",
    )

    spec = importlib.util.spec_from_file_location(
        "round125_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any(
            "文件页单容器" in item
            for item in version.PHONE_CHANGELOG
        ),
        f"手机端 v{version.PHONE_VERSION} 变更表记录文件页收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"fileRow" in dex
            and b"uploadFileDirect" in dex
            and "跟电脑要文件：输入文件名，如 报表.xlsx".encode("utf-8") in dex,
            "APK/DEX 包含文件单容器、面板头和连续文件行",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
