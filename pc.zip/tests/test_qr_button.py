# -*- coding: utf-8 -*-
"""验收悬浮窗上那个「二维码」按钮：点一下要弹出码，而且手机真能扫出来。

扫得出来这件事不靠嘴说 —— 直接用手机端 APP 用的那个码库（ZXing）把那颗码读一遍，
读出来的东西必须跟手机入口网址一模一样。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "qr-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402
import qr_tools  # noqa: E402
from overlay_feature.defaults import DEFAULTS  # noqa: E402
from _overlay_test_support import isolate_overlay  # noqa: E402

JAVA = Path(r"F:\android-dev\jdk-17\bin\java.exe")
ZXING = Path(r"F:\android-dev\zxing-core-3.5.3.jar")
CLASSES = ROOT / "work" / "qrcheck"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    cfg = dict(DEFAULTS)
    cfg.update({"overlay_bg_image": "", "overlay_alpha": 1.0, "auto_tune": False,
                "snap_edges": False, "phone_enabled": True})
    paths = isolate_overlay(overlay, S, cfg, app_dir=APP)

    print("① 画码那个小库在不在")
    check(qr_tools.available(), "qrcode 库在（requirements.txt 里也加上了）")

    o = overlay.Overlay()
    o.alpha_override = 1.0
    for _ in range(30):
        o.root.update()
        time.sleep(0.005)
    o.cfg["phone_port"] = 8765

    def walk(w):
        for c in w.winfo_children():
            yield c
            yield from walk(c)

    print("①b 「智能」页里真的有那个按钮")
    o.set_expanded(True)            # 设置面板是懒建的，先把它展开
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)
    page = o.tab_frames["智能"]
    chips = [w for w in walk(page)
             if isinstance(w, o.tk.Label) and str(w.cget("text")) == "二维码"]
    check(len(chips) == 2, f"本机和外网各有一个「二维码」按钮（找到 {len(chips)} 个）")
    check(any(isinstance(w, o.tk.Label) and str(w.cget("text")).startswith("复制")
              for w in walk(page)), "它就在「复制」旁边（手机网址那一行）")

    print("② 打开本机手机入口二维码")
    o.show_qr()
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)
    win = getattr(o, "qr_win", None)
    check(win is not None and bool(win.winfo_exists()), "弹出了一个二维码小窗")
    url = getattr(o, "qr_url", "")
    check(url.startswith("http://") and "?k=" in url,
          f"码里装的是手机入口网址（{url[:34]}…）")
    photo = getattr(o, "qr_photo", None)
    check(photo is not None and photo.width() >= 180,
          f"码画出来了，{photo.width()}x{photo.height()} 像素" if photo else "没画出来")

    print("③ 让手机端的码库（ZXing）真扫一遍")
    shot = ROOT / "work" / "qr-shown.png"
    if photo is not None:
        from PIL import ImageTk

        ImageTk.getimage(photo).convert("RGB").save(shot)
        check(shot.exists() and shot.stat().st_size > 800,
              f"把窗口里那张码存下来（{shot.stat().st_size} 字节）")
        cp = f"{CLASSES};{ZXING}"
        got = subprocess.run([str(JAVA), "-cp", cp, "DecodeQr", str(shot)],
                             capture_output=True, text=True, timeout=90)
        decoded = (got.stdout or "").strip()
        check(decoded == url, f"扫出来 == 网址（扫到：{decoded[:44]}…）" if decoded else
              f"扫不出来：{got.stderr[:200]}")
    else:
        check(False, "没有图可扫")

    print("④ 另存为图片那条路也能出图")
    saved = S / "另存.png"
    qr_tools.qr_image(url, box=10, border=4).save(saved)
    got = subprocess.run([str(JAVA), "-cp", f"{CLASSES};{ZXING}", "DecodeQr", str(saved)],
                         capture_output=True, text=True, timeout=90)
    check((got.stdout or "").strip() == url, "存成 10 倍像素的图，照样扫得出来")

    print("⑤ 换端口 / 换 IP，码要跟着变")
    o.cfg["phone_port"] = 8888
    o.show_qr()
    for _ in range(20):
        o.root.update()
        time.sleep(0.01)
    check(":8888" in getattr(o, "qr_url", ""),
          f"改了端口，重开就是新地址（{getattr(o, 'qr_url', '')[:34]}…）")
    o.show_qr()
    for _ in range(20):
        o.root.update()
        time.sleep(0.01)
    wins = [
        w for w in o.root.winfo_children()
        if isinstance(w, o.tk.Toplevel)
        and w is not o.panel_win
        and w.winfo_exists()
    ]
    check(len(wins) == 1, f"连点两次只留一个二维码小窗（现在 {len(wins)} 个）")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
