# -*- coding: utf-8 -*-
"""Talk-mode capture side effects stay injectable and testable."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.talk_capture import (  # noqa: E402
    TalkCaptureDependencies,
    capture_talk_utterance,
)


class Status:
    def __init__(self) -> None:
        self.calls: list[tuple[tuple, dict]] = []

    def set(self, *args, **kwargs) -> None:
        self.calls.append((args, kwargs))

    def level(self, *args, **kwargs) -> None:
        self.calls.append((args, kwargs))


class Recorder:
    def __init__(self, cuts: list[bool]) -> None:
        self.cuts = list(cuts)
        self.last_cut = False
        self.reads = 0

    def _read(self) -> np.ndarray:
        self.reads += 1
        return np.zeros(1024, dtype=np.float32)


class Transcriber:
    def transcribe(self, _audio) -> str:
        return "半句"


def deps(
    recorder: Recorder,
    status: Status,
    *,
    paused: bool = False,
    speaking: bool = False,
    wake: bool = True,
    records: list[np.ndarray] | None = None,
    events: list[tuple] | None = None,
) -> TalkCaptureDependencies:
    events = events if events is not None else []
    records = list(records or [np.ones(16000, dtype=np.float32)])

    def safe_record(*_args, **_kwargs):
        if records:
            audio = records.pop(0)
            recorder.last_cut = recorder.cuts.pop(0) if recorder.cuts else False
            return audio
        return None

    class Duplex:
        def audio_frame(self, _level):
            return "barge"

    return TalkCaptureDependencies(
        recorder=recorder,
        rate=16000,
        cfg={"caption_enabled": False},
        self_speech={"on": False},
        music={"on": False},
        spoken_flag={"first": False},
        status=status,
        syslog=lambda tag, text: events.append(("log", tag, text)),
        shut_up=lambda: events.append(("shut_up",)),
        speaking_now=lambda: speaking,
        duplex=Duplex(),
        cancel_reference_echo=lambda audio, _rate: audio,
        spectrum_bands=lambda _audio, _rate: [0.2],
        transcriber=Transcriber(),
        safe_calibrate=lambda: 0.02,
        safe_record=safe_record,
        checked_pause=lambda: paused,
        on_speech=lambda: events.append(("speech",)),
        hint="测试提示",
        wake_enabled=wake,
    )


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    status = Status()
    recorder = Recorder([])
    audio = capture_talk_utterance(
        deps(recorder, status, paused=True)
    )
    check(audio is None and recorder.reads == 1, "暂停时只读一帧保持缓冲")

    status = Status()
    recorder = Recorder([])
    audio = capture_talk_utterance(
        deps(recorder, status, speaking=True, records=[
            np.ones(16000, dtype=np.float32),
        ])
    )
    check(audio is not None and status.calls[0][0][0] == "idle",
          "talk 模式有声纹唤醒时进入待唤醒状态")
    check(any("hint" in kwargs for _args, kwargs in status.calls),
          "采集层通过注入状态对象设置提示")

    status = Status()
    recorder = Recorder([True, False])
    parts = [
        np.ones(16000, dtype=np.float32),
        np.full(16000, 2.0, dtype=np.float32),
        np.full(16000, 3.0, dtype=np.float32),
    ]
    audio = capture_talk_utterance(
        deps(recorder, status, records=parts)
    )
    check(audio is not None and audio.size == 32000,
          "被 120 秒规则允许的长句会拼接到下一次正常断句")
    check(float(audio[-1]) == 2.0,
          "长句续录不混入第三段")

    status = Status()
    recorder = Recorder([])
    events: list[tuple] = []
    audio = capture_talk_utterance(
        deps(
            recorder,
            status,
            wake=False,
            events=events,
            records=[None],
        )
    )
    check(audio is None, "过短或空录音不进入识别")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    module = (APP / "voice_feature" / "talk_capture.py").read_text(
        encoding="utf-8"
    )
    check("capture_talk_utterance(" in stt,
          "主循环调用独立采集会话")
    check("def show_partial" not in stt and "def show_partial" in module,
          "实时字幕及插话副作用迁出主循环")
    check("continue_long_capture(" not in stt
          and "continue_long_capture(" in module,
          "长句续录判定不再留在 stt.py")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
