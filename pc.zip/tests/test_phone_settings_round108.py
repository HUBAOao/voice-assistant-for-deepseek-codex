# -*- coding: utf-8 -*-
"""Round 108 native settings-page lifecycle, validation and save contracts."""
from __future__ import annotations

import subprocess
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))
import version as app_version  # noqa: E402

ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, label: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + label)
        bad += 0 if condition else 1

    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    settings_js = (APP / "phone_feature" / "ui" / "settings.js").read_text(
        encoding="utf-8"
    )
    runtime = (APP / "phone_feature" / "ui" / "page_runtime.js").read_text(
        encoding="utf-8"
    )
    core = (APP / "phone_feature" / "ui" / "page_core.js").read_text(
        encoding="utf-8"
    )
    activity = (
        JAVA / "NativeFinDeckActivity.java"
    ).read_text(encoding="utf-8")
    version = (APP / "version.py").read_text(encoding="utf-8")

    settings_source = activity.split(
        "private void showSettings(String initialCategory)", 1
    )[-1].split("private LinearLayout settingsAccordion(", 1)[0]
    appearance = activity.split(
        "private void populateNativeAppearance(", 1
    )[-1].split("private void applyNativeBackground(", 1)[0]
    connection = activity.split(
        "private void populateNativeConnection(", 1
    )[-1].split("private void loadNativeConnectionInfo(", 1)[0]
    security = activity.split(
        "private void addNativeSecurityControls(", 1
    )[-1].split("private void loadSecurityControls(", 1)[0]
    load_security = activity.split(
        "private void loadSecurityControls(", 1
    )[-1].split("private void setTaggedEdit(", 1)[0]
    post_security = activity.split(
        "private void postSecurity(", 1
    )[-1].split("private Dialog showNativeDialog(", 1)[0]
    about = activity.split(
        "private void loadNativeAbout(", 1
    )[-1].split("private boolean setNotificationDone(", 1)[0]
    notification = activity.split(
        "private boolean setNotificationDone(", 1
    )[-1].split("private void copyText(", 1)[0]
    pet = activity.split(
        "private boolean setPetEnabled(", 1
    )[-1].split("private void updateThinkingBandForPlus(", 1)[0]
    pause = activity.split("protected void onPause()", 1)[1].split(
        "public void onBackPressed()", 1
    )[0]
    destroy = activity.split("protected void onDestroy()", 1)[1].split(
        "private static final class MaxHeightScrollView", 1
    )[0]

    check(
        all(f'data-cat="{name}"' in page for name in (
            "basic", "appearance", "connection", "pet", "about"
        ))
        and all(token in settings_source for token in (
            '"基础"', '"外观"', '"连接与通知"', '"桌宠"', '"关于"'
        ))
        and "settingsAccordionAnimations" in activity,
        "旧页与原生页都保留基础、外观、连接与通知、桌宠、关于五类抽屉",
    )
    check(
        "name.addTextChangedListener" in settings_source
        and '"名字已即时保存"' in settings_source
        and '"名字保存失败，请重试"' in settings_source
        and "desktopDisplayName" in settings_source
        and "setOnFocusChangeListener" in settings_source,
        "手机名字即时刷新，按实际保存结果显示反馈并恢复电脑名称占位",
    )
    check(
        "resolveNativeUpdate" in activity
        and 'updateBase + "/version.json"' in activity
        and 'api.get("/api/version")' in activity
        and '"有新版 v"' in activity
        and '"已经是最新（v"' in activity
        and '"检查更新失败：连不上电脑？"' in activity,
        "基础页更新检查继续优先公网清单、失败回退电脑并区分三种状态",
    )
    check(
        all(token in appearance for token in (
            '"壁纸透明度"', '"聊天色块透明度"', '"聊天色块模糊"',
            '"顶栏透明度"', '"顶栏模糊"', '"底栏透明度"', '"底栏模糊"',
        ))
        and '"http".equals(scheme)' in appearance
        and '"https".equals(scheme)' in appearance
        and "网址无效" in appearance
        and "图片网址已保存并即时应用" in appearance,
        "外观七个滑杆保持即时保存，壁纸网址校验 http(s) 后再写入外观",
    )
    check(
        "loadNativeConnectionInfo(" in connection
        and "重试连接信息" in connection
        and '"连不上电脑：' in activity
        and "background 电池设置" not in connection
        and '"电池优化"' in connection
        and '"系统通知设置"' in connection
        and "openBatterySettings();" in connection
        and "openNotificationSettings();" in connection,
        "连接信息有断线错误与原地重试，电池和通知系统入口均保留",
    )
    check(
        "settingsPageCurrent(dialog, generation, state)" in activity
        and "remote.setTag(remoteUrl);" in activity
        and "外网地址未启用" in activity
        and '"连接正常"' in activity,
        "外网状态区分连接正常、未启用和断线，旧抽屉关闭后的响应不会写回",
    )
    check(
        "startForegroundService(service);" in notification
        and "prefs.edit().putBoolean(\"notify_done\", enabled).apply();"
        in notification
        and "prefs.edit().putBoolean(\"notify_done\", previous).apply();"
        in notification
        and "NotifyService.isRunning()" in notification
        and "开启失败：通知服务没有启动" in notification,
        "通知开关只在启动成功后写入，并按服务实际状态纠正失败现场",
    )
    check(
        "Settings.canDrawOverlays" in pet
        and "ACTION_MANAGE_OVERLAY_PERMISSION" in pet
        and "prefs.edit().putBoolean(\"pet_on\", enabled).apply();" in pet
        and "prefs.edit().putBoolean(\"pet_on\", previous).apply();" in pet
        and "开启失败：桌宠服务没有启动" in activity,
        "桌宠先检查悬浮窗权限，服务和持久状态失败时都恢复实际结果",
    )
    check(
        "securityNumber(" in security
        and "readBoundedSecurityNumber(" in security
        and ' 1, 3650' in security
        and ' 20, 5000' in security
        and ' 1, 1440' in security
        and ' 1, 50' in security
        and "setSecurityNotice(" in security,
        "保留与跨设备策略按旧页上下限校验，非法输入不提交",
    )
    check(
        'action.put("capability_ttl_seconds", ttlMinutes * 60);' in security
        and '"跨设备策略已保存", true,' in security
        and "api.invalidateCapability();" in post_security
        and "loadSecurityControls(" in post_security,
        "跨设备策略保存后失效旧能力凭据，并从服务端重读权威状态",
    )
    check(
        "securityActionInFlight" in post_security
        and "上一项安全操作还没结束" in post_security
        and "securityLoadGeneration" in load_security
        and "settingsPageCurrent(" in load_security
        and "dialog, settingsToken, panel" in load_security
        and "focused instanceof EditText" in load_security
        and "if (!editing)" in load_security
        and "重试读取安全状态" in security,
        "安全读写有重复提交锁、加载代际、断线重试且不覆盖正在编辑的数值",
    )
    check(
        "showDangerConfirm(" in security
        and '"吊销全部设备？"' in security
        and 'action.put("rotate_key", true);' in security
        and '恢复操作密钥？' in activity
        and "!passphrase.equals(repeated)" in activity
        and "api.invalidateCapability();" in activity,
        "轮换、当前/全部设备吊销和恢复包恢复继续要求危险确认",
    )
    check(
        "settingsPageCurrent(dialog, generation, view)" in about
        and "重试读取关于" in settings_source
        and '"作者："' in about
        and "读取失败：" in about,
        "关于页加载作者与版权，断线保留原因和原地重试且不写回旧抽屉",
    )
    check(
        "settingsDialog = dialog;" in settings_source
        and "settingsGeneration++;" in settings_source
        and "nativeUpdateCheckGeneration++;" in settings_source
        and "securityLoadGeneration++;" in settings_source
        and "settleSettingsAccordionAnimations();" in settings_source,
        "关闭设置时作废更新、安全和折叠动画，快速重开不复活旧现场",
    )
    check(
        "isSettingsKeyboardVisible(panel)" in settings_source
        and "hideSettingsKeyboard(panel);" in settings_source
        and "nativeModalDepth == 0" in settings_source
        and "event.getAction() == KeyEvent.ACTION_UP" in settings_source,
        "输入法可见时第一次返回只收键盘，危险子层优先于设置抽屉",
    )
    check(
        "settingsGeneration++;" in destroy
        and "securityLoadGeneration++;" in destroy
        and "settingsDialog = null;" in destroy
        and "settleSettingsAccordionAnimations();" in destroy,
        "Activity 销毁使设置页全部异步请求失效并收敛折叠动画",
    )
    check(
        'id="settingsCats"' in page
        and "loadSecurity();" in settings_js
        and "retentionDays" in runtime
        and 'id="wallalpha"' in page
        and 'id="chatAlpha"' in page
        and 'id="topAlpha"' in page
        and 'id="bottomAlpha"' in page
        and "look.chatBlur" in core,
        "旧 phone_page/settings/page_runtime/page_core 仍是设置页唯一规格",
    )
    check(
        "鳍舱第一百零八轮原生设置整页收口" in version
        and "PHONE_CHANGELOG" in version
        and 'PHONE_VERSION = f"1.{len(PHONE_CHANGELOG)}"' in version,
        "手机端版本表新增第一百零八轮并继续由 PHONE_CHANGELOG 计算",
    )

    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    with zipfile.ZipFile(apk) as archive:
        dex = archive.read("classes.dex")
    check(
        b"settingsPageCurrent" in dex
        and b"securityActionInFlight" in dex
        and b"confirmNotificationSwitch" in dex
        and b"setPetEnabled" in dex
        and b"readBoundedSecurityNumber" in dex,
        "最终 APK 含设置页代际、安全锁、通知实测反馈、桌宠权限和数值校验",
    )
    aapt2 = Path(r"F:\android-dev\sdk\build-tools\34.0.0\aapt2.exe")
    manifest_dump = subprocess.run(
        [str(aapt2), "dump", "xmltree", str(apk),
         "--file", "AndroidManifest.xml"],
        check=True, capture_output=True, text=True, encoding="utf-8",
    ).stdout
    check(
        f'versionName(0x0101021c)="{app_version.PHONE_VERSION}"'
        in manifest_dump
        and "versionCode(0x0101021b)="
        f"{1000 + len(app_version.PHONE_CHANGELOG)}" in manifest_dump,
        "最终 APK 版本与当前手机版本表一致",
    )

    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
