# -*- coding: utf-8 -*-
"""Tests for rotating application-layer operation capabilities."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        os.environ["FIN_DECK_SECURITY_KEY"] = str(base / "key.bin")
        os.environ["FIN_DECK_SECURITY_POLICY"] = str(base / "policy.json")
        os.environ["FIN_DECK_SECURITY_META"] = str(base / "meta.json")
        from features.app_security import AppSecurity

        security = AppSecurity()
        issued = security.issue(device_id="phone-test", device_epoch=7)
        payload = security.verify(issued["capability"])
        assert payload["v"] == 2
        bound = security.verify(
            issued["capability"],
            device_id="phone-test",
            device_epoch=7,
            require_device=True,
        )
        assert bound["device_epoch"] == 7
        for args in (
            {"device_id": "other-phone", "device_epoch": 7},
            {"device_id": "phone-test", "device_epoch": 8},
        ):
            try:
                security.verify(
                    issued["capability"], require_device=True, **args
                )
            except ValueError:
                pass
            else:
                raise AssertionError("device binding did not reject capability")
        old = issued["capability"]
        result = security.rotate()
        assert result["key_age_days"] == 0
        try:
            security.verify(old)
        except ValueError as exc:
            assert "签名" in str(exc)
        else:
            raise AssertionError("rotation did not invalidate old capability")
        fresh = security.issue()
        assert security.verify(fresh["capability"])["exp"] > payload["iat"]
        policy = security.set_policy(rotate_days=99)
        assert policy["rotate_days"] == 99
        assert AppSecurity().policy()["rotate_days"] == 99

        print("  ✓ 设备绑定与密钥轮换")
        passphrase = "fin-deck-portable-passphrase"
        exported = security.export_backup(passphrase)
        envelope = exported["backup"]
        assert "FINSEC-BACKUP-1" in envelope
        assert fresh["capability"] not in envelope
        assert security.verify(fresh["capability"])["v"] == 2
        current = security.issue()
        import json

        tampered = json.loads(envelope)
        tag = str(tampered["tag"])
        tampered["tag"] = ("A" if tag[0] != "A" else "B") + tag[1:]
        try:
            security.restore_backup(json.dumps(tampered), passphrase)
        except ValueError as exc:
            assert "篡改" in str(exc)
        else:
            raise AssertionError("tampered backup was accepted")
        assert security.verify(current["capability"])["v"] == 2
        os.environ["FIN_DECK_SECURITY_KEY"] = str(base / "restored-key.bin")
        os.environ["FIN_DECK_SECURITY_POLICY"] = str(base / "restored-policy.json")
        os.environ["FIN_DECK_SECURITY_META"] = str(base / "restored-meta.json")
        other = AppSecurity()
        other.issue()
        try:
            other.verify(current["capability"])
        except ValueError:
            pass
        else:
            raise AssertionError("fresh install unexpectedly accepted another key")
        try:
            other.restore_backup(envelope, "the-wrong-passphrase")
        except ValueError as exc:
            assert "口令" in str(exc) or "篡改" in str(exc)
        else:
            raise AssertionError("wrong backup passphrase was accepted")
        restored = other.restore_backup(envelope, passphrase)
        assert restored["key_generation"] >= 1
        try:
            other.verify(current["capability"])
        except ValueError as exc:
            assert "密钥" in str(exc) or "签名" in str(exc)
        else:
            raise AssertionError("restore re-enabled an older capability generation")
        assert other.verify(other.issue()["capability"])["v"] == 2
        print("  ✓ 口令加密恢复包可跨安装恢复，错误口令被拒绝")
        print("test_app_security: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
