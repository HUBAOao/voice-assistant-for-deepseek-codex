# -*- coding: utf-8 -*-
"""Focused tests for the extracted phone command and status routes."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature import basic_routes as routes  # noqa: E402


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="findeck-basic-routes-") as raw:
        root = Path(raw)
        (root / "speak.json").write_text(
            json.dumps({"active": True, "text": "正在说"}),
            encoding="utf-8",
        )
        (root / "balance-latest.json").write_text(
            json.dumps({"costCNY": 0.01}), encoding="utf-8"
        )
        (root / "phone_page.html").write_text("page", encoding="utf-8")
        (root / "app.apk").write_bytes(b"x" * 2048)

        state = {"state_text": "idle", "busy": False}
        calls: list[tuple] = []

        def get_log(since, keyword=""):
            calls.append(("log", since, keyword))
            if since >= 20:
                class EmptyRows(list):
                    latest_n = 12
                return EmptyRows()
            return [{"n": 8, "text": "回答"}]

        common = dict(
            get_log=get_log,
            get_state=lambda: state,
            speak_file=root / "speak.json",
            balance_file=root / "balance-latest.json",
            page_file=root / "phone_page.html",
            apk_file=root / "app.apk",
            pc_version=lambda: "1.232",
            phone_version=lambda: "1.43",
            get_info=lambda: {"name": "大肥鱼"},
        )
        status, body, cors = routes.get_route(
            "/api/log", {"since": ["7"], "q": ["回答"]}, **common
        )
        assert status == 200 and body["lines"][0]["text"] == "回答"
        assert body["state"] == "idle" and cors is False
        assert calls == [("log", 7, "回答")]
        status, body, cors = routes.get_route(
            "/api/log", {"since": ["20"], "q": [""]}, **common
        )
        assert status == 200 and body["lines"] == [] and body["latest_n"] == 12

        status, body, cors = routes.get_route("/api/state", {}, **common)
        assert status == 200 and body["busy"] is False and cors is True
        status, body, _ = routes.get_route("/api/speak", {}, **common)
        assert body["text"] == "正在说"
        status, body, _ = routes.get_route("/api/balance", {}, **common)
        assert body["costCNY"] == 0.01
        status, body, _ = routes.get_route("/api/version", {}, **common)
        assert body["pc"] == "1.232" and body["phone"] == "1.43"
        assert body["apk"] == "app.apk" and body["apk_kb"] == 2.0
        status, body, _ = routes.get_route("/api/info", {}, **common)
        assert body == {"ok": True, "name": "大肥鱼"}
        assert routes.get_route("/api/other", {}, **common) is None

        commands: list[str] = []
        stopped: list[bool] = []
        media: list[str] = []
        assert routes.post_route(
            "/api/cmd", {"text": "   "}, on_command=commands.append
        )[0] == 400
        status, body, audit = routes.post_route(
            "/api/cmd", {"text": "查一下进度"}, on_command=commands.append
        )
        assert status == 200 and body["ok"] is True
        assert commands == ["查一下进度"] and audit == ("发命令", "查一下进度")
        status, _, audit = routes.post_route(
            "/api/stop", {}, on_stop=lambda: stopped.append(True)
        )
        assert status == 200 and stopped == [True] and audit == ("喊停", "")
        status, _, audit = routes.post_route(
            "/api/send-media",
            {"text": "图片说明"},
            on_media_command=media.append,
        )
        assert status == 200 and media == ["图片说明"]
        assert audit == ("发附件文字", "图片说明")
        assert routes.post_route("/api/other", {}) is None
        assert routes.BASIC_SECURE_POST_PATHS == {
            "/api/cmd", "/api/send-media"
        }

    print("test_basic_routes: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
