# -*- coding: utf-8 -*-
"""Authentication, pairing identity and HTTP framing stay behind a tested boundary."""
from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.request_auth import (  # noqa: E402
    DEV_COOKIE,
    caller_identity,
    device_identity,
    encoded_response,
    json_object,
    pairing_api_response,
    request_length,
    supplied_token,
    token_valid,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    local = caller_identity("127.0.0.1", "")
    check(local.address == "127.0.0.1" and not local.public,
          "本机请求保留为本机")
    forwarded = caller_identity(
        "127.0.0.1", "198.51.100.9, 203.0.113.12"
    )
    check(forwarded.address == "203.0.113.12" and forwarded.public,
          "公网转发只信代理追加的最后一段")
    direct = caller_identity("192.0.2.8", "203.0.113.12")
    check(direct.address == "192.0.2.8" and not direct.public,
          "直连来源不会被伪造转发头覆盖")

    check(supplied_token({"k": ["query-pass"]}, "header-pass") == "query-pass",
          "查询参数令牌优先")
    check(supplied_token({}, "header-pass") == "header-pass",
          "支持 X-Token 头")
    check(token_valid("same", "same") and not token_valid("", ""),
          "令牌比较拒绝空值")
    check(not token_valid("short", "another"),
          "错误令牌被拒绝")

    stored = device_identity(
        f"other=1; {DEV_COOKIE}=device-1",
        "Browser",
        "192.0.2.8",
        find_device=lambda _ua, _ip: "should-not-run",
        new_device_id=lambda: "should-not-run",
    )
    check(stored.device_id == "device-1" and not stored.fresh
          and not stored.set_cookie, "已有 cookie 直接复用设备号")
    known = device_identity(
        "", "UA", "192.0.2.8",
        find_device=lambda _ua, _ip: "known-device",
        new_device_id=lambda: "should-not-run",
    )
    check(known.device_id == "known-device" and not known.fresh,
          "没有 cookie 时按 UA 与来源复用旧设备")
    fresh = device_identity(
        "", "UA", "192.0.2.8",
        find_device=lambda _ua, _ip: "",
        new_device_id=lambda: "new-device",
    )
    check(fresh.device_id == "new-device" and fresh.fresh
          and f"{DEV_COOKIE}=new-device" in fresh.set_cookie,
          "新设备生成 HttpOnly 持久 cookie")
    check("HttpOnly" in fresh.set_cookie and "SameSite=Lax" in fresh.set_cookie,
          "设备 cookie 带安全属性")

    rejected = pairing_api_response(True, "012345")
    check(rejected is not None and rejected[0] == 403
          and rejected[1].get("err") == "pairing",
          "未配对 API 返回 403 配对错误")
    check(pairing_api_response(False, "012345") is None,
          "未配对页面继续显示配对码页")

    check(request_length("12") == 12, "有效请求体长度")
    check(request_length("-1") == 0 and request_length("abc") == 0,
          "非法请求体长度归零")
    check(request_length("999", maximum=20) == 0,
          "超限请求体长度归零")
    check(json_object(b'{"ok": true}') == {"ok": True},
          "JSON 对象正常解析")
    check(json_object(b'["not", "an", "object"]') == {},
          "非对象 JSON 不进入路由参数")
    check(json_object(b"not-json") == {}, "坏 JSON 安全降级为空对象")

    small_body, small_encoding = encoded_response(b"x" * 100, "gzip")
    check(small_body == b"x" * 100 and not small_encoding,
          "小响应不压缩")
    large = json.dumps({"data": "x" * 2000}).encode("utf-8")
    packed, encoding = encoded_response(large, "br, gzip")
    check(encoding == "gzip" and gzip.decompress(packed) == large,
          "大响应可逆压缩")
    plain, no_encoding = encoded_response(large, "identity")
    check(plain == large and not no_encoding,
          "客户端不支持 gzip 时保持原文")

    source = (APP / "phone_link.py").read_text(encoding="utf-8")
    for marker in (
        "caller_identity(",
        "device_identity(",
        "request_length(",
        "json_object(",
        "encoded_response(",
    ):
        check(marker in source, f"PhoneLink 使用 {marker.rstrip('(')}")
    check("secrets.compare_digest" not in source,
          "PhoneLink 不再内联令牌比较")
    check("gzip.compress" not in source,
          "PhoneLink 不再内联响应压缩")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
