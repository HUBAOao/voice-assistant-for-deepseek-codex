# -*- coding: utf-8 -*-
"""End-to-end checks for files delivered as phone chat messages."""
from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    temp_root = Path(tempfile.mkdtemp(prefix="findeck_chat_files_"))
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    try:
        import chat_file_inbox
        import file_share
        import storage_paths

        file_share.SHARE_DIR = temp_root / "手机文件"
        file_share.UPLOAD_DIR = temp_root / "手机上传"
        file_share.AUDIO_DIR = temp_root / "试听"
        chat_file_inbox.EVENT_DIR = temp_root / "聊天文件事件"
        chat_file_inbox.EVENT_FILE = (
            chat_file_inbox.EVENT_DIR / "events.jsonl"
        )
        chat_file_inbox.LOCK_FILE = (
            chat_file_inbox.EVENT_DIR / ".events.lock"
        )
        chat_file_inbox.storage_paths.mirror_file = (
            lambda *_args, **_kwargs: None
        )
        file_share.storage_paths.mirror_file = (
            lambda *_args, **_kwargs: None
        )

        source = temp_root / "电脑文件.apk"
        source.write_bytes(b"apk-test-payload")
        shared = file_share.add_file(source)
        check(shared is not None, "电脑文件复制到手机分享目录")
        first = chat_file_inbox.publish_file(shared, "鳍舱手机端需求线")
        check(
            first["kind"] == "ai"
            and first["text"] == ""
            and first["conv"] == "鳍舱手机端需求线"
            and first["attachments"][0]["size"] == len(b"apk-test-payload")
            and first["attachments"][0]["mime"]
            == "application/vnd.android.package-archive",
            "文件事件带目标会话、附件元数据和 APK MIME",
        )
        check(int(first.get("ts_ms") or 0) > 0, "文件事件带毫秒时间")
        print("\n① 手机端接口读取与下载")

        spec = importlib.util.spec_from_file_location(
            "phone_link_chat_files",
            APP / "phone_link.py",
        )
        pl = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(pl)
        link = pl.PhoneLink(
            on_command=lambda _text: None,
            get_state=lambda: {},
            get_log=lambda _since: [],
            port=8793,
            pairing=False,
        )
        check(link.start(), "手机入口启动")
        base = f"http://127.0.0.1:{link.port}"

        def get(path: str, key: str = "") -> tuple[int, bytes]:
            separator = "&" if "?" in path else "?"
            suffix = (
                f"{separator}k={urllib.parse.quote(key)}"
                if key else ""
            )
            request = urllib.request.Request(base + path + suffix)
            try:
                with urllib.request.urlopen(request, timeout=8) as response:
                    return response.status, response.read()
            except urllib.error.HTTPError as exc:
                return exc.code, exc.read()

        def post(path: str, body: bytes, key: str = "",
                 capability: str = "") -> tuple[int, dict]:
            separator = "&" if "?" in path else "?"
            suffix = (
                f"{separator}k={urllib.parse.quote(key)}"
                if key else ""
            )
            headers = {"Content-Type": "application/octet-stream"}
            if capability:
                headers["X-FinDeck-Capability"] = capability
            request = urllib.request.Request(
                base + path + suffix,
                data=body,
                method="POST",
                headers=headers,
            )
            try:
                with urllib.request.urlopen(request, timeout=8) as response:
                    return response.status, json.loads(response.read())
            except urllib.error.HTTPError as exc:
                return exc.code, json.loads(exc.read())

        status, _ = get("/api/chat-files?since=0")
        check(status == 401, "没有令牌不能读取聊天文件")
        status, body = get(
            f"/api/chat-files?since=0",
            link.token,
        )
        payload = json.loads(body)
        check(
            status == 200
            and len(payload.get("events", [])) == 1
            and payload["events"][0]["attachments"][0]["name"]
            == "电脑文件.apk",
            "外网同款接口拉到文件聊天事件",
        )
        remote_url = payload["events"][0]["attachments"][0]["remote_url"]
        status, downloaded = get(remote_url, link.token)
        check(
            status == 200 and downloaded == b"apk-test-payload",
            "事件里的受控地址能下载原文件",
        )

        print("\n② 新文件推送与游标去重")
        status, capability_body = get("/api/security/session", link.token)
        capability = json.loads(capability_body).get("capability", "")
        check(status == 200 and bool(capability), "取得文件操作能力凭据")
        status, _ = post(
            "/api/chat-files?name=bypass.apk",
            b"unsecured",
            link.token,
        )
        check(status == 403, "发文件消息必须带能力凭据")
        name = urllib.parse.quote("第二个文件.apk")
        status, posted = post(
            f"/api/chat-files?name={name}&conv={urllib.parse.quote('外部测试会话')}",
            b"second-payload",
            link.token,
            capability,
        )
        check(
            status == 200
            and posted.get("cursor") == 2
            and posted.get("event", {}).get("conv") == "外部测试会话",
            "手机或电脑可把新文件登记成聊天消息",
        )
        cursor = payload["cursor"]
        status, body = get(
            f"/api/chat-files?since={cursor}",
            link.token,
        )
        incremental = json.loads(body)
        check(
            status == 200
            and len(incremental.get("events", [])) == 1
            and incremental["events"][0]["seq"] == 2,
            "独立游标只返回新文件",
        )
        status, body = get(
            f"/api/chat-files?since={incremental['cursor']}",
            link.token,
        )
        check(
            json.loads(body).get("events") == [],
            "同一游标重复轮询不会重复投递",
        )

        print("\n③ 源命令接入")
        command_source = (
            APP / "voice_feature" / "local_commands.py"
        ).read_text(encoding="utf-8")
        check(
            "chat_file_inbox.publish_file(destination, conversation)"
            in command_source
            and "已发到聊天" in command_source,
            "原有“发到手机”命令同时生成聊天文件消息",
        )
        media_source = (APP / "phone_feature" / "media_routes.py").read_text(
            encoding="utf-8"
        )
        check(
            '"/api/chat-files"' in media_source
            and "MAX_UPLOAD_BYTES" in media_source
            and "publish_bytes" in media_source,
            "HTTP 发文件受 200 MB 上限和分享目录保护",
        )
        link.stop()
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
