# -*- coding: utf-8 -*-
"""Pure and fake-adb tests for the native UI regression harness."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "work"))

from android_native_ui_harness import (
    CommandResult,
    build_html,
    compare_images,
    extract_png,
    fatals_for_package,
    image_metadata,
    keyboard_visible,
    launcher_readiness,
    load_manifest,
    parse_bounds,
    parse_devices,
    parse_lock_state,
    parse_package_versions,
    parse_ui_xml,
    parse_wm_size,
    select_node,
    sha256_bytes,
    svg_metadata,
    validate_manifest,
    run_harness,
)


PNG_1X1 = bytes.fromhex(
    "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
    "0000000d49444154789c6360000000020001a5f5c9a40000000049454e44ae426082"
)


def result(text: str = "", code: int = 0, raw: bytes | None = None) -> CommandResult:
    return CommandResult(
        code,
        raw if raw is not None else text.encode("utf-8"),
        b"",
    )


class LockedFakeAdb:
    def __init__(self) -> None:
        self.calls: list[tuple[str, ...]] = []

    def devices(self) -> CommandResult:
        self.calls.append(("devices",))
        return result(
            "List of devices attached\n"
            "192.168.1.4:43715 device product:q7q model:SM_F9660 device:q7q transport_id:1\n"
        )

    def shell(self, *args: str, timeout: int = 30) -> CommandResult:
        self.calls.append(tuple(args))
        if args == ("dumpsys", "power"):
            return result("mWakefulness=Dozing")
        if args == ("dumpsys", "window"):
            return result(
                "mDreamingLockscreen=true\n"
                "mCurrentFocus=Window{1 u0 NotificationShade}\n"
            )
        if args == ("dumpsys", "window", "policy"):
            return result(
                "KeyguardServiceDelegate\n showing=true\n"
                "screenState=SCREEN_STATE_OFF\n"
                "interactiveState=INTERACTIVE_STATE_SLEEP\n"
            )
        return result("unexpected", code=99)

    def exec_out(self, *args: str, timeout: int = 60) -> CommandResult:
        self.calls.append(("exec-out", *args))
        return result("unexpected", code=99)


class UnlockedFakeAdb:
    X = 1080
    Y = 2520

    def __init__(self, version: str = "1.148", code: int = 1148) -> None:
        self.version = version
        self.code = code
        self.apk = b"fake-device-apk"
        self.calls: list[tuple[str, ...]] = []

    def devices(self) -> CommandResult:
        return result(
            "List of devices attached\n"
            "serial device product:q7q model:SM_F9660 device:q7q transport_id:1\n"
        )

    def shell(self, *args: str, timeout: int = 30) -> CommandResult:
        self.calls.append(tuple(args))
        if args == ("dumpsys", "power"):
            return result("mWakefulness=Awake")
        if args == ("dumpsys", "window"):
            return result(
                "mCurrentFocus=Window{1 u0 com.hubao.voiceassistant/"
                "com.hubao.voiceassistant.NativeFinDeckActivity}"
            )
        if args == ("dumpsys", "window", "policy"):
            return result(
                "KeyguardServiceDelegate\n showing=false\n"
                "screenState=SCREEN_STATE_ON\n"
                "interactiveState=INTERACTIVE_STATE_AWAKE\n"
            )
        if args[:2] == ("dumpsys", "package"):
            return result(f"versionCode={self.code} versionName={self.version}")
        if args[:2] == ("pm", "path"):
            return result("package:/data/app/base.apk")
        if args[:2] == ("logcat", "-c"):
            return result("")
        if args and args[0] == "am":
            return result("Status: ok")
        if args == ("wm", "size"):
            return result(f"Physical size: {self.X}x{self.Y}")
        if args[:2] == ("uiautomator", "dump"):
            return result("UI hierchary dumped to: /data/local/tmp/x")
        if args[:2] == ("rm", "-f"):
            return result("")
        if args[:2] == ("logcat", "-d"):
            return result("")
        return result(f"unexpected {args}", code=99)

    def exec_out(self, *args: str, timeout: int = 60) -> CommandResult:
        self.calls.append(("exec-out", *args))
        if args == ("cat", "/data/app/base.apk"):
            return result(raw=self.apk)
        if args[0] == "cat":
            return result(
                '<hierarchy><node text="" class="android.widget.EditText" '
                'clickable="true" enabled="true" bounds="[0,0][100,100]" /></hierarchy>'
            )
        if args[:2] == ("screencap", "-p"):
            return result(raw=PNG_1X1)
        return result("unexpected exec-out", code=99)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    checks = []

    def check(name: str, condition: bool) -> None:
        checks.append((name, condition))
        print(("  ✓ " if condition else "  ✗ ") + name)

    manifest = load_manifest(ROOT / "work" / "native-ui-harness" / "pages.json")
    check("页面清单可加载且至少有主聊天、历史、设置", {
        "main_chat", "history", "settings"
    }.issubset({page["id"] for page in manifest["pages"]}))
    check("清单拒绝只有语义选择器重复 id 的错误", "页面 id 重复：x" in validate_manifest({
        "package": "p",
        "launcher_activity": ".Main",
        "native_activity": ".Native",
        "pages": [
            {"id": "x", "open": [{"selector": {"text": "a"}}], "expect_any": [{"text": "a"}]},
            {"id": "x", "open": [{"selector": {"text": "b"}}], "expect_any": [{"text": "b"}]},
        ],
    }))
    check("清单拒绝越界坐标回退", "坐标回退" in "；".join(validate_manifest({
        "package": "p",
        "launcher_activity": ".Main",
        "native_activity": ".Native",
        "pages": [
            {"id": "x", "open": [{"fallback": [1.2, -1]}], "expect_any": [{"text": "a"}]}
        ],
    })))
    check("清单拒绝越界滑动坐标", "滑动坐标" in "；".join(validate_manifest({
        "package": "p",
        "launcher_activity": ".Main",
        "native_activity": ".Native",
        "pages": [
            {
                "id": "x",
                "open": [
                    {
                        "action": "swipe",
                        "from": [0.5, -0.1],
                        "to": [0.5, 0.7],
                    }
                ],
                "expect_any": [{"text": "a"}],
            }
        ],
    })))

    devices = parse_devices(
        "List of devices attached\n"
        "serial device product:p model:SM_F9660 device:d transport_id:7\n"
        "offline transport_id:8\n"
    )
    check("ADB 设备解析只收 device 状态", len(devices) == 1 and devices[0]["model"] == "SM_F9660")
    versions = parse_package_versions("versionCode=1148 versionName=1.148")
    check("包版本解析", versions == {"version_name": "1.148", "version_code": 1148})

    locked = parse_lock_state("mWakefulness=Dozing", "mDreamingLockscreen=true")
    check("Dozing 明确判锁屏", locked["locked"] and "dreaming_lockscreen" in locked["reasons"])
    shade = parse_lock_state(
        "mWakefulness=Awake",
        "mCurrentFocus=Window{1 u0 NotificationShade}",
    )
    check("NotificationShade 判锁屏", shade["locked"])
    stale_shade = parse_lock_state(
        "mWakefulness=Awake",
        "mCurrentFocus=Window{1 u0 NotificationShade}\n"
        "WindowStateAnimator{2 NotificationShade}\n"
        "mCurrentFocus=Window{3 u0 com.hubao.voiceassistant/.MainActivity}",
    )
    check("历史 NotificationShade 窗口不覆盖当前 App 焦点",
          not stale_shade["locked"])
    policy_locked = parse_lock_state(
        "mWakefulness=Awake",
        "mCurrentFocus=Window{1 u0 Launcher}",
        "KeyguardServiceDelegate\n showing=true\n screenState=SCREEN_STATE_OFF",
    )
    check("Window policy 的 keyguard 也判锁屏", policy_locked["locked"])
    unlocked = parse_lock_state(
        "mWakefulness=Awake",
        "mCurrentFocus=Window{1 u0 com.hubao.voiceassistant/.NativeFinDeckActivity}",
    )
    check("App 焦点且 Awake 不误判锁屏", not unlocked["locked"])
    check("键盘可见状态识别", keyboard_visible("mInputShown=true"))
    check("键盘收起不会误判", not keyboard_visible("mInputShown=false"))
    check(
        "旧 mIsInputViewShown 不覆盖当前 mInputShown=false",
        not keyboard_visible("mInputShown=false mIsInputViewShown=true"),
    )
    check(
        "窗口历史 true 不覆盖 IME 当前 mInputShown=false",
        not keyboard_visible("mInputShown=false", "mInputShown=true"),
    )
    check("屏幕尺寸解析", parse_wm_size("Physical size: 1080x2520") == (1080, 2520))

    xml = """<hierarchy>
      <node text="取消" class="android.widget.TextView" clickable="false" enabled="true" bounds="[0,0][10,10]" />
      <node text="电脑屏幕" class="android.widget.TextView" clickable="false" enabled="true" bounds="[20,20][80,80]" />
      <node text="" hint="搜索对话或项目" class="android.widget.EditText" clickable="true" enabled="true" bounds="[0,100][100,140]" />
    </hierarchy>"""
    nodes = parse_ui_xml(xml)
    check("UIAutomator XML 与 bounds 解析", len(nodes) == 3 and parse_bounds("[1,2][3,4]").center == (2, 3))
    screen = select_node(nodes, {"text": "电脑屏幕"})
    check("语义定位返回可点击父级中心", screen is not None and screen.bounds.center == (50, 50))
    search = select_node(nodes, {"hint": "搜索对话或项目"})
    check("hint 语义定位", search is not None and search.klass.endswith("EditText"))
    check("语义定位缺项返回 None", select_node(nodes, {"text": "不存在"}) is None)

    current_gate = launcher_readiness({
        "status": "pass",
        "ok": True,
        "device_actions_executed": True,
        "app": {
            "expected": {
                "version_name": "1.155",
                "version_code": 1155,
                "sha256": "A",
            },
            "observed": {
                "version_name": "1.155",
                "version_code": 1155,
                "sha256": "A",
            },
        },
        "pages": [],
        "fatals": [],
    }, manifest)
    check(
        "launcher 门槛在缺少本轮证据时明确阻止切换",
        not current_gate["ready"]
        and any("缺少本轮页面记录" in item for item in current_gate["blockers"]),
    )

    log = """
10-25 12:00:00.000 E/AndroidRuntime( 10): FATAL EXCEPTION: main
10-25 12:00:00.001 E/AndroidRuntime( 10): Process: com.hubao.voiceassistant, PID: 10
10-25 12:00:01.000 E/AndroidRuntime( 11): FATAL EXCEPTION: other
10-25 12:00:01.001 E/AndroidRuntime( 11): Process: com.example.other, PID: 11
"""
    fatal = fatals_for_package(log, "com.hubao.voiceassistant")
    check(
        "FATAL 只归属目标包",
        len(fatal) == 1
        and "com.hubao.voiceassistant" in fatal[0]
        and "com.example.other" not in fatal[0],
    )
    check("HTML 转义不可信页面文字", "&lt;script&gt;" in build_html({
        "status": "<script>",
        "pages": [{"id": "x", "title": "<script>", "status": "fail"}],
    }))

    with tempfile.TemporaryDirectory(prefix="findeck-harness-test-") as temp:
        temp_path = Path(temp)
        png = temp_path / "shot.png"
        png.write_bytes(PNG_1X1)
        metadata = image_metadata(png)
        check("PNG 元数据包含尺寸、颜色类型与哈希", metadata["width"] == 1 and metadata["height"] == 1 and metadata["format"] == "png")
        check(
            "screencap 文本警告后的 PNG 可提取",
            extract_png(
                b"[Warning] Multiple displays were found\n"
                + PNG_1X1
                + b"\n"
            ) == PNG_1X1,
        )
        svg = temp_path / "ref.svg"
        svg.write_text(
            '<svg width="10" height="10" viewBox="0 0 10 10">'
            '<rect fill="#002FA7" /></svg>',
            encoding="utf-8",
        )
        svg_meta = svg_metadata(svg)
        check("SVG 元数据包含 viewBox、节点数、颜色", svg_meta["view_box"] == "0 0 10 10" and svg_meta["node_count"] == 2)
        check("缺基线只记录元数据不冒充通过", compare_images(png, None)["status"] == "baseline_missing")
        try:
            from PIL import Image

            red = Image.new("RGB", (8, 8), (255, 0, 0))
            same = temp_path / "red.png"
            blue = temp_path / "blue.png"
            red.save(same)
            Image.new("RGB", (8, 8), (0, 0, 255)).save(blue)
            check("同图像素比较通过", compare_images(same, same, "pixel")["ok"])
            check("异图像素比较失败", not compare_images(blue, same, "pixel")["ok"])
        except ImportError:
            check("Pillow 可用以执行像素比较", False)

        gate_pages = []
        evidence_pages = []
        for configured in manifest["pages"]:
            page_id = configured["id"]
            gate_pages.append({
                **configured,
                "visual": {"mode": "pixel", "baseline": str(png)},
            })
            evidence_pages.append({
                "id": page_id,
                "status": "pass",
                "used_coordinate_fallback": False,
                "screenshot": {"path": str(png), "metadata": metadata},
                "ui_xml": str(svg),
                "activity_retained": True,
                "visual_comparison": {"status": "pixel_match", "ok": True},
                "keyboard": {
                    "visible_before_back": True,
                    "visible_after_back": False,
                    "page_retained_after_keyboard_back": True,
                },
            })
        ready_gate = launcher_readiness({
            "status": "pass",
            "ok": True,
            "device_actions_executed": True,
            "app": {
                "expected": {
                    "version_name": "1.155",
                    "version_code": 1155,
                    "sha256": "A",
                },
                "observed": {
                    "version_name": "1.155",
                    "version_code": 1155,
                    "sha256": "A",
                },
            },
            "pages": evidence_pages,
            "fatals": [],
        }, {**manifest, "pages": gate_pages})
        check(
            "launcher 门槛只在全部真实证据与像素基线齐全时放行",
            ready_gate["ready"],
        )

        dry_report, _ = run_harness(
            None,
            manifest,
            output_dir=None,
            dry_run=True,
        )
        check("dry-run 不执行任何设备动作", dry_report["status"] == "dry_run" and not dry_report["device_actions_executed"])

        locked_fake = LockedFakeAdb()
        locked_report, locked_dir = run_harness(
            locked_fake,
            manifest,
            output_dir=temp_path / "locked",
            dry_run=False,
        )
        check("真实执行遇到锁屏明确拒绝", locked_report["status"] == "refused_locked" and not locked_report["device_actions_executed"])
        forbidden = ("am", "input", "screencap", "logcat")
        check("锁屏拒绝前没有启动、触控、截图或 logcat", not any(call and call[0] in forbidden for call in locked_fake.calls))
        check("锁屏也写 JSON/HTML 报告", (locked_dir / "report.json").is_file() and (locked_dir / "report.html").is_file())

        unlocked_fake = UnlockedFakeAdb()
        unlocked_manifest = {
            **manifest,
            "pages": [
                {
                    "id": "main_chat",
                    "title": "主聊天",
                    "expect_any": [{"class": "android.widget.EditText"}],
                    "close_back": 0,
                    "visual": {"mode": "metadata"},
                }
            ],
        }
        unlocked_report, unlocked_dir = run_harness(
            unlocked_fake,
            unlocked_manifest,
            output_dir=temp_path / "unlocked",
            dry_run=False,
            expected_version="1.148",
            expected_code=1148,
            expected_sha256=sha256_bytes(unlocked_fake.apk),
        )
        check("假 ADB 走通解锁前置、启动、截图与报告", unlocked_report["status"] == "pass" and unlocked_report["pages"][0]["status"] == "pass")
        check("成功运行保存截图和 HTML", (unlocked_dir / "screenshots" / "main_chat.png").is_file() and (unlocked_dir / "report.html").is_file())
        check("成功运行包含启动和截图调用", any(call and call[0] == "am" for call in unlocked_fake.calls) and ("exec-out", "screencap", "-p") in unlocked_fake.calls)
        check(
            "每页运行前强制进入原生预览",
            any(
                call[:3] == ("am", "force-stop", "com.hubao.voiceassistant")
                for call in unlocked_fake.calls
            ),
        )

    passed = sum(1 for _, condition in checks if condition)
    print(f"\n{passed}/{len(checks)} checks passed")
    assert passed == len(checks)
    print("test_android_native_ui_harness: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
