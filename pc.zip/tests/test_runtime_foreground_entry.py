# -*- coding: utf-8 -*-
"""Prepared foreground start keeps feed and live ordering testable."""
from __future__ import annotations

import ast
import sys
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import voice_feature.runtime_main_foreground as foreground  # noqa: E402
from voice_feature.runtime_entry_pipeline import RuntimeEntryResult  # noqa: E402


def make_dependencies(*, feed=None):
    spoken = {"first": False}
    mic_capture = {"recovery": None}
    session_state = SimpleNamespace(
        as_tuple=lambda: (
            spoken,
            ["停", "别说了"],
            {},
            [],
            {},
            {"music": True},
            {},
            {},
            {},
            {},
            {},
            {},
            {},
            {},
            {},
            {},
            "提示",
            3,
            {},
            mic_capture,
        )
    )
    args = SimpleNamespace(
        feed=feed,
        no_greeting=False,
        default_input=False,
        input=None,
        max_seconds=20,
        beep=True,
    )
    startup = SimpleNamespace(
        args=args,
        cfg={"greeting_enabled": True},
        instance_guard=object(),
    )
    audio = SimpleNamespace(
        mode="wake",
        wake_words=["大肥鱼"],
        cancel_words=["取消"],
        silence=0.8,
        stream=object(),
        recorder=object(),
        device=None,
        rate=16000,
        level={"value": 0},
    )
    entry = RuntimeEntryResult(
        startup=startup,
        audio=audio,
        tracker=object(),
        session_state=session_state,
        exit_code=None,
    )
    services = SimpleNamespace(
        phone=SimpleNamespace(pause={"paused": False}),
        control_runtime=SimpleNamespace(set_paused=lambda *_: None),
        periodic_runtime=SimpleNamespace(tick=lambda: True),
        remote=SimpleNamespace(),
        overlay_liveness=SimpleNamespace(process=None),
        phone_server=object(),
    )

    def required(*_args, **_kwargs):
        return True

    platform = SimpleNamespace(
        find_window=lambda name: (1, name),
        paste_text=required,
        record_ptt=lambda recorder: recorder,
        has_utterance=lambda audio_data, rate: True,
        level_state=lambda value: "quiet",
        resolve_device=lambda device: device,
        open_stream=lambda device: (device, 16000),
        make_recorder=object,
        syslog=lambda kind, text: None,
        shut_up=lambda: None,
        speaking_now=lambda: False,
        duplex={},
        cancel_reference_echo=lambda audio_data, rate: audio_data,
        spectrum_bands=required,
        transcriber=object(),
        key_watcher_factory=object,
        tracker_worker_factory=object,
        start_scheduler=required,
        build_greeting=lambda cfg, wake: "你好",
        speak_greeting=required,
        speak=lambda text: None,
        beep=lambda freq, ms: None,
        crash_file=ROOT / "work" / "unused-crash.txt",
        emit=lambda text, **kwargs: None,
        decode_audio_file=lambda path: ("decoded", path),
        target_rate=16000,
    )
    return foreground.PreparedForegroundDependencies(
        entry=entry,
        handle=lambda *_: True,
        handle_lock=object(),
        services=services,
        status=SimpleNamespace(),
        lifecycle=object(),
        on_speech=lambda: None,
        platform=platform,
    ), spoken, mic_capture


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    original = foreground.assemble_foreground_runtime
    try:
        foreground.assemble_foreground_runtime = (
            lambda _deps: (_ for _ in ()).throw(
                AssertionError("feed mode must not start foreground")
            )
        )
        deps, _spoken, _mic = make_dependencies(feed=["sample.wav"])
        seen = []
        deps = foreground.PreparedForegroundDependencies(
            **{
                **deps.__dict__,
                "handle": lambda audio_data, rate: seen.append(
                    (audio_data, rate)
                ),
            }
        )
        code = foreground.run_prepared_foreground(deps)
        check(code == 0, "调试音频模式保持成功返回码 0")
        check(seen == [(("decoded", "sample.wav"), 16000)],
              "调试音频仍解码后交给同一个 handle")

        captured = {}

        def fake_foreground(runtime_deps):
            captured["deps"] = runtime_deps
            return 7

        foreground.assemble_foreground_runtime = fake_foreground
        deps, spoken, mic = make_dependencies()
        code = foreground.run_prepared_foreground(deps)
        runtime = captured["deps"]
        check(code == 7, "前台模式原样返回运行时返回码")
        check(runtime.handle_audio is deps.handle
              and runtime.status is deps.status,
              "单句 handler 与状态对象按原引用转发")
        check(runtime.overlay_process is None
              and runtime.phone_server is deps.services.phone_server,
              "悬浮窗存活与手机服务沿用既有装配对象")
        runtime.before_fallback_capture()
        check(spoken["first"] is True,
              "首次兜底麦克风语义保持")
        recovery = object()
        runtime.on_microphone_ready(recovery)
        check(mic["recovery"] is recovery,
              "麦克风恢复对象仍写回原会话状态")
    finally:
        foreground.assemble_foreground_runtime = original

    stt = APP / "stt.py"
    source = stt.read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    lines = main_node.end_lineno - main_node.lineno + 1
    foreground_entry = (
        APP / "voice_feature" / "runtime_application_foreground.py"
    ).read_text(encoding="utf-8")
    check(lines <= 120, f"main() 行数保持受控：{lines} / 120")
    check("run_prepared_foreground(" in foreground_entry
          and "run_runtime_application(" in source,
          "stt.py 通过独立前台入口启动")
    check("assemble_foreground_runtime" not in source
          and "assemble_foreground_runtime" not in foreground_entry,
          "main 所在文件不再直接构造前台依赖")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
