# -*- coding: utf-8 -*-
"""Round 118: real Codex completion events reach the notification service once."""
from __future__ import annotations

import sys
import tempfile
import types
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
ANDROID = ROOT / "work" / "android-app"
sys.path.insert(0, str(APP))

import phone_stream  # noqa: E402
from voice_feature.phone_bridge_runtime import (  # noqa: E402
    PhoneBridgeDependencies,
    start_phone_bridge,
)
from voice_feature.phone_history_runtime import (  # noqa: E402
    PhoneHistoryDependencies,
    build_phone_history,
)
from voice_feature.runtime_reply_assembly import (  # noqa: E402
    RuntimeReplyAssembly,
    RuntimeReplyDependencies,
)


def assistant(turn_id: str, text: str, phase: str = "final_answer") -> dict:
    return {
        "type": "response_item",
        "payload": {
            "type": "message",
            "role": "assistant",
            "id": "assistant-" + turn_id,
            "phase": phase,
            "internal_chat_message_metadata_passthrough": {
                "turn_id": turn_id,
            },
            "content": [{"text": text}],
        },
    }


def complete(turn_id: str) -> dict:
    return {
        "type": "event_msg",
        "payload": {
            "type": "task_complete",
            "turn_id": turn_id,
            "root_turn_id": turn_id,
        },
    }


class Watcher:
    def __init__(self, active: bool) -> None:
        self.active = active
        self.calls = []

    def start(self, **kwargs):
        self.calls.append(kwargs)

    def is_running(self) -> bool:
        return self.active


class Server:
    def __init__(self, **_kwargs) -> None:
        self.on_client = None

    def start(self):
        return True

    def url(self):
        return "http://127.0.0.1:8765/?k=test"

    def stop(self):
        pass


class Lifecycle:
    def start_daemon(self, _name, _target):
        pass


class Ingress:
    def request_submit(self):
        return None

    def push_media(self, _text):
        return None


class History:
    def ingest(self, _rows):
        return None

    def visible_records(self, rows):
        return rows


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    watcher = phone_stream.GlobalStreamWatcher()
    finals = []
    marker = lambda conv, preview, event_id: finals.append(
        (conv, preview, event_id)
    )
    watcher._handle_message(
        "thread-real", "真实会话", assistant("turn-1", "通知验收完成。"),
        lambda *_args: None, marker,
    )
    watcher._handle_message(
        "thread-real", "真实会话", complete("turn-1"),
        lambda *_args: None, marker,
    )
    watcher._handle_message(
        "thread-real", "真实会话", complete("turn-1"),
        lambda *_args: None, marker,
    )
    check(len(finals) == 1
          and finals[0] == ("真实会话", "通知验收完成。", "thread-real:turn-1"),
          "final_answer 与 task_complete 合并成一个真实完成事件")

    records = []
    stream = Watcher(active=True)
    bridge = start_phone_bridge(
        PhoneBridgeDependencies(
            enabled=True,
            suppressed=False,
            port=8765,
            phone_link_module=types.SimpleNamespace(PhoneLink=Server),
            runtime_lifecycle=Lifecycle(),
            ingress=Ingress(),
            on_command=lambda _text: None,
            get_state=lambda: {},
            get_log=lambda *_args: [],
            on_stop=lambda: None,
            on_voice=lambda _data: "",
            get_info=lambda: {},
            on_image=lambda _name: None,
            get_schedule=lambda: [],
            on_schedule=lambda *_args: (True, ""),
            get_replies=lambda: [],
            get_codex_control=lambda: {},
            get_target=lambda: "",
            get_target_id=lambda: "",
            on_target=lambda *_args: (True, ""),
            on_thread_action=lambda *_args: (True, ""),
            on_new_thread=lambda *_args: (True, ""),
            fallback_get_windows=lambda: [],
            worker=lambda: None,
            syslog=lambda tag, text: records.append((tag, text)),
            threads_module=types.SimpleNamespace(
                list_threads=lambda: [],
                list_projects=lambda: [],
            ),
            phone_stream_module=types.SimpleNamespace(
                GLOBAL_WATCHER=stream,
            ),
        )
    )
    check(bridge is not None and stream.calls, "真实手机桥启动全局监听")
    stream.calls[0]["marker"]("真实会话", "通知验收完成。", "thread:turn")
    check([tag for tag, _ in records] == ["流终", "完"],
          "一次终态同时写入流终和手机完成事件")

    with tempfile.TemporaryDirectory(prefix="findeck_completion_") as raw:
        root = Path(raw)
        syslog = root / "syslog.md"
        syslog.write_text(
            "\n".join([
                "2026-10-25 10:00:00 [完] （真实会话）这段回答处理完了",
                "2026-10-25 10:00:01 [完] （真实会话）这段回答处理完了",
            ]),
            encoding="utf-8",
        )
        deps = PhoneHistoryDependencies(
            syslog_file=syslog,
            raw_replies_file=root / "replies.jsonl",
            last_reply_file=root / "last.json",
            load_config=lambda: {},
            self_who=lambda _cfg: "",
            ack_phrases=(),
            phone_window_title=lambda: "",
            current_thread_name=lambda: "",
            chat_history=History(),
            print_line=lambda *_args, **_kwargs: None,
            clock=lambda: datetime(2026, 10, 25, 10, 0, 2),
        )
        rows = build_phone_history(0, "", deps=deps)
        check(len(rows) == 2 and [row["n"] for row in rows] == [1, 2],
              "连续同文完成事件保留各自日志序号")
        check(getattr(rows, "latest_n", 0) == 2,
              "历史响应附带当前日志最高序号")

    reply_records = []
    reply_assembly = RuntimeReplyAssembly(
        RuntimeReplyDependencies(
            reply_reader_module=types.SimpleNamespace(
                ReplyReader=lambda *_args, **_kwargs: object()
            ),
            speak=lambda *_args, **_kwargs: None,
            syslog=lambda tag, text: reply_records.append((tag, text)),
            on_raw_reply=lambda _data: None,
            busy={"on": True},
            page_path=lambda: Path("missing"),
            reload_module=lambda: None,
            emit=lambda *_args, **_kwargs: None,
        )
    )
    original = phone_stream.GLOBAL_WATCHER
    try:
        phone_stream.GLOBAL_WATCHER = types.SimpleNamespace(
            is_running=lambda: True
        )
        reply_assembly._done("真实会话")
    finally:
        phone_stream.GLOBAL_WATCHER = original
    check(reply_records == [], "流监听可用时读屏完成不重复写完成事件")

    java = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "NotifyService.java"
    ).read_text(encoding="utf-8")
    check("lastText" not in java and "num <= since" in java,
          "安卓服务按日志序号消费完成事件，不按提示文字去重")
    check("notify_since" in java and "firstPoll" in java,
          "首次启动仍只建立通知基线，不补弹历史完成")
    check("latest_n" in java and "since > latestLine" in java,
          "超前或损坏的通知游标会按最高序号安全重基线")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
