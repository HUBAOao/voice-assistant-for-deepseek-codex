# -*- coding: utf-8 -*-
"""Round 120 native IME and launcher-gate regressions."""
from __future__ import annotations

import importlib.util
import json
import sys
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
MANIFEST = ANDROID / "AndroidManifest.xml"
PAGES = ROOT / "work" / "native-ui-harness" / "pages.json"
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"
NS = "{http://schemas.android.com/apk/res/android}"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    key_start = activity.index("composer.setOnKeyListener")
    editor_start = activity.index("composer.setOnEditorActionListener")
    key_block = activity[key_start:editor_start]
    editor_end = activity.index(
        "composer.setOnFocusChangeListener", editor_start
    )
    editor_block = activity[editor_start:editor_end]
    helper_start = activity.index("private boolean isComposerComposing()")
    helper_end = activity.index("private FrameLayout buildFrostedSurface", helper_start)
    helper = activity[helper_start:helper_end]

    print("① 输入法组合输入")
    check(
        "import android.view.inputmethod.BaseInputConnection;" in activity,
        "使用 Android IME 组合区段 API",
    )
    check(
        "BaseInputConnection.getComposingSpanStart(text) >= 0" in helper
        and "BaseInputConnection.getComposingSpanEnd(text) >= 0" in helper,
        "同时检查组合区起点和终点",
    )
    check(
        "event.isShiftPressed() || isComposerComposing()" in key_block,
        "回车键在 Shift 或组合输入阶段不发送",
    )
    check(
        editor_block.count("if (isComposerComposing()) return false;") >= 2,
        "物理回车和 IME send/done 都不会提交未完成候选",
    )
    check(
        "sendComposer();" in key_block and "sendComposer();" in editor_block,
        "组合输入结束后仍保留回车发送路径",
    )

    print("\n② 真机键盘与 launcher 门槛")
    pages_data = json.loads(PAGES.read_text(encoding="utf-8"))
    pages = {page["id"]: page for page in pages_data["pages"]}
    harness = (
        ROOT / "work" / "android_native_ui_harness.py"
    ).read_text(encoding="utf-8")
    check(len(pages) == 12, "页面清单仍为固定 12 页")
    check(
        "keyboard" in pages["main_chat"] and "keyboard" in pages["history"],
        "主聊天和历史搜索都纳入输入法分层返回回归",
    )
    check(
        'remaining_backs = max(0, int(page.get("close_back", 2)) - 1)'
        in harness,
        "主聊天收键盘后不会多发一次返回而误退 Activity",
    )
    tree = ET.parse(MANIFEST)
    application = tree.getroot().find("application")
    launchers = []
    for node in application.findall("activity"):
        for intent in node.findall("intent-filter"):
            actions = {
                item.get(NS + "name") for item in intent.findall("action")
            }
            if "android.intent.action.MAIN" in actions:
                launchers.append(node.get(NS + "name"))
    check(
        launchers == [".NativeFinDeckActivity"],
        "真机结构门槛与外观验收完成后默认 launcher 切到原生入口",
    )

    print("\n③ 版本")
    spec = importlib.util.spec_from_file_location("round120_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        version.PHONE_VERSION == f"1.{len(version.PHONE_CHANGELOG)}",
        f"手机端版本由变更表推导为 v{version.PHONE_VERSION}",
    )
    check(
        any(
            "组合输入" in item and "launcher 严格门槛" in item
            for item in version.PHONE_CHANGELOG
        ),
        "手机端变更表保留本轮输入法与门槛记录",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"getComposingSpanStart" in dex
            and b"getComposingSpanEnd" in dex,
            "APK/DEX 包含组合输入区段保护",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
