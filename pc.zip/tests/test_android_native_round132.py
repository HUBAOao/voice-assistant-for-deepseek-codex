# -*- coding: utf-8 -*-
"""Round 132 remove mobile voice UI from the native Android app."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
REPORT = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "DiagnosticReport.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = ACTIVITY.read_text(encoding="utf-8")
    report = REPORT.read_text(encoding="utf-8")
    footer_setup = method_block(
        source,
        "quickRow = new LinearLayout(this);",
        "quickRow.setVisibility(View.GONE);",
    )
    panel = method_block(
        source,
        "private LinearLayout buildPlusPanel()",
        "private void setPlusOpen(",
    )
    tile = method_block(
        source,
        "private void addTile(",
        "private void setPlusOpen(",
    )
    acceptance = method_block(
        source,
        "private void addAcceptanceTools(",
        "private String buildAcceptanceSnapshot()",
    )
    permissions = method_block(
        source,
        "private void requestAcceptancePermissions()",
        "private String acceptanceLabel(",
    )
    status = method_block(
        source,
        "private void renderStatus(",
        "private void showStatus(",
    )

    print("① 主聊天可见语音入口")
    check(
        'addQuick("朗读"' not in footer_setup
        and "speakLatest();" not in footer_setup,
        "快捷条不再创建“朗读”或调用手机 TTS",
    )
    check(
        'addTileRow(panel, "粘贴文字", "", "发图片", "发文件")'
        in panel,
        "功能面板第四行用空白占位替换“手机朗读”",
    )
    check(
        panel.count("addTileRow(panel") == 6
        and 'addTileRow(panel, "电脑屏幕", "文件", "对话会话", "日程")'
        in panel
        and 'addTileRow(panel, "任务台", "扩展", "真机验收", "看原话")'
        in panel
        and 'addTileRow(panel, "扫码", "静音", "分享对话", "搜历史")'
        in panel,
        "六行网格、其他 22 个能力和顺序保持不变",
    )
    check(
        '"手机朗读".equals(label)' not in tile
        and "speakLatest();" not in tile
        and "手机朗读" not in panel,
        "功能面板不再渲染或执行“手机朗读”",
    )
    check(
        source.count("speakLatest();") == 0,
        "手机 TTS 方法仅保留定义，不存在任何调用点",
    )

    print("\n② 真机验收与权限")
    check(
        '"8 秒采样"' not in acceptance
        and "micSample" not in acceptance
        and "startNativeRecording();" not in acceptance
        and "8 秒麦克风采样" not in acceptance,
        "验收工具不再创建 8 秒采样，也不调用麦克风录音",
    )
    check(
        '"音频焦点"' not in acceptance
        and '"音频路由"' not in acceptance
        and "DeviceDiagnostics.audioEnvironment(" not in acceptance,
        "验收工具移除手机音频焦点/路由入口",
    )
    check(
        "RECORD_AUDIO" not in permissions
        and "android.Manifest.permission.POST_NOTIFICATIONS" in permissions
        and "录音和通知权限" not in permissions,
        "验收“申请权限”只处理通知权限，不再请求麦克风",
    )
    check(
        '"系统、录音、通知与悬浮窗权限"' not in acceptance
        and '"录音权限"' not in status
        and 'data.optBoolean("record_permission")' not in status,
        "验收说明和状态卡不再显示录音权限",
    )
    check(
        '"audio_focus"' not in report
        and '"audio_environment"' not in report
        and 'device.remove("record_permission")' in report
        and 'background.remove("record_permission")' in report
        and "complete" not in report,
        "诊断报告不再生成手机音频/麦克风验收章节",
    )

    print("\n③ 保留非语音能力与休眠实现")
    check(
        'addQuick("新对话"' in footer_setup
        and 'addQuick("粘贴"' in footer_setup
        and 'addQuick("附件"' in footer_setup
        and 'addQuick("停止"' in footer_setup
        and "stopSpeech();" in source,
        "新对话、粘贴、附件和停止命令保持",
    )
    check(
        "stop" in source
        and '"/api/stop"' in source
        and "sendComposer();" in source
        and "drainOutgoingQueue();" in source,
        "发送队列和停止命令语义未改",
    )
    check(
        "private void startNativeRecording()" in source
        and "private void speakLatest()" in source
        and "new TextToSpeech(" in source,
        "底层录音/TTS 仅作为休眠实现保留",
    )
    check(
        "addAudioFile(" in source
        and "MediaPlayer" in source
        and "setNotificationDone(" in source
        and "startNotifyService(" in source,
        "音频文件试听与通知能力未删除",
    )

    spec = importlib.util.spec_from_file_location("round132_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十二轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录语音 UI 清理",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"addAcceptanceTools" in dex
            and b"buildPlusPanel" in dex,
            "APK/DEX 保留非语音验收与功能面板实现",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
