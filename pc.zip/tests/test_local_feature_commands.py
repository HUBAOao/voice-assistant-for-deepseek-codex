# -*- coding: utf-8 -*-
"""Regression tests for standalone game, note, utility and reminder commands."""
from __future__ import annotations

import sys
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.feature_commands import (  # noqa: E402
    dispatch_game_command,
    dispatch_note_command,
    dispatch_reminder_command,
    dispatch_utility_command,
)


class Status:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []

    def set(self, state: str, text: str = "") -> None:
        self.calls.append((state, text))


def done() -> bool:
    return True


def test_game() -> None:
    starts: list[tuple[str, str]] = []
    result = dispatch_game_command(
        "猜数字",
        game_feed=lambda _text: False,
        parse_game=lambda _text: ("guess", ""),
        game_start=lambda kind, extra: starts.append((kind, extra)),
        done=done,
    )
    assert result is True and starts == [("guess", "")]
    assert dispatch_game_command(
        "随便聊聊",
        game_feed=lambda _text: False,
        parse_game=lambda _text: None,
        game_start=lambda *_args: None,
        done=done,
    ) is None


def test_notes() -> None:
    calls: list[tuple] = []
    common = dict(
        query_ledger=("账本",),
        query_note=("我的笔记",),
        parse_ledger=lambda text: ("咖啡", 12) if "咖啡" in text else None,
        parse_note=lambda text: text.removeprefix("记一下") if "记一下" in text else None,
        say_ledger=lambda: calls.append(("say-ledger",)),
        say_notes=lambda: calls.append(("say-notes",)),
        add_ledger=lambda *args: calls.append(("ledger", *args)),
        add_note=lambda text: calls.append(("note", text)),
        beep=lambda: calls.append(("beep",)),
        done=done,
    )
    assert dispatch_note_command("账本", **common) is True
    assert dispatch_note_command("我的笔记", **common) is True
    assert dispatch_note_command("记一下咖啡 12块", **common) is True
    assert dispatch_note_command("记一下明天买牛奶", **common) is True
    assert calls[:3] == [("say-ledger",), ("say-notes",), ("ledger", "咖啡", 12)]
    assert calls[-2:] == [("note", "明天买牛奶"), ("beep",)]
    assert dispatch_note_command("聊聊天气", **common) is None


def test_utilities() -> None:
    status = Status()
    spoken: list[str] = []
    keys: list[tuple[int, bool]] = []
    opened: list[str] = []
    common = dict(
        parse_calc=lambda _text: ("1+1", 2.0),
        parse_convert=lambda _text: None,
        parse_media=lambda _text: None,
        parse_open=lambda _text: None,
        speak=spoken.append,
        status=status,
        beep=lambda: None,
        press_key=lambda key, up=False: keys.append((key, up)),
        open_named=lambda name: opened.append(name) or name,
        done=done,
    )
    assert dispatch_utility_command("一加一", **common) is True
    assert spoken == ["1+1 等于 2"] and status.calls[-1][0] == "sent"

    media = dict(common, parse_calc=lambda _text: None, parse_media=lambda _text: ("播放", 0x250))
    assert dispatch_utility_command("播放", **media) is True
    assert keys == [(0x250, False), (0x250, True)]

    opening = dict(common, parse_calc=lambda _text: None, parse_open=lambda _text: "微信")
    assert dispatch_utility_command("打开微信", **opening) is True
    assert opened == ["微信"]

    opening_miss = dict(
        common,
        parse_calc=lambda _text: None,
        parse_open=lambda _text: "不存在",
        open_named=lambda _name: None,
    )
    assert dispatch_utility_command(
        "打开不存在",
        **opening_miss,
    ) is None


def test_reminder(monkeypatch_sleep=0) -> None:
    status = Status()
    calls: list[tuple] = []
    result = dispatch_reminder_command(
        "10分钟后提醒我喝水",
        enabled=True,
        parse_reminder=lambda _text: (600.0, "喝水"),
        start_reminder=lambda *args: calls.append(("start", *args)),
        paste_to_window=False,
        target_hwnd=0,
        speak=lambda text: calls.append(("speak", text)),
        status=status,
        beep=lambda: calls.append(("beep",)),
        arm_followup=lambda: calls.append(("followup",)),
        once=True,
    )
    assert result is True
    assert calls[0] == ("start", 600.0, "喝水", False, 0)
    assert calls[1][0] == "speak" and "10 分钟" in calls[1][1]
    assert status.calls[-1][1].startswith("⏰")
    assert dispatch_reminder_command(
        "提醒我",
        enabled=False,
        parse_reminder=lambda _text: (1.0, "测试"),
        start_reminder=lambda *_args: None,
        paste_to_window=False,
        target_hwnd=0,
        speak=lambda _text: None,
        status=status,
        beep=lambda: None,
        arm_followup=lambda: None,
        once=False,
    ) is None


def main() -> int:
    test_game()
    test_notes()
    test_utilities()
    test_reminder()
    print("test_local_feature_commands: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
