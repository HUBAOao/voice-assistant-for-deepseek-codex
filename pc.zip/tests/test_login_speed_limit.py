# -*- coding: utf-8 -*-
"""公网地址那扇门的专项测试：令牌错了会不会被限速，对的令牌会不会被误封。

跑在独立端口上（8793），不碰正在运行的那个手机入口。
"""
from __future__ import annotations

import importlib.util
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

PORT = 8793
GOOD = "good-" + "a" * 30
BAD = "nope-" + "b" * 30


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("pl", APP / "phone_link.py")
    pl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pl)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    def code_of(url: str) -> int:
        try:
            with urllib.request.urlopen(url, timeout=8) as r:
                return r.status
        except urllib.error.HTTPError as exc:
            return exc.code

    pl.guard_reset()
    link = pl.PhoneLink(on_command=lambda *_: None,
                        get_state=lambda: {"state_text": "idle"},
                        get_log=lambda since: [], port=PORT)
    link.token = GOOD                       # 这一场用指定的令牌
    check(link.start(), "服务起在 %d 端口" % link.port)
    base = "http://127.0.0.1:%d/?k=" % link.port
    time.sleep(0.3)

    print("① 对的令牌能进、不攒失败")
    check(code_of(base + GOOD) == 200, "第一次 200")
    check(code_of(base + GOOD) == 200, "再来一次 200")

    print("② 错的令牌回 401；连错 %d 次就关门" % pl.GUARD_FAILS)
    got = [code_of(base + BAD) for _ in range(pl.GUARD_FAILS)]
    check(all(c == 401 for c in got), "前 %d 次都是 401（拿到的是 %s）"
          % (len(got), sorted(set(got))))
    check(code_of(base + BAD) == 429, "第 %d 次变成 429（关门外了）" % (pl.GUARD_FAILS + 1))

    print("③ 关门是按来源封的（同一来源拿对令牌也先等着）")
    check(code_of(base + GOOD) == 429, "被封的来源：429")
    st = pl.guard_stats()
    check(st["blocks"] >= 1, "计到封锁次数 blocks=%d" % st["blocks"])
    check(st["fails"] >= pl.GUARD_FAILS, "计到失败次数 fails=%d" % st["fails"])

    print("④ 解封之后立刻恢复")
    pl.guard_reset()
    check(code_of(base + GOOD) == 200, "解封后对的令牌 200")
    check(code_of(base + BAD) == 401, "解封后错的令牌回到 401（不是一直 429）")

    print("⑤ 令牌是长的（旧的 12 位那批自动作废）")
    tok = pl.load_token()
    check(len(tok) >= pl.TOKEN_MIN_CHARS, "现有令牌 %d 位（门槛 %d）"
          % (len(tok), pl.TOKEN_MIN_CHARS))

    link.stop()
    pl.guard_reset()
    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
