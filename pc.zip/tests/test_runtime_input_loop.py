# -*- coding: utf-8 -*-
"""Verify mode assembly and the injected audio loop without opening hardware."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_input_loop import (  # noqa: E402
    InputRuntimeDependencies,
    prepare_input_runtime,
)


class Args:
    key = "*"
    pause_key = "-"
    target = ""


class Watcher:
    def __init__(self, key: str) -> None:
        self.key = key
        self.value = False

    def down(self) -> bool:
        return self.value


class Tracker:
    def __init__(self) -> None:
        self.title = "Codex"
        self.polls = 0

    def poll(self) -> None:
        self.polls += 1


class Worker:
    def __init__(self, tracker) -> None:
        self.tracker = tracker
        self.starts = []

    def start(self, lifecycle) -> None:
        self.starts.append(lifecycle)


class Remote:
    def __init__(self) -> None:
        self.polls = 0

    def poll(self) -> None:
        self.polls += 1


class Status:
    def level(self, *args, **kwargs) -> None:
        pass


def dependencies(mode: str, *, watchers: dict[str, Watcher] | None = None):
    tracker = Tracker()
    remote = Remote()
    workers = []
    tick_calls = {"n": 0}
    pause_changes = []
    messages = []

    def worker_factory(value):
        worker = Worker(value)
        workers.append(worker)
        return worker

    def factory(key):
        watcher = Watcher(key)
        if watchers is not None:
            watchers[key] = watcher
        return watcher

    def runtime_tick():
        tick_calls["n"] += 1
        return False

    def set_paused(value, why):
        pause_changes.append((value, why))
        deps.pause["paused"] = value

    deps = InputRuntimeDependencies(
        mode=mode,
        args=Args(),
        tracker=tracker,
        wake_words=["大肥鱼"],
        cancel_words=["取消"],
        silence=1.2,
        runtime_lifecycle=object(),
        pause={"prev": False, "paused": False},
        set_paused=set_paused,
        runtime_tick=runtime_tick,
        remote=remote,
        handle_lock=object(),
        handle_audio=lambda _audio: False,
        status=Status(),
        microphone=object(),
        key_watcher_factory=factory,
        tracker_worker_factory=worker_factory,
        find_window=lambda _target: (0, ""),
        record_ptt=lambda _recorder: None,
        has_utterance=lambda _audio, _rate: True,
        on_level=lambda _value: None,
        on_hold_start=lambda: None,
        on_hold_stop=lambda: None,
        on_speech=lambda: None,
        before_fallback_capture=lambda: None,
        capture_talk_factory=lambda checked: lambda: checked(),
        emit=messages.append,
    )
    return deps, tracker, remote, workers, tick_calls, pause_changes, messages


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    watchers: dict[str, Watcher] = {}
    deps, tracker, remote, workers, ticks, changes, messages = dependencies(
        "talk", watchers=watchers
    )
    result = prepare_input_runtime(deps)
    check(tracker.polls == 1 and len(workers) == 1,
          "talk 模式先记录前台窗口并启动追踪工作器")
    check(workers[0].starts == [deps.runtime_lifecycle],
          "追踪工作器仍注册到统一生命周期")
    check(any("当前发送目标：Codex" in line for line in messages),
          "talk 模式保留发送目标与操作说明")
    check(result.audio_loop.deps.capture_talk() is False,
          "talk 捕获闭包接到同一暂停判定")
    check(ticks["n"] == 1, "talk 暂停判定先运行周期检查")
    watchers["-"].value = True
    check(result.checked_pause() is True and changes == [(True, "")],
          "暂停键边沿仍只触发一次暂停")
    check(result.checked_pause() is True and len(changes) == 1,
          "按住暂停键不会反复切换")
    watchers["-"].value = False
    result.checked_pause()
    watchers["-"].value = True
    result.checked_pause()
    check(changes[-1] == (False, ""), "松开再按会切回继续")
    result.audio_loop.deps.remote_poll()
    check(ticks["n"] >= 5 and remote.polls == 0,
          "talk 的录音轮询统一走前台周期任务")

    watchers = {}
    deps, tracker, remote, workers, ticks, _changes, messages = dependencies(
        "hold", watchers=watchers
    )
    result = prepare_input_runtime(deps)
    check(result.tracker_worker is None and not workers,
          "hold 模式不启动前台追踪工作器")
    check(result.audio_loop.deps.key_down is not None,
          "hold 模式仍把按键读取器交给录音循环")
    check(any("按住 *" in line for line in messages),
          "hold 模式保留原有提示")
    result.audio_loop.deps.remote_poll()
    check(remote.polls == 1 and ticks["n"] == 0,
          "hold 模式只轮询悬浮窗命令，不启动 talk 周期任务")

    deps, tracker, remote, workers, _ticks, _changes, _messages = dependencies(
        "enter"
    )
    result = prepare_input_runtime(deps)
    check(result.tracker_worker is None and tracker.polls == 0,
          "enter 模式不访问窗口追踪器")
    check(result.audio_loop.deps.key_down is None,
          "enter 模式保持无按住键路径")
    check(result.checked_pause() is False,
          "普通模式仍可直接读取暂停状态")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (APP / "voice_feature" / "runtime_input_loop.py").read_text(
        encoding="utf-8"
    )
    check("prepare_input_runtime(" in source
          and "if mode == \"hold\":" not in source,
          "main() 不再内联三种输入模式分支")
    check("class InputRuntimeDependencies" in module
          and "AudioLoopDependencies(" in module,
          "输入模式、暂停判定和录音循环由同一可注入边界装配")
    check(source.index("tracker_worker = input_runtime.tracker_worker")
          < source.index("register_shutdown_resources("),
          "退出资源在输入运行时提供追踪器之后才登记")
    hot_reload_pet = source.split(
        'if (fresh.get("pet_enabled", True)', 1
    )[1].split("transcriber.hotwords", 1)[0]
    check("args.no_overlay" in hot_reload_pet,
          "无悬浮窗模式在配置热重载后也不会拉起桌宠")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
