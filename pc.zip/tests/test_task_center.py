# -*- coding: utf-8 -*-
"""Regression tests for persistent task approvals and activity."""
from __future__ import annotations

import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
import sys
sys.path.insert(0, str(APP))

from features.tasks import (  # noqa: E402
    TaskStore,
    _turn_changes,
    _turn_status,
    _turn_tools,
    classify_risk,
    redact_sensitive,
)


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        path = Path(raw) / "tasks.json"
        store = TaskStore(path)
        task = store.create("重构手机端", thread_id="thread-1")
        assert task["status"] == "queued"

        task = store.request_approval(
            task["id"], "Remove-Item -Recurse build", target="build", risk="high"
        )
        assert task["status"] == "waiting_approval"
        assert task["approval"]["risk"] == "high"

        task = store.decide(task["id"], True, "允许清理构建目录")
        assert task["status"] == "running"
        assert task["approval"]["decision"] == "approved"

        store.add_tool_call(task["id"], "shell", detail="pytest")
        store.add_test(task["id"], "test_task_center", True)
        store.set_changes(task["id"], [
            {"path": "phone_link.py", "status": "modified", "added": 12, "removed": 3}
        ])
        queued = store.queue_message(task["id"], "补上失败提示")
        message_id = queued["messages"][0]["id"]
        edited = store.edit_message(task["id"], message_id, "补上失败提示和截图")
        assert edited["messages"][0]["edited_at"] > 0
        first = edited["messages"][0]
        second = store.queue_message(task["id"], "再检查移动端")["messages"][-1]
        reordered = store.reorder_messages(task["id"], [second["id"], first["id"]])
        assert [item["id"] for item in reordered["messages"][:2]] == [
            second["id"], first["id"]
        ]
        store.cancel_message(task["id"], second["id"])
        store.update(task["id"], status="succeeded")

        reopened = TaskStore(path).get(task["id"])
        assert reopened and reopened["status"] == "succeeded"
        assert reopened["tests"][0]["ok"] is True
        assert reopened["changes"][0]["path"] == "phone_link.py"
        assert reopened["messages"][0]["status"] == "cancelled"
        assert reopened["messages"][1]["text"] == "补上失败提示和截图"
        assert classify_risk("读取文件") == "low"
        assert classify_risk("删除旧备份") == "high"
        assert classify_risk("提交代码") == "medium"
        assert "secret-value" not in redact_sensitive(
            "token=secret-value", limit=100
        )
        assert _turn_status("inProgress") == "running"
        assert _turn_status("interrupted") == "cancelled"
        tools = _turn_tools([
            {"type": "commandExecution", "command": "pytest -q",
             "status": "completed", "exitCode": 0}
        ])
        assert tools[0]["name"] == "shell"
        changes = _turn_changes([
            {"type": "fileChange", "changes": [{"path": "a.py", "kind": "update"}]}
        ])
        assert changes[0]["path"] == "a.py"
        first_snapshot = store.snapshot(after=0)
        assert first_snapshot["cursor"] >= first_snapshot["items"][0]["revision"]
        delta = store.snapshot(after=first_snapshot["cursor"])
        assert delta["items"] == []
        store.update(task["id"], detail="new delta")
        assert store.snapshot(after=first_snapshot["cursor"])["items"]
        policy = store.set_retention(terminal_days=30, max_tasks=120)
        assert policy["terminal_days"] == 30 and policy["max_tasks"] == 120
        print("test_task_center: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
