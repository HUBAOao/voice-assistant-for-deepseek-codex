# -*- coding: utf-8 -*-
"""Route module order and capability-gate coverage stay centralized."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.route_dispatch import (  # noqa: E402
    RouteResponse,
    dispatch_get,
    dispatch_post,
    secure_post_paths,
)
from phone_feature.static_routes import StaticResult  # noqa: E402


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    order = []
    response = dispatch_get(
        "/asset.js",
        {},
        static_call=lambda: (
            order.append("static")
            or StaticResult(200, b"asset", "text/javascript", audit=("取文件", "asset.js"))
        ),
        basic_call=lambda: order.append("basic"),
        media_call=lambda: order.append("media"),
        session_call=lambda: order.append("session"),
        console_call=lambda: order.append("console"),
        history_call=lambda: order.append("history"),
    )
    check(order == ["static"] and response.encoded() == b"asset",
          "静态资源优先且字节响应保持原样")
    check(response.audit == ("取文件", "asset.js"),
          "调度结果保留审计事件")

    order.clear()
    response = dispatch_get(
        "/api/state",
        {},
        static_call=lambda: order.append("static"),
        basic_call=lambda: (
            order.append("basic") or (200, {"ok": True}, True)
        ),
        media_call=lambda: order.append("media"),
        session_call=lambda: order.append("session"),
        console_call=lambda: order.append("console"),
        history_call=lambda: order.append("history"),
    )
    check(order == ["static", "basic"] and
          response.headers == (("Access-Control-Allow-Origin", "*"),),
          "基础查询按原顺序执行并保留 CORS")

    order.clear()
    response = dispatch_post(
        "/api/tasks/action",
        {},
        b"{}",
        {},
        {},
        basic_call=lambda: order.append("basic"),
        console_call=lambda: (
            order.append("console") or (200, {"ok": True}, ("任务", "test"))
        ),
        session_call=lambda: order.append("session"),
        history_call=lambda: order.append("history"),
        media_call=lambda: order.append("media"),
    )
    check(order == ["basic", "console"] and response.audit == ("任务", "test"),
          "POST 调度保持原优先级并保留审计")

    required = {
        "/api/cmd",
        "/api/submit",
        "/api/send-media",
        "/api/upload",
        "/api/voice",
        "/api/threads/action",
        "/api/threads/new",
        "/api/target",
        "/api/schedule",
        "/api/tasks/action",
        "/api/security/action",
        "/api/plugins/action",
        "/api/plugins/install",
        "/api/device-acceptance/action",
        "/api/agents/action",
        "/api/history/clear",
        "/api/history/restore",
    }
    check(secure_post_paths() == required,
          "集中后的能力凭据路由矩阵仍为 17 条")
    check("/api/stop" not in secure_post_paths(),
          "普通停止接口继续保持普通令牌鉴权")

    phone = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("dispatch_get(" in phone and "dispatch_post(" in phone,
          "PhoneLink 主 Handler 只调用统一路由编排")
    check("static_result = static_get(" not in phone
          and "session_result = session_schedule_get(" not in phone,
          "主 Handler 不再内联各模块调用顺序")
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
