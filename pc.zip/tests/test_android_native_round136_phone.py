# -*- coding: utf-8 -*-
"""Round 136 phone follow-up: cursor, grouped copy and smooth conversation focus."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "work" / "android-app" / "java" / "com" / "hubao" / "voiceassistant"
ACTIVITY = JAVA / "NativeFinDeckActivity.java"
UPDATE_PROVIDER = JAVA / "UpdateProvider.java"
SEND_ICON = ROOT / "work" / "android-app" / "res" / "drawable" / "ic_findeck_send.xml"
COPY_ICON = ROOT / "work" / "android-app" / "res" / "drawable" / "ic_findeck_copy.xml"
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = ACTIVITY.read_text(encoding="utf-8")
    provider_source = UPDATE_PROVIDER.read_text(encoding="utf-8")
    send_icon = SEND_ICON.read_text(encoding="utf-8")
    copy_icon = COPY_ICON.read_text(encoding="utf-8")
    footer = method_block(source, "private View buildFooter()", "private void addAction(")
    caret = method_block(source, "private void updateNativeCaret()", "private void scheduleChatBackdropRefresh")
    message_row = method_block(source, "private void addMessageRow(", "private CharSequence historyKeywordSpan(")
    copy_action = method_block(
        source,
        "private void addGroupCopyAction(",
        "private void addMessageRow(",
    )
    target = source.split(
        "private void targetConversation(\n            JSONObject item,",
        1,
    )[-1].split("private void showSettings()", 1)[0]
    chrome_surface = method_block(
        source,
        "private FrameLayout buildFrostedSurface(",
        "private final class SnapshotFrostedBackdrop",
    )
    connection = method_block(
        source,
        "private void populateNativeConnection(",
        "private void refreshNativeUpdateRow(",
    )
    connection_info = method_block(
        source,
        "private void loadNativeConnectionInfo(",
        "private void loadNativeAbout(",
    )
    update_resolver = method_block(
        source,
        "private void resolveNativeUpdate(",
        "private String resolveHttpDownloadUrl(",
    )
    consume = method_block(
        source,
        "private void consume(",
        "private JSONObject mergeLocalEcho(",
    )
    chat_files = method_block(
        source,
        "private void consumeChatFiles(",
        "private boolean hasChatFileEvent(",
    )
    chat_poll = method_block(
        source,
        "private void poll()",
        "private void consume(",
    )
    chat_file_insert = method_block(
        source,
        "private int insertChatFileByTime(",
        "private boolean hasChatFileEvent(",
    )
    peek_settle = method_block(
        source,
        "private void openConversationPeekSmooth(",
        "private void discardClosingConversationPeek(",
    )
    peek_scroll = method_block(
        source,
        "private final class ConversationQuickSwipeScrollView",
        "private ConversationMessageGroup conversationMessageGroupAt(",
    )

    print("① 输入区")
    check("composer.setCursorVisible(false);" in footer,
          "输入框关闭系统闪烁竖线")
    check("class GlowDotDrawable extends Drawable" in source
          and "new RadialGradient(" in source,
          "插入点圆点使用径向自发光光晕")
    check("M12,20V5M7,10L12,5L18,10M5,3H19" in send_icon,
          "发送箭头尖端顶住上方横线")

    print("\n② 消息组")
    check("StringBuilder copyBuffer" in source
          and "private void addGroupCopyAction(" in source
          and "copyBuffer.toString()" not in message_row
          and "groupCopy.toString()" in source,
          "一个头像组只生成一次复制入口并汇总整组文字")
    check("private void removeGroupCopyAction(" in source
          and 'findViewWithTag("native-group-copy-row")' in source,
          "同组继续追加消息时先替换旧复制入口，不会叠成多个")
    check("native-message-meta|conversation" not in message_row
          and 'conversationView.setTag("native-message-meta|conversation|"'
          in source,
          "真实会话小字从逐条消息移到组级底行")
    check(source.count('setTag("native-message-meta|conversation|') == 1,
          "每个合并消息组只创建一处会话小字")
    check("ImageView copy = new ImageView(this);" in source
          and "R.drawable.ic_findeck_copy" in source
          and 'android:width="16dp"' in copy_icon
          and "copy.setAlpha(" in copy_action
          and "copy.setBackground(" not in copy_action,
          "组级复制入口使用缩小减淡的无底板图标")
    check("NativeTheme.dp(this, 24)" in copy_action
          and "NativeTheme.dp(this, 22)" in copy_action,
          "复制图标点击区缩小到 24×22dp")
    check("void recordTime(String value)" in source
          and "firstTime.equals(lastTime)" in source
          and "group.recordTime(time);" in message_row,
          "合并组记录首句和末句时间，一致时只保留一个")
    check('native-message-meta|time|' in source
          and 'native-message-meta|time|' not in message_row
          and "groupTimeLabel" in copy_action,
          "时间范围只在合并组右下角显示一次")

    attachment_cards = method_block(
        source,
        "private void addMessageAttachments(",
        "private void addBareImagePaths(",
    )
    chat_download = method_block(
        source,
        "private void downloadChatAttachment(",
        "private void loadFilesInto(",
    )
    check("ProgressBar progress" in attachment_cards
          and 'setText("下载")' in attachment_cards
          and "native-chat-download-progress" in attachment_cards
          and "downloadChatAttachment(" in attachment_cards,
          "非图片附件在气泡内显示下载按钮和实时进度条")
    check("connection.getContentLengthLong()" in chat_download
          and "progress.setProgress(" in chat_download
          and 'setText("打开文件")' in chat_download
          and "openDownloadedChatAttachment(" in chat_download,
          "文件按字节更新进度，下载完成显示打开文件按钮")
    check("Intent.createChooser(" in chat_download
          and 'mediaType.startsWith("image/")'
          in source
          and 'mediaType.startsWith("video/")'
          in source,
          "图片视频不弹应用选择器，其他文件弹出用哪个应用打开")
    check('"chat-downloads"' in provider_source,
          "聊天文件通过受控 content:// 路径交给系统打开")
    check("holder.setBackgroundColor(Color.TRANSPARENT);"
          in attachment_cards
          and "group.addView(row" in source
          and "conversation.equals(lastRenderedConversation)"
          in source,
          "文件附件不套独立小卡，并与普通文字共用合并气泡")
    check('api.get("/api/chat-files?since=" + chatFileSince)'
          in chat_poll
          and "consumeChatFiles(chatFiles);" in chat_poll,
          "本轮严格等聊天日志成功后再拉文件收件箱")
    check("new JSONObject(event.toString())" in chat_files
          and "hasChatFileEvent(eventId)" in chat_files
          and 'item.put("kind", "ai")' in chat_files,
          "文件事件转为左侧大气泡并按事件 ID 去重")
    check("chatFileSince = Math.max(0L, nextCursor);" in chat_files
          and "native_chat_file_since" in source
          and "chatFileSince = 0" in source,
          "独立游标随 Activity 留存，换连接和退出筛选时重置")
    check("messages.add(i, item);" in chat_file_insert
          and "existing > stamp" in chat_file_insert
          and "messageTimestamp(item)" in chat_file_insert
          and 'item.put("ts_ms", line.optLong("ts_ms", 0L));' in consume,
          "滞后文件按毫秒时间插回原位置，不再只追加到底部")

    print("\n③ token 横幅")
    balance_host = method_block(
        source,
        "private FrameLayout buildBalanceBannerHost()",
        "private void showBalanceBanner(",
    )
    balance_show = method_block(
        source,
        "private void showBalanceBanner(",
        "private void showTasks()",
    )
    check("private FrameLayout balanceBannerHost;" in source
          and "BALANCE_BANNER_HOLD_MS = 3000" in source,
          "token 提示使用独立顶栏下横幅并固定停留 3 秒")
    check("ViewGroup.LayoutParams.MATCH_PARENT" in balance_host
          and "balanceToast.setBackgroundColor(NativeTheme.ACCENT)" in balance_host
          and "balanceToast.setTextColor(NativeTheme.ACCENT_INK)" in balance_host
          and "NativeTheme.rounded(" not in balance_host,
          "提示条是贴住屏幕左右边缘的主题色直角色块")
    check("topChrome.getHeight()" in balance_show
          and "translationY(-bannerHeight)" in balance_show
          and "translationY(0f)" in balance_show
          and "BALANCE_BANNER_HOLD_MS" in balance_show,
          "提示从顶栏下方展开，停留后向上缩回")

    print("\n④ 会话切换")
    check("private ValueAnimator conversationFocusAnimator;" in source,
          "会话切换使用单独的光晕动画器")
    check("private void animateConversationFocus(" in source
          and "conversationFocusAnimator.cancel();" in source,
          "快速切换会从当前光晕状态平滑反向，不排队卡顿")
    check("animateConversationFocus(" in target
          and "previousConversation" in target,
          "真实切换成功后只更新现有消息组的光晕")
    check("renderMessages();" not in target,
          "切换会话不销毁并重建整页消息")
    check("private float focusFraction;" in source
          and "activeLayer.setAlpha(" in source,
          "每个 AI 消息组独立插值当前/非当前渐变层")
    check("VelocityTracker" in peek_scroll
          and "computeCurrentVelocity(1000)" in peek_scroll
          and "finishExternalPeekGesture(velocityX)" in peek_scroll,
          "左滑跟手阶段实时计算速度")
    check("ValueAnimator.ofFloat(start, end)" in peek_settle
          and "panel.setTranslationX(width + shift)" in peek_settle
          and "DecelerateInterpolator(1.7f)" in peek_settle,
          "松手后从当前位置平滑吸附，不再瞬移")

    print("\n⑤ 顶栏与底栏")
    check("new SnapshotFrostedBackdrop(" in chrome_surface
          and "headerFrostedBackdrop = backdrop;" in chrome_surface
          and "footerFrostedBackdrop = backdrop;" in chrome_surface
          and "headerFrostedTint = tint;" in chrome_surface
          and "footerFrostedTint = tint;" in chrome_surface
          and "content.setBackgroundColor(Color.TRANSPARENT);" in chrome_surface,
          "顶栏底栏使用独立模糊背板和独立主题 tint 层")
    check("backdrop.setAlpha(1f);"
          in chrome_surface
          and '"顶部抽屉透明度"' in source
          and '"顶部抽屉模糊"' in source
          and '"底部抽屉透明度"' in source
          and '"底部抽屉模糊"' in source
          and "NativeTheme.TOP_DRAWER_ALPHA" in source
          and "NativeTheme.BOTTOM_DRAWER_ALPHA" in source
          and "NativeTheme.TOP_DRAWER_BLUR" in source
          and "NativeTheme.BOTTOM_DRAWER_BLUR" in source,
          "透明度和模糊度分别控制顶部筛选抽屉与底部功能抽屉")
    check('"底部抽屉颜色"' in source
          and 'look.put("bottomTint", color);' in source
          and 'look.put("bottomTint", value);' in source
          and "NativeTheme.BOTTOM_DRAWER_COLOR" in source
          and "NativeTheme.drawerColor(" in source,
          "底部抽屉颜色支持预设、自定义色值并即时应用")
    check("new SnapshotFrostedBackdrop(this)" in
          source.split("private void showHistory()", 1)[-1]
          and "historyFrostedTint = historyTint;" in source
          and "refreshHistoryDrawerFrosted(panel);" in source
          and "plusSurface = buildPlusPanel();" in source
          and "plusFrostedTint = tint;" in source
          and "scheduleBottomDrawerFrosted();" in source,
          "顶部筛选抽屉和底部功能抽屉都使用独立GPU毛玻璃")
    live_backdrop = method_block(
        source,
        "private final class SnapshotFrostedBackdrop",
        "private void invalidateLiveFrostedChrome()",
    )
    capture_live = method_block(
        source,
        "private void captureLiveBackdrop(",
        "private void captureFrostedChrome()",
    )
    check("Canvas beginSnapshot(int width, int height)" in live_backdrop
          and "setRenderEffect(" in live_backdrop
          and "Bitmap.createBitmap(" in live_backdrop
          and "snapshot.prepareToDraw();" in live_backdrop
          and "installedBlur != blur" in live_backdrop,
          "模糊背板由独立取样位图和 GPU RenderEffect 组成")
    check("FrostedBarLayout extends FrameLayout" in source
          and "content.measure(widthMeasureSpec, contentHeightSpec)"
          in source
          and "setMeasuredDimension(width, height)" in source,
          "模糊叠层不参与栏体测量，顶底栏不会被撑成整屏")
    check("wallpaperView.draw(canvas);" in capture_live
          and "rootScrim.draw(canvas);" in capture_live
          and "body.draw(canvas);" in capture_live
          and "surfaceAt" in capture_live,
          "按栏屏幕坐标截取壁纸、遮罩和 body 真实后方内容")
    check("root.postOnAnimation(liveChromeCaptureRunnable);"
          in method_block(
              source,
              "private void invalidateLiveFrostedChrome()",
              "private void refreshLiveAppearance()",
          )
          and "protected void onScrollChanged(" in source
          and "scheduleFrostedChromeCapture();" in method_block(
              source,
              "protected void onScrollChanged(",
              "private final class ConversationMessageGroup",
          ),
          "滚动与外观变化时强制实时重绘顶底栏模糊层")
    check("header.setBackgroundColor(Color.TRANSPARENT);" in source
          and "footer.setBackgroundColor(Color.TRANSPARENT);" in source
          and "composer.setBackgroundColor(Color.TRANSPARENT);" in source,
          "只保留文字图片按钮和输入文字，让聊天气泡直接透出")

    print("\n⑥ 连接方式")
    check('"公网连接（唯一方式）"' in connection
          and '"当前公网链接"' in connection
          and '"Tailscale 备用连接"' not in connection
          and '"扫码配对 WLAN"' not in connection,
          "连接页只保留公网连接，不再显示 WLAN 或 Tailscale")
    check("扫码公网链接" in connection
          and "复制公网链接" in connection,
          "主操作是扫码与复制公网链接")
    check('"native_public_url"' in source
          and '"native_public_url", remoteUrl' in connection_info,
          "连接成功后自动记住公网 HTTPS 地址")
    check("private boolean switchToPublicFallback()" in source
          and "switchToPublicFallback()" in consume
          and 'api.setUrl(publicUrl)' in source,
          "WLAN 网络失败时自动切换已保存的公网地址")
    check('"fixed_url"' in connection_info
          and '"update_url"' not in connection_info,
          "公网连接只使用固定 API 地址，不把下载页误当连接地址")
    api_source = (JAVA / "NativeApiClient.java").read_text(encoding="utf-8")
    notify_source = (JAVA / "NotifyService.java").read_text(encoding="utf-8")
    check("static boolean isPublicUrl(" in api_source
          and '"https".equalsIgnoreCase(uri.getScheme())' in api_source
          and "!isPublicUrl(value)" in api_source
          and "只接受公网 HTTPS 地址" in api_source,
          "连接层拒绝 WLAN、Tailscale 私有地址和非 HTTPS 地址")
    check('"native_public_url", "url", "best_url"' in notify_source
          and '"lan_url", "remote_url"' not in notify_source
          and "NativeApiClient.isPublicUrl(value)" in notify_source,
          "后台通知轮询只使用公网入口")
    check('api.get("/api/version")' in update_resolver
          and "versionIsNewer(siteVersion, latest)"
          in update_resolver
          and 'api.absoluteUrl("app.apk")'
          in update_resolver,
          "更新检查同时比较公网站和当前电脑，电脑更新时直接从公网 /app.apk 下载")
    check('"native_public_url"' in update_resolver
          and "api.getFrom(" in update_resolver
          and 'publicUrl, "/api/version"' in update_resolver
          and "versionIsNewer(publicVersion, latest)"
          in update_resolver,
          "更新检查再独立比较已保存的自己的公网地址")

    print("\n⑦ 版本与包")
    spec = importlib.util.spec_from_file_location("round136_phone_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(version.PHONE_VERSION == "1.233", "手机端版本升到 v1.233")
    check(
        any("第一百三十六轮手机聊天交互" in item for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录本轮聊天交互修正",
    )
    check(
        any("原生顶栏下方" in item and "吃掉 token" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录顶栏 token 横幅",
    )
    check(
        any("WLAN 配对" in item and "公网链接" in item
            and "Tailscale" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录连接方式收敛",
    )
    check(
        any("合并消息组时间" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录组级时间范围",
    )
    check(
        any("更新源" in item and "公网" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录公网更新源比较",
    )
    check(
        any("文件卡" in item and "进度条" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录聊天文件卡与下载进度",
    )
    check(
        any("普通消息" in item and "大气泡" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录文件附件并入普通大气泡",
    )
    check(
        any("顶栏和底栏" in item and "透出" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录顶底栏透明化",
    )
    check(
        any("透明度和模糊度" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录顶底栏可调毛玻璃",
    )
    check(
        any("毛玻璃合成" in item for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录毛玻璃 tint 修复",
    )
    check(
        any("实时" in item and "毛玻璃" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录实时毛玻璃重绘",
    )
    check(
        any("公网聊天文件接收" in item and "独立游标" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录聊天文件收件箱和去重",
    )
    check(
        any("只保留公网连接" in item and "WLAN 配对" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录公网唯一连接方式",
    )
    check(
        any("左滑会话菜单跟手" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录左滑吸附和速度判定",
    )
    check(
        any("顶底栏真毛玻璃重建" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录独立取样和 GPU 模糊重建",
    )
    check(
        any("重影" in item and "重复气泡" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录毛玻璃单层合成修复重影",
    )
    check(
        any("文件气泡按时间归位" in item
            for item in version.PHONE_CHANGELOG),
        "PHONE_CHANGELOG 记录文件气泡时序修复",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(b"animateConversationFocus" in dex
              and b"GlowDotDrawable" in dex
              and b"showBalanceBanner" in dex
              and b"downloadChatAttachment" in dex,
              "APK/DEX 含会话光晕、顶栏提示和聊天文件下载实现")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
