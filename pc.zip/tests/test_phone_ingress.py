# -*- coding: utf-8 -*-
"""Phone HTTP ingress is bounded, ordered and safe to drain from one worker."""
from __future__ import annotations

import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.phone_ingress import PhoneIngressQueue  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    queue = PhoneIngressQueue()
    queue.push_command("第一句", "task-1")
    queue.push_command("第二句", "task-2")
    check(queue.take_command() == ("task-1", "第一句"), "命令按提交顺序取出")
    check(queue.take_command() == ("task-2", "第二句"), "连续命令不会互相覆盖")
    check(queue.take_command() is None, "空队列返回 None，而不是抛异常")

    check(queue.push_media("  图片附言  ") and queue.take_media() == "图片附言",
          "媒体附言会去首尾空白并按队列取出")
    check(not queue.push_media("  ") and queue.take_media() == "",
          "纯空白附言不会制造空任务")

    image_a = object()
    image_b = object()
    queue.push_image(image_a)
    queue.push_image(image_b)
    check(queue.take_image() is image_a and queue.take_image() is image_b,
          "手机图片保持原对象与提交顺序")

    queue.request_submit()
    check(queue.consume_submit() and not queue.consume_submit(),
          "提交请求只消费一次，不会连续敲多个回车")

    queue.push_command("并发 A")
    thread = threading.Thread(target=lambda: queue.push_command("并发 B"))
    thread.start()
    thread.join()
    got = {queue.take_command(), queue.take_command()}
    check(got == {("", "并发 A"), ("", "并发 B")},
          "HTTP 线程与运行时线程并发入队不丢命令")
    check(queue.counts() == {
        "commands": 0, "media": 0, "images": 0, "submit": False,
    }, "诊断快照能看到全部队列已清空")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    phone_assembly = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    application_services = (
        APP / "voice_feature" / "runtime_application_services.py"
    ).read_text(encoding="utf-8")
    check("PhoneIngressQueue()" in phone_assembly
          and "handle_command=lambda text:" in application_services
          and "phone_window=application.phone_window" in application_services,
          "手机业务装配通过独立入口队列启动手机线程")
    for marker in (
        "phone_box: list[str]",
        "phone_media_commands: list[str]",
        "phone_submit_requested = threading.Event()",
        "phone_pics: list = []",
    ):
        check(marker not in stt, f"main() 不再内联 {marker}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
