# -*- coding: utf-8 -*-
"""Regression checks for extracted fact-memory, weather and voiceprint logic."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature import personal_commands as personal  # noqa: E402


class Status:
    def __init__(self) -> None:
        self.last = None

    def set(self, state: str, **fields) -> None:
        self.last = (state, fields)


class Reply:
    def __init__(self, body: str) -> None:
        self.body = body

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self) -> bytes:
        return self.body.encode("utf-8")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as td:
        memory_file = Path(td) / "memory.json"
        check(personal.memory_add(memory_file, "我喜欢喝美式"), "事实记忆可写入")
        check(personal.memory_add(memory_file, "我的生日是十月"), "第二条事实记忆可写入")
        rows = json.loads(memory_file.read_text(encoding="utf-8"))
        check(len(rows) == 2 and rows[0]["text"] == "我喜欢喝美式",
              "记忆文件保持旧 JSON 结构")
        found = personal.memory_find(memory_file, "我喜欢喝什么")
        check(bool(found) and found[0]["text"] == "我喜欢喝美式",
              "记忆检索仍能找回相近事实")
        check(personal.parse_remember("帮我记住 我不吃香菜") == "我不吃香菜",
              "记住命令正文解析不变")
        check(personal.parse_ask_memory("你还记得我生日吗"),
              "回忆问题仍进入本地记忆分支")

        spoken: list[str] = []
        logs: list[tuple[str, str]] = []
        status = Status()
        handled = personal.dispatch_memory_command(
            "记住我喜欢喝美式",
            "记住我喜欢喝美式",
            memory_file=memory_file,
            speak=spoken.append,
            syslog=lambda tag, text: logs.append((tag, text)),
            status=status,
            print_line=lambda _text: None,
            beep=lambda: None,
            done=lambda: True,
        )
        check(handled is True and spoken[-1] == "记住了：我喜欢喝美式",
              "事实记忆分支回复保持原样")
        check(status.last and status.last[0] == "sent", "事实记忆更新状态")

        cfg = {"weather_city": "上海"}
        saved: list[dict] = []
        weather = personal.dispatch_weather_command(
            "今天天气怎么样",
            cfg=cfg,
            save_config=saved.append,
            speak=spoken.append,
            syslog=lambda tag, text: logs.append((tag, text)),
            status=status,
            done=lambda: True,
            fetch_weather=lambda city: f"{city}:晴 +22C",
        )
        check(weather is True and spoken[-1] == "上海:晴 +22C",
              "天气查询使用钉死的城市并保留结果")
        personal.dispatch_weather_command(
            "天气城市设成杭州",
            cfg=cfg,
            save_config=saved.append,
            speak=spoken.append,
            syslog=lambda tag, text: logs.append((tag, text)),
            status=status,
            done=lambda: True,
        )
        check(cfg["weather_city"] == "杭州" and saved[-1]["weather_city"] == "杭州",
              "天气城市写入配置且同步内存")

        checked_urls: list[str] = []

        def opener(request, timeout=0):
            checked_urls.append(request.full_url)
            check(timeout == 6, "天气请求保持 6 秒超时")
            return Reply("杭州:+22C")

        line = personal.weather_line("杭州", opener=opener)
        check(line == "杭州:+22C" and "wttr.in" in checked_urls[-1],
              "天气网络请求仍走 wttr.in")

        voice_state = {"enroll": False}
        voice = personal.dispatch_voiceprint_command(
            "注册我的声音",
            voiceprint_state=voice_state,
            train_wake_voice=lambda: None,
            speak=spoken.append,
            print_line=lambda _text: None,
            done=lambda: True,
        )
        check(voice is True and voice_state["enroll"] is True,
              "声纹注册命令进入下一句采样")

        sr = 16000
        seconds = np.arange(sr, dtype=np.float32) / sr
        audio = (0.2 * np.sin(2 * np.pi * 220 * seconds)).astype(np.float32)
        features = personal.voice_features(audio, sr)
        check(features is not None and len(features) == 48,
              "声纹特征仍为 24 个均值 + 24 个标准差")
        voice_file = Path(td) / "voiceprint.json"
        check(personal.voice_enroll(audio, sr, voice_file),
              "声纹可写入独立路径")
        score = personal.voice_score(audio, sr, voice_file)
        check(score is not None and score > 0.99, "同一段声音的相似度接近 1")
        check(personal.background_noise("好的", 0.1, None, True),
              "极低相似度短句仍按背景音拦截")
        check(not personal.background_noise("好的", 0.1, 0.9, True),
              "唤醒声纹通过时仍放行短句")

        source = (APP / "stt.py").read_text(encoding="utf-8")
        for needle in (
            "dispatch_memory_command",
            "dispatch_weather_command",
            "dispatch_voiceprint_command",
            "background_noise(text_to_send",
        ):
            check(needle in source, f"STT 仍经过 {needle}")
        check("def _mel_matrix" not in source and "def weather_line" not in source,
              "声纹矩阵和天气实现已移出 STT 主文件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
