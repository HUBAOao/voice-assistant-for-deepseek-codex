# -*- coding: utf-8 -*-
"""Static phone resources and authenticated downloads resolve without leaking paths."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.static_routes import get_route  # noqa: E402


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_static_") as raw:
        base = Path(raw)
        ui = base / "ui"
        ui.mkdir()
        (ui / "app.js").write_text("console.log('ok')", encoding="utf-8")
        (ui / "bad.exe").write_bytes(b"MZ")
        apk = base / "phone.apk"
        apk.write_bytes(b"PK-test")
        shot = base / "shot.png"
        shot.write_bytes(b"PNG")
        image = base / "photo.jpg"
        image.write_bytes(b"JPG")
        audio = base / "voice.wav"
        audio.write_bytes(b"WAV")
        download = base / "report 报表.txt"
        download.write_bytes(b"REPORT")
        upload = base / "upload.webp"
        upload.write_bytes(b"WEBP")

        def routes(path: str, query: dict[str, list[str]] | None = None):
            return get_route(
                path,
                query or {},
                page_bytes=lambda: b"<html>page</html>",
                phone_ui_root=ui,
                icon_png=lambda size: b"PNG" + str(size).encode(),
                apk_file=apk,
                shot_path=lambda name: shot if name == "one.png" else None,
                local_image_path=lambda name: (
                    image if name == str(image) else None
                ),
                audio_path=lambda name: (
                    audio if name == "voice.wav" else None
                ),
                file_path=lambda name: (
                    download if name == download.name else None
                ),
                upload_path=lambda name: (
                    upload if name == upload.name else None
                ),
            )

        page = routes("/")
        check(page is not None and page.body == b"<html>page</html>",
              "首页仍返回当前手机页")
        asset = routes("/phone-assets/app.js")
        check(asset is not None and b"console.log" in asset.body,
              "外挂脚本仍可读取")
        check(routes("/phone-assets/../bad.exe") is not None
              and routes("/phone-assets/../bad.exe").status == 404,
              "越界资源路径被拒绝")
        check(routes("/phone-assets/bad.exe").status == 404,
              "非脚本资源扩展名被拒绝")
        icon = routes("/icon-512.png")
        check(icon is not None and icon.body == b"PNG512",
              "应用图标仍按尺寸生成")
        sw = routes("/sw.js")
        check(sw is not None and b"skipWaiting" in sw.body,
              "Service Worker 仍可安装")
        app = routes("/app.apk")
        check(app is not None and app.body == b"PK-test"
              and "attachment" in dict(app.headers)["Content-Disposition"],
              "APK 仍作为附件下载")
        screen = routes("/shot/one.png")
        check(screen is not None and screen.content_type == "image/png"
              and screen.audit == ("看屏幕", "one.png"),
              "截图下载和审计记录保持")
        local = routes("/api/image", {"path": [str(image)]})
        check(local is not None and local.body == b"JPG",
              "本机回显图片仍可读取")
        sound = routes("/audio/voice.wav")
        check(sound is not None and sound.content_type == "audio/wav"
              and "inline" in dict(sound.headers)["Content-Disposition"],
              "试听音频仍内联播放")
        report = routes("/file/report%20%E6%8A%A5%E8%A1%A8.txt")
        check(report is not None and report.body == b"REPORT"
              and report.content_type == "application/octet-stream"
              and "attachment" in dict(report.headers)["Content-Disposition"],
              "普通文件仍原样下载")
        loaded = routes("/uploaded/upload.webp")
        check(loaded is not None and loaded.body == b"WEBP",
              "手机上传回显仍可读取")
        check(routes("/not-a-route") is None, "未知路径交给后续路由")
        check(routes("/shot/missing.png").status == 404,
              "不存在的截图返回 404")

    source = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("from phone_feature.static_routes import get_route" in source,
          "手机入口已接入静态资源模块")
    for marker in (
        'u.path.startswith("/phone-assets/")',
        'u.path.startswith("/audio/")',
        'u.path.startswith("/file/")',
        'u.path.startswith("/uploaded/")',
    ):
        check(marker not in source, f"旧内联路由已移除：{marker}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
