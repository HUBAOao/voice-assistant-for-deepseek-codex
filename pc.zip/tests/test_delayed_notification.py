# -*- coding: utf-8 -*-
"""Static checks for the real delayed-notification acceptance path."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
PAGE = ROOT / "outputs" / "voice-to-text"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    receiver = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
                / "DelayedNotificationReceiver.java").read_text(encoding="utf-8")
    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")
    activity = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
                / "MainActivity.java").read_text(encoding="utf-8")
    notify = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
              / "NotifyService.java").read_text(encoding="utf-8")
    page = (PAGE / "phone_page.html").read_text(encoding="utf-8")
    management = (PAGE / "phone_feature" / "ui" / "management.js").read_text(
        encoding="utf-8"
    )
    diagnostics = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
                   / "DeviceDiagnostics.java").read_text(encoding="utf-8")

    check("setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP" in receiver,
          "延迟通知使用可在待机时触发的系统闹钟")
    check("Math.max(5, Math.min(120, requestedSeconds))" in receiver,
          "延迟时间限制为 5–120 秒")
    check("FLAG_IMMUTABLE" in receiver and "PendingIntent.getBroadcast" in receiver,
          "延迟广播使用不可变 PendingIntent")
    check("android:name=\".DelayedNotificationReceiver\"" in manifest
          and "android:exported=\"false\"" in manifest,
          "延迟通知接收器只允许本应用")
    check("@JavascriptInterface" in activity
          and "public void testDelayedNotification(final int seconds)" in activity,
          "页面可通过原生桥安排延迟通知")
    check("showDelayedTestNotification" in notify
          and "后台延迟通知已到达" in notify,
          "延迟通知使用可识别的后台验收文案")
    check("public static String snapshot(Context context)" in receiver
          and "delivery_lag_ms" in receiver
          and "keyguard_locked" in receiver
          and "notification_visible" in receiver,
          "原生接收器保留计划、实际送达、锁屏、偏差与当前可见状态")
    check("public static boolean isAlertActive(Context context)" in notify
          and "getActiveNotifications()" in notify,
          "完成通知可回读本应用当前是否仍在系统通知栏")
    check("public static boolean cancel(Context context)" in receiver
          and "alarms.cancel(pending)" in receiver,
          "待发送的后台验收通知可由系统闹钟取消")
    check('id="acceptNotifyDelayed"' in page
          and "15 秒后通知（可锁屏）" in page,
          "真机验收页提供 15 秒锁屏通知按钮")
    check('id="acceptNotifyEvidence"' in page
          and 'id="acceptNotifyCancel"' in page
          and "delayedNotificationProbe" in activity
          and "cancelDelayedNotification" in activity
          and "通知送达证据" in management
          and "系统通知栏" in management,
          "验收页可读取通知送达证据、当前可见性并取消待发送通知")
    check("VoiceApp.testDelayedNotification(15)" in management,
          "验收按钮调用原生延迟通知")
    check("backgroundReadiness" in diagnostics
          and "battery_optimization_ignored" in diagnostics
          and "done_channel_high" in diagnostics,
          "原生后台就绪快照汇总通知、服务与电池条件")
    check("backgroundReadinessProbe" in activity
          and "VoiceApp.backgroundReadinessProbe" in management
          and 'id="acceptBackgroundReadiness"' in page,
          "验收页可直接读取并展示原生后台就绪快照")
    check("done_channel_sound" in diagnostics
          and "done_channel_vibration" in diagnostics
          and "done_channel_lockscreen_visibility" in diagnostics
          and "done_channel_alerting" in diagnostics,
          "后台快照保留完成通道响铃、震动、锁屏可见性与可提醒判定")
    check("done_channel_alerting" in management
          and "done_channel_sound" in management
          and "done_channel_vibration" in management,
          "真机验收页展示完成通道实际提醒条件")
    check('id="acceptNotifyChannel"' in page
          and "openDoneNotificationChannelSettings" in activity
          and "ACTION_CHANNEL_NOTIFICATION_SETTINGS" in activity,
          "验收页可直达完成通知通道设置")
    check("SCHEDULE_EXACT_ALARM" not in manifest,
          "使用非精确闹钟，不新增精确闹钟特殊权限")

    from importlib.util import module_from_spec, spec_from_file_location

    spec = spec_from_file_location("findeck_version", PAGE / "version.py")
    version = module_from_spec(spec)
    spec.loader.exec_module(version)
    check(tuple(map(int, version.APP_VERSION.split("."))) >= (1, 241),
          f"电脑端版本为 v{version.APP_VERSION}")
    check(tuple(map(int, version.PHONE_VERSION.split("."))) >= (1, 52),
          f"手机端版本为 v{version.PHONE_VERSION}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
