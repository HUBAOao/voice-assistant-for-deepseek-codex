# -*- coding: utf-8 -*-
"""Guard the P3 capability boundary as phone routes move between modules."""
from __future__ import annotations

import sys
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.route_dispatch import secure_post_paths  # noqa: E402


def main() -> int:
    protected = secure_post_paths()
    required = {
        "/api/cmd",
        "/api/submit",
        "/api/send-media",
        "/api/upload",
        "/api/voice",
        "/api/threads/action",
        "/api/threads/new",
        "/api/target",
        "/api/schedule",
        "/api/tasks/action",
        "/api/security/action",
        "/api/plugins/action",
        "/api/plugins/install",
        "/api/device-acceptance/action",
        "/api/agents/action",
        "/api/history/clear",
        "/api/history/restore",
    }
    assert protected == required, sorted(protected ^ required)
    assert "/api/stop" not in protected

    post_routes: set[str] = set()
    for path in (APP / "phone_feature").glob("*_routes.py"):
        source = path.read_text(encoding="utf-8")
        marker = "def post_route("
        if marker not in source:
            continue
        body = source.split(marker, 1)[1]
        body = body.split("\ndef ", 1)[0]
        post_routes.update(re.findall(r'"(/api/[^"]+)"', body))
    # /api/stop is intentionally ordinary-token authenticated: it only stops
    # speech and was explicitly kept outside the high-risk capability gate.
    assert post_routes - protected == {"/api/stop"}, sorted(post_routes - protected)

    source = (APP / "phone_link.py").read_text(encoding="utf-8")
    assert "secure_post_paths()" in source
    assert "if u.path in secure_post_paths() and not self._secure()" in source
    assert source.index("if not self._gate(q):") < source.index(
        "if u.path in secure_post_paths() and not self._secure():"
    )
    assert "dispatch_post(" in source and "dispatch_get(" in source
    print("test_route_security_coverage: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
