# -*- coding: utf-8 -*-
"""Guard the P3 capability boundary as phone routes move between modules."""
from __future__ import annotations

import sys
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.basic_routes import BASIC_SECURE_POST_PATHS  # noqa: E402
from phone_feature.console_routes import SECURE_POST_PATHS as CONSOLE  # noqa: E402
from phone_feature.history_routes import SECURE_POST_PATHS as HISTORY  # noqa: E402
from phone_feature.session_schedule_routes import (  # noqa: E402
    SECURE_POST_PATHS as ACTIONS,
)


def main() -> int:
    protected = BASIC_SECURE_POST_PATHS | CONSOLE | HISTORY | ACTIONS
    required = {
        "/api/cmd",
        "/api/submit",
        "/api/send-media",
        "/api/upload",
        "/api/voice",
        "/api/threads/action",
        "/api/threads/new",
        "/api/target",
        "/api/schedule",
        "/api/tasks/action",
        "/api/security/action",
        "/api/plugins/action",
        "/api/plugins/install",
        "/api/device-acceptance/action",
        "/api/agents/action",
        "/api/history/clear",
        "/api/history/restore",
    }
    assert protected == required, sorted(protected ^ required)
    assert "/api/stop" not in protected

    post_routes: set[str] = set()
    for path in (APP / "phone_feature").glob("*_routes.py"):
        source = path.read_text(encoding="utf-8")
        marker = "def post_route("
        if marker not in source:
            continue
        body = source.split(marker, 1)[1]
        body = body.split("\ndef ", 1)[0]
        post_routes.update(re.findall(r'"(/api/[^"]+)"', body))
    # /api/stop is intentionally ordinary-token authenticated: it only stops
    # speech and was explicitly kept outside the high-risk capability gate.
    assert post_routes - protected == {"/api/stop"}, sorted(post_routes - protected)

    source = (APP / "phone_link.py").read_text(encoding="utf-8")
    assert "BASIC_SECURE_POST_PATHS" in source
    assert "CONSOLE_SECURE_POST_PATHS" in source
    assert "ACTION_SECURE_POST_PATHS" in source
    assert "HISTORY_SECURE_POST_PATHS" in source
    assert "if u.path in secure_paths and not self._secure()" in source
    assert source.index("if not self._gate(q):") < source.index(
        "if u.path in secure_paths and not self._secure():"
    )
    print("test_route_security_coverage: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
