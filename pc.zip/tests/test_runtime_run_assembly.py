# -*- coding: utf-8 -*-
"""Final loop, crash and shutdown behavior stays outside main()."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_run_assembly import (  # noqa: E402
    RuntimeRunDependencies,
    run_voice_runtime,
)


class Loop:
    def __init__(self, error=None) -> None:
        self.error = error

    def run(self):
        if self.error is not None:
            raise self.error


class Lifecycle:
    def __init__(self) -> None:
        self.closed = False

    def close(self):
        self.closed = True
        return []


class Status:
    def __init__(self) -> None:
        self.state = ""

    def set(self, state, **_kwargs):
        self.state = state


class Guard:
    def __init__(self) -> None:
        self.released = False

    def release(self):
        self.released = True


def deps(loop, lifecycle, status, guard) -> RuntimeRunDependencies:
    return RuntimeRunDependencies(
        audio_loop=loop,
        runtime_lifecycle=lifecycle,
        instance_guard=guard,
        status=status,
        syslog=lambda _tag, _text: None,
        speak=lambda _text: None,
        crash_file=Path("unused-crash.txt"),
        microphone_stream=lambda: None,
        tracker_worker=None,
        overlay_process=None,
        phone_server=None,
        emit=lambda _text: None,
    )


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    lifecycle = Lifecycle()
    guard = Guard()
    status = Status()
    code = run_voice_runtime(deps(Loop(), lifecycle, status, guard))
    check(code == 0 and lifecycle.closed and guard.released,
          "正常循环结束后通过生命周期释放资源和实例锁")
    check(status.state == "offline", "退出状态仍写入离线")

    lifecycle = Lifecycle()
    guard = Guard()
    status = Status()
    code = run_voice_runtime(
        deps(Loop(KeyboardInterrupt()), lifecycle, status, guard)
    )
    check(code == 0 and lifecycle.closed and guard.released,
          "键盘中断仍走同一退出清理路径")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    foreground = (
        APP / "voice_feature" / "runtime_foreground_assembly.py"
    ).read_text(encoding="utf-8")
    prepared = (
        APP / "voice_feature" / "runtime_main_foreground.py"
    ).read_text(encoding="utf-8")
    foreground_entry = (
        APP / "voice_feature" / "runtime_application_foreground.py"
    ).read_text(encoding="utf-8")
    check("return run_voice_runtime(" in foreground
          and "return assemble_foreground_runtime(" in prepared
          and "return run_prepared_foreground(" in foreground_entry
          and "shutdown_runtime(" not in source,
          "main() 不再手写最终运行、失败和退出收口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
