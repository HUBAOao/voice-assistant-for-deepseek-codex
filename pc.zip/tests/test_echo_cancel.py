# -*- coding: utf-8 -*-
"""Tests for provider-neutral echo cancellation primitives."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from features.voice_providers import AdaptiveEchoCanceller, ProviderRegistry  # noqa: E402


def main() -> int:
    rng = np.random.default_rng(7)
    reference = rng.normal(0, 0.08, 4096)
    echo = np.convolve(reference, [0.42, -0.18, 0.09], mode="full")[:reference.size]
    noise = rng.normal(0, 0.001, reference.size)
    microphone = echo + noise
    canceller = AdaptiveEchoCanceller(taps=16)
    first = canceller.cancel(microphone, reference)
    for _ in range(3):
        output = canceller.cancel(microphone, reference)
    before = float(np.sqrt(np.mean(microphone ** 2)))
    after = float(np.sqrt(np.mean(output ** 2)))
    assert after < before * 0.8, (before, after)
    registry = ProviderRegistry()
    assert not registry.stt and not registry.tts
    print(f"test_echo_cancel: PASS ({before:.4f} -> {after:.4f})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
