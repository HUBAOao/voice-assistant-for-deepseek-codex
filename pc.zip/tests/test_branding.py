# -*- coding: utf-8 -*-
"""Verify visible FinDeck branding while legacy filenames stay compatible."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import version  # noqa: E402


def main() -> int:
    assert version.PRODUCT_NAME == "鳍舱"
    assert version.PRODUCT_NAME_EN == "FinDeck"
    assert version.ASSISTANT_NAME == "大肥鱼"
    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    assert "<title>鳍舱 · FinDeck · 手机入口</title>" in page
    assert '<span class="dot" id="dot"></span><span class="name" id="appname">鳍舱</span>' in page
    manifest = (ROOT / "work" / "android-app" / "AndroidManifest.xml").read_text(
        encoding="utf-8"
    )
    assert 'android:label="鳍舱"' in manifest

    import phone_link

    pwa = phone_link.PhoneLink(
        lambda text: None, lambda: {}, lambda since=0: [],
        pairing=False, token="branding-test",
    )
    payload = __import__("json").loads(pwa.manifest())
    assert payload["name"] == "鳍舱 · FinDeck"
    assert payload["short_name"] == "鳍舱"

    # 兼容资产仍使用原文件名，不能为了品牌迁移破坏升级和旧快捷方式。
    assert (APP / "语音助手-手机端.apk").exists()
    assert (APP / "卸载语音助手.cmd").exists()
    print("test_branding: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
