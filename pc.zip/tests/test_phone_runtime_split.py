# -*- coding: utf-8 -*-
"""Phone bridge and schedule business stay injectable outside main()."""
from __future__ import annotations

import json
import sys
import tempfile
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.phone_bridge_runtime import (  # noqa: E402
    PhoneBridgeDependencies,
    start_phone_bridge,
)
from voice_feature.phone_schedule_runtime import (  # noqa: E402
    list_phone_schedules,
    update_phone_schedule,
)


class Ingress:
    def __init__(self) -> None:
        self.submit = 0
        self.media: list[str] = []

    def request_submit(self) -> None:
        self.submit += 1

    def push_media(self, text: str) -> bool:
        self.media.append(text)
        return True


class Server:
    def __init__(self, **kwargs) -> None:
        self.__dict__.update(kwargs)
        self.started = False
        self.stopped = False

    def start(self) -> bool:
        self.started = True
        return True

    def url(self) -> str:
        return "http://127.0.0.1:8765/?k=test"

    def stop(self) -> None:
        self.stopped = True


class Lifecycle:
    def __init__(self) -> None:
        self.jobs: list[tuple[str, object]] = []

    def start_daemon(self, name, target):
        self.jobs.append((name, target))


class Threads:
    list_threads = staticmethod(lambda: [{"id": "thread"}])
    list_projects = staticmethod(lambda: [{"id": "project"}])


class Watcher:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def start(self, **kwargs) -> None:
        self.calls.append(kwargs)


class FakeSchedule:
    @staticmethod
    def normalize(item: dict) -> dict:
        out = dict(item)
        out.setdefault("kind", "daily")
        out.setdefault("weekdays", [])
        out.setdefault("monthday", 1)
        out.setdefault("date", "")
        out.setdefault("enabled", True)
        return out

    @staticmethod
    def describe(item: dict) -> str:
        return "每天 " + str(item.get("time") or "")


def bridge_dependencies(**overrides) -> PhoneBridgeDependencies:
    ingress = Ingress()
    lifecycle = Lifecycle()
    watcher = Watcher()
    logs: list[str] = []
    events: list[tuple] = []
    phone_link_module = types.SimpleNamespace(PhoneLink=Server)
    phone_stream_module = types.SimpleNamespace(
        GLOBAL_WATCHER=watcher
    )
    values = dict(
        enabled=True,
        suppressed=False,
        port=8765,
        phone_link_module=phone_link_module,
        runtime_lifecycle=lifecycle,
        ingress=ingress,
        on_command=lambda text: events.append(("command", text)),
        get_state=lambda: {"state": "idle"},
        get_log=lambda since, keyword="": [],
        on_stop=lambda: None,
        on_voice=lambda data: "",
        get_info=lambda: {"name": "鳍舱"},
        on_image=lambda path: None,
        get_schedule=lambda: [],
        on_schedule=lambda action, payload: (True, "ok"),
        get_replies=lambda: [],
        get_codex_control=lambda: None,
        get_target=lambda: "thread",
        get_target_id=lambda: "id",
        on_target=lambda title, thread_id="": (True, "ok"),
        on_thread_action=lambda action, thread_id, data: (True, "ok"),
        on_new_thread=lambda project_id="": (True, "ok"),
        fallback_get_windows=lambda: [],
        worker=lambda: events.append(("worker",)),
        log=logs.append,
        syslog=lambda tag, text: events.append((tag, text)),
        threads_module=Threads,
        phone_stream_module=phone_stream_module,
    )
    values.update(overrides)
    return PhoneBridgeDependencies(**values)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    deps = bridge_dependencies()
    server = start_phone_bridge(deps)
    check(isinstance(server, Server) and server.started,
          "手机桥接由独立运行时启动真实服务对象")
    check(server.on_submit == deps.ingress.request_submit
          and server.on_media_command == deps.ingress.push_media,
          "附件提交和媒体附言仍绑定同一线程安全入口队列")
    check(server.get_windows() == [{"id": "thread"}]
          and server.get_projects() == [{"id": "project"}],
          "Codex 会话与项目列表仍接到手机入口")
    check(deps.runtime_lifecycle.jobs
          and deps.runtime_lifecycle.jobs[0][0] == "phone-command-worker",
          "手机命令取件线程仍通过生命周期去重启动")
    check(deps.phone_stream_module.GLOBAL_WATCHER.calls,
          "所有近期 Codex 会话的流式监听仍会启动")
    check(start_phone_bridge(bridge_dependencies(enabled=False)) is None
          and start_phone_bridge(bridge_dependencies(suppressed=True)) is None,
          "手机入口关闭或测试抑制时不会偷偷监听端口")

    class BrokenThreads:
        @staticmethod
        def list_threads():
            raise RuntimeError("threads unavailable")

    fallback = [{"title": "电脑窗口"}]
    fallback_deps = bridge_dependencies(
        threads_module=BrokenThreads,
        fallback_get_windows=lambda: fallback,
    )
    fallback_server = start_phone_bridge(fallback_deps)
    check(fallback_server.get_windows() == fallback,
          "读取 Codex 会话失败时仍回退到电脑窗口列表")

    with tempfile.TemporaryDirectory() as raw:
        config = Path(raw) / "config.json"
        state = {"schedules": [{
            "time": "08:30", "text": "晨会", "kind": "daily",
            "weekdays": [], "monthday": 1, "date": "", "enabled": True,
        }]}
        config.write_text(
            json.dumps(state, ensure_ascii=False), encoding="utf-8"
        )

        def load():
            return json.loads(config.read_text(encoding="utf-8"))

        events: list[tuple] = []
        rows = list_phone_schedules(load, schedule_module=FakeSchedule)
        check(len(rows) == 1 and rows[0]["when"] == "每天 08:30",
              "手机日程列表继续返回统一归一化字段")
        ok, message = update_phone_schedule(
            "add",
            {"item": {"time": "10:00", "text": "喝水"}},
            config_file=config,
            load_config=load,
            log=lambda tag, text: events.append((tag, text)),
            schedule_module=FakeSchedule,
        )
        check(ok and message == "好了" and len(load()["schedules"]) == 2,
              "手机新增日程写回 config.json")
        ok, _ = update_phone_schedule(
            "toggle",
            {"i": 0},
            config_file=config,
            load_config=load,
            log=lambda tag, text: events.append((tag, text)),
            schedule_module=FakeSchedule,
        )
        check(ok and load()["schedules"][0]["enabled"] is False,
              "日程启停仍按原索引生效")
        ok, _ = update_phone_schedule(
            "del",
            {"i": 1},
            config_file=config,
            load_config=load,
            log=lambda tag, text: events.append((tag, text)),
            schedule_module=FakeSchedule,
        )
        check(ok and len(load()["schedules"]) == 1,
              "删除日程后原子替换配置文件")
        check(not config.with_name(config.name + ".tmp").exists(),
              "临时配置文件不会残留在数据目录")
        check(any(tag == "日程" for tag, _text in events),
              "日程写入仍保留系统日志记录")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    application_services = (
        APP / "voice_feature" / "runtime_application_services.py"
    ).read_text(encoding="utf-8")
    services = (
        APP / "voice_feature" / "runtime_service_assembly.py"
    ).read_text(encoding="utf-8")
    check("PhoneBridgeDependencies(" in assembly
          and "start_phone_bridge(" in assembly
          and "assemble_phone_runtime(" in services
          and "assemble_runtime_services(" in application_services
          and "phone_link.PhoneLink(" not in stt,
          "main() 只消费手机业务装配，不再手写 PhoneLink 回调")
    check("list_phone_schedules(" in assembly
          and "update_phone_schedule(" in assembly
          and "old[\"text\"] = str(" not in stt,
          "日程读写业务已迁出 main()")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
