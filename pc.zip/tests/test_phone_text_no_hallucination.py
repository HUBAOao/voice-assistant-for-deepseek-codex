# -*- coding: utf-8 -*-
"""手机输入不能被语音幻觉过滤器丢弃。"""
from __future__ import annotations
from pathlib import Path

import pathlib
import sys

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import stt  # noqa: E402


def main() -> int:
    text = (
        "【【DSH】刷B站插件2.0 发布，私信双向 + 观看历史列表"
        "（dsh-bili-scroll）-哔哩哔哩】 https://b23.tv/kpCzQcX"
    )
    source = (APP / "stt.py").read_text(encoding="utf-8")
    checks = [
        ("该文本确实会命中原幻觉规则", stt.is_hallucination(text) is True),
        ("手机文字已绕过幻觉过滤",
         "if audio is not None and is_hallucination(text):" in source),
    ]
    bad = 0
    for name, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + name)
        bad += 0 if ok else 1
    print("失败项", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
