# -*- coding: utf-8 -*-
"""TTS defaults, clickable speaker control, and pause guarantee."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.window_geometry import speaker_rect  # noqa: E402
from overlay_feature.window_interaction import WindowInteractionMixin  # noqa: E402
from overlay_feature.defaults import DEFAULTS  # noqa: E402
from voice_feature.runtime_startup_callbacks import SavedRuntimeTargets  # noqa: E402
from voice_feature.speech_playback import (  # noqa: E402
    SPEECH_PROCESSES,
    SpeechProcesses,
)


class Process:
    def __init__(self) -> None:
        self.alive = True
        self.calls: list[str] = []

    def poll(self):
        return None if self.alive else 0

    def terminate(self) -> None:
        self.calls.append("terminate")
        self.alive = False

    def kill(self) -> None:
        self.calls.append("kill")
        self.alive = False

    def wait(self, timeout=None):
        self.calls.append(f"wait:{timeout}")
        return 0


class SpeakerClick(WindowInteractionMixin):
    def __init__(self) -> None:
        self.cfg = {"muted": True}
        self.layout = {"status": (0, 0, 15)}
        self.cur_h = 112
        self.commands: list[str] = []
        self.flashes: list[str] = []

    def hit_arrow(self, _x, _y):
        return False

    def hit_switch(self, _x, _y):
        return False

    def _send_command(self, action: str) -> None:
        self.commands.append(action)

    def flash(self, text: str) -> None:
        self.flashes.append(text)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    rect = speaker_rect(112, 15)
    check(
        rect[2] >= 22 and rect[3] >= 22
        and 0 <= rect[0] <= 344
        and 0 <= rect[1] <= 112,
        "喇叭图标有独立且足够大的点击区域",
    )
    click = SpeakerClick()
    click.on_press(SimpleNamespace(
        x=rect[0] + rect[2] // 2,
        y=rect[1] + rect[3] // 2,
    ))
    check(
        click.commands == ["toggle-mute"]
        and click.flashes == ["正在打开发声…"],
        "点喇叭只切换 TTS，不触发暂停听音开关",
    )

    created: list[Process] = []

    def fake_spawn(_command, **_kwargs):
        process = Process()
        created.append(process)
        return process

    processes = SpeechProcesses(spawn=fake_spawn, grace=0.01)
    first = processes.spawn(["pythonw.exe", "say.py", "正在念"])
    stopped = processes.set_enabled(False)
    blocked = False
    try:
        processes.spawn(["pythonw.exe", "say.py", "不许启动"])
    except RuntimeError:
        blocked = True
    check(
        stopped == 1 and first.alive is False and blocked,
        "TTS 暂停时先杀掉正在念的进程，并拒绝创建新进程",
    )
    processes.set_enabled(True)
    second = processes.spawn(["pythonw.exe", "say.py", "重新打开"])
    check(processes.enabled() and second.alive,
          "再次点开后才允许启动新的 TTS 进程")
    processes.interrupt()

    mute = {"on": False}
    phone = {"title": "", "id": ""}
    SavedRuntimeTargets(phone, mute).restore({})
    check(
        DEFAULTS["muted"] is True
        and mute["on"] is True
        and not SPEECH_PROCESSES.enabled(),
        "出厂配置和旧配置缺项时都默认暂停 TTS",
    )
    SPEECH_PROCESSES.set_enabled(True)

    startup = (
        APP / "voice_feature" / "runtime_startup_callbacks.py"
    ).read_text(encoding="utf-8")
    preview = (
        APP / "overlay_feature" / "settings_voice_preview_mixin.py"
    ).read_text(encoding="utf-8")
    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check(
        'saved.get("muted", True)' in startup
        and "SPEECH_PROCESSES.set_enabled(not muted)" in startup,
        "启动恢复默认关闭 TTS 并同步底层进程闸门",
    )
    check(
        'self.cfg.get("muted", True)' in preview,
        "暂停状态下设置里的试听也不会启动 TTS",
    )
    check(
        stt.count("not SPEECH_PROCESSES.enabled()") >= 4
        and "朗读开关暂停：开机问候不启动" in stt,
        "普通朗读和开机问候在真正启动前再次检查 TTS 闸门",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
