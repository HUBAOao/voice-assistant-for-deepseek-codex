# -*- coding: utf-8 -*-
"""Exercise the authenticated task endpoints through the real HTTP server."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import phone_link  # noqa: E402


def request(url: str, payload: dict | None = None,
            headers: dict | None = None) -> dict:
    body = None
    headers = dict(headers or {})
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return json.loads(exc.read().decode("utf-8"))


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        os.environ["FIN_DECK_TASKS_FILE"] = str(Path(raw) / "tasks.json")
        os.environ["FIN_DECK_SECURITY_KEY"] = str(Path(raw) / "security-key.bin")
        os.environ["FIN_DECK_SECURITY_POLICY"] = str(Path(raw) / "security-policy.json")
        token = "task-api-test-token"
        link = phone_link.PhoneLink(
            lambda text: None,
            lambda: {"state": "idle"},
            lambda since=0: [],
            port=8794,
            pairing=False,
            token=token,
        )
        assert link.start()
        base = "http://127.0.0.1:8794"
        q = "?k=" + token
        try:
            denied = request(base + "/api/tasks/action" + q, {
                "action": "create", "title": "没有凭据"
            })
            assert not denied["ok"] and denied["need_capability"]
            session = request(base + "/api/security/session" + q)
            assert session["ok"] and session["capability"]
            headers = {"X-FinDeck-Capability": session["capability"]}
            created = request(base + "/api/tasks/action" + q, {
                "action": "create",
                "title": "检查 P1 控制台",
                "thread_id": "thread-p1",
            }, headers)
            assert created["ok"]
            task_id = created["task"]["id"]

            waiting = request(base + "/api/tasks/action" + q, {
                "action": "message",
                "id": task_id,
                "text": "补上测试结果",
            }, headers)
            assert waiting["task"]["messages"][0]["text"] == "补上测试结果"

            listed = request(base + "/api/tasks" + q)
            assert listed["ok"] and listed["items"][0]["id"] == task_id
            assert listed["cursor"] >= 1
            cursor = listed["cursor"]

            unchanged = request(
                base + "/api/tasks?after=" + str(cursor) + "&" + q[1:]
            )
            assert unchanged["ok"] and unchanged["items"] == []
            assert task_id in unchanged["ids"]
            assert unchanged["cursor"] == cursor and not unchanged["reset"]

            second = request(base + "/api/tasks/action" + q, {
                "action": "create",
                "title": "检查增量同步",
            }, headers)
            second_id = second["task"]["id"]
            changed = request(
                base + "/api/tasks?after=" + str(cursor) + "&" + q[1:]
            )
            assert changed["ok"]
            assert [item["id"] for item in changed["items"]] == [second_id]
            assert set(changed["ids"]) == {task_id, second_id}
            assert changed["cursor"] > cursor and not changed["reset"]

            cancelled = request(base + "/api/tasks/action" + q, {
                "action": "cancel",
                "id": task_id,
            }, headers)
            assert cancelled["task"]["status"] == "cancelled"
            security = request(base + "/api/security" + q)
            assert security["ok"] and security["retention"]["max_tasks"] > 0
            agents = request(base + "/api/agents" + q)
            assert agents["ok"] and "worktrees" in agents
            print("test_task_api: PASS")
        finally:
            link.stop()
            os.environ.pop("FIN_DECK_TASKS_FILE", None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
