# -*- coding: utf-8 -*-
"""Verify the split settings panel fades in/out without resizing its parent."""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "anim-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402
from _overlay_test_support import isolate_overlay  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0
    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg["auto_tune"] = False
    isolate_overlay(overlay, S, cfg, app_dir=APP, state="hearing")
    o = overlay.Overlay()
    o.alpha_override = 1.0
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)

    o.set_expanded(True)
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)
    compact = (int(o.cur_w), int(o.cur_h))

    real_step = o._fade_panel_step
    recorded: list[tuple[float, bool]] = []

    def record(token, alpha, hide):
        recorded.append((float(alpha), bool(hide)))
        real_step(token, alpha, hide)

    o._fade_panel_step = record

    recorded.clear()
    o.set_expanded(False)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    down = list(recorded)

    recorded.clear()
    o.set_expanded(True)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    up = list(recorded)
    final_compact = (int(o.cur_w), int(o.cur_h))
    panel_visible = bool(o.panel_win and o.panel_win.winfo_exists()
                         and o.panel_win.state() != "withdrawn")
    o.root.destroy()

    checks = [
        (len(down) == 6 and down[-1][1],
         f"收起按 6 步淡出后 withdraw（实际 {len(down)} 步）"),
        (len(up) == 8 and not any(hide for _alpha, hide in up),
         f"展开按 8 步淡入（实际 {len(up)} 步）"),
        (compact == final_compact,
         f"紧凑主浮窗尺寸不变（{compact} → {final_compact}）"),
        (panel_visible, "展开完成后设置面板实际可见"),
    ]
    for ok, text in checks:
        print(("  ✓ " if ok else "  ✗ ") + text)
        if not ok:
            bad += 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
