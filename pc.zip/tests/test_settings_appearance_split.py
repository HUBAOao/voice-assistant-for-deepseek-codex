# -*- coding: utf-8 -*-
"""Appearance, voice and text actions live outside the overlay shell."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.defaults import CARD, VOICES  # noqa: E402
from overlay_feature.settings_appearance_mixin import (  # noqa: E402
    OverlaySettingsAppearanceMixin,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Chip:
        def __init__(self) -> None:
            self.options = {}

        def config(self, **options) -> None:
            self.options.update(options)

    class Label(Chip):
        pass

    class Slider:
        def __init__(self, value: int) -> None:
            self.value = value

        def get(self) -> int:
            return self.value

        def set(self, value: int) -> None:
            self.value = value

    class Root:
        def __init__(self) -> None:
            self.geometry_text = ""

        def geometry(self, value: str) -> None:
            self.geometry_text = value

    class Probe(OverlaySettingsAppearanceMixin):
        def __init__(self) -> None:
            self.cfg = {"voice_preset": 2}
            self.button_color = "#2277cc"
            self.root = Root()
            self.bg_label = Label()
            self.voice_label = Label()
            self.voice_index = 0
            self.wave_style_value = "siri"
            self.style_chips = {"siri": Chip(), "bars": Chip()}
            self.perf_value = "quality"
            self.perf_chips = {"eco": Chip(), "quality": Chip()}
            self.name_freq_value = "少"
            self.name_freq_chips = {"少": Chip(), "多": Chip()}
            self.self_freq_value = "少"
            self.self_freq_chips = {"少": Chip(), "多": Chip()}
            self.sl_anim = Slider(60)
            self.changes = 0

        def on_change(self) -> None:
            self.changes += 1

    probe = Probe()
    check(probe._rate_value("+18%") == 18.0 and probe._rate_value("坏值") == 8.0,
          "语速解析保留合法值并安全回退")
    check(probe._voice_index() == 0, "越界音色预设安全回退到第一项")
    probe.voice_index = len(VOICES) - 1
    check(probe._voice_text() == VOICES[-1][1], "音色标签仍来自同一份预设表")

    probe.set_bg("C:/tmp/背景.png")
    check(probe.bg_path.endswith("背景.png") and probe.bg_label.options["text"] == "背景.png",
          "背景选择仍即时写回标签")
    probe.set_wave_style("bars")
    check(probe.style_chips["bars"].options["bg"] == "#2277cc"
          and probe.style_chips["siri"].options["bg"] == CARD,
          "波形样式仍用主题色标出当前项")
    probe.set_perf("eco")
    check(probe.sl_anim.get() == 20 and probe.perf_chips["eco"].options["bg"] == "#2277cc",
          "性能档仍同步动画滑块与高亮")
    probe.set_name_freq("多")
    probe.set_self_freq("多")
    check(probe.name_freq_chips["多"].options["bg"] == "#2277cc"
          and probe.self_freq_chips["多"].options["bg"] == "#2277cc",
          "称呼频率行为保持不变")
    check(probe.changes >= 5, "每个设置动作仍触发统一即时预览")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    module = (APP / "overlay_feature" / "settings_appearance_mixin.py").read_text(
        encoding="utf-8"
    )
    for marker in (
        "def _entry(",
        "def edit_text(",
        "def set_autostart(",
        "def apply_size(",
        "def preview_voice(",
    ):
        check(marker in module and marker not in overlay,
              f"设置动作 {marker} 已迁出 overlay.py")
    check("OverlaySettingsAppearanceMixin" in overlay,
          "悬浮窗仍通过混入组合原设置动作")
    check("def _overlay_inputlog(" in overlay,
          "迁移后的文字编辑仍走悬浮窗原输入日志入口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
