# -*- coding: utf-8 -*-
"""Sending and connection settings stay composable without a native window."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_connection_mixin import (  # noqa: E402
    OverlaySettingsConnectionMixin,
)
from overlay_feature.settings_recognition_mixin import (  # noqa: E402
    OverlaySettingsRecognitionMixin,
)
from overlay_feature.settings_delivery_mixin import (  # noqa: E402
    OverlaySettingsDeliveryMixin,
)
from overlay_feature.settings_send_mixin import (  # noqa: E402
    OverlaySettingsSendMixin,
)


class Probe(OverlaySettingsDeliveryMixin):
    def __init__(self) -> None:
        self.calls: list[str] = []

    def build_send_controls(self, parent) -> None:
        self.calls.append("send")

    def build_connection_controls(self, parent) -> None:
        self.calls.append("connection")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    probe = Probe()
    probe.build_delivery_section(object())
    check(probe.calls == ["send", "connection"],
          "历史 build_delivery_section 仍按发送、连接顺序组合")
    check(OverlaySettingsDeliveryMixin.__mro__[1:3]
          == (OverlaySettingsSendMixin, OverlaySettingsConnectionMixin),
          "历史业务类同时保留发送与连接两个独立边界")
    check(
        OverlaySettingsSendMixin.build_send_controls.__module__
        == "overlay_feature.settings_send_mixin",
        "发送方式与本地投递开关由 sending 模块提供",
    )
    check(
        OverlaySettingsConnectionMixin.build_connection_controls.__module__
        == "overlay_feature.settings_connection_mixin",
        "历史 connection 入口继续负责组合连接设置",
    )
    check(
        OverlaySettingsConnectionMixin.build_recognition_controls
        is OverlaySettingsRecognitionMixin.build_recognition_controls,
        "识别模型与语言控件由独立识别模块提供",
    )

    delivery = (
        APP / "overlay_feature" / "settings_delivery_mixin.py"
    ).read_text(encoding="utf-8")
    send = (
        APP / "overlay_feature" / "settings_send_mixin.py"
    ).read_text(encoding="utf-8")
    connection = (
        APP / "overlay_feature" / "settings_connection_mixin.py"
    ).read_text(encoding="utf-8")
    recognition = (
        APP / "overlay_feature" / "settings_recognition_mixin.py"
    ).read_text(encoding="utf-8")
    pages = (
        APP / "overlay_feature" / "settings_pages_mixin.py"
    ).read_text(encoding="utf-8")
    check(len(delivery.splitlines()) < 40,
          "投递兼容入口不再承载二百多行控件业务")
    check("self._group(parent, \"说话方式\")" in send
          and "self._group(parent, \"发送\")" in send
          and "手机网址" not in send,
          "发送模块同时构建说话方式与本地发送选项")
    check("手机网址" in connection
          and "self.build_recognition_controls(parent)" in connection
          and "识别模型" not in connection
          and "发送方式" not in connection,
          "连接模块只组合手机外网设备与独立识别边界")
    check("self._group(parent, \"识别\")" in recognition
          and "识别模型" in recognition
          and "识别语言" in recognition
          and "手机网址" not in recognition,
          "识别模块承载模型、语言、重启和录音提示")
    check("self.build_delivery_section(parent)" in pages,
          "主设置页的调用入口和顺序保持不变")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
