# -*- coding: utf-8 -*-
"""Win32 calls remain behind the overlay platform boundary."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import window_control  # noqa: E402


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    check(window_control.window_handles(0) == [], "空窗口句柄安全返回")
    check(not window_control.grab_foreground(0), "空焦点操作安全返回")
    enabled = window_control.enable_precise_timer(1)
    if enabled:
        window_control.disable_precise_timer(1)
    check(enabled == (os.name == "nt"), "高精度定时器只在 Windows 启用")
    window_control.refresh_window_tree(0)
    check(True, "空重绘请求不抛异常")

    with tempfile.TemporaryDirectory(prefix="findeck_window_") as raw:
        folder = Path(raw) / "export"
        folder.mkdir()
        hidden = window_control.hide_path(folder)
        check(hidden, "导出目录隐藏属性设置成功")
        if os.name == "nt":
            check(bool(folder.stat().st_file_attributes & 0x02),
                  "Windows 隐藏属性真实写入")
        else:
            check(True, "非 Windows 保持无操作兼容")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    control = (APP / "overlay_feature" / "window_control.py").read_text(
        encoding="utf-8"
    )
    for marker in (
        "ctypes.windll",
        "RedrawWindow",
        "timeBeginPeriod",
        "SetFileAttributesW",
        "GetParent(",
    ):
        check(marker not in overlay, f"overlay.py 不再内联 {marker}")
    check("_window_control.refresh_window_tree" in overlay,
          "重绘交给平台边界")
    check("_window_control.hide_path" in overlay,
          "目录隐藏交给平台边界")
    check("finally:" in control and "AttachThreadInput" in control,
          "前台焦点抢占失败也会解除线程输入附着")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
