# -*- coding: utf-8 -*-
"""Failure reporting and shutdown keep running after individual errors."""
from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_lifecycle import RuntimeLifecycle  # noqa: E402
from voice_feature.runtime_teardown import (  # noqa: E402
    handle_runtime_failure,
    shutdown_runtime,
)


class Status:
    def __init__(self, events: list[str], fail: bool = False) -> None:
        self.events = events
        self.fail = fail

    def set(self, state: str, **_options) -> None:
        self.events.append("status:" + state)
        if self.fail:
            raise RuntimeError("status unavailable")


class Guard:
    def __init__(self, events: list[str], fail: bool = False) -> None:
        self.events = events
        self.fail = fail

    def release(self) -> None:
        self.events.append("guard:release")
        if self.fail:
            raise RuntimeError("release failed")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_teardown_") as raw:
        crash = Path(raw) / "last-crash.txt"
        events: list[str] = []
        sleeps: list[float] = []
        try:
            handle_runtime_failure(
                RuntimeError("模型断开"),
                crash_file=crash,
                syslog=lambda kind, text: events.append(
                    f"syslog:{kind}:{text}"
                ),
                speak=lambda text: events.append("speak:" + text),
                emit=lambda text: events.append(
                    "emit:" + text.strip()[:8]
                ),
                now=lambda: datetime(2026, 10, 23, 21, 30, 5),
                sleep=sleeps.append,
            )
        except SystemExit as exc:
            check(exc.code == 3, "运行异常仍使用原退出码 3")
        else:
            bad += 1
            print("  ✗ 运行异常没有退出")
        saved = crash.read_text(encoding="utf-8")
        check("2026-10-23 21:30:05" in saved
              and "RuntimeError: 模型断开" in saved,
              "崩溃文件保留时间、类型和详情")
        check(any(item.startswith("syslog:错:") for item in events)
              and any(item.startswith("speak:") for item in events)
              and sleeps == [2],
              "异常记录、播报提示和两秒重启等待都保留")

        lifecycle = RuntimeLifecycle()
        order: list[str] = []
        lifecycle.register_closeable(
            "microphone", lambda: order.append("microphone")
        )
        lifecycle.register_closeable(
            "overlay",
            lambda: (_ for _ in ()).throw(RuntimeError("overlay stuck")),
        )
        lifecycle.register_closeable(
            "tracker", lambda: order.append("tracker")
        )
        shutdown_events: list[str] = []
        errors = shutdown_runtime(
            lifecycle,
            Guard(shutdown_events),
            status=Status(shutdown_events, fail=True),
            syslog=lambda kind, text: shutdown_events.append(
                f"syslog:{kind}"
            ),
            emit=lambda text: shutdown_events.append("emit"),
        )
        check(order == ["tracker", "microphone"],
              "悬浮窗清理失败不会跳过追踪器和麦克风")
        check("emit" in shutdown_events
              and "status:offline" in shutdown_events
              and "guard:release" in shutdown_events,
              "离线状态失败后仍会清理生命周期并释放实例")
        check([name for name, _error in errors] == ["status", "overlay"],
              "退出错误按资源名完整交付给诊断")
        check(shutdown_runtime(
            lifecycle,
            Guard(shutdown_events),
            status=Status(shutdown_events),
            syslog=lambda *_args: None,
            emit=lambda *_args: None,
        ) == [],
            "重复退出不会重复关闭资源")

        stt = (APP / "stt.py").read_text(encoding="utf-8")
        run_assembly = (
            APP / "voice_feature" / "runtime_run_assembly.py"
        ).read_text(encoding="utf-8")
        foreground = (
            APP / "voice_feature" / "runtime_foreground_assembly.py"
        ).read_text(encoding="utf-8")
        prepared = (
            APP / "voice_feature" / "runtime_main_foreground.py"
        ).read_text(encoding="utf-8")
        check("return run_prepared_foreground(" in stt
              and "return assemble_foreground_runtime(" in prepared
              and "return run_voice_runtime(" in foreground
              and "handle_runtime_failure(" in run_assembly
              and "shutdown_runtime(" in run_assembly
              and "import traceback\n" not in stt.split(
                  "def main()", 1
              )[-1],
              "main() 只调用已准备前台装配，不再内联崩溃与清理实现")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
