# -*- coding: utf-8 -*-
"""Round 121 native header visual parity regression."""
from __future__ import annotations

import sys
import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    header_start = activity.index("private View buildHeader()")
    header_end = activity.index("private View buildFooter()", header_start)
    header = activity[header_start:header_end]

    print("① 旧页面最终规格")
    check(
        "header #spk { display:none !important; }" in page,
        "旧页面最终 CSS 无条件隐藏页头扬声器状态",
    )

    print("\n② 原生页头对齐")
    check(
        "speakerState = new ImageView(this);" in header,
        "原生页头不再把扬声器状态当成可见控件",
    )
    check(
        "speakerState.setVisibility(View.GONE);" in header,
        "隐藏状态在加入页头前已明确设为 GONE",
    )

    spec = importlib.util.spec_from_file_location("round121_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        version.PHONE_VERSION == f"1.{len(version.PHONE_CHANGELOG)}",
        f"手机端版本由变更表推导为 v{version.PHONE_VERSION}",
    )
    check(
        any(
            "页头视觉对齐" in item
            for item in version.PHONE_CHANGELOG
        ),
        "手机端变更表保留本轮页头视觉修复",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
