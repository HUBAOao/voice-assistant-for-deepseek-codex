# -*- coding: utf-8 -*-
"""验收「手机 APP 一键更新」：设置里那个常驻入口 + 真能装上的那条路。

以前用不了的原因有三条，这个测试就盯着这三条：
  ① 网页给的是**相对地址**（Uri.parse 打不开）→ 现在必须给绝对地址
  ② 以前只是把浏览器叫起来 → 现在是 APP 自己下载 + 拉起系统安装器
  ③ 安卓 8+ 要先允许「安装未知应用」→ 现在没权限会带用户去开，回来接着下
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
AND = ROOT / "work" / "android-app"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    java = (AND / "java" / "com" / "hubao" / "voiceassistant"
            / "MainActivity.java").read_text(encoding="utf-8")
    provider = (AND / "java" / "com" / "hubao" / "voiceassistant"
                / "UpdateProvider.java")
    man = (AND / "AndroidManifest.xml").read_text(encoding="utf-8")

    print("① 设置里那个常驻入口")
    check('id="updbtn"' in page and 'id="updnow"' in page,
          "设置面板里有「更新」那一行（状态文字 + 按钮）")
    check("function refreshUpdRow" in page, "有刷新那一行的函数")
    check("refreshUpdRow();" in page.split("async function checkUpdate")[-1],
          "页面一进来就会顺便把这一行刷新（不用你自己去找）")
    check('btn.textContent = "一键更新"' in page, "有新版时按钮变成「一键更新」")
    check("已经是最新" in page, "没新版时明说「已经是最新」")

    print("② 地址必须是绝对的（以前就是栽在这）")
    check("location.origin + \"/app.apk" in page,
          "下载地址用 location.origin 拼成绝对地址")
    check("absoluteUrl" in java, "Java 那边也会兜底把相对地址补全")
    check('Uri.parse(url)' not in java.split("openUpdate")[1][:400],
          "openUpdate 不再直接把地址丢给浏览器")

    print("③ APP 自己下载 + 拉起安装器")
    check("downloadAndInstall" in java, "有下载函数")
    check("HttpURLConnection" in java and "update.apk" in java,
          "自己把新版下到本机 update.apk")
    check("application/vnd.android.package-archive" in java,
          "下载完按 APK 类型交给系统")
    check("content://" in java and "UpdateProvider.AUTHORITY" in java,
          "用 content:// 递文件（安卓 7 以后不许用 file://）")
    check(provider.exists() and "extends ContentProvider" in
          (provider.read_text(encoding="utf-8") if provider.exists() else ""),
          "自带的迷你 FileProvider（UpdateProvider）在")
    check("canRequestPackageInstalls" in java
          and "ACTION_MANAGE_UNKNOWN_APP_SOURCES" in java,
          "安卓 8+ 会先检查/带你去开「安装未知应用」")
    check("protected void onResume" in java and "pendingUpdateUrl" in java,
          "开完权限回来会自动接着下")

    print("④ 清单里该有的东西")
    check("REQUEST_INSTALL_PACKAGES" in man, "有 REQUEST_INSTALL_PACKAGES 权限")
    check("com.hubao.voiceassistant.updates" in man and "<provider" in man,
          "provider 声明和代码里的 authority 对得上")

    print("⑤ 打出来的 APK 里真的有这些")
    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    check(apk.exists(), f"APK 在（{apk.stat().st_size / 1024:.0f} KB）" if apk.exists() else "APK 不在")
    if apk.exists():
        z = zipfile.ZipFile(apk)
        dex = b"".join(z.read(n) for n in z.namelist() if n.endswith(".dex"))
        for needle, what in ((b"UpdateProvider", "UpdateProvider 类"),
                             (b"canRequestPackageInstalls", "权限检查"),
                             (b"com.hubao.voiceassistant.updates", "authority")):
            check(needle in dex, f"dex 里有 {what}")
        print("     phone-version.txt =",
              (APP / "phone-version.txt").read_text(encoding="utf-8").strip())
        check("1.21" in (APP / "phone-version.txt").read_text(encoding="utf-8"),
              "手机端版本已经是 1.21（有新版手机才会提示更新）")
    # 手机页面下载到的必须就是这一个 APK（不然"一键更新"装了个旧包）
    same = (APP / "语音助手-手机端.apk")
    check(same.exists() and same.stat().st_size == apk.stat().st_size,
          "手机入口发出去的那个 APK 和刚打的是同一个")

    print("⑥ 电脑那边报的版本号")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8801)
    if link.start():
        try:
            time.sleep(0.2)
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/api/version?k={link.token}", timeout=8) as r:
                d = json.loads(r.read().decode("utf-8"))
            check(str(d.get("phone")) == "1.21", f"/api/version 报手机端 {d.get('phone')}")
            check(int(d.get("apk_kb") or 0) > 400, f"APK 大小报的是 {d.get('apk_kb')} KB")
            check(d.get("apk") == "语音助手-手机端.apk", f"APK 名字：{d.get('apk')}")
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/app.apk?k={link.token}", timeout=20) as r:
                body = r.read()
            check(body[:2] == b"PK" and len(body) > 400 * 1024,
                  f"/app.apk 真能下到一个完整 APK（{len(body) / 1024:.0f} KB）")
        finally:
            link.stop()
    else:
        check(False, "手机入口起不来，跳过")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
