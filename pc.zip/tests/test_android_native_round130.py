# -*- coding: utf-8 -*-
"""Round 130 native settings drawer parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
SETTINGS_JS = (
    ROOT
    / "outputs"
    / "voice-to-text"
    / "phone_feature"
    / "ui"
    / "settings.js"
)
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start: str, end: str) -> str:
    return source.split(start, 1)[-1].split(end, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    settings_js = SETTINGS_JS.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    settings = method_block(
        activity,
        "private void showSettings(String initialCategory)",
        "private LinearLayout settingsAccordion(",
    )
    accordion = method_block(
        activity,
        "private LinearLayout settingsAccordion(",
        "private void closeOtherSettingsSections(",
    )
    accordion_body = method_block(
        activity,
        "private void toggleMeasuredHeight(",
        "private void smoothScrollSettingsSection(",
    )
    appearance = method_block(
        activity,
        "private void populateNativeAppearance(",
        "private void applyNativeBackground(",
    )
    connection = method_block(
        activity,
        "private void populateNativeConnection(",
        "private void loadNativeAbout(",
    )
    about = method_block(
        activity,
        "private void loadNativeAbout(",
        "private boolean setNotificationDone(",
    )

    print("① 旧页设置最终规格")
    check(
        "width:84% !important; max-width:380px !important"
        in page
        and "background:rgba(27,27,31,.54) !important" in page
        and "backdrop-filter:blur(28px) saturate(170%)" in page,
        "设置抽屉与左侧会话抽屉同为 84%/380px、54% 底和 28px 毛玻璃",
    )
    check(
        "padding:18px 16px !important" in page
        and "#sheethead h4 { font-size:var(--fs-mid)" in page
        and "min-height:40px !important; padding:0 14px !important"
        in page,
        "设置头为 18/16px 内边距、14px 标题和 40px 关闭键",
    )
    check(
        "min-height:82px !important" in page
        and "padding:14px 16px !important" in page
        and ".settings-cat-head b { font-size:15px !important; }" in page,
        "分类头为 82px 高、14/16px 内边距和 15px 标题",
    )
    check(
        "border-bottom:1px solid rgba(255,255,255,.07)" in page
        and "background:rgba(255,255,255,.035) !important" in page
        and "width:9px; height:9px" in page,
        "分类有 1px 分隔线、展开淡底和 9px 箭头",
    )
    check(
        "padding:4px 16px 16px" in page
        and "max-height:0; overflow:hidden; opacity:0"
        in page,
        "展开分组为 4/16/16px 内边距并从零高度展开",
    )
    check(
        "padding:9px 11px; border-radius:9px" in page
        and "background:var(--line); color:var(--fg); border-radius:9px"
        in page
        and "background:var(--accent); color:var(--accent-ink)"
        in page,
        "设置输入为 9/11px 圆角输入，按钮 chip 为 LINE 底和 ACCENT 选中态",
    )
    check(
        "width:30px; height:30px; border-radius:50%" in page
        and "border:2px solid transparent" in page,
        "主题色板为 30px 圆形和选中描边",
    )
    check(
        "#sheetdone { width:calc(100% - 32px) !important;"
        " margin:12px 16px 18px !important; }" in page
        and ".done { background:transparent; color:var(--accent)"
        in page,
        "好了按钮为透明 ACCENT 文字和 12/16/18px 外边距",
    )
    check(
        "background:var(--line);border-radius:0;padding:10px 12px"
        in page
        and "font-size:12px;line-height:1.75" in page,
        "关于块为 LINE 底、直角、10/12px 内边距和 1.75 行高",
    )
    check(
        "function closeSettingsCats()" in settings_js
        and "function openSettingsCat(name)" in settings_js
        and "closeSettingsCats();" in settings_js,
        "旧设置分类保持单开互斥和按内容高度展开",
    )

    print("\n② 原生设置抽屉")
    check(
        "Math.round(getResources().getDisplayMetrics().widthPixels * 0.84f)"
        in settings
        and "NativeTheme.dp(this, 380)" in settings
        and "Color.argb(\n                138, 27, 27, 31"
        in settings,
        "原生抽屉宽度、全高和 54% 玻璃底保持",
    )
    check(
        'NativeTheme.text(this, "设置", 14' in settings
        and "NativeTheme.dp(this, 16), NativeTheme.dp(this, 18),"
        in settings
        and "NativeTheme.dp(this, 40)" in settings
        and "NativeTheme.LINE, 8, this" in settings,
        "设置头恢复 14px、18/16px 内边距和 40px LINE 关闭键",
    )
    check(
        "settings.setPadding(0, 0, 0" in settings
        and "settings-section-divider" in accordion
        and "Color.argb(9, 255, 255, 255)" in accordion
        and "SettingsChevron" in accordion,
        "分类容器去掉双重边距，并恢复分隔线、展开淡底和几何箭头",
    )
    check(
        "targetTop = expand ? NativeTheme.dp(this, 4)" in accordion_body
        and "targetBottom = expand ? NativeTheme.dp(this, 16)"
        in accordion_body
        and "closeOtherSettingsSections(parent, section)" in accordion,
        "原生展开分组继续 4/16/16px 且保持单开互斥",
    )
    check(
        "settingsTextInput(" in settings
        and "settingsTextInput(" in appearance
        and "setPadding(NativeTheme.dp(this, 11)" in activity
        and "setStroke(NativeTheme.dp(this, 1), NativeTheme.LINE)"
        in activity
        and "setCornerRadius(NativeTheme.dp(this, 9))" in activity,
        "设置输入恢复 14px、9/11px 内边距、1px 边框和 9px 圆角",
    )
    check(
        "settingsChip(" in settings
        and "settingsChip(" in appearance
        and "settingsChip(" in connection
        and "NativeTheme.LINE, 9, this" in activity
        and "NativeTheme.ACCENT_INK" in activity,
        "设置 chip 恢复 LINE 底、ACCENT 选中和 14px 字",
    )
    check(
        "accentSwatches" in appearance
        and "NativeTheme.dp(this, 30), NativeTheme.dp(this, 30)"
        in appearance
        and "background.setStroke(" in activity
        and "selected ? NativeTheme.TEXT : Color.TRANSPARENT"
        in activity,
        "原生主题色板恢复 30px 圆形与 2px 选中描边",
    )
    check(
        "NativeTheme.text(this, \"好了\", 14, NativeTheme.ACCENT)"
        in settings
        and "settings.addView(done" in settings
        and "doneParams.setMargins(" in settings
        and "NativeTheme.dp(this, 16), NativeTheme.dp(this, 12),"
        in settings
        and "NativeTheme.dp(this, 16), NativeTheme.dp(this, 18)"
        in settings,
        "原生好了按钮恢复透明 ACCENT 文字和 12/16/18px 外边距",
    )
    check(
        "NativeTheme.LINE" in settings
        and "aboutBox.setLineSpacing(0f, 1.75f)" in settings
        and "setPadding(NativeTheme.dp(this, 12), NativeTheme.dp(this, 10),"
        in settings,
        "原生关于块恢复 LINE 底和 1.75 行高",
    )
    check(
        "appendSettingsAboutLine(text, free, NativeTheme.ACCENT, 1f)"
        in about
        and "new android.text.style.ForegroundColorSpan(color)" in about
        and "new android.text.style.RelativeSizeSpan(size)" in about,
        "关于块恢复作者/版权/自由使用/提示的分层颜色与字号",
    )
    check(
        'TextView petOn = settingsChip("开")' in settings
        and 'TextView petOff = settingsChip("关")' in settings
        and 'settingsChip("开")' in connection
        and 'settingsChip("关")' in connection,
        "桌宠与通知开关改用旧页 chip，不再使用普通按钮",
    )
    check(
        "updateAction.setTextSize(13)" in settings
        and "NativeTheme.dp(this, 34)" in settings
        and "NativeTheme.LINE, 9, this" in settings,
        "检查更新恢复 34px 高、13px 字 LINE 按钮",
    )
    check(
        "setDimAmount(0.45f)" in settings
        and "settingsPageCurrent(" in activity
        and "setNotificationDone(" in activity
        and "confirmNotificationSwitch(" in activity
        and "settingsInitialCategoryCue" in activity,
        "遮罩、权限、系统页返回、保存、危险确认与代际语义保持不变",
    )
    check(
        "settingsTwoColumn(retentionDays, retentionTasks)"
        in activity
        and "settingsTwoColumn(ttl, rotateDays)" in activity
        and "styleSettingsActionButton(saveRetention, false)"
        in activity
        and "settingsTextInput(hint)" in activity,
        "安全数值恢复两列 36px 输入与 44px 同组动作，保留原有校验和危险确认",
    )

    spec = importlib.util.spec_from_file_location("round130_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("第一百三十轮" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录设置页收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"SettingsChevron" in dex
            and b"settingsTextInput" in dex,
            "APK/DEX 含新设置头、输入和分类箭头实现",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
