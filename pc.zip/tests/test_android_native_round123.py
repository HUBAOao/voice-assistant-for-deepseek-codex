# -*- coding: utf-8 -*-
"""Round 123 task page and shared task-action geometry parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    task_start = activity.index("private void renderTasks(")
    task_end = activity.index("private String taskStatusText(", task_start)
    tasks = activity[task_start:task_end]
    plugin_start = activity.index("private void loadPluginsInto(")
    plugin_end = activity.index("private String joinJsonArray(", plugin_start)
    plugins = activity[plugin_start:plugin_end]
    acceptance_start = activity.index("private void addAcceptanceTools(")
    acceptance_end = activity.index("private void acceptanceMark(", acceptance_start)
    acceptance = activity[acceptance_start:acceptance_end]

    print("① 旧任务页最终规格")
    check(
        ".taskCompose {" in page
        and "grid-template-columns:minmax(0,1fr) 52px; gap:0;" in page
        and "height:44px; margin-bottom:10px;" in page,
        "任务输入为 44px 连续 1fr+52px 网格",
    )
    check(
        "background:rgba(255,255,255,.045);" in page
        and "border-left:2px solid rgba(255,255,255,.12);" in page
        and ".taskCard.approval { border-left-color:#ffb020; }" in page,
        "任务卡固定淡底，只用 2px 左边线表示状态",
    )
    check(
        ".taskStatus {" in page
        and "padding:3px 7px;" in page
        and "font-size:10px;" in page,
        "任务状态是 10px 内联标签",
    )
    check(
        ".taskActions button {" in page
        and "height:40px; border:0; border-radius:0;" in page
        and "background:rgba(255,255,255,.055);" in page,
        "共享 taskActions 为 40px 直角零间隙按钮",
    )
    check(
        ".taskMessage {" in page
        and "grid-template-columns:minmax(0,1fr) 34px 34px; gap:0;" in page
        and "border-left:1px solid rgba(255,255,255,.06);" in page,
        "排队消息为正文加两个 34px 直角操作列",
    )

    print("\n② 原生任务页结构")
    check(
        "taskCardBackground(" in tasks
        and "new LayerDrawable(" in activity
        and "setLayerWidth(1, NativeTheme.dp(this, 2))" in activity,
        "原生任务卡恢复固定底和 2px 状态左边线",
    )
    check(
        "taskStatusBadge(" in tasks
        and "Color.argb(31, Color.red(NativeTheme.ACCENT),"
        in activity
        and "Color.green(NativeTheme.ACCENT),"
        in activity,
        "原生状态恢复 10px 直角内联标签",
    )
    check(
        "taskMetaText(" in tasks
        and "NativeTheme.text(this, text, 10, NativeTheme.DIM)"
        in activity
        and "card.addView(detail, matchWidthTop(6));" in tasks,
        "原生任务元信息恢复 10px 与 6px 间距",
    )
    check(
        "taskApprovalPanel(" in tasks
        and "Color.rgb(255, 210, 138)" in activity
        and "font:11px/1.55" not in activity,
        "原生批准风险块恢复琥珀底、直角和等宽小字",
    )
    check(
        "flatActionGrid(" in tasks
        and "flatActionButton(" in tasks
        and "NativeTheme.dp(this, 40)" in tasks,
        "任务操作改用共享 40px 直角零间隙网格",
    )
    check(
        "flatMessageRow(" in tasks
        and "NativeTheme.dp(this, 34)" in tasks,
        "排队消息恢复 1fr+34px+34px 操作列",
    )

    print("\n③ 扩展与验收复用共享动作")
    check(
        "flatActionGrid(" in plugins
        and "flatActionButton(" in plugins,
        "扩展页改用同一套 taskActions 直角网格",
    )
    check(
        "flatActionGrid(" in acceptance
        and "flatActionButton(" in acceptance,
        "验收页改用同一套 taskActions 直角网格",
    )

    spec = importlib.util.spec_from_file_location(
        "round123_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any(
            "任务页与共享动作" in item
            for item in version.PHONE_CHANGELOG
        ),
        f"手机端 v{version.PHONE_VERSION} 变更表记录本轮任务控件收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"taskCardBackground" in dex
            and b"flatActionGrid" in dex
            and b"flatMessageRow" in dex,
            "APK/DEX 包含任务卡、共享动作网格和消息行",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
