# -*- coding: utf-8 -*-
"""Round 129 native conversation drawer parity."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
CONVERSATIONS_JS = (
    ROOT
    / "outputs"
    / "voice-to-text"
    / "phone_feature"
    / "ui"
    / "conversations.js"
)
ACTIVITY = (
    ROOT
    / "work"
    / "android-app"
    / "java"
    / "com"
    / "hubao"
    / "voiceassistant"
    / "NativeFinDeckActivity.java"
)
SEARCH_ICON = (
    ROOT
    / "work"
    / "android-app"
    / "res"
    / "drawable"
    / "ic_findeck_search.xml"
)
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def method_block(source: str, start_marker: str, end_marker: str) -> str:
    return source.split(start_marker, 1)[-1].split(end_marker, 1)[0]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    page = PAGE.read_text(encoding="utf-8")
    conversations = CONVERSATIONS_JS.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    final_css = page.split(
        "/* ===== Codex 风格会话切换页 ===== */", 1
    )[-1].split("</style>", 1)[0]
    drawer = method_block(
        activity,
        "private void renderConversationDialogAt(",
        "private int conversationDrawerWidth()",
    )
    conversation_list = method_block(
        activity,
        "private void renderConversationList(",
        "private void addConversationDiffBanner(",
    )
    group = method_block(
        activity,
        "private void addConversationGroup(",
        "private void addAutoConversationRow(",
    )
    row = method_block(
        activity,
        "private void addConversationRow(",
        "private void addConversationDiffBanner(",
    )
    modals = method_block(
        activity,
        "private void renameConversation(",
        "private void conversationAction(",
    )

    print("① 旧页会话抽屉最终规格")
    check(
        "padding:16px 14px 10px" in final_css
        and "grid-template-columns:minmax(0,1fr) 38px 38px"
        in final_css
        and "font-size:18px" in final_css,
        "旧页标题栏为 18px 标题、38px 新建/关闭按钮和 16/14/10px 内边距",
    )
    check(
        "grid-template-columns:18px minmax(0,1fr) 34px" in final_css
        and "min-height:38px; padding:8px 6px 3px" in final_css
        and "font-size:11px; font-weight:600" in final_css,
        "旧页分组头为 18/正文/34 三列、38px 高、11px 半粗字",
    )
    check(
        "grid-template-columns:9px minmax(0,1fr) 30px" in final_css
        and "padding:10px 8px 9px 10px" in final_css
        and "width:7px; height:7px; margin-top:5px; border-radius:50%"
        in final_css,
        "旧页会话行为 9/正文/30 三列、10/8/9/10px 内边距和 7px 未读点",
    )
    check(
        "font-size:14px !important" in final_css
        and "font-size:11px;" in final_css
        and "font-size:9px; line-height:1.2" in final_css,
        "旧页行标题、预览和元信息分别为 14/11/9px",
    )
    check(
        "height:42px !important" in final_css
        and "font-size:12px !important" in final_css
        and "background:rgba(255,255,255,.018) !important" in final_css,
        "旧页四分类标签为 42px 高、12px 字和独立淡底单元",
    )
    check(
        "padding:6px 8px 26px !important" in final_css
        and "padding:30px 18px" in final_css,
        "旧页列表内边距为 6/8/26px，空态为 30/18px",
    )
    check(
        "#convDialog { left:18px; right:18px" in final_css
        and "border-radius:16px" in final_css
        and "height:44px; padding:0 12px; border:1px solid"
        in final_css
        and "gap:2px; max-height:42vh" in final_css,
        "旧页会话对话框为 18px 侧距、16px 圆角、44px 输入框和 42vh 选择区",
    )

    print("\n② 原生抽屉、列表与操作层")
    check(
        'NativeTheme.text(this, "对话", 18' in drawer
        and "NativeTheme.dp(this, 38), NativeTheme.dp(this, 38)"
        in drawer
        and "setStroke" not in drawer,
        "原生标题恢复 18px 和两个 38px 方角入口",
    )
    check(
        "ic_findeck_search" in drawer
        and 'conversationSearchInput("搜索对话或项目")' in drawer
        and "clearSearch.setVisibility" in drawer
        and "View.INVISIBLE" in drawer
        and "searchInputParams.leftMargin = NativeTheme.dp(this, 7);"
        in drawer
        and "NativeTheme.dp(this, 40)" in drawer,
        "原生搜索恢复图标、40px 胶囊、7px 列距和按内容显隐的清空按钮",
    )
    check(
        "NativeTheme.dp(this, 42)" in drawer
        and "this, tabLabels[i], 12" in drawer
        and "Color.argb(5, 255, 255, 255)" in drawer,
        "原生分类标签恢复 42px、12px 字和独立淡底单元",
    )
    check(
        "NativeTheme.dp(this, 8), NativeTheme.dp(this, 6),"
        in drawer
        and "NativeTheme.dp(this, 26)" in drawer,
        "原生列表恢复 6/8/26px 内边距",
    )
    check(
        "FrameLayout head" in group
        and "NativeTheme.text(this, title, 11, NativeTheme.DIM)"
        in group
        and "NativeTheme.dp(this, 34)" in group
        and "NativeTheme.dp(this, 28), NativeTheme.dp(this, 28)"
        in group
        and 'chevron.setText("⌄")' in group
        and "setRotation(collapsed.contains(key) ? -90f : 0f)"
        in group,
        "原生分组头恢复三列、34px 计数列、28px 新建按钮和折叠旋转",
    )
    check(
        "conversationUnreadDot(" in row
        and "NativeTheme.dp(this, 9)" in row
        and "NativeTheme.dp(this, 30)" in row
        and "this, previewText, 11"
        in row
        and "setLineSpacing(0f, 1.35f)" in row
        and "NativeTheme.dp(this, 28), NativeTheme.dp(this, 28)"
        in row,
        "原生活会话行恢复 9/正文/30 网格、7px 未读点、14/11/9px 文字和 28px 菜单",
    )
    check(
        "NativeTheme.rounded(" in row
        and "12,\n                this" in row
        and "row.setAlpha(.72f)" in row
        and '"电脑正打开",\n                        NativeTheme.ACCENT'
        in row,
        "原生选中淡底/左侧强调、归档透明度和状态徽标颜色",
    )
    check(
        "conversationEmptyText(" in conversation_list
        and "NativeTheme.dp(this, 30)" in activity
        and "NativeTheme.dp(this, 18)" in activity,
        "原生无结果收敛为旧页 30/18px 居中空态",
    )
    check(
        "conversationDialogPanel(" in modals
        and "NativeTheme.dp(this, 12), NativeTheme.dp(this, 10),"
        in activity
        and "NativeTheme.dp(this, 12), NativeTheme.dp(this, 16)"
        in activity
        and 'conversationDialogInput("会话名称")' in modals
        and "setMaxHeight(NativeTheme.dp(this, 44))" in activity
        and "MaxHeightScrollView choices" in modals
        and "setMaxHeight(Math.max(" in modals,
        "原生重命名/项目选择对话框恢复 12/10/12/16px、44px 输入和 42vh 上限",
    )
    check(
        "setDimAmount(.58f)" in activity
        and "dismissNativeDialog(actionSheet, actionSheetPanel, send);"
        in activity
        and "refreshConversationDrawerData();" in activity
        and "pendingConversationDiff" in activity,
        "底部操作层、提示、轮询与选择切换语义保持不变",
    )
    check(SEARCH_ICON.is_file(), "新增搜索图标复用旧页线性放大镜规格")

    spec = importlib.util.spec_from_file_location("round129_version", VERSION)
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(
        any("对话会话" in item for item in version.PHONE_CHANGELOG),
        f"手机端 v{version.PHONE_VERSION} 变更表记录对话会话抽屉收口",
    )
    check(APK.is_file(), f"v{version.PHONE_VERSION} APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        check(
            b"conversationUnreadDot" in dex
            and b"conversationSearchInput" in dex,
            "APK/DEX 含新会话行和搜索框实现",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
