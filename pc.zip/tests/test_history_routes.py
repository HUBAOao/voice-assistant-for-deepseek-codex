# -*- coding: utf-8 -*-
"""Focused tests for history routes after removal from phone_link.py."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature import history_routes  # noqa: E402


class FakeHistory:
    def __init__(self) -> None:
        self.calls: list[tuple] = []

    def query(self, **kwargs):
        self.calls.append(("query", kwargs))
        return [{"text": "命中", "conv": "鳍舱"}]

    def conversations(self):
        return [{"title": "鳍舱", "count": 1}]

    def archive_list(self):
        return [{"name": "2026-10.jsonl", "count": 2}]

    def clear_active(self):
        return {"ok": True, "count": 3, "archive": "清除-test.jsonl"}

    def restore_archive(self, name: str):
        return {"ok": bool(name), "name": name}


def main() -> int:
    fake = FakeHistory()
    history_routes.chat_history = fake
    status, body = history_routes.get_route(
        "/api/history",
        {"q": ["鳍舱"], "convs": ["鳍舱\x1f任务"], "from": ["2026-10-01"],
         "to": ["2026-10-23"], "archive": ["0"], "limit": ["88"]},
    )
    assert status == 200 and body["ok"] and body["items"][0]["text"] == "命中"
    assert fake.calls[0][1] == {
        "keyword": "鳍舱", "convs": ["鳍舱", "任务"],
        "date_from": "2026-10-01", "date_to": "2026-10-23",
        "include_archive": False, "limit": 88,
    }
    assert history_routes.get_route("/api/history/convs", {})[1]["items"][0]["count"] == 1
    assert history_routes.get_route("/api/history/archives", {})[1]["items"][0]["count"] == 2
    assert history_routes.post_route("/api/history/clear", {})[1]["count"] == 3
    assert history_routes.post_route(
        "/api/history/restore", {"name": "2026-10.jsonl"}
    )[1]["name"] == "2026-10.jsonl"
    assert history_routes.get_route("/api/other", {}) is None
    assert history_routes.post_route("/api/other", {}) is None
    print("test_history_routes: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
