# -*- coding: utf-8 -*-
"""Tests for local worktree and bounded Codex worker orchestration."""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from features.agent_workers import (  # noqa: E402
    AgentOperations,
    WorktreeManager,
    codex_exec_command,
)


def git(cwd: Path, *args: str) -> None:
    subprocess.run(["git", *args], cwd=str(cwd), check=True, capture_output=True)


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        repo = Path(raw) / "repo"
        repo.mkdir()
        git(repo, "init", "-b", "main")
        git(repo, "config", "user.name", "FinDeck Test")
        git(repo, "config", "user.email", "findeck@localhost")
        (repo / "README.md").write_text("base\n", encoding="utf-8")
        git(repo, "add", "README.md")
        git(repo, "commit", "-m", "base")

        manager = WorktreeManager(repo)
        created = manager.create("P3 worker", base="HEAD")
        assert created.path.is_dir()
        assert (created.path / "README.md").read_text(encoding="utf-8") == "base\n"
        paths = [item.path.resolve() for item in manager.list()]
        assert repo.resolve() in paths and created.path.resolve() in paths
        manager.remove(created.path)
        assert created.path.resolve() not in [
            item.path.resolve() for item in manager.list()
        ]
        ops = AgentOperations(repo)
        second = ops.create_worktree("api", base="HEAD")
        assert Path(second["path"]).is_dir()
        try:
            ops.submit("x", cwd=str(Path(raw) / "outside"))
        except ValueError:
            pass
        else:
            raise AssertionError("AgentOperations accepted an arbitrary cwd")
        ops.remove_worktree(second["path"])

    cmd = codex_exec_command(cwd="C:/work", sandbox="workspace-write", model="test-model")
    assert cmd[:3] == ["codex", "exec", "--json"]
    assert "--worktree" not in cmd
    assert cmd[-1] == "-" and "test-model" in cmd
    print("test_agent_workers: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
