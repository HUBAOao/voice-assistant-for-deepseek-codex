# -*- coding: utf-8 -*-
"""Plugin manifests are opt-in, path-bounded, and version checked."""
from __future__ import annotations

import json
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def write_plugin(base: Path, folder: str, manifest: dict, code: str = "") -> Path:
    root = base / folder
    root.mkdir(parents=True)
    (root / "plugin.json").write_text(
        json.dumps(manifest, ensure_ascii=False), encoding="utf-8"
    )
    if code:
        (root / "main.py").write_text(code, encoding="utf-8")
    return root


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        base = Path(raw)
        os.environ["FIN_DECK_SECURITY_KEY"] = str(base / "security-key.bin")
        os.environ["FIN_DECK_SECURITY_POLICY"] = str(base / "security-policy.json")
        os.environ["FIN_DECK_SECURITY_META"] = str(base / "security-meta.json")

        from features.plugin_registry import PluginHost, PluginRegistry
        from features.voice_providers import ProviderRegistry

        write_plugin(base, "demo", {
            "id": "demo.speech",
            "name": "Demo Speech",
            "version": "1.2.3",
            "api": 1,
            "entrypoint": "main.py",
            "capabilities": ["stt"],
            "permissions": ["microphone"],
        }, """
class DemoSTT:
    name = "demo-stt"
    def transcribe(self, audio, sample_rate=16000):
        return "demo"

def register(context):
    context.register_stt(DemoSTT())
""")
        write_plugin(base, "bad-api", {
            "id": "bad.api", "version": "1", "api": 99,
            "entrypoint": "main.py", "capabilities": ["stt"],
        }, "raise SystemExit('must not load')")
        write_plugin(base, "escape", {
            "id": "bad.escape", "version": "1", "api": 1,
            "entrypoint": "../outside.py", "capabilities": ["tts"],
        })
        registry = PluginRegistry(base)
        status = {row["id"]: row for row in registry.status()}
        assert status["demo.speech"]["error"] == ""
        assert not status["demo.speech"]["loaded"]
        assert "API" in status["bad-api"]["error"]
        assert "越界" in status["escape"]["error"]

        providers = ProviderRegistry()
        result = registry.load_enabled(set(), context=providers)
        assert result == {}
        assert not providers.stt
        result = registry.load_enabled({"demo.speech"}, context=providers)
        assert result == {"demo.speech": "loaded"}
        assert providers.get_stt("demo-stt").transcribe([]) == "demo"
        result = registry.load_enabled({"demo.speech"}, context=providers)
        assert result == {"demo.speech": "loaded"}
        print("test_plugin_registry: PASS")

        managed = base / "managed"
        host = PluginHost(managed)
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, "w") as z:
            z.writestr("managed-demo/plugin.json", json.dumps({
                "id": "managed.demo",
                "name": "Managed Demo",
                "version": "2.0.0",
                "api": 1,
                "entrypoint": "main.py",
                "capabilities": ["stt"],
                "permissions": ["microphone"],
            }))
            z.writestr("managed-demo/main.py", """
class ManagedSTT:
    name = "managed-stt"
    def transcribe(self, audio, sample_rate=16000):
        return "managed"

def register(context):
    context.register_stt(ManagedSTT())
""")
        payload = archive.getvalue()
        preview = host.install_archive(payload)
        assert preview["needs_confirmation"] is True
        assert not (managed / "managed.demo").exists()
        installed = host.install_archive(
            payload, confirmed_permissions={"microphone"}
        )
        assert installed["installed"] is True and installed["sealed"] is True
        assert installed["enabled"] is False and installed["loaded"] is False
        from features.voice_providers import PROVIDERS

        enabled = host.enable("managed.demo")
        assert enabled["enabled"] is True and enabled["loaded"] is True
        assert PROVIDERS.get_stt("managed-stt").transcribe([]) == "managed"
        reloaded = host.reload("managed.demo")
        assert reloaded["loaded"] is True
        (managed / "managed.demo" / "main.py").write_text(
            "raise RuntimeError('tampered')", encoding="utf-8"
        )
        try:
            host.reload("managed.demo")
        except ValueError as exc:
            assert "签名" in str(exc) or "修改" in str(exc)
        else:
            raise AssertionError("tampered plugin was reloaded")
        assert not host.snapshot()["plugins"][0]["enabled"]
        assert "managed-stt" not in PROVIDERS.stt
        removed = host.remove("managed.demo", confirm=True)
        assert removed["removed"] is True
        assert Path(removed["recoverable_at"]).is_dir()
        assert not (managed / "managed.demo").exists()
        print("test_plugin_lifecycle: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
