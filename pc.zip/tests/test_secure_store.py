# -*- coding: utf-8 -*-
"""Verify DPAPI encryption for local task data."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from features.secure_store import read_secure, unprotect, protect, write_secure  # noqa: E402
from features.tasks import TaskStore  # noqa: E402


def main() -> int:
    secret = "任务批准：删除临时文件".encode("utf-8")
    protected = protect(secret)
    assert protected != secret
    assert unprotect(protected) == secret

    with tempfile.TemporaryDirectory() as raw:
        path = Path(raw) / "tasks.json"
        write_secure(path, secret)
        assert secret not in path.read_bytes()
        assert read_secure(path) == secret

        store = TaskStore(path)
        task = store.create("敏感任务")
        store.request_approval(task["id"], "Remove-Item test", risk="high")
        assert "Remove-Item test".encode("utf-8") not in path.read_bytes()
        assert TaskStore(path).get(task["id"])["approval"]["risk"] == "high"
    print("test_secure_store: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
