# -*- coding: utf-8 -*-
"""The extracted CLI keeps every runtime option and config default."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.cli_options import build_argument_parser  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    cfg = {
        "model": "medium",
        "lang": "en",
        "target": "ChatGPT",
        "wake_word": "大肥鱼,喂喂",
        "cancel_word": "算了",
        "input": "USB",
    }
    parser = build_argument_parser(
        cfg,
        default_input="USB Mic",
        default_out="transcripts.md",
    )
    args = parser.parse_args([])
    check(args.model == "medium" and args.lang == "en", "模型与语言沿用配置")
    check(args.target == "ChatGPT" and args.wake_word == "大肥鱼,喂喂",
          "发送目标与唤醒词沿用配置")
    check(args.cancel_word == "算了" and args.input == "USB Mic",
          "取消词与输入设备沿用入口默认")
    check(args.mode == "hold" and args.key == "*" and args.pause_key == "-",
          "运行模式和按键默认值保持")
    check(args.beep and args.out == "transcripts.md" and not args.no_overlay,
          "提示音、日志和悬浮窗默认值保持")

    args = parser.parse_args([
        "--send-word",
        "鳍舱",
        "--ptt",
        "--no-beep",
        "--mode",
        "talk",
        "--no-send",
        "--keep-draft",
        "--dry-run",
        "--immediate",
        "--allow-multiple",
        "--feed",
        "one.wav",
        "--feed",
        "two.wav",
        "--silence",
        "1.5",
        "--wake-timeout",
        "8",
        "--out",
        "custom.md",
    ])
    check(args.wake_word == "鳍舱" and args.ptt, "旧唤醒词别名与 PTT 保持")
    check(args.mode == "talk" and args.no_send and args.dry_run,
          "对话模式及试运行开关保持")
    check(args.keep_draft and args.immediate and args.allow_multiple,
          "草稿保留、免唤醒和多实例开关保持")
    check(args.feed == ["one.wav", "two.wav"] and args.silence == 1.5,
          "多音频输入和静音阈值保持")
    check(not args.beep and args.wake_timeout == 8.0,
          "无提示音与数值参数保持")
    check(args.out == "custom.md", "显式日志路径覆盖默认值")

    stt_source = (APP / "stt.py").read_text(encoding="utf-8")
    check("build_argument_parser(" in stt_source
          and "ap.add_argument(" not in stt_source,
          "main 入口不再内联整段命令行定义")
    check("import argparse" not in stt_source,
          "命令行依赖已收进独立模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
