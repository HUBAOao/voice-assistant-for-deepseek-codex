# -*- coding: utf-8 -*-
"""下载页：一个网址，别人打开就能下电脑端和手机端，还能看更新信息。

两种用法，内容都是现算的（版本号、包大小、更新日志都直接读 version.py）：
  * 电脑上跑着这个助手时：手机/别人连同一个 Wi-Fi，浏览器打开 http://电脑IP:8765/dl
  * 想发到外面去：make_package.py 会把这个页面 + 两个安装包生成到「下载页」文件夹，
    整个文件夹就是一个能直接传上去的静态站（相对路径，不用改任何东西）。

以后只要更新了版本，改的是 version.py —— 页面上的版本号和多出来的更新条目
会自己跟着变，不用手工同步。
"""
from __future__ import annotations

import html as _html
import time
from pathlib import Path

import version

HERE = Path(__file__).resolve().parent

# 手机端想在外面（不在同一个 Wi-Fi）用，要再装一个 Tailscale；它的官方 APK 有 100.6MB，
# 超过 GitHub 仓库单文件 100MB 的上限，所以让 Actions 把它挂成 Release 附件，这里链过去就行。
TAILSCALE_APK = ("https://github.com/HUBAOao/voice-assistant-for-deepseek-codex"
                 "/releases/latest/download/tailscale.apk")


def _ver_list(changelog: list[str], count: int = 8) -> list[tuple[str, str]]:
    """把更新日志倒过来（新的在前），并配上传本号：第 i 条 = v1.i。"""
    out: list[tuple[str, str]] = []
    for idx in range(len(changelog) - 1, max(-1, len(changelog) - 1 - count), -1):
        # 版本记录里为了在别处显示好看用了 **加粗** 记号，网页里不需要（会原样显示成星号）
        out.append((f"1.{idx + 1}", changelog[idx].replace("**", "")))
    return out


def _size_text(path: Path | None) -> str:
    if not path or not path.exists():
        return "还没放进来"
    mb = path.stat().st_size / 1024 / 1024
    if mb >= 1:
        return f"{mb:.1f} MB"
    return f"{path.stat().st_size / 1024:.0f} KB"


def find_pc_zip() -> Path | None:
    """找电脑端安装包（每个人的电脑上放的位置不一样，多找几个地方）。"""
    names = ("语音助手-安装包.zip", "语音助手-更新包.zip")
    here = HERE
    spots = [here, here.parent, here.parent.parent,
             Path.home() / "Desktop",
             Path("F:/语音助手/安装包"), Path("F:/语音助手"),
             Path("D:/语音助手/安装包"), Path("E:/语音助手/安装包")]
    for name in names:
        for d in spots:
            try:
                p = d / name
                if p.is_file():
                    return p
            except Exception:
                continue
    # 实在没有就挑一个"更新包"，让页面至少能下点东西
    for d in spots:
        try:
            hits = sorted(d.glob("语音助手-更新包-v*.zip"))
            if hits:
                return hits[-1]
        except Exception:
            continue
    return None


def find_apk() -> Path | None:
    for name in ("语音助手-手机端.apk", "app.apk"):
        p = HERE / name
        if p.is_file():
            return p
    hits = sorted(HERE.glob("语音助手-手机端-更新包-*.apk"))
    return hits[-1] if hits else None


def find_update_zip() -> Path | None:
    """电脑端的"更新包"（装了老版本的人用它升级，比整个重装小）。"""
    spots = [HERE, HERE.parent, Path.home() / "Desktop",
             Path("F:/语音助手/安装包"), Path("F:/语音助手"),
             Path("D:/语音助手/安装包"), Path("E:/语音助手/安装包")]
    best: Path | None = None
    for d in spots:
        try:
            for p in sorted(d.glob("语音助手-更新包-v*.zip")):
                if best is None or p.name > best.name:
                    best = p
        except Exception:
            continue
    return best


def info() -> dict:
    """页面要用的所有信息（现算，永远跟 version.py 一致）。"""
    import version

    apk = find_apk()
    zips = find_pc_zip()
    return {
        "pc": version.APP_VERSION,
        "phone": version.PHONE_VERSION,
        "apk": apk,
        "apk_size": _size_text(apk),
        "zip": zips,
        "zip_size": _size_text(zips),
        "update_zip": find_update_zip(),
        "pc_log": _ver_list(version.CHANGELOG, 6),
        "phone_log": _ver_list(version.PHONE_CHANGELOG, 4),
        "today": time.strftime("%Y-%m-%d"),
    }


def manifest() -> dict:
    """给两边的 APP 读的"更新清单"（网页刷新了，两边的提示就跟着变）。

    放两种地址：远程托管的话就是同一个 JSON，字段不变。
    """
    d = info()

    def one(version_text: str, path: Path | None, url: str,
            notes: list[tuple[str, str]], update_url: str = "") -> dict:
        return {
            "version": version_text,
            "size": _size_text(path),
            "kb": round(path.stat().st_size / 1024, 1) if path and path.exists() else 0,
            "url": url if path and path.exists() else "",
            "update_url": update_url if path and path.exists() else "",
            "notes": [{"version": v, "text": t} for v, t in notes],
        }

    return {
        "ok": True,
        "updated": time.strftime("%Y-%m-%d %H:%M"),
        "pc": one(d["pc"], d["zip"], "pc.zip", d["pc_log"],
                  update_url="update.zip" if d["update_zip"] else ""),
        "phone": one(d["phone"], d["apk"], "app.apk", d["phone_log"]),
    }


def _esc(text: str) -> str:
    return _html.escape(str(text), quote=True)


def build_html(base: str = "", lan_url: str = "", qr_href: str = "") -> str:
    """生成下载页。base 是资源前缀（在线版传空，静态版传空用相对路径）。"""
    d = info()
    apk_href = f"{base}app.apk" if d["apk"] else ""
    zip_href = f"{base}pc.zip" if d["zip"] else ""
    log_rows = "".join(
        f'<li><b>v{v}</b><span>{_esc(t)}</span></li>' for v, t in d["pc_log"])
    phone_rows = "".join(
        f'<li><b>v{v}</b><span>{_esc(t)}</span></li>' for v, t in d["phone_log"])
    qr_block = ""
    if qr_href:
        qr_block = (f'<div class="qr"><img src="{_esc(qr_href)}" alt="扫码打开这一页">'
                    '<div class="qh">手机扫这个码<br>打开下载页</div></div>')
    # 局域网那份才有"这台电脑自己的下载页在哪"这句话；发到外面去的版本不放，
    # 不然别人看着莫名其妙（"我哪知道你的 IP"）。
    lan_tip = (f'<div class="tip">装在电脑上之后，这个下载页就在电脑自己的网址下：'
               f'<code>{_esc(lan_url)}</code> —— 同一个 Wi-Fi 里谁想装都能打开。</div>'
               if lan_url else "")
    return f"""<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>语音助手 · 下载</title>
<style>
  :root {{ --bg:#12121a; --panel:#1b1b23; --line:#33333d; --fg:#f2f2f5;
           --dim:#9a9aa5; --accent:#3ddc84; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:var(--bg); color:var(--fg);
          font-family:-apple-system,"Microsoft YaHei UI","Segoe UI",sans-serif;
          line-height:1.6; }}
  .wrap {{ max-width:820px; margin:0 auto; padding:28px 18px 60px; }}
  h1 {{ font-size:26px; margin:0 0 6px; }}
  .sub {{ color:var(--dim); font-size:14px; margin-bottom:22px; }}
  .cards {{ display:flex; gap:16px; flex-wrap:wrap; }}
  .card {{ flex:1 1 300px; background:var(--panel); border:1px solid var(--line);
           border-radius:16px; padding:18px; }}
  .card h2 {{ margin:0 0 4px; font-size:19px; }}
  .card .meta {{ color:var(--dim); font-size:13px; margin-bottom:14px; }}
  .btn {{ display:block; text-align:center; text-decoration:none; font-weight:700;
          padding:14px; border-radius:12px; background:var(--accent); color:#08130c;
          font-size:16px; }}
  .btn.ghost {{ background:#2a2a34; color:var(--fg); }}
  .btn.off {{ background:#2a2a34; color:var(--dim); pointer-events:none; }}
  .tip {{ color:var(--dim); font-size:12.5px; margin-top:10px; }}
  .how {{ background:var(--panel); border:1px solid var(--line); border-radius:16px;
          padding:16px 18px; margin-top:18px; }}
  .how ol {{ margin:6px 0 0 20px; padding:0; }}
  .how li {{ margin:4px 0; font-size:14px; }}
  .logs {{ display:flex; gap:16px; flex-wrap:wrap; margin-top:18px; }}
  .log {{ flex:1 1 320px; background:var(--panel); border:1px solid var(--line);
          border-radius:16px; padding:16px 18px; }}
  .log h3 {{ margin:0 0 8px; font-size:15px; }}
  .log ul {{ list-style:none; margin:0; padding:0; }}
  .log li {{ display:flex; gap:10px; padding:6px 0;
             border-bottom:1px dashed #2c2c36; font-size:13.5px; }}
  .log li:last-child {{ border-bottom:0; }}
  .log li b {{ color:var(--accent); flex:0 0 54px; font-weight:700; }}
  .log li span {{ color:#d6d6dd; }}
  .sig {{ display:block; margin-top:10px; font-size:11.5px; color:#6f6f7a; line-height:1.8; }}
  .sig b {{ color:#8a8a95; font-weight:600; }}
  .qr {{ text-align:center; margin:18px 0 0; }}
  .qr img {{ width:200px; height:200px; background:#fff; border-radius:12px; padding:8px; }}
  .qh {{ color:var(--dim); font-size:12.5px; margin-top:6px; }}
  footer {{ color:#6f6f7a; font-size:12px; margin-top:26px; text-align:center; }}
  code {{ background:#26262f; padding:1px 6px; border-radius:6px; }}
</style></head><body><div class="wrap">
  <h1>语音助手 · 下载</h1>
  <div class="sub">电脑端（Windows，解压双击就能装）和手机端（安卓 APP）。
    两边版本分开算：电脑端 v{d['pc']}，手机端 v{d['phone']}（{d['today']}）。</div>

  <div class="cards">
    <div class="card">
      <h2>🖥 电脑端</h2>
      <div class="meta">Windows 10/11 · v{d['pc']} · {_esc(d['zip_size'])}</div>
      <a class="btn{' off' if not zip_href else ''}" href="{_esc(zip_href or '#')}">
        {'下载安装包（zip）' if zip_href else '安装包没找到'}</a>
      <div class="tip">解压得到一个文件夹，双击里面的
        <code>1-安装语音助手.cmd</code>，等它自己装完就行（第一次会装依赖，慢一点）。</div>
    </div>
    <div class="card">
      <h2>📱 手机端</h2>
      <div class="meta">安卓 7.0 以上 · v{d['phone']} · {_esc(d['apk_size'])}</div>
      <a class="btn{' off' if not apk_href else ''}" href="{_esc(apk_href or '#')}">
        {'下载安卓 APP（apk）' if apk_href else 'APK 没找到'}</a>
      <div class="tip">装完打开 APP，扫电脑上那个二维码就连上了（不用手敲地址）。
        手机上打开的这一页，点上面的按钮就能直接下。</div>
      <div class="tip" style="margin-top:10px">
        📶 <b>想在外面（不在同一个 Wi-Fi）也能用？</b>不用另外找软件 ——
        电脑端 <b>设置 → 智能 → 外网访问</b> 点一下「一键开启」（它会自己把 Tailscale
        装好、把登录页开出来给你登）；手机 APP 里 <b>设置 → 外网访问</b> 点「装 / 开 Tailscale」，
        它会自己把 APK 下下来装上，回来点「用这条地址连」就切过去了。只在家里用就不用管这一栏。
        <br>（不想让 APP 自动装的话，也可以直接下
        <a href="{TAILSCALE_APK}" style="color:var(--accent)">官方的 Tailscale apk</a>）
      </div>
    </div>
  </div>

  <div class="how">
    <h3 style="margin:0;font-size:15px">怎么用（三步）</h3>
    <ol>
      <li>电脑端：下载 → 解压 → 双击 <code>1-安装语音助手.cmd</code>，装好桌面上会有图标</li>
      <li>手机端：下载 APK 装上，打开 APP 后点左上角「扫码」</li>
      <li>电脑上点悬浮窗的「二维码」按钮，用手机照一下就连上了
        （手机和电脑要连同一个 Wi-Fi）</li>
    </ol>
    {lan_tip}
  </div>

  {qr_block}

  <div class="logs">
    <div class="log"><h3>电脑端最近的更新（v{d['pc']}）</h3><ul>{log_rows}</ul></div>
    <div class="log"><h3>手机端最近的更新（v{d['phone']}）</h3><ul>{phone_rows}</ul></div>
  </div>

  <footer>版本号、包大小、更新日志都跟着程序里的版本记录走，有新版这一页就是新的。
    <span class="sig">
      <b>语音助手 v{d['pc']}</b> · 作者 <b>{_esc(version.AUTHOR)}</b>
      · 联系方式 {_esc(version.CONTACT)} · {_esc(version.COPYRIGHT)}<br>
      {_esc(version.FREE_LINE)}<br>{_esc(version.NOTICE)}
    </span>
  </footer>
<!-- （下载量那块去掉了：现在只有 GitHub Pages 这一种下载方式，静态网站没有服务器，
     计数不了。用户要求"只留 GitHub 网址"，所以整块拿掉，页面上也不再显示那一行。） -->
</div></body></html>
"""


def write_static(out_dir: Path, lan_url: str = "") -> list[Path]:
    """生成一个能直接传上去的静态下载站（相对路径，不依赖电脑在不在）。"""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    made: list[Path] = []
    apk = find_apk()
    zipf = find_pc_zip()
    if apk:
        dst = out_dir / "app.apk"
        dst.write_bytes(apk.read_bytes())
        made.append(dst)
    if zipf:
        dst = out_dir / "pc.zip"
        dst.write_bytes(zipf.read_bytes())
        made.append(dst)
    page = out_dir / "index.html"
    page.write_text(build_html(base="", lan_url=lan_url), encoding="utf-8")
    made.append(page)
    # 更新清单也放进去：两边 APP 都能读同一份数据（远程托管也照读）
    import json as _json

    mf = out_dir / "version.json"
    mf.write_text(_json.dumps(manifest(), ensure_ascii=False, indent=2), encoding="utf-8")
    made.append(mf)
    # （这里以前会生成一份"怎么发出去"的说明 txt。网站已经上线了，那份说明就是废话，
    #   用户让删掉 —— 顺手把可能残留的旧文件也清掉。）
    for junk in ("怎么发出去.txt", "怎么让所有人都能下载.txt", "下载页-单文件.html"):
        try:
            (out_dir / junk).unlink(missing_ok=True)
        except Exception:
            pass
    return made


def write_single_file(out_path: Path) -> Path:
    """把所有东西塞进**一个 HTML 文件**：两个安装包直接嵌在里面。

    这个文件不依赖任何东西 —— 不依赖你的电脑开着、不依赖网络、不用建站，
    双击就能打开、点一下就能下（两个包都从文件自己里出来）。
    用来"发给某个人让他自己去装"最省事：微信/QQ 当文件发过去就行。
    """
    import base64

    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    d = info()
    apk_b64 = ""
    zip_b64 = ""
    if d["apk"]:
        apk_b64 = base64.b64encode(d["apk"].read_bytes()).decode("ascii")
    if d["zip"]:
        zip_b64 = base64.b64encode(d["zip"].read_bytes()).decode("ascii")
    html = build_html(base="")          # 正文用普通的（按钮由下面的脚本接管）
    # 正文里那两个 <a href="app.apk"> 换成"从文件内部取数据"的按钮
    html = html.replace('href="app.apk"', 'href="#" id="grab-apk"')
    html = html.replace('href="pc.zip"', 'href="#" id="grab-pc"')
    script = f"""
<script>
// 两个安装包就在这个文件里（base64 嵌着），点一下直接生成下载，不需要联网、不需要服务器。
const B64_PC = "{zip_b64}";
const B64_APK = "{apk_b64}";
function grabFromFile(b64, name, type) {{
  if (!b64) {{ alert("这个文件里没有打包进去，请用文件夹里那份下载页"); return; }}
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], {{type: type}}));
  const a = document.createElement("a");
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}}
document.getElementById("grab-pc").onclick = e => {{
  e.preventDefault(); grabFromFile(B64_PC, "voice-assistant-pc.zip", "application/zip");
}};
document.getElementById("grab-apk").onclick = e => {{
  e.preventDefault(); grabFromFile(B64_APK, "voice-assistant.apk",
                                  "application/vnd.android.package-archive");
}};
// 单文件版：写上"这一份是离线的"，免得别人以为网站在哪
document.querySelectorAll(".tip").forEach(el => {{
  if (el.textContent.indexOf("同一个 Wi-Fi") >= 0) el.style.display = "none";
}});
</script>
</body>"""
    html = html.replace("</body>", script, 1)
    out_path.write_text(html, encoding="utf-8")
    return out_path
