# -*- coding: utf-8 -*-
"""手机聊天历史：E 盘主存储、F 盘镜像、60 天热/归档分层。"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterable

import storage_paths

HISTORY_DIR = storage_paths.DATA_ROOT / "聊天记录"
ACTIVE_FILE = HISTORY_DIR / "messages.jsonl"
ARCHIVE_DIR = HISTORY_DIR / "归档"
CLEARED_DIR = HISTORY_DIR / "已清除"
STATE_FILE = HISTORY_DIR / "state.json"
HOT_DAYS = 60

_LOCK = threading.RLock()
_IDS: set[str] | None = None
_LAST_MAINT = 0.0


def _ensure() -> None:
    storage_paths.ensure_layout()
    for p in (HISTORY_DIR, ARCHIVE_DIR, CLEARED_DIR):
        p.mkdir(parents=True, exist_ok=True)


def _state() -> dict:
    try:
        data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_state(data: dict) -> None:
    _ensure()
    tmp = STATE_FILE.with_suffix(".part")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(STATE_FILE)
    storage_paths.mirror_file(STATE_FILE, Path("聊天记录") / STATE_FILE.name)


def _visible(rec: dict, hidden_before: int | None = None) -> bool:
    hidden = int(_state().get("hidden_before_ms") or 0) if hidden_before is None else hidden_before
    ts = int(rec.get("ts_ms") or 0)
    restored = int(rec.get("restored_at_ms") or 0)
    return not hidden or ts > hidden or restored > hidden


def visible_records(records: Iterable[dict]) -> list[dict]:
    hidden = int(_state().get("hidden_before_ms") or 0)
    return [r for r in records
            if _visible({"ts_ms": r.get("_ts") or r.get("ts_ms"),
                         "restored_at_ms": r.get("restored_at_ms")}, hidden)]


def _norm_conv(value: object) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    return "对话" if not text or text == "本机" else text


def _record_id(rec: dict) -> str:
    key = "\x1f".join((
        str(rec.get("kind") or ""),
        str(rec.get("ts_ms") or rec.get("ts") or ""),
        _norm_conv(rec.get("conv")),
        str(rec.get("text") or ""),
    ))
    return hashlib.sha1(key.encode("utf-8", "replace")).hexdigest()


def _load_file(path: Path) -> list[dict]:
    out = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if isinstance(rec, dict) and rec.get("text"):
                rec.setdefault("id", _record_id(rec))
                out.append(rec)
    except Exception:
        pass
    return out


def _write_jsonl(path: Path, records: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".part")
    with tmp.open("w", encoding="utf-8") as fh:
        for rec in records:
            fh.write(json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n")
    tmp.replace(path)
    storage_paths.mirror_file(path, path.relative_to(storage_paths.DATA_ROOT))


def _all_records(include_archive: bool = True) -> list[dict]:
    _ensure()
    global _IDS
    with _LOCK:
        files = [ACTIVE_FILE]
        if include_archive:
            files.extend(sorted(ARCHIVE_DIR.glob("*.jsonl")))
        seen = set()
        out = []
        for path in files:
            for rec in _load_file(path):
                rid = str(rec["id"])
                if rid in seen:
                    continue
                seen.add(rid)
                out.append(rec)
        out.sort(key=lambda x: (int(x.get("ts_ms") or 0), str(x.get("id") or "")))
        _IDS = seen
        return out


def _archive_month(ts_ms: int) -> Path:
    dt = datetime.fromtimestamp(ts_ms / 1000)
    return ARCHIVE_DIR / f"{dt:%Y-%m}.jsonl"


def maintain() -> None:
    """把 60 天以前的记录从热文件移到按月归档；恢复过的记录重新计 60 天。"""
    _ensure()
    cutoff = int((datetime.now() - timedelta(days=HOT_DAYS)).timestamp() * 1000)
    with _LOCK:
        active = _load_file(ACTIVE_FILE)
        if not active:
            return
        hot, old = [], []
        for rec in active:
            ts = int(rec.get("ts_ms") or 0)
            restored = int(rec.get("restored_at_ms") or 0)
            if ts and ts < cutoff and restored < cutoff:
                old.append(rec)
            else:
                hot.append(rec)
        if not old:
            return
        by_month: dict[Path, list[dict]] = {}
        for rec in old:
            by_month.setdefault(_archive_month(int(rec.get("ts_ms") or time.time() * 1000)), []).append(rec)
        for path, recs in by_month.items():
            existing = _load_file(path)
            have = {str(r["id"]) for r in existing}
            existing.extend(r for r in recs if str(r["id"]) not in have)
            existing.sort(key=lambda x: int(x.get("ts_ms") or 0))
            _write_jsonl(path, existing)
        _write_jsonl(ACTIVE_FILE, hot)


def ingest(records: Iterable[dict]) -> int:
    global _LAST_MAINT
    _ensure()
    recs = list(records)
    if not recs:
        return 0
    global _IDS
    if _IDS is None:
        _all_records(True)
    have = set(_IDS or set())
    added = []
    hidden_before = int(_state().get("hidden_before_ms") or 0)
    cutoff = int((datetime.now() - timedelta(days=HOT_DAYS)).timestamp() * 1000)
    for src in recs:
        ts = int(src.get("ts_ms") or src.get("_ts") or 0)
        if not ts:
            continue
        if hidden_before and ts <= hidden_before:
            continue
        rec = {
            "id": "",
            "ts_ms": ts,
            "date": datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d"),
            "at": str(src.get("at") or datetime.fromtimestamp(ts / 1000).strftime("%H:%M")),
            "kind": str(src.get("kind") or "ai"),
            "conv": _norm_conv(src.get("conv")),
            "text": str(src.get("text") or ""),
            "raw": str(src.get("raw") or ""),
        }
        rec["id"] = _record_id(rec)
        if rec["id"] in have:
            continue
        have.add(rec["id"])
        added.append(rec)
    if not added:
        if time.time() - _LAST_MAINT > 3600:
            maintain()
            _LAST_MAINT = time.time()
        return 0
    with _LOCK:
        active = _load_file(ACTIVE_FILE)
        active.extend(r for r in added if int(r["ts_ms"]) >= cutoff)
        active.sort(key=lambda x: int(x["ts_ms"]))
        _write_jsonl(ACTIVE_FILE, active)
        archived = [r for r in added if int(r["ts_ms"]) < cutoff]
        by_month: dict[Path, list[dict]] = {}
        for rec in archived:
            by_month.setdefault(_archive_month(int(rec["ts_ms"])), []).append(rec)
        for path, recs2 in by_month.items():
            existing = _load_file(path)
            ids = {str(r["id"]) for r in existing}
            existing.extend(r for r in recs2 if str(r["id"]) not in ids)
            existing.sort(key=lambda x: int(x["ts_ms"]))
            _write_jsonl(path, existing)
        _IDS = have
    if time.time() - _LAST_MAINT > 3600:
        maintain()
        _LAST_MAINT = time.time()
    return len(added)


def conversations() -> list[dict]:
    counts: dict[str, int] = {}
    for rec in _all_records(True):
        conv = _norm_conv(rec.get("conv"))
        counts[conv] = counts.get(conv, 0) + 1
    return [{"title": k, "count": v} for k, v in
            sorted(counts.items(), key=lambda x: (-x[1], x[0]))]


def query(keyword: str = "", convs: list[str] | None = None,
          date_from: str = "", date_to: str = "",
          include_archive: bool = True, limit: int = 5000) -> list[dict]:
    allowed = {_norm_conv(c) for c in (convs or []) if str(c or "").strip()}
    kw = str(keyword or "").strip().casefold()
    hidden = int(_state().get("hidden_before_ms") or 0)
    out = []
    for rec in _all_records(include_archive):
        if not _visible(rec, hidden):
            continue
        date = str(rec.get("date") or "")
        if date_from and date < date_from:
            continue
        if date_to and date > date_to:
            continue
        if allowed and _norm_conv(rec.get("conv")) not in allowed:
            continue
        if kw and kw not in str(rec.get("text") or "").casefold():
            continue
        out.append(rec)
    return out[-max(1, min(10000, int(limit))):]


def archive_list() -> list[dict]:
    _ensure()
    out = []
    files = sorted(ARCHIVE_DIR.glob("*.jsonl"), reverse=True)
    files += sorted(CLEARED_DIR.glob("*.jsonl"), reverse=True)
    for path in files:
        recs = _load_file(path)
        if not recs:
            continue
        out.append({
            "name": path.name,
            "source": "cleared" if path.parent == CLEARED_DIR else "archive",
            "from": min(r.get("date", "") for r in recs),
            "to": max(r.get("date", "") for r in recs),
            "count": len(recs),
            "kb": round(path.stat().st_size / 1024, 1),
        })
    return out


def clear_active() -> dict:
    _ensure()
    with _LOCK:
        active = _load_file(ACTIVE_FILE)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dst = CLEARED_DIR / f"清除-{stamp}.jsonl"
        if active:
            _write_jsonl(dst, active)
        _write_jsonl(ACTIVE_FILE, [])
        state = _state()
        state["hidden_before_ms"] = int(time.time() * 1000)
        state["last_clear_archive"] = dst.name
        _save_state(state)
        _IDS = None
        return {"ok": True, "count": len(active), "archive": dst.name}


def restore_archive(name: str) -> dict:
    _ensure()
    safe = Path(str(name or "")).name
    path = ARCHIVE_DIR / safe
    if not path.is_file():
        path = CLEARED_DIR / safe
    if not safe.endswith(".jsonl") or not path.is_file():
        return {"ok": False, "err": "没有这个归档"}
    recs = _load_file(path)
    now = int(time.time() * 1000)
    for rec in recs:
        rec["restored_at_ms"] = now
    with _LOCK:
        active = _load_file(ACTIVE_FILE)
        have = {str(r["id"]) for r in active}
        active.extend(r for r in recs if str(r["id"]) not in have)
        active.sort(key=lambda x: int(x["ts_ms"]))
        _write_jsonl(ACTIVE_FILE, active)
        _IDS = None
    return {"ok": True, "count": len(recs), "name": safe}
