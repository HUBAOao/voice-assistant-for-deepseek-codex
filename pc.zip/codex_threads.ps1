# Read / switch / manage Codex desktop threads through UI Automation.
# ASCII only: Windows PowerShell 5.1 can read this file as ANSI.
#
# Actions:
#   list
#   open -NameFile file [-DryRun]
#   archive|unarchive|delete -NameFile file -MenuFile labels.txt [-ConfirmFile labels.txt]
#   dumpmenu -NameFile file

param(
    [string]$Action = "list",
    [string]$Name = "",
    [string]$NameFile = "",
    [string]$MenuFile = "",
    [string]$ConfirmFile = "",
    [string]$OutFile = "",
    [switch]$DryRun
)

[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
$OutputEncoding = [Console]::OutputEncoding
if ($NameFile -and (Test-Path -LiteralPath $NameFile)) {
    $Name = (Get-Content -Raw -Encoding UTF8 -LiteralPath $NameFile).Trim()
}

$script:lines = New-Object System.Collections.ArrayList
function Say([string]$text) {
    [void]$script:lines.Add($text)
    Write-Output $text
    if ($OutFile) {
        $script:lines | Out-File -FilePath $OutFile -Encoding UTF8
    }
}

function Read-Labels([string]$path) {
    if (-not $path -or -not (Test-Path -LiteralPath $path)) { return @() }
    return @(Get-Content -LiteralPath $path -Encoding UTF8 |
        ForEach-Object { $_.Trim() } | Where-Object { $_ })
}

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$auto = [System.Windows.Automation.AutomationElement]
$scopeKids = [System.Windows.Automation.TreeScope]::Children
$scopeAll = [System.Windows.Automation.TreeScope]::Descendants
$true2 = [System.Windows.Automation.Condition]::TrueCondition

$root = $auto::RootElement
$cond = New-Object System.Windows.Automation.PropertyCondition($auto::NameProperty, "ChatGPT")
$win = $root.FindFirst($scopeKids, $cond)
if ($null -eq $win) {
    Say "NO_WINDOW"
    exit 1
}
$wr = $win.Current.BoundingRectangle
$appPids = @(Get-Process -Name ChatGPT -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })

Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$shell = New-Object -ComObject WScript.Shell
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class VaMouse {
  [DllImport("user32.dll")] public static extern void mouse_event(int f, int dx, int dy, int d, int e);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
}
"@

function Click-Rect($r, [bool]$rightClick = $false) {
    $cx = [int]($r.X + $r.Width / 2)
    $cy = [int]($r.Y + $r.Height / 2)
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($cx, $cy)
    Start-Sleep -Milliseconds 100
    if ($rightClick) {
        [VaMouse]::mouse_event(0x0008, 0, 0, 0, 0)
        Start-Sleep -Milliseconds 60
        [VaMouse]::mouse_event(0x0010, 0, 0, 0, 0)
    } else {
        [VaMouse]::mouse_event(0x0002, 0, 0, 0, 0)
        Start-Sleep -Milliseconds 55
        [VaMouse]::mouse_event(0x0004, 0, 0, 0, 0)
    }
    return @($cx, $cy)
}

function Activate-App {
    $h = [IntPtr]$win.Current.NativeWindowHandle
    try { [VaMouse]::ShowWindowAsync($h, 9) | Out-Null } catch {}
    try { [VaMouse]::BringWindowToTop($h) | Out-Null } catch {}
    try { [void]$shell.AppActivate([int]$win.Current.ProcessId) } catch {}
    try { [VaMouse]::SetForegroundWindow($h) | Out-Null } catch {}
    Start-Sleep -Milliseconds 180
}

function Invoke-Element($e) {
    try {
        $invoke = $null
        if ($e.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern, [ref]$invoke)) {
            $invoke.Invoke()
            return $true
        }
    } catch {}
    try {
        $expand = $null
        if ($e.TryGetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern, [ref]$expand)) {
            $expand.Expand()
            return $true
        }
    } catch {}
    $r = $e.Current.BoundingRectangle
    if ($r.Width -le 0 -or $r.Height -le 0) { return $false }
    Activate-App
    Click-Rect $r $false | Out-Null
    return $true
}

function Row-Is-Sidebar($e, $wr) {
    $r = $e.Current.BoundingRectangle
    if ($r.Width -lt 120 -or $r.Width -gt 620) { return $false }
    if ($r.Height -lt 24 -or $r.Height -gt 90) { return $false }
    if ($r.X -lt ($wr.X - 2) -or $r.X -gt ($wr.X + $wr.Width * 0.32)) { return $false }
    if ($r.Y -lt ($wr.Y - 2) -or ($r.Y + $r.Height) -gt ($wr.Y + $wr.Height)) { return $false }
    return $true
}

$listCond = New-Object System.Windows.Automation.PropertyCondition(
    $auto::ControlTypeProperty, [System.Windows.Automation.ControlType]::ListItem)

function Find-VisibleRow([string]$target) {
    $items = $win.FindAll($scopeAll, $listCond)
    foreach ($e in $items) {
        $n = $e.Current.Name
        if (-not $n) { continue }
        if ($n.Trim() -ne $target.Trim()) { continue }
        if (-not (Row-Is-Sidebar $e $wr)) { continue }
        return $e
    }
    return $null
}

function Scroll-SidebarToTop() {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public class VaScroll {
  [DllImport("user32.dll")] public static extern void mouse_event(int f, int dx, int dy, int d, int e);
}
"@
    $sx = [int]($wr.X + [Math]::Min(170, $wr.Width * 0.14))
    $sy = [int]($wr.Y + $wr.Height * 0.55)
    [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($sx, $sy)
    Start-Sleep -Milliseconds 100
    for ($k = 0; $k -lt 28; $k++) {
        [VaScroll]::mouse_event(0x0800, 0, 0, 420, 0)
    }
    Start-Sleep -Milliseconds 180
}

function Find-Row([string]$target) {
    $e = Find-VisibleRow $target
    if ($e) { return $e }
    Scroll-SidebarToTop
    for ($round = 0; $round -lt 80; $round++) {
        $e = Find-VisibleRow $target
        if ($e) { return $e }
        [VaScroll]::mouse_event(0x0800, 0, 0, -420, 0)
        Start-Sleep -Milliseconds 130
    }
    return $null
}

function Find-UiByName([string[]]$labels, $controlType = $null, [bool]$buttonsOnly = $false) {
    if (-not $labels -or $labels.Count -eq 0) { return $null }
    $all = $root.FindAll($scopeAll, $true2)
    foreach ($e in $all) {
        try {
            if ($appPids -notcontains $e.Current.ProcessId) { continue }
            if ($e.Current.IsOffscreen) { continue }
            $r = $e.Current.BoundingRectangle
            if ($r.Width -le 0 -or $r.Height -le 0) { continue }
            if ($controlType -and $e.Current.ControlType -ne $controlType) { continue }
            if ($buttonsOnly -and $e.Current.ControlType -ne [System.Windows.Automation.ControlType]::Button) { continue }
            $n = [string]$e.Current.Name
            foreach ($label in $labels) {
                if ($n.Trim() -eq $label.Trim() -or $n.Trim().StartsWith($label.Trim())) {
                    return $e
                }
            }
        } catch {}
    }
    return $null
}

function Find-RowButton($row, [string[]]$labels) {
    if (-not $row -or -not $labels -or $labels.Count -eq 0) { return $null }
    $rr = $row.Current.BoundingRectangle
    $rowY = $rr.Y + $rr.Height / 2
    $buttonCond = New-Object System.Windows.Automation.PropertyCondition(
        $auto::ControlTypeProperty, [System.Windows.Automation.ControlType]::Button)
    $buttons = $win.FindAll($scopeAll, $buttonCond)
    $best = $null
    $bestDy = 9999
    foreach ($e in $buttons) {
        try {
            $n = [string]$e.Current.Name
            $matched = $false
            foreach ($label in $labels) {
                if ($n.Trim() -eq $label.Trim() -or $n.Trim().StartsWith($label.Trim())) {
                    $matched = $true
                    break
                }
            }
            if (-not $matched) { continue }
            $r = $e.Current.BoundingRectangle
            if ($r.Width -le 0 -or $r.Height -le 0) { continue }
            $dy = [Math]::Abs(($r.Y + $r.Height / 2) - $rowY)
            if ($dy -lt $bestDy -and $dy -lt 28) {
                $best = $e
                $bestDy = $dy
            }
        } catch {}
    }
    return $best
}

function Dump-Element([int]$limit = 80) {
    $n = 0
    $all = $root.FindAll($scopeAll, $true2)
    foreach ($x in $all) {
        if ($n -ge $limit) { break }
        try {
            if ($appPids -notcontains $x.Current.ProcessId) { continue }
            if ($x.Current.IsOffscreen) { continue }
            $r = $x.Current.BoundingRectangle
            if ($r.Width -le 0 -or $r.Height -le 0) { continue }
            if ($x.Current.ControlType -eq [System.Windows.Automation.ControlType]::MenuItem -or
                $x.Current.ControlType -eq [System.Windows.Automation.ControlType]::Button) {
                Say ("UI`t" + $x.Current.ControlType.ProgrammaticName + "`t" + $x.Current.Name)
                $n++
            }
        } catch {}
    }
}

$docCond = New-Object System.Windows.Automation.PropertyCondition(
    $auto::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)

if ($Action -eq "list") {
    $doc = $win.FindFirst($scopeAll, $docCond)
    $current = ""
    if ($doc) { $current = $doc.Current.Name }
    $items = $win.FindAll($scopeAll, $listCond)
    foreach ($e in $items) {
        $n = $e.Current.Name
        if (-not $n -or -not (Row-Is-Sidebar $e $wr)) { continue }
        $mark = "0"
        if ($current -and $n.Trim() -eq $current.Trim()) { $mark = "1" }
        Say ($n + "`t" + $mark)
    }
    exit 0
}

if ($Action -eq "dumpmenu") {
    $row = Find-Row $Name
    if (-not $row) { Say "NOT_FOUND"; exit 0 }
    Activate-App
    Click-Rect $row.Current.BoundingRectangle $true | Out-Null
    Start-Sleep -Milliseconds 350
    Dump-Element
    [System.Windows.Forms.SendKeys]::SendWait("{ESC}")
    exit 0
}

if ($Action -eq "dumpactions") {
    $button = Find-UiByName @("Chat actions") ([System.Windows.Automation.ControlType]::Button)
    if (-not $button) { Say "ACTION_BUTTON_NOT_FOUND"; exit 0 }
    Activate-App
    Invoke-Element $button | Out-Null
    Start-Sleep -Milliseconds 450
    Dump-Element
    [System.Windows.Forms.SendKeys]::SendWait("{ESC}")
    exit 0
}

if ($Action -eq "deletepreview") {
    $row = Find-Row $Name
    Activate-App
    if ($row) { Click-Rect $row.Current.BoundingRectangle $false | Out-Null }
    Start-Sleep -Milliseconds 180
    $doc = $win.FindFirst($scopeAll, $docCond)
    if ($doc) {
        $doc.SetFocus()
        Say "DOC_FOCUSED"
    } else {
        Say "NO_DOC"
    }
    [System.Windows.Forms.SendKeys]::SendWait("^+{BACKSPACE}")
    Start-Sleep -Milliseconds 700
    Dump-Element
    [System.Windows.Forms.SendKeys]::SendWait("{ESC}")
    exit 0
}

if ($Action -eq "dumpcommand") {
    Say ("APP_PIDS " + ($appPids -join ","))
    $button = Find-UiByName @("Search") ([System.Windows.Automation.ControlType]::Button)
    if (-not $button) { Say "SEARCH_NOT_FOUND"; exit 0 }
    Invoke-Element $button | Out-Null
    Start-Sleep -Milliseconds 450
    Dump-Element 160
    [System.Windows.Forms.SendKeys]::SendWait("{ESC}")
    exit 0
}

if ($Action -eq "new") {
    Activate-App
    [System.Windows.Forms.SendKeys]::SendWait("^n")
    Say "NEW_SENT"
    exit 0
}

if ($Action -eq "archivecurrent") {
    $row = Find-Row $Name
    Activate-App
    if ($row) { Click-Rect $row.Current.BoundingRectangle $false | Out-Null }
    Start-Sleep -Milliseconds 180
    [System.Windows.Forms.SendKeys]::SendWait("^+a")
    Start-Sleep -Milliseconds 500
    Say "ARCHIVE_SENT"
    exit 0
}

if ($Action -eq "open") {
    $row = Find-Row $Name
    if (-not $row) { Say "NOT_FOUND"; exit 0 }
    $r = $row.Current.BoundingRectangle
    if ($DryRun) {
        Say ("WOULD_CLICK " + [int]($r.X + $r.Width / 2) + "," + [int]($r.Y + $r.Height / 2))
        exit 0
    }
    $pt = Click-Rect $r $false
    Say ("CLICKED " + $pt[0] + "," + $pt[1])
    exit 0
}

if ($Action -eq "archive" -or $Action -eq "unarchive" -or $Action -eq "delete") {
    $labels = Read-Labels $MenuFile
    $row = Find-Row $Name
    $item = $null
    if ($Action -eq "delete") {
        Activate-App
        if ($row) { Click-Rect $row.Current.BoundingRectangle $false | Out-Null }
        Start-Sleep -Milliseconds 180
        [System.Windows.Forms.SendKeys]::SendWait("^+{DELETE}")
        Start-Sleep -Milliseconds 650
        $item = $true
    } elseif ($row) {
        $item = Find-RowButton $row $labels
        if ($item) {
            Invoke-Element $item | Out-Null
            Start-Sleep -Milliseconds 500
        }
    }

    if (-not $item -and $Action -eq "unarchive") {
        $item = Find-UiByName $labels ([System.Windows.Automation.ControlType]::Button)
        if ($item) {
            Invoke-Element $item | Out-Null
            Start-Sleep -Milliseconds 350
        }
    }
    if (-not $item) { Say "NOT_FOUND"; exit 0 }

    if ($Action -eq "delete") {
        $confirm = Read-Labels $ConfirmFile
        $button = Find-UiByName $confirm ([System.Windows.Automation.ControlType]::Button)
        if (-not $button) { $button = Find-UiByName $confirm ([System.Windows.Automation.ControlType]::MenuItem) }
        if (-not $button) { Say "CONFIRM_NOT_FOUND"; exit 0 }
        Invoke-Element $button | Out-Null
        Start-Sleep -Milliseconds 450
        Say "CONFIRMED"
        exit 0
    }
    Say "CLICKED_MENU"
    exit 0
}

Say "UNKNOWN_ACTION"
exit 1
