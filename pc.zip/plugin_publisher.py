# -*- coding: utf-8 -*-
"""Generate FinDeck publisher keys and sign a plugin directory."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))


def write_json(path: Path, value: dict, *, private: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=1, sort_keys=True),
        encoding="utf-8",
    )
    if private:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description="鳍舱插件发布者签名工具")
    sub = parser.add_subparsers(dest="command", required=True)
    keygen = sub.add_parser("keygen", help="生成 RSA 2048 发布者密钥")
    keygen.add_argument("--private", required=True)
    keygen.add_argument("--public", required=True)
    sign = sub.add_parser("sign", help="给插件目录写入发布者签名")
    sign.add_argument("--plugin", required=True)
    sign.add_argument("--private", required=True)
    sign.add_argument("--publisher", required=True)
    sign.add_argument("--name", default="")
    verify = sub.add_parser("verify", help="校验插件目录签名")
    verify.add_argument("--plugin", required=True)
    args = parser.parse_args()

    from features.plugin_signing import (
        generate_private_key,
        public_from_private,
        sign_plugin,
        verify_plugin,
    )

    if args.command == "keygen":
        private_key = generate_private_key(2048)
        public_key = public_from_private(private_key)
        write_json(Path(args.private), private_key, private=True)
        write_json(Path(args.public), public_key)
        print("私钥：" + args.private)
        print("公钥：" + args.public)
        print("密钥指纹：" + public_key["key_id"])
        return 0
    if args.command == "sign":
        private_key = json.loads(Path(args.private).read_text(encoding="utf-8"))
        envelope = sign_plugin(
            Path(args.plugin),
            private_key,
            publisher_id=args.publisher,
            publisher_name=args.name,
        )
        print("已签名：" + envelope["signature"])
        print("指纹：" + envelope["publisher"]["key_id"])
        return 0
    result = verify_plugin(Path(args.plugin))
    print(json.dumps(result, ensure_ascii=False, indent=1))
    return 0 if result.get("valid") else 1


if __name__ == "__main__":
    raise SystemExit(main())
