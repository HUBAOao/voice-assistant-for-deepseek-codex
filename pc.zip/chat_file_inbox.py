# -*- coding: utf-8 -*-
"""Persistent file-message inbox shared by desktop commands and the phone.

The normal chat log has a dense integer sequence owned by the speech runtime.
File messages use this small independent journal so publishing a file never
renumbers or duplicates ordinary chat lines.
"""
from __future__ import annotations

import json
import mimetypes
import os
import threading
import time
import urllib.parse
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import storage_paths


EVENT_DIR = storage_paths.DATA_ROOT / "聊天文件事件"
EVENT_FILE = EVENT_DIR / "events.jsonl"
LOCK_FILE = EVENT_DIR / ".events.lock"
MAX_EVENTS = 200

_thread_lock = threading.RLock()


def _ensure() -> None:
    EVENT_DIR.mkdir(parents=True, exist_ok=True)


@contextmanager
def _write_lock() -> Iterator[None]:
    """Serialize writers in this process and in the optional CLI process."""
    _ensure()
    with _thread_lock:
        with LOCK_FILE.open("a+b") as handle:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                if handle.tell() == 0:
                    handle.write(b"\0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
                try:
                    yield
                finally:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _read_events() -> list[dict]:
    if not EVENT_FILE.is_file():
        return []
    events: list[dict] = []
    try:
        lines = EVENT_FILE.read_text(encoding="utf-8").splitlines()
    except Exception:
        return []
    for line in lines:
        try:
            value = json.loads(line)
        except Exception:
            continue
        if not isinstance(value, dict):
            continue
        try:
            seq = int(value.get("seq") or 0)
        except Exception:
            seq = 0
        if seq <= 0 or not isinstance(value.get("attachments"), list):
            continue
        value["seq"] = seq
        try:
            stamp_ms = int(value.get("ts_ms") or 0)
        except Exception:
            stamp_ms = 0
        if stamp_ms <= 0:
            try:
                stamp_ms = int(round(float(value.get("at_epoch") or 0) * 1000))
            except Exception:
                stamp_ms = 0
        if stamp_ms > 0:
            value["ts_ms"] = stamp_ms
        events.append(value)
    events.sort(key=lambda item: int(item["seq"]))
    return events


def _save_events(events: list[dict]) -> None:
    _ensure()
    temp = EVENT_FILE.with_name(
        EVENT_FILE.name + f".{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp"
    )
    try:
        with temp.open("w", encoding="utf-8", newline="\n") as output:
            for event in events:
                output.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")))
                output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        os.replace(temp, EVENT_FILE)
        storage_paths.mirror_file(
            EVENT_FILE,
            Path("聊天文件事件") / EVENT_FILE.name,
        )
    finally:
        try:
            if temp.exists():
                temp.unlink()
        except Exception:
            pass


def _conversation(value: str) -> str:
    clean = str(value or "").strip()
    return clean[:120] if clean else "本机"


def _mime(name: str) -> str:
    suffix = Path(name).suffix.lower()
    special = {
        ".apk": "application/vnd.android.package-archive",
        ".epub": "application/epub+zip",
        ".pdf": "application/pdf",
        ".zip": "application/zip",
    }
    return special.get(
        suffix,
        mimetypes.guess_type(name)[0] or "application/octet-stream",
    )


def _event_for_file(path: Path, conversation: str) -> dict:
    name = path.name
    size = int(path.stat().st_size)
    now = time.time()
    return {
        "id": "file-" + uuid.uuid4().hex,
        "at": time.strftime("%m-%d %H:%M", time.localtime(now)),
        "at_epoch": now,
        "ts_ms": int(round(now * 1000)),
        "conv": _conversation(conversation),
        "kind": "ai",
        "text": "",
        "attachments": [{
            "name": name,
            "size": size,
            "mime": _mime(name),
            "remote_url": "/file/" + urllib.parse.quote(name, safe=""),
        }],
    }


def publish_file(path: Path, conversation: str = "") -> dict:
    """Append one already-shared file as a durable incoming chat message."""
    import file_share

    shared = file_share.file_path(Path(path).name)
    if shared is None:
        raise ValueError("文件不在手机分享目录")
    with _write_lock():
        events = _read_events()
        seq = max((int(item["seq"]) for item in events), default=0) + 1
        event = _event_for_file(shared, conversation)
        event["seq"] = seq
        events.append(event)
        _save_events(events[-MAX_EVENTS:])
        return event


def publish_bytes(
    name: str,
    data: bytes,
    conversation: str = "",
) -> dict:
    """Store a posted file in the share directory, then publish its message."""
    import file_share

    saved = file_share.save_shared(name, data)
    if saved is None:
        raise ValueError("文件保存失败")
    return publish_file(saved, conversation)


def list_events(since: int = 0) -> dict:
    """Return events after ``since`` plus the cursor for the next poll."""
    try:
        cursor_in = max(0, int(since))
    except Exception:
        cursor_in = 0
    with _write_lock():
        events = _read_events()
    latest = int(events[-1]["seq"]) if events else 0
    selected = [item for item in events if int(item["seq"]) > cursor_in]
    return {
        "ok": True,
        "events": selected,
        "cursor": latest,
        "latest": latest,
        "reset": cursor_in > latest,
    }
