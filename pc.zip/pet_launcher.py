#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""桌面快捷方式入口：点一下直接出现大肥鱼桌宠。

不再弹「对话模式 / 转录模式 / 只开悬浮窗」那个选择框，也不主动打开旧版悬浮窗。
语音程序没跑就先把它拉起来；桌宠已经开着就只把它叫到前面（Electron 单实例）。
"""

from __future__ import annotations

import ctypes
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG = HERE / "config.json"
STATUS = HERE / "status.json"
VOICE_MUTEX = "VoiceAssistantVoice_v1"
PYTHONW = HERE / ".venv" / "Scripts" / "pythonw.exe"
PET_DIR = HERE / "pet_live"
PET_EXE = PET_DIR / "node_modules" / "electron" / "dist" / "electron.exe"


def runner() -> Path:
    return PYTHONW if PYTHONW.exists() else Path(sys.executable)


def mutex_exists(name: str) -> bool:
    k = ctypes.windll.kernel32
    h = k.OpenMutexW(0x00100000, False, name)
    if h:
        k.CloseHandle(h)
        return True
    return False


def pid_alive(pid: int) -> bool:
    if not pid:
        return False
    k = ctypes.windll.kernel32
    h = k.OpenProcess(0x1000, False, pid)
    if not h:
        return False
    k.CloseHandle(h)
    return True


def voice_running() -> bool:
    if mutex_exists(VOICE_MUTEX):
        return True
    try:
        pid = int(json.loads(STATUS.read_text(encoding="utf-8")).get("pid") or 0)
    except Exception:
        return False
    return pid_alive(pid)


def ensure_config() -> None:
    """快捷方式是“要桌宠”，所以把 pet_enabled 打开；旧版悬浮窗的默认值不动。"""
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8")) if CONFIG.exists() else {}
        if not isinstance(data, dict):
            data = {}
        changed = False
        if not data.get("pet_enabled", True):
            data["pet_enabled"] = True
            changed = True
        if changed:
            CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def start_voice() -> None:
    flags = 0x08000000 if sys.platform == "win32" else 0
    subprocess.Popen([str(runner()), str(HERE / "stt.py"), "--mode", "talk"],
                     cwd=str(HERE), creationflags=flags,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def show_pet() -> None:
    if not PET_EXE.exists() or not (PET_DIR / "main.js").exists():
        return
    flags = 0x08000000 if sys.platform == "win32" else 0
    subprocess.Popen([str(PET_EXE), str(PET_DIR)], cwd=str(PET_DIR),
                     creationflags=flags,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def main() -> int:
    ensure_config()
    if not voice_running():
        start_voice()
        time.sleep(1.8)          # 让 stt.py 先把自己的单实例锁拿到
    # 已经开着时这一下只会触发 second-instance，把桌宠叫到前面
    show_pet()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
