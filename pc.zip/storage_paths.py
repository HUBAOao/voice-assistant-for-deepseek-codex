# -*- coding: utf-8 -*-
"""语音助手持久数据：E 盘为主，F 盘镜像备份。"""
from __future__ import annotations

import shutil
from pathlib import Path

E_ROOT = Path(r"E:\语音助手")
DATA_ROOT = E_ROOT / "数据"
F_ROOT = Path(r"F:\语音助手\备份")
F_DATA_ROOT = F_ROOT / "数据"


def ensure_layout() -> None:
    for p in (
        DATA_ROOT,
        DATA_ROOT / "聊天记录",
        DATA_ROOT / "聊天记录" / "归档",
        DATA_ROOT / "聊天记录" / "已清除",
        DATA_ROOT / "手机屏幕",
        DATA_ROOT / "手机文件",
        DATA_ROOT / "手机上传",
        DATA_ROOT / "试听",
        F_DATA_ROOT,
    ):
        try:
            p.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass


def mirror_file(src: Path, relative: Path | str) -> Path | None:
    """把 E 盘文件镜像到 F 盘同结构位置；失败不影响主文件。"""
    try:
        ensure_layout()
        rel = Path(relative)
        dst = F_DATA_ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return dst
    except Exception:
        return None


def mirror_tree(relative: Path | str) -> None:
    try:
        ensure_layout()
        rel = Path(relative)
        src = DATA_ROOT / rel
        dst = F_DATA_ROOT / rel
        if src.is_dir():
            shutil.copytree(src, dst, dirs_exist_ok=True)
    except Exception:
        pass


def migrate_legacy(source: Path, relative: Path | str) -> Path:
    """首次迁移：旧 C 盘数据复制到 E，保留旧文件作为回滚副本。"""
    ensure_layout()
    dst = DATA_ROOT / Path(relative)
    if source.exists() and not dst.exists():
        try:
            if source.is_dir():
                shutil.copytree(source, dst, dirs_exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, dst)
        except Exception:
            pass
    return dst
