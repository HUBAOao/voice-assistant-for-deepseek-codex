# -*- coding: utf-8 -*-
"""Sound, output-device and voice controls for the overlay settings panel."""
from __future__ import annotations

from ui_widgets import Slider
from overlay_feature.defaults import BG_PANEL, CARD, VOICES


class OverlaySettingsAudioMixin:
    def build_sound(self, parent) -> None:
        row = self._row(parent, "出声开关")
        self._chip(
            row,
            "🔇 静音（我不听，但你说我照办）",
            lambda: (
                self._overlay_send_command("mute"),
                self.flash("已静音：它不念了", 3),
            ),
        ).pack(side="right", padx=(4, 10))
        self._chip(
            row,
            "🔊 恢复出声",
            lambda: (
                self._overlay_send_command("unmute"),
                self.flash("恢复出声", 3),
            ),
        ).pack(side="right", padx=2)
        self.sl_volume = Slider(
            parent, "朗读音量", 0, 100,
            float(self.cfg.get("volume") or 80),
            fmt="{:.0f}%", on_change=self.on_change, bg=BG_PANEL,
        )
        self.sl_rate = Slider(
            parent, "语速", -40, 60,
            self._rate_value(self.cfg.get("rate")),
            fmt="{:+.0f}%", on_change=self.on_change, bg=BG_PANEL,
        )
        row = self._row(parent, "输出设备")
        self.device_label = self.tk.Label(
            row,
            text=self._output_device_text(),
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 8),
        )
        self.device_label.pack(side="left", padx=4)
        self._chip(row, "选择 ▾", self.choose_output_device).pack(
            side="right", padx=(0, 10)
        )
        self.tk.Label(
            parent,
            text="耳机没戴/没连时，声音会播到耳机里；这里可以切到显示器/扬声器",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            anchor="w",
        ).pack(fill="x", padx=(14, 10), pady=(0, 2))
        row = self._row(parent, "音色")
        self.voice_index = self._voice_index()
        self.voice_label = self.tk.Label(
            row,
            text=self._voice_text(),
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9),
        )
        self.voice_label.pack(side="left", padx=4)
        self._chip(row, "试听", lambda: self.preview_voice()).pack(
            side="right", padx=6
        )
        self.voice_drawer_open = False
        self.voice_more = self._chip(
            row, "选择 ▾", lambda: self.toggle_voice_drawer()
        )
        self.voice_more.pack(side="right", padx=(0, 6))
        self.voice_drawer = self.tk.Frame(parent, bg=CARD)
        self.voice_rows = {}
        self._build_voice_drawer()

    def _output_devices(self) -> list[tuple[int, str]]:
        rows: list[tuple[int, str]] = []
        seen: set[str] = set()
        try:
            import sounddevice as sd

            for index, device in enumerate(sd.query_devices()):
                if int(device.get("max_output_channels") or 0) <= 0:
                    continue
                name = str(device.get("name") or "").strip()
                if not name or name in seen:
                    continue
                seen.add(name)
                rows.append((index, name))
        except Exception:
            pass
        return rows

    def _output_device_text(self) -> str:
        value = self.cfg.get("output_device")
        try:
            import sounddevice as sd

            if value in (None, ""):
                index = int(sd.default.device[1])
            else:
                index = int(value)
            name = str(sd.query_devices(index).get("name") or "").strip()
            return ("系统默认 · " if value in (None, "") else "") + name[:30]
        except Exception:
            return "系统默认" if value in (None, "") else f"设备 {value}"

    def choose_output_device(self) -> None:
        tk = self.tk
        menu = tk.Menu(
            self.root,
            tearoff=0,
            bg="#26262d",
            fg="#ffffff",
            activebackground=self.button_color,
            activeforeground="#ffffff",
            font=("Microsoft YaHei UI", 9),
        )
        menu.add_command(
            label="系统默认", command=lambda: self.set_output_device("")
        )
        menu.add_separator()
        for index, name in self._output_devices():
            menu.add_command(
                label=f"{index}  {name[:46]}",
                command=lambda i=index: self.set_output_device(i),
            )
        try:
            menu.tk_popup(
                self.root.winfo_pointerx(), self.root.winfo_pointery()
            )
        finally:
            menu.grab_release()

    def set_output_device(self, value) -> None:
        data = self._overlay_load_config()
        data["output_device"] = value
        self._overlay_write_config(data)
        self.cfg["output_device"] = value
        try:
            self.device_label.config(text=self._output_device_text())
        except Exception:
            pass
        self.flash(
            f"输出设备：{self._output_device_text()}（下一句生效）", 3.5
        )

    def _build_voice_drawer(self) -> None:
        tk = self.tk
        head = tk.Frame(self.voice_drawer, bg=CARD)
        head.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(
            head,
            text=f"想要哪个直接点（一共 {len(VOICES)} 个）",
            bg=CARD,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(head, "收起", lambda: self.toggle_voice_drawer()).pack(
            side="right"
        )
        for index, (_voice, label, _pitch, _fx) in enumerate(VOICES):
            line = tk.Frame(self.voice_drawer, bg=CARD)
            line.pack(fill="x", padx=8, pady=1)
            name = tk.Label(
                line,
                text=label,
                bg=CARD,
                fg="#ffffff",
                anchor="w",
                font=("Microsoft YaHei UI", 9),
                padx=6,
                pady=3,
                cursor="hand2",
            )
            name.pack(side="left", fill="x", expand=True)
            name.bind(
                "<Button-1>", lambda _event, i=index: self.select_voice(i)
            )
            self._chip(
                line, "听", lambda idx=index: self.preview_voice(idx)
            ).pack(side="right", padx=(4, 2))
            self.voice_rows[index] = name
        self.refresh_voice_rows()

    def toggle_voice_drawer(self) -> None:
        self.voice_drawer_open = not bool(
            getattr(self, "voice_drawer_open", False)
        )
        if self.voice_drawer_open:
            self.voice_drawer.pack(fill="x", padx=12, pady=(2, 8))
            self.voice_more.config(text="选择 ▴")
        else:
            self.voice_drawer.pack_forget()
            self.voice_more.config(text="选择 ▾")
        self.root.after(10, self._on_stage_inner)

    def select_voice(self, index: int) -> None:
        self.voice_index = max(0, min(len(VOICES) - 1, int(index)))
        self.voice_label.config(text=self._voice_text())
        self.refresh_voice_rows()
        self.on_change()

    def refresh_voice_rows(self) -> None:
        for index, label in getattr(self, "voice_rows", {}).items():
            label.config(
                bg=self.button_color if index == self.voice_index else CARD,
                fg="#ffffff",
            )
