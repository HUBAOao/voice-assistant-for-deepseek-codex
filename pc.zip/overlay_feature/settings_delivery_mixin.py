# -*- coding: utf-8 -*-
"""Delivery, network and recognition controls for the settings panel."""
from __future__ import annotations

from overlay_feature import runtime as _runtime
from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import CONTROL


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsDeliveryMixin:
    """Build the business controls that send or connect.

    The mixin only composes controls.  Configuration writes, URL discovery,
    device management and commands stay in the existing action methods.
    """

    def build_delivery_section(self, parent) -> None:
        self._group(parent, "发送")
        row = self._row(parent, "发送方式")
        self.send_mode_value = str(self.cfg.get("send_mode") or "paste_enter")
        self.send_chips = {}
        for value, label in (
            ("paste_enter", "粘贴并回车"),
            ("paste", "只粘贴"),
            ("type", "当打字机"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_send_mode(current),
            )
            chip.pack(side="left", padx=3)
            self.send_chips[value] = chip
        self.refresh_send_chips()
        self.sw_confirm = self._switch_row(
            parent,
            "发之前先问我",
            bool(self.cfg.get("confirm_send", False)),
        )
        self.sw_follow = self._switch_row(
            parent,
            "跟着当前窗口发",
            bool(self.cfg.get("follow_foreground", False)),
        )
        self.sw_readreply = self._switch_row(
            parent,
            "自动念回答",
            bool(self.cfg.get("read_reply", True)),
        )
        self.sw_tray = self._switch_row(
            parent,
            "托盘图标",
            bool(self.cfg.get("tray_enabled", True)),
        )
        self.sw_gate = self._switch_row(
            parent,
            "只认我的声音",
            bool(self.cfg.get("voiceprint_gate", False)),
        )

        self.sw_phone = self._switch_row(
            parent,
            "手机入口",
            bool(self.cfg.get("phone_enabled", True)),
        )
        row = self._row(parent, "手机网址")
        try:
            import phone_link

            url_now = phone_link.phone_url(
                int(self.cfg.get("phone_port") or 8765)
            )
        except Exception:
            url_now = "（读不到网卡地址，重启后再看）"
        self.phone_url_label = self.tk.Label(
            row,
            text=url_now,
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        )
        self.phone_url_label.pack(side="left", padx=(0, 6))
        self._chip(row, "复制", lambda: self.copy_phone_url()).pack(side="right")
        self._chip(row, "二维码", lambda: self.show_qr()).pack(
            side="right", padx=(0, 6)
        )
        self.tk.Label(
            parent,
            text="手机连同一个 Wi-Fi，浏览器打开这条网址就行；"
                 "出门在外面要用，点下面「外网访问」的一键开启",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            wraplength=360,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 4))

        self._group(parent, "外网访问（在外面也能连）")
        self.remote_label = self.tk.Label(
            parent,
            text="正在看…",
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            justify="left",
            wraplength=350,
            font=("Microsoft YaHei UI", 8),
        )
        self.remote_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(parent, "外网访问")
        self._chip(row, "一键开启", self.remote_enable).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "二维码", self.show_remote_qr).pack(
            side="right", padx=2
        )
        self._chip(row, "复制地址", self.copy_remote_url).pack(
            side="right", padx=2
        )
        self._chip(row, "刷新", self.refresh_remote).pack(
            side="right", padx=2
        )
        row = self._row(parent, "公网地址")
        self._chip(row, "开（手机免装）", self.remote_funnel_on).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "复制", self.copy_public_url).pack(
            side="right", padx=2
        )
        self._chip(row, "关掉", self.remote_funnel_off).pack(
            side="right", padx=2
        )

        row = self._row(parent, "能连的设备")
        self.devices_label = self.tk.Label(
            row,
            text="…",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        )
        self.devices_label.pack(side="left")
        self._chip(row, "名单", self.show_device_list).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "连接记录", self.show_access_log).pack(
            side="right", padx=2
        )
        row = self._row(parent, "手机令牌")
        self._chip(row, "换一条", self.rotate_phone_token).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            row,
            text="怕链接泄漏了就换",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self.refresh_devices_label()

        self._group(parent, "识别")
        row = self._row(parent, "唤醒词训练")
        self.tk.Label(
            row,
            text="念三遍让它记住你的口音",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(
            row,
            "开始训练",
            lambda: (
                send_command("expand"),
                self.flash("对着麦克风说「训练唤醒词」", 3),
            ),
        ).pack(side="right", padx=(4, 10))
        row = self._row(parent, "识别模型")
        self.model_value = str(
            self.cfg.get("model") or "large-v3-turbo"
        )
        self.model_chips = {}
        for value, label in (
            ("small", "小(快)"),
            ("medium", "中"),
            ("large-v3-turbo", "大(准)"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_model(current),
            )
            chip.pack(side="left", padx=3)
            self.model_chips[value] = chip
        self.refresh_model_chips()
        row = self._row(parent, "识别语言")
        self.lang_value = str(self.cfg.get("lang") or "zh")
        self.lang_chips = {}
        for value, label in (
            ("zh", "中文"),
            ("zh,en", "中英混说"),
            ("en", "英文"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_lang(current),
            )
            chip.pack(side="left", padx=3)
            self.lang_chips[value] = chip
        self.refresh_lang_chips()
        row = self._row(parent, "改完生效")
        self.tk.Label(
            row,
            text="改模型或语言后要点重启",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(row, "重启程序", self.restart_program).pack(
            side="right", padx=(4, 10)
        )
        self.sw_rec = self._switch_row(
            parent,
            "录音提示灯",
            bool(self.cfg.get("rec_indicator", True)),
        )
