# -*- coding: utf-8 -*-
"""Rendering for the complete overlay window."""
from __future__ import annotations

import time

from overlay_feature.window_support import (
    LABELS,
    Image,
    ImageDraw,
    font,
    mix,
)


class WindowRenderMixin:
    def draw_full(
        self,
        image,
        draw,
        wave_color: str,
        state_color: str,
        speak_active: bool,
        speak_text: str,
        speak_progress: float,
    ) -> None:
        width = image.width
        if self.show_status:
            x, y, size = self.layout["status"]
            label = LABELS.get(self.state, self.state)
            if self.focus_left > 0:
                label = LABELS["focus"]
            if self.sleep_stage >= 2:
                label = LABELS["sleepy"]
            if time.time() < self.toast_until:
                label = self.toast
            label_font = font(size)
            bounds = draw.textbbox((0, 0), label, font=label_font)
            x0 = width + x - (bounds[2] - bounds[0]) if x < 0 else x
            draw.text(
                (x0, y),
                label,
                font=label_font,
                fill=mix(
                    self.panel_color,
                    state_color,
                    min(1.0, 0.3 + self.text_fade),
                ),
            )
        bands = list((self.status or {}).get("bands") or [])
        if (
            self.spectrum_on
            and bands
            and not speak_active
            and self.focus_left <= 0
        ):
            self.draw_spectrum(image, draw, wave_color, bands)
        elif self.focus_left > 0:
            self.draw_focus(
                image,
                draw,
                wave_color,
                1.0 - self.focus_left / max(1.0, self.focus_total),
            )
        else:
            self.draw_voice(image, wave_color)
        gap, height = self.layout["wave"]
        self.draw_caption(
            draw,
            width,
            image.height - gap - height,
            speak_text if speak_active else "",
            speak_progress,
        )
        if self.show_switch:
            sprite = self.switch_sprite(self.switch_pos)
            x0, y0 = self.switch_rect()
            image.paste(sprite, (x0, y0), sprite)
        self._draw_speaker_icon(image)
        self.draw_arrow(draw, width)

    def _draw_speaker_icon(self, image) -> None:
        try:
            muted = bool(self.cfg.get("muted"))
            size = max(9, int(self.layout["status"][2] * 0.85))
            scale = 8
            tile = Image.new(
                "RGBA",
                (size * scale, size * scale),
                (0, 0, 0, 0),
            )
            draw = ImageDraw.Draw(tile)
            color = (
                (255, 209, 102, 255)
                if muted
                else (61, 220, 132, 255)
            )
            unit = size * scale / 24.0

            def point(x, y):
                return x * unit, y * unit

            draw.rounded_rectangle(
                [point(3, 9.5), point(7.5, 14.5)],
                radius=1.5 * unit,
                fill=color,
            )
            draw.polygon(
                [
                    point(7.5, 9.5),
                    point(11.5, 6),
                    point(11.5, 18),
                    point(7.5, 14.5),
                ],
                fill=color,
            )
            if muted:
                draw.line(
                    [point(14, 7.5), point(20.5, 16.5)],
                    fill=color,
                    width=max(1, int(1.6 * unit)),
                )
            else:
                draw.arc(
                    [point(8.5, 8), point(15.5, 16)],
                    -70,
                    70,
                    fill=color,
                    width=max(1, int(1.5 * unit)),
                )
                draw.arc(
                    [point(8.5, 4.5), point(19.5, 19.5)],
                    -70,
                    70,
                    fill=color,
                    width=max(1, int(1.5 * unit)),
                )
            tile = tile.resize((size, size), Image.LANCZOS)
            alpha = tile.getchannel("A").point(
                lambda value: int(value * 0.55)
            )
            tile.putalpha(alpha)
            padding = max(3, int(size * 0.35))
            image.paste(
                tile,
                (
                    padding,
                    max(0, image.height - size - padding),
                ),
                tile,
            )
        except Exception:
            pass
