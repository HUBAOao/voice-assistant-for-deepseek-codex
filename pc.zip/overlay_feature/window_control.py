# -*- coding: utf-8 -*-
"""Win32 window-control boundary for the desktop overlay.

The rest of FinDeck can call this small API without duplicating ctypes calls.
macOS/Linux remain intentionally deferred by product decision, so unsupported
platforms degrade to no-op/failure instead of pretending the calls worked.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path


WS_EX_NOACTIVATE = 0x08000000
WS_EX_TOOLWINDOW = 0x00000080
RDW_INVALIDATE = 0x0001
RDW_ERASE = 0x0004
RDW_ALLCHILDREN = 0x0080
RDW_UPDATENOW = 0x0100


def virtual_screen() -> tuple[int, int, int, int]:
    """Return the full virtual desktop; keep the legacy 1920x1080 fallback."""
    if os.name != "nt":
        return 0, 0, 1920, 1080
    try:
        user32 = ctypes.windll.user32
        return (
            user32.GetSystemMetrics(76),
            user32.GetSystemMetrics(77),
            user32.GetSystemMetrics(78),
            user32.GetSystemMetrics(79),
        )
    except Exception:
        return 0, 0, 1920, 1080


def window_handles(inner_hwnd: int) -> list[int]:
    """Return the Tk child and its top-level parent handles."""
    if os.name != "nt" or not inner_hwnd:
        return []
    try:
        outer = ctypes.windll.user32.GetParent(int(inner_hwnd)) or int(inner_hwnd)
        return [handle for handle in {int(outer), int(inner_hwnd)} if handle]
    except Exception:
        return [int(inner_hwnd)]


def make_no_activate(hwnd: int) -> None:
    if os.name != "nt" or not hwnd:
        return
    try:
        user32 = ctypes.windll.user32
        style = user32.GetWindowLongW(int(hwnd), -20)
        user32.SetWindowLongW(
            int(hwnd),
            -20,
            style | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW,
        )
    except Exception:
        pass


def make_window_tree_no_activate(inner_hwnd: int) -> None:
    """Apply the no-activate style to Tk's child and outer wrapper."""
    for hwnd in window_handles(inner_hwnd):
        make_no_activate(hwnd)


def enable_precise_timer(period_ms: int = 1) -> bool:
    """Raise the Windows timer resolution for high-frame-rate animation."""
    if os.name != "nt":
        return False
    try:
        return bool(ctypes.windll.winmm.timeBeginPeriod(int(period_ms))) or True
    except Exception:
        return False


def disable_precise_timer(period_ms: int = 1) -> None:
    if os.name != "nt":
        return
    try:
        ctypes.windll.winmm.timeEndPeriod(int(period_ms))
    except Exception:
        pass


def refresh_window_tree(hwnd: int) -> None:
    """Force Windows to repaint child controls after a layered resize."""
    if os.name != "nt" or not hwnd:
        return
    try:
        ctypes.windll.user32.RedrawWindow(
            ctypes.c_void_p(int(hwnd)),
            None,
            None,
            RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN | RDW_UPDATENOW,
        )
    except Exception:
        pass


def hide_path(path: Path | str) -> bool:
    """Set the Windows hidden attribute; other platforms report no-op success."""
    if os.name != "nt":
        return True
    try:
        return bool(ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x02))
    except Exception:
        return False


def set_no_activate(hwnd: int, no_activate: bool) -> None:
    if os.name != "nt" or not hwnd:
        return
    try:
        user32 = ctypes.windll.user32
        style = user32.GetWindowLongW(int(hwnd), -20)
        style = style | WS_EX_NOACTIVATE if no_activate else style & ~WS_EX_NOACTIVATE
        user32.SetWindowLongW(int(hwnd), -20, style)
    except Exception:
        pass


def grab_foreground(hwnd: int) -> bool:
    """Temporarily attach to the foreground input queue and focus our window."""
    if os.name != "nt" or not hwnd:
        return False
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    attached = False
    focused = False
    current_thread = 0
    foreground_thread = 0
    try:
        foreground = user32.GetForegroundWindow()
        current_thread = kernel32.GetCurrentThreadId()
        foreground_thread = (
            user32.GetWindowThreadProcessId(foreground, None)
            if foreground
            else 0
        )
        if foreground_thread and foreground_thread != current_thread:
            attached = bool(
                user32.AttachThreadInput(current_thread, foreground_thread, True)
            )
        user32.ShowWindow(int(hwnd), 5)
        user32.BringWindowToTop(int(hwnd))
        focused = bool(user32.SetForegroundWindow(int(hwnd)))
        user32.SetFocus(int(hwnd))
    except Exception:
        try:
            focused = bool(ctypes.windll.user32.SetForegroundWindow(int(hwnd)))
        except Exception:
            focused = False
    finally:
        if attached and current_thread and foreground_thread:
            try:
                user32.AttachThreadInput(
                    current_thread,
                    foreground_thread,
                    False,
                )
            except Exception:
                pass
    return focused


def set_keyboard_activation(
    handles: list[int],
    enabled: bool,
    *,
    grab: bool = True,
) -> bool:
    """Toggle no-activate on all overlay handles and optionally focus it."""
    usable = [int(handle) for handle in handles if handle]
    for hwnd in usable:
        set_no_activate(hwnd, not enabled)
    if enabled and usable and grab:
        return grab_foreground(usable[0])
    return bool(enabled)
