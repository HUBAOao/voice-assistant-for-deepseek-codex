# -*- coding: utf-8 -*-
"""Large-caption window lifecycle for the settings overlay."""
from __future__ import annotations

import time

from overlay_feature.runtime import make_no_activate, virtual_screen


class OverlaySettingsCaptionMixin:
    """Own the accessibility caption window without the settings shell."""

    def make_big_caption(self) -> None:
        if self.caption_win is not None:
            return
        tk = self.tk
        try:
            win = tk.Toplevel(self.root)
        except Exception:
            return
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        try:
            win.attributes("-alpha", 0.9)
        except Exception:
            pass
        win.configure(bg="#08080a")
        lab = tk.Label(
            win,
            text="",
            bg="#08080a",
            fg="#ffffff",
            font=("Microsoft YaHei UI", self.big_size),
            justify="center",
        )
        lab.pack(fill="both", expand=True, padx=18, pady=10)
        self.caption_win, self.caption_label = win, lab
        try:
            make_no_activate(win.winfo_id())
        except Exception:
            pass
        self.place_big_caption()

    def place_big_caption(self) -> None:
        if self.caption_win is None:
            return
        try:
            vx, vy, vw, vh = virtual_screen()
            width = int(vw * 0.84)
            height = max(90, int(self.big_size * 2.4))
            self.caption_win.geometry(
                f"{width}x{height}+{vx + (vw - width) // 2}"
                f"+{vy + vh - height - 64}"
            )
            self.caption_label.config(font=("Microsoft YaHei UI", self.big_size))
        except Exception:
            pass

    def sync_big_caption(self) -> None:
        if not self.big_on:
            if self.caption_win is not None:
                try:
                    self.caption_win.destroy()
                except Exception:
                    pass
                self.caption_win = self.caption_label = None
            return
        if self.caption_win is None:
            self.make_big_caption()
        text = str((self.status or {}).get("text") or "").strip()
        if not text and self.focus_left > 0:
            left = int(self.focus_left)
            text = f"专注 {left // 60:02d}:{left % 60:02d}"
        if text and text != self.caption_last:
            self.caption_last = text
            self.caption_at = time.time()
            try:
                self.caption_label.config(text=text, fg="#ffffff")
            except Exception:
                pass
        elif self.caption_last and time.time() - self.caption_at > 8:
            self.caption_last = ""
            try:
                self.caption_label.config(text="")
            except Exception:
                pass
