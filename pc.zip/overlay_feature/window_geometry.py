# -*- coding: utf-8 -*-
"""Pure window placement and hit-test rules for the FinDeck overlay.

Keeping these calculations independent of Tk and Win32 makes multi-monitor,
edge snapping and panel placement testable without opening a GUI.
"""
from __future__ import annotations


Rect = tuple[int, int, int, int]


def clamp_axis(value: int, start: int, extent: int, size: int) -> int:
    """Keep a span inside an axis while allowing oversized windows."""
    high = max(start, start + extent - int(size))
    return min(max(int(value), start), high)


def clamp_position(
    x: int,
    y: int,
    width: int,
    height: int,
    viewport: Rect,
    margin: int = 0,
) -> tuple[int, int]:
    vx, vy, vw, vh = viewport
    left = vx + max(0, margin)
    top = vy + max(0, margin)
    right = vx + vw - max(0, margin)
    bottom = vy + vh - max(0, margin)
    return (
        clamp_axis(int(x), left, max(0, right - left), width),
        clamp_axis(int(y), top, max(0, bottom - top), height),
    )


def nearest_edge(
    x: int,
    y: int,
    width: int,
    height: int,
    viewport: Rect,
    snap_px: int,
) -> str:
    vx, vy, vw, vh = viewport
    distances = {
        "left": int(x) - vx,
        "right": (vx + vw) - (int(x) + int(width)),
        "top": int(y) - vy,
        "bottom": (vy + vh) - (int(y) + int(height)),
    }
    edge, distance = min(distances.items(), key=lambda item: item[1])
    limit = max(0, int(snap_px))
    return edge if -limit <= distance <= limit else ""


def dock_position(
    edge: str,
    x: int,
    y: int,
    width: int,
    height: int,
    viewport: Rect,
) -> tuple[int, int]:
    vx, vy, vw, vh = viewport
    x, y = int(x), int(y)
    width, height = int(width), int(height)
    if edge == "left":
        return vx, clamp_axis(y, vy, vh, height)
    if edge == "right":
        return vx + vw - width, clamp_axis(y, vy, vh, height)
    if edge == "top":
        return clamp_axis(x, vx, vw, width), vy
    if edge == "bottom":
        return clamp_axis(x, vx, vw, width), vy + vh - height
    return x, y


def panel_position(
    anchor_x: int,
    anchor_y: int,
    header_height: int,
    compact_width: int,
    panel_width: int,
    panel_height: int,
    viewport: Rect,
    margin: int = 8,
) -> tuple[int, int]:
    """Place the settings panel below the overlay, or above near the bottom."""
    vx, vy, vw, vh = viewport
    margin = max(0, int(margin))
    panel_width, panel_height = int(panel_width), int(panel_height)
    x = int(anchor_x) - max(0, (panel_width - int(compact_width)) // 2)
    if x + panel_width > vx + vw - margin:
        x = vx + vw - panel_width - margin
    if x < vx + margin:
        x = vx + margin
    y = int(anchor_y) + int(header_height) - 1
    if y + panel_height > vy + vh - margin:
        y = int(anchor_y) - panel_height + 1
    if y < vy + margin:
        y = vy + margin
    return int(x), int(y)


def point_in_rect(x: int, y: int, rect: Rect) -> bool:
    left, top, width, height = rect
    return left <= x <= left + width and top <= y <= top + height


def switch_rect(current_width: int, configured_x: int, switch_width: int) -> Rect:
    """Return the switch hit box; negative X is measured from the right edge."""
    x = (
        int(current_width) + int(configured_x) - int(switch_width)
        if int(configured_x) < 0
        else int(configured_x)
    )
    return x, 0, int(switch_width), 0


def arrow_rect(
    current_width: int,
    header_height: int,
    arrow_size: int,
    right_gap: int = 10,
    bottom_gap: int = 8,
) -> Rect:
    x = int(current_width) - int(arrow_size) - int(right_gap)
    y = int(header_height) - int(arrow_size) - int(bottom_gap)
    return x, y, int(arrow_size), int(arrow_size)


def default_position(
    viewport: Rect,
    width: int,
    right_gap: int = 40,
    top: int = 60,
) -> tuple[int, int]:
    vx, vy, vw, _vh = viewport
    return vx + vw - int(width) - int(right_gap), vy + int(top)
