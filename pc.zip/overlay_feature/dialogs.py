# -*- coding: utf-8 -*-
"""Overlay About and searchable dialog-log windows."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import version
from overlay_feature.defaults import BG_PANEL, CARD

SYSLOG_FILE = Path(__file__).resolve().parents[1] / "syslog.md"


class OverlayDialogMixin:
    def _syslog_path(self) -> Path:
        """Follow the owning overlay module's syslog override.

        Tests and portable builds may point ``overlay.SYSLOG_FILE`` at another
        location after this module has been imported.  Keeping a second,
        import-time constant here silently reads the wrong file.
        """
        owner = sys.modules.get(type(self).__module__)
        return Path(getattr(owner, "SYSLOG_FILE", SYSLOG_FILE))

    def show_about(self) -> None:
        """关于：作者、邮箱、版权、使用许可 —— 全软件只在这一个窗口里显示。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("关于")
        win.configure(bg=BG_PANEL)
        win.geometry("460x430")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text=f"{version.PRODUCT_NAME} · {self.name}", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w", padx=18,
                                                               pady=(16, 2))
        tk.Label(win, text=version.label(), bg=BG_PANEL, fg="#8a8a95",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18)
        box = tk.Frame(win, bg=CARD)
        box.pack(fill="x", padx=18, pady=(12, 10))
        for text, color, size in (
                (f"作者：{version.AUTHOR}", "#ffffff", 11),
                (f"邮箱：{version.CONTACT}", "#ffffff", 11),
                (version.COPYRIGHT, "#9a9aa5", 10),
                (version.FREE_LINE, self.accent, 10)):
            tk.Label(box, text=text, bg=CARD, fg=color, anchor="w", justify="left",
                     wraplength=390, font=("Microsoft YaHei UI", size)).pack(
                         anchor="w", padx=14, pady=(8 if size == 11 else 2, 0))
        tk.Label(box, text="", bg=CARD, font=("Microsoft YaHei UI", 4)).pack()
        tk.Label(win, text=version.NOTICE, bg=BG_PANEL, fg="#6f6f7a", anchor="w",
                 justify="left", wraplength=400,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=18)
        close = tk.Label(win, text="知道了", bg=self.button_color, fg="#ffffff",
                         font=("Microsoft YaHei UI", 10, "bold"), padx=22, pady=6,
                         cursor="hand2")
        close.pack(pady=(14, 12))
        close.bind("<Button-1>", lambda _e: win.destroy())
        win.bind("<Escape>", lambda _e: win.destroy())
        try:
            win.lift()
            win.focus_force()
        except Exception:
            pass

    def log_summary(self) -> str:
        """系统日志现在有多大、有多少行。"""
        path = self._syslog_path()
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return "（还没有记录）"
        size = path.stat().st_size
        return f"{len(lines)} 行 · {size / 1024:.0f} KB · syslog.md"

    def open_syslog(self) -> None:
        try:
            os.startfile(str(self._syslog_path()))
        except Exception:
            self.flash("打不开日志文件", 2)

    # ------------------------------------------------- 对话日志小窗口
    LOG_KINDS = {           # 日志里的标记 -> (给你的名字, 颜色)
        "听": ("你说", "#3ddc84"),
        "发": ("发出去", "#4aa3ff"),
        "念": ("它念", "#22d3ee"),
        "答": ("AI 回答", "#c084fc"),
        "做": ("做的事", "#c9a227"),
        "编": ("改设置", "#9a9aa5"),
        "声": ("声纹", "#7f7f8a"),
        "噪": ("噪声", "#6f6f7a"),
        "醒": ("唤醒", "#7fd4a8"),
    }
    TALK_KINDS = ("听", "发", "念", "答")

    def open_log_window(self) -> None:
        """对话日志做成一个小窗口，直接在里头看，不用去开记事本。"""
        tk = self.tk
        win = getattr(self, "log_win", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.deiconify()
                    win.lift()
                    self.refresh_log_window()
                    return
            except Exception:
                pass
        win = tk.Toplevel(self.root)
        self.log_win = win
        win.title("对话日志")
        win.configure(bg=BG_PANEL)
        win.geometry("620x460")
        win.minsize(420, 280)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(12, 2))
        tk.Label(head, text="对话日志", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left")
        self.log_count = tk.Label(head, text="", bg=BG_PANEL, fg="#6f6f7a",
                                  font=("Microsoft YaHei UI", 8))
        self.log_count.pack(side="right")
        tk.Label(win, text="你和它说过的每句话、它发出去的和念出来的，都在这儿（越往下越新）",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 anchor="w").pack(fill="x", padx=14, pady=(0, 6))

        tool = tk.Frame(win, bg=BG_PANEL)
        tool.pack(fill="x", padx=14, pady=(0, 4))
        self.log_only_talk = tk.BooleanVar(value=True)
        self.log_filter_chips = {}
        for value, label in ((True, "只看对话"), (False, "全都看")):
            chip = tk.Label(tool, text=label, bg=CARD, fg="#ffffff", padx=10, pady=3,
                            cursor="hand2", font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=(0, 4))
            chip.bind("<Button-1>", lambda _e, v=value: self.set_log_filter(v))
            self.log_filter_chips[value] = chip
        tk.Label(tool, text="搜", bg=BG_PANEL, fg="#9a9aa5",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(8, 2))
        self.log_search = tk.StringVar(value="")
        entry = tk.Entry(tool, textvariable=self.log_search, bg=CARD, fg="#ffffff",
                         insertbackground="#ffffff", relief="flat",
                         font=("Microsoft YaHei UI", 9))
        entry.pack(side="left", fill="x", expand=True, padx=(0, 6), ipady=2)
        self.log_search.trace_add("write", lambda *_a: self.refresh_log_window())
        again = tk.Label(tool, text="刷新", bg=CARD, fg="#ffffff", padx=10, pady=3,
                         cursor="hand2", font=("Microsoft YaHei UI", 9))
        again.pack(side="right")
        again.bind("<Button-1>", lambda _e: self.refresh_log_window())

        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=14)
        text = tk.Text(body, bg="#16161b", fg="#d8d8e0", relief="flat", wrap="word",
                       insertbackground="#ffffff", font=("Microsoft YaHei UI", 9),
                       padx=10, pady=8, spacing1=1, spacing3=2, height=12)
        bar = tk.Scrollbar(body, command=text.yview, bg=CARD, troughcolor=BG_PANEL,
                           relief="flat", width=12)
        text.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        text.tag_config("stamp", foreground="#5f5f68")
        for tag, (_name, color) in self.LOG_KINDS.items():
            text.tag_config(tag, foreground=color)
        text.tag_config("body", foreground="#d8d8e0")
        self.log_text = text

        foot = tk.Frame(win, bg=BG_PANEL)
        foot.pack(fill="x", padx=14, pady=(6, 12))
        close = tk.Label(foot, text="关闭", bg=CARD, fg="#ffffff", padx=16, pady=5,
                         cursor="hand2", font=("Microsoft YaHei UI", 9))
        close.pack(side="right")
        close.bind("<Button-1>", lambda _e: self.close_log_window())
        note_btn = tk.Label(foot, text="用记事本打开", bg=BG_PANEL, fg="#9a9aa5",
                            padx=8, pady=5, cursor="hand2", font=("Microsoft YaHei UI", 8))
        note_btn.pack(side="right", padx=6)
        note_btn.bind("<Button-1>", lambda _e: self.open_syslog())
        self.log_hint = tk.Label(foot, text="", bg=BG_PANEL, fg="#6f6f7a",
                                 font=("Microsoft YaHei UI", 8))
        self.log_hint.pack(side="left")
        win.bind("<Escape>", lambda _e: self.close_log_window())
        win.protocol("WM_DELETE_WINDOW", self.close_log_window)
        self._log_seen = 0
        self.refresh_log_window()
        self._log_tick()

    def close_log_window(self) -> None:
        win = getattr(self, "log_win", None)
        self.log_win = None
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass

    def set_log_filter(self, only_talk: bool) -> None:
        self.log_only_talk.set(bool(only_talk))
        for value, chip in getattr(self, "log_filter_chips", {}).items():
            chip.config(bg=self.button_color if value == only_talk else CARD)
        self.refresh_log_window()

    def refresh_log_window(self) -> None:
        text = getattr(self, "log_text", None)
        if text is None:
            return
        try:
            if not self.log_win.winfo_exists():
                return
        except Exception:
            return
        only = bool(getattr(self, "log_only_talk", None) and self.log_only_talk.get())
        needle = (getattr(self, "log_search", None) and self.log_search.get().strip()) or ""
        path = self._syslog_path()
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            lines = []
        rows = []
        for line in lines[-900:]:                     # 再多也没人往下翻
            kind = ""
            if line.startswith("20") and "[" in line:
                try:
                    kind = line.split("[", 1)[1].split("]", 1)[0]
                except Exception:
                    kind = ""
            if only and kind not in self.TALK_KINDS:
                continue
            if needle and needle not in line:
                continue
            rows.append((kind, line))
        try:
            at_bottom = text.yview()[1] > 0.97
        except Exception:
            at_bottom = True
        text.configure(state="normal")
        text.delete("1.0", "end")
        for kind, line in rows:
            stamp, rest = line[:19], line[19:]
            text.insert("end", stamp, "stamp")
            text.insert("end", rest + "\n", kind if kind in self.LOG_KINDS else "body")
        text.configure(state="disabled")
        for value, chip in getattr(self, "log_filter_chips", {}).items():
            chip.config(bg=self.button_color if value == only else CARD)
        if getattr(self, "log_count", None) is not None:
            self.log_count.config(text=f"{len(rows)} 行"
                                       + (f" · 搜「{needle}」" if needle else ""))
        if at_bottom or getattr(self, "_log_seen", 0) != len(rows):
            text.see("end")
        self._log_seen = len(rows)
        if getattr(self, "log_hint", None) is not None:
            self.log_hint.config(text="新的一行会自动跳到底；往上翻就不会被拽走了")

    def _log_tick(self) -> None:
        """开着的时候每两秒自己刷一次，不用手点。"""
        win = getattr(self, "log_win", None)
        if win is None:
            return
        try:
            if not win.winfo_exists():
                return
        except Exception:
            return
        path = self._syslog_path()
        try:
            size = path.stat().st_mtime_ns
        except OSError:
            size = 0
        if size != getattr(self, "_log_mtime", None):
            self._log_mtime = size
            self.refresh_log_window()
        try:
            win.after(2000, self._log_tick)
        except Exception:
            pass
