# -*- coding: utf-8 -*-
"""Panel keyboard focus and option chip actions."""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

from overlay_feature import window_control as _window_control
from overlay_feature.window_support import CARD


class PanelActionsMixin:
    def hwnds(self) -> list[int]:
        return _window_control.window_handles(self.root.winfo_id())

    def allow_keyboard(self, enabled: bool) -> None:
        try:
            _window_control.set_keyboard_activation(
                self.hwnds(),
                enabled,
                grab=True,
            )
        except Exception:
            pass

    def focus_entry(self, widget) -> None:
        self.allow_keyboard(True)
        self.set_editing(True)
        try:
            _window_control.grab_foreground(self.hwnds()[0])
            self.root.focus_force()
            widget.focus_set()
            widget.icursor("end")
            _window_control.grab_foreground(widget.winfo_id())
        except Exception:
            pass

    def set_editing(self, on: bool) -> None:
        if on == self.editing_on:
            return
        self.editing_on = on
        self.edit_touch = time.time()
        self._send_command("editing-on" if on else "editing-off")
        self._inputlog(
            "编辑状态 = "
            + ("开（主程序先别抢焦点）" if on else "关")
        )

    def _pick_chip(self, chips: dict, value: str) -> None:
        for key, chip in chips.items():
            chip.config(
                bg=self.button_color if key == value else CARD,
                fg="#ffffff",
            )

    def set_send_mode(self, value: str) -> None:
        self.send_mode_value = value
        self._pick_chip(self.send_chips, value)
        self.on_change()
        labels = {
            "paste_enter": "粘贴并回车",
            "paste": "只粘贴",
            "type": "当打字机",
        }
        self.flash("发送方式：" + labels.get(value, value), 2)

    def set_input_mode(self, value: str) -> None:
        self.input_mode_value = value if value in ("talk", "hold") else "talk"
        self._pick_chip(self.input_mode_chips, self.input_mode_value)
        self.on_change()
        self.refresh_autostart_mode()
        labels = {
            "talk": "自动对话",
            "hold": "按住说话，松手发送",
        }
        self.flash(
            "说话方式：" + labels[self.input_mode_value]
            + "；点「重启程序」生效",
            3,
        )

    def set_hold_key(self, value: str) -> None:
        self.hold_key_value = str(value or "*")
        self._pick_chip(self.hold_key_chips, self.hold_key_value)
        self.on_change()
        self.refresh_autostart_mode()
        labels = {"*": "小键盘 *", "f9": "F9", "space": "空格"}
        self.flash(
            "按住键：" + labels.get(self.hold_key_value, self.hold_key_value)
            + "；点「重启程序」生效",
            3,
        )

    def set_model(self, value: str) -> None:
        self.model_value = value
        self._pick_chip(self.model_chips, value)
        self.on_change()
        self.flash("模型改好了，点「重启程序」生效", 3)

    def set_lang(self, value: str) -> None:
        self.lang_value = value
        self._pick_chip(self.lang_chips, value)
        self.on_change()
        self.flash("语言改好了，点「重启程序」生效", 3)

    def refresh_send_chips(self) -> None:
        self._pick_chip(
            getattr(self, "send_chips", {}),
            self.send_mode_value,
        )

    def refresh_input_mode_chips(self) -> None:
        self._pick_chip(
            getattr(self, "input_mode_chips", {}),
            self.input_mode_value,
        )

    def refresh_hold_key_chips(self) -> None:
        self._pick_chip(
            getattr(self, "hold_key_chips", {}),
            self.hold_key_value,
        )

    def refresh_model_chips(self) -> None:
        self._pick_chip(
            getattr(self, "model_chips", {}),
            self.model_value,
        )

    def refresh_lang_chips(self) -> None:
        self._pick_chip(
            getattr(self, "lang_chips", {}),
            self.lang_value,
        )

    def restart_program(self) -> None:
        self.flash("正在重启语音程序…", 3)
        self._send_command("restart")

    def refresh_autostart_mode(self) -> None:
        """Let an existing login shortcut read the selected mode from config."""
        script = Path(__file__).resolve().parents[1] / "autostart.ps1"
        if not script.exists():
            return
        try:
            subprocess.Popen(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                    "-AppDir",
                    str(script.parent),
                    "-Action",
                    "refresh",
                    "-Mode",
                    "config",
                ],
                creationflags=0x08000000,
            )
        except Exception:
            pass

    def ask_clear(self) -> None:
        self.flash("要清空就说「清空所有记录」再「确定清空」", 3)
