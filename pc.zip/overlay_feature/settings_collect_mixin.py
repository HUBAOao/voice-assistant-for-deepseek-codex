# -*- coding: utf-8 -*-
"""Collect visible settings widgets into one durable configuration snapshot."""
from __future__ import annotations

import version
import wake_levels
from overlay_feature.defaults import DEFAULTS, VOICES
from overlay_feature.runtime import CONFIG, load_config


class OverlaySettingsCollectMixin:
    """Own widget-to-config collection without saving or rebuilding the panel."""

    def collect(self) -> dict:
        data = load_config(CONFIG)
        data.update({
            "name": self.entry_name.get().strip() or version.ASSISTANT_NAME,
            "wake_word": self.entry_wake.get().strip() or "大肥鱼",
            "greeting_text": self.entry_greeting.get().strip(),
            "greeting_enabled": self.sw_greeting.get(),
            "user_name": self.entry_user.get().strip(),
            "name_freq": self.name_freq_value,
            "ack_text": self.entry_ack.get().strip() or DEFAULTS["ack_text"],
            "ack_enabled": self.sw_ack.get(),
            "self_name": self.entry_self.get().strip() or "大肥鱼",
            "self_talk": self.sw_self.get(),
            "self_freq": self.self_freq_value,
            "volume": int(self.sl_volume.get()),
            "rate": f"{int(self.sl_rate.get()):+d}%",
            "voice": VOICES[self.voice_index][0],
            "voice_pitch": VOICES[self.voice_index][2],
            "voice_fx": VOICES[self.voice_index][3],
            "voice_preset": int(self.voice_index),
            "overlay_width": int(self.sl_width.get()),
            "overlay_height": int(self.sl_height.get()),
            "overlay_color": self.sw_color[0].itemcget(self.sw_color[1], "fill"),
            "overlay_accent": self.sw_accent[0].itemcget(self.sw_accent[1], "fill"),
            "overlay_button": self.sw_button[0].itemcget(self.sw_button[1], "fill"),
            "overlay_text": self.sw_text[0].itemcget(self.sw_text[1], "fill"),
            "overlay_talk_color": self.sw_talk[0].itemcget(self.sw_talk[1], "fill"),
            "overlay_bg_image": self.bg_path,
            "overlay_alpha": round(self.sl_alpha.get() / 100, 2),
            "overlay_bg_dim": int(self.sl_dim.get()),
            "overlay_wave_style": self.wave_style_value,
            "ov_name_x": int(self.sp_name.get()["x"]),
            "ov_name_y": int(self.sp_name.get()["y"]),
            "ov_name_size": int(self.sp_name.get()["s"]),
            "ov_status_x": int(self.sp_status.get()["x"]),
            "ov_status_y": int(self.sp_status.get()["y"]),
            "ov_status_size": int(self.sp_status.get()["s"]),
            "ov_switch_x": int(self.sp_switch.get()["x"]),
            "ov_switch_y": int(self.sp_switch.get()["y"]),
            "ov_wave_y": int(self.sp_wave.get()["y"]),
            "ov_wave_h": int(self.sp_wave.get()["h"]),
            "overlay_show_name": self.sw_show["name"].get(),
            "overlay_show_status": self.sw_show["status"].get(),
            "overlay_show_line": self.sw_show["line"].get(),
            "overlay_show_switch": self.sw_show["switch"].get(),
            "followup_seconds": int(self.sl_followup.get()),
            "caption_enabled": self.sw_caption.get(),
            "mood_enabled": self.sw_mood.get(),
            "mood_idle": self.sw_sleepy.get(),
            "wave_spectrum": self.sw_spectrum.get(),
            "karaoke": self.sw_karaoke.get(),
            "diary_enabled": self.sw_diary.get(),
            "big_caption": self.sw_big.get(),
            "screenshot_enabled": self.sw_shot.get(),
            "screen_share": self.sw_share.get(),
            "phone_enabled": self.sw_phone.get(),
            "hourly_chime": self.sw_chime.get(),
            "sit_reminder": self.sw_sit.get(),
            "meeting_mute": self.sw_meeting.get(),
            "read_hotkey": self.sw_hotkey.get(),
            "voiceprint_warn": self.sw_voiceprint.get(),
            "pet_enabled": self.sw_pet.get(),
            "follow_foreground": self.sw_follow.get(),
            "read_reply": self.sw_readreply.get(),
            "rec_indicator": self.sw_rec.get(),
            "weather_city": self.entry_city.get().strip(),
            "send_mode": self.send_mode_value,
            "confirm_send": self.sw_confirm.get(),
            "tray_enabled": self.sw_tray.get(),
            "auto_tune": self.sw_autotune.get(),
            "auto_restart": self.sw_restart.get(),
            "not_heard_reply": self.sw_notheard.get(),
            "voiceprint_gate": self.sw_gate.get(),
            "model": self.model_value,
            "lang": self.lang_value,
            "wake_level": str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL),
            "wake_levels": self.custom_levels(),
            "reminders_enabled": self.sw_reminder.get(),
            "reminder_paste": self.sw_reminder_paste.get(),
            "shortcuts": self.shortcuts,
            "schedules": self.schedule_panel.entries,
            "schedule_modules": self.schedule_panel.modules,
            "perf_mode": self.perf_value,
            "anim_fps": int(self.sl_anim.get()),
            "wheel_alpha": self.sw_wheel.get(),
            "snap_edges": self.sw_snap.get(),
            **self._fx_to_save(),
        })
        return data

    def _fx_to_save(self) -> dict:
        """Persist user effects without turning temporary low-performance mode off."""
        fx = {
            key: bool(switch.get())
            for key, switch in getattr(self, "fx_switches", {}).items()
        }
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None)
            if before:
                fx.update(before)
        return fx
