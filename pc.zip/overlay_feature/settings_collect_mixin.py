# -*- coding: utf-8 -*-
"""Collect visible settings widgets into one durable configuration snapshot."""
from __future__ import annotations

import version
from overlay_feature.defaults import DEFAULTS, VOICES
from overlay_feature import runtime as _runtime
from overlay_feature.settings_feature_collect_mixin import (
    OverlaySettingsFeatureCollectMixin,
)


class OverlaySettingsCollectMixin(OverlaySettingsFeatureCollectMixin):
    """Own widget-to-config collection without saving or rebuilding the panel."""

    def collect(self) -> dict:
        data = _runtime.load_config(_runtime.CONFIG)
        data.update({
            "name": self.entry_name.get().strip() or version.ASSISTANT_NAME,
            "wake_word": self.entry_wake.get().strip() or "大肥鱼",
            "greeting_text": self.entry_greeting.get().strip(),
            "greeting_enabled": self.sw_greeting.get(),
            "user_name": self.entry_user.get().strip(),
            "name_freq": self.name_freq_value,
            "ack_text": self.entry_ack.get().strip() or DEFAULTS["ack_text"],
            "ack_enabled": self.sw_ack.get(),
            "self_name": self.entry_self.get().strip() or "大肥鱼",
            "self_talk": self.sw_self.get(),
            "self_freq": self.self_freq_value,
            "volume": int(self.sl_volume.get()),
            "rate": f"{int(self.sl_rate.get()):+d}%",
            "voice": VOICES[self.voice_index][0],
            "voice_pitch": VOICES[self.voice_index][2],
            "voice_fx": VOICES[self.voice_index][3],
            "voice_preset": int(self.voice_index),
            "overlay_width": int(self.sl_width.get()),
            "overlay_height": int(self.sl_height.get()),
            "overlay_color": self.sw_color[0].itemcget(self.sw_color[1], "fill"),
            "overlay_accent": self.sw_accent[0].itemcget(self.sw_accent[1], "fill"),
            "overlay_button": self.sw_button[0].itemcget(self.sw_button[1], "fill"),
            "overlay_text": self.sw_text[0].itemcget(self.sw_text[1], "fill"),
            "overlay_talk_color": self.sw_talk[0].itemcget(self.sw_talk[1], "fill"),
            "overlay_bg_image": self.bg_path,
            "overlay_alpha": round(self.sl_alpha.get() / 100, 2),
            "overlay_bg_dim": int(self.sl_dim.get()),
            "overlay_wave_style": self.wave_style_value,
            "ov_name_x": int(self.sp_name.get()["x"]),
            "ov_name_y": int(self.sp_name.get()["y"]),
            "ov_name_size": int(self.sp_name.get()["s"]),
            "ov_status_x": int(self.sp_status.get()["x"]),
            "ov_status_y": int(self.sp_status.get()["y"]),
            "ov_status_size": int(self.sp_status.get()["s"]),
            "ov_switch_x": int(self.sp_switch.get()["x"]),
            "ov_switch_y": int(self.sp_switch.get()["y"]),
            "ov_wave_y": int(self.sp_wave.get()["y"]),
            "ov_wave_h": int(self.sp_wave.get()["h"]),
            "overlay_show_name": self.sw_show["name"].get(),
            "overlay_show_status": self.sw_show["status"].get(),
            "overlay_show_line": self.sw_show["line"].get(),
            "overlay_show_switch": self.sw_show["switch"].get(),
        })
        return self.collect_feature_settings(data)
