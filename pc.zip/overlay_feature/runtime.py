# -*- coding: utf-8 -*-
"""Runtime helpers for the desktop overlay process."""
from __future__ import annotations

import ctypes
import json
import os
import re
import time
from pathlib import Path

from PIL import ImageFont

from overlay_feature.window_control import (
    grab_foreground,
    make_no_activate,
    set_no_activate,
    virtual_screen,
)

HERE = Path(__file__).resolve().parent.parent
STATUS = HERE / "status.json"
SPEAK_STATUS = HERE / "speak.json"
CONTROL = HERE / "control.json"
POS = HERE / "overlay_pos.json"
CONFIG = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"
READY_FILE = HERE / "overlay_ready.json"
SYSLOG_FILE = HERE / "syslog.md"
EXIT_LOG = HERE / "overlay-exit.log"
INPUT_LOG = HERE / "input.log"

STARTUP_LNK = "语音助手（开机自启）.lnk"
FONT_FILES = [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc"]


_HEX_COLOR = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def safe_color(value, fallback: str) -> str:
    """配置里的颜色只认 #rgb / #rrggbb；写错了就退回默认值。

    以前不校验，config.json 里写个 "zzz" 会让 Tk 直接抛 unknown color name，
    悬浮窗一启动就崩——而配置文件是用户能手改的。
    """
    text = str(value or "").strip()
    return text if _HEX_COLOR.match(text) else fallback


def rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    if len(value) == 3:
        value = "".join(c * 2 for c in value)
    try:
        return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    except Exception:
        return 128, 128, 128


def hexs(color) -> str:
    return "#%02x%02x%02x" % tuple(int(max(0, min(255, round(c)))) for c in color)


def mix(a: str, b: str, t: float) -> str:
    ra, rb = rgb(a), rgb(b)
    return hexs(tuple(ra[i] + (rb[i] - ra[i]) * t for i in range(3)))


def shade(color: str, t: float) -> str:
    target = "#000000" if t < 0 else "#ffffff"
    return mix(color, target, abs(t))


def font(size: int, bold: bool = False):
    for path in ([FONT_FILES[1]] if bold else []) + FONT_FILES:
        try:
            return ImageFont.truetype(path, int(size))
        except Exception:
            continue
    return ImageFont.load_default()


def load_config(path: Path | None = None) -> dict:
    try:
        data = json.loads((path or CONFIG).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_config(data: dict, path: Path | None = None) -> None:
    try:
        (path or CONFIG).write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception:
        pass


def send_command(action: str, path: Path | None = None) -> None:
    try:
        (path or CONTROL).write_text(
            json.dumps({"action": action, "ts": time.time()}), encoding="utf-8"
        )
    except Exception:
        pass


def note(text: str, path: Path | None = None) -> None:
    """写一行启动/退出小日志。

    带个大小上限：万一哪次又出现"每帧都报同一个错"，
    日志最多长到 400KB 就自己裁到最近 1500 行，不会像上次那样堆到 3MB。
    """
    try:
        target = path or EXIT_LOG
        with target.open("a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%H:%M:%S')}] {text}\n")
        if target.stat().st_size > 400_000:
            lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
            target.write_text("\n".join(lines[-1500:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def inputlog(text: str, path: Path | None = None) -> None:
    """输入诊断日志：点击、拿到焦点、敲了哪个键，都记一行。

    以后你要是又说"打不进字"，我看这个文件就知道卡在哪一步——是没点中、
    没拿到焦点，还是拿到焦点又被别的东西抢走了。
    """
    try:
        target = path or INPUT_LOG
        with target.open("a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%H:%M:%S')}] {text}\n")
        if target.stat().st_size > 300_000:      # 别无限长
            lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
            target.write_text("\n".join(lines[-800:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def startup_exists() -> bool:
    try:
        base = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup"
        return (base / STARTUP_LNK).exists()
    except Exception:
        return False


def single_instance(ready_file: Path | None = None) -> bool:
    """同一时间只留一个悬浮窗。

    但是 —— 如果那个"已经在跑"的其实是**卡死/崩了没退干净的僵尸进程**，它占着
    互斥体不放，新开的悬浮窗就会安安静静地退出，用户看到的就是"永远没有悬浮窗"。
    所以这里加一道判断：回执文件（overlay_ready.json）超过 40 秒没更新，就当
    上一个是死的，照样起来。（活着的悬浮窗每 10 秒续一次回执。）
    """
    if os.name != "nt":
        return True
    stale = True
    pid = 0
    try:
        data = json.loads((ready_file or READY_FILE).read_text(encoding="utf-8"))
        stale = time.time() - float(data.get("ts") or 0) > 40
        pid = int(data.get("pid") or 0)
    except Exception:
        stale = True          # 连回执都没有 → 多半根本没有活的悬浮窗
    # 回执过期不等于进程死了：主程序重启时会把回执删掉/覆盖，旧浮窗可能还活着。
    # 只要 pid 还在，就不要再开第二个（之前"两个悬浮窗"就是这么来的）。
    if stale and pid and _pid_alive(pid):
        return False
    if stale:
        return True
    k = ctypes.windll.kernel32
    k.CreateMutexW(None, False, "VoiceAssistantOverlay_v1")
    return k.GetLastError() != 183


def _pid_alive(pid: int) -> bool:
    try:
        if os.name != "nt":
            os.kill(int(pid), 0)
            return True
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        k.CloseHandle(h)
        return True
    except Exception:
        return False


def process_alive(pid: int) -> bool:
    if not pid:
        return False
    k = ctypes.windll.kernel32
    handle = k.OpenProcess(0x1000, False, pid)
    if not handle:
        return False
    k.CloseHandle(handle)
    return True
