# -*- coding: utf-8 -*-
"""Frame animation, resize easing, color transitions, and auto tuning."""
from __future__ import annotations

import math
import time

from PIL import ImageDraw, ImageTk

from overlay_feature.window_support import (
    COLORS,
    FADE_SECONDS,
    FX_KEYS,
    RESIZE_STEPS,
    RESIZE_STEP_MS,
    SIMPLE_STEPS,
    hexs,
    mix,
    rgb,
)


class WindowAnimationMixin:
    def anim(self) -> None:
        frame_start = time.perf_counter()
        now = time.time()
        self.dt = min(
            0.1,
            max(0.0, now - getattr(self, "_frame_t", now)),
        )
        self._frame_t = now
        self._sweep_pos = (self._sweep_pos + self.dt * 0.55) % 1.0
        if self.intro < 1.0:
            self.intro = min(1.0, self.intro + 0.09)
            ease = 1 - (1 - self.intro) ** 3
            self.root.geometry(
                f"+{self.base_x}+{int(self.base_y - 16 * (1 - ease))}"
            )
            self.root.attributes("-alpha", self.alpha * ease)
        if self._frames % 4 == 0:
            self.watch_hover()
        if self.snap_on and self.snap_edge:
            if self.simple_on():
                width, height = self.simple_size()
                self.target_w = float(width)
                self.target_h = float(height)
            elif not self.expanded:
                self.target_w = float(self.compact_w)
                self.target_h = float(self.header_h)
            if self._drag is None:
                self.base_x, self.base_y = self.dock_pos(
                    self.cur_w,
                    self.cur_h,
                )
        if (
            abs(self.target_w - self.cur_w) > 0.6
            or abs(self.target_h - self.cur_h) > 0.6
        ):
            key = (round(self.target_w, 1), round(self.target_h, 1))
            if self.resize_from is None or self._resize_key != key:
                self._rz_step = 0
                self._resize_key = key
                self.resize_from = (self.cur_w, self.cur_h)
            start_w, start_h = self.resize_from
            self._rz_step = getattr(self, "_rz_step", 0) + 1
            steps = (
                SIMPLE_STEPS
                if self.snap_edge and not self.expanded
                else RESIZE_STEPS
            )
            progress = min(1.0, self._rz_step / float(steps))
            eased = progress * progress * (3 - 2 * progress)
            self.cur_w = start_w + (self.target_w - start_w) * eased
            self.cur_h = start_h + (self.target_h - start_h) * eased
            self.root.geometry(
                f"{int(self.cur_w)}x{int(self.cur_h)}"
                f"+{self.base_x}+{self.base_y}"
            )
            self._base_key = None
            if self.expanded:
                self._place_panel(self.cur_h)
            self._repaint_now()
            if progress >= 1.0:
                self.cur_w, self.cur_h = self.target_w, self.target_h
                self.resize_from = self._resize_key = self._rz_step = None
                self.root.geometry(
                    f"{int(self.cur_w)}x{int(self.cur_h)}"
                    f"+{self.base_x}+{self.base_y}"
                )
                if self._panel_closing:
                    self._finish_panel_close()
        elif self.resize_from is not None:
            self.cur_w, self.cur_h = self.target_w, self.target_h
            self.resize_from = self._resize_key = self._rz_step = None
            self.root.geometry(
                f"{int(self.cur_w)}x{int(self.cur_h)}"
                f"+{self.base_x}+{self.base_y}"
            )
            if self._panel_closing:
                self._finish_panel_close()
        if self.expanded and self.panel_win is not None:
            self._position_panel_window()
        self.level_shown += (self.level - self.level_shown) * 0.16
        self.breath = (self.breath + 0.055) % (2 * math.pi)
        self.wave_phase += 0.13 + 0.3 * self.level_shown
        if self.text_fade < 1.0:
            self.text_fade = min(1.0, self.text_fade + 0.07)
        if abs(self.switch_target - self.switch_pos) > 0.002:
            self.switch_pos += (self.switch_target - self.switch_pos) * 0.14
        else:
            self.switch_pos = self.switch_target
        state_color = COLORS.get(self.state, self.accent)
        speak_active, speak_level, speak_text, speak_progress = (
            self.read_speaking()
        )
        if speak_active:
            self.level = speak_level
        active = (
            self.level > 0.06
            or speak_active
            or self.state
            in (
                "listening",
                "hearing",
                "thinking",
                "sent",
                "copied",
                "focus",
            )
        )
        if active:
            if self.sleep_stage >= 2:
                self._pop = 1.0
            self.last_active = now
            self.sleep_stage = 0
        elif self.mood_idle:
            idle = now - self.last_active
            self.sleep_stage = 2 if idle >= 240 else (1 if idle >= 120 else 0)
        else:
            self.sleep_stage = 0
        if self._pop > 0:
            self._pop = max(0.0, self._pop - self.dt * 2.0)
        now = time.time()
        target_hex = (
            self.talk_color
            if speak_active
            else (state_color if self.line_follow else self.accent)
        )
        mood = str((self.status or {}).get("mood") or "")
        if (
            mood
            and time.time()
            - float((self.status or {}).get("mood_ts") or 0)
            > 10
        ):
            mood = ""
        if self.mood_on and mood and not speak_active:
            target_hex = mix(
                target_hex,
                "#ff6b35" if mood == "急" else "#455270",
                0.60,
            )
        target_rgb = rgb(target_hex)
        current = getattr(self, "_wave_rgb", None)
        if current is None:
            current = target_rgb
        if self.perf == "eco":
            current = target_rgb
            self._fade_from = target_rgb
            self._fade_to = target_rgb
            self._fade_t0 = now
            self._fade_dur = FADE_SECONDS
        else:
            if target_rgb != getattr(self, "_fade_to", None):
                self._fade_from = current
                self._fade_to = target_rgb
                self._fade_t0 = now
                self._fade_dur = FADE_SECONDS
            progress = min(
                1.0,
                max(
                    0.0,
                    (now - self._fade_t0) / max(0.01, self._fade_dur),
                ),
            )
            eased = progress * progress * (3 - 2 * progress)
            start = self._fade_from
            current = tuple(
                start[index]
                + (self._fade_to[index] - start[index]) * eased
                for index in range(3)
            )
        self._wave_rgb = current
        wave_color = hexs(
            tuple(round(channel / 4) * 4 for channel in current)
        )
        image = self.base_image().copy()
        draw = ImageDraw.Draw(image)
        if self.simple_on():
            self.draw_simple(image, draw, wave_color)
        else:
            self.draw_full(
                image,
                draw,
                wave_color,
                state_color,
                speak_active,
                speak_text,
                speak_progress,
            )
        if (
            self._photo is None
            or self._photo.width() != image.width
            or self._photo.height() != image.height
        ):
            self._photo = ImageTk.PhotoImage(image)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(image)
        if self.intro >= 1.0:
            desired = self.alpha_override if self.alpha_override else self.alpha
            if abs(desired - getattr(self, "_alpha_set", -1.0)) > 0.004:
                self._alpha_set = desired
                try:
                    self.root.attributes("-alpha", desired)
                except Exception:
                    pass
            if (
                not getattr(self, "_ready_done", False)
                or now - getattr(self, "_ready_ts", 0.0) > 10.0
            ):
                self._ready_done = True
                self._ready_ts = now
                self.write_ready()
        spent_ms = (time.perf_counter() - frame_start) * 1000
        floor_ms = RESIZE_STEP_MS if self.resize_from is not None else 1
        self.root.after(
            max(floor_ms, int(round(self.frame_ms - spent_ms))),
            self.anim,
        )
        cost = time.perf_counter() - frame_start
        self._frame_cost = self._frame_cost * 0.9 + cost * 0.1
        previous = getattr(self, "_prev_t", None)
        if previous is not None:
            gap = max(0.0, now - previous)
            self._period = self._period * 0.9 + gap * 0.1
            self._gaps.append(gap)
            if len(self._gaps) > 60:
                del self._gaps[:-60]
        self._prev_t = now
        self._frames += 1
        budget = self.frame_ms / 1000.0
        gaps = self._gaps
        median = sorted(gaps)[len(gaps) // 2] if gaps else 0.0
        if median > budget * 1.25 and len(gaps) >= 60:
            self._slow_checks += 1
        else:
            self._slow_checks = 0
        if (
            getattr(self, "auto_tune", True)
            and not getattr(self, "_auto_low_off", False)
            and self._frames > 150
            and now - self._started > 20
            and self._slow_checks >= 5
        ):
            self._slow_checks = 0
            if self._degrade_stage == 0:
                fancy = [key for key in FX_KEYS if self.fx.get(key)]
                if fancy:
                    self._fx_before_low = {
                        key: bool(self.fx.get(key)) for key in FX_KEYS
                    }
                    for key in fancy:
                        self.fx[key] = False
                    self._auto_low = True
                    self._degrade_stage = 1
                    self._frames = 0
                    self._note(
                        f"帧间隔中位数 {median * 1000:.0f}ms 偏长，"
                        "先关掉声音条特效（保住帧率）"
                    )
                else:
                    self._degrade_stage = 2
            elif self._degrade_stage == 1:
                self._degrade_stage = 2
                self.frame_ms = max(self.frame_ms, 33)
                self._note("关了特效还是偏长，这才降到 30 帧")
