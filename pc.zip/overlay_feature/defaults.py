# -*- coding: utf-8 -*-
"""Stable overlay defaults and presentation constants."""
from __future__ import annotations


DEFAULTS = {
    # ↓↓↓ 这套是当前这套配置固化成的新默认值（除个人背景图与设备相关项）
    "name": "大肥鱼",
    "overlay_color": "#1b1b1f",
    "overlay_accent": "#3ddc84",
    "overlay_button": "#2f7f5a",
    "overlay_text": "#ffffff",
    "overlay_talk_color": "#4aa3ff",     # 我说话时声音条的颜色
    "overlay_alpha": 0.95,        # 你调成了 95%
    "overlay_bg_image": "assets/default-bg.jpg",
    "overlay_bg_dim": 45,
    "overlay_width": 344,
    "overlay_height": 112,
    "overlay_line_max": 420,
    "overlay_show_name": True,
    "overlay_show_status": True,
    "overlay_show_line": True,
    "overlay_show_switch": True,
    "ov_name_x": 16, "ov_name_y": 12, "ov_name_size": 19,
    "ov_status_x": -74, "ov_status_y": 12, "ov_status_size": 15,
    "ov_switch_x": -16, "ov_switch_y": 10,
    "ov_wave_y": 14, "ov_wave_h": 42,
    "overlay_wave_style": "siri",
    "wake_level": "宽松",         # 唤醒档位：严格 / 标准 / 宽松 / 极宽松（可自己加）
    "wake_levels": {},            # 用户自己加的档位（默认档位在 wake_levels.py 里）
    "volume": 80,
    "rate": "+8%",
    "voice": "zh-CN-XiaoyiNeural",
    "wake_word": "大肥鱼",
    "cancel_word": "取消",
    "greeting_enabled": True,
    "greeting_text": "{time}好，{name}已经就绪，说「{wake}」就能叫我。",
    "greeting_delay": 3,
    "user_name": "",              # 怎么称呼你
    "name_freq": "sometimes",     # off / sometimes / often
    "ack_enabled": True,
    # 应答语：可以写好几条（用 | 隔开），每次随机挑一条说
    "ack_text": ("好的我这就做|好嘞|收到|来了|马上办|好的，收到|得嘞|这就办|明白|"
                 "收到，这就去|嗯，交给我|好嘞，这就来|记住了|这就去办|好，安排|"
                 "收到啦|这就给你办|行，马上|晓得啦|收到收到"),
    "self_talk": True,            # 可爱自称（「大肥鱼完成任务啦」）
    "self_name": "大肥鱼",
    "self_freq": "sometimes",     # 自称说的勤不勤：off 不说 / sometimes 有时 / often 经常
    # 新加的智能功能
    "followup_seconds": 8,
    "reminders_enabled": True,
    "reminder_paste": False,     # 提醒也发窗口（默认关：提醒只在电脑上念，不往对话里塞、不花 token）
    "shortcuts": {},
    "schedules": [],
    "schedule_modules": [],
    "schedule_speak": True,
    "perf_mode": "quality",       # eco 节能 / standard 标准 / quality 质量
    "anim_fps": 60,
    "wheel_alpha": True,          # 滚轮是否改变透明度（你把它打开了）
    # 声音条特效（每个都能单独开关）
    "fx_trail": True,             # 视觉暂留：拖一条会慢慢淡掉的残影
    "fx_glow": True,              # 呼吸光晕：顺着条的轮廓（或那颗小圆点）往外铺的柔光
    "fx_sparkles": False,         # 星尘：说话时溅出的小亮点（你自己关掉了，就当出厂默认）
    "fx_reflection": True,        # 倒影：声音条下面一层淡淡的反光
    "fx_sweep": True,             # 流光：一道高光沿着声音条扫过
    # 下面这几个是"玩一下"用的，默认全关：你说的"那颗小圆点只留光晕"，
    # 想加回来就在设置里自己拨开（设置 → 外观 → 声音条特效）
    "fx_ripple": False,           # 波纹：没声音时，小圆点一圈圈荡开
    "fx_orbit": False,            # 卫星：两颗小卫星绕着圆点转，还拖着短短的光尾
    "fx_rotor": False,            # 光环：一圈会自己转的虚线光环
    "fx_starflare": False,        # 星芒：十字形的亮光
    "fx_aurora": False,           # 极光：没声音时，圆点外面那层光会慢慢换颜色
    "fx_heartbeat": False,        # 心跳：圆点像心跳那样"咚—咚"地脉动
    "fx_burst": True,             # 唤醒爆闪：被叫醒的一瞬间炸出一圈小火星（你要的）
    # 好玩的功能开关
    "caption_enabled": False,     # 实时字幕：边说边出字（你嫌它占显卡，关掉了）
    "overlay_show_caption": True, # 把字幕显示在声音条上方
    "mood_enabled": False,        # 语气反应：你急它暖、你轻它暗（你嫌它变来变去，关掉了）
    "mood_idle": True,            # 悬浮窗养成：长时间没人理它会打盹
    "wave_spectrum": False,       # 音浪模式：声音条变成跟着声音跳的频谱柱
    "karaoke": True,              # 逐字跟读：它念到哪个字哪个字亮
    "diary_enabled": True,        # 睡前日记：到点念一遍今天说了什么
    "diary_hour": 22,
    "big_caption": False,         # 大字幕：屏幕底部一条大字
    "big_caption_size": 34,
    "screenshot_enabled": True,   # 看屏幕截图：说「看屏幕 / 看看这个」就截屏贴进聊天窗口
    "screen_share": True,         # 屏幕发手机：说「截图发手机 / 录 8 秒发手机」就放到手机入口
    "phone_enabled": True,        # 手机入口：手机浏览器连过来发命令、看对话
    "phone_port": 8765,           # 手机入口的端口
    "hourly_chime": False,        # 整点报时
    "sit_reminder": False,        # 久坐提醒（连着用电脑一小时提醒你起来）（你把它关了）
    "sit_minutes": 60,
    "meeting_mute": True,         # 开会自动闭嘴：会议软件在前台就只出字幕
    "read_hotkey": True,          # Ctrl+Alt+R 朗读选中的文字
    "voiceprint_warn": False,     # 声纹提示：这次不太像你的声音就告诉你一声（你嫌吵，关掉了）
    "fatigue_reminder": True,     # 你说得比平时又慢又轻时劝你歇会儿
    "pet_enabled": False,         # 桌宠：DeepSeek 娘在桌面上走来走去（默认关着，想开随时开）
    "pet_scale": 3,               # 桌宠大小
    "pet_speed": 3,               # 桌宠走路快慢
    "pet_speak": True,            # 桌宠说话
    "follow_foreground": False,   # 发到"你当前在用的窗口"而不是写死的 ChatGPT
    "rec_indicator": True,        # 录音时右下角亮一个小红点提示
    "private_minutes": 5,         # 说"别记这段"之后静默几分钟
    "weather_city": "北京",        # 天气城市（空 = 自动定位，走代理会判到国外）
    "send_mode": "paste_enter",   # 发送方式：paste_enter / paste / type
    "confirm_send": False,        # 发之前先问你一声
    "tray_enabled": True,         # 右下角托盘图标
    "voiceprint_gate": True,      # 只认我的声音（没训练过声纹就自动放行，不会把人挡在外面）
    "model": "large-v3-turbo",    # 识别模型（改完要重启）
    "lang": "zh",                 # 识别语言
    "auto_tune": True,            # 低配机器上自动降级（关特效、30 帧、关实时字幕）
    "not_heard_reply": False,     # 没听清时念一句"没听清，再说一遍"
    "auto_restart": False,        # 崩溃后看门狗自动把它拉起来（你把它关了：不希望它自己又起来）
    "snap_edges": True,           # 贴边吸附：拖到屏幕边缘会吸住，并缩成一条小细条
    "read_reply": True,           # 自动念回答：发的消息有人回答了就念给你听
}

# 声音条特效的键，按"从主到次"排好；降级 / 布局 / 设置页都读这一份，避免几处各写一遍漏掉
FX_KEYS = ("fx_trail", "fx_glow", "fx_sparkles", "fx_reflection", "fx_sweep",
           "fx_ripple", "fx_orbit", "fx_rotor", "fx_starflare", "fx_aurora",
           "fx_heartbeat", "fx_burst")
# 只在小圆点状态才画的那几个（声音条铺满时看不见它们的意义）
FX_DOT_KEYS = ("fx_ripple", "fx_orbit", "fx_rotor", "fx_starflare",
               "fx_aurora", "fx_heartbeat", "fx_burst")

ARROW = 26
BG_PANEL = "#1d1d23"
BORDER = "#3a3a44"
CARD = "#24242c"
SW_W, SW_H = 46, 24
KNOB = "#f2f2f6"

COLORS = {
    "starting": "#8a8a95", "idle": "#8a8a95", "listening": "#3ddc84",
    "hearing": "#3ddc84", "thinking": "#4aa3ff", "sent": "#22d3ee",
    "copied": "#22d3ee", "paused": "#ffb020", "offline": "#ff5c5c",
    "focus": "#ffcf5c",
}
LABELS = {
    "starting": "启动中", "idle": "待唤醒", "listening": "在等你说",
    "hearing": "听到声音了", "thinking": "识别中", "sent": "已发送",
    "copied": "已识别", "paused": "已暂停", "offline": "未连接",
    "focus": "专注中", "sleepy": "打个盹",
}
VOICES = [
    # 用户要求：**只留大肥鱼这一种声线**，别的音色全部删掉。
    # 「更换语音」这个功能仍然保留（抽屉里就这一个，以后要加新音色往这里加就行）。
    # 格式：(音色值, 显示名, 变调, 特效)
    ("dfy:大肥鱼", "大肥鱼 · 本地克隆（推荐）", "", ""),
]
