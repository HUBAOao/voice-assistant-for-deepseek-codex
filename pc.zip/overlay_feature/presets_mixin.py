# -*- coding: utf-8 -*-
"""Overlay configuration presets and portable preset files."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from overlay_feature.defaults import BG_PANEL, CARD


class OverlayPresetsMixin:
    def _preset_owner(self):
        """Resolve callbacks from the owning overlay module.

        Tests replace ``overlay.CONFIG`` and ``overlay.load_config`` after this
        module is imported, so a copied import-time binding would target the
        wrong machine configuration.
        """
        return sys.modules.get(type(self).__module__)

    def _preset_load(self) -> dict:
        owner = self._preset_owner()
        return owner.load_config() if owner is not None else {}

    def _preset_write(self, data: dict) -> None:
        owner = self._preset_owner()
        if owner is not None:
            owner.write_config(data)

    def _preset_note(self, text: str) -> None:
        owner = self._preset_owner()
        if owner is not None:
            owner.note(text)

    def refresh_presets(self) -> None:
        if getattr(self, "preset_bar", None) is None:
            return
        for child in self.preset_bar.winfo_children():
            child.destroy()
        presets = self._preset_load().get("presets") or {}
        if not presets:
            self.tk.Label(self.preset_bar,
                          text="（可以把现在整套设置存成预设，随时切回来）",
                          bg=BG_PANEL, fg="#6f6f7a",
                          font=("Microsoft YaHei UI", 8)).pack(anchor="w")
            return
        for name in presets:
            chip = self.tk.Label(self.preset_bar, text=name[:12], bg=CARD, fg="#ffffff",
                                 padx=10, pady=3, cursor="hand2",
                                 font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=2, pady=1)
            chip.bind("<Button-1>", lambda _e, n=name: self.apply_preset(n))
            chip.bind("<Button-3>", lambda _e, n=name: self.remove_preset(n))

    def save_preset(self) -> None:
        def done(name: str) -> None:
            if not name:
                return
            data = self.collect()
            presets = dict(data.get("presets") or {})
            presets[name] = {key: value for key, value in data.items()
                             if key != "presets"}
            data["presets"] = presets
            self._preset_write(data)
            self.refresh_presets()
            self.flash(f"已存为预设「{name}」", 2.4)

        self.edit_text("预设名称", "", done)

    def apply_preset(self, name: str) -> None:
        data = self._preset_load()
        preset = (data.get("presets") or {}).get(name) or {}
        data.update(preset)
        self._preset_write(data)
        self.cfg = data
        owner = self._preset_owner()
        config = getattr(owner, "CONFIG", None)
        if config is not None:
            try:
                self.cfg_mtime = config.stat().st_mtime
            except OSError:
                pass
        self.apply_saved()
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None
            self.build_panel()
            self._place_panel(self._expanded_h())
        self.flash(f"已套用预设「{name}」", 2.4)

    def remove_preset(self, name: str) -> None:
        data = self._preset_load()
        presets = dict(data.get("presets") or {})
        presets.pop(name, None)
        data["presets"] = presets
        self._preset_write(data)
        self.refresh_presets()
        self.flash(f"已删除预设「{name}」", 2)

    def export_presets(self) -> None:
        from tkinter import filedialog

        presets = self._preset_load().get("presets") or {}
        if not presets:
            self.flash("还没有预设可以导出，先点「存为预设」", 3)
            return
        desk = Path.home() / "Desktop"
        path = filedialog.asksaveasfilename(
            parent=self.root, title="导出预设", defaultextension=".json",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            initialfile=f"鳍舱预设-{len(presets)}套.json",
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")])
        if not path:
            return
        payload = {
            "kind": "voice-assistant-presets",
            "version": 1,
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "presets": presets,
        }
        try:
            Path(path).write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:  # noqa: BLE001
            self.flash(f"导出失败：{exc}", 4)
            return
        self.flash(f"已导出 {len(presets)} 套预设 → {Path(path).name}", 3.5)
        self._preset_note(f"预设导出到 {path}")

    def import_presets(self) -> None:
        from tkinter import filedialog

        desk = Path.home() / "Desktop"
        path = filedialog.askopenfilename(
            parent=self.root, title="导入预设",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")])
        if not path:
            return
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            self.flash(f"这个文件读不了：{exc}", 4)
            return
        if isinstance(raw, dict) and isinstance(raw.get("presets"), dict):
            incoming = raw["presets"]
        elif isinstance(raw, dict) and raw and all(
                isinstance(value, dict) for value in raw.values()):
            incoming = raw
        else:
            self.flash("这文件里没有预设", 4)
            return
        incoming = {str(key)[:40]: value for key, value in incoming.items()
                    if isinstance(value, dict)}
        if not incoming:
            self.flash("这文件里没有预设", 4)
            return
        data = self._preset_load()
        presets = dict(data.get("presets") or {})
        old = set(presets)
        presets.update(incoming)
        data["presets"] = presets
        self._preset_write(data)
        filled = [name for name in incoming if name not in old]
        overwritten = [name for name in incoming if name in old]
        self.refresh_presets()
        result = f"导入 {len(incoming)} 套预设"
        if overwritten:
            result += f"（覆盖了 {len(overwritten)} 套同名）"
        if filled:
            result += f"：{'、'.join(filled[:3])}"
            if len(filled) > 3:
                result += "…"
        self.flash(result, 3.5)
        self._preset_note(
            f"导入预设：新增 {len(filled)} 套、覆盖 {len(overwritten)} 套"
        )
