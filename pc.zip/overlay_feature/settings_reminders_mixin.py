# -*- coding: utf-8 -*-
"""Reminder and shortcut controls for the overlay settings feature page."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsRemindersMixin:
    def build_reminders(self, parent) -> None:
        """Compose reminder toggles without owning their action methods."""
        self._group(parent, "提醒与日程")
        self.sw_reminder = self._switch_row(
            parent, "提醒功能", bool(self.cfg.get("reminders_enabled", True))
        )
        self.sw_reminder_paste = self._switch_row(
            parent, "提醒也发窗口", bool(self.cfg.get("reminder_paste", False))
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(
            row,
            text='说"10 分钟后提醒我喝水"就会到点念出来',
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        row = self._row(parent, "快捷指令")
        self.shortcuts = dict(self.cfg.get("shortcuts") or {})
        self.shortcuts_label = self.tk.Label(
            row,
            text=self.shortcuts_summary(),
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.shortcuts_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "编辑", self.edit_shortcuts).pack(side="right", padx=(4, 10))
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 8))
        self.tk.Label(
            row,
            text="每行一条：说中短语就执行  url:网址  app:程序  say:朗读的内容",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")
