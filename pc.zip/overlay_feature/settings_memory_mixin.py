# -*- coding: utf-8 -*-
"""Explicit memory archive actions and their read-only viewer."""
from __future__ import annotations

import re
import threading

import memory_archive
from overlay_feature.defaults import BG_PANEL


class OverlaySettingsMemoryMixin:
    def memory_summary(self) -> str:
        try:
            info = memory_archive.summary()
        except Exception:
            info = None
        if not info:
            return "还没有归档 · 说「集中记忆归档」或点「归档」"
        stats = info.get("stats") or {}
        return (
            f"上次 {info.get('generated_at', '')} · "
            f"{stats.get('threads', 0)} 个会话 / "
            f"{stats.get('user_messages', 0)} 条你的话"
        )

    def do_memory_archive(self) -> None:
        """Archive only after an explicit button press."""
        self.flash("正在把所有对话的记忆归档…", 3)

        def job() -> None:
            try:
                info = memory_archive.build_archive()
                message = memory_archive.describe(info)
            except Exception as exc:  # noqa: BLE001
                message = f"归档没成功：{exc}"

            def done() -> None:
                self.flash(message, 4)
                try:
                    self.memory_label.config(text=self.memory_summary())
                except Exception:
                    pass
                if getattr(self, "memory_win", None) is not None:
                    try:
                        if self.memory_win.winfo_exists():
                            self.load_memory_text()
                    except Exception:
                        pass

            try:
                self.root.after(0, done)
            except Exception:
                pass

        threading.Thread(target=job, daemon=True).start()

    def open_memory_archive(self) -> None:
        """Open the previous archive without regenerating it."""
        path = memory_archive.ARCHIVE_MD
        if not path.is_file():
            self.flash("还没有归档，先点「归档」或说「集中记忆归档」", 3)
            return
        tk = self.tk
        win = getattr(self, "memory_win", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.deiconify()
                    win.lift()
                    self.load_memory_text()
                    return
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        self.memory_win = win
        win.title("集中记忆归档")
        win.configure(bg=BG_PANEL)
        win.geometry("780x620")
        win.minsize(520, 360)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(12, 2))
        tk.Label(
            head,
            text="集中记忆归档",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 11, "bold"),
        ).pack(side="left")
        tk.Label(
            head,
            text=self.memory_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="right")
        tk.Label(
            win,
            text="所有 Codex 对话 + 事实记忆 / 便签 / 记账 / 日程 / 日记，"
                 "都收在这一份里。只有点「归档」才会更新。",
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        ).pack(fill="x", padx=14, pady=(0, 6))

        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=14)
        text = tk.Text(
            body,
            bg="#16161b",
            fg="#d8d8e0",
            relief="flat",
            wrap="word",
            font=("Microsoft YaHei UI", 9),
            padx=10,
            pady=8,
            spacing1=1,
            spacing3=2,
        )
        bar = tk.Scrollbar(
            body,
            command=text.yview,
            bg="#26262d",
            troughcolor=BG_PANEL,
            relief="flat",
            width=12,
        )
        text.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        self.memory_text = text

        foot = tk.Frame(win, bg=BG_PANEL)
        foot.pack(fill="x", padx=14, pady=(6, 12))
        self._chip(
            foot,
            "用记事本打开",
            lambda: memory_archive.open_archive(),
        ).pack(side="left")
        self._chip(foot, "重新归档", self.do_memory_archive).pack(
            side="left", padx=6
        )
        self._chip(foot, "关闭", win.destroy).pack(side="right")
        self.load_memory_text()

    def load_memory_text(self) -> None:
        path = memory_archive.ARCHIVE_MD
        try:
            content = path.read_text(encoding="utf-8-sig", errors="replace")
        except Exception as exc:  # noqa: BLE001
            content = f"读不了归档文件：{exc}"
        content = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", content)
        limit = 1_500_000
        if len(content) > limit:
            content = (
                content[:limit]
                + "\n\n…（文件太大，这里先显示前 1.5 MB；"
                  "完整内容点「用记事本打开」）"
            )
        text = getattr(self, "memory_text", None)
        if text is None:
            return
        try:
            text.configure(state="normal")
            text.delete("1.0", "end")
            text.insert("1.0", content)
            text.configure(state="disabled")
        except Exception:
            pass
