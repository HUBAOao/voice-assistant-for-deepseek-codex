# -*- coding: utf-8 -*-
"""Overlay configuration, runtime status, and periodic state refresh."""
from __future__ import annotations

import json
import os
import time

from overlay_feature.window_support import (
    PANEL_H,
    STATUS_MS,
    build_overlay_settings,
    config_value,
    process_alive,
)


class WindowStateMixin:
    @property
    def cfg_mtime(self) -> float:
        return self._config_watcher.mtime

    @cfg_mtime.setter
    def cfg_mtime(self, value: float) -> None:
        self._config_watcher.set_mtime(value)

    def on_tk_error(self, exc_type, exc_value, exc_tb) -> None:
        import traceback

        self._note(
            "回调异常: "
            + "".join(
                traceback.format_exception_only(exc_type, exc_value)
            ).strip()
        )
        try:
            (self._path("CONFIG").parent / "overlay-error.log").write_text(
                "".join(
                    traceback.format_exception(exc_type, exc_value, exc_tb)
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

    def cfg_get(self, key: str):
        return config_value(self.cfg, key)

    def apply_config(self) -> None:
        build_overlay_settings(self.cfg).apply_to(self)

    def reload_config_if_changed(self) -> None:
        updated = self._config_watcher.poll()
        if updated is None:
            return
        self.cfg = updated
        self.apply_saved()

    def apply_saved(self) -> None:
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.target_w = float(self.compact_w)
        self.target_h = float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        self._base_key = None
        self.root.title(self.name)
        self.root.configure(bg=self.panel_color)
        self.canvas.configure(bg=self.panel_color)
        self.menu.configure(activebackground=self.button_color)

    def read_status(self) -> dict:
        try:
            return json.loads(
                self._path("STATUS").read_text(encoding="utf-8")
            )
        except Exception:
            return {}

    def handle_remote(self) -> None:
        try:
            data = json.loads(
                self._path("CONTROL").read_text(encoding="utf-8")
            )
        except Exception:
            return
        timestamp = float(data.get("ts") or 0)
        if timestamp <= getattr(self, "_ctrl_ts", 0.0):
            return
        self._ctrl_ts = timestamp
        action = str(data.get("action") or "")
        if action == "expand":
            self.set_expanded(True)
        elif action == "collapse":
            self.set_expanded(False)
        elif action == "qr":
            self.show_qr()
        elif action == "perf":
            gaps = list(self._gaps)
            gaps.sort()
            median = gaps[len(gaps) // 2] * 1000 if gaps else 0.0
            p90 = gaps[int(len(gaps) * 0.9)] * 1000 if gaps else 0.0
            try:
                self._path("HERE").joinpath("perf.json").write_text(
                    json.dumps(
                        {
                            "目标帧率": self.fps,
                            "帧预算ms": round(self.frame_ms, 1),
                            "中位间隔ms": round(median, 1),
                            "p90间隔ms": round(p90, 1),
                            "最差间隔ms": (
                                round(gaps[-1] * 1000, 1) if gaps else 0.0
                            ),
                            "实际帧率": (
                                round(1000 / median, 1) if median else 0.0
                            ),
                            "画一帧ms": round(self._frame_cost * 1000, 1),
                            "已降级": self._degrade_stage,
                            "特效": {
                                key: value
                                for key, value in self.fx.items()
                                if key.startswith("fx_")
                            },
                            "窗口": f"{int(self.cur_w)}x{int(self.cur_h)}",
                            "ts": time.time(),
                        },
                        ensure_ascii=False,
                        indent=2,
                    ),
                    encoding="utf-8",
                )
            except Exception:
                pass

    def tick(self) -> None:
        self.reload_config_if_changed()
        self.handle_remote()
        self.poll_wake_test()
        self.check_new_devices()
        self.sync_big_caption()
        self.sync_rec_dot()
        if (
            self.editing_on
            and time.time() - getattr(self, "edit_touch", 0) > 90
        ):
            self.set_editing(False)
        data = self.read_status()
        if data:
            self.miss = 0
            self.status = data
        else:
            self.miss += 1
            if self.miss == 40:
                self._note(f"连续 {self.miss} 次读不到 status.json")
        state = (self.status or {}).get("state") or "offline"
        if (
            state == "hearing"
            and float((self.status or {}).get("level") or 0.0) < 0.05
        ):
            state = "listening"
        self.state = state
        self.level = float((self.status or {}).get("level") or 0.0)
        self.focus_left = float((self.status or {}).get("focus") or 0.0)
        if self.focus_left <= 0:
            self.focus_total = 0.0
        elif (
            self.focus_total <= 0
            or self.focus_left > self.focus_total + 0.5
        ):
            self.focus_total = self.focus_left
        self.switch_target = 0.0 if state == "paused" else 1.0
        if self.status:
            pid = int(self.status.get("pid") or 0)
            if time.time() - self.started > 8 and not process_alive(pid):
                self.dead_hits += 1
                if self.dead_hits >= 4:
                    self._note(f"退出：主程序不在了（pid={pid}）")
                    self.quit()
                    return
            else:
                self.dead_hits = 0
        elif self.miss >= 80:
            self._note("退出：连续读不到状态文件")
            self.quit()
            return
        self.root.after(STATUS_MS, self.tick)

    def read_speaking(self) -> tuple[bool, float, str, float]:
        return self._read_speaking()

    def write_ready(self) -> None:
        try:
            window = self.root.winfo_x(), self.root.winfo_y()
            self._path("READY").write_text(
                json.dumps(
                    {
                        "pid": os.getpid(),
                        "ts": time.time(),
                        "size": [int(self.cur_w), int(self.cur_h)],
                        "pos": [int(window[0]), int(window[1])],
                        "alpha": round(
                            float(getattr(self, "_alpha_set", 0.0)),
                            2,
                        ),
                        "visible": bool(self.root.winfo_viewable()),
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _read_speaking(self) -> tuple[bool, float, str, float]:
        counter = getattr(self, "_speak_tick", 0) + 1
        self._speak_tick = counter
        if (
            counter % 3 != 1
            and getattr(self, "_speak_cache", None) is not None
        ):
            return self._speak_cache
        try:
            data = json.loads(
                self._path("SPEAK_STATUS").read_text(encoding="utf-8")
            )
            fresh = time.time() - float(data.get("ts") or 0) < 1.5
            self._speak_cache = (
                bool(data.get("active")) and fresh,
                float(data.get("level") or 0.0),
                str(data.get("text") or ""),
                float(data.get("progress") or 0.0),
            )
        except Exception:
            self._speak_cache = (False, 0.0, "", 0.0)
        return self._speak_cache
