# -*- coding: utf-8 -*-
"""Audio, appearance and shared row controls for the overlay settings panel."""
from __future__ import annotations

from pathlib import Path

from ui_widgets import Slider, SpinRow, Switch
from overlay_feature.defaults import BG_PANEL, BORDER, CARD, DEFAULTS, VOICES


class OverlaySettingsContentMixin:
    def build_sound(self, parent) -> None:
        row = self._row(parent, "出声开关")
        self._chip(
            row,
            "🔇 静音（我不听，但你说我照办）",
            lambda: (
                self._overlay_send_command("mute"),
                self.flash("已静音：它不念了", 3),
            ),
        ).pack(side="right", padx=(4, 10))
        self._chip(
            row,
            "🔊 恢复出声",
            lambda: (
                self._overlay_send_command("unmute"),
                self.flash("恢复出声", 3),
            ),
        ).pack(side="right", padx=2)
        self.sl_volume = Slider(
            parent, "朗读音量", 0, 100,
            float(self.cfg.get("volume") or 80),
            fmt="{:.0f}%", on_change=self.on_change, bg=BG_PANEL,
        )
        self.sl_rate = Slider(
            parent, "语速", -40, 60,
            self._rate_value(self.cfg.get("rate")),
            fmt="{:+.0f}%", on_change=self.on_change, bg=BG_PANEL,
        )
        row = self._row(parent, "输出设备")
        self.device_label = self.tk.Label(
            row,
            text=self._output_device_text(),
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 8),
        )
        self.device_label.pack(side="left", padx=4)
        self._chip(row, "选择 ▾", self.choose_output_device).pack(
            side="right", padx=(0, 10)
        )
        self.tk.Label(
            parent,
            text="耳机没戴/没连时，声音会播到耳机里；这里可以切到显示器/扬声器",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            anchor="w",
        ).pack(fill="x", padx=(14, 10), pady=(0, 2))
        row = self._row(parent, "音色")
        self.voice_index = self._voice_index()
        self.voice_label = self.tk.Label(
            row,
            text=self._voice_text(),
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9),
        )
        self.voice_label.pack(side="left", padx=4)
        self._chip(row, "试听", lambda: self.preview_voice()).pack(
            side="right", padx=6
        )
        self.voice_drawer_open = False
        self.voice_more = self._chip(
            row, "选择 ▾", lambda: self.toggle_voice_drawer()
        )
        self.voice_more.pack(side="right", padx=(0, 6))
        self.voice_drawer = self.tk.Frame(parent, bg=CARD)
        self.voice_rows = {}
        self._build_voice_drawer()

    def _output_devices(self) -> list[tuple[int, str]]:
        rows: list[tuple[int, str]] = []
        seen: set[str] = set()
        try:
            import sounddevice as sd

            for index, device in enumerate(sd.query_devices()):
                if int(device.get("max_output_channels") or 0) <= 0:
                    continue
                name = str(device.get("name") or "").strip()
                if not name or name in seen:
                    continue
                seen.add(name)
                rows.append((index, name))
        except Exception:
            pass
        return rows

    def _output_device_text(self) -> str:
        value = self.cfg.get("output_device")
        try:
            import sounddevice as sd

            if value in (None, ""):
                index = int(sd.default.device[1])
            else:
                index = int(value)
            name = str(sd.query_devices(index).get("name") or "").strip()
            return ("系统默认 · " if value in (None, "") else "") + name[:30]
        except Exception:
            return "系统默认" if value in (None, "") else f"设备 {value}"

    def choose_output_device(self) -> None:
        tk = self.tk
        menu = tk.Menu(
            self.root,
            tearoff=0,
            bg="#26262d",
            fg="#ffffff",
            activebackground=self.button_color,
            activeforeground="#ffffff",
            font=("Microsoft YaHei UI", 9),
        )
        menu.add_command(
            label="系统默认", command=lambda: self.set_output_device("")
        )
        menu.add_separator()
        for index, name in self._output_devices():
            menu.add_command(
                label=f"{index}  {name[:46]}",
                command=lambda i=index: self.set_output_device(i),
            )
        try:
            menu.tk_popup(
                self.root.winfo_pointerx(), self.root.winfo_pointery()
            )
        finally:
            menu.grab_release()

    def set_output_device(self, value) -> None:
        data = self._overlay_load_config()
        data["output_device"] = value
        self._overlay_write_config(data)
        self.cfg["output_device"] = value
        try:
            self.device_label.config(text=self._output_device_text())
        except Exception:
            pass
        self.flash(
            f"输出设备：{self._output_device_text()}（下一句生效）", 3.5
        )

    def _build_voice_drawer(self) -> None:
        tk = self.tk
        head = tk.Frame(self.voice_drawer, bg=CARD)
        head.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(
            head,
            text=f"想要哪个直接点（一共 {len(VOICES)} 个）",
            bg=CARD,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(head, "收起", lambda: self.toggle_voice_drawer()).pack(
            side="right"
        )
        for index, (_voice, label, _pitch, _fx) in enumerate(VOICES):
            line = tk.Frame(self.voice_drawer, bg=CARD)
            line.pack(fill="x", padx=8, pady=1)
            name = tk.Label(
                line,
                text=label,
                bg=CARD,
                fg="#ffffff",
                anchor="w",
                font=("Microsoft YaHei UI", 9),
                padx=6,
                pady=3,
                cursor="hand2",
            )
            name.pack(side="left", fill="x", expand=True)
            name.bind(
                "<Button-1>", lambda _event, i=index: self.select_voice(i)
            )
            self._chip(
                line, "听", lambda idx=index: self.preview_voice(idx)
            ).pack(side="right", padx=(4, 2))
            self.voice_rows[index] = name
        self.refresh_voice_rows()

    def toggle_voice_drawer(self) -> None:
        self.voice_drawer_open = not bool(
            getattr(self, "voice_drawer_open", False)
        )
        if self.voice_drawer_open:
            self.voice_drawer.pack(fill="x", padx=12, pady=(2, 8))
            self.voice_more.config(text="选择 ▴")
        else:
            self.voice_drawer.pack_forget()
            self.voice_more.config(text="选择 ▾")
        self.root.after(10, self._on_stage_inner)

    def select_voice(self, index: int) -> None:
        self.voice_index = max(0, min(len(VOICES) - 1, int(index)))
        self.voice_label.config(text=self._voice_text())
        self.refresh_voice_rows()
        self.on_change()

    def refresh_voice_rows(self) -> None:
        for index, label in getattr(self, "voice_rows", {}).items():
            label.config(
                bg=self.button_color if index == self.voice_index else CARD,
                fg="#ffffff",
            )

    def build_look(self, parent) -> None:
        row = self._row(parent, "样式")
        self.wave_style_value = self.wave_style
        self.style_chips = {}
        for value, label in (("siri", "波形带"), ("bars", "声波条")):
            chip = self._chip(
                row, label, lambda current=value: self.set_wave_style(current)
            )
            chip.pack(side="left", padx=3)
            self.style_chips[value] = chip
        self.refresh_style_chips()

        row = self._row(parent, "颜色")
        self.sw_color = self._swatch(row, "面板", self.panel_color)
        self.sw_accent = self._swatch(row, "线条", self.accent)
        self.sw_button = self._swatch(row, "按钮", self.button_color)
        self.sw_text = self._swatch(row, "文字", self.text_color)
        row = self._row(parent, "说话色")
        self.sw_talk = self._swatch(row, "我说话时", self.talk_color)
        self.tk.Label(
            row,
            text="朗读时声音条换成这个颜色，形状跟着语音变化",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left", padx=6)

        row = self._row(parent, "背景图")
        self.bg_path = self.cfg.get("overlay_bg_image") or ""
        self.bg_label = self.tk.Label(
            row,
            text=Path(self.bg_path).name if self.bg_path else "无",
            bg=BG_PANEL,
            fg="#9a9aa5",
            width=12,
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.bg_label.pack(side="left", padx=4)
        self._chip(row, "清除", lambda: self.set_bg("")).pack(
            side="right", padx=4
        )
        self._chip(row, "选择", self.pick_bg).pack(side="right")

        self.sl_alpha = Slider(
            parent,
            "整体透明度",
            35,
            100,
            self.alpha * 100,
            fmt="{:.0f}%",
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sl_dim = Slider(
            parent,
            "背景变暗",
            0,
            90,
            float(self.cfg.get("overlay_bg_dim") or 45),
            fmt="{:.0f}%",
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sw_wheel = self._switch_row(
            parent, "滚轮调透明度", bool(self.cfg.get("wheel_alpha", True))
        )
        self.sw_snap = self._switch_row(
            parent, "贴边吸附", bool(self.cfg.get("snap_edges", True))
        )
        self.sl_width = Slider(
            parent,
            "悬浮窗宽度",
            240,
            760,
            self.W,
            fmt="{:.0f}",
            on_change=self.apply_size,
            bg=BG_PANEL,
        )
        self.sl_height = Slider(
            parent,
            "悬浮窗高度",
            76,
            220,
            self.H,
            fmt="{:.0f}",
            on_change=self.apply_size,
            bg=BG_PANEL,
        )

        self.tk.Label(
            parent,
            text="声音条特效（各自独立开关；节能模式下会自动关掉）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        self.fx_switches = {}
        for key, label, hint in (
            ("fx_trail", "视觉暂留", "声音条拖一条慢慢淡掉的残影"),
            ("fx_glow", "呼吸光晕", "顺着条的形状往外铺的柔光，跟着声音一明一暗"),
            ("fx_sparkles", "星尘", "说话时溅出去的小亮点"),
            ("fx_reflection", "倒影", "条下面一层淡淡的反光"),
            ("fx_sweep", "流光", "一道高光沿着条扫过去"),
            ("fx_ripple", "波纹", "没声音时，那颗小圆点一圈圈荡开"),
            ("fx_aurora", "极光柔光", "小圆点外面那层光会慢慢换色"),
            ("fx_rotor", "旋转光环", "一圈虚线光环绕着圆点慢慢转"),
            ("fx_orbit", "卫星环绕", "两颗小卫星绕着圆点飞，拖着光尾"),
            ("fx_starflare", "星芒", "十字形的亮光，一明一暗地闪"),
            ("fx_heartbeat", "心跳脉动", "圆点像心跳那样「咚—咚」"),
            ("fx_burst", "唤醒爆闪", "被叫醒的一瞬间炸出一圈小火星"),
        ):
            row = self._row(parent, label)
            self.tk.Label(
                row,
                text=hint,
                bg=BG_PANEL,
                fg="#6f6f7a",
                font=("Microsoft YaHei UI", 8),
            ).pack(side="left", padx=(0, 6))
            switch = Switch(
                row,
                bool(self.cfg.get(key, DEFAULTS[key])),
                on_change=lambda _value, current=key: self.on_fx_change(current),
                bg=BG_PANEL,
            )
            switch.canvas.pack(side="right", padx=(0, 10))
            self.fx_switches[key] = switch

        self.tk.Label(
            parent,
            text="各元素的位置和大小（负数的 X 表示离右边多远）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        layout = self.layout
        self.sp_name = SpinRow(
            parent,
            "名字",
            [
                ("x", "X", layout["name"][0], 4, -200, 800),
                ("y", "Y", layout["name"][1], 2, -80, 400),
                ("s", "字号", layout["name"][2], 1, 8, 48),
            ],
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sp_status = SpinRow(
            parent,
            "状态",
            [
                ("x", "X", layout["status"][0], 4, -800, 800),
                ("y", "Y", layout["status"][1], 2, -80, 400),
                ("s", "字号", layout["status"][2], 1, 8, 40),
            ],
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sp_switch = SpinRow(
            parent,
            "开关",
            [
                ("x", "X", layout["switch"][0], 4, -800, 800),
                ("y", "Y", layout["switch"][1], 2, -80, 400),
            ],
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sp_wave = SpinRow(
            parent,
            "波浪",
            [
                ("y", "距底", layout["wave"][0], 2, 0, 120),
                ("h", "高度", layout["wave"][1], 2, 10, 80),
            ],
            on_change=self.on_change,
            bg=BG_PANEL,
        )
        self.sw_show = {}
        for key, label in (
            ("name", "名字"), ("status", "状态"),
            ("line", "波浪"), ("switch", "开关"),
        ):
            self.sw_show[key] = self._switch_row(
                parent,
                "显示" + label,
                bool(self.cfg.get(f"overlay_show_{key}", True)),
            )

    def on_fx_change(self, key: str) -> None:
        switch = getattr(self, "fx_switches", {}).get(key)
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None) or {}
            self.fx.update({name: bool(value) for name, value in before.items()})
            self._auto_low = False
            self._fx_before_low = None
            self._auto_low_off = True
        self.fx[key] = (
            bool(switch.get()) if switch is not None
            else bool(self.fx.get(key))
        )
        if key == "fx_sparkles" and not self.fx[key]:
            self._sparks.clear()
        if key == "fx_trail" and not self.fx[key]:
            self._trail_img = None
        self.on_change()

    def _group(self, parent, title: str) -> None:
        tk = self.tk
        bar = tk.Frame(parent, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(
            bar,
            text=title,
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9, "bold"),
        ).pack(side="left")
        tk.Frame(bar, bg=BORDER, height=1).pack(
            side="left", fill="x", expand=True, padx=(8, 0)
        )

    def _row(self, parent, label):
        tk = self.tk
        row = tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", pady=3)
        tk.Label(
            row,
            text=label,
            bg=BG_PANEL,
            fg="#ffffff",
            width=12,
            anchor="w",
            font=("Microsoft YaHei UI", 9),
        ).pack(side="left", padx=(10, 4))
        return row

    def _chip(self, parent, text, command):
        chip = self.tk.Label(
            parent,
            text=text,
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=10,
            pady=3,
            cursor="hand2",
        )
        chip.bind("<Button-1>", lambda _event: command())
        return chip

    def _switch_row(self, parent, label, value, on_change=None):
        row = self._row(parent, label)
        switch = Switch(
            row,
            bool(value),
            on_change or (lambda _value: self.on_change()),
            bg=BG_PANEL,
        )
        switch.canvas.pack(side="right", padx=(0, 10))
        return switch

    def _swatch(self, parent, label, color):
        tk = self.tk
        cell = tk.Frame(parent, bg=BG_PANEL)
        cell.pack(side="left", padx=(0, 8))
        tk.Label(
            cell,
            text=label,
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left", padx=(0, 2))
        canvas = tk.Canvas(
            cell,
            width=26,
            height=16,
            bg=BG_PANEL,
            highlightthickness=0,
            cursor="hand2",
        )
        canvas.pack(side="left")
        rectangle = canvas.create_rectangle(
            1, 1, 25, 15, fill=color, outline="#55555f"
        )

        def choose(_event=None):
            from tkinter import colorchooser

            _rgb, picked = colorchooser.askcolor(
                color=canvas.itemcget(rectangle, "fill")
            )
            if picked:
                canvas.itemconfig(rectangle, fill=picked)
                self.on_change()

        canvas.bind("<Button-1>", choose)
        return canvas, rectangle
