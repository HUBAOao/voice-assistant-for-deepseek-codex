# -*- coding: utf-8 -*-
"""Wake-level selection, custom levels and self-test UI behavior."""
from __future__ import annotations

import json
import time

import wake_levels
from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import CONTROL, WAKE_TEST_FILE
from overlay_feature import runtime as _runtime


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsWakeMixin:
    """Keep wake behavior separate from the identity page composition."""

    def build_wake_level(self, parent) -> None:
        row = self._row(parent, "唤醒档位")
        self._chip(row, "自检", self.run_wake_test).pack(
            side="right",
            padx=(4, 10),
        )
        self._chip(row, "＋自定", self.add_wake_level).pack(
            side="right",
            padx=2,
        )
        self.level_holder = self.tk.Frame(parent, bg=BG_PANEL)
        self.level_holder.pack(fill="x", padx=(12, 10), pady=(0, 2))
        self.level_info = self.tk.Label(
            parent,
            text="",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            anchor="w",
            justify="left",
            wraplength=386,
        )
        self.level_info.pack(fill="x", padx=(14, 10), pady=(0, 3))
        self.level_chips = {}
        self.refresh_level_chips()

    def custom_levels(self) -> dict:
        return dict(self.cfg.get("wake_levels") or {})

    def refresh_level_chips(self) -> None:
        if not hasattr(self, "level_holder"):
            return
        for child in self.level_holder.winfo_children():
            child.destroy()
        self.level_chips = {}
        room = max(220, self.expand_w - 34)
        try:
            import tkinter.font as tkfont

            metre = tkfont.Font(font=("Microsoft YaHei UI", 9))
        except Exception:
            metre = None
        line, used = None, 0
        for name in wake_levels.merged(self.custom_levels()):
            width = (
                metre.measure(name) + 26
                if metre is not None
                else 9 * len(name) + 30
            )
            if line is None or used + width > room:
                line = self.tk.Frame(self.level_holder, bg=BG_PANEL)
                line.pack(anchor="w", fill="x")
                used = 0
            chip = self._chip(
                line,
                name,
                lambda current=name: self.set_wake_level(current),
            )
            chip.pack(side="left", padx=2, pady=1)
            used += width
            self.level_chips[name] = chip
        self.refresh_level_colors()
        self.update_level_info()

    def refresh_level_colors(self) -> None:
        current = str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL)
        for name, chip in getattr(self, "level_chips", {}).items():
            chip.config(
                bg=self.button_color if name == current else "#24242a",
                fg="#ffffff",
            )

    def update_level_info(
        self,
        text: str | None = None,
        color: str = "#7f7f8a",
    ) -> None:
        if not hasattr(self, "level_info"):
            return
        if text is None:
            name, params = wake_levels.params(self.cfg)
            text = f"「{name}」{wake_levels.describe(params)}"
            if getattr(self, "wake_test_result", ""):
                text = f"{self.wake_test_result}   ·   {text}"
        self.level_info.config(text=text, fg=color)

    def set_wake_level(self, name: str) -> None:
        self.cfg["wake_level"] = name
        self.refresh_level_colors()
        self.update_level_info()
        self.on_change()
        self.flash(f"唤醒档位：{name}", 1.6)

    def add_wake_level(self) -> None:
        name, params = wake_levels.params(self.cfg)

        def done(text: str) -> None:
            got = wake_levels.from_text(text)
            if not got:
                self.flash("没读懂，名称那一行不能空", 2.4)
                return
            new_name, new_params = got
            custom = dict(self.cfg.get("wake_levels") or {})
            custom[new_name] = new_params
            self.cfg["wake_levels"] = custom
            self.cfg["wake_level"] = new_name
            self.refresh_level_chips()
            self.on_change()
            self.flash(f"已新增档位「{new_name}」", 2.4)

        self.edit_text(
            "唤醒档位（照抄着改数值就行）",
            wake_levels.to_text(name, params),
            done,
            multiline=True,
        )

    def run_wake_test(self) -> None:
        send_command("wake-test")
        self.wake_test_at = time.time()
        self.wake_test_result = ""
        self.update_level_info(
            "正在自检唤醒词…（会合成几段语音试一遍，稍后念出结果）",
            "#c9c9d6",
        )
        self.flash("正在自检唤醒词…", 3)

    def poll_wake_test(self) -> None:
        try:
            data = json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_wake_test_ts", 0.0):
            return
        self._wake_test_ts = ts
        self.wake_test_result = str(data.get("summary") or "")
        if self.wake_test_result:
            self.flash(self.wake_test_result, 4.5)
            self.update_level_info()
