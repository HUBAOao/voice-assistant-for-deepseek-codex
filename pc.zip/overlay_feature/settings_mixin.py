# -*- coding: utf-8 -*-
"""Overlay settings shell, basic tab and wake-level controls."""
from __future__ import annotations

from pathlib import Path

import version
from overlay_feature.defaults import BG_PANEL, BORDER, CARD
from overlay_feature.runtime import (
    CONTROL,
    make_no_activate,
    virtual_screen,
)
from overlay_feature import runtime as _runtime


HERE = Path(__file__).resolve().parent.parent


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsMixin:
    def build_panel(self) -> None:
        import tkinter as tk

        # 设置面板放进独立窗口：主浮窗保持 344×112 不动，展开/收起不再改
        # 原生窗口尺寸（Windows 下每改一次尺寸都要重新合成整块半透明窗口，
        # 之前 14 步动画每步 20~30ms，所以怎么调都卡）。
        if self.panel_win is None:
            win = tk.Toplevel(self.root)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            win.configure(bg=BG_PANEL)
            try:
                win.attributes("-toolwindow", True)
            except Exception:
                pass
            win.attributes("-alpha", 0.0)
            win.withdraw()
            self.panel_win = win
        panel = tk.Frame(self.panel_win, bg=BG_PANEL, highlightthickness=1,
                         highlightbackground=BORDER)
        self.panel = panel
        self.tab_names = ["基本", "声音", "外观", "智能", "功能", "日程"]
        self.tab_frames: dict[str, object] = {}
        self.tab_labels: dict[str, object] = {}

        bar = tk.Frame(panel, bg=BG_PANEL)
        bar.pack(fill="x", padx=8, pady=(8, 4))
        for name in self.tab_names:
            lab = tk.Label(bar, text=name, bg=BG_PANEL, fg="#9a9aa5",
                           font=("Microsoft YaHei UI", 9), padx=10, pady=4, cursor="hand2")
            lab.pack(side="left", padx=2)
            lab.bind("<Button-1>", lambda _e, n=name: self.show_tab(n))
            self.tab_labels[name] = lab
        self.hint_label = tk.Label(bar, text="改动即时预览", bg=BG_PANEL, fg="#5f5f68",
                                   font=("Microsoft YaHei UI", 8))
        self.hint_label.pack(side="right", padx=6)

        # 标签页内容放在一张画布上：屏幕矮的机器（比如 1080P）也能用滚轮把
        # 下面够不着的开关滚出来看，不会像以前那样被窗口底边直接切掉。
        stage = tk.Canvas(panel, bg=BG_PANEL, highlightthickness=0, bd=0, takefocus=0)
        stage.pack(fill="both", expand=True)
        self.stage = self.stage_canvas = stage
        inner = tk.Frame(stage, bg=BG_PANEL)
        self.stage_inner = inner
        self._stage_win = stage.create_window((0, 0), window=inner, anchor="nw")
        stage.bind("<Configure>", self._on_stage_resize)
        inner.bind("<Configure>", self._on_stage_inner)
        for name in self.tab_names:
            self.tab_frames[name] = tk.Frame(inner, bg=BG_PANEL)

        self.build_basic(self.tab_frames["基本"])
        self.build_sound(self.tab_frames["声音"])
        self.build_look(self.tab_frames["外观"])
        self.build_smart(self.tab_frames["智能"], self.tab_frames["功能"])
        self.build_schedule(self.tab_frames["日程"])

        foot = tk.Frame(panel, bg=BG_PANEL)
        foot.pack(fill="x", padx=10, pady=(4, 10))
        # 左下角：版本号（＝你让我改过多少次，见 version.py）
        tk.Label(foot, text=version.label(), bg=BG_PANEL, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(2, 0))
        save = tk.Label(foot, text="保存", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=5, cursor="hand2")
        save.pack(side="right")
        save.bind("<Button-1>", lambda _e: self.save_settings())
        reset = tk.Label(foot, text="恢复默认", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        reset.pack(side="right", padx=8)
        reset.bind("<Button-1>", lambda _e: self.reset_defaults())
        # 「关于」：署名 / 版权 / 邮箱 / 使用许可，只在这一个地方显示
        about_btn = tk.Label(foot, text="关于", bg=CARD, fg="#ffffff",
                             font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        about_btn.pack(side="right", padx=(0, 4))
        about_btn.bind("<Button-1>", lambda _e: self.show_about())
        # 「检查更新」：数据读的是下载页那份（网页一刷新，这边就提示更新）
        self.upd_label = tk.Label(foot, text="", bg=BG_PANEL, fg="#6f6f7a",
                                  font=("Microsoft YaHei UI", 8))
        self.upd_label.pack(side="left", padx=(8, 0))
        upd_btn = tk.Label(foot, text="检查更新", bg=CARD, fg="#ffffff",
                           font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        upd_btn.pack(side="right", padx=(0, 4))
        upd_btn.bind("<Button-1>", lambda _e: self.check_update())
        # 「发布到网站」：把下载页推到公网（第一次会弹一次 git 登录，之后自动）
        pub_btn = tk.Label(foot, text="发布到网站", bg=CARD, fg="#ffffff",
                           font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        pub_btn.pack(side="right", padx=(0, 4))
        pub_btn.bind("<Button-1>", lambda _e: self.publish_site())
        self._bind_wheel_tree(inner)      # 面板里每一层都能吃滚轮
        # 右边一条细滚动条：内容装不下才出现，让你知道"还能往下滚"
        self.scroll_hint = tk.Canvas(panel, width=4, bg=BG_PANEL, highlightthickness=0, bd=0)
        self.show_tab("基本")

    # ------------------------------------------------- 面板滚轮
    def _on_stage_resize(self, event) -> None:
        """画布宽度变了，里面那层跟着变宽，内容才不会缩成一条。"""
        try:
            self.stage.itemconfig(self._stage_win, width=max(1, int(event.width)))
        except Exception:
            pass
        self._update_scroll_hint()

    def _on_stage_inner(self, _event=None) -> None:
        try:
            self.stage.configure(scrollregion=self.stage.bbox("all"))
        except Exception:
            pass
        self._update_scroll_hint()

    def _update_scroll_hint(self) -> None:
        """右上角那条细条：内容比窗口高才显示，位置跟着滚动走。"""
        bar = getattr(self, "scroll_hint", None)
        stage = getattr(self, "stage_canvas", None)
        if bar is None or stage is None:
            return
        try:
            region = stage.bbox("all")
            view = stage.winfo_height()
            if not region or view <= 1 or region[3] - region[1] <= view + 1:
                bar.place_forget()
                return
            top, bottom = stage.yview()
            h = max(26, int(view * (bottom - top)))
            y = int(stage.winfo_y() + view * top)
            bar.delete("all")
            bar.create_rectangle(0, 0, 4, h, fill=self.button_color, outline="")
            bar.place(relx=1.0, x=-6, y=y, width=4, height=h)
        except Exception:
            pass

    def _bind_wheel_tree(self, widget) -> None:
        widget.bind("<MouseWheel>", self.on_panel_wheel, add="+")
        for child in widget.winfo_children():
            self._bind_wheel_tree(child)

    def on_panel_wheel(self, event):
        """内容装不下才滚；装得下就不动，别抢浮窗自己那个"滚轮调透明度"。"""
        stage = getattr(self, "stage_canvas", None)
        if stage is None:
            return None
        region = stage.bbox("all")
        if not region or region[3] - region[1] <= stage.winfo_height() + 1:
            self._update_scroll_hint()
            return None
        stage.yview_scroll(-1 if getattr(event, "delta", 0) > 0 else 1, "units")
        self._update_scroll_hint()
        return "break"

    def show_tab(self, name: str) -> None:
        self.current_tab = name
        for key, frame in self.tab_frames.items():
            if key == name:
                frame.pack(fill="both", expand=True)
            else:
                frame.pack_forget()
        stage = getattr(self, "stage_canvas", None)
        if stage is not None:
            try:
                stage.yview_moveto(0.0)       # 换页从头看起
                self._on_stage_inner()
            except Exception:
                pass
        for key, lab in self.tab_labels.items():
            lab.config(bg=CARD if key == name else BG_PANEL,
                       fg="#ffffff" if key == name else "#9a9aa5")
        # 展开着切页：高度是固定的，不跟着内容变（装不下的用滚轮看）
        if self.expanded:
            self._place_panel(self._expanded_h())
        self.root.after(30, self._update_scroll_hint)
        # 切到「智能」那一页就顺手看一眼外网状态（后台跑，不卡界面）
        if name == "智能" and getattr(self, "remote_label", None) is not None:
            self.root.after(60, self.refresh_remote)

    def maybe_first_run(self) -> None:
        """第一次用的时候弹一个小引导（三步），看过了就不再弹。"""
        mark = HERE / "first-run.done"
        if mark.exists():
            return
        try:
            mark.write_text("ok", encoding="utf-8")
        except Exception:
            return
        tk = self.tk
        try:
            win = tk.Toplevel(self.root)
        except Exception:
            return
        win.title("第一次用，三步就能上手")
        win.configure(bg=BG_PANEL)
        win.attributes("-topmost", True)
        win.geometry("460x300")
        tk.Label(win, text="三步就能用起来", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 14, "bold")).pack(anchor="w", padx=18, pady=(16, 6))
        steps = [
            "1. 先确认麦克风：说「自检」，它会告诉你麦克风/模型/窗口/剪贴板有没有问题。",
            "2. 试一句：说「" + str(self.cfg.get("wake_word") or "大肥鱼") +
            "」，听到两声提示音再说话，说完自动发出去。",
            "3. 挑声音：设置 → 声音 → 音色，点「选择」把抽屉拉开，想用哪个直接点哪个"
            "（每行右边还有「听」，一边听一边挑）。",
            "",
            "其它常用的：说「专注25分钟」开番茄钟；「记一下 明天买牛奶」存便签；",
            "「别记这段」让它几分钟不记录；「自检」随时查身体。",
        ]
        for s in steps:
            tk.Label(win, text=s, bg=BG_PANEL, fg="#c9c9d6", justify="left",
                     font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=20, pady=1)
        tk.Label(win, text="知道了", bg=self.button_color, fg="#ffffff", padx=22, pady=6,
                 cursor="hand2", font=("Microsoft YaHei UI", 10, "bold")).pack(pady=14)
        win.winfo_children()[-1].bind("<Button-1>", lambda _e: win.destroy())

    def sync_rec_dot(self) -> None:
        """（用户要求）右下角那个「● 在听」的小红点去掉了。

        以前只要在录音就常亮，用户觉得碍事；现在要"在听"的提示只在浮窗/桌宠里、
        而且只有真的听到声音时才出现。这里保留函数名，只是把窗口关掉。
        """
        if self.rec_win is not None:
            try:
                self.rec_win.destroy()
            except Exception:
                pass
            self.rec_win = None
        return
        live = False          # 下面这段留着备查：真要恢复就把上面的 return 删掉
        if live and self.rec_win is None:
            try:
                win = self.tk.Toplevel(self.root)
                win.overrideredirect(True)
                win.title("在听")        # 别继承浮窗的名字，不然找窗口的工具会认错
                win.attributes("-topmost", True)
                win.configure(bg="#141418")
                lab = self.tk.Label(win, text="● 在听", bg="#141418", fg="#ff5c5c",
                                    font=("Microsoft YaHei UI", 12, "bold"), padx=12, pady=4)
                lab.pack()
                make_no_activate(win.winfo_id())
                vx, vy, vw, vh = virtual_screen()
                win.geometry(f"+{vx + vw - 150}+{vy + vh - 120}")
                self.rec_win = win
            except Exception:
                self.rec_win = None
        elif not live and self.rec_win is not None:
            try:
                self.rec_win.destroy()
            except Exception:
                pass
            self.rec_win = None

