# -*- coding: utf-8 -*-
"""Pillow rendering for the voice strip, dot effects, and sprites."""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter

from overlay_feature.defaults import ARROW, BORDER, KNOB, SW_H, SW_W
from overlay_feature.runtime import HERE, font, mix, rgb, shade


class OverlayVisualMixin:
    def switch_sprite(self, pos: float):
        p = round(pos * 40) / 40
        key = ("sw", p, self.button_color)
        sprite = self._sprites.get(key)
        if sprite is None:
            scale = 4
            big = (SW_W * scale, SW_H * scale)
            im = Image.new("RGBA", big, (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, big[0] - 1, big[1] - 1], radius=big[1] // 2,
                                fill=mix(shade(self.button_color, -0.45), self.button_color, p))
            pad, r = 3 * scale, (SW_H - 6) / 2 * scale
            x0 = pad + (big[0] - 2 * pad - 2 * r) * p
            cy = big[1] / 2
            d.ellipse([x0, cy - r, x0 + 2 * r, cy + r], fill=KNOB)
            sprite = im.resize((SW_W, SW_H), Image.LANCZOS)
            self._sprites[key] = sprite
        return sprite

    def ball_sprite(self, color: str, radius: float):
        r = max(1.0, round(radius * 2) / 2)
        key = ("ball", color, r)
        sprite = self._sprites.get(key)
        if sprite is None:
            size = int(r * 2) + 8
            scale = 4
            im = Image.new("RGBA", (size * scale, size * scale), (0, 0, 0, 0))
            c = size * scale / 2
            rr = r * scale
            ImageDraw.Draw(im).ellipse([c - rr, c - rr, c + rr, c + rr], fill=color)
            sprite = im.resize((size, size), Image.LANCZOS)
            self._sprites[key] = sprite
        return sprite

    # ------------------------------------------------------------ 底图
    def base_image(self) -> Image.Image:
        w, h = int(round(self.cur_w)), self.header_h
        key = (w, h, self.panel_color, self.bg_image, self.bg_dim, self.name,
               self.show_name, self.layout["name"], self.text_color)
        if self._base is None or self._base_key != key:
            im = Image.new("RGB", (w, h), self.panel_color)
            bg_path = Path(self.bg_image) if self.bg_image else None
            if bg_path is not None and not bg_path.is_absolute():
                bg_path = HERE / bg_path          # 支持随程序走的相对路径
            if bg_path is not None and bg_path.exists():
                try:
                    bg = Image.open(bg_path).convert("RGB")
                    ratio = max(w / bg.width, h / bg.height)
                    bg = bg.resize((max(1, int(bg.width * ratio)), max(1, int(bg.height * ratio))),
                                   Image.LANCZOS)
                    left, top = (bg.width - w) // 2, (bg.height - h) // 2
                    bg = bg.crop((left, top, left + w, top + h))
                    if self.bg_dim > 0:
                        bg = Image.blend(bg, Image.new("RGB", bg.size, (0, 0, 0)),
                                         self.bg_dim / 100)
                    im = bg
                except Exception:
                    pass
            d = ImageDraw.Draw(im)
            d.rectangle([0, 0, w - 1, h - 1], outline=BORDER)
            if self.show_name:
                nx, ny, nsize = self.layout["name"]
                d.text((nx, ny), self.name, font=font(nsize, bold=True), fill=self.text_color)
            self._base, self._base_key = im, key
        return self._base

    def draw_arrow(self, d: ImageDraw.ImageDraw, w: int) -> None:
        ax = w - ARROW - 10
        ay = self.header_h - ARROW - 8
        cx, cy = ax + ARROW / 2, ay + ARROW / 2
        color = mix(self.panel_color, self.text_color, 0.75)
        if self.expanded:
            d.line([(cx - 7, cy + 4), (cx, cy - 4), (cx + 7, cy + 4)],
                   fill=color, width=2, joint="curve")
        else:
            d.line([(cx - 7, cy - 4), (cx, cy + 4), (cx + 7, cy - 4)],
                   fill=color, width=2, joint="curve")

    # ------------------------------------------------------------ 声音条
    def draw_caption(self, d: ImageDraw.ImageDraw, w: int, wave_top: int,
                     spoken: str = "", progress: float = 0.0) -> None:
        """实时字幕：把你正在说的话（或刚发出去的那句）压在声音条上方。"""
        if not (self.show_caption and self.caption_on):
            return
        karaoke = bool(self.karaoke_on and spoken)
        text = spoken if karaoke else str((self.status or {}).get("text") or "").strip()
        if not text and self.focus_left > 0:      # 专注中：字幕位就让给倒计时
            left = int(self.focus_left)
            text = f"专注 {left // 60:02d}:{left % 60:02d}"
        if not text:
            return
        if len(text) > 42:
            text = text[:41] + "…"
        f = font(13)
        box = d.textbbox((0, 0), text, font=f)
        tw, th = box[2] - box[0], box[3] - box[1]
        y = wave_top - th - 6
        if y < 20:                       # 上方实在没空就不画，别压到名字上
            return
        x = max(6, (w - tw) / 2)
        d.rounded_rectangle([x - 9, y - 3, x + tw + 9, y + th + 4], radius=7,
                            fill=mix(self.panel_color, "#000000", 0.35))
        d.text((x + 1, y + 1), text, font=f, fill="#000000")
        if karaoke:
            # 逐字跟读：念到哪儿，前面那截就亮到哪儿；后面那截先暗暗地摆着
            cut = max(0, min(len(text), int(round(len(text) * progress))))
            head, tail = text[:cut], text[cut:]
            d.text((x, y), head, font=f, fill=self.text_color)
            if tail:
                offset = d.textlength(head, font=f)
                d.text((x + offset, y), tail, font=f,
                       fill=mix(self.panel_color, self.text_color, 0.38))
        else:
            d.text((x, y), text, font=f, fill=self.text_color)

    def draw_spectrum(self, im: Image.Image, d: ImageDraw.ImageDraw, color: str,
                      bands: list) -> None:
        """音浪：把声音条换成一排跟着音乐跳的柱子。"""
        if not self.show_line or not bands:
            return
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        count = len(bands)
        left, right = 18, im.width - 18
        step = (right - left) / count
        bar_w = max(3.0, step * 0.44)
        for i, value in enumerate(bands):
            frac = max(0.0, min(1.0, float(value)))
            # 平滑一点，别一帧一个样
            key = "_band_shown"
            shown = getattr(self, key, None)
            if shown is None or len(shown) != count:
                shown = [0.0] * count
            shown[i] += (frac - shown[i]) * 0.4
            setattr(self, key, shown)
            h = max(3.0, (height - 4) * shown[i])
            x0 = left + i * step + (step - bar_w) / 2
            d.rounded_rectangle([x0, bottom - h, x0 + bar_w, bottom],
                                radius=bar_w / 2, fill=color)

    def draw_focus(self, im: Image.Image, d: ImageDraw.ImageDraw, color: str,
                   elapsed: float) -> None:
        """番茄钟：把声音条换成一根越来越短、越来越红的进度条。"""
        if not self.show_line:
            return
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        left, right = 20, im.width - 20
        cy = bottom - height / 2
        bar_h = max(6.0, min(13.0, height * 0.24))
        d.rounded_rectangle([left, cy - bar_h / 2, right, cy + bar_h / 2],
                            radius=bar_h / 2, fill=mix(self.panel_color, "#ffffff", 0.14))
        frac = max(0.0, min(1.0, 1.0 - elapsed))
        if frac <= 0.002:
            return
        end = left + (right - left) * frac
        hot = mix(color, "#ff5c5c", min(1.0, max(0.0, elapsed - 0.6) / 0.4))
        d.rounded_rectangle([left, cy - bar_h / 2, max(left + bar_h, end), cy + bar_h / 2],
                            radius=bar_h / 2, fill=hot)
        r = bar_h * (0.75 + 0.3 * (0.5 + 0.5 * math.sin(self.breath * 2.4)))
        d.ellipse([end - r, cy - r, end + r, cy + r], fill=mix(hot, "#ffffff", 0.55))

    def draw_voice(self, im: Image.Image, color: str) -> None:
        """声音条：以音量为驱动，在"中间小圆点"和"整条波形"之间连续形变。

        t=0 全是小圆点，t=1 是铺满的波形；中间过程是平滑生长（不是阈值切换）。
        画完条之后再叠各种可选特效（视觉暂留、光晕、星尘、倒影、流光）。
        """
        if not self.show_line:
            return
        w = im.width
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        top = bottom - height
        level = max(0.0, min(1.0, self.level_shown * 1.25))
        raw = max(0.0, min(1.0, (level - 0.02) / 0.16))
        t = raw * raw * (3 - 2 * raw)          # smoothstep：两端更柔和
        dot_w = max(10.0, height * 0.55)
        if self.sleep_stage >= 2:               # 睡着了：缩成小小一颗、颜色也淡下去
            color = mix(color, self.panel_color, 0.45)
            dot_w *= 0.78
        if self._pop > 0:                       # 被叫醒：先弹一下
            dot_w *= 1.0 + 0.5 * self._pop
        eff_w = dot_w + (w - dot_w) * t
        thick = ((height * 0.62) * (1 - t) + 2.6 * t) * (1 + 0.4 * self._pop)
        strip = self.render_voice(int(eff_w), height, level, t, thick, color)
        x = int((w - strip.width) / 2)
        y = int(top + (height - strip.height) / 2)
        fx = self.fx if self.perf != "eco" else {}
        talk_now = t > 0.08                 # 真的在出声音（不是静止的小圆点）

        if self.sleep_stage >= 2 and t < 0.3:   # 睡着时飘两个 z
            zd = ImageDraw.Draw(im)
            fz = font(11)
            for i, (dx, dy) in enumerate(((8, -12), (17, -23))):
                zd.text((x + strip.width / 2 + dx, y + dy + math.sin(self.breath + i) * 2),
                        "z", font=fz, fill=mix(self.panel_color, "#ffffff", 0.5 - 0.15 * i))

        # 0) 呼吸光晕：顺着"当前这个形状"往外铺一层柔光 —— 有声音时贴着长条，
        #    没声音时就裹着那颗小圆点（"圆点只留光晕，光晕也要夹在长条上"）
        if fx.get("fx_glow"):
            self._draw_shape_glow(im, strip, x, y, color, t)
        # 1) 视觉暂留：攒一层会慢慢褪色的残影，垫在清晰的声音条下面
        if fx.get("fx_trail"):
            self._draw_trail(im, strip, x, y - top, w, height, top, bottom)
        # 2) 倒影：把声音条上下翻过来，淡淡地贴在下面
        if fx.get("fx_reflection"):
            self._draw_reflection(im, strip, x, y + strip.height,
                                  0.30 if talk_now else 0.16)
        im.paste(strip, (x, y), strip)
        # 3) 流光：一道高光沿着声音条扫过去
        if fx.get("fx_sweep") and talk_now:
            layer = Image.new("RGBA", strip.size, (255, 255, 255, 255))
            layer.putalpha(ImageChops.multiply(strip.getchannel("A"),
                                               self._sweep_mask(strip.width, strip.height)))
            im.paste(layer, (x, y), layer)
        # 4) 星尘：说话时溅出去的小亮点
        if fx.get("fx_sparkles"):
            self._draw_sparkles(im, x, y, strip, level, t, color)
        # 5) 没声音的时候（就是那颗小圆点）：呼吸、光晕、一圈圈荡开的波纹、偶尔星尘
        if not talk_now:
            # 小圆点的半径要按"真正画出来的那一坨"算：strip 是 width×height 的
            # 透明画布，圆点只占中间一块，拿画布尺寸当半径会让特效大出一圈、
            # 直接被窗口边缘切掉。
            cxd = x + strip.width / 2.0
            cyd = y + strip.height / 2.0
            bb = strip.getbbox() or (0, 0, strip.width, strip.height)
            dot_r = max(4.0, max(bb[2] - bb[0], bb[3] - bb[1]) / 2.0)
            # 上下左右能画到哪儿：特效再大也不许跑出窗口（不然只剩几根断弧）
            avail = max(dot_r + 5.0, min(cxd, im.width - cxd, cyd,
                                        im.height - cyd - 2.0))
            self._draw_dot_fx(im, cxd, cyd, dot_r, color, fx, avail)

    @staticmethod
    def _rgba(hexcolor: str, alpha: float) -> tuple:
        h = str(hexcolor or "#ffffff").lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        try:
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        except Exception:
            r = g = b = 255
        return (r, g, b, max(0, min(255, int(alpha))))

    @staticmethod
    def _hue(hexcolor: str, phase: float) -> str:
        """把颜色在色环上转 phase 圈（0~1），用来做极光那种缓慢换色。"""
        import colorsys

        h = str(hexcolor or "#ffffff").lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        try:
            r, g, b = (int(h[0:2], 16) / 255.0, int(h[2:4], 16) / 255.0,
                       int(h[4:6], 16) / 255.0)
        except Exception:
            r = g = b = 1.0
        hh, ss, vv = colorsys.rgb_to_hsv(r, g, b)
        # 纯灰的默认色相是 0，转起来会一眼红；给点最低饱和度，换色才看得出来
        hh = (hh + phase) % 1.0
        rr, gg, bb = colorsys.hsv_to_rgb(hh, max(ss, 0.55), vv)
        return "#%02x%02x%02x" % (int(rr * 255 + 0.5), int(gg * 255 + 0.5),
                                  int(bb * 255 + 0.5))

    def _beat(self) -> float:
        """心跳包络：一个周期里"咚—咚"两下，第二下比第一下轻一点。"""
        t = (self.breath * 1.6 / (2 * math.pi)) % 1.0
        out = 0.0
        for at, gain, span in ((0.0, 1.0, 0.20), (0.26, 0.72, 0.16)):
            dt = (t - at) % 1.0
            if dt < span:
                out = max(out, math.sin((1 - dt / span) * math.pi) * gain)
        return out

    def _draw_dot_fx(self, im: Image.Image, cx: float, cy: float, r: float,
                     color: str, fx: dict, avail: float | None = None) -> None:
        """小圆点的特效能：呼吸光晕、荡开的波纹、星尘，还有后来加的一堆花样。

        小圆点＝声音条完全收起来、没声音时的那个状态，所以这里的特效都只在
        "安静"的时候看得到；用户说"给小圆点也加点特效"，就照着一颗小球的
        感觉往上面叠：极光柔光、会转的光环、两颗粒子绕着飞、星芒、心跳、
        被叫醒那一下的爆闪。

        avail 是"从圆心到窗口边还剩多少像素"，所有半径都会被它夹住——
        不然光环比窗口还大，就只剩几根断弧挂在边上。
        """
        if r <= 0 or not fx:
            return
        reach = float(avail) if avail else r * 3.4

        def cap(value: float, slack: float = 1.0) -> float:
            return min(value, reach * slack)

        aura = Image.new("RGBA", im.size, (0, 0, 0, 0))
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        breath = 0.5 + 0.5 * math.sin(self.breath * 1.5)

        # ① 极光：垫在最底下，一层会慢慢换色的柔光（颜色沿着色环走）
        if fx.get("fx_aurora"):
            # 只在本色附近来回晃一点点（±25°），不搞整圈彩虹 —— 转整圈会飘到
            # 紫色/粉色上去，跟主题色对不上
            wobble = 0.07 * math.sin(self.breath * 0.02)
            hue = self._hue(mix(self.panel_color, color, 0.75), wobble)
            ad = ImageDraw.Draw(aura)
            for mult, alpha in ((2.05, 40), (1.45, 62)):
                rr = cap(r * (mult + 0.16 * breath), 0.92)
                ad.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                           fill=self._rgba(hue, alpha))
            aura = aura.filter(ImageFilter.GaussianBlur(max(2.5, r * 0.55)))
        # ② 旋转光环：一圈会自己转的虚线光环（转得很慢，像在待机）
        if fx.get("fx_rotor"):
            seg = 12
            rot = math.degrees(self.breath * 0.28)
            rr = cap(r * (1.72 + 0.10 * breath), 0.95)
            for i in range(0, seg, 2):
                a0 = rot + i * (360.0 / seg)
                if hasattr(d, "arc"):
                    d.arc([cx - rr, cy - rr, cx + rr, cy + rr], a0,
                          a0 + (360.0 / seg) * 0.60, fill=self._rgba(color, 150),
                          width=2)
        # 呼吸光晕不在这儿画：它走 _draw_shape_glow，跟长条共用一套（这样圆点就是
        # 一团柔光，长条就是一条顺着形状的光带，两个状态看着才是一回事）
        if fx.get("fx_ripple"):
            for k in (0.0, 0.5):                 # 两圈错开，看着像一直往外荡
                p = (self.breath * 0.32 + k) % 1.0
                rr = cap(r * (1.3 + 2.6 * p), 1.0)
                a = 95 * (1 - p) ** 1.6
                if a > 4:
                    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                              outline=self._rgba(color, a))
        # ③ 心跳：圆点像心跳那样"咚—咚"地脉动，多一圈跟着涨缩的亮环
        if fx.get("fx_heartbeat"):
            p = self._beat()
            if p > 0.02:
                rr = cap(r * (1.22 + 0.72 * p), 1.0)
                d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                          outline=self._rgba(mix(self.panel_color, color, 0.62),
                                             125 * p), width=2)
        # ④ 星芒：十字形的亮光，随呼吸一明一暗
        if fx.get("fx_starflare"):
            fl = 0.45 + 0.55 * breath
            for ang in (0.0, math.pi / 2, math.pi, math.pi * 1.5):
                ln = cap(r * (1.55 + 1.15 * fl), 1.05)
                d.line([cx + math.cos(ang) * r * 0.85, cy + math.sin(ang) * r * 0.85,
                        cx + math.cos(ang) * ln, cy + math.sin(ang) * ln],
                       fill=self._rgba(mix(color, "#ffffff", 0.35), 45 + 95 * fl),
                       width=2)
        # ⑤ 卫星：两颗小卫星一快一慢地绕着圆点转，各自拖一条短短的光尾
        if fx.get("fx_orbit"):
            for i, (speed, rad, tint) in enumerate(((0.52, 1.78, 0.0),
                                                    (-0.34, 2.26, 0.38))):
                ang = self.breath * speed + i * 2.6
                orb = cap(r * (rad + 0.06 * breath), 0.98)
                ox = cx + math.cos(ang) * orb
                oy = cy + math.sin(ang) * orb
                trail_tint = self._hue(color, tint) if fx.get("fx_aurora") else color
                for k in range(4):                       # 尾巴：越往后越淡越小
                    ta = ang - math.copysign(k * 0.20, speed)
                    tx = cx + math.cos(ta) * orb
                    ty = cy + math.sin(ta) * orb
                    sz = 1.5 - 0.28 * k
                    if sz <= 0:
                        continue
                    d.ellipse([tx - sz, ty - sz, tx + sz, ty + sz],
                              fill=self._rgba(trail_tint, 95 - 22 * k))
                d.ellipse([ox - 1.9, oy - 1.9, ox + 1.9, oy + 1.9],
                          fill=self._rgba("#ffffff", 215))
        # ⑥ 星尘：偶尔往上飘的小亮点
        if fx.get("fx_sparkles"):
            for i in range(2):
                p = (self.breath * 0.11 + i * 0.5) % 1.0
                a = 130 * (1 - p)
                if a > 8:
                    dx = math.sin(self.breath * 0.9 + i * 2.1) * cap(r + 8 + 15 * p, 1.1)
                    dy = -p * min(18.0, reach) + math.cos(self.breath * 0.7 + i) * 4
                    d.ellipse([cx + dx - 1.4, cy + dy - 1.4,
                               cx + dx + 1.4, cy + dy + 1.4],
                              fill=self._rgba(color, a))
        # ⑦ 唤醒爆闪：被叫醒（_pop 从 1 掉到 0）那半秒，炸出一圈往外飞的小火星
        if fx.get("fx_burst") and self._pop > 0.02:
            p = self._pop
            for i in range(12):
                ang = i * (2 * math.pi / 12) + 0.4
                dist = cap(r * (1.05 + 3.6 * (1 - p)), 1.2)
                dx = cx + math.cos(ang) * dist
                dy = cy + math.sin(ang) * dist
                sz = 1.1 + 2.1 * p
                d.ellipse([dx - sz, dy - sz, dx + sz, dy + sz],
                          fill=self._rgba(mix(color, "#ffffff", 0.3), 225 * p))
        if aura.getbbox():
            layer = Image.alpha_composite(aura, layer)
        if layer.getbbox():
            try:
                im.paste(Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB"), (0, 0))
            except Exception:
                pass

    def _draw_shape_glow(self, im: Image.Image, strip: Image.Image, x: int, y: int,
                         color: str, t: float) -> None:
        """呼吸光晕：按"形状"往外铺的柔光（长条就是一条长光带，圆点就是一团圆光）。

        以前这层光是在声音条自己那张小图上糊一层模糊再贴回去的 —— 图就条那么大，
        光一冒出边界就被裁掉了，等于白做（所以看着像"没有光晕"）。现在挪到整块画布
        上：把形状的透明通道往外扩一圈、模糊、染成主题色，垫在形状底下，
        光就会顺着条的轮廓铺开；那颗小圆点走的是同一条路，于是圆点只剩一团光晕。
        """
        if strip.width <= 0 or strip.height <= 0:
            return
        pad = int(max(5.0, strip.height * 0.55))
        wide = Image.new("RGBA",
                         (strip.width + pad * 2, strip.height + pad * 2),
                         (0, 0, 0, 0))
        wide.paste(strip, (pad, pad), strip)
        breathe = 0.72 + 0.28 * (0.5 + 0.5 * math.sin(self.breath * 1.6))
        alpha = int((124 - 38 * t) * breathe)     # 小圆点亮一点，长条淡一点
        glow = wide.copy()
        glow.putalpha(wide.getchannel("A").point(lambda v: min(255, v * alpha // 255)))
        glow = glow.filter(ImageFilter.GaussianBlur(max(2.0, strip.height * 0.22)))
        solid = Image.new("RGBA", glow.size, self._rgba(color, 0))
        solid.putalpha(glow.getchannel("A"))
        self._paste_clipped(im, solid, x - pad, y - pad)

    # -------------------------------------------------- 特效小工具
    @staticmethod
    def _fade_alpha(img: Image.Image, factor: float) -> Image.Image:
        out = img.copy()
        out.putalpha(img.getchannel("A").point(lambda v: int(v * factor)))
        return out

    @staticmethod
    def _paste_clipped(dst: Image.Image, src: Image.Image, x: int, y: int) -> None:
        """按目标边界裁一下再贴，避免超出窗口时报错。"""
        x0, y0 = max(0, x), max(0, y)
        x1 = min(dst.width, x + src.width)
        y1 = min(dst.height, y + src.height)
        if x1 <= x0 or y1 <= y0:
            return
        part = src.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        dst.paste(part, (x0, y0), part)

    def _draw_trail(self, im: Image.Image, strip: Image.Image, sx: int, sy: int,
                    w: int, height: int, top: int, bottom: int) -> None:
        """视觉暂留：每帧先把旧的残影淡一点点，再把当前这一帧盖上去。"""
        key = (w, height)
        if self._trail_img is None or self._trail_key != key:
            self._trail_img = Image.new("RGBA", (w, height), (0, 0, 0, 0))
            self._trail_key = key
        # 按时间褪色：帧率调高低都是同样的拖尾长度
        decay = 0.80 ** max(0.25, self.dt / 0.016)
        a = self._trail_img.getchannel("A").point(lambda v: int(v * decay))
        self._trail_img.putalpha(a)
        self._trail_img.alpha_composite(strip, (sx, sy))
        base = im.crop((0, top, w, bottom)).convert("RGBA")
        im.paste(Image.alpha_composite(base, self._trail_img).convert("RGB"), (0, top))

    def _sweep_mask(self, w: int, h: int) -> Image.Image:
        """一道柔和的竖向高光，沿着条来回扫：来回是因为来回两头都没有跳变。"""
        pos = 1.0 - abs(2.0 * (self._sweep_pos % 1.0) - 1.0)     # 乒乓往复
        width = 0.24
        row = Image.new("L", (w, 1))
        px = row.load()
        for i in range(w):
            u = i / max(1, w - 1)
            v = max(0.0, 1.0 - abs(u - pos) / width)
            px[i, 0] = int(v * v * 244)
        return row.resize((w, h))

    def _draw_reflection(self, im: Image.Image, strip: Image.Image, x: int,
                         mirror_y: int, alpha: float) -> None:
        """倒影：上下翻一份压扁的淡影，贴在声音条正下方那点空隙里。"""
        room = im.height - mirror_y - 1
        if room < 6:
            return
        want = max(6, min(room, int(strip.height * 0.42)))
        refl = strip.transpose(Image.FLIP_TOP_BOTTOM).resize(
            (strip.width, want), Image.LANCZOS)
        self._paste_clipped(im, self._fade_alpha(refl, alpha), x, mirror_y + 1)

    def _draw_sparkles(self, im: Image.Image, x: int, y: int, strip: Image.Image,
                       level: float, t: float, color: str) -> None:
        """星尘：声音越大冒得越多；用完自己会飘走、变小、消失。"""
        import random

        a = strip.getchannel("A")
        box = a.getbbox()
        if self.perf == "eco":
            return
        # 生成：只在"有声音"的时候冒
        want = int(level * t * 2.2)
        for _ in range(max(0, min(3, want))):
            if len(self._sparks) >= 46 or box is None:
                break
            px = random.randint(box[0], max(box[0], box[2] - 1))
            self._sparks.append({
                "x": x + px, "y": y + random.uniform(box[1], box[3]),
                "vx": random.uniform(-14, 14), "vy": random.uniform(-34, -14),
                "life": 1.0, "r": random.uniform(0.8, 1.9), "hue": random.random(),
            })
        if not self._sparks:
            return
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        alive = []
        for p in self._sparks:
            p["life"] -= self.dt * 1.15
            if p["life"] <= 0:
                continue
            p["x"] += p["vx"] * self.dt
            p["y"] += p["vy"] * self.dt
            p["vy"] += 26 * self.dt                 # 稍微减速，像真的飘上去
            fade = p["life"] ** 1.6
            col = mix(color, "#ffffff", 0.25 + 0.5 * p["hue"])
            r, g, b = rgb(col)
            rad = p["r"] * (0.6 + 0.8 * fade)
            d.ellipse([p["x"] - rad, p["y"] - rad, p["x"] + rad, p["y"] + rad],
                      fill=(r, g, b, int(200 * fade)))
            alive.append(p)
        self._sparks = alive[-46:]
        layer = layer.filter(ImageFilter.GaussianBlur(1.1))
        im.paste(Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB"), (0, 0))

    def render_voice(self, width: int, height: int, level: float, t: float,
                     thick: float, color: str) -> Image.Image:
        """按当前样式把声音条画到一张小图上（2 倍超采样 + 柔光）。"""
        width = max(12, width)
        scale = 2
        strip = Image.new("RGBA", (width * scale, height * scale), (0, 0, 0, 0))
        d = ImageDraw.Draw(strip)
        mid = height * scale / 2
        amp = (1.0 + level * (height / 2 - 3)) * scale * (0.35 + 0.65 * t)

        if self.wave_style == "bars":
            count = max(3, min(56, int(width / 7)))
            step = (width * scale) / count
            bar_w = max(2.0 * scale, step * 0.42)
            max_h = max(4.0, height - 2) * scale
            if len(self.bar_heights) != count:
                self.bar_heights = [0.0] * count
            for i in range(count):
                c = (i - (count - 1) / 2) / max(1.0, (count - 1) / 2)
                bulge = 0.18 + 0.82 * math.cos(c * 1.15) ** 2
                wobble = 0.5 + 0.5 * math.sin(self.wave_phase * 1.7 + i * 0.55)
                target = (2.0 + level * (max_h / scale - 2) * bulge * wobble) * scale
                self.bar_heights[i] += (target - self.bar_heights[i]) * 0.25
                bar_h = max(2.4 * scale, self.bar_heights[i])
                x0 = i * step + (step - bar_w) / 2
                d.rounded_rectangle([x0, height * scale - bar_h, x0 + bar_w, height * scale],
                                    radius=bar_w / 2, fill=color)
            return self._glow(strip, t).resize((width, height), Image.LANCZOS)

        # 一条中心线 + 沿线变化的厚度，用多边形填充：
        # t=0 时厚度剖面是中间鼓起的圆点，t=1 时变成两端收窄的细带，中间过程连续变形。
        total = width * scale
        count = max(12, min(160, total // 2))
        pts = []
        for i in range(count + 1):
            u = i / count
            env = math.sin(math.pi * u) ** 0.55                 # 两端收窄
            ph = self.wave_phase
            wob = (math.sin(u * 7.6 - ph * 1.35) * 0.72
                   + math.sin(u * 13.9 + ph * 2.05) * 0.28)
            cy = mid - env * amp * wob
            bump = math.sin(math.pi * u) ** 0.45                 # 圆点的"鼓包"
            half = (thick * scale / 2) * ((1 - t) * bump + t * max(0.18, env))
            pts.append((u * total, cy, max(0.7 * scale, half)))
        poly = [(x, cy - hw) for x, cy, hw in pts] + \
               [(x, cy + hw) for x, cy, hw in reversed(pts)]
        d.polygon(poly, fill=color)
        return self._glow(strip, t).resize((width, height), Image.LANCZOS)

    def _glow(self, strip: Image.Image, t: float) -> Image.Image:
        """（留着这个函数名，实际不在这儿加光了。）

        光晕改成在整块画布上画（见 _draw_shape_glow）—— 这里是声音条自己的小图，
        光一冒出边界就被裁掉，长条外面根本看不到光。
        """
        return strip
