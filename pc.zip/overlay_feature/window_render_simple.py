# -*- coding: utf-8 -*-
"""Rendering for the edge-docked compact strip."""
from __future__ import annotations

import math
import random

from overlay_feature.window_support import (
    Image,
    ImageDraw,
    ImageFilter,
    mix,
    rgb,
)


class SimpleRenderMixin:
    def draw_simple(self, image, draw, wave_color: str) -> None:
        width, height = image.size
        vertical = self.snap_edge in ("left", "right")
        draw.rounded_rectangle(
            [0, 0, width - 1, height - 1],
            radius=min(width, height) // 2,
            fill=self.panel_color,
        )
        level = max(0.0, min(1.0, self.level_shown))
        wobble = 0.5 + 0.5 * math.sin(self.wave_phase * 1.2)
        fraction = 0.22 + 0.70 * min(
            1.0,
            level * (0.55 + 0.45 * wobble) + level * 0.35,
        )
        thickness = max(2.0, min(width, height) * 0.40)
        desired = (
            0.5
            + (level - 0.35)
            * 0.40
            * math.sin(self.wave_phase * 0.62)
        )
        desired = min(0.86, max(0.14, desired))
        position = getattr(self, "_strip_pos", 0.5)
        self._strip_pos = position + (desired - position) * 0.16
        effects = {key: bool(value) for key, value in self.fx.items()}
        if self.perf == "eco" or getattr(self, "_auto_low", False):
            effects = {key: False for key in effects}

        def box_for(
            scale: float,
            extra: float = 0.0,
            pos: float | None = None,
        ) -> list:
            size = thickness + extra
            center = self._strip_pos if pos is None else pos
            if vertical:
                span = max(6.0, (height - 14) * scale)
                middle = 7 + (height - 14) * center
                y0 = min(
                    max(4.0, middle - span / 2),
                    height - 4 - span,
                )
                return [
                    width / 2 - size / 2,
                    y0,
                    width / 2 + size / 2,
                    y0 + span,
                ]
            span = max(6.0, (width - 14) * scale)
            middle = 7 + (width - 14) * center
            x0 = min(
                max(4.0, middle - span / 2),
                width - 4 - span,
            )
            return [
                x0,
                height / 2 - size / 2,
                x0 + span,
                height / 2 + size / 2,
            ]

        if effects.get("fx_trail"):
            for index, (old_fraction, old_position) in enumerate(
                getattr(self, "_strip_hist", [])[-3:]
            ):
                draw.rounded_rectangle(
                    box_for(old_fraction, 1.0, old_position),
                    radius=int(thickness // 2) + 1,
                    fill=mix(
                        self.panel_color,
                        wave_color,
                        0.16 + 0.12 * index,
                    ),
                )
        self._strip_hist = (
            getattr(self, "_strip_hist", [])
            + [(fraction, self._strip_pos)]
        )[-4:]
        if effects.get("fx_reflection"):
            gap = thickness * 0.95
            segment = box_for(fraction, -thickness * 0.62)
            if vertical:
                segment = [
                    segment[0] + gap,
                    segment[1],
                    segment[2] + gap,
                    segment[3],
                ]
            else:
                segment = [
                    segment[0],
                    segment[1] + gap,
                    segment[2],
                    segment[3] + gap,
                ]
            draw.rounded_rectangle(
                segment,
                radius=int(max(1, thickness // 3)),
                fill=mix(self.panel_color, wave_color, 0.34),
            )
        if effects.get("fx_glow") and level > 0.06:
            halo = Image.new("RGBA", image.size, (0, 0, 0, 0))
            halo_draw = ImageDraw.Draw(halo)
            halo_draw.rounded_rectangle(
                box_for(fraction, thickness * 0.6),
                radius=int(thickness),
                fill=rgb(wave_color) + (int(60 + 70 * level),),
            )
            halo = halo.filter(ImageFilter.GaussianBlur(3.0))
            image.paste(
                Image.alpha_composite(
                    image.convert("RGBA"),
                    halo,
                ).convert("RGB"),
                (0, 0),
            )
            draw = ImageDraw.Draw(image)
        draw.rounded_rectangle(
            box_for(fraction),
            radius=int(max(1, thickness // 2)),
            fill=wave_color,
        )
        if effects.get("fx_sweep"):
            segment = box_for(fraction)
            sweep = (self._sweep_pos * 1.6) % 1.0
            length = (
                max(4.0, (segment[3] - segment[1]) * 0.22)
                if vertical
                else max(4.0, (segment[2] - segment[0]) * 0.22)
            )
            if vertical:
                y0 = (
                    segment[1]
                    + (segment[3] - segment[1] - length) * sweep
                )
                box = [segment[0], y0, segment[2], y0 + length]
            else:
                x0 = (
                    segment[0]
                    + (segment[2] - segment[0] - length) * sweep
                )
                box = [x0, segment[1], x0 + length, segment[3]]
            draw.rounded_rectangle(
                box,
                radius=int(max(1, thickness // 3)),
                fill=mix(wave_color, "#ffffff", 0.55),
            )
        if effects.get("fx_sparkles") and level > 0.15:
            sparks = getattr(self, "_strip_sparks", [])
            if len(sparks) < 14 and random.random() < 0.5:
                segment = box_for(fraction)
                if vertical:
                    sparks.append(
                        [
                            width / 2 + random.uniform(-thickness, thickness),
                            random.choice([segment[1], segment[3]]),
                            random.uniform(-0.5, 0.5),
                            random.uniform(-1.4, 1.4),
                            1.0,
                        ]
                    )
                else:
                    sparks.append(
                        [
                            random.choice([segment[0], segment[2]]),
                            height / 2 + random.uniform(-thickness, thickness),
                            random.uniform(-1.4, 1.4),
                            random.uniform(-0.5, 0.5),
                            1.0,
                        ]
                    )
            alive = []
            for sx, sy, vx, vy, life in sparks:
                life -= 0.06
                if life <= 0:
                    continue
                sx, sy = sx + vx, sy + vy
                radius = 1.4 * life
                draw.ellipse(
                    [sx - radius, sy - radius, sx + radius, sy + radius],
                    fill=mix(wave_color, "#ffffff", 0.5 * life),
                )
                alive.append([sx, sy, vx, vy, life])
            self._strip_sparks = alive[-14:]
        edge_line = {
            "left": [(1, 4), (1, height - 4)],
            "right": [(width - 2, 4), (width - 2, height - 4)],
            "top": [(4, 1), (width - 4, 1)],
            "bottom": [(4, height - 2), (width - 4, height - 2)],
        }
        if self.snap_edge in edge_line:
            start, end = edge_line[self.snap_edge]
            draw.line([start, end], fill=wave_color, width=1)
