# -*- coding: utf-8 -*-
"""Text, voice, style and sizing interactions for the settings overlay."""
from __future__ import annotations

import subprocess
import threading
from pathlib import Path

from overlay_feature.defaults import CARD, VOICES
from overlay_feature import panel_controls as _controls


HERE = Path(__file__).resolve().parent.parent


class OverlaySettingsAppearanceMixin:
    def _entry(self, parent, label, value, multiline: bool = False):
        """One text setting that opens a normal editor dialog when clicked."""
        def open_editor():
            self._overlay_inputlog(f"点击「{label}」按钮")
            self.edit_text(
                label,
                variable.get(),
                lambda text: variable.set(text),
                multiline=multiline,
            )

        variable = _controls.text_field(
            self.tk,
            parent,
            label,
            value,
            open_editor,
            self.on_change,
        )
        return variable

    def edit_text(self, title: str, initial: str, on_ok=None, multiline: bool = False) -> None:
        """Open a normal titled editor so keyboard focus remains reliable."""
        _controls.text_dialog(
            self.tk,
            self.root,
            title,
            initial,
            multiline=multiline,
            button_color=self.button_color,
            on_ok=on_ok,
            on_editing=self.set_editing,
            on_touch=lambda value: setattr(self, "edit_touch", value),
        )

    def set_autostart(self, value: bool) -> None:
        script = HERE / "autostart.ps1"
        if script.exists():
            subprocess.Popen(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                    "-AppDir",
                    str(HERE),
                    "-Action",
                    "on" if value else "off",
                ],
                creationflags=0x08000000,
            )
        self.flash("开机自启：" + ("开" if value else "关"))

    def set_wave_style(self, value: str) -> None:
        self.wave_style_value = value
        self.wave_style = value
        self.refresh_style_chips()
        self.on_change()

    def set_perf(self, value: str) -> None:
        self.perf_value = value
        self.perf = value
        self.refresh_perf_chips()
        if value == "eco":
            self.sl_anim.set(20)
        elif value == "quality":
            self.sl_anim.set(60)
        self.on_change()

    def refresh_perf_chips(self) -> None:
        for value, chip in getattr(self, "perf_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.perf_value else CARD,
                fg="#ffffff",
            )

    def set_name_freq(self, value: str) -> None:
        self.name_freq_value = value
        self.refresh_name_freq()
        self.on_change()

    def refresh_name_freq(self) -> None:
        for value, chip in getattr(self, "name_freq_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.name_freq_value else CARD,
                fg="#ffffff",
            )

    def set_self_freq(self, value: str) -> None:
        self.self_freq_value = value
        self.refresh_self_freq()
        self.on_change()

    def refresh_self_freq(self) -> None:
        for value, chip in getattr(self, "self_freq_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.self_freq_value else CARD,
                fg="#ffffff",
            )

    def refresh_style_chips(self) -> None:
        for value, chip in getattr(self, "style_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.wave_style_value else CARD,
                fg="#ffffff",
            )

    def pick_bg(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="选一张背景图",
            filetypes=[
                ("图片", "*.png *.jpg *.jpeg *.webp *.bmp"),
                ("全部", "*.*"),
            ],
        )
        if path:
            self.set_bg(path)

    def set_bg(self, path: str) -> None:
        self.bg_path = path
        self.bg_label.config(text=Path(path).name if path else "无")
        self.on_change()

    def _rate_value(self, rate) -> float:
        try:
            return float(str(rate or "+8%").replace("%", "").replace("+", ""))
        except Exception:
            return 8.0

    def _voice_index(self) -> int:
        # Prefer the preset index because one Edge voice may have variants.
        try:
            idx = int(self.cfg.get("voice_preset") or -1)
            if 0 <= idx < len(VOICES):
                return idx
        except Exception:
            pass
        current = self.cfg.get("voice") or VOICES[0][0]
        for i, entry in enumerate(VOICES):
            value = entry[0]
            if value == current:
                return i
        return 0

    def _voice_text(self) -> str:
        return VOICES[self.voice_index][1]

    def apply_size(self, *_a) -> None:
        """Resize immediately while keeping panel geometry consistent."""
        try:
            self.W = int(self.sl_width.get())
            self.H = int(self.sl_height.get())
        except Exception:
            return
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + self.PANEL_H
        self._base = None
        self._base_key = None
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        try:
            self.root.geometry(
                f"{int(self.compact_w)}x{int(self.header_h)}+"
                f"{int(self.base_x)}+{int(self.base_y)}"
            )
        except Exception:
            pass
        self.on_change()

    def cycle_voice(self, step: int) -> None:
        self.voice_index = (self.voice_index + step) % len(VOICES)
        self.voice_label.config(text=self._voice_text())
        self.on_change()

    def preview_voice(self, idx: int | None = None) -> None:
        """Preview a voice without blocking the overlay event loop."""
        if idx is not None:
            self.select_voice(int(idx))
        voice, label, pitch, fx = VOICES[self.voice_index]
        label = label.split(" · ")[0]
        volume, rate = int(self.sl_volume.get()), int(self.sl_rate.get())

        def run() -> None:
            try:
                import say

                text = f"你好，我是{label}。以后就用这个声音跟你说话。"
                if say.is_clone(voice):
                    got = say.clone_audio(text, voice, f"{rate:+d}%")
                    if got is None:
                        self.root.after(
                            0,
                            lambda: self.flash("克隆音色这会儿用不了，看日志"),
                        )
                        return
                    audio, sr = got
                    if volume < 100:
                        audio = audio * max(0.0, min(1.0, volume / 100))
                    say.play(audio, sr)
                    return
                say.PITCH[0] = pitch
                mp3 = say.edge_mp3(text, voice, f"{rate:+d}%")
                audio, sr = say.decode_audio(mp3)
                audio = say.apply_fx(audio, sr, fx)
                if volume < 100:
                    audio = audio * max(0.0, min(1.0, volume / 100))
                say.play(audio, sr)
            except Exception as exc:  # noqa: BLE001
                why = str(exc)[:24]
                self.root.after(
                    0,
                    lambda w=why: self.flash(f"试听失败：{w}"),
                )

        threading.Thread(target=run, daemon=True).start()
