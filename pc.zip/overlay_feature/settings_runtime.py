# -*- coding: utf-8 -*-
"""Normalize overlay settings and watch the config file independently."""
from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from overlay_feature.defaults import DEFAULTS, FX_KEYS
from overlay_feature.runtime import safe_color

DEFAULT_ALPHA = 0.98
MIN_ALPHA, MAX_ALPHA = 0.35, 1.0
CONFIG_POLL_SECONDS = 0.3


def config_value(
    config: Mapping[str, Any],
    key: str,
    defaults: Mapping[str, Any] = DEFAULTS,
) -> Any:
    """Read one setting while preserving the historical default fallback."""
    return config.get(key, defaults.get(key))


@dataclass(frozen=True)
class OverlaySettingsState:
    """Validated presentation values applied to the overlay process."""

    name: str
    panel_color: str
    accent: str
    button_color: str
    text_color: str
    talk_color: str
    bg_image: str
    bg_dim: int
    alpha: float
    W: int
    H: int
    show_name: bool
    show_status: bool
    show_line: bool
    show_switch: bool
    line_follow: bool
    wave_style: str
    fx: dict[str, bool]
    show_caption: bool
    caption_on: bool
    mood_on: bool
    mood_idle: bool
    spectrum_on: bool
    karaoke_on: bool
    big_on: bool
    big_size: int
    rec_on: bool
    snap_on: bool
    perf: str
    fps: int
    frame_ms: int
    auto_tune: bool
    layout: dict[str, tuple[int, ...]]

    def as_attributes(self) -> dict[str, Any]:
        """Return a fresh attribute mapping for the live overlay object."""
        values = {
            field: getattr(self, field)
            for field in self.__dataclass_fields__
        }
        values["fx"] = dict(self.fx)
        values["layout"] = dict(self.layout)
        return values

    def apply_to(self, target: Any) -> None:
        """Apply validated state without leaving normalization in ``overlay``."""
        for name, value in self.as_attributes().items():
            setattr(target, name, value)


def build_overlay_settings(
    config: Mapping[str, Any],
    defaults: Mapping[str, Any] = DEFAULTS,
) -> OverlaySettingsState:
    """Convert user-editable JSON into a safe runtime presentation state."""
    c = config
    alpha = float(c.get("overlay_alpha") or DEFAULT_ALPHA)
    fps = max(15, min(60, int(c.get("anim_fps") or 60)))
    perf = str(c.get("perf_mode") or "quality")
    if perf == "eco":
        fps = min(fps, 20)
    elif perf == "standard":
        fps = min(fps, 40)

    return OverlaySettingsState(
        name=str(c.get("name") or defaults["name"]),
        panel_color=safe_color(
            c.get("overlay_color"), defaults["overlay_color"]
        ),
        accent=safe_color(
            c.get("overlay_accent"), defaults["overlay_accent"]
        ),
        button_color=safe_color(
            c.get("overlay_button"), defaults["overlay_button"]
        ),
        text_color=safe_color(
            c.get("overlay_text"), defaults["overlay_text"]
        ),
        talk_color=safe_color(
            c.get("overlay_talk_color"), defaults["overlay_talk_color"]
        ),
        bg_image=str(c.get("overlay_bg_image") or ""),
        bg_dim=int(c.get("overlay_bg_dim") or defaults["overlay_bg_dim"]),
        alpha=min(MAX_ALPHA, max(MIN_ALPHA, alpha)),
        W=int(c.get("overlay_width") or defaults["overlay_width"]),
        H=int(c.get("overlay_height") or defaults["overlay_height"]),
        show_name=bool(c.get("overlay_show_name", True)),
        show_status=bool(c.get("overlay_show_status", True)),
        show_line=bool(c.get("overlay_show_line", True)),
        show_switch=bool(c.get("overlay_show_switch", True)),
        line_follow=bool(c.get("overlay_line_follow_state", False)),
        wave_style=str(c.get("overlay_wave_style") or "siri"),
        fx={key: bool(c.get(key, defaults[key])) for key in FX_KEYS},
        show_caption=bool(c.get("overlay_show_caption", True)),
        caption_on=bool(c.get("caption_enabled", True)),
        mood_on=bool(c.get("mood_enabled", True)),
        mood_idle=bool(c.get("mood_idle", True)),
        spectrum_on=bool(c.get("wave_spectrum", False)),
        karaoke_on=bool(c.get("karaoke", True)),
        big_on=bool(c.get("big_caption", False)),
        big_size=max(16, min(72, int(c.get("big_caption_size") or 34))),
        rec_on=bool(c.get("rec_indicator", True)),
        snap_on=bool(c.get("snap_edges", True)),
        perf=perf,
        fps=fps,
        frame_ms=max(8, int(1000 / fps)),
        auto_tune=bool(c.get("auto_tune", True)),
        layout={
            "name": (
                int(config_value(c, "ov_name_x", defaults)),
                int(config_value(c, "ov_name_y", defaults)),
                int(config_value(c, "ov_name_size", defaults)),
            ),
            "status": (
                int(config_value(c, "ov_status_x", defaults)),
                int(config_value(c, "ov_status_y", defaults)),
                int(config_value(c, "ov_status_size", defaults)),
            ),
            "switch": (
                int(config_value(c, "ov_switch_x", defaults)),
                int(config_value(c, "ov_switch_y", defaults)),
            ),
            "wave": (
                int(config_value(c, "ov_wave_y", defaults)),
                int(config_value(c, "ov_wave_h", defaults)),
            ),
        },
    )


class OverlayConfigWatcher:
    """Load the config initially and notice later writes without duplicate I/O."""

    def __init__(
        self,
        *,
        path_provider: Callable[[], Path],
        loader: Callable[[], dict],
        clock: Callable[[], float] = time.time,
        stat_mtime: Callable[[Path], float | None] | None = None,
        throttle_seconds: float = CONFIG_POLL_SECONDS,
    ) -> None:
        self._path_provider = path_provider
        self._loader = loader
        self._clock = clock
        self._stat_mtime = stat_mtime or self._read_mtime
        self._throttle_seconds = throttle_seconds
        self._mtime = 0.0
        self._next_poll = 0.0

    @staticmethod
    def _read_mtime(path: Path) -> float | None:
        try:
            return path.stat().st_mtime
        except OSError:
            return None

    @property
    def mtime(self) -> float:
        return self._mtime

    @property
    def next_poll(self) -> float:
        return self._next_poll

    def set_mtime(self, value: float) -> None:
        """Keep direct writes from settings mixins from causing a self-reload."""
        self._mtime = float(value)
        self._next_poll = 0.0

    def load_initial(self) -> dict:
        data = self._loader()
        mtime = self._stat_mtime(self._path_provider())
        self._mtime = float(mtime or 0.0)
        self._next_poll = 0.0
        return data

    def poll(self) -> dict | None:
        """Return new config once; throttle unchanged files and repeated probes."""
        now = self._clock()
        if now < self._next_poll:
            return None
        self._next_poll = now + self._throttle_seconds
        mtime = self._stat_mtime(self._path_provider())
        if mtime is None or mtime == self._mtime:
            return None
        self._mtime = float(mtime)
        return self._loader()


__all__ = [
    "CONFIG_POLL_SECONDS",
    "DEFAULT_ALPHA",
    "MAX_ALPHA",
    "MIN_ALPHA",
    "OverlayConfigWatcher",
    "OverlaySettingsState",
    "build_overlay_settings",
    "config_value",
]
