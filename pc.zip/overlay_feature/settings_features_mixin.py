# -*- coding: utf-8 -*-
"""Reminder, shortcut and feature toggles for the overlay settings page."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsFeaturesMixin:
    def build_features(self, parent) -> None:
        """Build the feature page while keeping every existing widget name."""
        self.build_reminders(parent)

        self._group(parent, "好玩的功能")
        self.tk.Label(
            parent,
            text="",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        self.sw_caption = self._switch_row(
            parent, "实时字幕", bool(self.cfg.get("caption_enabled", True))
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 2))
        self.tk.Label(
            row,
            text="没说完就先出半截字（会多占一点显卡）",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")
        self.sw_mood = self._switch_row(
            parent, "语气反应", bool(self.cfg.get("mood_enabled", True))
        )
        self.sw_sleepy = self._switch_row(
            parent, "悬浮窗养成", bool(self.cfg.get("mood_idle", True))
        )
        self.sw_spectrum = self._switch_row(
            parent, "音浪模式", bool(self.cfg.get("wave_spectrum", False))
        )
        self.sw_karaoke = self._switch_row(
            parent, "逐字跟读", bool(self.cfg.get("karaoke", True))
        )
        self.sw_diary = self._switch_row(
            parent, "睡前日记", bool(self.cfg.get("diary_enabled", True))
        )
        self.sw_notheard = self._switch_row(
            parent, "没听清时说一声", bool(self.cfg.get("not_heard_reply", True))
        )
        self.sw_big = self._switch_row(
            parent, "大字幕", bool(self.cfg.get("big_caption", False))
        )
        self.sw_shot = self._switch_row(
            parent, "看屏幕截图", bool(self.cfg.get("screenshot_enabled", True))
        )
        self.sw_share = self._switch_row(
            parent, "屏幕发手机", bool(self.cfg.get("screen_share", True))
        )
        self.sw_chime = self._switch_row(
            parent, "整点报时", bool(self.cfg.get("hourly_chime", False))
        )
        self.sw_sit = self._switch_row(
            parent, "久坐提醒", bool(self.cfg.get("sit_reminder", True))
        )
        self.sw_meeting = self._switch_row(
            parent, "开会自动闭嘴", bool(self.cfg.get("meeting_mute", True))
        )
        self.sw_hotkey = self._switch_row(
            parent, "朗读选中(Ctrl+Alt+R)", bool(self.cfg.get("read_hotkey", True))
        )
        self.sw_voiceprint = self._switch_row(
            parent, "声纹提示（实验）", bool(self.cfg.get("voiceprint_warn", False))
        )
        self.sw_pet = self._switch_row(
            parent, "桌宠", bool(self.cfg.get("pet_enabled", True))
        )
