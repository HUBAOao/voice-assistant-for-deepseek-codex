# -*- coding: utf-8 -*-
"""Preview, save and reset transitions for the overlay settings panel."""
from __future__ import annotations

import time

from overlay_feature.defaults import DEFAULTS
from overlay_feature import runtime as _runtime


class OverlaySettingsPersistenceMixin:
    """Persist a collected snapshot and keep the live preview in sync."""

    def on_change(self, *_args) -> None:
        if self._push_job is not None:
            try:
                self.root.after_cancel(self._push_job)
            except Exception:
                pass
        self._push_job = self.root.after(120, self.push_now)
        if self.hint_label is not None:
            self.hint_label.config(text="改动即时预览", fg="#7f7f8a")

    def push_now(self) -> None:
        self._push_job = None
        data = self.collect()
        _runtime.write_config(data, _runtime.CONFIG)
        self.cfg = data
        try:
            self.cfg_mtime = _runtime.CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        self.after_wake_word_change(data)

    def after_wake_word_change(self, data: dict) -> None:
        """Run a wake self-check after the wake word actually changes."""
        now_word = str(data.get("wake_word") or "")
        if now_word == getattr(self, "_wake_seen", None):
            return
        first_time = not getattr(self, "_wake_seen", None)
        self._wake_seen = now_word
        if first_time or not now_word.strip():
            return
        if time.time() - self.started < 20:
            return
        self.run_wake_test()

    def save_settings(self) -> None:
        self.push_now()
        self.flash("已保存", 2)
        if self.hint_label is not None:
            self.hint_label.config(text="已保存", fg=self.accent)

    def reset_defaults(self) -> None:
        data = _runtime.load_config(_runtime.CONFIG)
        for key, value in DEFAULTS.items():
            if isinstance(value, dict):
                data[key] = dict(value)
            elif isinstance(value, list):
                data[key] = list(value)
            else:
                data[key] = value
        data.pop("overlay_line_follow_state", None)
        _runtime.write_config(data, _runtime.CONFIG)
        self.cfg = data
        try:
            self.cfg_mtime = _runtime.CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None
            if self.panel_win is not None:
                try:
                    self.panel_win.destroy()
                except Exception:
                    pass
                self.panel_win = None
            self.build_panel()
            self._place_panel(self._expanded_h())
            if self.expanded:
                self._show_panel()
        self.flash("已恢复默认设置", 2.4)
