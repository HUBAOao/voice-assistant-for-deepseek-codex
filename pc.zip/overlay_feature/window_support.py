# -*- coding: utf-8 -*-
"""Shared paths, visual constants, and service adapters for the overlay."""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageTk

from overlay_feature.defaults import (
    ARROW,
    BG_PANEL,
    BORDER,
    CARD,
    COLORS,
    DEFAULTS,
    FX_DOT_KEYS,
    FX_KEYS,
    KNOB,
    LABELS,
    SW_H,
    SW_W,
    VOICES,
)
from overlay_feature import runtime as _runtime
from overlay_feature import window_control as _window_control
from overlay_feature import window_geometry as _geometry
from overlay_feature.runtime import (
    CONFIG,
    CONTROL,
    EXIT_LOG,
    FONT_FILES,
    INPUT_LOG,
    POS,
    READY_FILE,
    SPEAK_STATUS,
    STARTUP_LNK,
    STATUS,
    SYSLOG_FILE,
    WAKE_TEST_FILE,
    font,
    hexs,
    inputlog,
    mix,
    process_alive,
    rgb,
    set_no_activate,
    shade,
    startup_exists,
    virtual_screen,
)
from overlay_feature.settings_runtime import (
    MAX_ALPHA,
    MIN_ALPHA,
    OverlayConfigWatcher,
    build_overlay_settings,
    config_value,
)


FRAME_MS = 16
FADE_SECONDS = 0.24
RESIZE_STEPS = 8
RESIZE_STEP_MS = 8
SIMPLE_STEPS = 6
SNAP_PX = 26
SIMPLE_LONG = 132
SIMPLE_THICK = 20
STATUS_MS = 200
PANEL_H = 452
PANEL_H_OPEN = 560


def load_config() -> dict:
    return _runtime.load_config(CONFIG)


def write_config(data: dict) -> None:
    _runtime.write_config(data, CONFIG)


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


def note(text: str) -> None:
    _runtime.note(text, EXIT_LOG)


def single_instance() -> bool:
    return _runtime.single_instance(READY_FILE)
