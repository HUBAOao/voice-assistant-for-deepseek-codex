# -*- coding: utf-8 -*-
"""Independent settings-panel lifetime and keyboard focus transitions."""
from __future__ import annotations

from overlay_feature import window_control as _window_control
from overlay_feature import window_geometry as _geometry
from overlay_feature.window_support import PANEL_H_OPEN, virtual_screen


class PanelRuntimeMixin:
    def set_expanded(self, value: bool) -> None:
        if value == self.expanded:
            return
        self.expanded = value
        self.allow_keyboard(value)
        if value:
            if self.panel is None:
                self.build_panel()
            self._show_panel()
            self.root.after(120, self._update_scroll_hint)
        else:
            self.set_editing(False)
            self._hide_panel()

    def _expanded_h(self) -> float:
        cap = max(420, self.root.winfo_screenheight() - 200)
        return float(self.header_h + int(min(cap, PANEL_H_OPEN)))

    def _place_panel(self, total_h: float) -> None:
        if self.panel is None:
            return
        height = max(
            1,
            int(round(self._expanded_h() - self.header_h)),
        )
        self.panel.place(
            x=0,
            y=0,
            width=self.expand_w,
            height=height,
        )
        if self.panel_win is not None:
            self.panel_win.geometry(f"{self.expand_w}x{height}")
            self._position_panel_window()
            try:
                self.panel.update_idletasks()
            except Exception:
                pass

    def _position_panel_window(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None or self.panel is None:
            return
        try:
            panel_height = max(
                1,
                int(round(self._expanded_h() - self.header_h)),
            )
            panel_width = int(self.expand_w)
            root_x = self.root.winfo_x()
            root_y = self.root.winfo_y()
            x, y = _geometry.panel_position(
                root_x,
                root_y,
                self.header_h,
                self.compact_w,
                panel_width,
                panel_height,
                virtual_screen(),
                margin=8,
            )
            geometry = (
                f"{panel_width}x{panel_height}+{int(x)}+{int(y)}"
            )
            if geometry != getattr(self, "_panel_geom", ""):
                self._panel_geom = geometry
                win.geometry(geometry)
        except Exception:
            pass

    def _show_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._place_panel(self._expanded_h())
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            win.attributes("-alpha", 0.0)
            win.deiconify()
            win.lift()
            win.attributes("-topmost", True)
        except Exception:
            pass
        target = float(self.alpha_override or self.alpha)
        for index in range(1, 9):
            self.root.after(
                int(12 * index),
                lambda a=target * index / 8, t=token: self._fade_panel_step(
                    t,
                    a,
                    False,
                ),
            )

    def _hide_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            start = float(win.attributes("-alpha") or 0.0)
        except Exception:
            start = 0.0
        for index in range(1, 7):
            last = index == 6
            self.root.after(
                int(12 * index),
                lambda a=start * (1 - index / 6), t=token, h=last:
                self._fade_panel_step(t, a, h),
            )

    def _fade_panel_step(
        self,
        token: int,
        alpha: float,
        hide: bool,
    ) -> None:
        if token != getattr(self, "_panel_fade_token", 0):
            return
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        try:
            win.attributes(
                "-alpha",
                max(0.0, min(1.0, float(alpha))),
            )
            if hide and alpha <= 0.02:
                win.withdraw()
        except Exception:
            pass

    def _repaint_now(self) -> None:
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        panel = getattr(self, "panel", None)
        if panel is not None:
            try:
                panel.update_idletasks()
            except Exception:
                pass
        _window_control.refresh_window_tree(self.root.winfo_id())
        try:
            current = getattr(self, "_alpha_set", None)
            if current is not None:
                self.root.attributes(
                    "-alpha",
                    max(0.05, float(current) - 0.001),
                )
                self.root.attributes("-alpha", float(current))
        except Exception:
            pass

    def _finish_panel_close(self) -> None:
        self._panel_closing = False
        self._hide_panel()
