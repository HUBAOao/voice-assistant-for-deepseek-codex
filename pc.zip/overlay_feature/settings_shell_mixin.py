# -*- coding: utf-8 -*-
"""Build the settings window shell; page business stays in mixins."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL, BORDER
from overlay_feature.settings_footer_mixin import (
    OverlaySettingsFooterMixin,
)
from overlay_feature import runtime as _runtime


def send_command(action: str) -> None:
    _runtime.send_command(action, _runtime.CONTROL)


class OverlaySettingsShellMixin(OverlaySettingsFooterMixin):
    def build_panel(self) -> None:
        import tkinter as tk

        # The compact overlay keeps its native size. The settings window is its
        # own translucent surface, avoiding a full native resize animation.
        if self.panel_win is None:
            win = tk.Toplevel(self.root)
            win.overrideredirect(True)
            win.attributes("-topmost", True)
            win.configure(bg=BG_PANEL)
            try:
                win.attributes("-toolwindow", True)
            except Exception:
                pass
            win.attributes("-alpha", 0.0)
            win.withdraw()
            self.panel_win = win
        panel = tk.Frame(
            self.panel_win,
            bg=BG_PANEL,
            highlightthickness=1,
            highlightbackground=BORDER,
        )
        self.panel = panel
        self.tab_names = ["基本", "声音", "外观", "智能", "功能", "日程"]
        self.tab_frames: dict[str, object] = {}
        self.tab_labels: dict[str, object] = {}

        bar = tk.Frame(panel, bg=BG_PANEL)
        bar.pack(fill="x", padx=8, pady=(8, 4))
        for name in self.tab_names:
            lab = tk.Label(
                bar,
                text=name,
                bg=BG_PANEL,
                fg="#9a9aa5",
                font=("Microsoft YaHei UI", 9),
                padx=10,
                pady=4,
                cursor="hand2",
            )
            lab.pack(side="left", padx=2)
            lab.bind("<Button-1>", lambda _e, n=name: self.show_tab(n))
            self.tab_labels[name] = lab
        self.hint_label = tk.Label(
            bar,
            text="改动即时预览",
            bg=BG_PANEL,
            fg="#5f5f68",
            font=("Microsoft YaHei UI", 8),
        )
        self.hint_label.pack(side="right", padx=6)

        stage = tk.Canvas(
            panel, bg=BG_PANEL, highlightthickness=0, bd=0, takefocus=0
        )
        stage.pack(fill="both", expand=True)
        self.stage = self.stage_canvas = stage
        inner = tk.Frame(stage, bg=BG_PANEL)
        self.stage_inner = inner
        self._stage_win = stage.create_window(
            (0, 0), window=inner, anchor="nw"
        )
        stage.bind("<Configure>", self._on_stage_resize)
        inner.bind("<Configure>", self._on_stage_inner)
        for name in self.tab_names:
            self.tab_frames[name] = tk.Frame(inner, bg=BG_PANEL)

        self.build_basic(self.tab_frames["基本"])
        self.build_sound(self.tab_frames["声音"])
        self.build_look(self.tab_frames["外观"])
        self.build_smart(self.tab_frames["智能"], self.tab_frames["功能"])
        self.build_schedule(self.tab_frames["日程"])

        foot = tk.Frame(panel, bg=BG_PANEL)
        foot.pack(fill="x", padx=10, pady=(4, 10))
        self.build_footer(foot)
        self._bind_wheel_tree(inner)
        self.scroll_hint = tk.Canvas(
            panel, width=4, bg=BG_PANEL, highlightthickness=0, bd=0
        )
        self.show_tab("基本")
