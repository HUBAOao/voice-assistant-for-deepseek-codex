# -*- coding: utf-8 -*-
"""Sending and delivery-mode controls for the settings panel."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsSendMixin:
    """Build the send mode and local delivery switches only."""

    def build_send_controls(self, parent) -> None:
        self._group(parent, "说话方式")
        row = self._row(parent, "触发方式")
        self.input_mode_value = str(
            self.cfg.get("input_mode") or "talk"
        )
        if self.input_mode_value not in ("talk", "hold"):
            self.input_mode_value = "talk"
        self.input_mode_chips = {}
        for value, label in (
            ("talk", "自动对话"),
            ("hold", "按住说话"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_input_mode(current),
            )
            chip.pack(side="left", padx=3)
            self.input_mode_chips[value] = chip
        self.refresh_input_mode_chips()

        row = self._row(parent, "按住键")
        self.hold_key_value = str(self.cfg.get("hold_key") or "*")
        self.hold_key_chips = {}
        for value, label in (
            ("*", "小键盘 *"),
            ("f9", "F9"),
            ("space", "空格"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_hold_key(current),
            )
            chip.pack(side="left", padx=3)
            self.hold_key_chips[value] = chip
        self.refresh_hold_key_chips()
        self.tk.Label(
            parent,
            text="按住时持续收音，松开后识别并发送；切换说话方式后点「重启程序」生效",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(0, 6))

        self._group(parent, "发送")
        row = self._row(parent, "发送方式")
        self.send_mode_value = str(self.cfg.get("send_mode") or "paste_enter")
        self.send_chips = {}
        for value, label in (
            ("paste_enter", "粘贴并回车"),
            ("paste", "只粘贴"),
            ("type", "当打字机"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_send_mode(current),
            )
            chip.pack(side="left", padx=3)
            self.send_chips[value] = chip
        self.refresh_send_chips()
        self.sw_confirm = self._switch_row(
            parent,
            "发之前先问我",
            bool(self.cfg.get("confirm_send", False)),
        )
        self.sw_follow = self._switch_row(
            parent,
            "跟着当前窗口发",
            bool(self.cfg.get("follow_foreground", False)),
        )
        self.sw_readreply = self._switch_row(
            parent,
            "自动念回答",
            bool(self.cfg.get("read_reply", True)),
        )
        self.sw_tray = self._switch_row(
            parent,
            "托盘图标",
            bool(self.cfg.get("tray_enabled", True)),
        )
        self.sw_gate = self._switch_row(
            parent,
            "只认我的声音",
            bool(self.cfg.get("voiceprint_gate", False)),
        )
