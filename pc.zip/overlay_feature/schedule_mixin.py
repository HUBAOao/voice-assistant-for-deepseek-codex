# -*- coding: utf-8 -*-
"""Overlay schedule tab and schedule editor."""
from __future__ import annotations

from schedule_panel import SchedulePanel
from overlay_feature.defaults import BG_PANEL, CARD
from overlay_feature.runtime import grab_foreground


class OverlayScheduleMixin:
    def build_schedule(self, parent) -> None:
        """日程：日历/表格两种视图，全部长在悬浮窗里，不另开窗口。"""
        self.schedule_panel = SchedulePanel(self.tk, parent, self.cfg, self.on_change,
                                            button_color=self.button_color, accent=self.accent)

    def edit_schedules(self) -> None:
        """日程表编辑：一行 = 时间 / 周期 / 要发送的内容。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("编辑 · 日程表")
        win.configure(bg=BG_PANEL)
        win.geometry("700x460")
        win.attributes("-topmost", True)
        tk.Label(win, text="日程表", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(win, text="时间用 24 小时制（如 09:00）；周期填 每天 / 工作日 / 周末 / 周一,周三 / 一三五",
                 bg=BG_PANEL, fg="#8a8a95", font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=14)

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(8, 2))
        for text, width in (("时间", 8), ("周期", 16), ("要发送的内容", 40)):
            tk.Label(head, text=text, bg=BG_PANEL, fg="#8a8a95", width=width, anchor="w",
                     font=("Microsoft YaHei UI", 9)).pack(side="left", padx=2)

        holder = tk.Frame(win, bg=BG_PANEL)
        holder.pack(fill="both", expand=True, padx=14)
        canvas = tk.Canvas(holder, bg=BG_PANEL, highlightthickness=0)
        scroll = tk.Scrollbar(holder, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG_PANEL)
        canvas.create_window((0, 0), window=inner, anchor="nw", width=650)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        rows: list[dict] = []

        def add_row(time_text: str = "09:00", days: str = "每天", body: str = "") -> None:
            row = tk.Frame(inner, bg=BG_PANEL)
            row.pack(fill="x", pady=2)
            var_t = tk.StringVar(value=time_text)
            var_d = tk.StringVar(value=days)
            var_b = tk.StringVar(value=body)
            entry_kw = dict(bg=CARD, fg="#ffffff", insertbackground="#ffffff", relief="flat",
                            font=("Microsoft YaHei UI", 9))
            e1 = tk.Entry(row, textvariable=var_t, width=8, **entry_kw)
            e1.pack(side="left", padx=2, ipady=3)
            e2 = tk.Entry(row, textvariable=var_d, width=16, **entry_kw)
            e2.pack(side="left", padx=2, ipady=3)
            e3 = tk.Entry(row, textvariable=var_b, **entry_kw)
            e3.pack(side="left", fill="x", expand=True, padx=2, ipady=3)
            item = {"t": var_t, "d": var_d, "b": var_b, "frame": row}
            rows.append(item)

            def remove() -> None:
                row.destroy()
                rows.remove(item)

            tk.Label(row, text="✕", bg=BG_PANEL, fg="#ff8080", padx=6, cursor="hand2",
                     font=("Microsoft YaHei UI", 9)).pack(side="left")
            for widget in row.winfo_children():
                if widget["text"] == "✕":
                    widget.bind("<Button-1>", lambda _e: remove())
            return item

        for item in self.schedules:
            add_row(str(item.get("time") or "09:00"), str(item.get("days") or "每天"),
                    str(item.get("text") or ""))
        if not rows:
            add_row()

        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(6, 12))
        tk.Label(bar, text="＋ 添加一行", bg=CARD, fg="#ffffff", padx=12, pady=5,
                 cursor="hand2", font=("Microsoft YaHei UI", 9)).pack(side="left")
        bar.winfo_children()[0].bind("<Button-1>", lambda _e: add_row())

        def confirm() -> None:
            data = []
            for item in rows:
                body = item["b"].get().strip()
                when = item["t"].get().strip()
                if not body or not when:
                    continue
                data.append({"time": when, "days": item["d"].get().strip() or "每天",
                             "text": body, "enabled": True})
            self.schedules = data
            self.schedule_label.config(text=self.schedule_summary())
            self.on_change()
            win.destroy()

        ok = tk.Label(bar, text="保存", bg=self.button_color, fg="#ffffff", padx=22, pady=6,
                      cursor="hand2", font=("Microsoft YaHei UI", 10, "bold"))
        ok.pack(side="right")
        ok.bind("<Button-1>", lambda _e: confirm())
        cancel = tk.Label(bar, text="取消", bg=CARD, fg="#ffffff", padx=16, pady=6,
                          cursor="hand2", font=("Microsoft YaHei UI", 10))
        cancel.pack(side="right", padx=8)
        cancel.bind("<Button-1>", lambda _e: win.destroy())
        try:
            win.lift()
            win.focus_force()
            grab_foreground(win.winfo_id())
        except Exception:
            pass
