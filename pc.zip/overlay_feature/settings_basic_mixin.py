# -*- coding: utf-8 -*-
"""Basic identity, wake-level and caption controls for the settings panel."""
from __future__ import annotations

import version
from overlay_feature.defaults import BG_PANEL, DEFAULTS
from overlay_feature.runtime import startup_exists


class OverlaySettingsBasicMixin:
    """Compose the basic settings page without owning config persistence."""

    def build_basic(self, parent) -> None:
        self.entry_name = self._entry(
            parent,
            "名字",
            self.cfg.get("name") or version.ASSISTANT_NAME,
        )
        self.entry_wake = self._entry(
            parent,
            "唤醒词",
            self.cfg.get("wake_word") or "大肥鱼",
        )
        self.build_wake_level(parent)
        self.entry_greeting = self._entry(
            parent,
            "问候语",
            self.cfg.get("greeting_text") or DEFAULTS["greeting_text"],
            multiline=True,
        )
        self.entry_user = self._entry(
            parent,
            "你的称呼",
            self.cfg.get("user_name") or "",
        )
        row = self._row(parent, "称呼频率")
        self.name_freq_value = str(self.cfg.get("name_freq") or "sometimes")
        self.name_freq_chips = {}
        for value, label in (
            ("off", "从不"),
            ("sometimes", "偶尔"),
            ("often", "经常"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_name_freq(current),
            )
            chip.pack(side="left", padx=3)
            self.name_freq_chips[value] = chip
        self.refresh_name_freq()

        # 应答语可以写多条，一行一条（或 | 隔开），每次随机挑一条。
        self.entry_ack = self._entry(
            parent,
            "应答语",
            self.cfg.get("ack_text") or DEFAULTS["ack_text"],
            multiline=True,
        )
        self.tk.Label(
            parent,
            text="可以写好几条，一行一条；每次随机挑一条说",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 3))
        self.sw_ack = self._switch_row(
            parent,
            "应答语开关",
            bool(self.cfg.get("ack_enabled", True)),
        )
        self.entry_self = self._entry(
            parent,
            "自称",
            self.cfg.get("self_name") or "大肥鱼",
        )
        self.sw_self = self._switch_row(
            parent,
            "自称开关",
            bool(self.cfg.get("self_talk", True)),
        )
        row = self._row(parent, "自称频率")
        self.self_freq_value = str(self.cfg.get("self_freq") or "sometimes")
        self.self_freq_chips = {}
        for value, label in (
            ("off", "从不说"),
            ("sometimes", "有时"),
            ("often", "经常"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_self_freq(current),
            )
            chip.pack(side="left", padx=3)
            self.self_freq_chips[value] = chip
        self.refresh_self_freq()
        self.sw_greeting = self._switch_row(
            parent,
            "开机问候",
            bool(self.cfg.get("greeting_enabled", True)),
        )
        self.sw_autostart = self._switch_row(
            parent,
            "开机自启",
            startup_exists(),
            on_change=self.set_autostart,
        )
        self.sw_restart = self._switch_row(
            parent,
            "崩溃自动重启",
            bool(self.cfg.get("auto_restart", True)),
        )
        row = self._row(parent, "预设")
        self._chip(row, "存为预设", self.save_preset).pack(
            side="right",
            padx=(4, 10),
        )
        self._chip(row, "导出预设", self.export_presets).pack(
            side="right",
            padx=2,
        )
        self._chip(row, "导入预设", self.import_presets).pack(
            side="right",
            padx=2,
        )
        self.preset_bar = self.tk.Frame(parent, bg=BG_PANEL)
        self.preset_bar.pack(fill="x", padx=12, pady=(0, 6))
        self.refresh_presets()
