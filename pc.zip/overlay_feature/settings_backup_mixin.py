# -*- coding: utf-8 -*-
"""Backup, export and diagnostic actions for the settings panel."""
from __future__ import annotations

import os
import re
from pathlib import Path

from overlay_feature import window_control as _window_control
from overlay_feature import runtime as _runtime
from overlay_feature.settings_mixin import send_command


class OverlaySettingsBackupMixin:
    def do_export(self) -> None:
        self.flash("正在打包数据…（会藏进「导出」文件夹）", 2.5)
        send_command("export")
        self.root.after(1600, self.refresh_backup_label)

    def do_import(self) -> None:
        self.flash("正在导入最新的导出包…", 2.5)
        send_command("import")

    def backup_dir(self) -> Path:
        """Keep archives in the hidden export directory."""
        folder = _runtime.CONFIG.parent / "导出"
        try:
            folder.mkdir(parents=True, exist_ok=True)
            _window_control.hide_path(folder)
            return folder
        except Exception:
            return _runtime.CONFIG.parent

    def backup_summary(self) -> str:
        folder = self.backup_dir()
        packs = sorted(
            list(folder.glob("语音助手数据-*.zip"))
            + list(folder.glob("语音助手诊断-*.zip"))
        )
        if not packs:
            return "还没有导出 / 诊断包 · 都藏在这个文件夹里，不往桌面上扔"
        bits = []
        for path in packs[-3:][::-1]:
            match = re.match(
                r"语音助手(数据|诊断)-(\d{8})-(\d{4})(?:-\d+)?\.zip$",
                path.name,
            )
            try:
                kb = path.stat().st_size / 1024
            except OSError:
                kb = 0
            if match:
                kind = match.group(1)
                when = (
                    f"{match.group(2)[4:6]}/{match.group(2)[6:8]} "
                    f"{match.group(3)[:2]}:{match.group(3)[2:]}"
                )
                bits.append(f"{kind} {when}（{kb:.0f}KB）")
            else:
                bits.append(f"{path.name}（{kb:.0f}KB）")
        more = f" · 共 {len(packs)} 个" if len(packs) > 3 else ""
        return "最新：" + "、".join(bits) + more + " · 藏在程序目录的「导出」里"

    def do_diagnose(self) -> None:
        self.flash("正在打包诊断…（会藏进「导出」文件夹）", 2.5)
        send_command("diagnose")
        self.root.after(1600, self.refresh_backup_label)

    def refresh_backup_label(self) -> None:
        label = getattr(self, "backup_label", None)
        if label is None:
            return
        try:
            label.config(text=self.backup_summary())
        except Exception:
            pass

    def open_backup_dir(self) -> None:
        folder = self.backup_dir()
        try:
            os.startfile(str(folder))
        except Exception:
            self.flash(f"打不开：{folder}", 3)
