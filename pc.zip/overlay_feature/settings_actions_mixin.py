# -*- coding: utf-8 -*-
"""Compatibility entrypoint for settings collection and persistence."""
from __future__ import annotations

from overlay_feature.settings_collect_mixin import OverlaySettingsCollectMixin
from overlay_feature.settings_persistence_mixin import (
    OverlaySettingsPersistenceMixin,
)


class OverlaySettingsActionsMixin(
    OverlaySettingsCollectMixin,
    OverlaySettingsPersistenceMixin,
):
    """Keep the historical mixin import while the two duties stay separate."""
