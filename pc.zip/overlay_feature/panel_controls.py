"""Reusable Tk control builders for the FinDeck settings panel."""

from __future__ import annotations

from typing import Callable

from overlay_feature.defaults import BG_PANEL, BORDER, CARD


def group(tk, parent, title: str, accent: str) -> None:
    bar = tk.Frame(parent, bg=BG_PANEL)
    bar.pack(fill="x", padx=14, pady=(12, 4))
    tk.Label(
        bar,
        text=title,
        bg=BG_PANEL,
        fg=accent,
        font=("Microsoft YaHei UI", 9, "bold"),
    ).pack(side="left")
    tk.Frame(bar, bg=BORDER, height=1).pack(
        side="left", fill="x", expand=True, padx=(8, 0)
    )


def row(tk, parent, label: str):
    result = tk.Frame(parent, bg=BG_PANEL)
    result.pack(fill="x", pady=3)
    tk.Label(
        result,
        text=label,
        bg=BG_PANEL,
        fg="#ffffff",
        width=12,
        anchor="w",
        font=("Microsoft YaHei UI", 9),
    ).pack(side="left", padx=(10, 4))
    return result


def chip(tk, parent, text: str, command: Callable[[], object]):
    result = tk.Label(
        parent,
        text=text,
        bg=CARD,
        fg="#ffffff",
        font=("Microsoft YaHei UI", 9),
        padx=10,
        pady=3,
        cursor="hand2",
    )
    result.bind("<Button-1>", lambda _event: command())
    return result


def switch_row(tk, parent, label: str, value, on_change, switch_factory):
    line = row(tk, parent, label)
    switch = switch_factory(line, bool(value), on_change, bg=BG_PANEL)
    switch.canvas.pack(side="right", padx=(0, 10))
    return switch


def swatch(tk, parent, label: str, color: str, on_change):
    cell = tk.Frame(parent, bg=BG_PANEL)
    cell.pack(side="left", padx=(0, 8))
    tk.Label(
        cell,
        text=label,
        bg=BG_PANEL,
        fg="#9a9aa5",
        font=("Microsoft YaHei UI", 8),
    ).pack(side="left", padx=(0, 2))
    canvas = tk.Canvas(
        cell,
        width=26,
        height=16,
        bg=BG_PANEL,
        highlightthickness=0,
        cursor="hand2",
    )
    canvas.pack(side="left")
    rectangle = canvas.create_rectangle(1, 1, 25, 15, fill=color, outline="#55555f")

    def choose(_event=None):
        from tkinter import colorchooser

        _rgb, picked = colorchooser.askcolor(
            color=canvas.itemcget(rectangle, "fill")
        )
        if picked:
            canvas.itemconfig(rectangle, fill=picked)
            on_change()

    canvas.bind("<Button-1>", choose)
    return canvas, rectangle


def text_field(
    tk,
    parent,
    label: str,
    value,
    on_open: Callable[[], object],
    on_change: Callable[[], object] | None = None,
):
    line = row(tk, parent, label)
    variable = tk.StringVar(value=str(value))

    def shown(text) -> str:
        one = " ".join(str(text or "").split())
        if not one:
            return "（点这里设置）"
        one = one.replace("|", " ／ ")
        return one if len(one) <= 26 else one[:25] + "…"

    button = tk.Label(
        line,
        text=shown(variable.get()),
        bg=CARD,
        fg="#ffffff",
        font=("Microsoft YaHei UI", 9),
        padx=10,
        pady=4,
        cursor="hand2",
        anchor="w",
        justify="left",
        highlightthickness=1,
        highlightbackground=BORDER,
    )
    button.pack(side="left", fill="x", expand=True, padx=(0, 10))
    button.bind("<Button-1>", lambda _event: on_open())
    button.bind("<Enter>", lambda _e: button.config(bg="#2c2c36"))
    button.bind("<Leave>", lambda _e: button.config(bg=CARD))

    def sync(*_args):
        button.config(text=shown(variable.get()))
        if on_change is not None:
            on_change()

    variable.trace_add("write", sync)
    return variable


def text_dialog(
    tk,
    root,
    title: str,
    initial: str,
    *,
    multiline: bool,
    button_color: str,
    on_ok,
    on_editing: Callable[[bool], object],
    on_touch: Callable[[float], object],
) -> None:
    import time

    win = tk.Toplevel(root)
    win.title(f"编辑 · {title}")
    win.configure(bg=BG_PANEL)
    win.attributes("-topmost", True)
    win.geometry("440x190" if multiline else "440x150")
    win.resizable(False, False)
    tk.Label(
        win,
        text=title,
        bg=BG_PANEL,
        fg="#ffffff",
        font=("Microsoft YaHei UI", 10, "bold"),
    ).pack(anchor="w", padx=14, pady=(12, 2))
    variable = tk.StringVar(value=initial)
    if multiline:
        box = tk.Text(
            win,
            height=3,
            bg=CARD,
            fg="#ffffff",
            insertbackground="#ffffff",
            relief="flat",
            wrap="word",
            font=("Microsoft YaHei UI", 10),
        )
        box.insert("1.0", initial)
        box.pack(fill="both", expand=True, padx=14, pady=6)
    else:
        box = tk.Entry(
            win,
            textvariable=variable,
            bg=CARD,
            fg="#ffffff",
            insertbackground="#ffffff",
            relief="flat",
            font=("Microsoft YaHei UI", 11),
        )
        box.pack(fill="x", padx=14, pady=10, ipady=6)
    bar = tk.Frame(win, bg=BG_PANEL)
    bar.pack(fill="x", padx=14, pady=(2, 12))

    def close() -> None:
        on_editing(False)
        win.destroy()

    def confirm() -> None:
        text = (
            box.get("1.0", "end").strip()
            if multiline else variable.get()
        ).strip()
        if on_ok:
            on_ok(text)
        close()

    ok = tk.Label(
        bar,
        text="确定",
        bg=button_color,
        fg="#ffffff",
        font=("Microsoft YaHei UI", 10, "bold"),
        padx=20,
        pady=6,
        cursor="hand2",
    )
    ok.pack(side="right")
    ok.bind("<Button-1>", lambda _event: confirm())
    cancel = tk.Label(
        bar,
        text="取消",
        bg=CARD,
        fg="#ffffff",
        font=("Microsoft YaHei UI", 10),
        padx=16,
        pady=6,
        cursor="hand2",
    )
    cancel.pack(side="right", padx=8)
    cancel.bind("<Button-1>", lambda _event: close())
    win.bind("<Return>", lambda _event: confirm())
    win.bind("<Escape>", lambda _event: close())
    win.protocol("WM_DELETE_WINDOW", close)
    on_editing(True)
    on_touch(time.time())
    try:
        win.lift()
        win.focus_force()
        box.focus_set()
    except Exception:
        pass
