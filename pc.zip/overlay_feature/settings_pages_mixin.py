# -*- coding: utf-8 -*-
"""Overlay "smart" and "features" settings pages."""
from __future__ import annotations

from ui_widgets import Slider
from overlay_feature import runtime as _runtime
from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import CONTROL


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsPagesMixin:
    def build_smart(self, parent, more) -> None:
        """智能＝听和发；more 是「功能」页，好玩的和维护的都写在那。"""
        self._group(parent, "性能")
        row = self._row(parent, "性能模式")
        self.perf_value = str(self.cfg.get("perf_mode") or "quality")
        self.perf_chips = {}
        for value, label in (("eco", "节能"), ("standard", "标准"), ("quality", "质量")):
            chip = self._chip(row, label, lambda v=value: self.set_perf(v))
            chip.pack(side="left", padx=3)
            self.perf_chips[value] = chip
        self.refresh_perf_chips()
        note = self.tk.Frame(parent, bg=BG_PANEL)
        note.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(note, text="节能＝关掉设置里的界面动画；质量＝动画全开、帧率拉满",
                      bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        self.sl_anim = Slider(
            parent, "动画帧率", 15, 60,
            float(self.cfg.get("anim_fps") or 60),
            fmt="{:.0f} fps", on_change=self.on_change, bg=BG_PANEL,
        )
        self.sw_autotune = self._switch_row(
            parent, "低配自动降级", bool(self.cfg.get("auto_tune", True))
        )
        self.sl_followup = Slider(
            parent, "连续对话", 0, 30,
            float(self.cfg.get("followup_seconds") or 0),
            fmt="{:.0f} 秒", on_change=self.on_change, bg=BG_PANEL,
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(2, 6))
        self.tk.Label(
            row,
            text="说一次唤醒词后，这段时间内接着说就不用再喊它（0＝关闭）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        self._group(more, "提醒与日程")
        self.sw_reminder = self._switch_row(
            more, "提醒功能", bool(self.cfg.get("reminders_enabled", True))
        )
        self.sw_reminder_paste = self._switch_row(
            more, "提醒也发窗口", bool(self.cfg.get("reminder_paste", False))
        )
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(
            row,
            text='说"10 分钟后提醒我喝水"就会到点念出来',
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        row = self._row(more, "快捷指令")
        self.shortcuts = dict(self.cfg.get("shortcuts") or {})
        self.shortcuts_label = self.tk.Label(
            row,
            text=self.shortcuts_summary(),
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.shortcuts_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "编辑", self.edit_shortcuts).pack(side="right", padx=(4, 10))
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 8))
        self.tk.Label(
            row,
            text="每行一条：说中短语就执行  url:网址  app:程序  say:朗读的内容",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        self._group(more, "好玩的功能")
        self.tk.Label(
            more,
            text="",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        self.sw_caption = self._switch_row(
            more, "实时字幕", bool(self.cfg.get("caption_enabled", True))
        )
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 2))
        self.tk.Label(
            row,
            text="没说完就先出半截字（会多占一点显卡）",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")
        self.sw_mood = self._switch_row(
            more, "语气反应", bool(self.cfg.get("mood_enabled", True))
        )
        self.sw_sleepy = self._switch_row(
            more, "悬浮窗养成", bool(self.cfg.get("mood_idle", True))
        )
        self.sw_spectrum = self._switch_row(
            more, "音浪模式", bool(self.cfg.get("wave_spectrum", False))
        )
        self.sw_karaoke = self._switch_row(
            more, "逐字跟读", bool(self.cfg.get("karaoke", True))
        )
        self.sw_diary = self._switch_row(
            more, "睡前日记", bool(self.cfg.get("diary_enabled", True))
        )
        self.sw_notheard = self._switch_row(
            more, "没听清时说一声", bool(self.cfg.get("not_heard_reply", True))
        )
        self.sw_big = self._switch_row(
            more, "大字幕", bool(self.cfg.get("big_caption", False))
        )
        # 语音截图（看屏幕）总开关：关掉之后说「看屏幕 / 看看这个」它就不截了，
        # 只说一声"这个功能我关掉了"，不会偷偷截你的屏幕。
        self.sw_shot = self._switch_row(
            more, "看屏幕截图", bool(self.cfg.get("screenshot_enabled", True))
        )
        self.sw_share = self._switch_row(
            more, "屏幕发手机", bool(self.cfg.get("screen_share", True))
        )
        self.sw_chime = self._switch_row(
            more, "整点报时", bool(self.cfg.get("hourly_chime", False))
        )
        self.sw_sit = self._switch_row(
            more, "久坐提醒", bool(self.cfg.get("sit_reminder", True))
        )
        self.sw_meeting = self._switch_row(
            more, "开会自动闭嘴", bool(self.cfg.get("meeting_mute", True))
        )
        self.sw_hotkey = self._switch_row(
            more, "朗读选中(Ctrl+Alt+R)", bool(self.cfg.get("read_hotkey", True))
        )
        self.sw_voiceprint = self._switch_row(
            more, "声纹提示（实验）", bool(self.cfg.get("voiceprint_warn", False))
        )
        self.sw_pet = self._switch_row(
            more, "桌宠", bool(self.cfg.get("pet_enabled", True))
        )

        # ---- 发送方式 / 模型 / 语音（这些改完要重启才生效的会标出来）
        self._group(parent, "发送")
        row = self._row(parent, "发送方式")
        self.send_mode_value = str(self.cfg.get("send_mode") or "paste_enter")
        self.send_chips = {}
        for value, label in (("paste_enter", "粘贴并回车"), ("paste", "只粘贴"),
                             ("type", "当打字机")):
            chip = self._chip(row, label, lambda v=value: self.set_send_mode(v))
            chip.pack(side="left", padx=3)
            self.send_chips[value] = chip
        self.refresh_send_chips()
        self.sw_confirm = self._switch_row(
            parent, "发之前先问我", bool(self.cfg.get("confirm_send", False))
        )
        self.sw_follow = self._switch_row(
            parent, "跟着当前窗口发", bool(self.cfg.get("follow_foreground", False))
        )
        self.sw_readreply = self._switch_row(
            parent, "自动念回答", bool(self.cfg.get("read_reply", True))
        )
        self.sw_tray = self._switch_row(
            parent, "托盘图标", bool(self.cfg.get("tray_enabled", True))
        )
        self.sw_gate = self._switch_row(
            parent, "只认我的声音", bool(self.cfg.get("voiceprint_gate", False))
        )
        # 📱 手机入口：手机浏览器打开这条网址就能发命令、看对话（改完要重启才生效）
        self.sw_phone = self._switch_row(
            parent, "手机入口", bool(self.cfg.get("phone_enabled", True))
        )
        row = self._row(parent, "手机网址")
        try:
            import phone_link

            url_now = phone_link.phone_url(
                int(self.cfg.get("phone_port") or 8765)
            )
        except Exception:
            url_now = "（读不到网卡地址，重启后再看）"
        self.phone_url_label = self.tk.Label(
            row,
            text=url_now,
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        )
        self.phone_url_label.pack(side="left", padx=(0, 6))
        self._chip(row, "复制", lambda: self.copy_phone_url()).pack(side="right")
        # 二维码按钮：点一下就把这条网址画成码，手机左上角「扫码」照着连
        self._chip(row, "二维码", lambda: self.show_qr()).pack(
            side="right", padx=(0, 6)
        )
        self.tk.Label(
            parent,
            text="手机连同一个 Wi-Fi，浏览器打开这条网址就行；"
                 "出门在外面要用，点下面「外网访问」的一键开启",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            wraplength=360,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 4))

        # 🌐 外网访问（Tailscale）—— 直接长在程序里。
        self._group(parent, "外网访问（在外面也能连）")
        self.remote_label = self.tk.Label(
            parent,
            text="正在看…",
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            justify="left",
            wraplength=350,
            font=("Microsoft YaHei UI", 8),
        )
        self.remote_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(parent, "外网访问")
        self._chip(row, "一键开启", self.remote_enable).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "二维码", self.show_remote_qr).pack(side="right", padx=2)
        self._chip(row, "复制地址", self.copy_remote_url).pack(side="right", padx=2)
        self._chip(row, "刷新", self.refresh_remote).pack(side="right", padx=2)
        # 公网地址（Funnel）：开了以后手机那台连 Tailscale 都不用装。
        row = self._row(parent, "公网地址")
        self._chip(row, "开（手机免装）", self.remote_funnel_on).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "复制", self.copy_public_url).pack(side="right", padx=2)
        self._chip(row, "关掉", self.remote_funnel_off).pack(side="right", padx=2)
        # 安全那两样：能用哪台设备（要你点同意）、令牌能换（怀疑泄漏时）。
        row = self._row(parent, "能连的设备")
        self.devices_label = self.tk.Label(
            row, text="…", bg=BG_PANEL, fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        )
        self.devices_label.pack(side="left")
        self._chip(row, "名单", self.show_device_list).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "连接记录", self.show_access_log).pack(
            side="right", padx=2
        )
        row = self._row(parent, "手机令牌")
        self._chip(row, "换一条", self.rotate_phone_token).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            row, text="怕链接泄漏了就换", bg=BG_PANEL, fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self.refresh_devices_label()
        self._group(parent, "识别")
        row = self._row(parent, "唤醒词训练")
        self.tk.Label(
            row, text="念三遍让它记住你的口音", bg=BG_PANEL, fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(
            row,
            "开始训练",
            lambda: (
                send_command("expand"),
                self.flash("对着麦克风说「训练唤醒词」", 3),
            ),
        ).pack(side="right", padx=(4, 10))
        row = self._row(parent, "识别模型")
        self.model_value = str(self.cfg.get("model") or "large-v3-turbo")
        self.model_chips = {}
        for value, label in (("small", "小(快)"), ("medium", "中"),
                             ("large-v3-turbo", "大(准)")):
            chip = self._chip(row, label, lambda v=value: self.set_model(v))
            chip.pack(side="left", padx=3)
            self.model_chips[value] = chip
        self.refresh_model_chips()
        row = self._row(parent, "识别语言")
        self.lang_value = str(self.cfg.get("lang") or "zh")
        self.lang_chips = {}
        for value, label in (("zh", "中文"), ("zh,en", "中英混说"), ("en", "英文")):
            chip = self._chip(row, label, lambda v=value: self.set_lang(v))
            chip.pack(side="left", padx=3)
            self.lang_chips[value] = chip
        self.refresh_lang_chips()
        row = self._row(parent, "改完生效")
        self.tk.Label(
            row, text="改模型或语言后要点重启", bg=BG_PANEL, fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(row, "重启程序", self.restart_program).pack(
            side="right", padx=(4, 10)
        )
        self.sw_rec = self._switch_row(
            parent, "录音提示灯", bool(self.cfg.get("rec_indicator", True))
        )

        self._group(more, "集中记忆")
        row = self._row(more, "记忆归档")
        self.memory_label = self.tk.Label(
            row,
            text=self.memory_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.memory_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "查看", self.open_memory_archive).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "归档", self.do_memory_archive).pack(side="right", padx=2)
        self.tk.Label(
            more,
            text="只有你说「集中记忆归档」或点「归档」才会生成；"
                 "说「查看记忆归档」只打开上一次的，不会自动重建",
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        ).pack(fill="x", padx=(14, 10), pady=(0, 4))
        self._group(more, "数据与排查")
        self.entry_city = self._entry(
            more, "天气城市", self.cfg.get("weather_city") or ""
        )
        row = self._row(more, "数据")
        self._chip(row, "导出", self.do_export).pack(side="right", padx=(4, 10))
        self._chip(row, "导入", self.do_import).pack(side="right", padx=2)
        self._chip(row, "清空", self.ask_clear).pack(side="right", padx=2)
        # 诊断包和导出包现在归到一块儿：都藏进程序目录里的「导出」文件夹。
        row = self._row(more, "备份与诊断")
        self._chip(row, "打包诊断", self.do_diagnose).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "打开文件夹", self.open_backup_dir).pack(
            side="right", padx=2
        )
        self.backup_label = self.tk.Label(
            more,
            text=self.backup_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        )
        self.backup_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(more, "系统日志")
        self.log_label = self.tk.Label(
            row,
            text=self.log_summary(),
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.log_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "记事本", self.open_syslog).pack(side="right", padx=(4, 10))
        self._chip(row, "查看", self.open_log_window).pack(side="right", padx=2)
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(
            row,
            text="你急它偏暖、你轻它偏灰；两分钟没人理就打哈欠、四分钟打盹；"
                 "音浪＝声音条变频谱柱；跟读＝它念到哪个字哪个字亮；"
                 "大字幕＝屏幕底部一条大字",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")
        # 卸载：不用跑去桌面找快捷方式，设置里直接就能卸。
        self._group(more, "卸载")
        row = self._row(more, "卸载")
        self._chip(row, "卸载鳍舱…", self.ask_uninstall).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            more,
            text="会先问你：只卸运行环境和模型（聊天记录留着），"
                 "还是连程序带记录一起删干净",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 6))
