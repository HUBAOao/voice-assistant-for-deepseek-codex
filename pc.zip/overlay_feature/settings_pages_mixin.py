# -*- coding: utf-8 -*-
"""Overlay "smart" and "features" settings pages."""
from __future__ import annotations

from ui_widgets import Slider
from overlay_feature.defaults import BG_PANEL


class OverlaySettingsPagesMixin:
    def build_smart(self, parent, more) -> None:
        """智能＝听和发；more 是「功能」页，好玩的和维护的都写在那。"""
        self._group(parent, "性能")
        row = self._row(parent, "性能模式")
        self.perf_value = str(self.cfg.get("perf_mode") or "quality")
        self.perf_chips = {}
        for value, label in (("eco", "节能"), ("standard", "标准"), ("quality", "质量")):
            chip = self._chip(row, label, lambda v=value: self.set_perf(v))
            chip.pack(side="left", padx=3)
            self.perf_chips[value] = chip
        self.refresh_perf_chips()
        note = self.tk.Frame(parent, bg=BG_PANEL)
        note.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(note, text="节能＝关掉设置里的界面动画；质量＝动画全开、帧率拉满",
                      bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        self.sl_anim = Slider(
            parent, "动画帧率", 15, 60,
            float(self.cfg.get("anim_fps") or 60),
            fmt="{:.0f} fps", on_change=self.on_change, bg=BG_PANEL,
        )
        self.sw_autotune = self._switch_row(
            parent, "低配自动降级", bool(self.cfg.get("auto_tune", True))
        )
        self.sl_followup = Slider(
            parent, "连续对话", 0, 30,
            float(self.cfg.get("followup_seconds") or 0),
            fmt="{:.0f} 秒", on_change=self.on_change, bg=BG_PANEL,
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(2, 6))
        self.tk.Label(
            row,
            text="说一次唤醒词后，这段时间内接着说就不用再喊它（0＝关闭）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        self.build_features(more)

        self.build_delivery_section(parent)

        self._group(more, "集中记忆")
        row = self._row(more, "记忆归档")
        self.memory_label = self.tk.Label(
            row,
            text=self.memory_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.memory_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "查看", self.open_memory_archive).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "归档", self.do_memory_archive).pack(side="right", padx=2)
        self.tk.Label(
            more,
            text="只有你说「集中记忆归档」或点「归档」才会生成；"
                 "说「查看记忆归档」只打开上一次的，不会自动重建",
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        ).pack(fill="x", padx=(14, 10), pady=(0, 4))
        self._group(more, "数据与排查")
        self.entry_city = self._entry(
            more, "天气城市", self.cfg.get("weather_city") or ""
        )
        row = self._row(more, "数据")
        self._chip(row, "导出", self.do_export).pack(side="right", padx=(4, 10))
        self._chip(row, "导入", self.do_import).pack(side="right", padx=2)
        self._chip(row, "清空", self.ask_clear).pack(side="right", padx=2)
        # 诊断包和导出包现在归到一块儿：都藏进程序目录里的「导出」文件夹。
        row = self._row(more, "备份与诊断")
        self._chip(row, "打包诊断", self.do_diagnose).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "打开文件夹", self.open_backup_dir).pack(
            side="right", padx=2
        )
        self.backup_label = self.tk.Label(
            more,
            text=self.backup_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        )
        self.backup_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(more, "系统日志")
        self.log_label = self.tk.Label(
            row,
            text=self.log_summary(),
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.log_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "记事本", self.open_syslog).pack(side="right", padx=(4, 10))
        self._chip(row, "查看", self.open_log_window).pack(side="right", padx=2)
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(
            row,
            text="你急它偏暖、你轻它偏灰；两分钟没人理就打哈欠、四分钟打盹；"
                 "音浪＝声音条变频谱柱；跟读＝它念到哪个字哪个字亮；"
                 "大字幕＝屏幕底部一条大字",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")
        # 卸载：不用跑去桌面找快捷方式，设置里直接就能卸。
        self._group(more, "卸载")
        row = self._row(more, "卸载")
        self._chip(row, "卸载鳍舱…", self.ask_uninstall).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            more,
            text="会先问你：只卸运行环境和模型（聊天记录留着），"
                 "还是连程序带记录一起删干净",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 6))
