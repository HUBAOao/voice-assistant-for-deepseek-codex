#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""电脑 ↔ 手机的文件互传。

电脑 → 手机：语音说「把桌面的报表.xlsx 发到手机」，或者手机页里输入文件名要，
            文件会被**复制**一份到 手机文件\\，手机入口再把它们端给手机下载。
手机 → 电脑：手机页上点「传到电脑」，文件存到 手机上传\\。

两条原则：
  · 只复制、不移动也不删原文件（宁可在分享目录里留副本，也别把用户的东西挪走）；
  · 名字里带路径分隔符的一律不认（防止 ../ 跑出去读别的文件）。
"""

from __future__ import annotations

import re
import shutil
import time
from pathlib import Path
from typing import Optional

import storage_paths

HERE = Path(__file__).resolve().parent
SHARE_DIR = storage_paths.migrate_legacy(HERE / "手机文件", "手机文件")
UPLOAD_DIR = storage_paths.migrate_legacy(HERE / "手机上传", "手机上传")
AUDIO_DIR = storage_paths.migrate_legacy(HERE / "试听", "试听")
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".ogg", ".aac", ".flac", ".opus")

# 找文件时翻这些地方（按顺序，越靠前越优先）
SEARCH_DIRS = [
    Path.home() / "Desktop",
    Path.home() / "Downloads",
    Path.home() / "Documents",
    Path.home() / "Pictures",
    HERE / "手机屏幕",
]
MAX_UPLOAD = 200 * 1024 * 1024        # 手机传上来单文件最大 200MB


def safe_name(name: str) -> str:
    """把名字洗干净：不许带路径、不许是保留名。"""
    name = (name or "").strip().strip('"').strip("'")
    name = name.replace("\\", "/").split("/")[-1]        # 只保留最后一段
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name)
    name = name.strip(". ")
    return name[:120]


def _ensure() -> None:
    SHARE_DIR.mkdir(parents=True, exist_ok=True)
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def add_file(src: Path, as_name: str = "") -> Optional[Path]:
    """把电脑上的一个文件复制到分享目录，返回复制后的路径。"""
    try:
        _ensure()
        src = Path(src)
        if not src.is_file():
            return None
        name = safe_name(as_name or src.name)
        if not name:
            return None
        dst = SHARE_DIR / name
        if dst.exists() and dst.samefile(src):
            return dst
        # 重名就加 (2)(3)…
        i = 1
        while dst.exists():
            i += 1
            dst = SHARE_DIR / f"{Path(name).stem}({i}){Path(name).suffix}"
        shutil.copy2(src, dst)
        storage_paths.mirror_file(dst, Path("手机文件") / dst.name)
        prune_share()
        return dst
    except Exception:
        return None


def find_file(word: str, limit: int = 200) -> Optional[Path]:
    """按名字找电脑上的文件：先精确、再包含；找不到就 None。"""
    word = safe_name(word)
    if not word:
        return None
    want = word.lower()
    hits: list[tuple[float, Path]] = []
    for d in SEARCH_DIRS:
        if not d.exists():
            continue
        try:
            for p in d.rglob("*"):
                if not p.is_file():
                    continue
                n = p.name.lower()
                if n == want or (want in n and len(n) <= len(want) + 12):
                    hits.append((p.stat().st_mtime, p))
                    if len(hits) >= limit:
                        break
        except Exception:
            continue
        if hits:
            break                      # 前面的目录里找到就不再往下翻
    if not hits:
        return None
    hits.sort(key=lambda x: x[0], reverse=True)
    exact = [p for _t, p in hits if p.name.lower() == want]
    return exact[0] if exact else hits[0][1]


def list_files(limit: int = 40) -> list[dict]:
    """分享目录里的文件（新的在前）。"""
    if not SHARE_DIR.exists():
        return []
    out = []
    for p in sorted(SHARE_DIR.glob("*"), key=lambda f: f.stat().st_mtime, reverse=True)[:limit]:
        if not p.is_file():
            continue
        st = p.stat()
        out.append({"name": p.name, "kb": round(st.st_size / 1024, 1), "ts": st.st_mtime})
    return out


def list_uploads(limit: int = 40) -> list[dict]:
    if not UPLOAD_DIR.exists():
        return []
    return [{"name": p.name, "kb": round(p.stat().st_size / 1024, 1), "ts": p.stat().st_mtime}
            for p in sorted(UPLOAD_DIR.glob("*"), key=lambda f: f.stat().st_mtime,
                            reverse=True)[:limit] if p.is_file()]


def file_path(name: str) -> Optional[Path]:
    """按名字取分享目录里的文件（防目录穿越）。"""
    n = safe_name(name)
    if not n or n != (name or "").strip():
        return None                      # 名字被"洗过"了，说明原本带路径/非法字符 → 不认
    p = SHARE_DIR / n
    return p if p.is_file() else None


def upload_path(name: str) -> Optional[Path]:
    """按名字取手机上传目录里的文件（同样防目录穿越）。"""
    n = safe_name(name)
    if not n or n != (name or "").strip():
        return None
    p = UPLOAD_DIR / n
    return p if p.is_file() else None


def save_upload(name: str, data: bytes) -> Optional[Path]:
    """手机传上来的文件存下来。"""
    try:
        _ensure()
        if len(data) > MAX_UPLOAD:
            return None
        n = safe_name(name) or f"手机文件-{time.strftime('%m%d-%H%M%S')}.bin"
        dst = UPLOAD_DIR / n
        i = 1
        while dst.exists():
            i += 1
            dst = UPLOAD_DIR / f"{Path(n).stem}({i}){Path(n).suffix}"
        dst.write_bytes(data)
        storage_paths.mirror_file(dst, Path("手机上传") / dst.name)
        return dst
    except Exception:
        return None


def prune_share(keep: int = 40) -> None:
    """分享目录只留最近这些（都是副本，删了不影响原文件）。"""
    if not SHARE_DIR.exists():
        return
    for old in sorted(SHARE_DIR.glob("*"), key=lambda f: f.stat().st_mtime,
                      reverse=True)[keep:]:
        try:
            if old.is_file():
                old.unlink()
        except Exception:
            pass


# ------------------------------------------------------------------ 手机试听
# 为什么单独开一个目录：语音样本是要在手机上**直接点开听**的，不是拿来下载存盘的。
# 混进「手机文件」里会被 prune_share 当旧文件删掉，也会跟文档混在一起不好找。

def add_audio(src: Path, as_name: str = "") -> Optional[Path]:
    """把一个音频复制到试听目录（只复制，不动原文件）。"""
    try:
        _ensure_audio()
        src = Path(src)
        if not src.is_file():
            return None
        name = safe_name(as_name or src.name)
        if not name:
            return None
        dst = AUDIO_DIR / name
        if dst.exists() and dst.samefile(src):
            return dst
        i = 1
        while dst.exists():
            i += 1
            dst = AUDIO_DIR / f"{Path(name).stem}({i}){Path(name).suffix}"
        shutil.copy2(src, dst)
        storage_paths.mirror_file(dst, Path("试听") / dst.name)
        prune_audio()
        return dst
    except Exception:
        return None


def _ensure_audio() -> None:
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)


def list_audios(limit: int = 40) -> list[dict]:
    """试听目录里的音频（新的在前）。"""
    if not AUDIO_DIR.exists():
        return []
    out = []
    for p in sorted(AUDIO_DIR.glob("*"), key=lambda f: f.stat().st_mtime,
                    reverse=True)[:limit]:
        if not p.is_file() or p.suffix.lower() not in AUDIO_EXT:
            continue
        st = p.stat()
        out.append({"name": p.name,
                    "kb": round(st.st_size / 1024, 1),
                    "ts": st.st_mtime,
                    "at": time.strftime("%m-%d %H:%M", time.localtime(st.st_mtime))})
    return out


def audio_path(name: str) -> Optional[Path]:
    """按名字取试听目录里的音频（防目录穿越）。"""
    n = safe_name(name)
    if not n or n != name.strip().replace("\\", "/").split("/")[-1]:
        return None
    p = AUDIO_DIR / n
    try:
        if p.is_file() and p.suffix.lower() in AUDIO_EXT:
            return p
    except Exception:
        pass
    return None


def prune_audio(keep: int = 40) -> None:
    """试听目录只留最近这些（都是副本，删了不影响原文件）。"""
    if not AUDIO_DIR.exists():
        return
    for old in sorted(AUDIO_DIR.glob("*"), key=lambda f: f.stat().st_mtime,
                      reverse=True)[keep:]:
        try:
            if old.is_file():
                old.unlink()
        except Exception:
            pass
