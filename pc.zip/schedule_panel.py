#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Composable schedule panel for the desktop overlay."""
from __future__ import annotations

from datetime import date

import sched
from schedule_feature.calendar_view import CalendarViewMixin
from schedule_feature.editor import EditorMixin
from schedule_feature.module_dialog import ModuleDialogMixin
from schedule_feature.module_list import ModuleListMixin
from schedule_feature.style import (
    ANIM_STEPS,
    BG,
    CARD,
    CARD_SEL,
    COMMAND,
    DIM,
    FG,
    HOUR_H,
    REMIND,
    ROW,
    ROW_HOVER,
)
from schedule_feature.table_view import TableViewMixin


class SchedulePanel(
    CalendarViewMixin,
    TableViewMixin,
    EditorMixin,
    ModuleDialogMixin,
    ModuleListMixin,
):
    """Month/day/table views plus draggable reusable schedule modules."""

    def __init__(
        self,
        tk,
        parent,
        cfg: dict,
        on_change,
        button_color="#2f7f5a",
        accent="#3ddc84",
    ) -> None:
        self.tk = tk
        self.parent = parent
        self.on_change = on_change
        self.button_color = button_color
        self.accent = accent
        self.entries = [
            sched.normalize(entry)
            for entry in cfg.get("schedules") or []
            if isinstance(entry, dict)
        ]
        self.modules = self._load_modules(cfg)
        self.modules_open = False
        today = date.today()
        self.year, self.month = today.year, today.month
        self.selected = today
        self.view = "calendar"
        self.kind = "command"
        self.dragging = None
        self._drag_label = None
        self.perf = str(cfg.get("perf_mode") or "standard")
        self.fps = max(15, min(60, int(cfg.get("anim_fps") or 60)))
        self._build()

    def _build(self) -> None:
        tk = self.tk
        bar = tk.Frame(self.parent, bg=BG)
        bar.pack(fill="x", padx=10, pady=(4, 2))
        self.view_chips = {}
        for value, label in (("calendar", "日历"), ("table", "表格")):
            chip = tk.Label(
                bar,
                text=label,
                bg=CARD,
                fg=FG,
                padx=12,
                pady=3,
                cursor="hand2",
                font=("Microsoft YaHei UI", 9),
            )
            chip.pack(side="left", padx=3)
            chip.bind(
                "<Button-1>",
                lambda _e, v=value: self.set_view(v),
            )
            self.view_chips[value] = chip
        tk.Label(
            bar,
            text="点某天放大成时间表 · 点空白缩回",
            bg=BG,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="right", padx=6)
        self.calendar_frame = tk.Frame(self.parent, bg=BG)
        self.day_frame = tk.Frame(self.parent, bg=BG)
        self.table_frame = tk.Frame(self.parent, bg=BG)
        self._build_calendar(self.calendar_frame)
        self._build_day(self.day_frame)
        self._build_table(self.table_frame)
        self._build_drawer(self.parent)
        self.set_view("calendar")

    def set_view(self, value: str) -> None:
        self.view = value
        for key, chip in self.view_chips.items():
            chip.config(
                bg=self.button_color if key == value else CARD
            )
        if value == "day":
            self.refresh_day()
            self._slide_in(self.day_frame)
            return
        for frame in (self.calendar_frame, self.table_frame):
            frame.pack_forget()
        if value == "table":
            self.table_frame.pack(fill="both", expand=True)
            self.refresh_table()
        else:
            self.calendar_frame.pack(fill="both", expand=True)
            self.refresh_calendar()
        self._slide_out(self.day_frame)

    def _slide_in(self, frame) -> None:
        width = max(320, self.parent.winfo_width() or 420)
        frame.place(x=width, y=0, relwidth=1, relheight=1)
        frame.lift()

        def apply(t: float) -> None:
            frame.place_configure(x=int(width * (1 - t)))
            if getattr(self, "drawer_wrap", None) is not None:
                self.drawer_wrap.lift()

        self._tween(apply)

    def _slide_out(self, frame) -> None:
        if not frame.winfo_ismapped():
            return
        width = max(320, self.parent.winfo_width() or 420)
        self._tween(
            lambda t: frame.place_configure(x=int(width * t)),
            done=frame.place_forget,
        )

    def _tween(self, apply, steps: int | None = None, done=None) -> None:
        if self.perf == "eco":
            apply(1.0)
            if done:
                done()
            return
        total = steps or max(6, int(ANIM_STEPS * self.fps / 60))
        delay = max(8, int(1000 / max(15, self.fps)))
        state = {"i": 0}

        def step() -> None:
            state["i"] += 1
            progress = 1 - (1 - state["i"] / total) ** 3
            try:
                apply(progress)
            except Exception:
                return
            if state["i"] < total:
                self.parent.after(delay, step)
            elif done:
                done()

        step()


__all__ = [
    "ANIM_STEPS",
    "BG",
    "CARD",
    "CARD_SEL",
    "COMMAND",
    "DIM",
    "FG",
    "HOUR_H",
    "REMIND",
    "ROW",
    "ROW_HOVER",
    "SchedulePanel",
]
