#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""桌宠右键「退出」的收尾器：先把语音助手叫停，再清掉它自己的残留进程。

只按“命令行里带本程序目录”认人，所以不会碰 Codex、语音克隆服务或别的 Python。
桌宠主进程会 detached 地拉起它，自己先退出；这里晚一点再动手，避免把正在退出的
主程序当成卡死进程重复处理。
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONTROL = HERE / "control.json"
MANUAL_EXIT = HERE / "manual-exit.json"


def write_quit() -> None:
    try:
        CONTROL.write_text(json.dumps({"action": "quit", "ts": time.time()}),
                           encoding="utf-8")
    except Exception:
        pass
    try:
        MANUAL_EXIT.write_text(json.dumps({"ts": time.time()}), encoding="utf-8")
    except Exception:
        pass


def log(text: str) -> None:
    try:
        with (HERE / "quit-all.log").open("a", encoding="utf-8") as fh:
            fh.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + text + "\n")
    except Exception:
        pass


def kill_pid(pid: int, why: str) -> None:
    if pid <= 0:
        return
    flags = 0x08000000 if sys.platform == "win32" else 0
    try:
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                       cwd=str(HERE), creationflags=flags, timeout=12,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log(f"taskkill {pid} ({why})")
    except Exception as exc:
        log(f"taskkill {pid} 失败：{exc}")


def pid_from_file(name: str) -> int:
    try:
        data = json.loads((HERE / name).read_text(encoding="utf-8"))
        return int(data.get("pid") or 0)
    except Exception:
        return 0


def kill_known(voice_pids: set[int]) -> None:
    if not voice_pids:
        log("没有可信的语音进程列表，跳过 PID 文件清理")
        return
    for name in ("status.json", "overlay_ready.json", "tray.pid",
                 "watchdog.pid", "pet.pid"):
        pid = pid_from_file(name)
        if pid in voice_pids:
            kill_pid(pid, name)
        elif pid:
            log(f"忽略 {name} 的过期 PID {pid}")


def list_voice_processes() -> list[tuple[int, str, str]]:
    """用 wmic 读命令行（PowerShell/WMI 在 pythonw 里会偶发卡住，wmic 快且稳）。"""
    flags = 0x08000000 if sys.platform == "win32" else 0
    query = "name='pythonw.exe' or name='python.exe' or name='electron.exe'"
    try:
        out = subprocess.check_output(
            ["wmic", "process", "where", query, "get",
             "ProcessId,Name,CommandLine", "/format:csv"],
            cwd=str(HERE), creationflags=flags, timeout=15,
            stderr=subprocess.DEVNULL,
        ).decode("utf-8", "replace")
    except Exception as exc:
        log(f"wmic 查询失败：{exc}")
        return []
    rows: list[tuple[int, str, str]] = []
    app = str(HERE).lower()
    for row in csv.reader(io.StringIO(out)):
        if len(row) < 4:
            continue
        cmd, name, pid_text = row[1], row[2], row[3]
        if not cmd or "quit_all.py" in cmd:
            continue
        if app not in cmd.lower():
            continue
        if name.lower() not in ("python.exe", "pythonw.exe", "electron.exe"):
            continue
        try:
            rows.append((int(pid_text), name, cmd))
        except ValueError:
            continue
    return rows


def kill_leftovers() -> None:
    rows = list_voice_processes()
    voice_pids = {pid for pid, _name, _cmd in rows}
    kill_known(voice_pids)
    for pid, name, cmd in rows:
        log(f"残留 {pid} {name}")
        kill_pid(pid, "命令行匹配本程序目录")
    log(f"清理完成，共处理 {len(rows)} 条残留")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--delay", type=float, default=1.5)
    args = ap.parse_args()
    write_quit()
    time.sleep(max(0.3, args.delay))
    kill_leftovers()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
