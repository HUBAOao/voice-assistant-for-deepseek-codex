#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手悬浮窗（精简版 + 就地设置）。

平时只有四样东西：名字、状态、开关、以及贴着底部的一条声音波浪。
  · 有声音 → 波浪铺满底部，上下抖动（不是左右伸缩）
  · 没声音 → 缩到中间，变成一个上下浮动的小圆球
右下角是个小箭头：点一下浮窗平滑长大，就地展开设置（基本/声音/外观/布局）。
设置里改什么都立刻预览，满意了再保存；也有「恢复默认」。
"""

from __future__ import annotations

import ctypes
import atexit
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageTk

from ui_widgets import Slider, SpinRow, Switch
from schedule_panel import SchedulePanel
import wake_levels
import version

HERE = Path(__file__).resolve().parent
STATUS = HERE / "status.json"
SPEAK_STATUS = HERE / "speak.json"
CONTROL = HERE / "control.json"
POS = HERE / "overlay_pos.json"
CONFIG = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"
READY_FILE = HERE / "overlay_ready.json"   # "窗口已经显示出来了"的回执，给主程序看
SYSLOG_FILE = HERE / "syslog.md"
EXIT_LOG = HERE / "overlay-exit.log"
INPUT_LOG = HERE / "input.log"

FRAME_MS = 16                 # 约 60fps
FADE_SECONDS = 0.24           # 声音条换色（说话/静默、改配色）的过渡时长
RESIZE_STEPS = 8              # 展开/收起走多少步（按步数走，机器慢也不会变成大跳）
RESIZE_STEP_MS = 8            # 展开/收起期间两帧之间至少要隔这么久，不然窗口尺寸会被合并
SIMPLE_STEPS = 6              # 缩成侧边条 / 从侧边条放大回来：距离短，走更少的步，更快
SNAP_PX = 26                  # 拖到离屏幕边缘多近就吸上去
SIMPLE_LONG = 132             # 贴边后那条"简化版"有多长
SIMPLE_THICK = 20             # 以及多粗
STATUS_MS = 200
CONFIG_MS = 300
PANEL_H = 452                 # 五个标签页，留够高度
PANEL_H_OPEN = 560            # 展开设置后的固定高度（不再跟着标签页内容变，装不下就用滚轮看）
ARROW = 26
DEFAULT_ALPHA = 0.98
MIN_ALPHA, MAX_ALPHA = 0.35, 1.0

DEFAULTS = {
    # ↓↓↓ 这套是当前这套配置固化成的新默认值（除个人背景图与设备相关项）
    "name": "大肥鱼",
    "overlay_color": "#1b1b1f",
    "overlay_accent": "#3ddc84",
    "overlay_button": "#2f7f5a",
    "overlay_text": "#ffffff",
    "overlay_talk_color": "#4aa3ff",     # 我说话时声音条的颜色
    "overlay_alpha": 0.95,        # 你调成了 95%
    "overlay_bg_image": "assets/default-bg.jpg",
    "overlay_bg_dim": 45,
    "overlay_width": 344,
    "overlay_height": 112,
    "overlay_line_max": 420,
    "overlay_show_name": True,
    "overlay_show_status": True,
    "overlay_show_line": True,
    "overlay_show_switch": True,
    "ov_name_x": 16, "ov_name_y": 12, "ov_name_size": 19,
    "ov_status_x": -74, "ov_status_y": 12, "ov_status_size": 15,
    "ov_switch_x": -16, "ov_switch_y": 10,
    "ov_wave_y": 14, "ov_wave_h": 42,
    "overlay_wave_style": "siri",
    "wake_level": "宽松",         # 唤醒档位：严格 / 标准 / 宽松 / 极宽松（可自己加）
    "wake_levels": {},            # 用户自己加的档位（默认档位在 wake_levels.py 里）
    "volume": 80,
    "rate": "+8%",
    "voice": "zh-CN-XiaoyiNeural",
    "wake_word": "大肥鱼",
    "cancel_word": "取消",
    "greeting_enabled": True,
    "greeting_text": "{time}好，{name}已经就绪，说「{wake}」就能叫我。",
    "greeting_delay": 3,
    "user_name": "",              # 怎么称呼你
    "name_freq": "sometimes",     # off / sometimes / often
    "ack_enabled": True,
    # 应答语：可以写好几条（用 | 隔开），每次随机挑一条说
    "ack_text": ("好的我这就做|好嘞|收到|来了|马上办|好的，收到|得嘞|这就办|明白|"
                 "收到，这就去|嗯，交给我|好嘞，这就来|记住了|这就去办|好，安排|"
                 "收到啦|这就给你办|行，马上|晓得啦|收到收到"),
    "self_talk": True,            # 可爱自称（「大肥鱼完成任务啦」）
    "self_name": "大肥鱼",
    "self_freq": "sometimes",     # 自称说的勤不勤：off 不说 / sometimes 有时 / often 经常
    # 新加的智能功能
    "followup_seconds": 8,
    "reminders_enabled": True,
    "reminder_paste": False,     # 提醒也发窗口（默认关：提醒只在电脑上念，不往对话里塞、不花 token）
    "shortcuts": {},
    "schedules": [],
    "schedule_modules": [],
    "schedule_speak": True,
    "perf_mode": "quality",       # eco 节能 / standard 标准 / quality 质量
    "anim_fps": 60,
    "wheel_alpha": True,          # 滚轮是否改变透明度（你把它打开了）
    # 声音条特效（每个都能单独开关）
    "fx_trail": True,             # 视觉暂留：拖一条会慢慢淡掉的残影
    "fx_glow": True,              # 呼吸光晕：顺着条的轮廓（或那颗小圆点）往外铺的柔光
    "fx_sparkles": False,         # 星尘：说话时溅出的小亮点（你自己关掉了，就当出厂默认）
    "fx_reflection": True,        # 倒影：声音条下面一层淡淡的反光
    "fx_sweep": True,             # 流光：一道高光沿着声音条扫过
    # 下面这几个是"玩一下"用的，默认全关：你说的"那颗小圆点只留光晕"，
    # 想加回来就在设置里自己拨开（设置 → 外观 → 声音条特效）
    "fx_ripple": False,           # 波纹：没声音时，小圆点一圈圈荡开
    "fx_orbit": False,            # 卫星：两颗小卫星绕着圆点转，还拖着短短的光尾
    "fx_rotor": False,            # 光环：一圈会自己转的虚线光环
    "fx_starflare": False,        # 星芒：十字形的亮光
    "fx_aurora": False,           # 极光：没声音时，圆点外面那层光会慢慢换颜色
    "fx_heartbeat": False,        # 心跳：圆点像心跳那样"咚—咚"地脉动
    "fx_burst": True,             # 唤醒爆闪：被叫醒的一瞬间炸出一圈小火星（你要的）
    # 好玩的功能开关
    "caption_enabled": False,     # 实时字幕：边说边出字（你嫌它占显卡，关掉了）
    "overlay_show_caption": True, # 把字幕显示在声音条上方
    "mood_enabled": False,        # 语气反应：你急它暖、你轻它暗（你嫌它变来变去，关掉了）
    "mood_idle": True,            # 悬浮窗养成：长时间没人理它会打盹
    "wave_spectrum": False,       # 音浪模式：声音条变成跟着声音跳的频谱柱
    "karaoke": True,              # 逐字跟读：它念到哪个字哪个字亮
    "diary_enabled": True,        # 睡前日记：到点念一遍今天说了什么
    "diary_hour": 22,
    "big_caption": False,         # 大字幕：屏幕底部一条大字
    "big_caption_size": 34,
    "screenshot_enabled": True,   # 看屏幕截图：说「看屏幕 / 看看这个」就截屏贴进聊天窗口
    "screen_share": True,         # 屏幕发手机：说「截图发手机 / 录 8 秒发手机」就放到手机入口
    "phone_enabled": True,        # 手机入口：手机浏览器连过来发命令、看对话
    "phone_port": 8765,           # 手机入口的端口
    "hourly_chime": False,        # 整点报时
    "sit_reminder": False,        # 久坐提醒（连着用电脑一小时提醒你起来）（你把它关了）
    "sit_minutes": 60,
    "meeting_mute": True,         # 开会自动闭嘴：会议软件在前台就只出字幕
    "read_hotkey": True,          # Ctrl+Alt+R 朗读选中的文字
    "voiceprint_warn": False,     # 声纹提示：这次不太像你的声音就告诉你一声（你嫌吵，关掉了）
    "fatigue_reminder": True,     # 你说得比平时又慢又轻时劝你歇会儿
    "pet_enabled": False,         # 桌宠：DeepSeek 娘在桌面上走来走去（默认关着，想开随时开）
    "pet_scale": 3,               # 桌宠大小
    "pet_speed": 3,               # 桌宠走路快慢
    "pet_speak": True,            # 桌宠说话
    "follow_foreground": False,   # 发到"你当前在用的窗口"而不是写死的 ChatGPT
    "rec_indicator": True,        # 录音时右下角亮一个小红点提示
    "private_minutes": 5,         # 说"别记这段"之后静默几分钟
    "weather_city": "北京",        # 天气城市（空 = 自动定位，走代理会判到国外）
    "send_mode": "paste_enter",   # 发送方式：paste_enter / paste / type
    "confirm_send": False,        # 发之前先问你一声
    "tray_enabled": True,         # 右下角托盘图标
    "voiceprint_gate": True,      # 只认我的声音（没训练过声纹就自动放行，不会把人挡在外面）
    "model": "large-v3-turbo",    # 识别模型（改完要重启）
    "lang": "zh",                 # 识别语言
    "auto_tune": True,            # 低配机器上自动降级（关特效、30 帧、关实时字幕）
    "not_heard_reply": False,     # 没听清时念一句"没听清，再说一遍"
    "auto_restart": False,        # 崩溃后看门狗自动把它拉起来（你把它关了：不希望它自己又起来）
    "snap_edges": True,           # 贴边吸附：拖到屏幕边缘会吸住，并缩成一条小细条
    "read_reply": True,           # 自动念回答：发的消息有人回答了就念给你听
}

# 声音条特效的键，按"从主到次"排好；降级 / 布局 / 设置页都读这一份，避免几处各写一遍漏掉
FX_KEYS = ("fx_trail", "fx_glow", "fx_sparkles", "fx_reflection", "fx_sweep",
           "fx_ripple", "fx_orbit", "fx_rotor", "fx_starflare", "fx_aurora",
           "fx_heartbeat", "fx_burst")
# 只在小圆点状态才画的那几个（声音条铺满时看不见它们的意义）
FX_DOT_KEYS = ("fx_ripple", "fx_orbit", "fx_rotor", "fx_starflare",
               "fx_aurora", "fx_heartbeat", "fx_burst")

BG_PANEL = "#1d1d23"
BORDER = "#3a3a44"
CARD = "#24242c"
SW_W, SW_H = 46, 24
KNOB = "#f2f2f6"

COLORS = {
    "starting": "#8a8a95", "idle": "#8a8a95", "listening": "#3ddc84",
    "hearing": "#3ddc84", "thinking": "#4aa3ff", "sent": "#22d3ee",
    "copied": "#22d3ee", "paused": "#ffb020", "offline": "#ff5c5c",
    "focus": "#ffcf5c",
}
LABELS = {
    "starting": "启动中", "idle": "待唤醒", "listening": "在听你说",
    "hearing": "听到声音了", "thinking": "识别中", "sent": "已发送",
    "copied": "已识别", "paused": "已暂停", "offline": "未连接",
    "focus": "专注中", "sleepy": "打个盹",
}
VOICES = [
    # (edge 音色, 显示名, 变调, 特效)
    # 变调/特效是"做出那个味道"，不是原版音源 —— 曼波/奶龙那些是特定角色的音源，
    # 微软免费语音库里没有（想要真音色得本地跑语音克隆模型，那是另一步）。
    ("zh-CN-XiaoyiNeural", "晓伊 · 活泼女声", "", ""),
    ("zh-CN-XiaoyiNeural", "卡通高音 · 奶龙味（变声）", "+34Hz", ""),
    ("zh-CN-XiaoxiaoNeural", "晓晓 · 温柔女声", "", ""),
    ("zh-CN-XiaoxiaoNeural", "机器人 · 电子味（特效）", "-10Hz", "robot"),
    ("zh-CN-XiaoxiaoNeural", "老电台 · 沙沙味（特效）", "", "radio"),
    ("zh-CN-XiaoxiaoNeural", "山谷回音（特效）", "", "echo"),
    ("zh-CN-YunxiNeural", "云希 · 年轻男声", "", ""),
    ("zh-CN-YunxiNeural", "闷低音 · 曼波味（变声）", "-30Hz", ""),
    ("zh-CN-YunjianNeural", "云健 · 男声浑厚", "", ""),
    ("zh-CN-YunyangNeural", "云扬 · 男声播音", "", ""),
    ("zh-CN-YunxiaNeural", "云夏 · 男声少年", "+14Hz", ""),
    ("zh-CN-liaoning-XiaobeiNeural", "小北 · 东北话", "", ""),
    ("zh-CN-shaanxi-XiaoniNeural", "小妮 · 陕西话", "", ""),
    ("zh-HK-HiuMaanNeural", "晓曼 · 粤语", "", ""),
    ("zh-CN-YunxiNeural", "云希 · 台湾味（变调）", "+8Hz", ""),
    ("ja-JP-NanamiNeural", "七海 · 日语", "", ""),
    ("en-US-AriaNeural", "Aria · 英语女声", "", ""),
]


def _clone_entries() -> list[tuple[str, str, str, str]]:
    """本机装了语音克隆环境的话，把那些"真音色"也挂进音色列表。

    没装的机器上一律是空的（clone_voice.py 也不会跟着安装包发出去），
    所以别人的界面上根本不会出现这一栏。
    """
    try:
        import clone_voice

        return [(value, name, "", "") for value, name in clone_voice.models()]
    except Exception:
        return []


VOICES.extend(_clone_entries())
STARTUP_LNK = "语音助手（开机自启）.lnk"
FONT_FILES = [r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyhbd.ttc"]


_HEX_COLOR = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def safe_color(value, fallback: str) -> str:
    """配置里的颜色只认 #rgb / #rrggbb；写错了就退回默认值。

    以前不校验，config.json 里写个 "zzz" 会让 Tk 直接抛 unknown color name，
    悬浮窗一启动就崩——而配置文件是用户能手改的。
    """
    text = str(value or "").strip()
    return text if _HEX_COLOR.match(text) else fallback


def rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    if len(value) == 3:
        value = "".join(c * 2 for c in value)
    try:
        return int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16)
    except Exception:
        return 128, 128, 128


def hexs(color) -> str:
    return "#%02x%02x%02x" % tuple(int(max(0, min(255, round(c)))) for c in color)


def mix(a: str, b: str, t: float) -> str:
    ra, rb = rgb(a), rgb(b)
    return hexs(tuple(ra[i] + (rb[i] - ra[i]) * t for i in range(3)))


def shade(color: str, t: float) -> str:
    target = "#000000" if t < 0 else "#ffffff"
    return mix(color, target, abs(t))


def font(size: int, bold: bool = False):
    for path in ([FONT_FILES[1]] if bold else []) + FONT_FILES:
        try:
            return ImageFont.truetype(path, int(size))
        except Exception:
            continue
    return ImageFont.load_default()


def load_config() -> dict:
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def write_config(data: dict) -> None:
    try:
        CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def send_command(action: str) -> None:
    try:
        CONTROL.write_text(json.dumps({"action": action, "ts": time.time()}), encoding="utf-8")
    except Exception:
        pass


def note(text: str) -> None:
    """写一行启动/退出小日志。

    带个大小上限：万一哪次又出现"每帧都报同一个错"，
    日志最多长到 400KB 就自己裁到最近 1500 行，不会像上次那样堆到 3MB。
    """
    try:
        with EXIT_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%H:%M:%S')}] {text}\n")
        if EXIT_LOG.stat().st_size > 400_000:
            lines = EXIT_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
            EXIT_LOG.write_text("\n".join(lines[-1500:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def inputlog(text: str) -> None:
    """输入诊断日志：点击、拿到焦点、敲了哪个键，都记一行。

    以后你要是又说"打不进字"，我看这个文件就知道卡在哪一步——是没点中、
    没拿到焦点，还是拿到焦点又被别的东西抢走了。
    """
    try:
        with INPUT_LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{time.strftime('%H:%M:%S')}] {text}\n")
        if INPUT_LOG.stat().st_size > 300_000:      # 别无限长
            lines = INPUT_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
            INPUT_LOG.write_text("\n".join(lines[-800:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def startup_exists() -> bool:
    try:
        base = Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup"
        return (base / STARTUP_LNK).exists()
    except Exception:
        return False


def single_instance() -> bool:
    """同一时间只留一个悬浮窗。

    但是 —— 如果那个"已经在跑"的其实是**卡死/崩了没退干净的僵尸进程**，它占着
    互斥体不放，新开的悬浮窗就会安安静静地退出，用户看到的就是"永远没有悬浮窗"。
    所以这里加一道判断：回执文件（overlay_ready.json）超过 40 秒没更新，就当
    上一个是死的，照样起来。（活着的悬浮窗每 10 秒续一次回执。）
    """
    if os.name != "nt":
        return True
    stale = True
    try:
        data = json.loads(READY_FILE.read_text(encoding="utf-8"))
        stale = time.time() - float(data.get("ts") or 0) > 40
    except Exception:
        stale = True          # 连回执都没有 → 多半根本没有活的悬浮窗
    if stale:
        return True
    k = ctypes.windll.kernel32
    k.CreateMutexW(None, False, "VoiceAssistantOverlay_v1")
    return k.GetLastError() != 183


def make_no_activate(hwnd: int) -> None:
    u = ctypes.windll.user32
    style = u.GetWindowLongW(hwnd, -20)
    u.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x00000080)


def set_no_activate(hwnd: int, no_activate: bool) -> None:
    """开关 WS_EX_NOACTIVATE 位：不需要打字时它保证浮窗永不抢焦点，
    要打字时必须把它去掉，否则窗口拿不到键盘焦点、输入框打不进字。"""
    u = ctypes.windll.user32
    style = u.GetWindowLongW(hwnd, -20)
    if no_activate:
        style |= 0x08000000
    else:
        style &= ~0x08000000
    u.SetWindowLongW(hwnd, -20, style)


def virtual_screen() -> tuple[int, int, int, int]:
    """整个虚拟桌面（多显示器时是几块屏合起来的那一大片）。"""
    try:
        u = ctypes.windll.user32
        return (u.GetSystemMetrics(76), u.GetSystemMetrics(77),
                u.GetSystemMetrics(78), u.GetSystemMetrics(79))
    except Exception:
        return 0, 0, 1920, 1080


def grab_foreground(hwnd: int) -> bool:
    """把键盘焦点抢过来。

    Windows 默认不允许"后台程序"调用 SetForegroundWindow（会直接失败返回 0），
    浮窗平时又是刻意不抢焦点的，于是点输入框时经常抢不到 → 打字打不进去。
    标准绕法是先把本线程挂到当前前台窗口的输入队列上，抢完再摘下来。
    """
    if not hwnd:
        return False
    u = ctypes.windll.user32
    k = ctypes.windll.kernel32
    try:
        fg = u.GetForegroundWindow()
        my_thread = k.GetCurrentThreadId()
        fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
        attached = False
        if fg_thread and fg_thread != my_thread:
            attached = bool(u.AttachThreadInput(my_thread, fg_thread, True))
        u.ShowWindow(hwnd, 5)              # SW_SHOW
        u.BringWindowToTop(hwnd)
        ok = bool(u.SetForegroundWindow(hwnd))
        u.SetFocus(hwnd)
        if attached:
            u.AttachThreadInput(my_thread, fg_thread, False)
        return ok
    except Exception:
        try:
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
        return False


def process_alive(pid: int) -> bool:
    if not pid:
        return False
    k = ctypes.windll.kernel32
    handle = k.OpenProcess(0x1000, False, pid)
    if not handle:
        return False
    k.CloseHandle(handle)
    return True


class Overlay:
    def __init__(self) -> None:
        import tkinter as tk

        self.tk = tk
        self.cfg = load_config()
        self.cfg_mtime = CONFIG.stat().st_mtime if CONFIG.exists() else 0.0
        self.started = time.time()
        self.status: dict = {}
        self.miss = self.dead_hits = 0
        self._next_status = self._next_cfg = 0.0
        self.level = self.level_shown = 0.0
        self.breath = 0.0
        self.wave_phase = 0.0
        self.bar_heights: list[float] = []
        self.switch_pos = self.switch_target = 1.0
        self.state = "starting"
        self.text_fade = 1.0
        self.toast = ""
        self.toast_until = 0.0
        self.intro = 0.0
        self._drag = None
        self._sprites: dict = {}
        self._base = None
        self._base_key = None
        self._photo = None
        self.expanded = False
        self.alpha_override = None
        self.panel_h_shown = 0
        self.panel_h_natural = 0
        self.resize_from = None
        self._resize_key = None
        self.panel = None
        self.hint_label = None
        self._push_job = None
        # 声音条特效的运行时状态
        self.dt = 0.016
        self._sparks: list[dict] = []
        self._trail_img = None
        self._trail_key = None
        self._sweep_pos = 0.0
        self._sweep_base = None
        self.last_active = time.time()   # 养成：多久没人理它
        self.sleep_stage = 0             # 0 正常 / 1 打哈欠 / 2 睡着了
        self._pop = 0.0                  # 被叫醒时"弹一下"的强度
        self._frames = 0                 # 画了多少帧（配合帧时间判断要不要降级）
        self._frame_cost = 0.0           # 每帧平均画了多久
        self._auto_low = False           # 已经因为机器慢自动降过级了吗
        self._fx_before_low: dict | None = None   # 降级前你自己选的那套特效开关
        self._auto_low_off = False       # 你亲手把特效开回来了，这一轮就别再自动关
        self._degrade_stage = 0          # 0 没降 / 1 关了特效 / 2 连帧率也降了
        self._period = 0.0               # 帧间隔（上一帧开始到这一帧开始）
        self._gaps: list[float] = []     # 最近 60 帧的间隔，取中位数用
        self._slow_checks = 0            # 连着几次判定为"跟不上"
        self._started = time.time()      # 启动时刻：开机那段 CPU 尖峰不算数
        self.snap_edge = ""              # "" / left / right / top / bottom：吸在哪条边上
        self.hovered = False             # 鼠标是不是在窗口上（贴边时用它决定放大还是缩成小条）
        self.snap_on = True              # 贴边吸附总开关（设置里能关）
        self._panel_closing = False
        self.current_tab = "基本"
        self.wake_test_result = ""      # 最近一次唤醒词自检的结论
        self.focus_left = 0.0           # 番茄钟剩余秒数（0 = 没在专注）
        self.focus_total = 0.0          # 这一轮专注一共多久
        self.caption_win = None         # 大字幕窗口
        self.caption_label = None
        self.caption_last = ""
        self.caption_at = 0.0
        self.rec_win = None             # 录音提示灯
        self.editing_on = False          # 正在改设置？（这期间让主程序别抢键盘）
        self.wake_test_at = 0.0
        try:                            # 上次运行留下的自检结果不当成新的
            self._wake_test_ts = float(
                json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            self._wake_test_ts = 0.0
        self._wake_seen = str(self.cfg.get("wake_word") or "")   # 用来判断唤醒词有没有被改
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.cur_w = float(self.compact_w)
        self.cur_h = float(self.header_h)
        self.target_w, self.target_h = self.cur_w, self.cur_h

        x, y = self.load_pos()
        self.base_x, self.base_y = x, y
        # Windows 的定时器默认只有 ~15.6ms 的精度：after(16) 经常被拖到 23ms 才醒，
        # 60 帧根本跑不起来。目标帧率够高（>=50 帧）时才把精度提到 1ms，
        # 退出时还回去；节能/30 帧模式就不折腾了，省电。
        if os.name == "nt" and self.frame_ms <= 20:
            try:
                ctypes.windll.winmm.timeBeginPeriod(1)
                atexit.register(lambda: ctypes.windll.winmm.timeEndPeriod(1))
            except Exception:
                pass
        self.root = tk.Tk()
        self.root.title(self.name)
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.panel_color)
        self.root.geometry(f"{self.compact_w}x{self.header_h}+{x}+{y - 16}")
        self.root.attributes("-alpha", 0.0)
        self.root.update_idletasks()
        try:
            u = ctypes.windll.user32
            inner = self.root.winfo_id()
            make_no_activate(u.GetParent(inner) or inner)
            make_no_activate(inner)
        except Exception:
            pass

        self.canvas = tk.Canvas(self.root, width=self.compact_w, height=self.header_h,
                                bg=self.panel_color, highlightthickness=0)
        self.canvas.pack(side="top", fill="x")      # 宽度跟着窗口走，不用每帧单独设
        self._photo = ImageTk.PhotoImage(
            Image.new("RGB", (self.compact_w, self.header_h), self.panel_color))
        self.img_item = self.canvas.create_image(0, 0, anchor="nw", image=self._photo)
        self.canvas.bind("<Button-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.open_menu)
        for widget in (self.canvas, self.root):
            widget.bind("<MouseWheel>", self.on_wheel)

        self.menu = tk.Menu(self.root, tearoff=0, bg="#26262d", fg="#ffffff",
                            activebackground=self.button_color, activeforeground="#ffffff",
                            font=("Microsoft YaHei UI", 9))
        self.menu.add_command(label="只关浮窗（程序继续跑）", command=self.quit)
        self.menu.add_command(label="退出语音程序", command=self.quit_program)

        self.root.report_callback_exception = self.on_tk_error
        note(f"启动 pid={os.getpid()} 位置=({x},{y})")
        self.root.after(120, self.tick)
        self.root.after(self.frame_ms, self.anim)
        self.root.after(1500, self.maybe_first_run)
        self.root.after(4000, self.warm_panel)     # 闲着的时候先把设置面板备好

    def warm_panel(self) -> None:
        """开了一会儿之后，偷偷把设置面板建好、摆到窗口外面去（窗口小，看不见）。

        为了让你第一次点箭头就是顺的：建面板要 map 七百个控件，就地卡 0.6~1.1 秒，
        以前这 0.6 秒正好卡在展开动画中间，动画就"没了"。
        """
        if self.panel is not None:
            return
        try:
            self.build_panel()
            self._place_panel(self._expanded_h())
        except Exception as exc:  # noqa: BLE001
            note(f"预热设置面板失败：{type(exc).__name__}")

    def on_tk_error(self, exc_type, exc_value, exc_tb) -> None:
        import traceback

        note("回调异常: " + "".join(traceback.format_exception_only(exc_type, exc_value)).strip())
        try:
            # 写在"当前配置所在的那个目录"：正常就是程序目录；脚本测试时会把 CONFIG
            # 指到临时目录，报错就落在那儿，不会把真程序这条日志冲掉。
            (CONFIG.parent / "overlay-error.log").write_text(
                "".join(traceback.format_exception(exc_type, exc_value, exc_tb)), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------ 配置
    def cfg_get(self, key: str):
        return self.cfg.get(key, DEFAULTS.get(key))

    def apply_config(self) -> None:
        c = self.cfg
        self.name = str(c.get("name") or DEFAULTS["name"])
        # 颜色一律先过校验：写错了不让它崩，退回默认值
        self.panel_color = safe_color(c.get("overlay_color"), DEFAULTS["overlay_color"])
        self.accent = safe_color(c.get("overlay_accent"), DEFAULTS["overlay_accent"])
        self.button_color = safe_color(c.get("overlay_button"), DEFAULTS["overlay_button"])
        self.text_color = safe_color(c.get("overlay_text"), DEFAULTS["overlay_text"])
        self.talk_color = safe_color(c.get("overlay_talk_color"), DEFAULTS["overlay_talk_color"])
        self.bg_image = str(c.get("overlay_bg_image") or "")
        self.bg_dim = int(c.get("overlay_bg_dim") or DEFAULTS["overlay_bg_dim"])
        self.alpha = min(MAX_ALPHA, max(MIN_ALPHA, float(c.get("overlay_alpha") or DEFAULT_ALPHA)))
        self.W = int(c.get("overlay_width") or DEFAULTS["overlay_width"])
        self.H = int(c.get("overlay_height") or DEFAULTS["overlay_height"])
        self.show_name = bool(c.get("overlay_show_name", True))
        self.show_status = bool(c.get("overlay_show_status", True))
        self.show_line = bool(c.get("overlay_show_line", True))
        self.show_switch = bool(c.get("overlay_show_switch", True))
        self.line_follow = bool(c.get("overlay_line_follow_state", False))
        self.wave_style = str(c.get("overlay_wave_style") or "siri")
        # 声音条特效开关；节能模式下统一不画（你要求节能＝界面动画全关）
        self.fx = {key: bool(c.get(key, DEFAULTS[key])) for key in FX_KEYS}
        self.show_caption = bool(c.get("overlay_show_caption", True))
        self.caption_on = bool(c.get("caption_enabled", True))
        self.mood_on = bool(c.get("mood_enabled", True))
        self.mood_idle = bool(c.get("mood_idle", True))
        self.spectrum_on = bool(c.get("wave_spectrum", False))
        self.karaoke_on = bool(c.get("karaoke", True))
        self.big_on = bool(c.get("big_caption", False))
        self.big_size = max(16, min(72, int(c.get("big_caption_size") or 34)))
        self.rec_on = bool(c.get("rec_indicator", True))
        self.snap_on = bool(c.get("snap_edges", True))   # 贴边吸附总开关
        # 性能模式：eco 关界面动画、质量模式帧率拉满
        self.perf = str(c.get("perf_mode") or "quality")
        self.fps = max(15, min(60, int(c.get("anim_fps") or 60)))
        if self.perf == "eco":
            self.fps = min(self.fps, 20)
        elif self.perf == "standard":
            self.fps = min(self.fps, 40)
        self.frame_ms = max(8, int(1000 / self.fps))
        self.auto_tune = bool(c.get("auto_tune", True))   # 机器慢时要不要自动降级
        self.layout = {
            "name": (int(self.cfg_get("ov_name_x")), int(self.cfg_get("ov_name_y")),
                     int(self.cfg_get("ov_name_size"))),
            "status": (int(self.cfg_get("ov_status_x")), int(self.cfg_get("ov_status_y")),
                       int(self.cfg_get("ov_status_size"))),
            "switch": (int(self.cfg_get("ov_switch_x")), int(self.cfg_get("ov_switch_y"))),
            "wave": (int(self.cfg_get("ov_wave_y")), int(self.cfg_get("ov_wave_h"))),
        }

    def reload_config_if_changed(self) -> None:
        now = time.time()
        if now < self._next_cfg:
            return
        self._next_cfg = now + CONFIG_MS / 1000
        try:
            mtime = CONFIG.stat().st_mtime
        except OSError:
            return
        if mtime == self.cfg_mtime:
            return
        self.cfg_mtime = mtime
        self.cfg = load_config()
        self.apply_saved()

    def apply_saved(self) -> None:
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.target_w = float(self.expand_w if self.expanded else self.compact_w)
        self.target_h = self._expanded_h() if self.expanded else float(self.header_h)
        if self.expanded:
            self._place_panel(self.target_h)       # 尺寸/标签页变了，面板跟着摆正
        self._base_key = None
        self.root.title(self.name)
        self.root.configure(bg=self.panel_color)
        self.canvas.configure(bg=self.panel_color)
        self.menu.configure(activebackground=self.button_color)

    # ------------------------------------------------------------ 位置
    def load_pos(self) -> tuple[int, int]:
        try:
            data = json.loads(POS.read_text(encoding="utf-8"))
            self.snap_edge = str(data.get("snap") or "")
            return int(data["x"]), int(data["y"])
        except Exception:
            pass
        screen = 1920
        try:
            screen = ctypes.windll.user32.GetSystemMetrics(0)
        except Exception:
            pass
        return screen - 344 - 40, 60

    # ------------------------------------------------------------ 交互
    def on_press(self, event) -> None:
        if self.hit_arrow(event.x, event.y):
            self.set_expanded(not self.expanded)
            return
        if self.hit_switch(event.x, event.y):
            self.toggle_switch()
            return
        self._drag = (event.x_root - self.root.winfo_x(), event.y_root - self.root.winfo_y())

    def on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.base_x, self.base_y = event.x_root - dx, event.y_root - dy
        self.root.geometry(f"+{self.base_x}+{self.base_y}")

    def on_release(self, _event) -> None:
        self._drag = None
        self.try_snap()
        self.save_pos()

    def save_pos(self) -> None:
        try:
            POS.write_text(json.dumps({
                "x": self.root.winfo_x(), "y": self.root.winfo_y(),
                "snap": self.snap_edge,
            }), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------- 贴边吸附 / 简化版
    def simple_size(self) -> tuple:
        """贴边之后那条"简化版"的尺寸：竖边竖条、横边横条。"""
        if self.snap_edge in ("left", "right"):
            return SIMPLE_THICK, SIMPLE_LONG
        if self.snap_edge in ("top", "bottom"):
            return SIMPLE_LONG, SIMPLE_THICK
        return self.compact_w, self.header_h

    def simple_on(self) -> bool:
        """什么时候缩成小条：吸在边上 + 鼠标不在上面 + 没展开设置。"""
        return bool(self.snap_edge) and self.snap_on and not self.hovered \
            and not self.expanded and not self._drag

    def nearest_edge(self, x: int, y: int, w: int, h: int) -> str:
        vx, vy, vw, vh = virtual_screen()
        near = {"left": x - vx, "right": (vx + vw) - (x + w),
                "top": y - vy, "bottom": (vy + vh) - (y + h)}
        edge, dist = min(near.items(), key=lambda kv: kv[1])
        return edge if dist <= SNAP_PX else ""

    def try_snap(self) -> None:
        """松手之后看要不要吸到边上。"""
        if not self.snap_on or self.expanded:
            self.snap_edge = ""
            self.reset_target()
            return
        x, y = self.root.winfo_x(), self.root.winfo_y()
        self.snap_edge = self.nearest_edge(x, y, int(self.cur_w), int(self.cur_h))
        if self.snap_edge:
            self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            note(f"吸到{ {'left': '左边', 'right': '右边', 'top': '上边', 'bottom': '下边'}[self.snap_edge] }")
        else:
            self.reset_target()

    def reset_target(self) -> None:
        """不贴边了：把目标尺寸恢复成"平时的浮窗"（或者展开的面板）。

        不恢复的话，从边上拖走之后它还会一直按"小细条"的尺寸缩着。
        """
        if self.expanded:
            self.target_w = float(self.expand_w)
            self.target_h = self._expanded_h()
        else:
            self.target_w = float(self.compact_w)
            self.target_h = float(self.header_h)

    def dock_pos(self, w: float, h: float) -> tuple:
        """吸在边上时，窗口该待在哪儿（跟着尺寸走，缩成小条也不会飘走）。"""
        vx, vy, vw, vh = virtual_screen()
        x, y = int(self.base_x), int(self.base_y)
        if self.snap_edge == "left":
            return vx, min(max(y, vy), vy + vh - int(h))
        if self.snap_edge == "right":
            return vx + vw - int(w), min(max(y, vy), vy + vh - int(h))
        if self.snap_edge == "top":
            return min(max(x, vx), vx + vw - int(w)), vy
        if self.snap_edge == "bottom":
            return min(max(x, vx), vx + vw - int(w)), vy + vh - int(h)
        return x, y

    def clamp_on_screen(self, x: int, y: int, w: int, h: int) -> tuple:
        """展开设置面板之后别跑到屏幕外面去。"""
        vx, vy, vw, vh = virtual_screen()
        x = min(max(x, vx), max(vx, vx + vw - w))
        y = min(max(y, vy), max(vy, vy + vh - h))
        return x, y

    def watch_hover(self) -> None:
        """用指针位置判断鼠标在不在窗口上 —— 比 Enter/Leave 稳（子控件不会误报离开）。"""
        try:
            px, py = self.root.winfo_pointerxy()
        except Exception:
            return
        wx, wy = self.root.winfo_x(), self.root.winfo_y()
        self.hovered = (wx - 2 <= px <= wx + self.cur_w + 2
                        and wy - 2 <= py <= wy + self.cur_h + 2)

    def switch_rect(self) -> tuple[int, int]:
        """返回开关左上角。X 为负表示"离右边多远"，所以要减掉开关自身宽度。"""
        x, y = self.layout["switch"]
        x0 = (int(self.cur_w) + x - SW_W) if x < 0 else x
        return x0, y

    def hit_switch(self, x: int, y: int) -> bool:
        if not self.show_switch:
            return False
        x0, y0 = self.switch_rect()
        return x0 <= x <= x0 + SW_W and y0 <= y <= y0 + SW_H

    def hit_arrow(self, x: int, y: int) -> bool:
        ax = int(self.cur_w) - ARROW - 10
        ay = self.header_h - ARROW - 8
        return ax <= x <= ax + ARROW and ay <= y <= ay + ARROW

    def on_wheel(self, event) -> None:
        if not bool(self.cfg.get("wheel_alpha", True)):
            return
        delta = 0.02 if getattr(event, "delta", 0) > 0 else -0.02
        self.alpha = min(MAX_ALPHA, max(MIN_ALPHA, self.alpha + delta))
        data = load_config()
        data["overlay_alpha"] = round(self.alpha, 2)
        write_config(data)
        self.flash(f"透明度 {int(self.alpha * 100)}%")

    def toggle_switch(self) -> None:
        paused = self.status.get("state") == "paused"
        send_command("resume" if paused else "pause")
        self.flash("正在恢复…" if paused else "正在暂停…")

    def open_menu(self, event) -> None:
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def quit_program(self) -> None:
        send_command("quit")
        self.flash("已让语音程序退出")
        self.root.after(700, self.quit)

    def quit(self, reason: str = "用户关掉了浮窗") -> None:
        note(f"退出：{reason}")
        try:
            self.root.destroy()
        except Exception:
            pass

    def flash(self, text: str, seconds: float = 1.6) -> None:
        self.toast = text
        self.toast_until = time.time() + seconds

    # ------------------------------------------------------------ 贴图
    def switch_sprite(self, pos: float):
        p = round(pos * 40) / 40
        key = ("sw", p, self.button_color)
        sprite = self._sprites.get(key)
        if sprite is None:
            scale = 4
            big = (SW_W * scale, SW_H * scale)
            im = Image.new("RGBA", big, (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, big[0] - 1, big[1] - 1], radius=big[1] // 2,
                                fill=mix(shade(self.button_color, -0.45), self.button_color, p))
            pad, r = 3 * scale, (SW_H - 6) / 2 * scale
            x0 = pad + (big[0] - 2 * pad - 2 * r) * p
            cy = big[1] / 2
            d.ellipse([x0, cy - r, x0 + 2 * r, cy + r], fill=KNOB)
            sprite = im.resize((SW_W, SW_H), Image.LANCZOS)
            self._sprites[key] = sprite
        return sprite

    def ball_sprite(self, color: str, radius: float):
        r = max(1.0, round(radius * 2) / 2)
        key = ("ball", color, r)
        sprite = self._sprites.get(key)
        if sprite is None:
            size = int(r * 2) + 8
            scale = 4
            im = Image.new("RGBA", (size * scale, size * scale), (0, 0, 0, 0))
            c = size * scale / 2
            rr = r * scale
            ImageDraw.Draw(im).ellipse([c - rr, c - rr, c + rr, c + rr], fill=color)
            sprite = im.resize((size, size), Image.LANCZOS)
            self._sprites[key] = sprite
        return sprite

    # ------------------------------------------------------------ 底图
    def base_image(self) -> Image.Image:
        w, h = int(round(self.cur_w)), self.header_h
        key = (w, h, self.panel_color, self.bg_image, self.bg_dim, self.name,
               self.show_name, self.layout["name"], self.text_color)
        if self._base is None or self._base_key != key:
            im = Image.new("RGB", (w, h), self.panel_color)
            bg_path = Path(self.bg_image) if self.bg_image else None
            if bg_path is not None and not bg_path.is_absolute():
                bg_path = HERE / bg_path          # 支持随程序走的相对路径
            if bg_path is not None and bg_path.exists():
                try:
                    bg = Image.open(bg_path).convert("RGB")
                    ratio = max(w / bg.width, h / bg.height)
                    bg = bg.resize((max(1, int(bg.width * ratio)), max(1, int(bg.height * ratio))),
                                   Image.LANCZOS)
                    left, top = (bg.width - w) // 2, (bg.height - h) // 2
                    bg = bg.crop((left, top, left + w, top + h))
                    if self.bg_dim > 0:
                        bg = Image.blend(bg, Image.new("RGB", bg.size, (0, 0, 0)),
                                         self.bg_dim / 100)
                    im = bg
                except Exception:
                    pass
            d = ImageDraw.Draw(im)
            d.rectangle([0, 0, w - 1, h - 1], outline=BORDER)
            if self.show_name:
                nx, ny, nsize = self.layout["name"]
                d.text((nx, ny), self.name, font=font(nsize, bold=True), fill=self.text_color)
            self._base, self._base_key = im, key
        return self._base

    def draw_arrow(self, d: ImageDraw.ImageDraw, w: int) -> None:
        ax = w - ARROW - 10
        ay = self.header_h - ARROW - 8
        cx, cy = ax + ARROW / 2, ay + ARROW / 2
        color = mix(self.panel_color, self.text_color, 0.75)
        if self.expanded:
            d.line([(cx - 7, cy + 4), (cx, cy - 4), (cx + 7, cy + 4)],
                   fill=color, width=2, joint="curve")
        else:
            d.line([(cx - 7, cy - 4), (cx, cy + 4), (cx + 7, cy - 4)],
                   fill=color, width=2, joint="curve")

    # ------------------------------------------------------------ 声音条
    def draw_caption(self, d: ImageDraw.ImageDraw, w: int, wave_top: int,
                     spoken: str = "", progress: float = 0.0) -> None:
        """实时字幕：把你正在说的话（或刚发出去的那句）压在声音条上方。"""
        if not (self.show_caption and self.caption_on):
            return
        karaoke = bool(self.karaoke_on and spoken)
        text = spoken if karaoke else str((self.status or {}).get("text") or "").strip()
        if not text and self.focus_left > 0:      # 专注中：字幕位就让给倒计时
            left = int(self.focus_left)
            text = f"专注 {left // 60:02d}:{left % 60:02d}"
        if not text:
            return
        if len(text) > 42:
            text = text[:41] + "…"
        f = font(13)
        box = d.textbbox((0, 0), text, font=f)
        tw, th = box[2] - box[0], box[3] - box[1]
        y = wave_top - th - 6
        if y < 20:                       # 上方实在没空就不画，别压到名字上
            return
        x = max(6, (w - tw) / 2)
        d.rounded_rectangle([x - 9, y - 3, x + tw + 9, y + th + 4], radius=7,
                            fill=mix(self.panel_color, "#000000", 0.35))
        d.text((x + 1, y + 1), text, font=f, fill="#000000")
        if karaoke:
            # 逐字跟读：念到哪儿，前面那截就亮到哪儿；后面那截先暗暗地摆着
            cut = max(0, min(len(text), int(round(len(text) * progress))))
            head, tail = text[:cut], text[cut:]
            d.text((x, y), head, font=f, fill=self.text_color)
            if tail:
                offset = d.textlength(head, font=f)
                d.text((x + offset, y), tail, font=f,
                       fill=mix(self.panel_color, self.text_color, 0.38))
        else:
            d.text((x, y), text, font=f, fill=self.text_color)

    def draw_spectrum(self, im: Image.Image, d: ImageDraw.ImageDraw, color: str,
                      bands: list) -> None:
        """音浪：把声音条换成一排跟着音乐跳的柱子。"""
        if not self.show_line or not bands:
            return
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        count = len(bands)
        left, right = 18, im.width - 18
        step = (right - left) / count
        bar_w = max(3.0, step * 0.44)
        for i, value in enumerate(bands):
            frac = max(0.0, min(1.0, float(value)))
            # 平滑一点，别一帧一个样
            key = "_band_shown"
            shown = getattr(self, key, None)
            if shown is None or len(shown) != count:
                shown = [0.0] * count
            shown[i] += (frac - shown[i]) * 0.4
            setattr(self, key, shown)
            h = max(3.0, (height - 4) * shown[i])
            x0 = left + i * step + (step - bar_w) / 2
            d.rounded_rectangle([x0, bottom - h, x0 + bar_w, bottom],
                                radius=bar_w / 2, fill=color)

    def draw_focus(self, im: Image.Image, d: ImageDraw.ImageDraw, color: str,
                   elapsed: float) -> None:
        """番茄钟：把声音条换成一根越来越短、越来越红的进度条。"""
        if not self.show_line:
            return
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        left, right = 20, im.width - 20
        cy = bottom - height / 2
        bar_h = max(6.0, min(13.0, height * 0.24))
        d.rounded_rectangle([left, cy - bar_h / 2, right, cy + bar_h / 2],
                            radius=bar_h / 2, fill=mix(self.panel_color, "#ffffff", 0.14))
        frac = max(0.0, min(1.0, 1.0 - elapsed))
        if frac <= 0.002:
            return
        end = left + (right - left) * frac
        hot = mix(color, "#ff5c5c", min(1.0, max(0.0, elapsed - 0.6) / 0.4))
        d.rounded_rectangle([left, cy - bar_h / 2, max(left + bar_h, end), cy + bar_h / 2],
                            radius=bar_h / 2, fill=hot)
        r = bar_h * (0.75 + 0.3 * (0.5 + 0.5 * math.sin(self.breath * 2.4)))
        d.ellipse([end - r, cy - r, end + r, cy + r], fill=mix(hot, "#ffffff", 0.55))

    def draw_voice(self, im: Image.Image, color: str) -> None:
        """声音条：以音量为驱动，在"中间小圆点"和"整条波形"之间连续形变。

        t=0 全是小圆点，t=1 是铺满的波形；中间过程是平滑生长（不是阈值切换）。
        画完条之后再叠各种可选特效（视觉暂留、光晕、星尘、倒影、流光）。
        """
        if not self.show_line:
            return
        w = im.width
        gap, height = self.layout["wave"]
        bottom = im.height - gap
        top = bottom - height
        level = max(0.0, min(1.0, self.level_shown * 1.25))
        raw = max(0.0, min(1.0, (level - 0.02) / 0.16))
        t = raw * raw * (3 - 2 * raw)          # smoothstep：两端更柔和
        dot_w = max(10.0, height * 0.55)
        if self.sleep_stage >= 2:               # 睡着了：缩成小小一颗、颜色也淡下去
            color = mix(color, self.panel_color, 0.45)
            dot_w *= 0.78
        if self._pop > 0:                       # 被叫醒：先弹一下
            dot_w *= 1.0 + 0.5 * self._pop
        eff_w = dot_w + (w - dot_w) * t
        thick = ((height * 0.62) * (1 - t) + 2.6 * t) * (1 + 0.4 * self._pop)
        strip = self.render_voice(int(eff_w), height, level, t, thick, color)
        x = int((w - strip.width) / 2)
        y = int(top + (height - strip.height) / 2)
        fx = self.fx if self.perf != "eco" else {}
        talk_now = t > 0.08                 # 真的在出声音（不是静止的小圆点）

        if self.sleep_stage >= 2 and t < 0.3:   # 睡着时飘两个 z
            zd = ImageDraw.Draw(im)
            fz = font(11)
            for i, (dx, dy) in enumerate(((8, -12), (17, -23))):
                zd.text((x + strip.width / 2 + dx, y + dy + math.sin(self.breath + i) * 2),
                        "z", font=fz, fill=mix(self.panel_color, "#ffffff", 0.5 - 0.15 * i))

        # 0) 呼吸光晕：顺着"当前这个形状"往外铺一层柔光 —— 有声音时贴着长条，
        #    没声音时就裹着那颗小圆点（"圆点只留光晕，光晕也要夹在长条上"）
        if fx.get("fx_glow"):
            self._draw_shape_glow(im, strip, x, y, color, t)
        # 1) 视觉暂留：攒一层会慢慢褪色的残影，垫在清晰的声音条下面
        if fx.get("fx_trail"):
            self._draw_trail(im, strip, x, y - top, w, height, top, bottom)
        # 2) 倒影：把声音条上下翻过来，淡淡地贴在下面
        if fx.get("fx_reflection"):
            self._draw_reflection(im, strip, x, y + strip.height,
                                  0.30 if talk_now else 0.16)
        im.paste(strip, (x, y), strip)
        # 3) 流光：一道高光沿着声音条扫过去
        if fx.get("fx_sweep") and talk_now:
            layer = Image.new("RGBA", strip.size, (255, 255, 255, 255))
            layer.putalpha(ImageChops.multiply(strip.getchannel("A"),
                                               self._sweep_mask(strip.width, strip.height)))
            im.paste(layer, (x, y), layer)
        # 4) 星尘：说话时溅出去的小亮点
        if fx.get("fx_sparkles"):
            self._draw_sparkles(im, x, y, strip, level, t, color)
        # 5) 没声音的时候（就是那颗小圆点）：呼吸、光晕、一圈圈荡开的波纹、偶尔星尘
        if not talk_now:
            # 小圆点的半径要按"真正画出来的那一坨"算：strip 是 width×height 的
            # 透明画布，圆点只占中间一块，拿画布尺寸当半径会让特效大出一圈、
            # 直接被窗口边缘切掉。
            cxd = x + strip.width / 2.0
            cyd = y + strip.height / 2.0
            bb = strip.getbbox() or (0, 0, strip.width, strip.height)
            dot_r = max(4.0, max(bb[2] - bb[0], bb[3] - bb[1]) / 2.0)
            # 上下左右能画到哪儿：特效再大也不许跑出窗口（不然只剩几根断弧）
            avail = max(dot_r + 5.0, min(cxd, im.width - cxd, cyd,
                                        im.height - cyd - 2.0))
            self._draw_dot_fx(im, cxd, cyd, dot_r, color, fx, avail)

    @staticmethod
    def _rgba(hexcolor: str, alpha: float) -> tuple:
        h = str(hexcolor or "#ffffff").lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        try:
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
        except Exception:
            r = g = b = 255
        return (r, g, b, max(0, min(255, int(alpha))))

    @staticmethod
    def _hue(hexcolor: str, phase: float) -> str:
        """把颜色在色环上转 phase 圈（0~1），用来做极光那种缓慢换色。"""
        import colorsys

        h = str(hexcolor or "#ffffff").lstrip("#")
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        try:
            r, g, b = (int(h[0:2], 16) / 255.0, int(h[2:4], 16) / 255.0,
                       int(h[4:6], 16) / 255.0)
        except Exception:
            r = g = b = 1.0
        hh, ss, vv = colorsys.rgb_to_hsv(r, g, b)
        # 纯灰的默认色相是 0，转起来会一眼红；给点最低饱和度，换色才看得出来
        hh = (hh + phase) % 1.0
        rr, gg, bb = colorsys.hsv_to_rgb(hh, max(ss, 0.55), vv)
        return "#%02x%02x%02x" % (int(rr * 255 + 0.5), int(gg * 255 + 0.5),
                                  int(bb * 255 + 0.5))

    def _beat(self) -> float:
        """心跳包络：一个周期里"咚—咚"两下，第二下比第一下轻一点。"""
        t = (self.breath * 1.6 / (2 * math.pi)) % 1.0
        out = 0.0
        for at, gain, span in ((0.0, 1.0, 0.20), (0.26, 0.72, 0.16)):
            dt = (t - at) % 1.0
            if dt < span:
                out = max(out, math.sin((1 - dt / span) * math.pi) * gain)
        return out

    def _draw_dot_fx(self, im: Image.Image, cx: float, cy: float, r: float,
                     color: str, fx: dict, avail: float | None = None) -> None:
        """小圆点的特效能：呼吸光晕、荡开的波纹、星尘，还有后来加的一堆花样。

        小圆点＝声音条完全收起来、没声音时的那个状态，所以这里的特效都只在
        "安静"的时候看得到；用户说"给小圆点也加点特效"，就照着一颗小球的
        感觉往上面叠：极光柔光、会转的光环、两颗粒子绕着飞、星芒、心跳、
        被叫醒那一下的爆闪。

        avail 是"从圆心到窗口边还剩多少像素"，所有半径都会被它夹住——
        不然光环比窗口还大，就只剩几根断弧挂在边上。
        """
        if r <= 0 or not fx:
            return
        reach = float(avail) if avail else r * 3.4

        def cap(value: float, slack: float = 1.0) -> float:
            return min(value, reach * slack)

        aura = Image.new("RGBA", im.size, (0, 0, 0, 0))
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        breath = 0.5 + 0.5 * math.sin(self.breath * 1.5)

        # ① 极光：垫在最底下，一层会慢慢换色的柔光（颜色沿着色环走）
        if fx.get("fx_aurora"):
            # 只在本色附近来回晃一点点（±25°），不搞整圈彩虹 —— 转整圈会飘到
            # 紫色/粉色上去，跟主题色对不上
            wobble = 0.07 * math.sin(self.breath * 0.02)
            hue = self._hue(mix(self.panel_color, color, 0.75), wobble)
            ad = ImageDraw.Draw(aura)
            for mult, alpha in ((2.05, 40), (1.45, 62)):
                rr = cap(r * (mult + 0.16 * breath), 0.92)
                ad.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                           fill=self._rgba(hue, alpha))
            aura = aura.filter(ImageFilter.GaussianBlur(max(2.5, r * 0.55)))
        # ② 旋转光环：一圈会自己转的虚线光环（转得很慢，像在待机）
        if fx.get("fx_rotor"):
            seg = 12
            rot = math.degrees(self.breath * 0.28)
            rr = cap(r * (1.72 + 0.10 * breath), 0.95)
            for i in range(0, seg, 2):
                a0 = rot + i * (360.0 / seg)
                if hasattr(d, "arc"):
                    d.arc([cx - rr, cy - rr, cx + rr, cy + rr], a0,
                          a0 + (360.0 / seg) * 0.60, fill=self._rgba(color, 150),
                          width=2)
        # 呼吸光晕不在这儿画：它走 _draw_shape_glow，跟长条共用一套（这样圆点就是
        # 一团柔光，长条就是一条顺着形状的光带，两个状态看着才是一回事）
        if fx.get("fx_ripple"):
            for k in (0.0, 0.5):                 # 两圈错开，看着像一直往外荡
                p = (self.breath * 0.32 + k) % 1.0
                rr = cap(r * (1.3 + 2.6 * p), 1.0)
                a = 95 * (1 - p) ** 1.6
                if a > 4:
                    d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                              outline=self._rgba(color, a))
        # ③ 心跳：圆点像心跳那样"咚—咚"地脉动，多一圈跟着涨缩的亮环
        if fx.get("fx_heartbeat"):
            p = self._beat()
            if p > 0.02:
                rr = cap(r * (1.22 + 0.72 * p), 1.0)
                d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr],
                          outline=self._rgba(mix(self.panel_color, color, 0.62),
                                             125 * p), width=2)
        # ④ 星芒：十字形的亮光，随呼吸一明一暗
        if fx.get("fx_starflare"):
            fl = 0.45 + 0.55 * breath
            for ang in (0.0, math.pi / 2, math.pi, math.pi * 1.5):
                ln = cap(r * (1.55 + 1.15 * fl), 1.05)
                d.line([cx + math.cos(ang) * r * 0.85, cy + math.sin(ang) * r * 0.85,
                        cx + math.cos(ang) * ln, cy + math.sin(ang) * ln],
                       fill=self._rgba(mix(color, "#ffffff", 0.35), 45 + 95 * fl),
                       width=2)
        # ⑤ 卫星：两颗小卫星一快一慢地绕着圆点转，各自拖一条短短的光尾
        if fx.get("fx_orbit"):
            for i, (speed, rad, tint) in enumerate(((0.52, 1.78, 0.0),
                                                    (-0.34, 2.26, 0.38))):
                ang = self.breath * speed + i * 2.6
                orb = cap(r * (rad + 0.06 * breath), 0.98)
                ox = cx + math.cos(ang) * orb
                oy = cy + math.sin(ang) * orb
                trail_tint = self._hue(color, tint) if fx.get("fx_aurora") else color
                for k in range(4):                       # 尾巴：越往后越淡越小
                    ta = ang - math.copysign(k * 0.20, speed)
                    tx = cx + math.cos(ta) * orb
                    ty = cy + math.sin(ta) * orb
                    sz = 1.5 - 0.28 * k
                    if sz <= 0:
                        continue
                    d.ellipse([tx - sz, ty - sz, tx + sz, ty + sz],
                              fill=self._rgba(trail_tint, 95 - 22 * k))
                d.ellipse([ox - 1.9, oy - 1.9, ox + 1.9, oy + 1.9],
                          fill=self._rgba("#ffffff", 215))
        # ⑥ 星尘：偶尔往上飘的小亮点
        if fx.get("fx_sparkles"):
            for i in range(2):
                p = (self.breath * 0.11 + i * 0.5) % 1.0
                a = 130 * (1 - p)
                if a > 8:
                    dx = math.sin(self.breath * 0.9 + i * 2.1) * cap(r + 8 + 15 * p, 1.1)
                    dy = -p * min(18.0, reach) + math.cos(self.breath * 0.7 + i) * 4
                    d.ellipse([cx + dx - 1.4, cy + dy - 1.4,
                               cx + dx + 1.4, cy + dy + 1.4],
                              fill=self._rgba(color, a))
        # ⑦ 唤醒爆闪：被叫醒（_pop 从 1 掉到 0）那半秒，炸出一圈往外飞的小火星
        if fx.get("fx_burst") and self._pop > 0.02:
            p = self._pop
            for i in range(12):
                ang = i * (2 * math.pi / 12) + 0.4
                dist = cap(r * (1.05 + 3.6 * (1 - p)), 1.2)
                dx = cx + math.cos(ang) * dist
                dy = cy + math.sin(ang) * dist
                sz = 1.1 + 2.1 * p
                d.ellipse([dx - sz, dy - sz, dx + sz, dy + sz],
                          fill=self._rgba(mix(color, "#ffffff", 0.3), 225 * p))
        if aura.getbbox():
            layer = Image.alpha_composite(aura, layer)
        if layer.getbbox():
            try:
                im.paste(Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB"), (0, 0))
            except Exception:
                pass

    def _draw_shape_glow(self, im: Image.Image, strip: Image.Image, x: int, y: int,
                         color: str, t: float) -> None:
        """呼吸光晕：按"形状"往外铺的柔光（长条就是一条长光带，圆点就是一团圆光）。

        以前这层光是在声音条自己那张小图上糊一层模糊再贴回去的 —— 图就条那么大，
        光一冒出边界就被裁掉了，等于白做（所以看着像"没有光晕"）。现在挪到整块画布
        上：把形状的透明通道往外扩一圈、模糊、染成主题色，垫在形状底下，
        光就会顺着条的轮廓铺开；那颗小圆点走的是同一条路，于是圆点只剩一团光晕。
        """
        if strip.width <= 0 or strip.height <= 0:
            return
        pad = int(max(5.0, strip.height * 0.55))
        wide = Image.new("RGBA",
                         (strip.width + pad * 2, strip.height + pad * 2),
                         (0, 0, 0, 0))
        wide.paste(strip, (pad, pad), strip)
        breathe = 0.72 + 0.28 * (0.5 + 0.5 * math.sin(self.breath * 1.6))
        alpha = int((124 - 38 * t) * breathe)     # 小圆点亮一点，长条淡一点
        glow = wide.copy()
        glow.putalpha(wide.getchannel("A").point(lambda v: min(255, v * alpha // 255)))
        glow = glow.filter(ImageFilter.GaussianBlur(max(2.0, strip.height * 0.22)))
        solid = Image.new("RGBA", glow.size, self._rgba(color, 0))
        solid.putalpha(glow.getchannel("A"))
        self._paste_clipped(im, solid, x - pad, y - pad)

    # -------------------------------------------------- 特效小工具
    @staticmethod
    def _fade_alpha(img: Image.Image, factor: float) -> Image.Image:
        out = img.copy()
        out.putalpha(img.getchannel("A").point(lambda v: int(v * factor)))
        return out

    @staticmethod
    def _paste_clipped(dst: Image.Image, src: Image.Image, x: int, y: int) -> None:
        """按目标边界裁一下再贴，避免超出窗口时报错。"""
        x0, y0 = max(0, x), max(0, y)
        x1 = min(dst.width, x + src.width)
        y1 = min(dst.height, y + src.height)
        if x1 <= x0 or y1 <= y0:
            return
        part = src.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        dst.paste(part, (x0, y0), part)

    def _draw_trail(self, im: Image.Image, strip: Image.Image, sx: int, sy: int,
                    w: int, height: int, top: int, bottom: int) -> None:
        """视觉暂留：每帧先把旧的残影淡一点点，再把当前这一帧盖上去。"""
        key = (w, height)
        if self._trail_img is None or self._trail_key != key:
            self._trail_img = Image.new("RGBA", (w, height), (0, 0, 0, 0))
            self._trail_key = key
        # 按时间褪色：帧率调高低都是同样的拖尾长度
        decay = 0.80 ** max(0.25, self.dt / 0.016)
        a = self._trail_img.getchannel("A").point(lambda v: int(v * decay))
        self._trail_img.putalpha(a)
        self._trail_img.alpha_composite(strip, (sx, sy))
        base = im.crop((0, top, w, bottom)).convert("RGBA")
        im.paste(Image.alpha_composite(base, self._trail_img).convert("RGB"), (0, top))

    def _sweep_mask(self, w: int, h: int) -> Image.Image:
        """一道柔和的竖向高光，沿着条来回扫：来回是因为来回两头都没有跳变。"""
        pos = 1.0 - abs(2.0 * (self._sweep_pos % 1.0) - 1.0)     # 乒乓往复
        width = 0.24
        row = Image.new("L", (w, 1))
        px = row.load()
        for i in range(w):
            u = i / max(1, w - 1)
            v = max(0.0, 1.0 - abs(u - pos) / width)
            px[i, 0] = int(v * v * 244)
        return row.resize((w, h))

    def _draw_reflection(self, im: Image.Image, strip: Image.Image, x: int,
                         mirror_y: int, alpha: float) -> None:
        """倒影：上下翻一份压扁的淡影，贴在声音条正下方那点空隙里。"""
        room = im.height - mirror_y - 1
        if room < 6:
            return
        want = max(6, min(room, int(strip.height * 0.42)))
        refl = strip.transpose(Image.FLIP_TOP_BOTTOM).resize(
            (strip.width, want), Image.LANCZOS)
        self._paste_clipped(im, self._fade_alpha(refl, alpha), x, mirror_y + 1)

    def _draw_sparkles(self, im: Image.Image, x: int, y: int, strip: Image.Image,
                       level: float, t: float, color: str) -> None:
        """星尘：声音越大冒得越多；用完自己会飘走、变小、消失。"""
        import random

        a = strip.getchannel("A")
        box = a.getbbox()
        if self.perf == "eco":
            return
        # 生成：只在"有声音"的时候冒
        want = int(level * t * 2.2)
        for _ in range(max(0, min(3, want))):
            if len(self._sparks) >= 46 or box is None:
                break
            px = random.randint(box[0], max(box[0], box[2] - 1))
            self._sparks.append({
                "x": x + px, "y": y + random.uniform(box[1], box[3]),
                "vx": random.uniform(-14, 14), "vy": random.uniform(-34, -14),
                "life": 1.0, "r": random.uniform(0.8, 1.9), "hue": random.random(),
            })
        if not self._sparks:
            return
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(layer)
        alive = []
        for p in self._sparks:
            p["life"] -= self.dt * 1.15
            if p["life"] <= 0:
                continue
            p["x"] += p["vx"] * self.dt
            p["y"] += p["vy"] * self.dt
            p["vy"] += 26 * self.dt                 # 稍微减速，像真的飘上去
            fade = p["life"] ** 1.6
            col = mix(color, "#ffffff", 0.25 + 0.5 * p["hue"])
            r, g, b = rgb(col)
            rad = p["r"] * (0.6 + 0.8 * fade)
            d.ellipse([p["x"] - rad, p["y"] - rad, p["x"] + rad, p["y"] + rad],
                      fill=(r, g, b, int(200 * fade)))
            alive.append(p)
        self._sparks = alive[-46:]
        layer = layer.filter(ImageFilter.GaussianBlur(1.1))
        im.paste(Image.alpha_composite(im.convert("RGBA"), layer).convert("RGB"), (0, 0))

    def render_voice(self, width: int, height: int, level: float, t: float,
                     thick: float, color: str) -> Image.Image:
        """按当前样式把声音条画到一张小图上（2 倍超采样 + 柔光）。"""
        width = max(12, width)
        scale = 2
        strip = Image.new("RGBA", (width * scale, height * scale), (0, 0, 0, 0))
        d = ImageDraw.Draw(strip)
        mid = height * scale / 2
        amp = (1.0 + level * (height / 2 - 3)) * scale * (0.35 + 0.65 * t)

        if self.wave_style == "bars":
            count = max(3, min(56, int(width / 7)))
            step = (width * scale) / count
            bar_w = max(2.0 * scale, step * 0.42)
            max_h = max(4.0, height - 2) * scale
            if len(self.bar_heights) != count:
                self.bar_heights = [0.0] * count
            for i in range(count):
                c = (i - (count - 1) / 2) / max(1.0, (count - 1) / 2)
                bulge = 0.18 + 0.82 * math.cos(c * 1.15) ** 2
                wobble = 0.5 + 0.5 * math.sin(self.wave_phase * 1.7 + i * 0.55)
                target = (2.0 + level * (max_h / scale - 2) * bulge * wobble) * scale
                self.bar_heights[i] += (target - self.bar_heights[i]) * 0.25
                bar_h = max(2.4 * scale, self.bar_heights[i])
                x0 = i * step + (step - bar_w) / 2
                d.rounded_rectangle([x0, height * scale - bar_h, x0 + bar_w, height * scale],
                                    radius=bar_w / 2, fill=color)
            return self._glow(strip, t).resize((width, height), Image.LANCZOS)

        # 一条中心线 + 沿线变化的厚度，用多边形填充：
        # t=0 时厚度剖面是中间鼓起的圆点，t=1 时变成两端收窄的细带，中间过程连续变形。
        total = width * scale
        count = max(12, min(160, total // 2))
        pts = []
        for i in range(count + 1):
            u = i / count
            env = math.sin(math.pi * u) ** 0.55                 # 两端收窄
            ph = self.wave_phase
            wob = (math.sin(u * 7.6 - ph * 1.35) * 0.72
                   + math.sin(u * 13.9 + ph * 2.05) * 0.28)
            cy = mid - env * amp * wob
            bump = math.sin(math.pi * u) ** 0.45                 # 圆点的"鼓包"
            half = (thick * scale / 2) * ((1 - t) * bump + t * max(0.18, env))
            pts.append((u * total, cy, max(0.7 * scale, half)))
        poly = [(x, cy - hw) for x, cy, hw in pts] + \
               [(x, cy + hw) for x, cy, hw in reversed(pts)]
        d.polygon(poly, fill=color)
        return self._glow(strip, t).resize((width, height), Image.LANCZOS)

    def _glow(self, strip: Image.Image, t: float) -> Image.Image:
        """（留着这个函数名，实际不在这儿加光了。）

        光晕改成在整块画布上画（见 _draw_shape_glow）—— 这里是声音条自己的小图，
        光一冒出边界就被裁掉，长条外面根本看不到光。
        """
        return strip

    # ------------------------------------------------------------ 状态
    def read_status(self) -> dict:
        try:
            return json.loads(STATUS.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def handle_remote(self) -> None:
        try:
            data = json.loads(CONTROL.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_ctrl_ts", 0.0):
            return
        self._ctrl_ts = ts
        action = str(data.get("action") or "")
        if action == "expand":
            self.set_expanded(True)
        elif action == "collapse":
            self.set_expanded(False)
        elif action == "qr":
            # 别的窗口 / 托盘 / 手机入口也能叫它把连接二维码弹出来
            self.show_qr()
        elif action == "perf":
            # 把当前的真实帧率情况写出来（用来量"到底卡不卡"，不用瞎猜）
            gaps = list(self._gaps)
            gaps.sort()
            med = gaps[len(gaps) // 2] * 1000 if gaps else 0.0
            p90 = gaps[int(len(gaps) * 0.9)] * 1000 if gaps else 0.0
            try:
                (HERE / "perf.json").write_text(json.dumps({
                    "目标帧率": self.fps, "帧预算ms": round(self.frame_ms, 1),
                    "中位间隔ms": round(med, 1),
                    "p90间隔ms": round(p90, 1),
                    "最差间隔ms": round(gaps[-1] * 1000, 1) if gaps else 0.0,
                    "实际帧率": round(1000 / med, 1) if med else 0.0,
                    "画一帧ms": round(self._frame_cost * 1000, 1),
                    "已降级": self._degrade_stage,
                    "特效": {k: v for k, v in self.fx.items() if k.startswith("fx_")},
                    "窗口": f"{int(self.cur_w)}x{int(self.cur_h)}",
                    "ts": time.time(),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    def tick(self) -> None:
        self.reload_config_if_changed()
        self.handle_remote()
        self.poll_wake_test()
        self.sync_big_caption()
        self.sync_rec_dot()
        # 编辑状态别一直挂着：90 秒没敲字就自动让位（免得它永远不粘了）
        if self.editing_on and time.time() - getattr(self, "edit_touch", 0) > 90:
            self.set_editing(False)
        data = self.read_status()
        if data:
            self.miss = 0
            self.status = data
        else:
            self.miss += 1
            if self.miss == 40:
                note(f"连续 {self.miss} 次读不到 status.json")
        state = (self.status or {}).get("state") or "offline"
        self.state = state
        self.level = float((self.status or {}).get("level") or 0.0)
        self.focus_left = float((self.status or {}).get("focus") or 0.0)
        if self.focus_left <= 0:
            self.focus_total = 0.0
        elif self.focus_total <= 0 or self.focus_left > self.focus_total + 0.5:
            self.focus_total = self.focus_left      # 新的一轮专注
        self.switch_target = 0.0 if state == "paused" else 1.0
        if self.status:
            pid = int(self.status.get("pid") or 0)
            if time.time() - self.started > 8 and not process_alive(pid):
                self.dead_hits += 1
                if self.dead_hits >= 4:
                    note(f"退出：主程序不在了（pid={pid}）")
                    self.quit()
                    return
            else:
                self.dead_hits = 0
        elif self.miss >= 80:
            note("退出：连续读不到状态文件")
            self.quit()
            return
        self.root.after(STATUS_MS, self.tick)

    # ------------------------------------------------------------ 画面
    def anim(self) -> None:
        frame_t0 = time.perf_counter()
        now_t = time.time()
        self.dt = min(0.1, max(0.0, now_t - getattr(self, "_frame_t", now_t)))
        self._frame_t = now_t
        self._sweep_pos = (self._sweep_pos + self.dt * 0.55) % 1.0

        if self.intro < 1.0:
            self.intro = min(1.0, self.intro + 0.09)
            ease = 1 - (1 - self.intro) ** 3
            self.root.geometry(f"+{self.base_x}+{int(self.base_y - 16 * (1 - ease))}")
            self.root.attributes("-alpha", self.alpha * ease)

        # 贴边吸附：吸在边上、鼠标又不在上面的时候，缩成一条小细条；
        # 鼠标移上去自己放大回来。只有"吸在边上"才会这样，随便放桌面中间不受影响。
        if self._frames % 4 == 0:
            self.watch_hover()
        if self.snap_on and self.snap_edge:
            if self.simple_on():
                w_s, h_s = self.simple_size()
                self.target_w, self.target_h = float(w_s), float(h_s)
            elif not self.expanded:
                self.target_w = float(self.compact_w)
                self.target_h = float(self.header_h)
            # 展开设置时的高度交给 set_expanded() 管，别每帧算一遍面板高度
            # 正在拖的时候**千万别**抢位置：不然每帧都被拉回边缘，等于拖不动
            if self._drag is None:
                self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)

        # 展开/收起：固定"步数"的缓动。
        # 为什么不用时间驱动？改窗口尺寸这一下是要 Windows 重新合成这个半透明窗口的，
        # 一帧要 20~30ms，用 0.24 秒去卡只能挤出 6 个台阶，头一步就跳掉三分之一，
        # 肉眼就是"卡"。改成固定 14 步：机器快就 230ms 走完，机器慢就慢一点，
        # 但每一步都是均匀的，看着才顺。
        if abs(self.target_w - self.cur_w) > 0.6 or abs(self.target_h - self.cur_h) > 0.6:
            key = (round(self.target_w, 1), round(self.target_h, 1))
            if self.resize_from is None or self._resize_key != key:
                # 目标一变就重新从"当前尺寸"开始走：否则会拿着上一次的进度，
                # 一帧就跳到位（收起时看起来就像没有动画）
                self._resize_key = key
                self._rz_step = 0
                self.resize_from = (self.cur_w, self.cur_h)
            w0, h0 = self.resize_from
            self._rz_step = getattr(self, "_rz_step", 0) + 1
            # 贴边小条那一下距离短，少走几步就到位（更快）；展开/收起面板走 8 步
            steps = SIMPLE_STEPS if (self.snap_edge and not self.expanded) else RESIZE_STEPS
            t = min(1.0, self._rz_step / float(steps))
            e = t * t * (3 - 2 * t)          # smoothstep：两头慢、中间快
            self.cur_w = w0 + (self.target_w - w0) * e
            self.cur_h = h0 + (self.target_h - h0) * e
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            self._base_key = None
            # 面板跟着窗口一起长（而不是一开始就摆到最终高度）：
            # 面板每帧都"变了尺寸"，Tk 就会把它整块重画；不然新露出来的那条
            # 是没画过的像素 —— 分层窗口里看着就是一条黑带。
            if self.expanded:
                self._place_panel(self.cur_h)
            # 展开/收起时窗口一变大，新露出来的那块必须**马上重画**。
            # 不重画的话它是"未绘制"的 —— 浮窗是分层窗口，未绘制 = 透明，
            # 你会直接看到后面的聊天窗口透过来，看着就是一大块黑边（真机抓到过整片黑）。
            self._repaint_now()
            if t >= 1.0:
                self.cur_w, self.cur_h = self.target_w, self.target_h
                self.resize_from = self._resize_key = self._rz_step = None
                self.root.geometry(
                    f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
                if self._panel_closing:        # 收起动画走完了，这才把面板撤掉
                    self._finish_panel_close()
        elif self.resize_from is not None:
            # 尺寸已经到位（差得不足 1px）：把缓动状态清干净，
            # 不然下一次展开/收起会拿着过期进度瞬间跳完
            self.cur_w, self.cur_h = self.target_w, self.target_h
            self.resize_from = self._resize_key = self._rz_step = None
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            if self._panel_closing:
                self._finish_panel_close()

        # 帧率提高后每帧步长相应减小，观感速度保持一致
        self.level_shown += (self.level - self.level_shown) * 0.16
        self.breath = (self.breath + 0.055) % (2 * math.pi)
        self.wave_phase += 0.13 + 0.3 * self.level_shown
        if self.text_fade < 1.0:
            self.text_fade = min(1.0, self.text_fade + 0.07)
        if abs(self.switch_target - self.switch_pos) > 0.002:
            self.switch_pos += (self.switch_target - self.switch_pos) * 0.14
        else:
            self.switch_pos = self.switch_target

        state_color = COLORS.get(self.state, self.accent)
        # 我正在说话时：换成说话色，并用朗读的实时音量驱动形状和大小
        speak_active, speak_level, speak_text, speak_prog = self.read_speaking()
        if speak_active:
            self.level = speak_level

        # 养成：长时间没人理它会打哈欠→打盹；被叫醒时弹一下
        active = (self.level > 0.06 or speak_active
                  or self.state in ("listening", "hearing", "thinking", "sent",
                                    "copied", "focus"))
        if active:
            if self.sleep_stage >= 2:
                self._pop = 1.0
            self.last_active = now_t
            self.sleep_stage = 0
        elif self.mood_idle:
            idle = now_t - self.last_active
            self.sleep_stage = 2 if idle >= 240 else (1 if idle >= 120 else 0)
        else:
            self.sleep_stage = 0
        if self._pop > 0:
            self._pop = max(0.0, self._pop - self.dt * 2.0)

        # 颜色过渡：目标色变了就从"当前显示色"补间过去，用固定时长 + smoothstep，
        # 所以起步慢、收尾也慢，中间不会抖；帧率从 30 调到 60 快慢也一样。
        # 说话↔不说话换色、在设置里改配色，都会是渐变而不是"啪"地跳。
        now_t = time.time()
        target_hex = self.talk_color if speak_active else (
            state_color if self.line_follow else self.accent)
        # 语气反应：你吼得急，线条就往暖色偏；你轻声说，就往冷灰偏
        mood = str((self.status or {}).get("mood") or "")
        # 语气只在 10 秒内有效：不然一句"急"会一直黄下去，看着像自己变色
        if mood and time.time() - float((self.status or {}).get("mood_ts") or 0) > 10:
            mood = ""
        if self.mood_on and mood and not speak_active:
            target_hex = mix(target_hex, "#ff6b35" if mood == "急" else "#455270", 0.60)
        target_rgb = rgb(target_hex)
        cur = getattr(self, "_wave_rgb", None)
        if cur is None:
            cur = target_rgb
        if self.perf == "eco":                 # 节能模式：不做过渡，直接跳到目标色
            cur = target_rgb
            self._fade_from = target_rgb
            self._fade_to = target_rgb
            self._fade_t0 = now_t
            self._fade_dur = FADE_SECONDS
        else:
            if target_rgb != getattr(self, "_fade_to", None):
                self._fade_from = cur          # 从肉眼看到的颜色接着往下走
                self._fade_to = target_rgb
                self._fade_t0 = now_t
                self._fade_dur = FADE_SECONDS
            p = min(1.0, max(0.0, (now_t - self._fade_t0) / max(0.01, self._fade_dur)))
            e = p * p * (3 - 2 * p)            # smoothstep 缓动
            a = self._fade_from
            cur = tuple(a[i] + (self._fade_to[i] - a[i]) * e for i in range(3))
        self._wave_rgb = cur
        # 量化到 4 的倍数：过渡够细腻，又不会让渲染出来的颜色无限细分
        wave_color = hexs(tuple(round(c / 4) * 4 for c in cur))
        im = self.base_image().copy()
        d = ImageDraw.Draw(im)
        if self.simple_on():
            # 贴边时的"简化版小窗口"：只有一条会跟着声音起伏的细条
            self.draw_simple(im, d, wave_color)
        else:
            self.draw_full(im, d, wave_color, state_color, speak_active,
                           speak_text, speak_prog)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)
        # 透明度只在"真的变了"的时候设：每帧设一次会让窗口合成器每帧重算一遍
        if self.intro >= 1.0:
            want = self.alpha_override if self.alpha_override else self.alpha
            if abs(want - getattr(self, "_alpha_set", -1.0)) > 0.004:
                self._alpha_set = want
                try:
                    self.root.attributes("-alpha", want)
                except Exception:
                    pass
            # 给主程序回执："窗口真的画出来了"（动画循环活着 + 窗口可见 + 不是透明的）
            if (not getattr(self, "_ready_done", False)
                    or now_t - getattr(self, "_ready_ts", 0.0) > 10.0):
                self._ready_done = True
                self._ready_ts = now_t
                self.write_ready()
        # 下一帧按"这一帧开始的时间"排。以前是排在画完之后：
        # 画一帧要 6ms，间隔就变成 16+6=22ms，60 帧永远跑不到（实测只有 44 帧）。
        spent_ms = (time.perf_counter() - frame_t0) * 1000
        # 展开/收起动画期间还要留个最小步进间隔：改窗口尺寸这一步本身要 20ms 上下，
        # 不加下限的话每一步都"已经超时"，12 步会在一次事件循环里挤成一坨，
        # Windows 只画最后一个尺寸 —— 看着就是内容"啪"地出现/消失，中间什么都没有。
        floor_ms = RESIZE_STEP_MS if self.resize_from is not None else 1
        self.root.after(max(floor_ms, int(round(self.frame_ms - spent_ms))), self.anim)
        # 机器忙的时候自动降级。注意两点：
        #   · 看的是"帧间隔"（上一帧开始 → 这一帧开始），不是 anim 里的耗时 ——
        #     机器忙的时候进程会被抢走 CPU，墙体时间里的等待不该算成我们的锅；
        #   · 先关特效、不降帧。以前一上来就掉到 30 帧，结果"为了省 CPU 把画面变得更卡"。
        cost = time.perf_counter() - frame_t0
        self._frame_cost = getattr(self, "_frame_cost", cost) * 0.9 + cost * 0.1
        prev = getattr(self, "_prev_t", None)
        if prev is not None:
            gap = max(0.0, now_t - prev)
            self._period = getattr(self, "_period", gap) * 0.9 + gap * 0.1
            self._gaps.append(gap)
            if len(self._gaps) > 60:
                del self._gaps[:-60]
        self._prev_t = now_t
        self._frames = getattr(self, "_frames", 0) + 1
        budget = self.frame_ms / 1000.0
        gaps = self._gaps
        median = sorted(gaps)[len(gaps) // 2] if gaps else 0.0
        if median > budget * 1.25 and len(gaps) >= 60:
            self._slow_checks = getattr(self, "_slow_checks", 0) + 1
        else:
            self._slow_checks = 0
        if (getattr(self, "auto_tune", True)
                and not getattr(self, "_auto_low_off", False)   # 你亲手开回来的，就别再自动关
                and self._frames > 150
                and (now_t - getattr(self, "_started", now_t)) > 20
                and getattr(self, "_slow_checks", 0) >= 5):
            self._slow_checks = 0
            stage = getattr(self, "_degrade_stage", 0)
            if stage == 0:
                fancy = [k for k in FX_KEYS if self.fx.get(k)]
                if fancy:
                    # 先把"你自己选的那套"记下来：降级只是这一次运行的事，
                    # 不许它顺着"保存设置"溜进 config.json 变成你的新设置
                    self._fx_before_low = {k: bool(self.fx.get(k)) for k in FX_KEYS}
                    for k in fancy:
                        self.fx[k] = False
                    self._auto_low = True
                    self._degrade_stage = 1
                    self._frames = 0
                    note(f"帧间隔中位数 {median * 1000:.0f}ms 偏长，先关掉声音条特效（保住帧率）")
                else:
                    self._degrade_stage = 2
            elif stage == 1:
                self._degrade_stage = 2
                self.frame_ms = max(self.frame_ms, 33)
                note("关了特效还是偏长，这才降到 30 帧")

    def draw_simple(self, im, d, wave_color: str) -> None:
        """贴边时那条"简化版"：一小段会跟着声音起伏的光条，没有字也没有开关。

        竖着贴左/右边就是竖条，贴上/下边就是横条。外观页那五个特效在这里同样生效：
        视觉暂留拖残影、呼吸光晕垫柔光、星尘溅亮点、倒影来一条对称的淡影、流光扫过。
        """
        w, h = im.size
        vertical = self.snap_edge in ("left", "right")
        d.rounded_rectangle([0, 0, w - 1, h - 1], radius=min(w, h) // 2,
                            fill=self.panel_color)

        level = max(0.0, min(1.0, self.level_shown))
        wob = 0.5 + 0.5 * math.sin(self.wave_phase * 1.2)
        frac = 0.22 + 0.70 * min(1.0, level * (0.55 + 0.45 * wob) + level * 0.35)
        thick = max(2.0, min(w, h) * 0.40)
        # 光条在长轴上跟着声音来回滑（像个 VU 表）—— 有了这个"动"，
        # 视觉暂留的拖影才看得出来；不然一直是同心放大，根本看不见。
        want_pos = 0.5 + (level - 0.35) * 0.40 * math.sin(self.wave_phase * 0.62)
        want_pos = min(0.86, max(0.14, want_pos))
        now_pos = getattr(self, "_strip_pos", 0.5)
        self._strip_pos = now_pos + (want_pos - now_pos) * 0.16
        # 节能模式 / 已经自动降过级：特效一律不画（跟主声音条一个规矩）
        fx = {k: bool(v) for k, v in self.fx.items()}
        if self.perf == "eco" or getattr(self, "_auto_low", False):
            fx = {k: False for k in fx}

        def box_for(f: float, extra: float = 0.0, pos: float | None = None) -> list:
            t = thick + extra
            c = self._strip_pos if pos is None else pos
            if vertical:
                span = max(6.0, (h - 14) * f)
                mid = 7 + (h - 14) * c
                y0 = min(max(4.0, mid - span / 2), h - 4 - span)
                return [w / 2 - t / 2, y0, w / 2 + t / 2, y0 + span]
            span = max(6.0, (w - 14) * f)
            mid = 7 + (w - 14) * c
            x0 = min(max(4.0, mid - span / 2), w - 4 - span)
            return [x0, h / 2 - t / 2, x0 + span, h / 2 + t / 2]

        # ① 视觉暂留：把最近几帧的长度留成一层层淡影
        if fx.get("fx_trail"):
            for i, (old_f, old_p) in enumerate(getattr(self, "_strip_hist", [])[-3:]):
                d.rounded_rectangle(box_for(old_f, 1.0, old_p),
                                    radius=int(thick // 2) + 1,
                                    fill=mix(self.panel_color, wave_color,
                                             0.16 + 0.12 * i))
        self._strip_hist = (getattr(self, "_strip_hist", [])
                            + [(frac, self._strip_pos)])[-4:]

        # ② 倒影：旁边并排来一条更细更淡的（竖条就左右并排、横条就上下并排）
        if fx.get("fx_reflection"):
            gap = thick * 0.95
            seg = box_for(frac, -thick * 0.62)
            if vertical:
                seg = [seg[0] + gap, seg[1], seg[2] + gap, seg[3]]
            else:
                seg = [seg[0], seg[1] + gap, seg[2], seg[3] + gap]
            d.rounded_rectangle(seg, radius=int(max(1, thick // 3)),
                                fill=mix(self.panel_color, wave_color, 0.34))

        # ③ 呼吸光晕：先垫一层毛茸茸的柔光
        if fx.get("fx_glow") and level > 0.06:
            halo = Image.new("RGBA", im.size, (0, 0, 0, 0))
            hd = ImageDraw.Draw(halo)
            hd.rounded_rectangle(box_for(frac, thick * 0.6), radius=int(thick),
                                 fill=rgb(wave_color) + (int(60 + 70 * level),))
            halo = halo.filter(ImageFilter.GaussianBlur(3.0))
            im.paste(Image.alpha_composite(im.convert("RGBA"), halo).convert("RGB"),
                     (0, 0))
            d = ImageDraw.Draw(im)

        # ④ 光条本体
        d.rounded_rectangle(box_for(frac), radius=int(max(1, thick // 2)), fill=wave_color)

        # ⑤ 流光：一条高光顺着光条扫过去
        if fx.get("fx_sweep"):
            seg = box_for(frac)
            t = (self._sweep_pos * 1.6) % 1.0
            length = max(4.0, (seg[3] - seg[1]) * 0.22) if vertical \
                else max(4.0, (seg[2] - seg[0]) * 0.22)
            if vertical:
                y0 = seg[1] + (seg[3] - seg[1] - length) * t
                box = [seg[0], y0, seg[2], y0 + length]
            else:
                x0 = seg[0] + (seg[2] - seg[0] - length) * t
                box = [x0, seg[1], x0 + length, seg[3]]
            d.rounded_rectangle(box, radius=int(max(1, thick // 3)),
                                fill=mix(wave_color, "#ffffff", 0.55))

        # ⑥ 星尘：说话时在光条两头溅几个小亮点
        if fx.get("fx_sparkles") and level > 0.15:
            import random as _random

            sparks = getattr(self, "_strip_sparks", [])
            if len(sparks) < 14 and _random.random() < 0.5:
                seg = box_for(frac)
                if vertical:
                    sparks.append([w / 2 + _random.uniform(-thick, thick),
                                   _random.choice([seg[1], seg[3]]),
                                   _random.uniform(-0.5, 0.5),
                                   _random.uniform(-1.4, 1.4), 1.0])
                else:
                    sparks.append([_random.choice([seg[0], seg[2]]),
                                   h / 2 + _random.uniform(-thick, thick),
                                   _random.uniform(-1.4, 1.4),
                                   _random.uniform(-0.5, 0.5), 1.0])
            alive = []
            for sx, sy, vx2, vy2, life in sparks:
                life -= 0.06
                if life <= 0:
                    continue
                sx, sy = sx + vx2, sy + vy2
                r = 1.4 * life
                d.ellipse([sx - r, sy - r, sx + r, sy + r],
                          fill=mix(wave_color, "#ffffff", 0.5 * life))
                alive.append([sx, sy, vx2, vy2, life])
            self._strip_sparks = alive[-14:]

        # ⑦ 贴的那一侧一条高光，暗示"我贴着屏幕边"
        edge_line = {"left": [(1, 4), (1, h - 4)], "right": [(w - 2, 4), (w - 2, h - 4)],
                     "top": [(4, 1), (w - 4, 1)], "bottom": [(4, h - 2), (w - 4, h - 2)]}
        if self.snap_edge in edge_line:
            a, b = edge_line[self.snap_edge]
            d.line([a, b], fill=wave_color, width=1)

    def draw_full(self, im, d, wave_color: str, state_color: str,
                  speak_active: bool, speak_text: str, speak_prog: float) -> None:
        """平时那套样子：名字 + 状态 + 声音条 + 开关 + 箭头。"""
        w_now = im.width
        if self.show_status:
            sx, sy, ssize = self.layout["status"]
            label = LABELS.get(self.state, self.state)
            if self.focus_left > 0:
                label = LABELS["focus"]          # 专注中优先显示
            if self.sleep_stage >= 2:
                label = LABELS["sleepy"]        # 睡着了就别再写"待唤醒"
            if time.time() < self.toast_until:
                label = self.toast
            f = font(ssize)
            box = d.textbbox((0, 0), label, font=f)
            x0 = (w_now + sx - (box[2] - box[0])) if sx < 0 else sx
            d.text((x0, sy), label, font=f,
                   fill=mix(self.panel_color, state_color, min(1.0, 0.3 + self.text_fade)))
        bands = list((self.status or {}).get("bands") or [])
        if self.spectrum_on and bands and not speak_active and self.focus_left <= 0:
            self.draw_spectrum(im, d, wave_color, bands)
        elif self.focus_left > 0:
            self.draw_focus(im, d, wave_color,
                            1.0 - self.focus_left / max(1.0, self.focus_total))
        else:
            self.draw_voice(im, wave_color)
        gap, height = self.layout["wave"]
        self.draw_caption(d, w_now, im.height - gap - height,
                          speak_text if speak_active else "", speak_prog)
        if self.show_switch:
            sw = self.switch_sprite(self.switch_pos)
            x0, y0 = self.switch_rect()
            im.paste(sw, (x0, y0), sw)
        self.draw_arrow(d, w_now)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)

    def read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        return self._read_speaking()

    def write_ready(self) -> None:
        """写一张"我已经把窗口显示出来了"的回执给主程序（每 10 秒续一次时间戳）。"""
        try:
            w = self.root.winfo_x(), self.root.winfo_y()
            READY_FILE.write_text(json.dumps({
                "pid": os.getpid(),
                "ts": time.time(),
                "size": [int(self.cur_w), int(self.cur_h)],
                "pos": [int(w[0]), int(w[1])],
                "alpha": round(float(getattr(self, "_alpha_set", 0.0)), 2),
                "visible": bool(self.root.winfo_viewable()),
            }, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        counter = getattr(self, "_speak_tick", 0) + 1
        self._speak_tick = counter
        if counter % 3 != 1 and getattr(self, "_speak_cache", None) is not None:
            return self._speak_cache
        try:
            data = json.loads(SPEAK_STATUS.read_text(encoding="utf-8"))
            fresh = time.time() - float(data.get("ts") or 0) < 1.5
            self._speak_cache = (bool(data.get("active")) and fresh,
                                 float(data.get("level") or 0.0),
                                 str(data.get("text") or ""),
                                 float(data.get("progress") or 0.0))
        except Exception:
            self._speak_cache = (False, 0.0, "", 0.0)
        return self._speak_cache

    # ------------------------------------------------------------ 展开 / 收起
    def set_expanded(self, value: bool) -> None:
        if value == self.expanded:
            return
        self.expanded = value
        self.allow_keyboard(value)      # 展开时要能打字，收起后继续不抢焦点
        # 注意：不在这里改透明度 —— 你要求展开前后保持一致。
        # （透明窗口里 Windows 会关掉 ClearType，想要最锐的文字可以把透明度拉到 100%）
        if value:
            if self.panel is None:
                self.build_panel()
            # 面板一次性摆到最终高度，靠窗口变大把它"拉"出来，收起时再被窗口边界卷回去，
            # 这样展开和收起都是连贯动画（以前收起是内容"啪"地消失）
            self.target_w = float(self.expand_w)
            self.target_h = self._expanded_h()
            self._place_panel(self.target_h)
            self._panel_closing = False
            if self.snap_edge:
                # 贴着边展开设置面板：把它挪回屏幕里，别让面板一半在屏幕外
                self.base_x, self.base_y = self.clamp_on_screen(
                    self.base_x, self.base_y, int(self.expand_w), int(self.target_h))
            # 面板刚变大，等布局稳定再量一次"内容够不够放"，该显示滚动条就显示
            self.root.after(120, self._update_scroll_hint)
        else:
            self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
            self._panel_closing = True
            self.set_editing(False)
            if abs(self.cur_h - self.target_h) < 0.6:   # 已经在最小尺寸，无需等动画
                self._finish_panel_close()

    def _expanded_h(self) -> float:
        """展开后的窗口高度 —— **固定值**，不再跟着标签页内容变。

        以前是按当前页内容算需要多高：切到"外观"就长高一点、切到"基本"又缩回去，
        日程页还要单独给 620，看着就是"窗口自己在上下抽动"。现在固定成一个高度，
        装不下的部分用滚轮看（面板本来就是画布 + 滚轮，右边还有一条细滚动条提示）。
        高度上限还是跟着屏幕走：1080P 这种矮屏幕不会把底部按钮顶出窗外。
        """
        cap = max(420, self.root.winfo_screenheight() - 200)
        return float(self.header_h + int(min(cap, PANEL_H_OPEN)))

    def _place_panel(self, total_h: float) -> None:
        if self.panel is None:
            return
        self.panel.place(x=0, y=self.header_h, width=self.expand_w,
                         height=max(1, int(round(total_h - self.header_h))))
        self._repaint_now()

    def _repaint_now(self) -> None:
        """让新露出来的那块立刻画上（Tk 平时要等到下一次空闲才画）。

        只在这几个时刻用：改窗口尺寸、面板换高度、换标签页 —— 一帧几毫秒，
        换来的是"展开过程里看不到没画的黑块"。
        """
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        panel = getattr(self, "panel", None)
        if panel is not None:
            try:
                panel.update_idletasks()
            except Exception:
                pass
        # Tk 的 update_idletasks 只管"有空就画"，窗口刚变大的那块它不一定画 ——
        # 于是那块是黑的/透明的。这里直接让 Windows 立刻把整棵控件树重画一遍。
        if os.name == "nt":
            try:
                RDW_INVALIDATE, RDW_ERASE, RDW_ALLCHILDREN, RDW_UPDATENOW = 0x1, 0x4, 0x80, 0x100
                ctypes.windll.user32.RedrawWindow(
                    ctypes.c_void_p(int(self.root.winfo_id())), None, None,
                    RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN | RDW_UPDATENOW)
            except Exception:
                pass
        # 分层窗口（-alpha）改尺寸之后，Windows 常常只重画"变小"的部分，
        # 新露出来的那条一直是黑的。重新设一遍 alpha 就会让它整块重新合成。
        try:
            cur = getattr(self, "_alpha_set", None)
            if cur is not None:
                self.root.attributes("-alpha", max(0.05, float(cur) - 0.001))
                self.root.attributes("-alpha", float(cur))
        except Exception:
            pass

    def _finish_panel_close(self) -> None:
        self._panel_closing = False
        # 故意不 place_forget()：面板就留在那儿，被变小的窗口裁掉就行。
        # 以前每次收起都把它撤掉、展开再 map 七百个控件，主线程一卡 0.6 秒，
        # 卡完动画早跑完了 —— 看着就是"内容啪地出现 / 啪地消失"。
        # 现在展开收起只是改窗口尺寸，图省下来的时间正好用来做动画。

    def _hide_panel(self) -> None:
        if not self.expanded and self.panel is not None:
            self._finish_panel_close()

    # ------------------------------------------------------------ 键盘焦点
    def hwnds(self) -> list[int]:
        u = ctypes.windll.user32
        inner = self.root.winfo_id()
        outer = u.GetParent(inner) or inner
        return [h for h in {outer, inner} if h]

    def allow_keyboard(self, enabled: bool) -> None:
        """展开设置期间允许窗口被激活，这样输入框才能打字。"""
        try:
            for hwnd in self.hwnds():
                set_no_activate(hwnd, not enabled)
            if enabled:
                grab_foreground(self.hwnds()[0])
        except Exception:
            pass

    def focus_entry(self, widget) -> None:
        """点输入框时把焦点真的交给它（默认的浮窗是拿不到焦点的）。"""
        self.allow_keyboard(True)
        self.set_editing(True)
        try:
            grab_foreground(self.hwnds()[0])
            self.root.focus_force()
            widget.focus_set()
            widget.icursor("end")
            grab_foreground(widget.winfo_id())      # 再对着输入框自己抢一次
        except Exception:
            pass

    def set_editing(self, on: bool) -> None:
        """告诉主程序"我正在改设置"，这段时间别抢我的键盘（别往聊天窗口粘东西）。"""
        if on == self.editing_on:
            return
        self.editing_on = on
        self.edit_touch = time.time()
        send_command("editing-on" if on else "editing-off")
        inputlog(f"编辑状态 = {'开（主程序先别抢焦点）' if on else '关'}")

    # ------------------------------------------------------------ 设置面板
    def build_panel(self) -> None:
        import tkinter as tk

        panel = tk.Frame(self.root, bg=BG_PANEL, highlightthickness=1,
                         highlightbackground=BORDER)
        self.panel = panel
        self.tab_names = ["基本", "声音", "外观", "智能", "功能", "日程"]
        self.tab_frames: dict[str, object] = {}
        self.tab_labels: dict[str, object] = {}

        bar = tk.Frame(panel, bg=BG_PANEL)
        bar.pack(fill="x", padx=8, pady=(8, 4))
        for name in self.tab_names:
            lab = tk.Label(bar, text=name, bg=BG_PANEL, fg="#9a9aa5",
                           font=("Microsoft YaHei UI", 9), padx=10, pady=4, cursor="hand2")
            lab.pack(side="left", padx=2)
            lab.bind("<Button-1>", lambda _e, n=name: self.show_tab(n))
            self.tab_labels[name] = lab
        self.hint_label = tk.Label(bar, text="改动即时预览", bg=BG_PANEL, fg="#5f5f68",
                                   font=("Microsoft YaHei UI", 8))
        self.hint_label.pack(side="right", padx=6)

        # 标签页内容放在一张画布上：屏幕矮的机器（比如 1080P）也能用滚轮把
        # 下面够不着的开关滚出来看，不会像以前那样被窗口底边直接切掉。
        stage = tk.Canvas(panel, bg=BG_PANEL, highlightthickness=0, bd=0, takefocus=0)
        stage.pack(fill="both", expand=True)
        self.stage = self.stage_canvas = stage
        inner = tk.Frame(stage, bg=BG_PANEL)
        self.stage_inner = inner
        self._stage_win = stage.create_window((0, 0), window=inner, anchor="nw")
        stage.bind("<Configure>", self._on_stage_resize)
        inner.bind("<Configure>", self._on_stage_inner)
        for name in self.tab_names:
            self.tab_frames[name] = tk.Frame(inner, bg=BG_PANEL)

        self.build_basic(self.tab_frames["基本"])
        self.build_sound(self.tab_frames["声音"])
        self.build_look(self.tab_frames["外观"])
        self.build_smart(self.tab_frames["智能"], self.tab_frames["功能"])
        self.build_schedule(self.tab_frames["日程"])

        foot = tk.Frame(panel, bg=BG_PANEL)
        foot.pack(fill="x", padx=10, pady=(4, 10))
        # 左下角：版本号（＝你让我改过多少次，见 version.py）
        tk.Label(foot, text=version.label(), bg=BG_PANEL, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(2, 0))
        save = tk.Label(foot, text="保存", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=5, cursor="hand2")
        save.pack(side="right")
        save.bind("<Button-1>", lambda _e: self.save_settings())
        reset = tk.Label(foot, text="恢复默认", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        reset.pack(side="right", padx=8)
        reset.bind("<Button-1>", lambda _e: self.reset_defaults())
        # 「关于」：署名 / 版权 / 邮箱 / 使用许可，只在这一个地方显示
        about_btn = tk.Label(foot, text="关于", bg=CARD, fg="#ffffff",
                             font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        about_btn.pack(side="right", padx=(0, 4))
        about_btn.bind("<Button-1>", lambda _e: self.show_about())
        # 「检查更新」：数据读的是下载页那份（网页一刷新，这边就提示更新）
        self.upd_label = tk.Label(foot, text="", bg=BG_PANEL, fg="#6f6f7a",
                                  font=("Microsoft YaHei UI", 8))
        self.upd_label.pack(side="left", padx=(8, 0))
        upd_btn = tk.Label(foot, text="检查更新", bg=CARD, fg="#ffffff",
                           font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        upd_btn.pack(side="right", padx=(0, 4))
        upd_btn.bind("<Button-1>", lambda _e: self.check_update())
        # 「发布到网站」：把下载页推到公网（第一次会弹一次 git 登录，之后自动）
        pub_btn = tk.Label(foot, text="发布到网站", bg=CARD, fg="#ffffff",
                           font=("Microsoft YaHei UI", 9), padx=12, pady=5, cursor="hand2")
        pub_btn.pack(side="right", padx=(0, 4))
        pub_btn.bind("<Button-1>", lambda _e: self.publish_site())
        self._bind_wheel_tree(inner)      # 面板里每一层都能吃滚轮
        # 右边一条细滚动条：内容装不下才出现，让你知道"还能往下滚"
        self.scroll_hint = tk.Canvas(panel, width=4, bg=BG_PANEL, highlightthickness=0, bd=0)
        self.show_tab("基本")

    # ------------------------------------------------- 面板滚轮
    def _on_stage_resize(self, event) -> None:
        """画布宽度变了，里面那层跟着变宽，内容才不会缩成一条。"""
        try:
            self.stage.itemconfig(self._stage_win, width=max(1, int(event.width)))
        except Exception:
            pass
        self._update_scroll_hint()

    def _on_stage_inner(self, _event=None) -> None:
        try:
            self.stage.configure(scrollregion=self.stage.bbox("all"))
        except Exception:
            pass
        self._update_scroll_hint()

    def _update_scroll_hint(self) -> None:
        """右上角那条细条：内容比窗口高才显示，位置跟着滚动走。"""
        bar = getattr(self, "scroll_hint", None)
        stage = getattr(self, "stage_canvas", None)
        if bar is None or stage is None:
            return
        try:
            region = stage.bbox("all")
            view = stage.winfo_height()
            if not region or view <= 1 or region[3] - region[1] <= view + 1:
                bar.place_forget()
                return
            top, bottom = stage.yview()
            h = max(26, int(view * (bottom - top)))
            y = int(stage.winfo_y() + view * top)
            bar.delete("all")
            bar.create_rectangle(0, 0, 4, h, fill=self.button_color, outline="")
            bar.place(relx=1.0, x=-6, y=y, width=4, height=h)
        except Exception:
            pass

    def _bind_wheel_tree(self, widget) -> None:
        widget.bind("<MouseWheel>", self.on_panel_wheel, add="+")
        for child in widget.winfo_children():
            self._bind_wheel_tree(child)

    def on_panel_wheel(self, event):
        """内容装不下才滚；装得下就不动，别抢浮窗自己那个"滚轮调透明度"。"""
        stage = getattr(self, "stage_canvas", None)
        if stage is None:
            return None
        region = stage.bbox("all")
        if not region or region[3] - region[1] <= stage.winfo_height() + 1:
            self._update_scroll_hint()
            return None
        stage.yview_scroll(-1 if getattr(event, "delta", 0) > 0 else 1, "units")
        self._update_scroll_hint()
        return "break"

    def show_tab(self, name: str) -> None:
        self.current_tab = name
        for key, frame in self.tab_frames.items():
            if key == name:
                frame.pack(fill="both", expand=True)
            else:
                frame.pack_forget()
        stage = getattr(self, "stage_canvas", None)
        if stage is not None:
            try:
                stage.yview_moveto(0.0)       # 换页从头看起
                self._on_stage_inner()
            except Exception:
                pass
        for key, lab in self.tab_labels.items():
            lab.config(bg=CARD if key == name else BG_PANEL,
                       fg="#ffffff" if key == name else "#9a9aa5")
        # 展开着切页：高度是固定的，不跟着内容变（装不下的用滚轮看）
        if self.expanded:
            self.target_w = float(self.expand_w)
            self.target_h = self._expanded_h()
            self._place_panel(self.target_h)
        self.root.after(30, self._update_scroll_hint)
        # 切到「智能」那一页就顺手看一眼外网状态（后台跑，不卡界面）
        if name == "智能" and getattr(self, "remote_label", None) is not None:
            self.root.after(60, self.refresh_remote)

    def build_basic(self, parent) -> None:
        self.entry_name = self._entry(parent, "名字", self.cfg.get("name") or "语音助手")
        self.entry_wake = self._entry(parent, "唤醒词", self.cfg.get("wake_word") or "大肥鱼")
        self.build_wake_level(parent)
        self.entry_greeting = self._entry(parent, "问候语",
                                          self.cfg.get("greeting_text") or DEFAULTS["greeting_text"],
                                          multiline=True)
        self.entry_user = self._entry(parent, "你的称呼", self.cfg.get("user_name") or "")
        row = self._row(parent, "称呼频率")
        self.name_freq_value = str(self.cfg.get("name_freq") or "sometimes")
        self.name_freq_chips = {}
        for value, label in (("off", "从不"), ("sometimes", "偶尔"), ("often", "经常")):
            chip = self._chip(row, label, lambda v=value: self.set_name_freq(v))
            chip.pack(side="left", padx=3)
            self.name_freq_chips[value] = chip
        self.refresh_name_freq()
        # 应答语：可以写好几条，一行一条（或 | 隔开），每次随机挑一条
        self.entry_ack = self._entry(parent, "应答语",
                                     self.cfg.get("ack_text") or DEFAULTS["ack_text"],
                                     multiline=True)
        self.tk.Label(parent, text="可以写好几条，一行一条；每次随机挑一条说",
                      bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=(14, 10),
                                                           pady=(0, 3))
        self.sw_ack = self._switch_row(parent, "应答语开关",
                                       bool(self.cfg.get("ack_enabled", True)))
        self.entry_self = self._entry(parent, "自称", self.cfg.get("self_name") or "大肥鱼")
        self.sw_self = self._switch_row(parent, "自称开关",
                                        bool(self.cfg.get("self_talk", True)))
        # 自称说的勤不勤（三档）：以前只有"开/关"，结果它几乎不说，
        # 用户说"我从来没听你说过自称" —— 所以给个频率，还要真的用上
        row = self._row(parent, "自称频率")
        self.self_freq_value = str(self.cfg.get("self_freq") or "sometimes")
        self.self_freq_chips = {}
        for value, label in (("off", "从不说"), ("sometimes", "有时"),
                             ("often", "经常")):
            chip = self._chip(row, label, lambda v=value: self.set_self_freq(v))
            chip.pack(side="left", padx=3)
            self.self_freq_chips[value] = chip
        self.refresh_self_freq()
        self.sw_greeting = self._switch_row(parent, "开机问候",
                                            bool(self.cfg.get("greeting_enabled", True)))
        self.sw_autostart = self._switch_row(parent, "开机自启", startup_exists(),
                                             on_change=self.set_autostart)
        self.sw_restart = self._switch_row(parent, "崩溃自动重启",
                                           bool(self.cfg.get("auto_restart", True)))
        # 预设：整套设置存下来，随时切换
        row = self._row(parent, "预设")
        self._chip(row, "存为预设", self.save_preset).pack(side="right", padx=(4, 10))
        self._chip(row, "导出预设", self.export_presets).pack(side="right", padx=2)
        self._chip(row, "导入预设", self.import_presets).pack(side="right", padx=2)
        self.preset_bar = self.tk.Frame(parent, bg=BG_PANEL)
        self.preset_bar.pack(fill="x", padx=12, pady=(0, 6))
        self.refresh_presets()

    # ------------------------------------------------- 唤醒档位 / 自检
    def build_wake_level(self, parent) -> None:
        """唤醒档位：几档灵敏度，也能自己再加几档；改唤醒词会自动跑一次自检。"""
        row = self._row(parent, "唤醒档位")
        self._chip(row, "自检", self.run_wake_test).pack(side="right", padx=(4, 10))
        self._chip(row, "＋自定", self.add_wake_level).pack(side="right", padx=2)
        # 档位按钮单独占一行（档位多了会自动折行），不然加了自定义档会被挤出可视区
        self.level_holder = self.tk.Frame(parent, bg=BG_PANEL)
        self.level_holder.pack(fill="x", padx=(12, 10), pady=(0, 2))
        self.level_info = self.tk.Label(parent, text="", bg=BG_PANEL, fg="#7f7f8a",
                                        font=("Microsoft YaHei UI", 8), anchor="w",
                                        justify="left", wraplength=386)
        self.level_info.pack(fill="x", padx=(14, 10), pady=(0, 3))
        self.level_chips = {}
        self.refresh_level_chips()

    def custom_levels(self) -> dict:
        return dict(self.cfg.get("wake_levels") or {})

    def refresh_level_chips(self) -> None:
        if not hasattr(self, "level_holder"):
            return
        for child in self.level_holder.winfo_children():
            child.destroy()
        self.level_chips = {}
        room = max(220, self.expand_w - 34)
        # 用字体量宽度决定折行：刚建好的控件 winfo_reqwidth() 还量不准，
        # 而 update_idletasks() 在构建面板时会造成重入，所以两者都别用
        try:
            import tkinter.font as tkfont

            metre = tkfont.Font(font=("Microsoft YaHei UI", 9))
        except Exception:
            metre = None
        line, used = None, 0
        for name in wake_levels.merged(self.custom_levels()):
            width = (metre.measure(name) + 26) if metre is not None else (9 * len(name) + 30)
            if line is None or used + width > room:      # 一行放不下就折行
                line = self.tk.Frame(self.level_holder, bg=BG_PANEL)
                line.pack(anchor="w", fill="x")
                used = 0
            # 注意：按钮必须"生"在这一行里。用 pack -in 只是换布局不改父子关系，
            # 后建的行框会把先建的按钮盖住（之前首个档位就是这么消失的）
            chip = self._chip(line, name, lambda n=name: self.set_wake_level(n))
            chip.pack(side="left", padx=2, pady=1)
            used += width
            self.level_chips[name] = chip
        self.refresh_level_colors()
        self.update_level_info()

    def refresh_level_colors(self) -> None:
        current = str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL)
        for name, chip in getattr(self, "level_chips", {}).items():
            chip.config(bg=self.button_color if name == current else CARD, fg="#ffffff")

    def update_level_info(self, text: str | None = None, color: str = "#7f7f8a") -> None:
        if not hasattr(self, "level_info"):
            return
        if text is None:
            name, params = wake_levels.params(self.cfg)
            text = f"「{name}」{wake_levels.describe(params)}"
            if getattr(self, "wake_test_result", ""):
                text = f"{self.wake_test_result}   ·   {text}"
        self.level_info.config(text=text, fg=color)

    def set_wake_level(self, name: str) -> None:
        data = self.cfg
        data["wake_level"] = name
        self.cfg = data
        self.refresh_level_colors()
        self.update_level_info()
        self.on_change()
        self.flash(f"唤醒档位：{name}", 1.6)

    def add_wake_level(self) -> None:
        """自己再加一档：把当前档位的参数抄进小编辑框，改完存成新档位。"""
        name, params = wake_levels.params(self.cfg)

        def done(text: str) -> None:
            got = wake_levels.from_text(text)
            if not got:
                self.flash("没读懂，名称那一行不能空", 2.4)
                return
            new_name, new_params = got
            data = self.cfg
            custom = dict(data.get("wake_levels") or {})
            custom[new_name] = new_params
            data["wake_levels"] = custom
            data["wake_level"] = new_name
            self.cfg = data
            self.refresh_level_chips()
            self.on_change()
            self.flash(f"已新增档位「{new_name}」", 2.4)

        self.edit_text("唤醒档位（照抄着改数值就行）", wake_levels.to_text(name, params),
                       done, multiline=True)

    def run_wake_test(self) -> None:
        """让主程序跑一次唤醒词自检：结果会写进 wake_test.json，这边轮询着显示。"""
        send_command("wake-test")
        self.wake_test_at = time.time()
        self.wake_test_result = ""
        self.update_level_info("正在自检唤醒词…（会合成几段语音试一遍，稍后念出结果）", "#c9c9d6")
        self.flash("正在自检唤醒词…", 3)

    def poll_wake_test(self) -> None:
        try:
            data = json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_wake_test_ts", 0.0):
            return
        self._wake_test_ts = ts
        self.wake_test_result = str(data.get("summary") or "")
        if self.wake_test_result:
            self.flash(self.wake_test_result, 4.5)
            self.update_level_info()

    # ------------------------------------------------- 大字幕
    def make_big_caption(self) -> None:
        """屏幕底部一条独立的大字窗口，听网课/没字幕的视频时用。"""
        if self.caption_win is not None:
            return
        tk = self.tk
        try:
            win = tk.Toplevel(self.root)
        except Exception:
            return
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        try:
            win.attributes("-alpha", 0.9)
        except Exception:
            pass
        win.configure(bg="#08080a")
        lab = tk.Label(win, text="", bg="#08080a", fg="#ffffff",
                       font=("Microsoft YaHei UI", self.big_size), justify="center")
        lab.pack(fill="both", expand=True, padx=18, pady=10)
        self.caption_win, self.caption_label = win, lab
        try:
            make_no_activate(win.winfo_id())      # 不抢焦点，你该干嘛干嘛
        except Exception:
            pass
        self.place_big_caption()

    def place_big_caption(self) -> None:
        if self.caption_win is None:
            return
        try:
            vx, vy, vw, vh = virtual_screen()
            w = int(vw * 0.84)
            h = max(90, int(self.big_size * 2.4))
            self.caption_win.geometry(f"{w}x{h}+{vx + (vw - w) // 2}+{vy + vh - h - 64}")
            self.caption_label.config(font=("Microsoft YaHei UI", self.big_size))
        except Exception:
            pass

    def sync_big_caption(self) -> None:
        if not self.big_on:
            if self.caption_win is not None:
                try:
                    self.caption_win.destroy()
                except Exception:
                    pass
                self.caption_win = self.caption_label = None
            return
        if self.caption_win is None:
            self.make_big_caption()
        text = str((self.status or {}).get("text") or "").strip()
        if not text and self.focus_left > 0:
            left = int(self.focus_left)
            text = f"专注 {left // 60:02d}:{left % 60:02d}"
        if text and text != self.caption_last:
            self.caption_last = text
            self.caption_at = time.time()
            try:
                self.caption_label.config(text=text, fg="#ffffff")
            except Exception:
                pass
        elif self.caption_last and time.time() - self.caption_at > 8:
            self.caption_last = ""
            try:
                self.caption_label.config(text="")
            except Exception:
                pass

    def maybe_first_run(self) -> None:
        """第一次用的时候弹一个小引导（三步），看过了就不再弹。"""
        mark = HERE / "first-run.done"
        if mark.exists():
            return
        try:
            mark.write_text("ok", encoding="utf-8")
        except Exception:
            return
        tk = self.tk
        try:
            win = tk.Toplevel(self.root)
        except Exception:
            return
        win.title("第一次用，三步就能上手")
        win.configure(bg=BG_PANEL)
        win.attributes("-topmost", True)
        win.geometry("460x300")
        tk.Label(win, text="三步就能用起来", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 14, "bold")).pack(anchor="w", padx=18, pady=(16, 6))
        steps = [
            "1. 先确认麦克风：说「自检」，它会告诉你麦克风/模型/窗口/剪贴板有没有问题。",
            "2. 试一句：说「" + str(self.cfg.get("wake_word") or "大肥鱼") +
            "」，听到两声提示音再说话，说完自动发出去。",
            "3. 挑声音：设置 → 声音 → 音色，点「选择」把抽屉拉开，想用哪个直接点哪个"
            "（每行右边还有「听」，一边听一边挑）。",
            "",
            "其它常用的：说「专注25分钟」开番茄钟；「记一下 明天买牛奶」存便签；",
            "「别记这段」让它几分钟不记录；「自检」随时查身体。",
        ]
        for s in steps:
            tk.Label(win, text=s, bg=BG_PANEL, fg="#c9c9d6", justify="left",
                     font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=20, pady=1)
        tk.Label(win, text="知道了", bg=self.button_color, fg="#ffffff", padx=22, pady=6,
                 cursor="hand2", font=("Microsoft YaHei UI", 10, "bold")).pack(pady=14)
        win.winfo_children()[-1].bind("<Button-1>", lambda _e: win.destroy())

    def sync_rec_dot(self) -> None:
        """录音时右下角亮一个小红点——不用盯着浮窗也知道它在听。"""
        live = self.rec_on and self.state in ("hearing", "listening")
        if live and self.rec_win is None:
            try:
                win = self.tk.Toplevel(self.root)
                win.overrideredirect(True)
                win.title("在听")        # 别继承浮窗的名字，不然找窗口的工具会认错
                win.attributes("-topmost", True)
                win.configure(bg="#141418")
                lab = self.tk.Label(win, text="● 在听", bg="#141418", fg="#ff5c5c",
                                    font=("Microsoft YaHei UI", 12, "bold"), padx=12, pady=4)
                lab.pack()
                make_no_activate(win.winfo_id())
                vx, vy, vw, vh = virtual_screen()
                win.geometry(f"+{vx + vw - 150}+{vy + vh - 120}")
                self.rec_win = win
            except Exception:
                self.rec_win = None
        elif not live and self.rec_win is not None:
            try:
                self.rec_win.destroy()
            except Exception:
                pass
            self.rec_win = None

    def refresh_presets(self) -> None:
        if getattr(self, "preset_bar", None) is None:   # 面板还没展开过就别画
            return
        for child in self.preset_bar.winfo_children():
            child.destroy()
        presets = load_config().get("presets") or {}
        if not presets:
            self.tk.Label(self.preset_bar, text="（可以把现在整套设置存成预设，随时切回来）",
                          bg=BG_PANEL, fg="#6f6f7a",
                          font=("Microsoft YaHei UI", 8)).pack(anchor="w")
            return
        for name in presets:
            chip = self.tk.Label(self.preset_bar, text=name[:12], bg=CARD, fg="#ffffff",
                                 padx=10, pady=3, cursor="hand2",
                                 font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=2, pady=1)
            chip.bind("<Button-1>", lambda _e, n=name: self.apply_preset(n))
            chip.bind("<Button-3>", lambda _e, n=name: self.remove_preset(n))

    def save_preset(self) -> None:
        def done(name: str) -> None:
            if not name:
                return
            data = self.collect()
            presets = dict(data.get("presets") or {})
            snapshot = {k: v for k, v in data.items() if k != "presets"}
            presets[name] = snapshot
            data["presets"] = presets
            write_config(data)
            self.refresh_presets()
            self.flash(f"已存为预设「{name}」", 2.4)

        self.edit_text("预设名称", "", done)

    def apply_preset(self, name: str) -> None:
        data = load_config()
        preset = (data.get("presets") or {}).get(name) or {}
        data.update(preset)
        write_config(data)
        self.cfg = data
        try:
            self.cfg_mtime = CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        if self.panel is not None:      # 面板按新预设重建
            self.panel.destroy()
            self.panel = None
            self.build_panel()
            self._place_panel(self._expanded_h())
        self.flash(f"已套用预设「{name}」", 2.4)

    def remove_preset(self, name: str) -> None:
        data = load_config()
        presets = dict(data.get("presets") or {})
        presets.pop(name, None)
        data["presets"] = presets
        write_config(data)
        self.refresh_presets()
        self.flash(f"已删除预设「{name}」", 2)

    # ------------------------------------------------- 预设的导出 / 导入
    def export_presets(self) -> None:
        """把所有预设打包成一个 json 文件，方便备份或者拷给别人用。"""
        from tkinter import filedialog

        presets = load_config().get("presets") or {}
        if not presets:
            self.flash("还没有预设可以导出，先点「存为预设」", 3)
            return
        desk = Path.home() / "Desktop"
        path = filedialog.asksaveasfilename(
            parent=self.root, title="导出预设", defaultextension=".json",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            initialfile=f"语音助手预设-{len(presets)}套.json",
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")])
        if not path:
            return
        payload = {"kind": "voice-assistant-presets", "version": 1,
                   "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                   "presets": presets}
        try:
            Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                  encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            self.flash(f"导出失败：{exc}", 4)
            return
        self.flash(f"已导出 {len(presets)} 套预设 → {Path(path).name}", 3.5)
        note(f"预设导出到 {path}")

    def import_presets(self) -> None:
        """从 json 文件里读回预设；重名的直接覆盖，别的一概不动。"""
        from tkinter import filedialog

        desk = Path.home() / "Desktop"
        path = filedialog.askopenfilename(
            parent=self.root, title="导入预设",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")])
        if not path:
            return
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            self.flash(f"这个文件读不了：{exc}", 4)
            return
        # 认两种格式：我们导出的那种（带 presets），或者干脆就是一个 {名字: 设置}
        if isinstance(raw, dict) and isinstance(raw.get("presets"), dict):
            incoming = raw["presets"]
        elif isinstance(raw, dict) and raw and all(isinstance(v, dict) for v in raw.values()):
            incoming = raw
        else:
            self.flash("这文件里没有预设", 4)
            return
        incoming = {str(k)[:40]: v for k, v in incoming.items() if isinstance(v, dict)}
        if not incoming:
            self.flash("这文件里没有预设", 4)
            return
        data = load_config()
        presets = dict(data.get("presets") or {})
        old = set(presets)
        presets.update(incoming)
        data["presets"] = presets
        write_config(data)
        filled = [k for k in incoming if k not in old]
        overwritten = [k for k in incoming if k in old]
        self.refresh_presets()
        got = f"导入 {len(incoming)} 套预设"
        if overwritten:
            got += f"（覆盖了 {len(overwritten)} 套同名）"
        if filled:
            got += f"：{ '、'.join(filled[:3]) }" + ("…" if len(filled) > 3 else "")
        self.flash(got, 3.5)
        note(f"导入预设：新增 {len(filled)} 套、覆盖 {len(overwritten)} 套")

    def build_sound(self, parent) -> None:
        self.sl_volume = Slider(parent, "朗读音量", 0, 100, float(self.cfg.get("volume") or 80),
                                fmt="{:.0f}%", on_change=self.on_change, bg=BG_PANEL)
        self.sl_rate = Slider(parent, "语速", -40, 60, self._rate_value(self.cfg.get("rate")),
                              fmt="{:+.0f}%", on_change=self.on_change, bg=BG_PANEL)
        row = self._row(parent, "音色")
        self.voice_index = self._voice_index()
        self.voice_label = self.tk.Label(row, text=self._voice_text(), bg=BG_PANEL, fg=self.accent,
                                         font=("Microsoft YaHei UI", 9))
        self.voice_label.pack(side="left", padx=4)
        self._chip(row, "试听", lambda: self.preview_voice()).pack(side="right", padx=6)
        # 抽屉式的音色列表：点一下"选择"把抽屉拉开，想用哪个直接点哪个
        # （以前是 ◀ ▶ 一个一个翻，17 个音色翻起来手都酸）
        self.voice_drawer_open = False
        self.voice_more = self._chip(row, "选择 ▾", lambda: self.toggle_voice_drawer())
        self.voice_more.pack(side="right", padx=(0, 6))
        self.voice_drawer = self.tk.Frame(parent, bg=CARD)
        self.voice_rows = {}
        self._build_voice_drawer()

    def _build_voice_drawer(self) -> None:
        """音色抽屉里的内容：一行一个，点哪行就是哪个，右边还有单独的「听」。"""
        tk = self.tk
        head = tk.Frame(self.voice_drawer, bg=CARD)
        head.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(head, text=f"想要哪个直接点（一共 {len(VOICES)} 个）", bg=CARD,
                 fg="#9a9aa5", font=("Microsoft YaHei UI", 8)).pack(side="left")
        self._chip(head, "收起", lambda: self.toggle_voice_drawer()).pack(side="right")
        for i, (_voice, label, _pitch, _fx) in enumerate(VOICES):
            line = tk.Frame(self.voice_drawer, bg=CARD)
            line.pack(fill="x", padx=8, pady=1)
            name = tk.Label(line, text=label, bg=CARD, fg="#ffffff", anchor="w",
                            font=("Microsoft YaHei UI", 9), padx=6, pady=3,
                            cursor="hand2")
            name.pack(side="left", fill="x", expand=True)
            name.bind("<Button-1>", lambda _e, idx=i: self.select_voice(idx))
            self._chip(line, "听", lambda idx=i: self.preview_voice(idx)).pack(
                side="right", padx=(4, 2))
            self.voice_rows[i] = name
        self.refresh_voice_rows()

    def toggle_voice_drawer(self) -> None:
        self.voice_drawer_open = not bool(getattr(self, "voice_drawer_open", False))
        if self.voice_drawer_open:
            self.voice_drawer.pack(fill="x", padx=12, pady=(2, 8))
            self.voice_more.config(text="选择 ▴")
        else:
            self.voice_drawer.pack_forget()
            self.voice_more.config(text="选择 ▾")
        self.root.after(10, self._on_stage_inner)    # 内容高了，滚轮范围跟着重算

    def select_voice(self, idx: int) -> None:
        """直接选第 idx 个音色（抽屉里点一下就行）。"""
        self.voice_index = max(0, min(len(VOICES) - 1, int(idx)))
        self.voice_label.config(text=self._voice_text())
        self.refresh_voice_rows()
        self.on_change()                            # 立刻生效 + 存进配置

    def refresh_voice_rows(self) -> None:
        for idx, lab in getattr(self, "voice_rows", {}).items():
            lab.config(bg=self.button_color if idx == self.voice_index else CARD,
                       fg="#ffffff")

    def build_look(self, parent) -> None:
        row = self._row(parent, "样式")
        self.wave_style_value = self.wave_style
        self.style_chips = {}
        for value, label in (("siri", "波形带"), ("bars", "声波条")):
            chip = self._chip(row, label, lambda v=value: self.set_wave_style(v))
            chip.pack(side="left", padx=3)
            self.style_chips[value] = chip
        self.refresh_style_chips()

        row = self._row(parent, "颜色")
        self.sw_color = self._swatch(row, "面板", self.panel_color)
        self.sw_accent = self._swatch(row, "线条", self.accent)
        self.sw_button = self._swatch(row, "按钮", self.button_color)
        self.sw_text = self._swatch(row, "文字", self.text_color)
        row = self._row(parent, "说话色")
        self.sw_talk = self._swatch(row, "我说话时", self.talk_color)
        self.tk.Label(row, text="朗读时声音条换成这个颜色，形状跟着语音变化",
                      bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8)).pack(
            side="left", padx=6)

        row = self._row(parent, "背景图")
        self.bg_path = self.cfg.get("overlay_bg_image") or ""
        self.bg_label = self.tk.Label(row, text=(Path(self.bg_path).name if self.bg_path else "无"),
                                      bg=BG_PANEL, fg="#9a9aa5", width=12, anchor="w",
                                      font=("Microsoft YaHei UI", 8))
        self.bg_label.pack(side="left", padx=4)
        self._chip(row, "清除", lambda: self.set_bg("")).pack(side="right", padx=4)
        self._chip(row, "选择", self.pick_bg).pack(side="right")

        self.sl_alpha = Slider(parent, "整体透明度", 35, 100, self.alpha * 100, fmt="{:.0f}%",
                               on_change=self.on_change, bg=BG_PANEL)
        self.sl_dim = Slider(parent, "背景变暗", 0, 90,
                             float(self.cfg.get("overlay_bg_dim") or 45), fmt="{:.0f}%",
                             on_change=self.on_change, bg=BG_PANEL)
        self.sw_wheel = self._switch_row(parent, "滚轮调透明度",
                                         bool(self.cfg.get("wheel_alpha", True)))
        self.sw_snap = self._switch_row(parent, "贴边吸附",
                                        bool(self.cfg.get("snap_edges", True)))
        # 悬浮窗本身的宽/高（按用户要求做成可调的；改完立刻量一次）
        self.sl_width = Slider(parent, "悬浮窗宽度", 240, 760, self.W, fmt="{:.0f}",
                               on_change=self.apply_size, bg=BG_PANEL)
        self.sl_height = Slider(parent, "悬浮窗高度", 76, 220, self.H, fmt="{:.0f}",
                                on_change=self.apply_size, bg=BG_PANEL)

        self.tk.Label(parent, text="声音条特效（各自独立开关；节能模式下会自动关掉）",
                      bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=14, pady=(8, 0))
        self.fx_switches = {}
        for key, label, hint in (
                ("fx_trail", "视觉暂留", "声音条拖一条慢慢淡掉的残影"),
                ("fx_glow", "呼吸光晕", "顺着条的形状往外铺的柔光，跟着声音一明一暗"),
                ("fx_sparkles", "星尘", "说话时溅出去的小亮点"),
                ("fx_reflection", "倒影", "条下面一层淡淡的反光"),
                ("fx_sweep", "流光", "一道高光沿着条扫过去"),
                ("fx_ripple", "波纹", "没声音时，那颗小圆点一圈圈荡开"),
                ("fx_aurora", "极光柔光", "小圆点外面那层光会慢慢换色"),
                ("fx_rotor", "旋转光环", "一圈虚线光环绕着圆点慢慢转"),
                ("fx_orbit", "卫星环绕", "两颗小卫星绕着圆点飞，拖着光尾"),
                ("fx_starflare", "星芒", "十字形的亮光，一明一暗地闪"),
                ("fx_heartbeat", "心跳脉动", "圆点像心跳那样「咚—咚」"),
                ("fx_burst", "唤醒爆闪", "被叫醒的一瞬间炸出一圈小火星")):
            row = self._row(parent, label)
            self.tk.Label(row, text=hint, bg=BG_PANEL, fg="#6f6f7a",
                          font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(0, 6))
            sw = Switch(row, bool(self.cfg.get(key, DEFAULTS[key])),
                        on_change=lambda _v, k=key: self.on_fx_change(k), bg=BG_PANEL)
            sw.canvas.pack(side="right", padx=(0, 10))
            self.fx_switches[key] = sw

        # ---- 布局（原来的「布局」页合到这里了：外观和布局本来就是一件事）
        self.tk.Label(parent, text="各元素的位置和大小（负数的 X 表示离右边多远）",
                      bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=14, pady=(8, 0))
        lay = self.layout
        self.sp_name = SpinRow(parent, "名字", [
            ("x", "X", lay["name"][0], 4, -200, 800),
            ("y", "Y", lay["name"][1], 2, -80, 400),
            ("s", "字号", lay["name"][2], 1, 8, 48)], on_change=self.on_change, bg=BG_PANEL)
        self.sp_status = SpinRow(parent, "状态", [
            ("x", "X", lay["status"][0], 4, -800, 800),
            ("y", "Y", lay["status"][1], 2, -80, 400),
            ("s", "字号", lay["status"][2], 1, 8, 40)], on_change=self.on_change, bg=BG_PANEL)
        self.sp_switch = SpinRow(parent, "开关", [
            ("x", "X", lay["switch"][0], 4, -800, 800),
            ("y", "Y", lay["switch"][1], 2, -80, 400)], on_change=self.on_change, bg=BG_PANEL)
        self.sp_wave = SpinRow(parent, "波浪", [
            ("y", "距底", lay["wave"][0], 2, 0, 120),
            ("h", "高度", lay["wave"][1], 2, 10, 80)], on_change=self.on_change, bg=BG_PANEL)
        self.sw_show = {}
        for key, label in (("name", "名字"), ("status", "状态"),
                           ("line", "波浪"), ("switch", "开关")):
            self.sw_show[key] = self._switch_row(
                parent, "显示" + label, bool(self.cfg.get(f"overlay_show_{key}", True)))

    def on_fx_change(self, key: str) -> None:
        """某个特效开关被拨动：立刻生效并预览，同时把状态存进配置。"""
        sw = getattr(self, "fx_switches", {}).get(key)
        if getattr(self, "_auto_low", False):
            # 你亲手动特效开关了：把"机器慢所以先关掉"那次降级撤掉，听你的
            before = getattr(self, "_fx_before_low", None) or {}
            self.fx.update({k: bool(v) for k, v in before.items()})
            self._auto_low = False
            self._fx_before_low = None
            self._auto_low_off = True
        self.fx[key] = bool(sw.get()) if sw is not None else bool(self.fx.get(key))
        if key == "fx_sparkles" and not self.fx[key]:
            self._sparks.clear()
        if key == "fx_trail" and not self.fx[key]:
            self._trail_img = None
        self.on_change()

    def build_smart(self, parent, more) -> None:
        """智能＝听和发；more 是「功能」页，好玩的和维护的都写在那。"""
        self._group(parent, "性能")
        row = self._row(parent, "性能模式")
        self.perf_value = str(self.cfg.get("perf_mode") or "quality")
        self.perf_chips = {}
        for value, label in (("eco", "节能"), ("standard", "标准"), ("quality", "质量")):
            chip = self._chip(row, label, lambda v=value: self.set_perf(v))
            chip.pack(side="left", padx=3)
            self.perf_chips[value] = chip
        self.refresh_perf_chips()
        note = self.tk.Frame(parent, bg=BG_PANEL)
        note.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(note, text="节能＝关掉设置里的界面动画；质量＝动画全开、帧率拉满",
                      bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        self.sl_anim = Slider(parent, "动画帧率", 15, 60, float(self.cfg.get("anim_fps") or 60),
                              fmt="{:.0f} fps", on_change=self.on_change, bg=BG_PANEL)
        self.sw_autotune = self._switch_row(parent, "低配自动降级",
                                            bool(self.cfg.get("auto_tune", True)))
        self.sl_followup = Slider(parent, "连续对话", 0, 30,
                                  float(self.cfg.get("followup_seconds") or 0),
                                  fmt="{:.0f} 秒", on_change=self.on_change, bg=BG_PANEL)
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(2, 6))
        self.tk.Label(row, text="说一次唤醒词后，这段时间内接着说就不用再喊它（0＝关闭）",
                      bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8)).pack(anchor="w")

        self._group(more, "提醒与日程")
        self.sw_reminder = self._switch_row(more, "提醒功能",
                                            bool(self.cfg.get("reminders_enabled", True)))

        self.sw_reminder_paste = self._switch_row(more, "提醒也发窗口",
                                                  bool(self.cfg.get("reminder_paste", False)))
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(row, text='说"10 分钟后提醒我喝水"就会到点念出来',
                      bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8)).pack(anchor="w")

        row = self._row(more, "快捷指令")
        self.shortcuts = dict(self.cfg.get("shortcuts") or {})
        self.shortcuts_label = self.tk.Label(row, text=self.shortcuts_summary(),
                                             bg=BG_PANEL, fg="#9a9aa5", anchor="w",
                                             font=("Microsoft YaHei UI", 8))
        self.shortcuts_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "编辑", self.edit_shortcuts).pack(side="right", padx=(4, 10))
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 8))
        self.tk.Label(row, text="每行一条：说中短语就执行  url:网址  app:程序  say:朗读的内容",
                      bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8)).pack(anchor="w")

        self._group(more, "好玩的功能")
        self.tk.Label(more, text="", bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=14, pady=(8, 0))
        self.sw_caption = self._switch_row(more, "实时字幕",
                                           bool(self.cfg.get("caption_enabled", True)))
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 2))
        self.tk.Label(row, text="没说完就先出半截字（会多占一点显卡）",
                      bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        self.sw_mood = self._switch_row(more, "语气反应",
                                        bool(self.cfg.get("mood_enabled", True)))
        self.sw_sleepy = self._switch_row(more, "悬浮窗养成",
                                          bool(self.cfg.get("mood_idle", True)))
        self.sw_spectrum = self._switch_row(more, "音浪模式",
                                            bool(self.cfg.get("wave_spectrum", False)))
        self.sw_karaoke = self._switch_row(more, "逐字跟读",
                                           bool(self.cfg.get("karaoke", True)))
        self.sw_diary = self._switch_row(more, "睡前日记",
                                         bool(self.cfg.get("diary_enabled", True)))
        self.sw_notheard = self._switch_row(more, "没听清时说一声",
                                            bool(self.cfg.get("not_heard_reply", True)))
        self.sw_big = self._switch_row(more, "大字幕",
                                       bool(self.cfg.get("big_caption", False)))
        # 语音截图（看屏幕）总开关：关掉之后说「看屏幕 / 看看这个」它就不截了，
        # 只说一声"这个功能我关掉了"，不会偷偷截你的屏幕。
        self.sw_shot = self._switch_row(more, "看屏幕截图",
                                        bool(self.cfg.get("screenshot_enabled", True)))
        self.sw_share = self._switch_row(more, "屏幕发手机",
                                         bool(self.cfg.get("screen_share", True)))
        self.sw_chime = self._switch_row(more, "整点报时",
                                         bool(self.cfg.get("hourly_chime", False)))
        self.sw_sit = self._switch_row(more, "久坐提醒",
                                       bool(self.cfg.get("sit_reminder", True)))
        self.sw_meeting = self._switch_row(more, "开会自动闭嘴",
                                           bool(self.cfg.get("meeting_mute", True)))
        self.sw_hotkey = self._switch_row(more, "朗读选中(Ctrl+Alt+R)",
                                          bool(self.cfg.get("read_hotkey", True)))
        self.sw_voiceprint = self._switch_row(more, "声纹提示（实验）",
                                              bool(self.cfg.get("voiceprint_warn", False)))
        self.sw_pet = self._switch_row(more, "桌宠",
                                       bool(self.cfg.get("pet_enabled", True)))
        # ---- 发送方式 / 模型 / 语音（这些改完要重启才生效的会标出来）
        self._group(parent, "发送")
        row = self._row(parent, "发送方式")
        self.send_mode_value = str(self.cfg.get("send_mode") or "paste_enter")
        self.send_chips = {}
        for value, label in (("paste_enter", "粘贴并回车"), ("paste", "只粘贴"),
                             ("type", "当打字机")):
            chip = self._chip(row, label, lambda v=value: self.set_send_mode(v))
            chip.pack(side="left", padx=3)
            self.send_chips[value] = chip
        self.refresh_send_chips()
        self.sw_confirm = self._switch_row(parent, "发之前先问我",
                                           bool(self.cfg.get("confirm_send", False)))
        self.sw_follow = self._switch_row(parent, "跟着当前窗口发",
                                          bool(self.cfg.get("follow_foreground", False)))
        self.sw_readreply = self._switch_row(
            parent, "自动念回答", bool(self.cfg.get("read_reply", True)))
        self.sw_tray = self._switch_row(parent, "托盘图标",
                                        bool(self.cfg.get("tray_enabled", True)))
        self.sw_gate = self._switch_row(parent, "只认我的声音",
                                        bool(self.cfg.get("voiceprint_gate", False)))
        # 📱 手机入口：手机浏览器打开这条网址就能发命令、看对话（改完要重启才生效）
        self.sw_phone = self._switch_row(parent, "手机入口",
                                         bool(self.cfg.get("phone_enabled", True)))
        row = self._row(parent, "手机网址")
        try:
            import phone_link
            url_now = phone_link.phone_url(int(self.cfg.get("phone_port") or 8765))
        except Exception:
            url_now = "（读不到网卡地址，重启后再看）"
        self.phone_url_label = self.tk.Label(
            row, text=url_now, bg=BG_PANEL, fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8))
        self.phone_url_label.pack(side="left", padx=(0, 6))
        self._chip(row, "复制", lambda: self.copy_phone_url()).pack(side="right")
        # 二维码按钮：点一下就把这条网址画成码，手机 APP 左上角「扫码」照一下就自动连上
        self._chip(row, "二维码", lambda: self.show_qr()).pack(side="right", padx=(0, 6))
        self.tk.Label(parent, text="手机连同一个 Wi-Fi，浏览器打开这条网址就行；"
                                   "出门在外面要用，点下面「外网访问」的一键开启",
                      bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                      wraplength=360, justify="left").pack(anchor="w", padx=14, pady=(0, 4))
        # 🌐 外网访问（Tailscale）—— 直接长在程序里：电脑上没装就帮它装、没登录就帮它登，
        # 完了给一条固定地址，手机不在同一个 Wi-Fi（用流量）也能连。
        self._group(parent, "外网访问（在外面也能连）")
        self.remote_label = self.tk.Label(
            parent, text="正在看…", bg=BG_PANEL, fg="#9a9aa5", anchor="w",
            justify="left", wraplength=350, font=("Microsoft YaHei UI", 8))
        self.remote_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(parent, "外网访问")
        self._chip(row, "一键开启", self.remote_enable).pack(side="right", padx=(4, 10))
        self._chip(row, "二维码", self.show_remote_qr).pack(side="right", padx=2)
        self._chip(row, "复制地址", self.copy_remote_url).pack(side="right", padx=2)
        self._chip(row, "刷新", self.refresh_remote).pack(side="right", padx=2)
        self._group(parent, "识别")
        row = self._row(parent, "唤醒词训练")
        self.tk.Label(row, text="念三遍让它记住你的口音", bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(side="left")
        self._chip(row, "开始训练", lambda: (send_command("expand"),
                                             self.flash("对着麦克风说「训练唤醒词」", 3))
                   ).pack(side="right", padx=(4, 10))
        row = self._row(parent, "识别模型")
        self.model_value = str(self.cfg.get("model") or "large-v3-turbo")
        self.model_chips = {}
        for value, label in (("small", "小(快)"), ("medium", "中"),
                             ("large-v3-turbo", "大(准)")):
            chip = self._chip(row, label, lambda v=value: self.set_model(v))
            chip.pack(side="left", padx=3)
            self.model_chips[value] = chip
        self.refresh_model_chips()
        row = self._row(parent, "识别语言")
        self.lang_value = str(self.cfg.get("lang") or "zh")
        self.lang_chips = {}
        for value, label in (("zh", "中文"), ("zh,en", "中英混说"), ("en", "英文")):
            chip = self._chip(row, label, lambda v=value: self.set_lang(v))
            chip.pack(side="left", padx=3)
            self.lang_chips[value] = chip
        self.refresh_lang_chips()
        row = self._row(parent, "改完生效")
        self.tk.Label(row, text="改模型或语言后要点重启", bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(side="left")
        self._chip(row, "重启程序", self.restart_program).pack(side="right", padx=(4, 10))
        self.sw_rec = self._switch_row(parent, "录音提示灯",
                                       bool(self.cfg.get("rec_indicator", True)))
        self._group(more, "数据与排查")
        self.entry_city = self._entry(more, "天气城市", self.cfg.get("weather_city") or "")
        row = self._row(more, "数据")
        self._chip(row, "导出", self.do_export).pack(side="right", padx=(4, 10))
        self._chip(row, "导入", self.do_import).pack(side="right", padx=2)
        self._chip(row, "清空", self.ask_clear).pack(side="right", padx=2)
        # 诊断包和导出包现在归到一块儿：都藏进程序目录里那个隐藏的「导出」文件夹
        row = self._row(more, "备份与诊断")
        self._chip(row, "打包诊断", self.do_diagnose).pack(side="right", padx=(4, 10))
        self._chip(row, "打开文件夹", self.open_backup_dir).pack(side="right", padx=2)
        self.backup_label = self.tk.Label(more, text=self.backup_summary(), bg=BG_PANEL,
                                          fg="#6f6f7a", anchor="w", justify="left",
                                          wraplength=max(220, self.expand_w - 40),
                                          font=("Microsoft YaHei UI", 8))
        self.backup_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(more, "系统日志")
        self.log_label = self.tk.Label(row, text=self.log_summary(), bg=BG_PANEL,
                                       fg="#9a9aa5", anchor="w",
                                       font=("Microsoft YaHei UI", 8))
        self.log_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "记事本", self.open_syslog).pack(side="right", padx=(4, 10))
        self._chip(row, "查看", self.open_log_window).pack(side="right", padx=2)
        row = self.tk.Frame(more, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(row, text="你急它偏暖、你轻它偏灰；两分钟没人理就打哈欠、四分钟打盹；"
                                "音浪＝声音条变频谱柱；跟读＝它念到哪个字哪个字亮；"
                                "大字幕＝屏幕底部一条大字",
                      bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        # 卸载：不用跑去桌面找快捷方式，设置里直接就能卸
        self._group(more, "卸载")
        row = self._row(more, "卸载")
        self._chip(row, "卸载语音助手…", self.ask_uninstall).pack(side="right", padx=(4, 10))
        self.tk.Label(more, text="会先问你：只卸运行环境和模型（聊天记录留着），"
                                 "还是连程序带记录一起删干净",
                      bg=BG_PANEL, fg="#6f6f7a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=(14, 10),
                                                           pady=(0, 6))

    def build_schedule(self, parent) -> None:
        """日程：日历/表格两种视图，全部长在悬浮窗里，不另开窗口。"""
        self.schedule_panel = SchedulePanel(self.tk, parent, self.cfg, self.on_change,
                                            button_color=self.button_color, accent=self.accent)

    def edit_schedules(self) -> None:
        """日程表编辑：一行 = 时间 / 周期 / 要发送的内容。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("编辑 · 日程表")
        win.configure(bg=BG_PANEL)
        win.geometry("700x460")
        win.attributes("-topmost", True)
        tk.Label(win, text="日程表", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(win, text="时间用 24 小时制（如 09:00）；周期填 每天 / 工作日 / 周末 / 周一,周三 / 一三五",
                 bg=BG_PANEL, fg="#8a8a95", font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=14)

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(8, 2))
        for text, width in (("时间", 8), ("周期", 16), ("要发送的内容", 40)):
            tk.Label(head, text=text, bg=BG_PANEL, fg="#8a8a95", width=width, anchor="w",
                     font=("Microsoft YaHei UI", 9)).pack(side="left", padx=2)

        holder = tk.Frame(win, bg=BG_PANEL)
        holder.pack(fill="both", expand=True, padx=14)
        canvas = tk.Canvas(holder, bg=BG_PANEL, highlightthickness=0)
        scroll = tk.Scrollbar(holder, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=BG_PANEL)
        canvas.create_window((0, 0), window=inner, anchor="nw", width=650)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        rows: list[dict] = []

        def add_row(time_text: str = "09:00", days: str = "每天", body: str = "") -> None:
            row = tk.Frame(inner, bg=BG_PANEL)
            row.pack(fill="x", pady=2)
            var_t = tk.StringVar(value=time_text)
            var_d = tk.StringVar(value=days)
            var_b = tk.StringVar(value=body)
            entry_kw = dict(bg=CARD, fg="#ffffff", insertbackground="#ffffff", relief="flat",
                            font=("Microsoft YaHei UI", 9))
            e1 = tk.Entry(row, textvariable=var_t, width=8, **entry_kw)
            e1.pack(side="left", padx=2, ipady=3)
            e2 = tk.Entry(row, textvariable=var_d, width=16, **entry_kw)
            e2.pack(side="left", padx=2, ipady=3)
            e3 = tk.Entry(row, textvariable=var_b, **entry_kw)
            e3.pack(side="left", fill="x", expand=True, padx=2, ipady=3)
            item = {"t": var_t, "d": var_d, "b": var_b, "frame": row}
            rows.append(item)

            def remove() -> None:
                row.destroy()
                rows.remove(item)

            tk.Label(row, text="✕", bg=BG_PANEL, fg="#ff8080", padx=6, cursor="hand2",
                     font=("Microsoft YaHei UI", 9)).pack(side="left")
            for widget in row.winfo_children():
                if widget["text"] == "✕":
                    widget.bind("<Button-1>", lambda _e: remove())
            return item

        for item in self.schedules:
            add_row(str(item.get("time") or "09:00"), str(item.get("days") or "每天"),
                    str(item.get("text") or ""))
        if not rows:
            add_row()

        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(6, 12))
        tk.Label(bar, text="＋ 添加一行", bg=CARD, fg="#ffffff", padx=12, pady=5,
                 cursor="hand2", font=("Microsoft YaHei UI", 9)).pack(side="left")
        bar.winfo_children()[0].bind("<Button-1>", lambda _e: add_row())

        def confirm() -> None:
            data = []
            for item in rows:
                body = item["b"].get().strip()
                when = item["t"].get().strip()
                if not body or not when:
                    continue
                data.append({"time": when, "days": item["d"].get().strip() or "每天",
                             "text": body, "enabled": True})
            self.schedules = data
            self.schedule_label.config(text=self.schedule_summary())
            self.on_change()
            win.destroy()

        ok = tk.Label(bar, text="保存", bg=self.button_color, fg="#ffffff", padx=22, pady=6,
                      cursor="hand2", font=("Microsoft YaHei UI", 10, "bold"))
        ok.pack(side="right")
        ok.bind("<Button-1>", lambda _e: confirm())
        cancel = tk.Label(bar, text="取消", bg=CARD, fg="#ffffff", padx=16, pady=6,
                          cursor="hand2", font=("Microsoft YaHei UI", 10))
        cancel.pack(side="right", padx=8)
        cancel.bind("<Button-1>", lambda _e: win.destroy())
        try:
            win.lift()
            win.focus_force()
            grab_foreground(win.winfo_id())
        except Exception:
            pass

    def _pick_chip(self, chips: dict, value: str) -> None:
        for k, chip in chips.items():
            chip.config(bg=self.button_color if k == value else CARD, fg="#ffffff")

    def set_send_mode(self, value: str) -> None:
        self.send_mode_value = value
        self._pick_chip(self.send_chips, value)
        self.on_change()
        self.flash("发送方式：" + {"paste_enter": "粘贴并回车", "paste": "只粘贴",
                                   "type": "当打字机"}.get(value, value), 2)

    def set_model(self, value: str) -> None:
        self.model_value = value
        self._pick_chip(self.model_chips, value)
        self.on_change()
        self.flash("模型改好了，点「重启程序」生效", 3)

    def set_lang(self, value: str) -> None:
        self.lang_value = value
        self._pick_chip(self.lang_chips, value)
        self.on_change()
        self.flash("语言改好了，点「重启程序」生效", 3)

    def refresh_send_chips(self) -> None:
        self._pick_chip(getattr(self, "send_chips", {}), self.send_mode_value)

    def refresh_model_chips(self) -> None:
        self._pick_chip(getattr(self, "model_chips", {}), self.model_value)

    def refresh_lang_chips(self) -> None:
        self._pick_chip(getattr(self, "lang_chips", {}), self.lang_value)

    def restart_program(self) -> None:
        self.flash("正在重启语音程序…", 3)
        send_command("restart")

    def do_export(self) -> None:
        self.flash("正在打包数据…（会藏进「导出」文件夹）", 2.5)
        send_command("export")
        self.root.after(1600, self.refresh_backup_label)

    def do_import(self) -> None:
        self.flash("正在导入最新的导出包…", 2.5)
        send_command("import")

    # ------------------------------------------------- 备份与诊断（都藏进导出文件夹）
    def backup_dir(self) -> Path:
        """和主程序一个规矩：包裹都放这儿，不往桌面上扔。"""
        folder = HERE / "导出"
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                try:
                    ctypes.windll.kernel32.SetFileAttributesW(str(folder), 0x02)  # 隐藏
                except Exception:
                    pass
            return folder
        except Exception:
            return HERE

    def backup_summary(self) -> str:
        """最新几个包：时间 + 大小，一眼看出有没有打出来。"""
        folder = self.backup_dir()
        packs = sorted(list(folder.glob("语音助手数据-*.zip"))
                       + list(folder.glob("语音助手诊断-*.zip")))
        if not packs:
            return "还没有导出 / 诊断包 · 都藏在这个文件夹里，不往桌面上扔"
        bits = []
        for path in packs[-3:][::-1]:
            m = re.match(r"语音助手(数据|诊断)-(\d{8})-(\d{4})(?:-\d+)?\.zip$", path.name)
            try:
                kb = path.stat().st_size / 1024
            except OSError:
                kb = 0
            if m:
                kind = m.group(1)
                when = (f"{m.group(2)[4:6]}/{m.group(2)[6:8]} "
                        f"{m.group(3)[:2]}:{m.group(3)[2:]}")
                bits.append(f"{kind} {when}（{kb:.0f}KB）")
            else:
                bits.append(f"{path.name}（{kb:.0f}KB）")
        more = f" · 共 {len(packs)} 个" if len(packs) > 3 else ""
        return "最新：" + "、".join(bits) + more + " · 藏在程序目录的「导出」里"

    def do_diagnose(self) -> None:
        self.flash("正在打包诊断…（会藏进「导出」文件夹）", 2.5)
        send_command("diagnose")
        self.root.after(1600, self.refresh_backup_label)

    def refresh_backup_label(self) -> None:
        label = getattr(self, "backup_label", None)
        if label is None:
            return
        try:
            label.config(text=self.backup_summary())
        except Exception:
            pass

    def open_backup_dir(self) -> None:
        folder = self.backup_dir()
        try:
            os.startfile(str(folder))
        except Exception:
            self.flash(f"打不开：{folder}", 3)

    # ------------------------------------------------- 卸载（悬浮窗里直接卸）
    def uninstall_command(self, full: bool) -> list[str]:
        """拼出"启动卸载程序"的命令行。单独拆出来，方便测。"""
        cmd_file = HERE / "卸载语音助手.cmd"
        if not cmd_file.exists():
            cmd_file = HERE / "uninstall.cmd"
        if cmd_file.exists():
            return ["cmd", "/c", str(cmd_file), "--yes"] + (["--full"] if full else [])
        # 连 .cmd 都没有就自己叫 uninstall.py
        return [sys.executable, str(HERE / "uninstall.py"), "--yes"] + \
               (["--full"] if full else [])

    def do_uninstall(self, full: bool) -> None:
        """真去卸：另开一个独立窗口跑卸载程序，进度你自己看得见。

        必须是"独立进程 + 独立窗口"：卸载程序干的第一件事就是把后台的我们全停掉，
        停完它还得接着干活，所以它不能挂在我们的进程树上。
        """
        cmd = self.uninstall_command(full)
        try:
            subprocess.Popen(cmd, cwd=str(HERE),
                             creationflags=0x00000010)   # CREATE_NEW_CONSOLE：看得见进度
        except Exception as exc:  # noqa: BLE001
            self.flash(f"卸载程序没起来：{exc}", 5)
            return
        note("从悬浮窗发起卸载：" + ("彻底删除（连记录）" if full else "卸载（保留记录）"))
        self.flash("卸载程序起来了，接下来交给它（后台的我会被它关掉）", 5)

    def ask_uninstall(self) -> None:
        """先问清楚要卸到哪一步。彻底删除要点两下，防手滑。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("卸载语音助手")
        win.configure(bg=BG_PANEL)
        win.geometry("456x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text="卸载语音助手", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w", padx=16,
                                                              pady=(14, 2))
        tk.Label(win, justify="left", anchor="w", bg=BG_PANEL, fg="#9a9aa5", wraplength=400,
                 font=("Microsoft YaHei UI", 8),
                 text="不管选哪个，都会先关掉后台的语音助手、取消开机自启、"
                      "删掉桌面和开始菜单里指向本程序的快捷方式。\n"
                      f"程序目录：{HERE}").pack(anchor="w", padx=16)

        card = tk.Frame(win, bg=CARD)
        card.pack(fill="x", padx=16, pady=10)
        tk.Label(card, text="删掉 .venv 运行环境、识别模型、日志（省几个 G）；"
                            "程序文件、设置、聊天记录都留着，以后想用重跑一次 setup.cmd 就行",
                 bg=CARD, fg="#c9c9d6", justify="left", anchor="w", wraplength=370,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=12, pady=(8, 0))
        b1 = tk.Label(card, text="① 卸载（保留我的记录）", bg=self.button_color,
                      fg="#ffffff", font=("Microsoft YaHei UI", 10, "bold"),
                      pady=8, cursor="hand2")
        b1.pack(fill="x", padx=12, pady=(6, 10))

        warn = tk.Label(win, text="整个文件夹连聊天记录、日记、记账一起删干净，删完找不回来",
                        bg=BG_PANEL, fg="#9a9aa5", justify="left", anchor="w",
                        wraplength=400, font=("Microsoft YaHei UI", 8))
        warn.pack(anchor="w", padx=16)
        b2 = tk.Label(win, text="② 彻底删除（连程序和记录一起清掉）", bg=CARD,
                      fg="#ff8080", font=("Microsoft YaHei UI", 10, "bold"),
                      pady=8, cursor="hand2")
        b2.pack(fill="x", padx=16, pady=(6, 4))
        armed = {"on": False}

        def pick_keep(_e=None) -> None:
            win.destroy()
            self.do_uninstall(False)

        def pick_full(_e=None) -> None:
            if not armed["on"]:      # 第一下只是"解锁"，防手滑
                armed["on"] = True
                b2.config(text="真的要全删？再点一次就动手", bg="#7a1f1f")
                warn.config(text="连聊天记录和设置一起删，没有回收站，删完就真没了",
                            fg="#ff8080")
                return
            win.destroy()
            self.do_uninstall(True)

        def pick_cancel(_e=None) -> None:
            win.destroy()
            self.flash("没卸，什么都没动", 2)

        b1.bind("<Button-1>", pick_keep)
        b2.bind("<Button-1>", pick_full)
        b1.bind("<Enter>", lambda _e: b1.config(bg=self.accent))
        b1.bind("<Leave>", lambda _e: b1.config(bg=self.button_color))
        b2.bind("<Enter>", lambda _e: b2.config(bg="#5a1717" if armed["on"] else "#2c2c36"))
        b2.bind("<Leave>", lambda _e: b2.config(bg="#7a1f1f" if armed["on"] else CARD))
        cancel = tk.Label(win, text="先不卸了", bg=BG_PANEL, fg="#9a9aa5",
                          font=("Microsoft YaHei UI", 9), cursor="hand2")
        cancel.pack(pady=(2, 10))
        cancel.bind("<Button-1>", pick_cancel)
        win.bind("<Escape>", pick_cancel)
        try:
            win.lift()
            win.focus_force()
        except Exception:
            pass

    def ask_clear(self) -> None:
        self.flash("要清空就说「清空所有记录」再「确定清空」", 3)

    def publish_site(self) -> None:
        """把下载页发布到公网网站（第一次要填一次仓库地址、登录一次，以后自动）。

        发布之后：更新就以**网站上的文件**为准 —— 两边 APP 都去读那上面的
        version.json，网站一更新，提示就跟着变。
        """
        import site_publish

        tk = self.tk
        cur_repo = site_publish.repo_url()
        win = tk.Toplevel(self.root)
        win.title("发布下载页到网站")
        win.configure(bg=BG_PANEL)
        win.geometry("560x330")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text="发布到网站（免费静态托管）", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w", padx=18,
                                                               pady=(14, 2))
        tk.Label(win, text="第一次：先在 github.com 建一个空仓库（Public），把它的 https 地址\n"
                           "贴到下面；点「发布」会弹一次登录，登完就记住了。\n"
                           "以后每次更新，打包时会**自动**重新生成并推上去。",
                 bg=BG_PANEL, fg="#8a8a95", font=("Microsoft YaHei UI", 9),
                 justify="left").pack(anchor="w", padx=18)
        tk.Label(win, text="仓库地址（https://github.com/用户名/仓库名.git）",
                 bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(12, 2))
        repo_var = tk.StringVar(value=cur_repo)
        tk.Entry(win, textvariable=repo_var, bg=CARD, fg="#ffffff", relief="flat",
                 insertbackground="#ffffff",
                 font=("Consolas", 10)).pack(fill="x", padx=18, ipady=6)
        tk.Label(win, text="网站网址（发布成功后填，形如 https://用户名.github.io/仓库名/）",
                 bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(10, 2))
        url_var = tk.StringVar(value=site_publish.public_url())
        tk.Entry(win, textvariable=url_var, bg=CARD, fg="#ffffff", relief="flat",
                 insertbackground="#ffffff",
                 font=("Consolas", 10)).pack(fill="x", padx=18, ipady=6)
        msg = tk.Label(win, text="", bg=BG_PANEL, fg=self.accent,
                       font=("Microsoft YaHei UI", 9), wraplength=520, justify="left")
        msg.pack(anchor="w", padx=18, pady=(10, 0))
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(10, 14))

        def do_publish() -> None:
            repo = repo_var.get().strip()
            url = url_var.get().strip()
            site_publish.configure(repo=repo, url=url)
            msg.config(text="正在发布…（第一次会弹一个登录窗口，登一次就行）")

            def run() -> None:
                # 你自己点的这个按钮 = 现在就发（不管攒够没攒够）
                ok, why, did = site_publish.publish(force=True)
                self.root.after(0, lambda: msg.config(
                    text=("发布成功：" + (url or site_publish.public_url() or "（记得填网站网址）"))
                    if ok else ("没发上去：" + why),
                    fg=self.accent if ok else "#ff9a9a"))
                if ok:
                    self.root.after(0, lambda: self.flash("网站上已经是新版了", 3))

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(bar, text="发布", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=20, pady=6,
                        cursor="hand2")
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _e: do_publish())
        close = tk.Label(bar, text="关掉", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        close.pack(side="right", padx=8)
        close.bind("<Button-1>", lambda _e: win.destroy())

    def check_update(self) -> None:
        """检查更新：读的是**下载页那份数据**（网页刷新了，这边就提示）。

        来源默认是本机这一份（http://127.0.0.1:端口/dl/version.json）—— 跟别人看到的
        下载页是同一个东西。要是把下载页传到了公网，在设置里把「更新源」填成那个网址，
        跑到哪儿都能收到提示。
        """
        if self.upd_label is not None:
            self.upd_label.config(text="正在检查…", fg="#7f7f8a")
        self.flash("正在检查更新…", 1.6)

        def work() -> None:
            try:
                import self_update

                got = self_update.check(self.cfg)
            except Exception as exc:            # noqa: BLE001
                got = {"ok": False, "err": f"{type(exc).__name__}: {exc}"[:80]}
            self.root.after(0, lambda: self._update_result(got))

        threading.Thread(target=work, daemon=True).start()

    def _update_result(self, got: dict) -> None:
        """检查结果：没新版就说一声，有新版就弹个窗口问你要不要装。"""
        if not got.get("ok"):
            why = str(got.get("err") or "读不到更新信息")
            if self.upd_label is not None:
                self.upd_label.config(text=why, fg="#ff9a9a")
            self.flash(why, 3)
            return
        pc = got.get("pc") or {}
        if not got.get("pc_new"):
            text = f"已是最新（v{version.APP_VERSION}）"
            if self.upd_label is not None:
                self.upd_label.config(text=text, fg="#7f8f86")
            self.flash(text, 2.4)
            return
        ver = str(pc.get("version"))
        if self.upd_label is not None:
            self.upd_label.config(text=f"有新版 v{ver}", fg=self.accent)
        self._update_dialog(ver, pc, str(got.get("src") or ""))

    def _update_dialog(self, ver: str, pc: dict, src: str) -> None:
        """有新版本：把更新内容摆出来，问你是"一键更新"还是"自己去下载页下"。"""
        import self_update

        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("有新版")
        win.configure(bg=BG_PANEL)
        win.geometry("470x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text=f"有新版本 v{ver}", bg=BG_PANEL, fg=self.accent,
                 font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w", padx=18,
                                                               pady=(16, 2))
        tk.Label(win, text=f"你现在是 v{version.APP_VERSION} · "
                           f"新版 {pc.get('size') or ''}", bg=BG_PANEL, fg="#8a8a95",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18)
        box = tk.Frame(win, bg=CARD)
        box.pack(fill="both", expand=True, padx=18, pady=(10, 8))
        txt = tk.Text(box, bg=CARD, fg="#e6e6ec", relief="flat", wrap="word",
                      font=("Microsoft YaHei UI", 9), insertbackground="#ffffff")
        txt.pack(fill="both", expand=True, padx=10, pady=10)
        txt.insert("1.0", "这一版改了什么：\n\n" + (self_update.notes_text(pc, 4)
                                                    or "（更新说明见下载页）"))
        txt.config(state="disabled")
        tk.Label(win, text="「一键更新」会下载更新包、自动关掉程序再装好（装完自己开回来）",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 wraplength=430, justify="left").pack(anchor="w", padx=18)
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(8, 14))

        def open_page() -> None:
            try:
                import webbrowser

                page = src[:-len("version.json")] if src.endswith("version.json") else src
                webbrowser.open(page)
                self.flash("下载页已经用浏览器打开了", 3)
            except Exception as exc:            # noqa: BLE001
                self.flash(f"打不开浏览器：{exc}", 3)

        def one_click() -> None:
            for child in bar.winfo_children():
                child.destroy()
            tk.Label(bar, text="正在下载更新包…（下完程序会自己关掉重开）",
                     bg=BG_PANEL, fg=self.accent,
                     font=("Microsoft YaHei UI", 9)).pack(side="left")

            def run() -> None:
                url = self_update.resolve(src, str(pc.get("update_url") or ""))
                ok, why = self_update.apply_update(url, HERE)
                self.root.after(0, lambda: self.flash(
                    "更新包开始装了，程序会自己重开" if ok else f"更新失败：{why}", 4))

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(bar, text="一键更新", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=6,
                        cursor="hand2")
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _e: one_click())
        later = tk.Label(bar, text="以后再说", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        later.pack(side="right", padx=8)
        later.bind("<Button-1>", lambda _e: win.destroy())
        page = tk.Label(bar, text="打开下载页", bg=CARD, fg="#ffffff",
                        font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        page.pack(side="right", padx=8)
        page.bind("<Button-1>", lambda _e: open_page())

    def show_about(self) -> None:
        """关于：作者、邮箱、版权、使用许可 —— 全软件只在这一个窗口里显示。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("关于")
        win.configure(bg=BG_PANEL)
        win.geometry("460x430")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text=f"语音助手 · {self.name}", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w", padx=18,
                                                               pady=(16, 2))
        tk.Label(win, text=version.label(), bg=BG_PANEL, fg="#8a8a95",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18)
        box = tk.Frame(win, bg=CARD)
        box.pack(fill="x", padx=18, pady=(12, 10))
        for text, color, size in (
                (f"作者：{version.AUTHOR}", "#ffffff", 11),
                (f"邮箱：{version.CONTACT}", "#ffffff", 11),
                (version.COPYRIGHT, "#9a9aa5", 10),
                (version.FREE_LINE, self.accent, 10)):
            tk.Label(box, text=text, bg=CARD, fg=color, anchor="w", justify="left",
                     wraplength=390, font=("Microsoft YaHei UI", size)).pack(
                         anchor="w", padx=14, pady=(8 if size == 11 else 2, 0))
        tk.Label(box, text="", bg=CARD, font=("Microsoft YaHei UI", 4)).pack()
        tk.Label(win, text=version.NOTICE, bg=BG_PANEL, fg="#6f6f7a", anchor="w",
                 justify="left", wraplength=400,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=18)
        close = tk.Label(win, text="知道了", bg=self.button_color, fg="#ffffff",
                         font=("Microsoft YaHei UI", 10, "bold"), padx=22, pady=6,
                         cursor="hand2")
        close.pack(pady=(14, 12))
        close.bind("<Button-1>", lambda _e: win.destroy())
        win.bind("<Escape>", lambda _e: win.destroy())
        try:
            win.lift()
            win.focus_force()
        except Exception:
            pass

    def log_summary(self) -> str:
        """系统日志现在有多大、有多少行。"""
        try:
            lines = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return "（还没有记录）"
        size = SYSLOG_FILE.stat().st_size
        return f"{len(lines)} 行 · {size / 1024:.0f} KB · syslog.md"

    def open_syslog(self) -> None:
        try:
            os.startfile(str(SYSLOG_FILE))
        except Exception:
            self.flash("打不开日志文件", 2)

    # ------------------------------------------------- 对话日志小窗口
    LOG_KINDS = {           # 日志里的标记 -> (给你的名字, 颜色)
        "听": ("你说", "#3ddc84"),
        "发": ("发出去", "#4aa3ff"),
        "念": ("它念", "#22d3ee"),
        "答": ("AI 回答", "#c084fc"),
        "做": ("做的事", "#c9a227"),
        "编": ("改设置", "#9a9aa5"),
        "声": ("声纹", "#7f7f8a"),
        "噪": ("噪声", "#6f6f7a"),
        "醒": ("唤醒", "#7fd4a8"),
    }
    TALK_KINDS = ("听", "发", "念", "答")

    def open_log_window(self) -> None:
        """对话日志做成一个小窗口，直接在里头看，不用去开记事本。"""
        tk = self.tk
        win = getattr(self, "log_win", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.deiconify()
                    win.lift()
                    self.refresh_log_window()
                    return
            except Exception:
                pass
        win = tk.Toplevel(self.root)
        self.log_win = win
        win.title("对话日志")
        win.configure(bg=BG_PANEL)
        win.geometry("620x460")
        win.minsize(420, 280)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(12, 2))
        tk.Label(head, text="对话日志", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left")
        self.log_count = tk.Label(head, text="", bg=BG_PANEL, fg="#6f6f7a",
                                  font=("Microsoft YaHei UI", 8))
        self.log_count.pack(side="right")
        tk.Label(win, text="你和它说过的每句话、它发出去的和念出来的，都在这儿（越往下越新）",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 anchor="w").pack(fill="x", padx=14, pady=(0, 6))

        tool = tk.Frame(win, bg=BG_PANEL)
        tool.pack(fill="x", padx=14, pady=(0, 4))
        self.log_only_talk = tk.BooleanVar(value=True)
        self.log_filter_chips = {}
        for value, label in ((True, "只看对话"), (False, "全都看")):
            chip = tk.Label(tool, text=label, bg=CARD, fg="#ffffff", padx=10, pady=3,
                            cursor="hand2", font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=(0, 4))
            chip.bind("<Button-1>", lambda _e, v=value: self.set_log_filter(v))
            self.log_filter_chips[value] = chip
        tk.Label(tool, text="搜", bg=BG_PANEL, fg="#9a9aa5",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(8, 2))
        self.log_search = tk.StringVar(value="")
        entry = tk.Entry(tool, textvariable=self.log_search, bg=CARD, fg="#ffffff",
                         insertbackground="#ffffff", relief="flat",
                         font=("Microsoft YaHei UI", 9))
        entry.pack(side="left", fill="x", expand=True, padx=(0, 6), ipady=2)
        self.log_search.trace_add("write", lambda *_a: self.refresh_log_window())
        again = tk.Label(tool, text="刷新", bg=CARD, fg="#ffffff", padx=10, pady=3,
                         cursor="hand2", font=("Microsoft YaHei UI", 9))
        again.pack(side="right")
        again.bind("<Button-1>", lambda _e: self.refresh_log_window())

        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=14)
        text = tk.Text(body, bg="#16161b", fg="#d8d8e0", relief="flat", wrap="word",
                       insertbackground="#ffffff", font=("Microsoft YaHei UI", 9),
                       padx=10, pady=8, spacing1=1, spacing3=2, height=12)
        bar = tk.Scrollbar(body, command=text.yview, bg=CARD, troughcolor=BG_PANEL,
                           relief="flat", width=12)
        text.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        text.tag_config("stamp", foreground="#5f5f68")
        for tag, (_name, color) in self.LOG_KINDS.items():
            text.tag_config(tag, foreground=color)
        text.tag_config("body", foreground="#d8d8e0")
        self.log_text = text

        foot = tk.Frame(win, bg=BG_PANEL)
        foot.pack(fill="x", padx=14, pady=(6, 12))
        close = tk.Label(foot, text="关闭", bg=CARD, fg="#ffffff", padx=16, pady=5,
                         cursor="hand2", font=("Microsoft YaHei UI", 9))
        close.pack(side="right")
        close.bind("<Button-1>", lambda _e: self.close_log_window())
        note_btn = tk.Label(foot, text="用记事本打开", bg=BG_PANEL, fg="#9a9aa5",
                            padx=8, pady=5, cursor="hand2", font=("Microsoft YaHei UI", 8))
        note_btn.pack(side="right", padx=6)
        note_btn.bind("<Button-1>", lambda _e: self.open_syslog())
        self.log_hint = tk.Label(foot, text="", bg=BG_PANEL, fg="#6f6f7a",
                                 font=("Microsoft YaHei UI", 8))
        self.log_hint.pack(side="left")
        win.bind("<Escape>", lambda _e: self.close_log_window())
        win.protocol("WM_DELETE_WINDOW", self.close_log_window)
        self._log_seen = 0
        self.refresh_log_window()
        self._log_tick()

    def close_log_window(self) -> None:
        win = getattr(self, "log_win", None)
        self.log_win = None
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass

    def set_log_filter(self, only_talk: bool) -> None:
        self.log_only_talk.set(bool(only_talk))
        for value, chip in getattr(self, "log_filter_chips", {}).items():
            chip.config(bg=self.button_color if value == only_talk else CARD)
        self.refresh_log_window()

    def refresh_log_window(self) -> None:
        text = getattr(self, "log_text", None)
        if text is None:
            return
        try:
            if not self.log_win.winfo_exists():
                return
        except Exception:
            return
        only = bool(getattr(self, "log_only_talk", None) and self.log_only_talk.get())
        needle = (getattr(self, "log_search", None) and self.log_search.get().strip()) or ""
        try:
            lines = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            lines = []
        rows = []
        for line in lines[-900:]:                     # 再多也没人往下翻
            kind = ""
            if line.startswith("20") and "[" in line:
                try:
                    kind = line.split("[", 1)[1].split("]", 1)[0]
                except Exception:
                    kind = ""
            if only and kind not in self.TALK_KINDS:
                continue
            if needle and needle not in line:
                continue
            rows.append((kind, line))
        try:
            at_bottom = text.yview()[1] > 0.97
        except Exception:
            at_bottom = True
        text.configure(state="normal")
        text.delete("1.0", "end")
        for kind, line in rows:
            stamp, rest = line[:19], line[19:]
            text.insert("end", stamp, "stamp")
            text.insert("end", rest + "\n", kind if kind in self.LOG_KINDS else "body")
        text.configure(state="disabled")
        for value, chip in getattr(self, "log_filter_chips", {}).items():
            chip.config(bg=self.button_color if value == only else CARD)
        if getattr(self, "log_count", None) is not None:
            self.log_count.config(text=f"{len(rows)} 行"
                                       + (f" · 搜「{needle}」" if needle else ""))
        if at_bottom or getattr(self, "_log_seen", 0) != len(rows):
            text.see("end")
        self._log_seen = len(rows)
        if getattr(self, "log_hint", None) is not None:
            self.log_hint.config(text="新的一行会自动跳到底；往上翻就不会被拽走了")

    def _log_tick(self) -> None:
        """开着的时候每两秒自己刷一次，不用手点。"""
        win = getattr(self, "log_win", None)
        if win is None:
            return
        try:
            if not win.winfo_exists():
                return
        except Exception:
            return
        try:
            size = SYSLOG_FILE.stat().st_mtime_ns
        except OSError:
            size = 0
        if size != getattr(self, "_log_mtime", None):
            self._log_mtime = size
            self.refresh_log_window()
        try:
            win.after(2000, self._log_tick)
        except Exception:
            pass

    def shortcuts_summary(self) -> str:
        if not self.shortcuts:
            return "（还没设置）"
        return f"{len(self.shortcuts)} 条：" + "、".join(list(self.shortcuts)[:3])

    def edit_shortcuts(self) -> None:
        text = "\n".join(f"{k}={v}" for k, v in self.shortcuts.items())

        def apply(value: str) -> None:
            data = {}
            for line in value.splitlines():
                line = line.strip()
                if not line or "=" not in line:
                    continue
                key, _, action = line.partition("=")
                key, action = key.strip(), action.strip()
                if key and action:
                    data[key] = action
            self.shortcuts = data
            self.shortcuts_label.config(text=self.shortcuts_summary())
            self.on_change()

        self.edit_text("快捷指令", text, apply, multiline=True)

    def _group(self, parent, title: str) -> None:
        """设置页里的一级分组标题。"""
        tk = self.tk
        bar = tk.Frame(parent, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(bar, text=title, bg=BG_PANEL, fg=self.accent,
                 font=("Microsoft YaHei UI", 9, "bold")).pack(side="left")
        tk.Frame(bar, bg=BORDER, height=1).pack(side="left", fill="x",
                                                expand=True, padx=(8, 0))

    def _row(self, parent, label):
        tk = self.tk
        row = tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", pady=3)
        tk.Label(row, text=label, bg=BG_PANEL, fg="#ffffff", width=12, anchor="w",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(10, 4))
        return row

    def _chip(self, parent, text, command):
        chip = self.tk.Label(parent, text=text, bg=CARD, fg="#ffffff",
                             font=("Microsoft YaHei UI", 9), padx=10, pady=3, cursor="hand2")
        chip.bind("<Button-1>", lambda _e: command())
        return chip

    def copy_phone_url(self) -> None:
        """把手机入口网址塞进剪贴板（手机扫不出码，但可以直接发给自己）。"""
        try:
            url = self.phone_url_now()
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("网址已复制，发到手机上打开就行")
        except Exception:
            self.flash("复制失败，手动抄一下这条网址")

    def phone_url_now(self) -> str:
        """现读一遍手机入口网址（网卡换了、端口改了都会跟着变）。"""
        try:
            import phone_link
            return phone_link.phone_url(int(self.cfg.get("phone_port") or 8765))
        except Exception:
            pass
        try:
            return str(self.phone_url_label.cget("text"))
        except Exception:
            return ""

    # ------------------------------------------------ 外网访问（Tailscale，内置的）
    # 用户要的是"别让我自己去装 Tailscale"：所以电脑端这块全自动 ——
    # 一键 = 没装就装（winget / 官方 msi）、没登录就登（自动开登录页）、完了给固定地址。
    def refresh_remote(self) -> None:
        """看一眼外网状态写进那一行小字。跑在后台线程里，别卡界面。"""
        threading.Thread(target=self._remote_report, daemon=True).start()
        self._remote_poll()

    def _remote_report(self, flash=None) -> None:
        """（后台线程里跑）读一次外网状态，结果放 _remote_job，等主线程来取。

        注意：Tk 的界面只能在主线程碰 —— 所以这里一个控件都不动，
        只往属性里塞结果，由主线程的 _remote_poll 去显示。
        """
        try:
            import remote_access
            st = remote_access.detail(fresh=True)
            if st["logged_in"]:
                # 只显前一半地址（令牌那串不摆出来，免得看着乱）：要完整的点「复制地址」
                text = ("已经通了 ✅  账号 %s · 设备 %s\n"
                        "手机在外面：点「复制地址」发到手机上，或用 APP 的「扫码」照二维码\n"
                        "%s（固定不变，重启电脑也一样）"
                        % (st["account"] or "—", st["device"] or "—",
                           self._masked_url(st["url"])))
                color = "#3ddc84"
            else:
                text = st["why"] or "外网访问现在用不了"
                color = "#e0b050"
            self.remote_fixed_url = st["url"]
            self.remote_fixed_alt = st.get("alt_url", "")
        except Exception as exc:                             # noqa: BLE001
            text = "读不到外网状态：%s（点「刷新」再试）" % exc
            color = "#e0b050"
        self._remote_job = (text, color)
        if flash:
            self._remote_flash = flash

    @staticmethod
    def _masked_url(url: str) -> str:
        """把地址里的令牌那截去掉，只留人看得懂的 http://ip:端口/?k=…。"""
        try:
            at = str(url or "").find("?k=")
            return (str(url)[:at + 3] + "…") if at > 0 else str(url or "")
        except Exception:                                    # noqa: BLE001
            return str(url or "")

    def _remote_poll(self, tries: int = 0) -> None:
        """（主线程）等后台那次读完了就显示出来；最多等 18 秒。"""
        job = getattr(self, "_remote_job", None)
        if job is not None:
            self._remote_job = None
            try:
                self.remote_label.config(text=job[0], fg=job[1])
            except Exception:                                # noqa: BLE001
                pass
            toast = getattr(self, "_remote_flash", None)
            if toast:
                self._remote_flash = None
                self.flash(toast[0], toast[1])
            return
        if tries < 120:
            try:
                self.root.after(150, lambda n=tries + 1: self._remote_poll(n))
            except Exception:                                # noqa: BLE001
                pass

    def remote_enable(self) -> None:
        """一键开启外网访问：装 → 登 → 显示固定地址。"""
        self.flash("正在弄外网访问，可能要你点一下「是」（装 Tailscale 那一步）…", 5)

        def work() -> None:
            try:
                import remote_access
                ok, msg = remote_access.enable(progress=None)
            except Exception as exc:                         # noqa: BLE001
                ok, msg = False, "出错了：%s" % exc
            # 成的时候 msg 本身就是一句完整的话；失败的时候补个前缀，免得看不出是哪儿出的问题
            self._remote_report(flash=(msg if ok else "外网访问没弄成：%s" % msg, 7))
            try:
                inputlog("点了「一键开启外网访问」")
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def copy_remote_url(self) -> None:
        """把外网那条固定地址塞进剪贴板（发给手机，或者手机扫码）。"""
        try:
            import remote_access
            url = getattr(self, "remote_fixed_url", "") or remote_access.fixed_url()
            if not url:
                self.flash("还没有外网地址 —— 先点「一键开启」", 4)
                return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("外网固定地址已复制，发到手机上就行", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)

    def show_remote_qr(self) -> None:
        """把外网固定地址也画成二维码 —— 手机 APP 里「扫码」照一下就切过去了。"""
        tk = self.tk
        try:
            import remote_access
            st = remote_access.detail(fresh=True)
        except Exception as exc:                             # noqa: BLE001
            self.flash("读不到外网地址：%s" % exc, 4)
            return
        url = st.get("url") or ""
        if not url:
            self.flash(st.get("why") or "还没有外网地址 —— 先点「一键开启」", 5)
            return
        import qr_tools

        win = tk.Toplevel(self.root)
        win.title("外网地址二维码")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 340) // 2
            y = self.root.winfo_y() + 40
            win.geometry("340x470+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:
            win.geometry("340x470")
        tk.Label(win, text="在外面也能连", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(14, 2))
        tk.Label(win, text="手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就换成外网那条；"
                           "前提是手机上装了 Tailscale 并登了电脑上这个账号",
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=290, justify="center").pack(padx=14)
        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=24, pady=10)
        keep = {"photo": None}
        if not qr_tools.available():
            holder.config(image="", width=28, height=10, compound="center",
                          fg="#333333", font=("Microsoft YaHei UI", 10),
                          text="这台机器少一个画二维码的小库")
        else:
            try:
                img = qr_tools.qr_image(url, box=1, border=3,
                                        dark="#101014", light="#ffffff")
                k = max(3, 250 // max(1, img.width))
                img = img.resize((img.width * k, img.height * k), Image.NEAREST)
                keep["photo"] = ImageTk.PhotoImage(img)
                holder.config(image=keep["photo"], text="", width=0, height=0)
                win._va_qr = keep["photo"]                   # 留着引用，不然白板
            except Exception as exc:                         # noqa: BLE001
                holder.config(image="", text="画不出来：%s" % exc, fg="#333333",
                              width=28, height=10, compound="center")
        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(2, 6))
        self._chip(btns, "复制地址", lambda: self.copy_remote_url()).pack(side="left", padx=4)
        tk.Label(win, text=url, bg=BG_PANEL, fg="#9a9aa5", font=("Consolas", 8),
                 wraplength=296, justify="center").pack(padx=14, pady=(4, 2))
        if st.get("account"):
            tk.Label(win, text="账号：%s" % st["account"], bg=BG_PANEL, fg="#6f6f7a",
                     font=("Microsoft YaHei UI", 8)).pack(pady=(0, 10))
        inputlog("点了「外网地址二维码」")

    def show_qr(self) -> None:
        """把手机入口网址画成二维码弹出来（本地画的，不联网）。

        手机端 APP 左上角有「扫码」，照一下这个码就自动连上电脑：
        不用手敲 IP，也不用抄那串令牌。
        """
        tk = self.tk
        import qr_tools

        url = self.phone_url_now()
        self.qr_url = url
        old = getattr(self, "qr_win", None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        self.qr_win = win
        win.title("手机扫码连接")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        size = "380x560"
        try:                       # 贴着悬浮窗弹出来，别飞到屏幕另一头去
            x = self.root.winfo_x() + (self.root.winfo_width() - 380) // 2
            y = self.root.winfo_y() + 40
            win.geometry(f"{size}+{max(0, x)}+{max(0, y)}")
        except Exception:
            win.geometry(size)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        tk.Label(win, text="手机扫码连接", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(16, 2))
        tk.Label(win, text="手机 APP 左上角点「扫码」，照一下这个码就自动连上；"
                           "没装 APP 直接用相机扫也行，扫出来是个网页",
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=330, justify="center").pack(padx=16)

        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=26, pady=12)
        keep = {"photo": None}

        def paint() -> None:
            if not qr_tools.available():
                keep["photo"] = None
                holder.config(image="", width=30, height=10, compound="center",
                              fg="#333333", font=("Microsoft YaHei UI", 10),
                              text="这台机器少一个画二维码的小库\n"
                                   "点下面「装一下二维码库」就行")
                return
            try:
                # 一个格子 1 像素先画出来，再整倍数放大 —— 边角才是硬的，扫得准
                img = qr_tools.qr_image(url, box=1, border=3,
                                        dark="#101014", light="#ffffff")
                k = max(3, 264 // max(1, img.width))
                img = img.resize((img.width * k, img.height * k), Image.NEAREST)
                keep["photo"] = ImageTk.PhotoImage(img)   # 得留着引用，不然白板
                self.qr_photo = keep["photo"]             # 也给测试留个抓手
                holder.config(image=keep["photo"], text="", width=0, height=0)
            except Exception as exc:                      # noqa: BLE001
                holder.config(image="", text=f"画不出来：{exc}", fg="#333333",
                              width=30, height=10, compound="center")

        def install_lib() -> None:
            self.flash("正在装二维码库，几秒钟…", 3)

            def work() -> None:
                ok, msg = qr_tools.install()
                self.root.after(0, lambda: (paint(), self.flash(msg, 3.5)))

            threading.Thread(target=work, daemon=True).start()

        def save_png() -> None:
            from tkinter import filedialog

            if not qr_tools.available():
                self.flash("先装上二维码库再存图", 3)
                return
            desk = Path.home() / "Desktop"
            path = filedialog.asksaveasfilename(
                parent=win, title="保存二维码", defaultextension=".png",
                initialdir=str(desk if desk.is_dir() else Path.home()),
                initialfile="手机入口二维码.png",
                filetypes=[("PNG 图片", "*.png"), ("所有文件", "*.*")])
            if not path:
                return
            try:
                qr_tools.qr_image(url, box=10, border=4).save(path)
            except Exception as exc:                      # noqa: BLE001
                self.flash(f"存不了：{exc}", 4)
                return
            self.flash(f"二维码存到 {Path(path).name} 了", 3)
            note(f"手机二维码另存到 {path}")

        paint()

        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(2, 6))
        self._chip(btns, "复制网址", lambda: self.copy_phone_url()).pack(side="left", padx=4)
        self._chip(btns, "另存为图片", lambda: save_png()).pack(side="left", padx=4)
        if not qr_tools.available():
            self._chip(btns, "装一下二维码库", lambda: install_lib()).pack(side="left", padx=4)

        tk.Label(win, text=url or "（读不到地址，重启一下程序）", bg=BG_PANEL,
                 fg="#9a9aa5", font=("Consolas", 9), wraplength=330,
                 justify="center").pack(padx=16, pady=(4, 2))
        tk.Label(win, text="换 Wi-Fi / 换电脑之后 IP 会变，到时候重新点一次这个按钮就行",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 wraplength=330, justify="center").pack(padx=16, pady=(0, 10))
        inputlog("点了「二维码」按钮")

    def _entry(self, parent, label, value, multiline: bool = False):
        """一行文字设置，做成一个按钮：点一下弹窗来改（不在小框里打字就不会丢焦点）。"""
        row = self._row(parent, label)
        var = self.tk.StringVar(value=str(value))

        def shown(text) -> str:
            one = " ".join(str(text or "").split())
            if not one:
                return "（点这里设置）"
            one = one.replace("|", " ／ ")      # 多条应答语的写法，显示得好看点
            return one if len(one) <= 26 else one[:25] + "…"

        btn = self.tk.Label(row, text=shown(var.get()), bg=CARD, fg="#ffffff",
                            font=("Microsoft YaHei UI", 9), padx=10, pady=4,
                            cursor="hand2", anchor="w", justify="left",
                            highlightthickness=1, highlightbackground=BORDER)
        btn.pack(side="left", fill="x", expand=True, padx=(0, 10))

        def open_editor(_event=None):
            inputlog(f"点击「{label}」按钮")
            self.edit_text(label, var.get(),
                           lambda t: (var.set(t), None)[1], multiline=multiline)

        btn.bind("<Button-1>", open_editor)
        btn.bind("<Enter>", lambda _e: btn.config(bg="#2c2c36"))
        btn.bind("<Leave>", lambda _e: btn.config(bg=CARD))

        def sync(*_args):
            btn.config(text=shown(var.get()))
            self.on_change()

        var.trace_add("write", sync)
        return var

    def edit_text(self, title: str, initial: str, on_ok=None, multiline: bool = False) -> None:
        """开一个普通窗口来编辑（带标题栏，能正常获得键盘焦点）。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title(f"编辑 · {title}")
        win.configure(bg=BG_PANEL)
        win.attributes("-topmost", True)
        win.geometry("440x190" if multiline else "440x150")
        win.resizable(False, False)
        tk.Label(win, text=title, bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        var = tk.StringVar(value=initial)
        if multiline:
            box = tk.Text(win, height=3, bg=CARD, fg="#ffffff", insertbackground="#ffffff",
                          relief="flat", wrap="word", font=("Microsoft YaHei UI", 10))
            box.insert("1.0", initial)
            box.pack(fill="both", expand=True, padx=14, pady=6)
        else:
            box = tk.Entry(win, textvariable=var, bg=CARD, fg="#ffffff",
                           insertbackground="#ffffff", relief="flat",
                           font=("Microsoft YaHei UI", 11))
            box.pack(fill="x", padx=14, pady=10, ipady=6)
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(2, 12))

        def confirm() -> None:
            text = (box.get("1.0", "end").strip() if multiline else var.get()).strip()
            if on_ok:
                on_ok(text)
            close()

        def close() -> None:
            # 关窗口时告诉主程序"改完了"，它可以接着抢键盘了
            self.set_editing(False)
            win.destroy()

        ok = tk.Label(bar, text="确定", bg=self.button_color, fg="#ffffff",
                      font=("Microsoft YaHei UI", 10, "bold"), padx=20, pady=6, cursor="hand2")
        ok.pack(side="right")
        ok.bind("<Button-1>", lambda _e: confirm())
        cancel = tk.Label(bar, text="取消", bg=CARD, fg="#ffffff",
                          font=("Microsoft YaHei UI", 10), padx=16, pady=6, cursor="hand2")
        cancel.pack(side="right", padx=8)
        cancel.bind("<Button-1>", lambda _e: close())
        win.bind("<Return>", lambda _e: confirm())
        win.bind("<Escape>", lambda _e: close())
        win.protocol("WM_DELETE_WINDOW", close)
        # 弹窗是独立窗口，焦点一定拿得到；这段时间让主程序先别往聊天框粘东西
        self.set_editing(True)
        self.edit_touch = time.time()
        try:
            win.lift()
            win.focus_force()
            box.focus_set()
        except Exception:
            pass

    def _switch_row(self, parent, label, value, on_change=None):
        row = self._row(parent, label)
        sw = Switch(row, bool(value), on_change or (lambda _v: self.on_change()), bg=BG_PANEL)
        sw.canvas.pack(side="right", padx=(0, 10))
        return sw

    def _swatch(self, parent, label, color):
        tk = self.tk
        cell = tk.Frame(parent, bg=BG_PANEL)
        cell.pack(side="left", padx=(0, 8))
        tk.Label(cell, text=label, bg=BG_PANEL, fg="#9a9aa5",
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(0, 2))
        canvas = tk.Canvas(cell, width=26, height=16, bg=BG_PANEL, highlightthickness=0,
                           cursor="hand2")
        canvas.pack(side="left")
        rect = canvas.create_rectangle(1, 1, 25, 15, fill=color, outline="#55555f")

        def choose(_event=None):
            from tkinter import colorchooser

            _rgb, picked = colorchooser.askcolor(color=canvas.itemcget(rect, "fill"))
            if picked:
                canvas.itemconfig(rect, fill=picked)
                self.on_change()

        canvas.bind("<Button-1>", choose)
        return canvas, rect

    def collect(self) -> dict:
        data = load_config()
        data.update({
            "name": self.entry_name.get().strip() or "语音助手",
            "wake_word": self.entry_wake.get().strip() or "大肥鱼",
            "greeting_text": self.entry_greeting.get().strip(),
            "greeting_enabled": self.sw_greeting.get(),
            "user_name": self.entry_user.get().strip(),
            "name_freq": self.name_freq_value,
            "ack_text": self.entry_ack.get().strip() or DEFAULTS["ack_text"],
            "ack_enabled": self.sw_ack.get(),
            "self_name": self.entry_self.get().strip() or "大肥鱼",
            "self_talk": self.sw_self.get(),
            "self_freq": self.self_freq_value,
            "volume": int(self.sl_volume.get()),
            "rate": f"{int(self.sl_rate.get()):+d}%",
            "voice": VOICES[self.voice_index][0],
            "voice_pitch": VOICES[self.voice_index][2],
            "voice_fx": VOICES[self.voice_index][3],
            "voice_preset": int(self.voice_index),
            "overlay_width": int(self.sl_width.get()),
            "overlay_height": int(self.sl_height.get()),
            "overlay_color": self.sw_color[0].itemcget(self.sw_color[1], "fill"),
            "overlay_accent": self.sw_accent[0].itemcget(self.sw_accent[1], "fill"),
            "overlay_button": self.sw_button[0].itemcget(self.sw_button[1], "fill"),
            "overlay_text": self.sw_text[0].itemcget(self.sw_text[1], "fill"),
            "overlay_talk_color": self.sw_talk[0].itemcget(self.sw_talk[1], "fill"),
            "overlay_bg_image": self.bg_path,
            "overlay_alpha": round(self.sl_alpha.get() / 100, 2),
            "overlay_bg_dim": int(self.sl_dim.get()),
            "overlay_wave_style": self.wave_style_value,
            "ov_name_x": int(self.sp_name.get()["x"]),
            "ov_name_y": int(self.sp_name.get()["y"]),
            "ov_name_size": int(self.sp_name.get()["s"]),
            "ov_status_x": int(self.sp_status.get()["x"]),
            "ov_status_y": int(self.sp_status.get()["y"]),
            "ov_status_size": int(self.sp_status.get()["s"]),
            "ov_switch_x": int(self.sp_switch.get()["x"]),
            "ov_switch_y": int(self.sp_switch.get()["y"]),
            "ov_wave_y": int(self.sp_wave.get()["y"]),
            "ov_wave_h": int(self.sp_wave.get()["h"]),
            "overlay_show_name": self.sw_show["name"].get(),
            "overlay_show_status": self.sw_show["status"].get(),
            "overlay_show_line": self.sw_show["line"].get(),
            "overlay_show_switch": self.sw_show["switch"].get(),
            "followup_seconds": int(self.sl_followup.get()),
            "caption_enabled": self.sw_caption.get(),
            "mood_enabled": self.sw_mood.get(),
            "mood_idle": self.sw_sleepy.get(),
            "wave_spectrum": self.sw_spectrum.get(),
            "karaoke": self.sw_karaoke.get(),
            "diary_enabled": self.sw_diary.get(),
            "big_caption": self.sw_big.get(),
            "screenshot_enabled": self.sw_shot.get(),
            "screen_share": self.sw_share.get(),
            "phone_enabled": self.sw_phone.get(),
            "hourly_chime": self.sw_chime.get(),
            "sit_reminder": self.sw_sit.get(),
            "meeting_mute": self.sw_meeting.get(),
            "read_hotkey": self.sw_hotkey.get(),
            "voiceprint_warn": self.sw_voiceprint.get(),
            "pet_enabled": self.sw_pet.get(),
            "follow_foreground": self.sw_follow.get(),
            "read_reply": self.sw_readreply.get(),
            "rec_indicator": self.sw_rec.get(),
            "weather_city": self.entry_city.get().strip(),
            "send_mode": self.send_mode_value,
            "confirm_send": self.sw_confirm.get(),
            "tray_enabled": self.sw_tray.get(),
            "auto_tune": self.sw_autotune.get(),
            "auto_restart": self.sw_restart.get(),
            "not_heard_reply": self.sw_notheard.get(),
            "voiceprint_gate": self.sw_gate.get(),
            "model": self.model_value,
            "lang": self.lang_value,
            "wake_level": str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL),
            "wake_levels": self.custom_levels(),
            "reminders_enabled": self.sw_reminder.get(),
            "reminder_paste": self.sw_reminder_paste.get(),
            "shortcuts": self.shortcuts,
            "schedules": self.schedule_panel.entries,
            "schedule_modules": self.schedule_panel.modules,
            "perf_mode": self.perf_value,
            "anim_fps": int(self.sl_anim.get()),
            "wheel_alpha": self.sw_wheel.get(),
            "snap_edges": self.sw_snap.get(),
            **self._fx_to_save(),
        })
        return data

    def _fx_to_save(self) -> dict:
        """要存进 config.json 的特效开关。

        机器一时忙（开模型、跑大文件、几十个进程抢 CPU）的时候，悬浮窗会自动把特效
        关掉保住帧率 —— 那是"这一次运行"的临时措施。以前它会被"保存设置"顺手写进
        配置文件，结果一次卡顿就把你选的特效永久关掉了。现在这种自动降级不落盘。
        """
        fx = {key: bool(sw.get())
              for key, sw in getattr(self, "fx_switches", {}).items()}
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None)
            if before:
                fx.update(before)
        return fx

    def on_change(self, *_a) -> None:
        if self._push_job is not None:
            try:
                self.root.after_cancel(self._push_job)
            except Exception:
                pass
        self._push_job = self.root.after(120, self.push_now)
        if self.hint_label is not None:
            self.hint_label.config(text="改动即时预览", fg="#7f7f8a")

    def push_now(self) -> None:
        self._push_job = None
        data = self.collect()
        write_config(data)
        self.cfg = data
        try:
            self.cfg_mtime = CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        self.after_wake_word_change(data)

    def after_wake_word_change(self, data: dict) -> None:
        """唤醒词一改就自动跑一次自检 —— 免得换了个词却没人告诉你好不好用。"""
        now_word = str(data.get("wake_word") or "")
        if now_word == getattr(self, "_wake_seen", None):
            return
        first_time = not getattr(self, "_wake_seen", None)
        self._wake_seen = now_word
        if first_time or not now_word.strip():
            return
        if time.time() - self.started < 20:      # 刚启动别抢开机问候的话筒
            return
        self.run_wake_test()

    def save_settings(self) -> None:
        self.push_now()
        self.flash("已保存", 2)
        if self.hint_label is not None:
            self.hint_label.config(text="已保存", fg=self.accent)

    def reset_defaults(self) -> None:
        data = load_config()
        for key, value in DEFAULTS.items():
            # 字典/列表要复制一份，不然改配置会顺手把 DEFAULTS 里那份也改了
            if isinstance(value, dict):
                data[key] = dict(value)
            elif isinstance(value, list):
                data[key] = list(value)
            else:
                data[key] = value
        data.pop("overlay_line_follow_state", None)
        write_config(data)
        self.cfg = data
        try:
            self.cfg_mtime = CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None
            self.build_panel()
            self._place_panel(self._expanded_h())
        self.flash("已恢复默认设置", 2.4)

    def set_autostart(self, value: bool) -> None:
        script = HERE / "autostart.ps1"
        if script.exists():
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-File", str(script), "-AppDir", str(HERE),
                              "-Action", "on" if value else "off"],
                             creationflags=0x08000000)
        self.flash("开机自启：" + ("开" if value else "关"))

    def set_wave_style(self, value: str) -> None:
        self.wave_style_value = value
        self.wave_style = value
        self.refresh_style_chips()
        self.on_change()

    def set_perf(self, value: str) -> None:
        self.perf_value = value
        self.perf = value
        self.refresh_perf_chips()
        if value == "eco":
            self.sl_anim.set(20)
        elif value == "quality":
            self.sl_anim.set(60)
        self.on_change()

    def refresh_perf_chips(self) -> None:
        for value, chip in getattr(self, "perf_chips", {}).items():
            chip.config(bg=self.button_color if value == self.perf_value else CARD,
                        fg="#ffffff")

    def set_name_freq(self, value: str) -> None:
        self.name_freq_value = value
        self.refresh_name_freq()
        self.on_change()

    def refresh_name_freq(self) -> None:
        for value, chip in getattr(self, "name_freq_chips", {}).items():
            chip.config(bg=self.button_color if value == self.name_freq_value else CARD,
                        fg="#ffffff")

    def set_self_freq(self, value: str) -> None:
        self.self_freq_value = value
        self.refresh_self_freq()
        self.on_change()

    def refresh_self_freq(self) -> None:
        for value, chip in getattr(self, "self_freq_chips", {}).items():
            chip.config(bg=self.button_color if value == self.self_freq_value else CARD,
                        fg="#ffffff")

    def refresh_style_chips(self) -> None:
        for value, chip in getattr(self, "style_chips", {}).items():
            chip.config(bg=self.button_color if value == self.wave_style_value else CARD,
                        fg="#ffffff")

    def pick_bg(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="选一张背景图",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp"), ("全部", "*.*")])
        if path:
            self.set_bg(path)

    def set_bg(self, path: str) -> None:
        self.bg_path = path
        self.bg_label.config(text=Path(path).name if path else "无")
        self.on_change()

    def _rate_value(self, rate) -> float:
        try:
            return float(str(rate or "+8%").replace("%", "").replace("+", ""))
        except Exception:
            return 8.0

    def _voice_index(self) -> int:
        # 优先按"第几套预设"记（同一个 edge 音色会有好几套：普通/变声/特效）
        try:
            idx = int(self.cfg.get("voice_preset") or -1)
            if 0 <= idx < len(VOICES):
                return idx
        except Exception:
            pass
        current = self.cfg.get("voice") or VOICES[0][0]
        for i, entry in enumerate(VOICES):
            value = entry[0]
            if value == current:
                return i
        return 0

    def _voice_text(self) -> str:
        return VOICES[self.voice_index][1]

    def apply_size(self, *_a) -> None:
        """改悬浮窗本身的宽/高：立刻量一次，重摆面板（不用重启）。"""
        try:
            self.W = int(self.sl_width.get())
            self.H = int(self.sl_height.get())
        except Exception:
            return
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self._base = None            # 头部底图要按新宽度重画
        self._base_key = None
        if self.expanded:
            self.target_w = float(self.expand_w)
            self.target_h = self._expanded_h()
            self._place_panel(self.target_h)
        else:
            self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        try:
            self.root.geometry(f"{int(self.target_w)}x{int(self.target_h)}+"
                               f"{int(self.base_x)}+{int(self.base_y)}")
        except Exception:
            pass
        self.on_change()

    def cycle_voice(self, step: int) -> None:
        self.voice_index = (self.voice_index + step) % len(VOICES)
        self.voice_label.config(text=self._voice_text())
        self.on_change()

    def preview_voice(self, idx: int | None = None) -> None:
        """试听。抽屉里那一列「听」会指定第几个，顺便就把它选上了。"""
        if idx is not None:
            self.select_voice(int(idx))
        voice, label, pitch, fx = VOICES[self.voice_index]
        label = label.split(" · ")[0]
        volume, rate = int(self.sl_volume.get()), int(self.sl_rate.get())

        def run() -> None:
            try:
                import say

                if say.is_clone(voice):        # 克隆音色：走本机的换嗓子那条路
                    got = say.clone_audio(f"你好，我是{label}。以后就用这个声音跟你说话。",
                                          voice, f"{rate:+d}%")
                    if got is None:
                        self.root.after(0, lambda: self.flash("克隆音色这会儿用不了，看日志"))
                        return
                    audio, sr = got
                    if volume < 100:
                        audio = audio * max(0.0, min(1.0, volume / 100))
                    say.play(audio, sr)
                    return
                say.PITCH[0] = pitch
                mp3 = say.edge_mp3(f"你好，我是{label}。以后就用这个声音跟你说话。",
                                   voice, f"{rate:+d}%")
                audio, sr = say.decode_audio(mp3)
                audio = say.apply_fx(audio, sr, fx)
                if volume < 100:
                    audio = audio * max(0.0, min(1.0, volume / 100))
                say.play(audio, sr)
            except Exception as exc:  # noqa: BLE001
                # 注意：except 里的 exc 出了这个块就被删了，得先取出来再用
                why = str(exc)[:24]
                self.root.after(0, lambda w=why: self.flash(f"试听失败：{w}"))

        threading.Thread(target=run, daemon=True).start()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    if not single_instance():
        return 0
    try:
        Overlay().run()
        note("mainloop 正常结束（窗口被销毁）")
    except Exception:
        import traceback

        try:
            (HERE / "overlay-error.log").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
