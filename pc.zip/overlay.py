#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手悬浮窗（精简版 + 就地设置）。

平时只有四样东西：名字、状态、开关、以及贴着底部的一条声音波浪。
  · 有声音 → 波浪铺满底部，上下抖动（不是左右伸缩）
  · 没声音 → 缩到中间，变成一个上下浮动的小圆球
右下角是个小箭头：点一下浮窗平滑长大，就地展开设置（基本/声音/外观/布局）。
设置里改什么都立刻预览，满意了再保存；也有「恢复默认」。
"""

from __future__ import annotations

import atexit
import json
import math
import os
import re
import time
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageTk

from ui_widgets import Slider, SpinRow, Switch
import wake_levels
import version
import memory_archive

HERE = Path(__file__).resolve().parent
STATUS = HERE / "status.json"
SPEAK_STATUS = HERE / "speak.json"
CONTROL = HERE / "control.json"
POS = HERE / "overlay_pos.json"
CONFIG = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"
READY_FILE = HERE / "overlay_ready.json"   # "窗口已经显示出来了"的回执，给主程序看
SYSLOG_FILE = HERE / "syslog.md"
EXIT_LOG = HERE / "overlay-exit.log"
INPUT_LOG = HERE / "input.log"

FRAME_MS = 16                 # 约 60fps
FADE_SECONDS = 0.24           # 声音条换色（说话/静默、改配色）的过渡时长
RESIZE_STEPS = 8              # 展开/收起走多少步（按步数走，机器慢也不会变成大跳）
RESIZE_STEP_MS = 8            # 展开/收起期间两帧之间至少要隔这么久，不然窗口尺寸会被合并
SIMPLE_STEPS = 6              # 缩成侧边条 / 从侧边条放大回来：距离短，走更少的步，更快
SNAP_PX = 26                  # 拖到离屏幕边缘多近就吸上去
SIMPLE_LONG = 132             # 贴边后那条"简化版"有多长
SIMPLE_THICK = 20             # 以及多粗
STATUS_MS = 200
PANEL_H = 452                 # 五个标签页，留够高度
PANEL_H_OPEN = 560            # 展开设置后的固定高度（不再跟着标签页内容变，装不下就用滚轮看）

from overlay_feature.defaults import (
    ARROW, BG_PANEL, BORDER, CARD, COLORS, DEFAULTS, FX_DOT_KEYS, FX_KEYS,
    KNOB, LABELS, SW_H, SW_W, VOICES,
)


def _clone_entries() -> list[tuple[str, str, str, str]]:
    """本机装了语音克隆环境的话，把那些"真音色"也挂进音色列表。

    没装的机器上一律是空的（clone_voice.py 也不会跟着安装包发出去），
    所以别人的界面上根本不会出现这一栏。
    """
    try:
        import clone_voice

        return [(value, name, "", "") for value, name in clone_voice.models()]
    except Exception:
        return []


# 原来的 RVC 克隆音色（曼波/高松灯…）也不再挂出来 —— 只留上面这一种。
# _clone_entries() 留着但不调用，以后想恢复只要把下一行的注释去掉。
# VOICES.extend(_clone_entries())
from overlay_feature.runtime import (
    CONFIG,
    CONTROL,
    EXIT_LOG,
    FONT_FILES,
    INPUT_LOG,
    POS,
    READY_FILE,
    SPEAK_STATUS,
    STARTUP_LNK,
    STATUS,
    SYSLOG_FILE,
    WAKE_TEST_FILE,
    _pid_alive,
    font,
    hexs,
    inputlog,
    mix,
    process_alive,
    rgb,
    set_no_activate,
    shade,
    startup_exists,
    virtual_screen,
)
from overlay_feature import runtime as _runtime
from overlay_feature import window_control as _window_control
from overlay_feature import window_geometry as _geometry
from overlay_feature.dialogs import OverlayDialogMixin
from overlay_feature.presets_mixin import OverlayPresetsMixin
from overlay_feature.schedule_mixin import OverlayScheduleMixin
from overlay_feature.settings_mixin import OverlaySettingsMixin
from overlay_feature.settings_onboarding_mixin import (
    OverlaySettingsOnboardingMixin,
)
from overlay_feature.settings_basic_mixin import OverlaySettingsBasicMixin
from overlay_feature.settings_wake_mixin import OverlaySettingsWakeMixin
from overlay_feature.settings_caption_mixin import OverlaySettingsCaptionMixin
from overlay_feature.settings_content_mixin import OverlaySettingsContentMixin
from overlay_feature.settings_visuals_mixin import OverlaySettingsVisualsMixin
from overlay_feature.settings_delivery_mixin import OverlaySettingsDeliveryMixin
from overlay_feature.settings_actions_mixin import OverlaySettingsActionsMixin
from overlay_feature.settings_pages_mixin import OverlaySettingsPagesMixin
from overlay_feature.settings_maintenance_mixin import (
    OverlaySettingsMaintenanceMixin,
)
from overlay_feature.settings_backup_mixin import OverlaySettingsBackupMixin
from overlay_feature.settings_memory_mixin import OverlaySettingsMemoryMixin
from overlay_feature.settings_features_mixin import OverlaySettingsFeaturesMixin
from overlay_feature.settings_reminders_mixin import OverlaySettingsRemindersMixin
from overlay_feature.settings_appearance_mixin import OverlaySettingsAppearanceMixin
from overlay_feature.settings_update_mixin import OverlaySettingsUpdateMixin
from overlay_feature.settings_remote_actions_mixin import (
    OverlaySettingsRemoteActionsMixin,
)
from overlay_feature.settings_devices_mixin import OverlaySettingsDevicesMixin
from overlay_feature.settings_uninstall_mixin import (
    OverlaySettingsUninstallMixin,
)
from overlay_feature.settings_product_actions_mixin import (
    OverlaySettingsProductActionsMixin,
)
from overlay_feature.visuals import OverlayVisualMixin
from overlay_feature import panel_controls as _panel_controls
from overlay_feature.settings_runtime import (
    MAX_ALPHA,
    MIN_ALPHA,
    OverlayConfigWatcher,
    build_overlay_settings,
    config_value,
)


def load_config() -> dict:
    return _runtime.load_config(CONFIG)


def write_config(data: dict) -> None:
    _runtime.write_config(data, CONFIG)


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


def note(text: str) -> None:
    _runtime.note(text, EXIT_LOG)


def inputlog(text: str) -> None:
    _runtime.inputlog(text, INPUT_LOG)


def single_instance() -> bool:
    return _runtime.single_instance(READY_FILE)

class Overlay(OverlayVisualMixin, OverlayDialogMixin, OverlayScheduleMixin,
              OverlaySettingsUninstallMixin,
              OverlaySettingsProductActionsMixin,
              OverlaySettingsDevicesMixin,
              OverlaySettingsRemoteActionsMixin,
              OverlayPresetsMixin, OverlaySettingsContentMixin,
              OverlaySettingsVisualsMixin,
              OverlaySettingsDeliveryMixin,
              OverlaySettingsFeaturesMixin, OverlaySettingsRemindersMixin,
              OverlaySettingsPagesMixin,
              OverlaySettingsBackupMixin, OverlaySettingsMemoryMixin,
              OverlaySettingsMaintenanceMixin,
              OverlaySettingsUpdateMixin,
              OverlaySettingsActionsMixin,
              OverlaySettingsAppearanceMixin,
              OverlaySettingsWakeMixin,
              OverlaySettingsCaptionMixin,
              OverlaySettingsBasicMixin,
              OverlaySettingsOnboardingMixin,
              OverlaySettingsMixin):
    def __init__(self) -> None:
        import tkinter as tk

        self.tk = tk
        self._config_watcher = OverlayConfigWatcher(
            path_provider=lambda: CONFIG,
            loader=load_config,
            clock=time.time,
        )
        self.cfg = self._config_watcher.load_initial()
        self.started = time.time()
        self.status: dict = {}
        self.miss = self.dead_hits = 0
        self._next_status = 0.0
        self.level = self.level_shown = 0.0
        self.breath = 0.0
        self.wave_phase = 0.0
        self.bar_heights: list[float] = []
        self.switch_pos = self.switch_target = 1.0
        self.state = "starting"
        self.text_fade = 1.0
        self.toast = ""
        self.toast_until = 0.0
        self.intro = 0.0
        self._drag = None
        self._sprites: dict = {}
        self._base = None
        self._base_key = None
        self._photo = None
        self.expanded = False
        self.alpha_override = None
        self.panel_h_shown = 0
        self.panel_h_natural = 0
        self.resize_from = None
        self._resize_key = None
        self.panel = None
        self.panel_win = None
        self._panel_fade_token = 0
        self._panel_geom = ""
        self.hint_label = None
        self._push_job = None
        # 声音条特效的运行时状态
        self.dt = 0.016
        self._sparks: list[dict] = []
        self._trail_img = None
        self._trail_key = None
        self._sweep_pos = 0.0
        self._sweep_base = None
        self.last_active = time.time()   # 养成：多久没人理它
        self.sleep_stage = 0             # 0 正常 / 1 打哈欠 / 2 睡着了
        self._pop = 0.0                  # 被叫醒时"弹一下"的强度
        self._frames = 0                 # 画了多少帧（配合帧时间判断要不要降级）
        self._frame_cost = 0.0           # 每帧平均画了多久
        self._auto_low = False           # 已经因为机器慢自动降过级了吗
        self._fx_before_low: dict | None = None   # 降级前你自己选的那套特效开关
        self._auto_low_off = False       # 你亲手把特效开回来了，这一轮就别再自动关
        self._degrade_stage = 0          # 0 没降 / 1 关了特效 / 2 连帧率也降了
        self._period = 0.0               # 帧间隔（上一帧开始到这一帧开始）
        self._gaps: list[float] = []     # 最近 60 帧的间隔，取中位数用
        self._slow_checks = 0            # 连着几次判定为"跟不上"
        self._started = time.time()      # 启动时刻：开机那段 CPU 尖峰不算数
        self.snap_edge = ""              # "" / left / right / top / bottom：吸在哪条边上
        self.hovered = False             # 鼠标是不是在窗口上（贴边时用它决定放大还是缩成小条）
        self.snap_on = True              # 贴边吸附总开关（设置里能关）
        self._panel_closing = False
        self.current_tab = "基本"
        self.wake_test_result = ""      # 最近一次唤醒词自检的结论
        self.focus_left = 0.0           # 番茄钟剩余秒数（0 = 没在专注）
        self.focus_total = 0.0          # 这一轮专注一共多久
        self.caption_win = None         # 大字幕窗口
        self.caption_label = None
        self.caption_last = ""
        self.caption_at = 0.0
        self.rec_win = None             # 录音提示灯
        self.editing_on = False          # 正在改设置？（这期间让主程序别抢键盘）
        self.wake_test_at = 0.0
        try:                            # 上次运行留下的自检结果不当成新的
            self._wake_test_ts = float(
                json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            self._wake_test_ts = 0.0
        self._wake_seen = str(self.cfg.get("wake_word") or "")   # 用来判断唤醒词有没有被改
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.cur_w = float(self.compact_w)
        self.cur_h = float(self.header_h)
        self.target_w, self.target_h = self.cur_w, self.cur_h

        x, y = self.load_pos()
        self.base_x, self.base_y = x, y
        # Windows 的定时器默认只有 ~15.6ms 的精度：after(16) 经常被拖到 23ms 才醒，
        # 60 帧根本跑不起来。目标帧率够高（>=50 帧）时才把精度提到 1ms，
        # 退出时还回去；节能/30 帧模式就不折腾了，省电。
        if self.frame_ms <= 20 and _window_control.enable_precise_timer(1):
            atexit.register(_window_control.disable_precise_timer, 1)
        self.root = tk.Tk()
        self.root.title(self.name)
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.panel_color)
        self.root.geometry(f"{self.compact_w}x{self.header_h}+{x}+{y - 16}")
        self.root.attributes("-alpha", 0.0)
        self.root.update_idletasks()
        try:
            _window_control.make_window_tree_no_activate(self.root.winfo_id())
        except Exception:
            pass

        self.canvas = tk.Canvas(self.root, width=self.compact_w, height=self.header_h,
                                bg=self.panel_color, highlightthickness=0)
        self.canvas.pack(side="top", fill="x")      # 宽度跟着窗口走，不用每帧单独设
        self._photo = ImageTk.PhotoImage(
            Image.new("RGB", (self.compact_w, self.header_h), self.panel_color))
        self.img_item = self.canvas.create_image(0, 0, anchor="nw", image=self._photo)
        self.canvas.bind("<Button-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.open_menu)
        for widget in (self.canvas, self.root):
            widget.bind("<MouseWheel>", self.on_wheel)

        self.menu = tk.Menu(self.root, tearoff=0, bg="#26262d", fg="#ffffff",
                            activebackground=self.button_color, activeforeground="#ffffff",
                            font=("Microsoft YaHei UI", 9))
        self.menu.add_command(label="只关浮窗（程序继续跑）", command=self.quit)
        self.menu.add_command(label="🔇 静音 / 🔊 恢复出声（切换）",
                              command=lambda: send_command("toggle-mute"))
        self.menu.add_command(label="退出语音程序", command=self.quit_program)

        self.root.report_callback_exception = self.on_tk_error
        note(f"启动 pid={os.getpid()} 位置=({x},{y})")
        self.root.after(120, self.tick)
        self.root.after(self.frame_ms, self.anim)
        self.root.after(1500, self.maybe_first_run)
        self.root.after(4000, self.warm_panel)     # 闲着的时候先把设置面板备好

    @property
    def cfg_mtime(self) -> float:
        return self._config_watcher.mtime

    @cfg_mtime.setter
    def cfg_mtime(self, value: float) -> None:
        self._config_watcher.set_mtime(value)

    def _overlay_send_command(self, action: str) -> None:
        send_command(action)

    def _overlay_load_config(self) -> dict:
        return load_config()

    def _overlay_write_config(self, data: dict) -> None:
        write_config(data)

    def _overlay_inputlog(self, text: str) -> None:
        inputlog(text)

    def warm_panel(self) -> None:
        """开了一会儿之后，偷偷把设置面板建好、摆到窗口外面去（窗口小，看不见）。

        为了让你第一次点箭头就是顺的：建面板要 map 七百个控件，就地卡 0.6~1.1 秒，
        以前这 0.6 秒正好卡在展开动画中间，动画就"没了"。
        """
        if self.panel is not None:
            return
        try:
            self.build_panel()
            self._place_panel(self._expanded_h())
            # 先在屏幕外/全透明状态下 map 一次，把控件树建好；真正展开时
            # 只是 deiconify + 淡入，不再现场 map 七百个控件。
            if self.panel_win is not None and not self.expanded:
                try:
                    self.panel_win.attributes("-alpha", 0.0)
                    self.panel_win.deiconify()
                    self.panel_win.update_idletasks()
                    self.panel_win.withdraw()
                except Exception:
                    pass
        except Exception as exc:  # noqa: BLE001
            note(f"预热设置面板失败：{type(exc).__name__}")

    def on_tk_error(self, exc_type, exc_value, exc_tb) -> None:
        import traceback

        note("回调异常: " + "".join(traceback.format_exception_only(exc_type, exc_value)).strip())
        try:
            # 写在"当前配置所在的那个目录"：正常就是程序目录；脚本测试时会把 CONFIG
            # 指到临时目录，报错就落在那儿，不会把真程序这条日志冲掉。
            (CONFIG.parent / "overlay-error.log").write_text(
                "".join(traceback.format_exception(exc_type, exc_value, exc_tb)), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------ 配置
    def cfg_get(self, key: str):
        return config_value(self.cfg, key)

    def apply_config(self) -> None:
        build_overlay_settings(self.cfg).apply_to(self)

    def reload_config_if_changed(self) -> None:
        updated = self._config_watcher.poll()
        if updated is None:
            return
        self.cfg = updated
        self.apply_saved()

    def apply_saved(self) -> None:
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        # 主浮窗永远保持紧凑尺寸；设置面板是独立窗口
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        self._base_key = None
        self.root.title(self.name)
        self.root.configure(bg=self.panel_color)
        self.canvas.configure(bg=self.panel_color)
        self.menu.configure(activebackground=self.button_color)

    # ------------------------------------------------------------ 位置
    def load_pos(self) -> tuple[int, int]:
        try:
            data = json.loads(POS.read_text(encoding="utf-8"))
            self.snap_edge = str(data.get("snap") or "")
            return int(data["x"]), int(data["y"])
        except Exception:
            pass
        return _geometry.default_position(
            virtual_screen(), self.W, right_gap=40, top=60
        )

    # ------------------------------------------------------------ 交互
    def on_press(self, event) -> None:
        if self.hit_arrow(event.x, event.y):
            self.set_expanded(not self.expanded)
            return
        if self.hit_switch(event.x, event.y):
            self.toggle_switch()
            return
        self._drag = (event.x_root - self.root.winfo_x(), event.y_root - self.root.winfo_y())

    def on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.base_x, self.base_y = event.x_root - dx, event.y_root - dy
        self.root.geometry(f"+{self.base_x}+{self.base_y}")

    def on_release(self, _event) -> None:
        self._drag = None
        self.try_snap()
        self.save_pos()

    def save_pos(self) -> None:
        try:
            POS.write_text(json.dumps({
                "x": self.root.winfo_x(), "y": self.root.winfo_y(),
                "snap": self.snap_edge,
            }), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------- 贴边吸附 / 简化版
    def simple_size(self) -> tuple:
        """贴边之后那条"简化版"的尺寸：竖边竖条、横边横条。"""
        if self.snap_edge in ("left", "right"):
            return SIMPLE_THICK, SIMPLE_LONG
        if self.snap_edge in ("top", "bottom"):
            return SIMPLE_LONG, SIMPLE_THICK
        return self.compact_w, self.header_h

    def simple_on(self) -> bool:
        """什么时候缩成小条：吸在边上 + 鼠标不在上面 + 没展开设置。"""
        return bool(self.snap_edge) and self.snap_on and not self.hovered \
            and not self.expanded and not self._drag

    def nearest_edge(self, x: int, y: int, w: int, h: int) -> str:
        return _geometry.nearest_edge(
            x, y, w, h, virtual_screen(), SNAP_PX
        )

    def try_snap(self) -> None:
        """松手之后看要不要吸到边上。"""
        if not self.snap_on or self.expanded:
            self.snap_edge = ""
            self.reset_target()
            return
        x, y = self.root.winfo_x(), self.root.winfo_y()
        self.snap_edge = self.nearest_edge(x, y, int(self.cur_w), int(self.cur_h))
        if self.snap_edge:
            self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            note(f"吸到{ {'left': '左边', 'right': '右边', 'top': '上边', 'bottom': '下边'}[self.snap_edge] }")
        else:
            self.reset_target()

    def reset_target(self) -> None:
        """不贴边了：把目标尺寸恢复成"平时的浮窗"（或者展开的面板）。

        不恢复的话，从边上拖走之后它还会一直按"小细条"的尺寸缩着。
        """
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._position_panel_window()

    def dock_pos(self, w: float, h: float) -> tuple:
        """吸在边上时，窗口该待在哪儿（跟着尺寸走，缩成小条也不会飘走）。"""
        return _geometry.dock_position(
            self.snap_edge,
            int(self.base_x),
            int(self.base_y),
            int(w),
            int(h),
            virtual_screen(),
        )

    def clamp_on_screen(self, x: int, y: int, w: int, h: int) -> tuple:
        """展开设置面板之后别跑到屏幕外面去。"""
        return _geometry.clamp_position(
            x, y, w, h, virtual_screen()
        )

    def watch_hover(self) -> None:
        """用指针位置判断鼠标在不在窗口上 —— 比 Enter/Leave 稳（子控件不会误报离开）。"""
        try:
            px, py = self.root.winfo_pointerxy()
        except Exception:
            return
        wx, wy = self.root.winfo_x(), self.root.winfo_y()
        self.hovered = (wx - 2 <= px <= wx + self.cur_w + 2
                        and wy - 2 <= py <= wy + self.cur_h + 2)

    def switch_rect(self) -> tuple[int, int]:
        """返回开关左上角。X 为负表示"离右边多远"，所以要减掉开关自身宽度。"""
        x, y = self.layout["switch"]
        x0 = _geometry.switch_rect(int(self.cur_w), x, SW_W)[0]
        return x0, y

    def hit_switch(self, x: int, y: int) -> bool:
        if not self.show_switch:
            return False
        x0, y0 = self.switch_rect()
        return x0 <= x <= x0 + SW_W and y0 <= y <= y0 + SW_H

    def hit_arrow(self, x: int, y: int) -> bool:
        return _geometry.point_in_rect(
            x, y,
            _geometry.arrow_rect(
                int(self.cur_w), self.header_h, ARROW
            ),
        )

    def on_wheel(self, event) -> None:
        if not bool(self.cfg.get("wheel_alpha", True)):
            return
        delta = 0.02 if getattr(event, "delta", 0) > 0 else -0.02
        self.alpha = min(MAX_ALPHA, max(MIN_ALPHA, self.alpha + delta))
        data = load_config()
        data["overlay_alpha"] = round(self.alpha, 2)
        write_config(data)
        self.flash(f"透明度 {int(self.alpha * 100)}%")

    def toggle_switch(self) -> None:
        paused = self.status.get("state") == "paused"
        send_command("resume" if paused else "pause")
        self.flash("正在恢复…" if paused else "正在暂停…")

    def open_menu(self, event) -> None:
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def quit_program(self) -> None:
        send_command("quit")
        self.flash("已让语音程序退出")
        self.root.after(700, self.quit)

    def quit(self, reason: str = "用户关掉了浮窗") -> None:
        note(f"退出：{reason}")
        try:
            self.root.destroy()
        except Exception:
            pass

    def flash(self, text: str, seconds: float = 1.6) -> None:
        self.toast = text
        self.toast_until = time.time() + seconds

    # ------------------------------------------------------------ 贴图
    # ------------------------------------------------------------ 状态
    def read_status(self) -> dict:
        try:
            return json.loads(STATUS.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def handle_remote(self) -> None:
        try:
            data = json.loads(CONTROL.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_ctrl_ts", 0.0):
            return
        self._ctrl_ts = ts
        action = str(data.get("action") or "")
        if action == "expand":
            self.set_expanded(True)
        elif action == "collapse":
            self.set_expanded(False)
        elif action == "qr":
            # 别的窗口 / 托盘 / 手机入口也能叫它把连接二维码弹出来
            self.show_qr()
        elif action == "perf":
            # 把当前的真实帧率情况写出来（用来量"到底卡不卡"，不用瞎猜）
            gaps = list(self._gaps)
            gaps.sort()
            med = gaps[len(gaps) // 2] * 1000 if gaps else 0.0
            p90 = gaps[int(len(gaps) * 0.9)] * 1000 if gaps else 0.0
            try:
                (HERE / "perf.json").write_text(json.dumps({
                    "目标帧率": self.fps, "帧预算ms": round(self.frame_ms, 1),
                    "中位间隔ms": round(med, 1),
                    "p90间隔ms": round(p90, 1),
                    "最差间隔ms": round(gaps[-1] * 1000, 1) if gaps else 0.0,
                    "实际帧率": round(1000 / med, 1) if med else 0.0,
                    "画一帧ms": round(self._frame_cost * 1000, 1),
                    "已降级": self._degrade_stage,
                    "特效": {k: v for k, v in self.fx.items() if k.startswith("fx_")},
                    "窗口": f"{int(self.cur_w)}x{int(self.cur_h)}",
                    "ts": time.time(),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    def tick(self) -> None:
        self.reload_config_if_changed()
        self.handle_remote()
        self.poll_wake_test()
        self.check_new_devices()          # 有新设备想连进来就弹窗问一声（公网那道门）
        self.sync_big_caption()
        self.sync_rec_dot()
        # 编辑状态别一直挂着：90 秒没敲字就自动让位（免得它永远不粘了）
        if self.editing_on and time.time() - getattr(self, "edit_touch", 0) > 90:
            self.set_editing(False)
        data = self.read_status()
        if data:
            self.miss = 0
            self.status = data
        else:
            self.miss += 1
            if self.miss == 40:
                note(f"连续 {self.miss} 次读不到 status.json")
        state = (self.status or {}).get("state") or "offline"
        # 「听到声音」只在真出声时算：麦克风底噪也能把 state 写成 hearing，
        # 那样浮窗会一直显示"听到声音了"（用户反馈）。这里按电平再看一道。
        if state == "hearing" and float((self.status or {}).get("level") or 0.0) < 0.05:
            state = "listening"
        self.state = state
        self.level = float((self.status or {}).get("level") or 0.0)
        self.focus_left = float((self.status or {}).get("focus") or 0.0)
        if self.focus_left <= 0:
            self.focus_total = 0.0
        elif self.focus_total <= 0 or self.focus_left > self.focus_total + 0.5:
            self.focus_total = self.focus_left      # 新的一轮专注
        self.switch_target = 0.0 if state == "paused" else 1.0
        if self.status:
            pid = int(self.status.get("pid") or 0)
            if time.time() - self.started > 8 and not process_alive(pid):
                self.dead_hits += 1
                if self.dead_hits >= 4:
                    note(f"退出：主程序不在了（pid={pid}）")
                    self.quit()
                    return
            else:
                self.dead_hits = 0
        elif self.miss >= 80:
            note("退出：连续读不到状态文件")
            self.quit()
            return
        self.root.after(STATUS_MS, self.tick)

    # ------------------------------------------------------------ 画面
    def anim(self) -> None:
        frame_t0 = time.perf_counter()
        now_t = time.time()
        self.dt = min(0.1, max(0.0, now_t - getattr(self, "_frame_t", now_t)))
        self._frame_t = now_t
        self._sweep_pos = (self._sweep_pos + self.dt * 0.55) % 1.0

        if self.intro < 1.0:
            self.intro = min(1.0, self.intro + 0.09)
            ease = 1 - (1 - self.intro) ** 3
            self.root.geometry(f"+{self.base_x}+{int(self.base_y - 16 * (1 - ease))}")
            self.root.attributes("-alpha", self.alpha * ease)

        # 贴边吸附：吸在边上、鼠标又不在上面的时候，缩成一条小细条；
        # 鼠标移上去自己放大回来。只有"吸在边上"才会这样，随便放桌面中间不受影响。
        if self._frames % 4 == 0:
            self.watch_hover()
        if self.snap_on and self.snap_edge:
            if self.simple_on():
                w_s, h_s = self.simple_size()
                self.target_w, self.target_h = float(w_s), float(h_s)
            elif not self.expanded:
                self.target_w = float(self.compact_w)
                self.target_h = float(self.header_h)
            # 展开设置时的高度交给 set_expanded() 管，别每帧算一遍面板高度
            # 正在拖的时候**千万别**抢位置：不然每帧都被拉回边缘，等于拖不动
            if self._drag is None:
                self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)

        # 展开/收起：固定"步数"的缓动。
        # 为什么不用时间驱动？改窗口尺寸这一下是要 Windows 重新合成这个半透明窗口的，
        # 一帧要 20~30ms，用 0.24 秒去卡只能挤出 6 个台阶，头一步就跳掉三分之一，
        # 肉眼就是"卡"。改成固定 14 步：机器快就 230ms 走完，机器慢就慢一点，
        # 但每一步都是均匀的，看着才顺。
        if abs(self.target_w - self.cur_w) > 0.6 or abs(self.target_h - self.cur_h) > 0.6:
            key = (round(self.target_w, 1), round(self.target_h, 1))
            if self.resize_from is None or self._resize_key != key:
                # 目标一变就重新从"当前尺寸"开始走：否则会拿着上一次的进度，
                # 一帧就跳到位（收起时看起来就像没有动画）
                self._resize_key = key
                self._rz_step = 0
                self.resize_from = (self.cur_w, self.cur_h)
            w0, h0 = self.resize_from
            self._rz_step = getattr(self, "_rz_step", 0) + 1
            # 贴边小条那一下距离短，少走几步就到位（更快）；展开/收起面板走 8 步
            steps = SIMPLE_STEPS if (self.snap_edge and not self.expanded) else RESIZE_STEPS
            t = min(1.0, self._rz_step / float(steps))
            e = t * t * (3 - 2 * t)          # smoothstep：两头慢、中间快
            self.cur_w = w0 + (self.target_w - w0) * e
            self.cur_h = h0 + (self.target_h - h0) * e
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            self._base_key = None
            # 面板跟着窗口一起长（而不是一开始就摆到最终高度）：
            # 面板每帧都"变了尺寸"，Tk 就会把它整块重画；不然新露出来的那条
            # 是没画过的像素 —— 分层窗口里看着就是一条黑带。
            if self.expanded:
                self._place_panel(self.cur_h)
            # 展开/收起时窗口一变大，新露出来的那块必须**马上重画**。
            # 不重画的话它是"未绘制"的 —— 浮窗是分层窗口，未绘制 = 透明，
            # 你会直接看到后面的聊天窗口透过来，看着就是一大块黑边（真机抓到过整片黑）。
            self._repaint_now()
            if t >= 1.0:
                self.cur_w, self.cur_h = self.target_w, self.target_h
                self.resize_from = self._resize_key = self._rz_step = None
                self.root.geometry(
                    f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
                if self._panel_closing:        # 收起动画走完了，这才把面板撤掉
                    self._finish_panel_close()
        elif self.resize_from is not None:
            # 尺寸已经到位（差得不足 1px）：把缓动状态清干净，
            # 不然下一次展开/收起会拿着过期进度瞬间跳完
            self.cur_w, self.cur_h = self.target_w, self.target_h
            self.resize_from = self._resize_key = self._rz_step = None
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            if self._panel_closing:
                self._finish_panel_close()

        # 面板是独立窗口：浮窗被拖动/吸边/换位置时，它跟着走
        if self.expanded and self.panel_win is not None:
            self._position_panel_window()

        # 帧率提高后每帧步长相应减小，观感速度保持一致
        self.level_shown += (self.level - self.level_shown) * 0.16
        self.breath = (self.breath + 0.055) % (2 * math.pi)
        self.wave_phase += 0.13 + 0.3 * self.level_shown
        if self.text_fade < 1.0:
            self.text_fade = min(1.0, self.text_fade + 0.07)
        if abs(self.switch_target - self.switch_pos) > 0.002:
            self.switch_pos += (self.switch_target - self.switch_pos) * 0.14
        else:
            self.switch_pos = self.switch_target

        state_color = COLORS.get(self.state, self.accent)
        # 我正在说话时：换成说话色，并用朗读的实时音量驱动形状和大小
        speak_active, speak_level, speak_text, speak_prog = self.read_speaking()
        if speak_active:
            self.level = speak_level

        # 养成：长时间没人理它会打哈欠→打盹；被叫醒时弹一下
        active = (self.level > 0.06 or speak_active
                  or self.state in ("listening", "hearing", "thinking", "sent",
                                    "copied", "focus"))
        if active:
            if self.sleep_stage >= 2:
                self._pop = 1.0
            self.last_active = now_t
            self.sleep_stage = 0
        elif self.mood_idle:
            idle = now_t - self.last_active
            self.sleep_stage = 2 if idle >= 240 else (1 if idle >= 120 else 0)
        else:
            self.sleep_stage = 0
        if self._pop > 0:
            self._pop = max(0.0, self._pop - self.dt * 2.0)

        # 颜色过渡：目标色变了就从"当前显示色"补间过去，用固定时长 + smoothstep，
        # 所以起步慢、收尾也慢，中间不会抖；帧率从 30 调到 60 快慢也一样。
        # 说话↔不说话换色、在设置里改配色，都会是渐变而不是"啪"地跳。
        now_t = time.time()
        target_hex = self.talk_color if speak_active else (
            state_color if self.line_follow else self.accent)
        # 语气反应：你吼得急，线条就往暖色偏；你轻声说，就往冷灰偏
        mood = str((self.status or {}).get("mood") or "")
        # 语气只在 10 秒内有效：不然一句"急"会一直黄下去，看着像自己变色
        if mood and time.time() - float((self.status or {}).get("mood_ts") or 0) > 10:
            mood = ""
        if self.mood_on and mood and not speak_active:
            target_hex = mix(target_hex, "#ff6b35" if mood == "急" else "#455270", 0.60)
        target_rgb = rgb(target_hex)
        cur = getattr(self, "_wave_rgb", None)
        if cur is None:
            cur = target_rgb
        if self.perf == "eco":                 # 节能模式：不做过渡，直接跳到目标色
            cur = target_rgb
            self._fade_from = target_rgb
            self._fade_to = target_rgb
            self._fade_t0 = now_t
            self._fade_dur = FADE_SECONDS
        else:
            if target_rgb != getattr(self, "_fade_to", None):
                self._fade_from = cur          # 从肉眼看到的颜色接着往下走
                self._fade_to = target_rgb
                self._fade_t0 = now_t
                self._fade_dur = FADE_SECONDS
            p = min(1.0, max(0.0, (now_t - self._fade_t0) / max(0.01, self._fade_dur)))
            e = p * p * (3 - 2 * p)            # smoothstep 缓动
            a = self._fade_from
            cur = tuple(a[i] + (self._fade_to[i] - a[i]) * e for i in range(3))
        self._wave_rgb = cur
        # 量化到 4 的倍数：过渡够细腻，又不会让渲染出来的颜色无限细分
        wave_color = hexs(tuple(round(c / 4) * 4 for c in cur))
        im = self.base_image().copy()
        d = ImageDraw.Draw(im)
        if self.simple_on():
            # 贴边时的"简化版小窗口"：只有一条会跟着声音起伏的细条
            self.draw_simple(im, d, wave_color)
        else:
            self.draw_full(im, d, wave_color, state_color, speak_active,
                           speak_text, speak_prog)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)
        # 透明度只在"真的变了"的时候设：每帧设一次会让窗口合成器每帧重算一遍
        if self.intro >= 1.0:
            want = self.alpha_override if self.alpha_override else self.alpha
            if abs(want - getattr(self, "_alpha_set", -1.0)) > 0.004:
                self._alpha_set = want
                try:
                    self.root.attributes("-alpha", want)
                except Exception:
                    pass
            # 给主程序回执："窗口真的画出来了"（动画循环活着 + 窗口可见 + 不是透明的）
            if (not getattr(self, "_ready_done", False)
                    or now_t - getattr(self, "_ready_ts", 0.0) > 10.0):
                self._ready_done = True
                self._ready_ts = now_t
                self.write_ready()
        # 下一帧按"这一帧开始的时间"排。以前是排在画完之后：
        # 画一帧要 6ms，间隔就变成 16+6=22ms，60 帧永远跑不到（实测只有 44 帧）。
        spent_ms = (time.perf_counter() - frame_t0) * 1000
        # 展开/收起动画期间还要留个最小步进间隔：改窗口尺寸这一步本身要 20ms 上下，
        # 不加下限的话每一步都"已经超时"，12 步会在一次事件循环里挤成一坨，
        # Windows 只画最后一个尺寸 —— 看着就是内容"啪"地出现/消失，中间什么都没有。
        floor_ms = RESIZE_STEP_MS if self.resize_from is not None else 1
        self.root.after(max(floor_ms, int(round(self.frame_ms - spent_ms))), self.anim)
        # 机器忙的时候自动降级。注意两点：
        #   · 看的是"帧间隔"（上一帧开始 → 这一帧开始），不是 anim 里的耗时 ——
        #     机器忙的时候进程会被抢走 CPU，墙体时间里的等待不该算成我们的锅；
        #   · 先关特效、不降帧。以前一上来就掉到 30 帧，结果"为了省 CPU 把画面变得更卡"。
        cost = time.perf_counter() - frame_t0
        self._frame_cost = getattr(self, "_frame_cost", cost) * 0.9 + cost * 0.1
        prev = getattr(self, "_prev_t", None)
        if prev is not None:
            gap = max(0.0, now_t - prev)
            self._period = getattr(self, "_period", gap) * 0.9 + gap * 0.1
            self._gaps.append(gap)
            if len(self._gaps) > 60:
                del self._gaps[:-60]
        self._prev_t = now_t
        self._frames = getattr(self, "_frames", 0) + 1
        budget = self.frame_ms / 1000.0
        gaps = self._gaps
        median = sorted(gaps)[len(gaps) // 2] if gaps else 0.0
        if median > budget * 1.25 and len(gaps) >= 60:
            self._slow_checks = getattr(self, "_slow_checks", 0) + 1
        else:
            self._slow_checks = 0
        if (getattr(self, "auto_tune", True)
                and not getattr(self, "_auto_low_off", False)   # 你亲手开回来的，就别再自动关
                and self._frames > 150
                and (now_t - getattr(self, "_started", now_t)) > 20
                and getattr(self, "_slow_checks", 0) >= 5):
            self._slow_checks = 0
            stage = getattr(self, "_degrade_stage", 0)
            if stage == 0:
                fancy = [k for k in FX_KEYS if self.fx.get(k)]
                if fancy:
                    # 先把"你自己选的那套"记下来：降级只是这一次运行的事，
                    # 不许它顺着"保存设置"溜进 config.json 变成你的新设置
                    self._fx_before_low = {k: bool(self.fx.get(k)) for k in FX_KEYS}
                    for k in fancy:
                        self.fx[k] = False
                    self._auto_low = True
                    self._degrade_stage = 1
                    self._frames = 0
                    note(f"帧间隔中位数 {median * 1000:.0f}ms 偏长，先关掉声音条特效（保住帧率）")
                else:
                    self._degrade_stage = 2
            elif stage == 1:
                self._degrade_stage = 2
                self.frame_ms = max(self.frame_ms, 33)
                note("关了特效还是偏长，这才降到 30 帧")

    def draw_simple(self, im, d, wave_color: str) -> None:
        """贴边时那条"简化版"：一小段会跟着声音起伏的光条，没有字也没有开关。

        竖着贴左/右边就是竖条，贴上/下边就是横条。外观页那五个特效在这里同样生效：
        视觉暂留拖残影、呼吸光晕垫柔光、星尘溅亮点、倒影来一条对称的淡影、流光扫过。
        """
        w, h = im.size
        vertical = self.snap_edge in ("left", "right")
        d.rounded_rectangle([0, 0, w - 1, h - 1], radius=min(w, h) // 2,
                            fill=self.panel_color)

        level = max(0.0, min(1.0, self.level_shown))
        wob = 0.5 + 0.5 * math.sin(self.wave_phase * 1.2)
        frac = 0.22 + 0.70 * min(1.0, level * (0.55 + 0.45 * wob) + level * 0.35)
        thick = max(2.0, min(w, h) * 0.40)
        # 光条在长轴上跟着声音来回滑（像个 VU 表）—— 有了这个"动"，
        # 视觉暂留的拖影才看得出来；不然一直是同心放大，根本看不见。
        want_pos = 0.5 + (level - 0.35) * 0.40 * math.sin(self.wave_phase * 0.62)
        want_pos = min(0.86, max(0.14, want_pos))
        now_pos = getattr(self, "_strip_pos", 0.5)
        self._strip_pos = now_pos + (want_pos - now_pos) * 0.16
        # 节能模式 / 已经自动降过级：特效一律不画（跟主声音条一个规矩）
        fx = {k: bool(v) for k, v in self.fx.items()}
        if self.perf == "eco" or getattr(self, "_auto_low", False):
            fx = {k: False for k in fx}

        def box_for(f: float, extra: float = 0.0, pos: float | None = None) -> list:
            t = thick + extra
            c = self._strip_pos if pos is None else pos
            if vertical:
                span = max(6.0, (h - 14) * f)
                mid = 7 + (h - 14) * c
                y0 = min(max(4.0, mid - span / 2), h - 4 - span)
                return [w / 2 - t / 2, y0, w / 2 + t / 2, y0 + span]
            span = max(6.0, (w - 14) * f)
            mid = 7 + (w - 14) * c
            x0 = min(max(4.0, mid - span / 2), w - 4 - span)
            return [x0, h / 2 - t / 2, x0 + span, h / 2 + t / 2]

        # ① 视觉暂留：把最近几帧的长度留成一层层淡影
        if fx.get("fx_trail"):
            for i, (old_f, old_p) in enumerate(getattr(self, "_strip_hist", [])[-3:]):
                d.rounded_rectangle(box_for(old_f, 1.0, old_p),
                                    radius=int(thick // 2) + 1,
                                    fill=mix(self.panel_color, wave_color,
                                             0.16 + 0.12 * i))
        self._strip_hist = (getattr(self, "_strip_hist", [])
                            + [(frac, self._strip_pos)])[-4:]

        # ② 倒影：旁边并排来一条更细更淡的（竖条就左右并排、横条就上下并排）
        if fx.get("fx_reflection"):
            gap = thick * 0.95
            seg = box_for(frac, -thick * 0.62)
            if vertical:
                seg = [seg[0] + gap, seg[1], seg[2] + gap, seg[3]]
            else:
                seg = [seg[0], seg[1] + gap, seg[2], seg[3] + gap]
            d.rounded_rectangle(seg, radius=int(max(1, thick // 3)),
                                fill=mix(self.panel_color, wave_color, 0.34))

        # ③ 呼吸光晕：先垫一层毛茸茸的柔光
        if fx.get("fx_glow") and level > 0.06:
            halo = Image.new("RGBA", im.size, (0, 0, 0, 0))
            hd = ImageDraw.Draw(halo)
            hd.rounded_rectangle(box_for(frac, thick * 0.6), radius=int(thick),
                                 fill=rgb(wave_color) + (int(60 + 70 * level),))
            halo = halo.filter(ImageFilter.GaussianBlur(3.0))
            im.paste(Image.alpha_composite(im.convert("RGBA"), halo).convert("RGB"),
                     (0, 0))
            d = ImageDraw.Draw(im)

        # ④ 光条本体
        d.rounded_rectangle(box_for(frac), radius=int(max(1, thick // 2)), fill=wave_color)

        # ⑤ 流光：一条高光顺着光条扫过去
        if fx.get("fx_sweep"):
            seg = box_for(frac)
            t = (self._sweep_pos * 1.6) % 1.0
            length = max(4.0, (seg[3] - seg[1]) * 0.22) if vertical \
                else max(4.0, (seg[2] - seg[0]) * 0.22)
            if vertical:
                y0 = seg[1] + (seg[3] - seg[1] - length) * t
                box = [seg[0], y0, seg[2], y0 + length]
            else:
                x0 = seg[0] + (seg[2] - seg[0] - length) * t
                box = [x0, seg[1], x0 + length, seg[3]]
            d.rounded_rectangle(box, radius=int(max(1, thick // 3)),
                                fill=mix(wave_color, "#ffffff", 0.55))

        # ⑥ 星尘：说话时在光条两头溅几个小亮点
        if fx.get("fx_sparkles") and level > 0.15:
            import random as _random

            sparks = getattr(self, "_strip_sparks", [])
            if len(sparks) < 14 and _random.random() < 0.5:
                seg = box_for(frac)
                if vertical:
                    sparks.append([w / 2 + _random.uniform(-thick, thick),
                                   _random.choice([seg[1], seg[3]]),
                                   _random.uniform(-0.5, 0.5),
                                   _random.uniform(-1.4, 1.4), 1.0])
                else:
                    sparks.append([_random.choice([seg[0], seg[2]]),
                                   h / 2 + _random.uniform(-thick, thick),
                                   _random.uniform(-1.4, 1.4),
                                   _random.uniform(-0.5, 0.5), 1.0])
            alive = []
            for sx, sy, vx2, vy2, life in sparks:
                life -= 0.06
                if life <= 0:
                    continue
                sx, sy = sx + vx2, sy + vy2
                r = 1.4 * life
                d.ellipse([sx - r, sy - r, sx + r, sy + r],
                          fill=mix(wave_color, "#ffffff", 0.5 * life))
                alive.append([sx, sy, vx2, vy2, life])
            self._strip_sparks = alive[-14:]

        # ⑦ 贴的那一侧一条高光，暗示"我贴着屏幕边"
        edge_line = {"left": [(1, 4), (1, h - 4)], "right": [(w - 2, 4), (w - 2, h - 4)],
                     "top": [(4, 1), (w - 4, 1)], "bottom": [(4, h - 2), (w - 4, h - 2)]}
        if self.snap_edge in edge_line:
            a, b = edge_line[self.snap_edge]
            d.line([a, b], fill=wave_color, width=1)

    def draw_full(self, im, d, wave_color: str, state_color: str,
                  speak_active: bool, speak_text: str, speak_prog: float) -> None:
        """平时那套样子：名字 + 状态 + 声音条 + 开关 + 箭头。"""
        w_now = im.width
        if self.show_status:
            sx, sy, ssize = self.layout["status"]
            label = LABELS.get(self.state, self.state)
            if self.focus_left > 0:
                label = LABELS["focus"]          # 专注中优先显示
            if self.sleep_stage >= 2:
                label = LABELS["sleepy"]        # 睡着了就别再写"待唤醒"
            if time.time() < self.toast_until:
                label = self.toast
            f = font(ssize)
            box = d.textbbox((0, 0), label, font=f)
            x0 = (w_now + sx - (box[2] - box[0])) if sx < 0 else sx
            # 状态图标：文字左边一个小圆点，跟着状态变色（待命绿 / 在想蓝 / 已发青 / 静音黄 / 暂停橙 / 断线灰）
            d.text((x0, sy), label, font=f,
                   fill=mix(self.panel_color, state_color, min(1.0, 0.3 + self.text_fade)))
        bands = list((self.status or {}).get("bands") or [])
        if self.spectrum_on and bands and not speak_active and self.focus_left <= 0:
            self.draw_spectrum(im, d, wave_color, bands)
        elif self.focus_left > 0:
            self.draw_focus(im, d, wave_color,
                            1.0 - self.focus_left / max(1.0, self.focus_total))
        else:
            self.draw_voice(im, wave_color)
        gap, height = self.layout["wave"]
        self.draw_caption(d, w_now, im.height - gap - height,
                          speak_text if speak_active else "", speak_prog)
        if self.show_switch:
            sw = self.switch_sprite(self.switch_pos)
            x0, y0 = self.switch_rect()
            im.paste(sw, (x0, y0), sw)
        # 出声状态：左下角一个**半透明的小喇叭**（会出声=带两道声波；静音=一道斜杠）。
        # 做法：先按 8 倍画再缩回来 → 边缘平滑不糊（小图直接画会毛刺）；再压一层透明度。
        try:
            muted = bool(self.cfg.get("muted"))
            size = max(9, int(self.layout["status"][2] * 0.85))
            k = 8
            tile = Image.new("RGBA", (size * k, size * k), (0, 0, 0, 0))
            td = ImageDraw.Draw(tile)
            col = (255, 209, 102, 255) if muted else (61, 220, 132, 255)
            u = size * k / 24.0
            def P(x, y):
                return (x * u, y * u)
            td.rounded_rectangle([P(3, 9.5), P(7.5, 14.5)], radius=1.5 * u, fill=col)
            td.polygon([P(7.5, 9.5), P(11.5, 6), P(11.5, 18), P(7.5, 14.5)], fill=col)
            if muted:
                td.line([P(14, 7.5), P(20.5, 16.5)], fill=col, width=max(1, int(1.6 * u)))
            else:
                td.arc([P(8.5, 8), P(15.5, 16)], -70, 70, fill=col, width=max(1, int(1.5 * u)))
                td.arc([P(8.5, 4.5), P(19.5, 19.5)], -70, 70, fill=col, width=max(1, int(1.5 * u)))
            tile = tile.resize((size, size), Image.LANCZOS)
            a = tile.getchannel("A").point(lambda v: int(v * 0.55))   # 半透明（55%）
            tile.putalpha(a)
            pad = max(3, int(size * 0.35))
            im.paste(tile, (pad, max(0, im.height - size - pad)), tile)
        except Exception:
            pass
        self.draw_arrow(d, w_now)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)

    def read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        return self._read_speaking()

    def write_ready(self) -> None:
        """写一张"我已经把窗口显示出来了"的回执给主程序（每 10 秒续一次时间戳）。"""
        try:
            w = self.root.winfo_x(), self.root.winfo_y()
            READY_FILE.write_text(json.dumps({
                "pid": os.getpid(),
                "ts": time.time(),
                "size": [int(self.cur_w), int(self.cur_h)],
                "pos": [int(w[0]), int(w[1])],
                "alpha": round(float(getattr(self, "_alpha_set", 0.0)), 2),
                "visible": bool(self.root.winfo_viewable()),
            }, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        counter = getattr(self, "_speak_tick", 0) + 1
        self._speak_tick = counter
        if counter % 3 != 1 and getattr(self, "_speak_cache", None) is not None:
            return self._speak_cache
        try:
            data = json.loads(SPEAK_STATUS.read_text(encoding="utf-8"))
            fresh = time.time() - float(data.get("ts") or 0) < 1.5
            self._speak_cache = (bool(data.get("active")) and fresh,
                                 float(data.get("level") or 0.0),
                                 str(data.get("text") or ""),
                                 float(data.get("progress") or 0.0))
        except Exception:
            self._speak_cache = (False, 0.0, "", 0.0)
        return self._speak_cache

    # ------------------------------------------------------------ 展开 / 收起
    def set_expanded(self, value: bool) -> None:
        if value == self.expanded:
            return
        self.expanded = value
        self.allow_keyboard(value)      # 展开时要能打字，收起后继续不抢焦点
        # 注意：不在这里改透明度 —— 你要求展开前后保持一致。
        # （透明窗口里 Windows 会关掉 ClearType，想要最锐的文字可以把透明度拉到 100%）
        if value:
            if self.panel is None:
                self.build_panel()
            # 主浮窗不改尺寸，面板是独立窗口，淡入
            self._show_panel()
            # 面板刚变大，等布局稳定再量一次"内容够不够放"，该显示滚动条就显示
            self.root.after(120, self._update_scroll_hint)
        else:
            self.set_editing(False)
            self._hide_panel()

    def _expanded_h(self) -> float:
        """展开后的窗口高度 —— **固定值**，不再跟着标签页内容变。

        以前是按当前页内容算需要多高：切到"外观"就长高一点、切到"基本"又缩回去，
        日程页还要单独给 620，看着就是"窗口自己在上下抽动"。现在固定成一个高度，
        装不下的部分用滚轮看（面板本来就是画布 + 滚轮，右边还有一条细滚动条提示）。
        高度上限还是跟着屏幕走：1080P 这种矮屏幕不会把底部按钮顶出窗外。
        """
        cap = max(420, self.root.winfo_screenheight() - 200)
        return float(self.header_h + int(min(cap, PANEL_H_OPEN)))

    def _place_panel(self, total_h: float) -> None:
        if self.panel is None:
            return
        ph = max(1, int(round(self._expanded_h() - self.header_h)))
        self.panel.place(x=0, y=0, width=self.expand_w, height=ph)
        if self.panel_win is not None:
            self.panel_win.geometry(f"{self.expand_w}x{ph}")
            self._position_panel_window()
            try:
                self.panel.update_idletasks()
            except Exception:
                pass

    def _position_panel_window(self) -> None:
        """面板窗口贴在浮窗下方/上方；浮窗本身永远不改尺寸。"""
        win = getattr(self, "panel_win", None)
        if win is None or self.panel is None:
            return
        try:
            ph = max(1, int(round(self._expanded_h() - self.header_h)))
            pw = int(self.expand_w)
            rx, ry = self.root.winfo_x(), self.root.winfo_y()
            x, y = _geometry.panel_position(
                rx, ry, self.header_h, self.compact_w, pw, ph,
                virtual_screen(), margin=8,
            )
            geom = f"{pw}x{ph}+{int(x)}+{int(y)}"
            if geom != getattr(self, "_panel_geom", ""):
                self._panel_geom = geom
                win.geometry(geom)
        except Exception:
            pass

    def _show_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._place_panel(self._expanded_h())
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            win.attributes("-alpha", 0.0)
            win.deiconify()
            win.lift()
            win.attributes("-topmost", True)
        except Exception:
            pass
        target = float(self.alpha_override or self.alpha)
        for i in range(1, 9):
            self.root.after(int(12 * i),
                            lambda a=target * i / 8, t=token:
                            self._fade_panel_step(t, a, False))

    def _hide_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            start = float(win.attributes("-alpha") or 0.0)
        except Exception:
            start = 0.0
        for i in range(1, 7):
            last = i == 6
            self.root.after(int(12 * i),
                            lambda a=start * (1 - i / 6), t=token, h=last:
                            self._fade_panel_step(t, a, h))

    def _fade_panel_step(self, token: int, alpha: float, hide: bool) -> None:
        if token != getattr(self, "_panel_fade_token", 0):
            return
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        try:
            win.attributes("-alpha", max(0.0, min(1.0, float(alpha))))
            if hide and alpha <= 0.02:
                win.withdraw()
        except Exception:
            pass

    def _repaint_now(self) -> None:
        """让新露出来的那块立刻画上（Tk 平时要等到下一次空闲才画）。

        只在这几个时刻用：改窗口尺寸、面板换高度、换标签页 —— 一帧几毫秒，
        换来的是"展开过程里看不到没画的黑块"。
        """
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        panel = getattr(self, "panel", None)
        if panel is not None:
            try:
                panel.update_idletasks()
            except Exception:
                pass
        # Tk 的 update_idletasks 只管"有空就画"，窗口刚变大的那块它不一定画 ——
        # 于是那块是黑的/透明的。这里直接让 Windows 立刻把整棵控件树重画一遍。
        _window_control.refresh_window_tree(self.root.winfo_id())
        # 分层窗口（-alpha）改尺寸之后，Windows 常常只重画"变小"的部分，
        # 新露出来的那条一直是黑的。重新设一遍 alpha 就会让它整块重新合成。
        try:
            cur = getattr(self, "_alpha_set", None)
            if cur is not None:
                self.root.attributes("-alpha", max(0.05, float(cur) - 0.001))
                self.root.attributes("-alpha", float(cur))
        except Exception:
            pass

    def _finish_panel_close(self) -> None:
        self._panel_closing = False
        # 独立窗口：收起就是淡出后 withdraw，下次展开只 deiconify
        self._hide_panel()

    # ------------------------------------------------------------ 键盘焦点
    def hwnds(self) -> list[int]:
        return _window_control.window_handles(self.root.winfo_id())

    def allow_keyboard(self, enabled: bool) -> None:
        """展开设置期间允许窗口被激活，这样输入框才能打字。"""
        try:
            _window_control.set_keyboard_activation(
                self.hwnds(), enabled, grab=True
            )
        except Exception:
            pass

    def focus_entry(self, widget) -> None:
        """点输入框时把焦点真的交给它（默认的浮窗是拿不到焦点的）。"""
        self.allow_keyboard(True)
        self.set_editing(True)
        try:
            _window_control.grab_foreground(self.hwnds()[0])
            self.root.focus_force()
            widget.focus_set()
            widget.icursor("end")
            _window_control.grab_foreground(widget.winfo_id())
        except Exception:
            pass

    def set_editing(self, on: bool) -> None:
        """告诉主程序"我正在改设置"，这段时间别抢我的键盘（别往聊天窗口粘东西）。"""
        if on == self.editing_on:
            return
        self.editing_on = on
        self.edit_touch = time.time()
        send_command("editing-on" if on else "editing-off")
        inputlog(f"编辑状态 = {'开（主程序先别抢焦点）' if on else '关'}")

    def _pick_chip(self, chips: dict, value: str) -> None:
        for k, chip in chips.items():
            chip.config(bg=self.button_color if k == value else CARD, fg="#ffffff")

    def set_send_mode(self, value: str) -> None:
        self.send_mode_value = value
        self._pick_chip(self.send_chips, value)
        self.on_change()
        self.flash("发送方式：" + {"paste_enter": "粘贴并回车", "paste": "只粘贴",
                                   "type": "当打字机"}.get(value, value), 2)

    def set_model(self, value: str) -> None:
        self.model_value = value
        self._pick_chip(self.model_chips, value)
        self.on_change()
        self.flash("模型改好了，点「重启程序」生效", 3)

    def set_lang(self, value: str) -> None:
        self.lang_value = value
        self._pick_chip(self.lang_chips, value)
        self.on_change()
        self.flash("语言改好了，点「重启程序」生效", 3)

    def refresh_send_chips(self) -> None:
        self._pick_chip(getattr(self, "send_chips", {}), self.send_mode_value)

    def refresh_model_chips(self) -> None:
        self._pick_chip(getattr(self, "model_chips", {}), self.model_value)

    def refresh_lang_chips(self) -> None:
        self._pick_chip(getattr(self, "lang_chips", {}), self.lang_value)

    def restart_program(self) -> None:
        self.flash("正在重启语音程序…", 3)
        send_command("restart")

    def ask_clear(self) -> None:
        self.flash("要清空就说「清空所有记录」再「确定清空」", 3)

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    if not single_instance():
        return 0
    try:
        Overlay().run()
        note("mainloop 正常结束（窗口被销毁）")
    except Exception:
        import traceback

        try:
            (HERE / "overlay-error.log").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
