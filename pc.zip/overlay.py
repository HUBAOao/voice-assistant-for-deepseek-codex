#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Desktop voice-assistant overlay composed from focused runtime mixins."""
from __future__ import annotations

import atexit
import os
import time
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageTk

from overlay_feature.defaults import (
    ARROW,
    BG_PANEL,
    BORDER,
    CARD,
    COLORS,
    DEFAULTS,
    FX_DOT_KEYS,
    FX_KEYS,
    KNOB,
    LABELS,
    SW_H,
    SW_W,
    VOICES,
)
from overlay_feature import runtime as _runtime
from overlay_feature import window_control as _window_control
from overlay_feature import window_geometry as _geometry
from overlay_feature import panel_controls as _panel_controls
from overlay_feature.dialogs import OverlayDialogMixin
from overlay_feature.panel_actions_runtime import PanelActionsMixin
from overlay_feature.panel_runtime import PanelRuntimeMixin
from overlay_feature.presets_mixin import OverlayPresetsMixin
from overlay_feature.runtime import (
    CONFIG,
    CONTROL,
    EXIT_LOG,
    FONT_FILES,
    INPUT_LOG,
    POS,
    READY_FILE,
    SPEAK_STATUS,
    STARTUP_LNK,
    STATUS,
    SYSLOG_FILE,
    WAKE_TEST_FILE,
    _pid_alive,
    font,
    hexs,
    mix,
    process_alive,
    rgb,
    set_no_activate,
    shade,
    startup_exists,
    virtual_screen,
)
from overlay_feature.schedule_mixin import OverlayScheduleMixin
from overlay_feature.settings_mixin import OverlaySettingsMixin
from overlay_feature.settings_onboarding_mixin import (
    OverlaySettingsOnboardingMixin,
)
from overlay_feature.settings_basic_mixin import OverlaySettingsBasicMixin
from overlay_feature.settings_wake_mixin import OverlaySettingsWakeMixin
from overlay_feature.settings_caption_mixin import OverlaySettingsCaptionMixin
from overlay_feature.settings_content_mixin import OverlaySettingsContentMixin
from overlay_feature.settings_visuals_mixin import OverlaySettingsVisualsMixin
from overlay_feature.settings_delivery_mixin import OverlaySettingsDeliveryMixin
from overlay_feature.settings_actions_mixin import OverlaySettingsActionsMixin
from overlay_feature.settings_pages_mixin import OverlaySettingsPagesMixin
from overlay_feature.settings_maintenance_mixin import (
    OverlaySettingsMaintenanceMixin,
)
from overlay_feature.settings_backup_mixin import OverlaySettingsBackupMixin
from overlay_feature.settings_memory_mixin import OverlaySettingsMemoryMixin
from overlay_feature.settings_features_mixin import OverlaySettingsFeaturesMixin
from overlay_feature.settings_reminders_mixin import OverlaySettingsRemindersMixin
from overlay_feature.settings_appearance_mixin import OverlaySettingsAppearanceMixin
from overlay_feature.settings_update_mixin import OverlaySettingsUpdateMixin
from overlay_feature.settings_remote_actions_mixin import (
    OverlaySettingsRemoteActionsMixin,
)
from overlay_feature.settings_devices_mixin import OverlaySettingsDevicesMixin
from overlay_feature.settings_uninstall_mixin import (
    OverlaySettingsUninstallMixin,
)
from overlay_feature.settings_product_actions_mixin import (
    OverlaySettingsProductActionsMixin,
)
from overlay_feature.visuals import OverlayVisualMixin
from overlay_feature.window_animation import WindowAnimationMixin
from overlay_feature.window_interaction import WindowInteractionMixin
from overlay_feature.window_render import WindowRenderMixin
from overlay_feature.window_render_simple import SimpleRenderMixin
from overlay_feature.window_state import WindowStateMixin
from overlay_feature.window_support import (
    FADE_SECONDS,
    FRAME_MS,
    PANEL_H,
    PANEL_H_OPEN,
    RESIZE_STEPS,
    RESIZE_STEP_MS,
    SIMPLE_LONG,
    SIMPLE_STEPS,
    SIMPLE_THICK,
    SNAP_PX,
    STATUS_MS,
    OverlayConfigWatcher,
    build_overlay_settings,
    config_value,
)
from overlay_feature.settings_runtime import MAX_ALPHA, MIN_ALPHA


HERE = Path(__file__).resolve().parent


def load_config() -> dict:
    return _runtime.load_config(CONFIG)


def write_config(data: dict) -> None:
    _runtime.write_config(data, CONFIG)


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


def note(text: str) -> None:
    _runtime.note(text, EXIT_LOG)


def inputlog(text: str) -> None:
    _runtime.inputlog(text, INPUT_LOG)


def single_instance() -> bool:
    return _runtime.single_instance(READY_FILE)


class Overlay(
    WindowStateMixin,
    WindowInteractionMixin,
    PanelRuntimeMixin,
    WindowAnimationMixin,
    WindowRenderMixin,
    SimpleRenderMixin,
    PanelActionsMixin,
    OverlayVisualMixin,
    OverlayDialogMixin,
    OverlayScheduleMixin,
    OverlaySettingsUninstallMixin,
    OverlaySettingsProductActionsMixin,
    OverlaySettingsDevicesMixin,
    OverlaySettingsRemoteActionsMixin,
    OverlayPresetsMixin,
    OverlaySettingsContentMixin,
    OverlaySettingsVisualsMixin,
    OverlaySettingsDeliveryMixin,
    OverlaySettingsFeaturesMixin,
    OverlaySettingsRemindersMixin,
    OverlaySettingsPagesMixin,
    OverlaySettingsBackupMixin,
    OverlaySettingsMemoryMixin,
    OverlaySettingsMaintenanceMixin,
    OverlaySettingsUpdateMixin,
    OverlaySettingsActionsMixin,
    OverlaySettingsAppearanceMixin,
    OverlaySettingsWakeMixin,
    OverlaySettingsCaptionMixin,
    OverlaySettingsBasicMixin,
    OverlaySettingsOnboardingMixin,
    OverlaySettingsMixin,
):
    def __init__(self) -> None:
        import tkinter as tk

        self._paths = {
            "HERE": HERE,
            "CONFIG": Path(CONFIG),
            "POS": Path(POS),
            "STATUS": Path(STATUS),
            "SPEAK_STATUS": Path(SPEAK_STATUS),
            "CONTROL": Path(CONTROL),
            "WAKE_TEST_FILE": Path(WAKE_TEST_FILE),
            "READY": Path(READY_FILE),
        }
        self.tk = tk
        self._config_watcher = OverlayConfigWatcher(
            path_provider=lambda: self._path("CONFIG"),
            loader=lambda: self._load_config(),
            clock=time.time,
        )
        self.cfg = self._config_watcher.load_initial()
        self.started = time.time()
        self.status: dict = {}
        self.miss = self.dead_hits = 0
        self._next_status = 0.0
        self.level = self.level_shown = 0.0
        self.breath = 0.0
        self.wave_phase = 0.0
        self.bar_heights: list[float] = []
        self.switch_pos = self.switch_target = 1.0
        self.state = "starting"
        self.text_fade = 1.0
        self.toast = ""
        self.toast_until = 0.0
        self.intro = 0.0
        self._drag = None
        self._sprites: dict = {}
        self._base = None
        self._base_key = None
        self._photo = None
        self.expanded = False
        self.alpha_override = None
        self.panel_h_shown = 0
        self.panel_h_natural = 0
        self.resize_from = None
        self._resize_key = None
        self.panel = None
        self.panel_win = None
        self._panel_fade_token = 0
        self._panel_geom = ""
        self.hint_label = None
        self._push_job = None
        self.dt = 0.016
        self._sparks: list[dict] = []
        self._trail_img = None
        self._trail_key = None
        self._sweep_pos = 0.0
        self._sweep_base = None
        self.last_active = time.time()
        self.sleep_stage = 0
        self._pop = 0.0
        self._frames = 0
        self._frame_cost = 0.0
        self._auto_low = False
        self._fx_before_low: dict | None = None
        self._auto_low_off = False
        self._degrade_stage = 0
        self._period = 0.0
        self._gaps: list[float] = []
        self._slow_checks = 0
        self._started = time.time()
        self.snap_edge = ""
        self.hovered = False
        self.snap_on = True
        self._panel_closing = False
        self.current_tab = "基本"
        self.wake_test_result = ""
        self.focus_left = 0.0
        self.focus_total = 0.0
        self.caption_win = None
        self.caption_label = None
        self.caption_last = ""
        self.caption_at = 0.0
        self.rec_win = None
        self.editing_on = False
        self.wake_test_at = 0.0
        try:
            self._wake_test_ts = float(
                __import__("json")
                .loads(
                    self._path("WAKE_TEST_FILE").read_text(
                        encoding="utf-8"
                    )
                )
                .get("ts")
                or 0
            )
        except Exception:
            self._wake_test_ts = 0.0
        self._wake_seen = str(self.cfg.get("wake_word") or "")
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.cur_w = float(self.compact_w)
        self.cur_h = float(self.header_h)
        self.target_w, self.target_h = self.cur_w, self.cur_h
        x, y = self.load_pos()
        self.base_x, self.base_y = x, y
        if self.frame_ms <= 20 and _window_control.enable_precise_timer(1):
            atexit.register(_window_control.disable_precise_timer, 1)
        self.root = tk.Tk()
        self.root.title(self.name)
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.panel_color)
        self.root.geometry(
            f"{self.compact_w}x{self.header_h}+{x}+{y - 16}"
        )
        self.root.attributes("-alpha", 0.0)
        self.root.update_idletasks()
        try:
            _window_control.make_window_tree_no_activate(
                self.root.winfo_id()
            )
        except Exception:
            pass
        self.canvas = tk.Canvas(
            self.root,
            width=self.compact_w,
            height=self.header_h,
            bg=self.panel_color,
            highlightthickness=0,
        )
        self.canvas.pack(side="top", fill="x")
        self._photo = ImageTk.PhotoImage(
            Image.new(
                "RGB",
                (self.compact_w, self.header_h),
                self.panel_color,
            )
        )
        self.img_item = self.canvas.create_image(
            0,
            0,
            anchor="nw",
            image=self._photo,
        )
        self.canvas.bind("<Button-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.open_menu)
        for widget in (self.canvas, self.root):
            widget.bind("<MouseWheel>", self.on_wheel)
        self.menu = tk.Menu(
            self.root,
            tearoff=0,
            bg="#26262d",
            fg="#ffffff",
            activebackground=self.button_color,
            activeforeground="#ffffff",
            font=("Microsoft YaHei UI", 9),
        )
        self.menu.add_command(
            label="只关浮窗（程序继续跑）",
            command=self.quit,
        )
        self.menu.add_command(
            label="🔇 静音 / 🔊 恢复出声（切换）",
            command=lambda: self._send_command("toggle-mute"),
        )
        self.menu.add_command(
            label="退出语音程序",
            command=self.quit_program,
        )
        self.root.report_callback_exception = self.on_tk_error
        self._note(f"启动 pid={os.getpid()} 位置=({x},{y})")
        self.root.after(120, self.tick)
        self.root.after(self.frame_ms, self.anim)
        self.root.after(1500, self.maybe_first_run)
        self.root.after(4000, self.warm_panel)

    def _path(self, name: str) -> Path:
        return self._paths[name]

    def _load_config(self) -> dict:
        return load_config()

    def _write_config(self, data: dict) -> None:
        write_config(data)

    def _send_command(self, action: str) -> None:
        send_command(action)

    def _note(self, text: str) -> None:
        note(text)

    def _inputlog(self, text: str) -> None:
        inputlog(text)

    def _overlay_send_command(self, action: str) -> None:
        self._send_command(action)

    def _overlay_load_config(self) -> dict:
        return self._load_config()

    def _overlay_write_config(self, data: dict) -> None:
        self._write_config(data)

    def _overlay_inputlog(self, text: str) -> None:
        self._inputlog(text)

    def warm_panel(self) -> None:
        if self.panel is not None:
            return
        try:
            self.build_panel()
            self._place_panel(self._expanded_h())
            if self.panel_win is not None and not self.expanded:
                try:
                    self.panel_win.attributes("-alpha", 0.0)
                    self.panel_win.deiconify()
                    self.panel_win.update_idletasks()
                    self.panel_win.withdraw()
                except Exception:
                    pass
        except Exception as error:
            self._note(f"预热设置面板失败：{type(error).__name__}")

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    if not single_instance():
        return 0
    try:
        Overlay().run()
        note("mainloop 正常结束（窗口被销毁）")
    except Exception:
        import traceback

        try:
            (HERE / "overlay-error.log").write_text(
                traceback.format_exc(),
                encoding="utf-8",
            )
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
