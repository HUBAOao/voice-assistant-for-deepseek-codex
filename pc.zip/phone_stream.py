# -*- coding: utf-8 -*-
"""把 Codex 当前 turn 的 assistant 文本按句推到手机。

Codex 的 thread_history 只在消息完成时落库；真正边跑边写的是会话 rollout JSONL。
这里盯住当前手机问题对应的 turn：新出现一段 assistant 文本，就切成句子逐条回调。
不读 reasoning，不碰 TTS，也不影响 Codex 自己。
"""
from __future__ import annotations

import json
import re
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path

import codex_replies

_SPLIT = re.compile(r"(?<=[。！？!?；;])|\n+")
_FLAT = re.compile(r"\s+")
STATE_DB = Path.home() / ".codex" / "state_5.sqlite"


def _norm(s: str) -> str:
    return _FLAT.sub("", str(s or ""))


def split_sentences(text: str) -> list[str]:
    parts = [p.strip() for p in _SPLIT.split(str(text or "")) if p.strip()]
    return [p for p in parts if len(p) >= 2]


def _line_ms(obj: dict) -> int:
    stamp = str(obj.get("timestamp") or "")
    try:
        return int(datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp() * 1000)
    except Exception:
        return 0


class PhoneStreamer:
    def __init__(self, log=print):
        self.log = log
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def stop(self) -> None:
        self._stop.set()
        th = self._thread
        if th and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=1.5)
        self._thread = None

    def start(self, sent_text: str, conv: str, emit, marker,
              since_ms: int | None = None) -> None:
        self.stop()
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            args=(str(sent_text or ""), str(conv or ""), emit, marker, self._stop,
                  since_ms),
            daemon=True,
        )
        self._thread.start()

    def _run(self, sent_text: str, conv: str, emit, marker, stop: threading.Event,
             since_ms: int | None = None) -> None:
        started_ms = int(since_ms or (time.time() * 1000))
        thread_id = ""
        wait_until = time.time() + 25
        while not stop.is_set() and time.time() < wait_until:
            hit = codex_replies.thread_for_text(
                sent_text, since_ms=started_ms - 20_000, look_ms=120_000)
            if hit:
                thread_id = str(hit[0])
                break
            time.sleep(0.5)
        if not thread_id:
            self.log("   ↳ 📱 流式：没定位到会话")
            return
        try:
            real_conv = str(codex_replies.titles_by_id().get(thread_id) or "").strip()
            if real_conv and real_conv not in ("ChatGPT", "Codex", "前台窗口", "自动"):
                conv = real_conv
            else:
                conv = "对话"
        except Exception:
            conv = "对话"
        path_text = codex_replies.rollout_path(thread_id)
        if not path_text:
            self.log("   ↳ 📱 流式：没找到 rollout 文件")
            return
        path = Path(path_text)
        try:
            size = path.stat().st_size
        except Exception:
            return

        # 从当前末尾附近开始，既不错过刚发的问题，也不用每次重读 30MB。
        pos = max(0, size - 4 * 1024 * 1024)
        carry = b""
        turn_id = ""
        seen_ids: set[str] = set()
        seen_sentences: set[str] = set()
        sent_key = _norm(sent_text)[:32]

        while not stop.is_set():
            try:
                with path.open("rb") as fh:
                    fh.seek(pos)
                    chunk = fh.read()
                    pos = fh.tell()
            except Exception:
                time.sleep(0.8)
                continue
            if not chunk:
                time.sleep(0.55)
                continue
            data = carry + chunk
            lines = data.split(b"\n")
            carry = lines.pop() if lines else b""
            done = False
            for raw in lines:
                if not raw.strip():
                    continue
                try:
                    obj = json.loads(raw.decode("utf-8", "replace"))
                except Exception:
                    continue
                ts = _line_ms(obj)
                if ts and ts < started_ms - 8_000:
                    continue
                typ = str(obj.get("type") or "")
                payload = obj.get("payload") or {}
                if typ == "response_item" and payload.get("type") == "message":
                    role = str(payload.get("role") or "")
                    text = "".join(str(c.get("text") or "")
                                   for c in (payload.get("content") or [])
                                   if isinstance(c, dict))
                    meta = payload.get("internal_chat_message_metadata_passthrough") or {}
                    meta_turn = str(meta.get("turn_id") or "")
                    if role == "user" and not turn_id:
                        if sent_key and sent_key in _norm(text):
                            turn_id = meta_turn
                        continue
                    if role != "assistant":
                        continue
                    if not turn_id or (meta_turn and meta_turn != turn_id):
                        continue
                    item_id = str(payload.get("id") or "")
                    if item_id and item_id in seen_ids:
                        continue
                    phase = str(payload.get("phase") or "")
                    if phase not in ("commentary", "final_answer"):
                        continue
                    for sentence in split_sentences(text):
                        key = _norm(sentence)[:180]
                        if not key or key in seen_sentences:
                            continue
                        seen_sentences.add(key)
                        try:
                            emit(conv, sentence)
                        except Exception:
                            pass
                    if item_id:
                        seen_ids.add(item_id)
                    if phase == "final_answer":
                        try:
                            marker(conv, _norm(text)[:60])
                        except Exception:
                            pass
                        done = True
                elif typ == "event_msg" and payload.get("type") == "task_complete":
                    root = str(payload.get("root_turn_id") or payload.get("turn_id") or "")
                    if turn_id and root == turn_id:
                        try:
                            marker(conv, "")      # 没有 final 段时也要结束手机的“忙”
                        except Exception:
                            pass
                        done = True
                if done:
                    break
            if done:
                return


class PhoneStreamManager:
    """一个 turn 一路：多个会话同时忙时，各发各的，不互相顶掉。"""

    def __init__(self):
        self._lock = threading.Lock()
        self._write_lock = threading.Lock()
        self._items: dict[str, PhoneStreamer] = {}

    def _prune(self) -> None:
        dead = []
        for key, st in self._items.items():
            th = st._thread
            if th is None or not th.is_alive():
                dead.append(key)
        for key in dead:
            self._items.pop(key, None)

    def start(self, sent_text: str, conv: str, emit, marker,
              since_ms: int | None = None) -> None:
        def safe_emit(c: str, s: str) -> None:
            with self._write_lock:
                emit(c, s)

        def safe_marker(c: str, p: str) -> None:
            with self._write_lock:
                marker(c, p)

        st = PhoneStreamer()
        key = f"{conv}|{time.time_ns()}"
        with self._lock:
            self._prune()
            self._items[key] = st
        st.start(sent_text, conv, safe_emit, safe_marker, since_ms=since_ms)

    def stop(self) -> None:
        with self._lock:
            items = list(self._items.values())
            self._items.clear()
        for st in items:
            st.stop()

    def active(self) -> int:
        with self._lock:
            self._prune()
            return len(self._items)


class GlobalStreamWatcher:
    """常驻观察所有近期 Codex 会话，不只观察手机刚发出的那个 turn。"""

    def __init__(self):
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._cursors: dict[str, int] = {}
        self._carry: dict[str, bytes] = {}
        self._seen: dict[str, set[str]] = {}
        self._turns: dict[str, str] = {}
        self._completed_turns: set[tuple[str, str]] = set()
        self._completion_order: list[tuple[str, str]] = []
        self._known: dict[str, tuple[str, str]] = {}
        self._bootstrapped = False

    def start(self, emit, marker) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop = threading.Event()
        self._thread = threading.Thread(
            target=self._run, args=(emit, marker, self._stop), daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        th = self._thread
        if th and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=1.5)
        self._thread = None

    def is_running(self) -> bool:
        """Whether rollout watching is alive and owns completion events."""
        th = self._thread
        return bool(th and th.is_alive() and not self._stop.is_set())

    def recent_threads(self, since_ms: int) -> list[tuple[str, str, str]]:
        try:
            con = sqlite3.connect(
                f"file:{STATE_DB.as_posix()}?mode=ro", uri=True, timeout=3.0)
            try:
                rows = con.execute(
                    "select id, coalesce(title,name,''), rollout_path, "
                    "coalesce(updated_at_ms, updated_at * 1000, 0) "
                    "from threads where archived=0 "
                    "and coalesce(updated_at_ms, updated_at * 1000, 0) >= ? "
                    "order by coalesce(updated_at_ms, updated_at * 1000, 0) desc "
                    "limit 120", (int(since_ms),)).fetchall()
            finally:
                con.close()
            try:
                import codex_replies

                title_by_id = codex_replies.titles_by_id()
            except Exception:
                title_by_id = {}
            out = []
            for tid, title, path, _updated in rows:
                path = str(path or "")
                if path.startswith("\\\\?\\"):
                    path = path[4:]
                if tid and path:
                    # state_5 里的 title 有时停留在会话第一句话；session_index
                    # 的改名结果才是手机和侧栏真正显示的名字。
                    real_title = str(title_by_id.get(str(tid)) or "").strip()
                    out.append((str(tid), real_title or str(title or "").strip(), path))
            return out
        except Exception:
            return []

    def _handle_message(self, thread_id: str, title: str, obj: dict,
                        emit, marker) -> bool:
        typ = str(obj.get("type") or "")
        payload = obj.get("payload") or {}
        if typ == "turn_context":
            turn_id = str(
                payload.get("turn_id") or payload.get("root_turn_id") or ""
            )
            if turn_id:
                self._turns[thread_id] = turn_id
            return False
        if typ == "event_msg" and payload.get("type") == "task_started":
            turn_id = str(
                payload.get("root_turn_id") or payload.get("turn_id") or ""
            )
            if turn_id:
                self._turns[thread_id] = turn_id
            return False
        if typ == "response_item" and payload.get("type") == "message":
            if str(payload.get("role") or "") != "assistant":
                return False
            phase = str(payload.get("phase") or "")
            if phase not in ("commentary", "final_answer"):
                return False
            text = "".join(
                str(c.get("text") or "") for c in (payload.get("content") or [])
                if isinstance(c, dict))
            if not text.strip():
                return False
            item_id = str(payload.get("id") or f"{thread_id}:{len(text)}")
            meta = payload.get(
                "internal_chat_message_metadata_passthrough"
            ) or {}
            turn_id = str(meta.get("turn_id") or "")
            if turn_id:
                self._turns[thread_id] = turn_id
            else:
                turn_id = self._turns.get(thread_id, "")
            seen = self._seen.setdefault(thread_id, set())
            conv = title or "对话"
            for sentence in split_sentences(text):
                key = item_id + "|" + _norm(sentence)[:180]
                if key in seen:
                    continue
                seen.add(key)
                try:
                    emit(conv, sentence)
                except Exception:
                    pass
            if phase == "final_answer":
                return self._mark_complete(
                    thread_id, turn_id or item_id, conv, text, marker
                )
        elif typ == "event_msg" and payload.get("type") == "task_complete":
            root = str(payload.get("root_turn_id") or payload.get("turn_id") or "")
            if root:
                self._turns[thread_id] = root
                return self._mark_complete(
                    thread_id, root, title or "对话", "", marker
                )
        return False

    def _mark_complete(self, thread_id: str, turn_id: str, conv: str,
                       text: str, marker) -> bool:
        """Emit one terminal event even when final_answer and task_complete both arrive."""
        if not turn_id:
            return False
        key = (thread_id, turn_id)
        if key in self._completed_turns:
            return True
        self._completed_turns.add(key)
        self._completion_order.append(key)
        if len(self._completion_order) > 2048:
            old = self._completion_order.pop(0)
            self._completed_turns.discard(old)
        try:
            marker(conv or "对话", _norm(text)[:60], f"{thread_id}:{turn_id}")
        except Exception:
            pass
        return True

    def _read_path(self, thread_id: str, title: str, path_text: str,
                   emit, marker, since_ms: int) -> None:
        path = Path(path_text)
        try:
            size = path.stat().st_size
        except Exception:
            return
        if path_text not in self._cursors:
            # 后来才出现的会话：只回看末尾 2MB，再用 started_ms 过滤，
            # 既能接住刚开始的输出，又不会把老会话整本重发。
            self._cursors[path_text] = max(0, size - 2 * 1024 * 1024)
            self._carry[path_text] = b""
        pos = self._cursors[path_text]
        if size < pos:
            pos = 0
            self._carry[path_text] = b""
        if size == pos:
            return
        try:
            with path.open("rb") as fh:
                fh.seek(pos)
                chunk = fh.read()
                self._cursors[path_text] = fh.tell()
        except Exception:
            return
        data = self._carry.get(path_text, b"") + chunk
        lines = data.split(b"\n")
        self._carry[path_text] = lines.pop() if lines else b""
        for raw in lines:
            if not raw.strip():
                continue
            try:
                obj = json.loads(raw.decode("utf-8", "replace"))
            except Exception:
                continue
            ts = _line_ms(obj)
            if ts and ts < since_ms:
                continue
            self._handle_message(thread_id, title, obj, emit, marker)

    def _run(self, emit, marker, stop: threading.Event) -> None:
        started_ms = int(time.time() * 1000)
        last_discover = 0.0
        while not stop.is_set():
            now = time.time()
            if now - last_discover >= 2.0:
                last_discover = now
                recent = self.recent_threads(started_ms - 10 * 60 * 1000)
                if not self._bootstrapped:
                    # 首轮已有会话从末尾开始，避免重发历史；之后新建的会话从头读。
                    for _tid, _title, path_text in recent:
                        try:
                            self._cursors[path_text] = Path(path_text).stat().st_size
                            self._carry[path_text] = b""
                        except Exception:
                            pass
                self._known = {path: (tid, title) for tid, title, path in recent}
                self._bootstrapped = True
            for path, (tid, title) in list(self._known.items()):
                if stop.is_set():
                    break
                self._read_path(tid, title, path, emit, marker,
                                started_ms - 8_000)
            stop.wait(0.45)


STREAMER = PhoneStreamManager()
GLOBAL_WATCHER = GlobalStreamWatcher()
