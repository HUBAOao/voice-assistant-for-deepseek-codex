#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""直接从 Codex 的会话库里读回答 —— 比"读窗口"靠谱得多。

为什么换掉读窗口：
  · 读窗口走的是 UI Automation 的 TextPattern，`GetText(N)` 是从头开始截 N 个字，
    实测只能读到 ~9700 字，**最新几条消息根本不在里面**；
  · 于是既出现"其实发出去了却说没发出去"的误判，也出现"回答念不全/念的是上一条"。

Codex 把整段对话写在 `~/.codex/thread_history_1.sqlite` 的 `thread_items` 表里：
  · item_type='userMessage'  → 你说的话（content[].text）
  · item_type='agentMessage' → 它的回答（text），phase 分 commentary（过程话）
    和 **final_answer（正经回答）**

所以：先按"你刚发出去的那句话"定位到是哪个会话，再取那个会话里最新的 final_answer。
"""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Optional

DB = Path.home() / ".codex" / "thread_history_1.sqlite"
STATE_DB = Path.home() / ".codex" / "state_5.sqlite"
SESSION_INDEX = Path.home() / ".codex" / "session_index.jsonl"
_TITLE_CACHE = {"at": 0.0, "map": {}}


def available() -> bool:
    try:
        return DB.is_file() and DB.stat().st_size > 0
    except Exception:
        return False


def _conn() -> sqlite3.Connection:
    # 只读打开（Codex 自己还在写，WAL 模式下读是安全的）
    return sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True, timeout=3.0)


def _norm(s: object) -> str:
    return "".join(str(s or "").split())


def _query(sql: str, args: tuple) -> list[tuple]:
    try:
        con = _conn()
        try:
            cur = con.cursor()
            cur.execute(sql, args)
            return cur.fetchall()
        finally:
            con.close()
    except Exception:
        return []


def titles_by_id() -> dict[str, str]:
    """thread_id → 会话标题。标题取 session_index 的改名结果，没有就用 state 库。"""
    now = time.time()
    if now - float(_TITLE_CACHE.get("at") or 0) < 30 and _TITLE_CACHE.get("map"):
        return dict(_TITLE_CACHE["map"])
    out: dict[str, str] = {}
    try:
        for ln in SESSION_INDEX.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                d = json.loads(ln)
            except Exception:
                continue
            if isinstance(d, dict) and d.get("id") and d.get("thread_name"):
                out[str(d["id"])] = str(d["thread_name"]).strip()
    except Exception:
        pass
    try:
        con = sqlite3.connect(f"file:{STATE_DB.as_posix()}?mode=ro", uri=True, timeout=3.0)
        try:
            for tid, title in con.execute("select id, title from threads"):
                tid, title = str(tid), str(title or "").strip()
                if tid and title and tid not in out:
                    out[tid] = title
        finally:
            con.close()
    except Exception:
        pass
    _TITLE_CACHE["at"] = now
    _TITLE_CACHE["map"] = out
    return dict(out)


def thread_for_text(text: str, since_ms: Optional[int] = None,
                    look_ms: int = 20 * 60 * 1000) -> Optional[tuple[str, int]]:
    """按"刚发出去的那句话"找到它落在哪个会话里 → (thread_id, 那条消息的时间)。

    这样就不用去猜"手机上选的是哪个对话"了，以实际落库为准。
    """
    key = _norm(text)[:16]
    if not key:
        return None
    since = int(since_ms or (time.time() * 1000 - look_ms))
    rows = _query(
        "select thread_id, item_json, created_at_ms from thread_items "
        "where item_type='userMessage' and created_at_ms >= ? "
        "order by created_at_ms desc limit 60", (since,))
    for tid, js, ts in rows:
        try:
            d = json.loads(js)
        except Exception:
            continue
        parts = d.get("content") or []
        txt = "".join(str(p.get("text") or "") for p in parts
                      if isinstance(p, dict))
        if key in _norm(txt):
            return str(tid), int(ts)
    return None


def latest_answer(thread_id: str, after_ms: int,
                  prefer_final: bool = True) -> Optional[tuple[str, int]]:
    """该会话里 after_ms 之后最新的一条回答 → (文本, 时间)。

    prefer_final=True 时只认 phase=final_answer（过程话不念）。
    还没出正经回答就返回 None（外面会继续等）。
    """
    if not thread_id:
        return None
    rows = _query(
        "select item_json, created_at_ms, coalesce(completed_at_ms,0) "
        "from thread_items where thread_id=? and item_type='agentMessage' "
        "and created_at_ms >= ? order by created_at_ms desc limit 20",
        (str(thread_id), int(after_ms)))
    for js, ts, done in rows:
        try:
            d = json.loads(js)
        except Exception:
            continue
        text = str(d.get("text") or "")
        if not text.strip():
            continue
        phase = str(d.get("phase") or "")
        if prefer_final and phase and phase != "final_answer":
            continue
        return text, int(ts)
    return None


def thread_for_answer(text: str, around_ms: Optional[int] = None,
                      look_ms: int = 15 * 60 * 1000) -> Optional[tuple[str, int]]:
    """按一段回答原文反查它属于哪个会话（给手机气泡标会话名用）。"""
    key = _norm(text)[:32]
    if not key:
        return None
    at = int(around_ms or (time.time() * 1000))
    rows = _query(
        "select thread_id, item_json, created_at_ms from thread_items "
        "where item_type='agentMessage' and created_at_ms >= ? "
        "and created_at_ms <= ? order by created_at_ms desc limit 200",
        (at - int(look_ms), at + 60 * 1000))
    for tid, js, ts in rows:
        try:
            d = json.loads(js)
        except Exception:
            continue
        got = _norm(d.get("text") or "")
        if got and (key in got or got[:32] in _norm(text)):
            return str(tid), int(ts)
    return None


def recent_item_threads(since_ms: int, until_ms: Optional[int] = None,
                        limit: int = 1500) -> tuple[dict[str, str], dict[str, str]]:
    """一次查出最近一段的用户/回答文本 → thread_id，供手机批量标会话名。"""
    end = int(until_ms or (time.time() * 1000)) + 60_000
    rows = _query(
        "select thread_id, item_type, item_json from thread_items "
        "where created_at_ms >= ? and created_at_ms <= ? "
        "order by created_at_ms desc limit ?",
        (int(since_ms), end, int(limit)))
    users: dict[str, str] = {}
    answers: dict[str, str] = {}
    for tid, typ, js in rows:
        try:
            d = json.loads(js)
        except Exception:
            continue
        if typ == "userMessage":
            text = "".join(str(p.get("text") or "") for p in (d.get("content") or [])
                           if isinstance(p, dict))
            target = users
        elif typ == "agentMessage":
            text = str(d.get("text") or "")
            target = answers
        else:
            continue
        key = _norm(text)[:32]
        if key and key not in target:
            target[key] = str(tid)
    return users, answers


def has_user_text(text: str, since_ms: Optional[int] = None,
                  look_ms: int = 5 * 60 * 1000) -> bool:
    """这句话到底进没进会话（用来替掉"读窗口 6 秒"那个误判）。"""
    return thread_for_text(text, since_ms=since_ms or int(time.time() * 1000 - look_ms),
                           look_ms=look_ms) is not None
