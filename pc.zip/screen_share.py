#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把电脑屏幕发给手机：截图 / 录屏，都存到 手机屏幕\\ 这个文件夹里，
手机入口（phone_link.py）再把它们端给手机看。

为什么不用 ffmpeg：用户那边的电脑不一定装，而这个功能得"装上就能用"。
录屏用 PIL 直接写成**动图**（优先 webp，退而求其次 gif）——
手机浏览器都认，不用装任何东西。

顺带处理一个坑：Windows 的 GDI 截屏**看不见分层窗口**（悬浮窗是带透明度的），
所以截完会把悬浮窗单独 PrintWindow 抓一份按 α 合进去，画面才跟肉眼看到的一致。
"""

from __future__ import annotations

import ctypes
import time
from pathlib import Path
from typing import Optional

import storage_paths

HERE = Path(__file__).resolve().parent
SHOT_DIR = storage_paths.migrate_legacy(HERE / "手机屏幕", "手机屏幕")
OVERLAY_TITLE = "大肥鱼"          # 要合进去的悬浮窗（跟设置的"名字"一致）


def _enable_dpi_awareness() -> None:
    """必须在任何截图前执行，否则高分屏只会返回缩放后的逻辑分辨率。"""
    try:
        # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


_enable_dpi_awareness()


class _BIH(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32),
                ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
                ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
                ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32),
                ("biYPelsPerMeter", ctypes.c_int32), ("biClrUsed", ctypes.c_uint32),
                ("biClrImportant", ctypes.c_uint32)]


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def _monitor_rects() -> list[tuple[int, int, int, int]]:
    u = ctypes.windll.user32
    out: list[tuple[int, int, int, int]] = []
    CB = ctypes.WINFUNCTYPE(ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p,
                            ctypes.POINTER(_RECT), ctypes.c_void_p)

    def cb(_hmon, _hdc, rect, _data):
        out.append((rect.contents.left, rect.contents.top,
                    rect.contents.right - rect.contents.left,
                    rect.contents.bottom - rect.contents.top))
        return 1

    try:
        u.EnumDisplayMonitors(None, None, CB(cb), 0)
    except Exception:
        pass
    return out


def _screen_bounds() -> tuple[int, int, int, int]:
    u = ctypes.windll.user32
    rects = _monitor_rects()
    if rects:
        left = min(r[0] for r in rects)
        top = min(r[1] for r in rects)
        right = max(r[0] + r[2] for r in rects)
        bottom = max(r[1] + r[3] for r in rects)
        return left, top, right - left, bottom - top
    return (u.GetSystemMetrics(76), u.GetSystemMetrics(77),
            u.GetSystemMetrics(78), u.GetSystemMetrics(79))


def screen_info() -> dict:
    x, y, w, h = _screen_bounds()
    rects = _monitor_rects()
    return {
        "count": len(rects) or int(ctypes.windll.user32.GetSystemMetrics(80) or 1),
        "x": x, "y": y, "width": w, "height": h,
        "monitors": [{"x": a, "y": b, "width": c, "height": d}
                     for a, b, c, d in rects],
    }


def _bbox_to_image(bbox: tuple, use_printwindow: bool = False):
    """把屏幕（或某个窗口）抓成 PIL 图片。"""
    from PIL import Image

    u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
    u32.GetDC.restype = ctypes.c_void_p
    g32.CreateCompatibleDC.restype = ctypes.c_void_p
    g32.CreateCompatibleBitmap.restype = ctypes.c_void_p
    hwnd, x, y, w, h = bbox
    src = u32.GetWindowDC(ctypes.c_void_p(hwnd)) if use_printwindow else u32.GetDC(0)
    mem = g32.CreateCompatibleDC(ctypes.c_void_p(src))
    bmp = g32.CreateCompatibleBitmap(ctypes.c_void_p(src), w, h)
    g32.SelectObject(ctypes.c_void_p(mem), ctypes.c_void_p(bmp))
    if use_printwindow:
        u32.PrintWindow(ctypes.c_void_p(hwnd), ctypes.c_void_p(mem), 2)
    else:
        g32.BitBlt(ctypes.c_void_p(mem), 0, 0, w, h, ctypes.c_void_p(src), x, y, 0x00CC0020)
    info = _BIH()
    info.biSize = ctypes.sizeof(_BIH)
    info.biWidth, info.biHeight = w, -h
    info.biPlanes, info.biBitCount, info.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(ctypes.c_void_p(mem), ctypes.c_void_p(bmp), 0, h, buf, ctypes.byref(info), 0)
    im = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1)
    g32.DeleteObject(ctypes.c_void_p(bmp))
    g32.DeleteDC(ctypes.c_void_p(mem))
    if use_printwindow:
        u32.ReleaseDC(ctypes.c_void_p(hwnd), ctypes.c_void_p(src))
    else:
        u32.ReleaseDC(0, ctypes.c_void_p(src))
    return im


def _grab_desktop_raw():
    """逐显示器抓取再拼接。一次性 BitBlt 超宽虚拟桌面会只返回局部内容。"""
    from PIL import Image

    vx, vy, vw, vh = _screen_bounds()
    monitors = _monitor_rects()
    if not monitors:
        return _bbox_to_image((0, vx, vy, vw, vh)).convert("RGB")
    out = Image.new("RGB", (vw, vh), (0, 0, 0))
    for x, y, w, h in monitors:
        part = _bbox_to_image((0, x, y, w, h)).convert("RGB")
        out.paste(part, (x - vx, y - vy))
    return out


def _overlay_bbox(title: str = OVERLAY_TITLE):
    """找悬浮窗的位置（要把它合进截图里）。"""
    u32 = ctypes.windll.user32
    found: list = []
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _l):
        if u32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(128)
            u32.GetWindowTextW(hwnd, buf, 128)
            if buf.value == title:
                found.append(hwnd)
        return True

    u32.EnumWindows(CB(cb), 0)
    if not found:
        return None
    # 桌宠容器常有一个横跨整个虚拟桌面的透明“活动区”。逐屏 GDI 截取已经
    # 包含实际桌宠画面；再把这种大窗口 PrintWindow 合成进去只会得到黑块。
    vx, vy, vw, vh = _screen_bounds()
    for hwnd in found:
        rect = (ctypes.c_int32 * 4)()
        u32.GetWindowRect(ctypes.c_void_p(hwnd), ctypes.byref(rect))
        l, t, r, b = rect
        w, h = r - l, b - t
        if w < 8 or h < 8:
            continue
        if w * h > vw * vh * 0.08 or w > max(1200, vw // 3) or h > max(900, vh // 2):
            continue
        return (hwnd, l, t, w, h)
    return None


def grab_screen_image(with_overlay: bool = True):
    """抓一张整屏（默认把悬浮窗按 α 合进去，跟肉眼看到的一致）。"""
    from PIL import Image

    vx, vy, vw, vh = _screen_bounds()
    im = _grab_desktop_raw()
    if not with_overlay:
        return im
    box = _overlay_bbox()
    if not box:
        return im
    try:
        hwnd, x, y, w, h = box
        ov = _bbox_to_image((hwnd, 0, 0, w, h), use_printwindow=True)
        alpha = ov.getchannel("A").point(lambda v: int(v * 0.95))   # 悬浮窗 95% 不透明
        ov.putalpha(alpha)
        im.paste(ov.convert("RGB"), (x - vx, y - vy), alpha)
    except Exception:
        pass
    return im


def _ensure_dir() -> Path:
    SHOT_DIR.mkdir(parents=True, exist_ok=True)
    return SHOT_DIR


def take_shot(prefix: str = "屏幕", max_width: int | None = None) -> Optional[Path]:
    """截一张屏，返回文件路径。"""
    try:
        _ensure_dir()
        im = grab_screen_image()
        if max_width and im.width > max_width:
            im = im.resize((max_width, max(1, int(im.height * max_width / im.width))))
        p = SHOT_DIR / f"{prefix}-{time.strftime('%m%d-%H%M%S')}.png"
        tmp = p.with_suffix(".part")
        im.save(tmp, format="PNG", optimize=True)
        tmp.replace(p)
        storage_paths.mirror_file(p, Path("手机屏幕") / p.name)
        prune()
        return p
    except Exception:
        return None


def _record_mp4(seconds: float, fps: int, max_width: int | None) -> Optional[Path]:
    """用 PyAV 流式编码 MP4，避免高分辨率整段帧都堆在内存里。"""
    import av
    import numpy as np

    vx, vy, vw, vh = _screen_bounds()
    end_at = time.time() + max(1.0, min(30.0, seconds))
    out = SHOT_DIR / f"录像-{time.strftime('%m%d-%H%M%S')}.mp4"
    tmp = out.with_suffix(".part")
    container = av.open(str(tmp), "w", format="mp4")
    stream = None
    first = True
    try:
        while time.time() < end_at:
            t0 = time.time()
            im = _grab_desktop_raw()
            if max_width and im.width > max_width:
                im = im.resize((max_width, max(1, int(im.height * max_width / im.width))))
            w, h = im.size
            if first:
                w -= w % 2
                h -= h % 2
                if (w, h) != im.size:
                    im = im.crop((0, 0, w, h))
                stream = container.add_stream("libx264", rate=max(3, min(12, fps)))
                stream.width, stream.height = w, h
                stream.pix_fmt = "yuv420p"
                stream.options = {"preset": "veryfast", "crf": "23"}
                first = False
            frame = av.VideoFrame.from_ndarray(np.asarray(im), format="rgb24")
            for packet in stream.encode(frame):
                container.mux(packet)
            spent = time.time() - t0
            delay = 1.0 / max(3, min(12, fps))
            if spent < delay:
                time.sleep(delay - spent)
        if stream is None:
            container.close()
            out.unlink(missing_ok=True)
            return None
        for packet in stream.encode():
            container.mux(packet)
        container.close()
        tmp.replace(out)
        storage_paths.mirror_file(out, Path("手机屏幕") / out.name)
        prune()
        return out
    except Exception:
        try:
            container.close()
        except Exception:
            pass
        try:
            out.unlink(missing_ok=True)
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return None


def record_screen(seconds: float = 8.0, fps: int = 6,
                  max_width: int | None = 5120) -> Optional[Path]:
    """录一段全屏 MP4；失败时退回高分辨率 WebP 动图。"""
    try:
        _ensure_dir()
        mp4 = _record_mp4(seconds, fps, max_width)
        if mp4:
            return mp4
        vx, vy, vw, vh = _screen_bounds()
        frames = []
        delay = 1.0 / max(3, min(15, fps))
        end_at = time.time() + max(1.0, min(60.0, seconds))
        while time.time() < end_at:
            t0 = time.time()
            im = _grab_desktop_raw()
            if max_width and im.width > max_width:
                im = im.resize((max_width, max(1, int(im.height * max_width / im.width))))
            frames.append(im)
            spent = time.time() - t0
            if spent < delay:
                time.sleep(delay - spent)
        if not frames:
            return None
        out_webp = SHOT_DIR / f"录像-{time.strftime('%m%d-%H%M%S')}.webp"
        out_tmp = out_webp.with_suffix(".part")
        try:
            frames[0].save(out_tmp, "WEBP", save_all=True, append_images=frames[1:],
                           duration=int(1000 * delay), loop=0, quality=70, method=4)
            out_tmp.replace(out_webp)
            storage_paths.mirror_file(out_webp, Path("手机屏幕") / out_webp.name)
            prune()
            return out_webp
        except Exception:
            out_gif = out_webp.with_suffix(".gif")
            out_tmp = out_gif.with_suffix(".part")
            frames[0].save(out_tmp, "GIF", save_all=True, append_images=frames[1:],
                           duration=int(1000 * delay), loop=0, optimize=True)
            out_tmp.replace(out_gif)
            storage_paths.mirror_file(out_gif, Path("手机屏幕") / out_gif.name)
            prune()
            return out_gif
    except Exception:
        return None


def _phone_preview_path(source: Path, max_width: int = 2560) -> Path:
    """Keep the original recording and cache a decoder-safe phone copy."""
    if source.suffix.lower() != ".mp4":
        return source
    preview = source.with_name(f"{source.stem}-phone.mp4")
    try:
        if preview.is_file() and preview.stat().st_mtime >= source.stat().st_mtime:
            return preview
        import av
        from PIL import Image

        with av.open(str(source)) as incoming:
            stream = incoming.streams.video[0]
            if not stream.width or stream.width <= max_width:
                return source
            width = max_width
            height = max(2, round(stream.height * width / stream.width))
            if height % 2:
                height += 1
            tmp = preview.with_suffix(".part")
            tmp.unlink(missing_ok=True)
            with av.open(str(tmp), "w", format="mp4") as outgoing:
                target = outgoing.add_stream(
                    "libx264",
                    rate=stream.average_rate or stream.guessed_rate or 6,
                )
                target.width, target.height = width, height
                target.pix_fmt = "yuv420p"
                target.options = {"preset": "veryfast", "crf": "23"}
                for frame in incoming.decode(video=0):
                    image = frame.to_image().resize(
                        (width, height), resample=Image.Resampling.LANCZOS
                    )
                    for packet in target.encode(av.VideoFrame.from_image(image)):
                        outgoing.mux(packet)
                for packet in target.encode():
                    outgoing.mux(packet)
            tmp.replace(preview)
            try:
                storage_paths.mirror_file(
                    preview, Path("手机屏幕") / preview.name
                )
            except Exception:
                pass
            return preview
    except Exception:
        try:
            preview.unlink(missing_ok=True)
            preview.with_suffix(".part").unlink(missing_ok=True)
        except Exception:
            pass
        return source


def list_shots(limit: int = 24) -> list[dict]:
    """最近发过来的屏幕（新的在前）。"""
    if not SHOT_DIR.exists():
        return []
    out = []
    visible = [
        p for p in SHOT_DIR.glob("*")
        if not p.name.endswith("-phone.mp4")
        and p.suffix.lower() in (".png", ".webp", ".mp4", ".gif", ".jpg", ".jpeg")
    ]
    for p in sorted(visible, key=lambda f: f.stat().st_mtime, reverse=True)[:limit]:
        st = p.stat()
        item = {
            "name": p.name,
            "kind": "video" if p.suffix.lower() in (".webp", ".gif", ".mp4")
            else "image",
            "ts": st.st_mtime,
            "kb": round(st.st_size / 1024, 1),
        }
        if p.suffix.lower() == ".mp4":
            preview = _phone_preview_path(p)
            if preview != p:
                item["preview"] = preview.name
        out.append(item)
    return out


def prune(keep: int = 24) -> None:
    """只留最近这些，别把硬盘塞满。"""
    if not SHOT_DIR.exists():
        return
    files = sorted(
        (
            p for p in SHOT_DIR.glob("*")
            if not p.name.endswith("-phone.mp4")
            and not p.name.endswith(".part")
        ),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )
    for old in files[keep:]:
        try:
            old.unlink()
            old.with_name(f"{old.stem}-phone.mp4").unlink(missing_ok=True)
        except Exception:
            pass
    live = {f"{p.stem}-phone.mp4" for p in files[:keep]}
    for preview in SHOT_DIR.glob("*-phone.mp4"):
        if preview.name not in live:
            try:
                preview.unlink()
            except Exception:
                pass


def shot_path(name: str) -> Optional[Path]:
    """按名字取文件（只认这个目录里的、名字里没有路径分隔符的，防穿越）。"""
    if not name or "/" in name or "\\" in name or ".." in name:
        return None
    p = SHOT_DIR / name
    return p if p.is_file() else None
