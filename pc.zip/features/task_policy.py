# -*- coding: utf-8 -*-
"""Task risk, retention, truncation, and secret-redaction policy."""
from __future__ import annotations

import re
import time
from typing import Any


STATUSES = {
    "queued",
    "running",
    "waiting_approval",
    "succeeded",
    "failed",
    "cancelled",
}
RISK_KEYWORDS = {
    "high": (
        "删除",
        "永久",
        "格式化",
        "卸载",
        "发布",
        "推送",
        "付款",
        "转账",
        "rm -rf",
        "del ",
        "remove-item",
        "drop table",
        "reset --hard",
    ),
    "medium": (
        "安装",
        "更新",
        "移动",
        "改名",
        "重命名",
        "上传",
        "提交",
        "commit",
        "merge",
        "覆盖",
        "write",
        "write_text",
    ),
}
DEFAULT_RETENTION = {
    "terminal_days": 14,
    "max_tasks": 200,
    "max_diff_chars": 65536,
    "max_tool_output_chars": 4096,
}
SECRET_PATTERNS = (
    re.compile(r"(?i)\b(Bearer)\s+[A-Za-z0-9._~+/=-]{12,}"),
    re.compile(
        r"(?i)\b(token|secret|password|passwd|api[_-]?key|authorization)"
        r"(\s*[:=]\s*)([^\s,;，。]{8,})"
    ),
    re.compile(
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
        re.S,
    ),
)


def redact_sensitive(text: str, *, limit: int = 4096) -> str:
    """Remove common credentials before task details are persisted or shown."""
    value = str(text or "")
    value = SECRET_PATTERNS[2].sub("[私钥已隐去]", value)
    value = SECRET_PATTERNS[0].sub(r"\1 [已隐去]", value)
    value = SECRET_PATTERNS[1].sub(r"\1\2[已隐去]", value)
    if limit > 0 and len(value) > int(limit):
        value = value[: int(limit)] + "\n…（已截断）"
    return value


def next_revision(data: dict[str, Any]) -> int:
    revision = max(1, int(data.get("revision") or 1)) + 1
    data["revision"] = revision
    return revision


def merge_retention(raw: Any) -> dict[str, int]:
    value = dict(DEFAULT_RETENTION)
    if isinstance(raw, dict):
        for key in value:
            try:
                number = int(raw.get(key))
            except (TypeError, ValueError):
                continue
            if number > 0:
                value[key] = number
    return value


def prune_data(data: dict[str, Any]) -> None:
    """Bound terminal history without dropping pending approvals."""
    tasks = data.get("tasks")
    if not isinstance(tasks, dict):
        data["tasks"] = {}
        return
    policy = merge_retention(data.get("retention"))
    data["retention"] = policy
    now = time.time()
    terminal = {"succeeded", "failed", "cancelled"}
    for task_id, task in list(tasks.items()):
        if not isinstance(task, dict):
            tasks.pop(task_id, None)
            continue
        stamp = float(task.get("updated_at") or task.get("created_at") or 0)
        if (
            task.get("status") in terminal
            and stamp
            and now - stamp > policy["terminal_days"] * 86400
        ):
            tasks.pop(task_id, None)
    if len(tasks) <= policy["max_tasks"]:
        return
    removable = [
        (float(task.get("updated_at") or 0), task_id)
        for task_id, task in tasks.items()
        if isinstance(task, dict)
        and task.get("status") in terminal
        and (task.get("approval") or {}).get("decision") != "pending"
    ]
    removable.sort()
    for _, task_id in removable[: max(0, len(tasks) - policy["max_tasks"])]:
        tasks.pop(task_id, None)


def sanitize_data(data: dict[str, Any]) -> None:
    """Apply retention limits and secret redaction at the storage boundary."""
    policy = merge_retention(data.get("retention"))
    for task in (data.get("tasks") or {}).values():
        if not isinstance(task, dict):
            continue
        task["title"] = redact_sensitive(str(task.get("title") or ""), limit=160)
        task["detail"] = redact_sensitive(str(task.get("detail") or ""), limit=1000)
        task["error"] = redact_sensitive(str(task.get("error") or ""), limit=1000)
        task["diff"] = redact_sensitive(
            str(task.get("diff") or ""),
            limit=policy["max_diff_chars"],
        )
        approval = task.get("approval")
        if isinstance(approval, dict):
            for key in ("command", "target", "reason", "note"):
                if key in approval:
                    approval[key] = redact_sensitive(
                        str(approval.get(key) or ""),
                        limit=2000 if key == "command" else 500,
                    )
        for message in task.get("messages") or []:
            if isinstance(message, dict):
                message["text"] = redact_sensitive(
                    str(message.get("text") or ""),
                    limit=4000,
                )
        for tool in task.get("tool_calls") or []:
            if not isinstance(tool, dict):
                continue
            tool["detail"] = redact_sensitive(
                str(tool.get("detail") or ""),
                limit=1000,
            )
            if tool.get("output"):
                tool["output"] = redact_sensitive(
                    str(tool.get("output") or ""),
                    limit=policy["max_tool_output_chars"],
                )


def classify_risk(command: str) -> str:
    text = str(command or "").lower()
    for risk in ("high", "medium"):
        if any(word in text for word in RISK_KEYWORDS[risk]):
            return risk
    return "low"
