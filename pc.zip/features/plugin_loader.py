# -*- coding: utf-8 -*-
"""Validate plugin manifests and explicitly execute enabled modules."""
from __future__ import annotations

import importlib.util
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from types import ModuleType
from typing import Any


PLUGIN_API = 1
ALLOWED_CAPABILITIES = {"command", "page", "stt", "tts", "task-provider"}
ALLOWED_PERMISSIONS = {
    "clipboard",
    "codex",
    "filesystem-read",
    "filesystem-write",
    "microphone",
    "network",
    "notifications",
    "playback",
    "tasks",
}
PLUGIN_ID = re.compile(r"^[a-z][a-z0-9._-]{1,63}$")


@dataclass(frozen=True)
class PluginRecord:
    id: str
    name: str
    version: str
    api: int
    entrypoint: Path
    capabilities: tuple[str, ...]
    permissions: tuple[str, ...]
    source: Path
    description: str = ""
    error: str = ""

    def public(self) -> dict[str, Any]:
        value = asdict(self)
        value["entrypoint"] = str(self.entrypoint)
        value["source"] = str(self.source)
        value["capabilities"] = list(self.capabilities)
        value["permissions"] = list(self.permissions)
        return value


def inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


class PluginRegistry:
    """Discover manifests without executing code; loading is explicit."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self._records: dict[str, PluginRecord] = {}
        self._modules: dict[str, ModuleType] = {}

    def _record(
        self,
        folder: Path,
        manifest_path: Path,
        raw: Any,
    ) -> PluginRecord:
        if not isinstance(raw, dict):
            raise ValueError("manifest 必须是 JSON 对象")
        plugin_id = str(raw.get("id") or folder.name).strip()
        if not PLUGIN_ID.fullmatch(plugin_id):
            raise ValueError("plugin id 格式不正确")
        try:
            api = int(raw.get("api") or 0)
        except (TypeError, ValueError) as error:
            raise ValueError("插件 API 版本不正确") from error
        if api != PLUGIN_API:
            raise ValueError("插件 API 版本不兼容")
        entry = str(raw.get("entrypoint") or "").strip()
        if not entry or Path(entry).is_absolute():
            raise ValueError("entrypoint 必须是插件目录内的相对路径")
        entrypoint = (folder / entry).resolve()
        if not inside(entrypoint, folder) or entrypoint.suffix.lower() != ".py":
            raise ValueError("entrypoint 越界或不是 Python 文件")
        if not entrypoint.is_file():
            raise ValueError("entrypoint 文件不存在")
        capabilities = tuple(
            sorted(
                {
                    str(item).strip().lower()
                    for item in raw.get("capabilities") or []
                    if str(item).strip()
                }
            )
        )
        unknown = set(capabilities) - ALLOWED_CAPABILITIES
        if unknown:
            raise ValueError("未知插件能力：" + ", ".join(sorted(unknown)))
        permissions = tuple(
            sorted(
                {
                    str(item).strip().lower()
                    for item in raw.get("permissions") or []
                    if str(item).strip()
                }
            )
        )
        unknown_permissions = set(permissions) - ALLOWED_PERMISSIONS
        if unknown_permissions:
            raise ValueError(
                "未知插件权限：" + ", ".join(sorted(unknown_permissions))
            )
        return PluginRecord(
            id=plugin_id,
            name=str(raw.get("name") or plugin_id)[:80],
            version=str(raw.get("version") or "0.0.0")[:40],
            api=PLUGIN_API,
            entrypoint=entrypoint,
            capabilities=capabilities,
            permissions=permissions,
            source=manifest_path,
            description=str(raw.get("description") or "")[:500],
        )

    def discover(self) -> dict[str, PluginRecord]:
        found: dict[str, PluginRecord] = {}
        if not self.root.is_dir():
            self._records = {}
            return {}
        root = self.root.resolve()
        for folder in sorted(self.root.iterdir(), key=lambda item: item.name):
            if (
                not folder.is_dir()
                or folder.name.startswith((".", "_"))
                or folder.is_symlink()
                or not inside(folder, root)
            ):
                continue
            manifest_path = folder / "plugin.json"
            if not manifest_path.is_file() or manifest_path.is_symlink():
                continue
            try:
                raw = json.loads(manifest_path.read_text(encoding="utf-8"))
                record = self._record(folder, manifest_path, raw)
                if record.id in found:
                    raise ValueError("plugin id 重复")
                found[record.id] = record
            except Exception as error:
                record = PluginRecord(
                    id=folder.name[:64],
                    name=folder.name[:80],
                    version="0",
                    api=0,
                    entrypoint=manifest_path,
                    capabilities=(),
                    permissions=(),
                    source=manifest_path,
                    error=str(error)[:240],
                )
                found[record.id] = record
        self._records = found
        return dict(found)

    def status(self, *, enabled: set[str] | None = None) -> list[dict[str, Any]]:
        active = set(enabled or ())
        rows = []
        for record in self.discover().values():
            item = record.public()
            item["enabled"] = record.id in active
            item["loaded"] = record.id in self._modules
            rows.append(item)
        rows.sort(key=lambda item: (bool(item.get("error")), item["id"]))
        return rows

    def load(self, plugin_id: str, *, context: Any) -> ModuleType:
        if plugin_id not in self._records:
            self.discover()
        record = self._records.get(str(plugin_id))
        if record is None or record.error:
            raise ValueError("插件不存在或清单无效")
        if plugin_id in self._modules:
            return self._modules[plugin_id]
        module_name = "findeck_plugin_" + re.sub(r"[^a-z0-9_]", "_", plugin_id)
        spec = importlib.util.spec_from_file_location(module_name, record.entrypoint)
        if spec is None or spec.loader is None:
            raise ValueError("无法创建插件模块")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
            hook = getattr(module, "register", None)
            if callable(hook):
                hook(context)
        except Exception:
            sys.modules.pop(module_name, None)
            raise
        self._modules[plugin_id] = module
        return module

    def unload(self, plugin_id: str, *, context: Any | None = None) -> None:
        plugin_id = str(plugin_id)
        module = self._modules.pop(plugin_id, None)
        if module is None:
            return
        for hook_name in ("deactivate", "unregister"):
            hook = getattr(module, hook_name, None)
            if not callable(hook):
                continue
            try:
                hook(context)
            except Exception:
                pass
        module_name = getattr(module, "__name__", "")
        if module_name:
            sys.modules.pop(module_name, None)

    def load_enabled(self, enabled: set[str], *, context: Any) -> dict[str, str]:
        if not self._records:
            self.discover()
        loaded: dict[str, str] = {}
        for plugin_id in sorted(set(enabled)):
            try:
                self.load(plugin_id, context=context)
                loaded[plugin_id] = "loaded"
            except Exception as error:
                loaded[plugin_id] = "error: " + str(error)[:180]
        return loaded
