# -*- coding: utf-8 -*-
"""Compatibility facade for task storage, policy, and Codex turn sync."""
from __future__ import annotations

from features.task_policy import (
    DEFAULT_RETENTION,
    RISK_KEYWORDS,
    SECRET_PATTERNS,
    STATUSES,
    classify_risk,
    merge_retention,
    next_revision,
    prune_data,
    redact_sensitive,
    sanitize_data,
)
from features.task_store import TaskStore
from features.task_sync import (
    LAST_SYNC,
    SYNC_LOCK,
    approval_expired,
    sync_recent_threads,
    turn_changes,
    turn_status,
    turn_tests,
    turn_tools,
)


_SECRET_PATTERNS = SECRET_PATTERNS
_next_revision = next_revision
_merge_retention = merge_retention
_prune_data = prune_data
_sanitize_data = sanitize_data
_SYNC_LOCK = SYNC_LOCK
_LAST_SYNC = LAST_SYNC
_turn_status = turn_status
_turn_changes = turn_changes
_turn_tools = turn_tools
_turn_tests = turn_tests
_approval_expired = approval_expired


__all__ = [
    "DEFAULT_RETENTION",
    "RISK_KEYWORDS",
    "STATUSES",
    "TaskStore",
    "classify_risk",
    "redact_sensitive",
    "sync_recent_threads",
]
