# -*- coding: utf-8 -*-
"""Persistent task state, approvals, tool activity, tests, and diffs."""
from __future__ import annotations

import json
import os
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from features.secure_store import read_secure, write_secure

STATUSES = {
    "queued",
    "running",
    "waiting_approval",
    "succeeded",
    "failed",
    "cancelled",
}

RISK_KEYWORDS = {
    "high": (
        "删除", "永久", "格式化", "卸载", "发布", "推送", "付款", "转账",
        "rm -rf", "del ", "remove-item", "drop table", "reset --hard",
    ),
    "medium": (
        "安装", "更新", "移动", "改名", "重命名", "上传", "提交", "commit",
        "merge", "覆盖", "write", "write_text",
    ),
}

DEFAULT_RETENTION = {
    "terminal_days": 14,
    "max_tasks": 200,
    "max_diff_chars": 65536,
    "max_tool_output_chars": 4096,
}
_SECRET_PATTERNS = (
    re.compile(r"(?i)\b(Bearer)\s+[A-Za-z0-9._~+/=-]{12,}"),
    re.compile(
        r"(?i)\b(token|secret|password|passwd|api[_-]?key|authorization)"
        r"(\s*[:=]\s*)([^\s,;，。]{8,})"
    ),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
               re.S),
)


def redact_sensitive(text: str, *, limit: int = 4096) -> str:
    """Remove common credentials before task details are persisted or shown."""
    value = str(text or "")
    value = _SECRET_PATTERNS[2].sub("[私钥已隐去]", value)
    value = _SECRET_PATTERNS[0].sub(r"\1 [已隐去]", value)
    value = _SECRET_PATTERNS[1].sub(r"\1\2[已隐去]", value)
    if limit > 0 and len(value) > int(limit):
        value = value[:int(limit)] + "\n…（已截断）"
    return value


def _next_revision(data: dict[str, Any]) -> int:
    revision = max(1, int(data.get("revision") or 1)) + 1
    data["revision"] = revision
    return revision


def _merge_retention(raw: Any) -> dict[str, int]:
    value = dict(DEFAULT_RETENTION)
    if isinstance(raw, dict):
        for key in value:
            try:
                number = int(raw.get(key))
            except (TypeError, ValueError):
                continue
            if number > 0:
                value[key] = number
    return value


def _prune_data(data: dict[str, Any]) -> None:
    """Bound terminal history while never silently dropping pending approval."""
    tasks = data.get("tasks")
    if not isinstance(tasks, dict):
        data["tasks"] = {}
        return
    policy = _merge_retention(data.get("retention"))
    data["retention"] = policy
    now = time.time()
    terminal = {"succeeded", "failed", "cancelled"}
    for task_id, task in list(tasks.items()):
        if not isinstance(task, dict):
            tasks.pop(task_id, None)
            continue
        stamp = float(task.get("updated_at") or task.get("created_at") or 0)
        if (task.get("status") in terminal
                and stamp and now - stamp > policy["terminal_days"] * 86400):
            tasks.pop(task_id, None)
    if len(tasks) <= policy["max_tasks"]:
        return
    removable = [
        (float(task.get("updated_at") or 0), task_id)
        for task_id, task in tasks.items()
        if isinstance(task, dict)
        and task.get("status") in terminal
        and not ((task.get("approval") or {}).get("decision") == "pending")
    ]
    removable.sort()
    for _, task_id in removable[:max(0, len(tasks) - policy["max_tasks"])]:
        tasks.pop(task_id, None)


def _sanitize_data(data: dict[str, Any]) -> None:
    """Apply retention limits and secret redaction at the storage boundary."""
    policy = _merge_retention(data.get("retention"))
    for task in (data.get("tasks") or {}).values():
        if not isinstance(task, dict):
            continue
        task["title"] = redact_sensitive(str(task.get("title") or ""), limit=160)
        task["detail"] = redact_sensitive(str(task.get("detail") or ""), limit=1000)
        task["error"] = redact_sensitive(str(task.get("error") or ""), limit=1000)
        task["diff"] = redact_sensitive(
            str(task.get("diff") or ""),
            limit=policy["max_diff_chars"],
        )
        approval = task.get("approval")
        if isinstance(approval, dict):
            for key in ("command", "target", "reason", "note"):
                if key in approval:
                    approval[key] = redact_sensitive(
                        str(approval.get(key) or ""),
                        limit=2000 if key == "command" else 500,
                    )
        for message in task.get("messages") or []:
            if isinstance(message, dict):
                message["text"] = redact_sensitive(
                    str(message.get("text") or ""), limit=4000
                )
        for tool in task.get("tool_calls") or []:
            if not isinstance(tool, dict):
                continue
            tool["detail"] = redact_sensitive(
                str(tool.get("detail") or ""), limit=1000
            )
            if tool.get("output"):
                tool["output"] = redact_sensitive(
                    str(tool.get("output") or ""),
                    limit=policy["max_tool_output_chars"],
                )


def classify_risk(command: str) -> str:
    text = str(command or "").lower()
    for risk in ("high", "medium"):
        if any(word in text for word in RISK_KEYWORDS[risk]):
            return risk
    return "low"


class TaskStore:
    """Small thread-safe JSON task store with atomic writes."""

    def __init__(self, path: Path | None = None) -> None:
        configured = os.environ.get("FIN_DECK_TASKS_FILE", "").strip()
        if path is None and configured:
            path = Path(configured)
        if path is None:
            try:
                import storage_paths

                path = storage_paths.DATA_ROOT / "任务" / "tasks.json"
            except Exception:
                path = Path(__file__).resolve().parent.parent / "任务" / "tasks.json"
        self.path = Path(path)
        self._lock = threading.RLock()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(read_secure(self.path).decode("utf-8"))
            if isinstance(data, dict) and isinstance(data.get("tasks"), dict):
                return data
        except Exception:
            pass
        data = {"version": 2, "revision": 1,
                "tasks": {}, "retention": dict(DEFAULT_RETENTION)}
        return data

    def _save(self, data: dict[str, Any]) -> None:
        data.setdefault("version", 2)
        data.setdefault("revision", 1)
        _prune_data(data)
        _sanitize_data(data)
        raw = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        write_secure(self.path, raw)

    @staticmethod
    def _event(task: dict[str, Any], kind: str, detail: str = "") -> None:
        events = task.setdefault("events", [])
        events.append({"at": time.time(), "kind": str(kind)[:40],
                       "detail": str(detail)[:300]})
        if len(events) > 200:
            del events[:-200]

    def create(self, title: str, *, thread_id: str = "", detail: str = "") -> dict[str, Any]:
        title = str(title or "").strip() or "未命名任务"
        now = time.time()
        task = {
            "id": "task_" + uuid.uuid4().hex[:16],
            "title": title[:160],
            "detail": str(detail or "")[:1000],
            "thread_id": str(thread_id or ""),
            "status": "queued",
            "created_at": now,
            "updated_at": now,
            "tool_calls": [],
            "tests": [],
            "changes": [],
            "messages": [],
            "approval": None,
            "error": "",
            "diff": "",
            "active_turn_id": "",
            "revision": 0,
            "events": [],
        }
        self._event(task, "created")
        with self._lock:
            data = self._load()
            task["revision"] = _next_revision(data)
            data["tasks"][task["id"]] = task
            self._save(data)
        return dict(task)

    def get(self, task_id: str) -> dict[str, Any] | None:
        with self._lock:
            task = self._load()["tasks"].get(str(task_id))
            return dict(task) if task else None

    def find_by_source(self, source: str, source_id: str) -> dict[str, Any] | None:
        with self._lock:
            for task in self._load()["tasks"].values():
                if (task.get("source") == str(source)
                        and task.get("source_id") == str(source_id)):
                    return dict(task)
        return None

    def list(self, *, status: str = "", limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            tasks = list(self._load()["tasks"].values())
        if status:
            tasks = [task for task in tasks if task.get("status") == status]
        tasks.sort(key=lambda task: float(task.get("updated_at") or 0), reverse=True)
        return [dict(task) for task in tasks[:max(1, int(limit))]]

    def snapshot(self, *, after: int = 0, limit: int = 100) -> dict[str, Any]:
        """Return a reconnect-safe delta plus the authoritative cursor."""
        with self._lock:
            data = self._load()
        cursor = max(1, int(data.get("revision") or 1))
        tasks = []
        for task in data["tasks"].values():
            if not isinstance(task, dict):
                continue
            if after and int(task.get("revision") or 0) <= int(after):
                continue
            tasks.append(dict(task))
        tasks.sort(key=lambda task: float(task.get("updated_at") or 0), reverse=True)
        return {
            "items": tasks[:max(1, int(limit))],
            "ids": sorted(str(task_id) for task_id in data["tasks"]),
            "cursor": cursor,
            "reset": bool(after and int(after) > cursor),
            "retention": _merge_retention(data.get("retention")),
        }

    def update(self, task_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            data = self._load()
            task = data["tasks"].get(str(task_id))
            if not task:
                raise KeyError("任务不存在")
            status = fields.get("status")
            if status and status not in STATUSES:
                raise ValueError("未知任务状态：%s" % status)
            for key, value in fields.items():
                if key in {"id", "created_at", "events"}:
                    continue
                task[key] = value
            task["updated_at"] = time.time()
            task["revision"] = _next_revision(data)
            self._event(task, "updated", ",".join(sorted(fields)))
            self._save(data)
            return dict(task)

    def request_approval(self, task_id: str, command: str, *,
                         target: str = "", risk: str = "",
                         request_id: Any = None, method: str = "",
                         item_id: str = "", thread_id: str = "",
                         turn_id: str = "", reason: str = "",
                         available_decisions: list[str] | None = None,
                         live: bool = False) -> dict[str, Any]:
        risk = str(risk or classify_risk(command)).lower()
        if risk not in {"low", "medium", "high"}:
            risk = "high"
        approval = {
            "command": redact_sensitive(str(command or ""), limit=2000),
            "target": redact_sensitive(str(target or ""), limit=500),
            "risk": risk,
            "requested_at": time.time(),
            "decision": "pending",
            "request_id": request_id,
            "method": str(method or "")[:120],
            "item_id": str(item_id or "")[:160],
            "thread_id": str(thread_id or "")[:160],
            "turn_id": str(turn_id or "")[:160],
            "reason": redact_sensitive(str(reason or ""), limit=500),
            "available_decisions": list(available_decisions or [])[:12],
            "live": bool(live),
        }
        return self.update(task_id, status="waiting_approval", approval=approval)

    def decide(self, task_id: str, approved: bool, note: str = "", *,
               decision: str = "", response_sent: bool = False) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        approval = task.get("approval") or {}
        if approval.get("decision") != "pending":
            raise ValueError("没有待批准请求")
        approval.update({
            "decision": str(decision or ("approved" if approved else "rejected")),
            "decided_at": time.time(),
            "note": redact_sensitive(str(note or ""), limit=500),
            "response_sent": bool(response_sent),
        })
        # A declined Codex approval lets the agent continue and choose another
        # path; it does not cancel the whole turn.  Purely local approvals keep
        # the old cancellation behavior.
        status = "running" if approved or approval.get("method") else "cancelled"
        return self.update(task_id, status=status, approval=approval)

    def add_tool_call(self, task_id: str, name: str, *, status: str = "running",
                      detail: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        calls = list(task.get("tool_calls") or [])
        calls.append({"name": str(name)[:120], "status": str(status)[:30],
                      "detail": redact_sensitive(detail, limit=1000),
                      "at": time.time()})
        return self.update(task_id, tool_calls=calls[-100:])

    def add_test(self, task_id: str, name: str, ok: bool, *,
                 detail: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        tests = list(task.get("tests") or [])
        tests.append({"name": str(name)[:160], "ok": bool(ok),
                      "detail": redact_sensitive(detail, limit=2000),
                      "at": time.time()})
        return self.update(task_id, tests=tests[-100:])

    def set_changes(self, task_id: str, changes: list[dict[str, Any]]) -> dict[str, Any]:
        clean = []
        for item in list(changes or [])[:500]:
            if not isinstance(item, dict):
                continue
            clean.append({
                "path": str(item.get("path") or "")[:500],
                "status": str(item.get("status") or "modified")[:30],
                "added": int(item.get("added") or 0),
                "removed": int(item.get("removed") or 0),
            })
        return self.update(task_id, changes=clean)

    def queue_message(self, task_id: str, text: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        messages.append({"id": uuid.uuid4().hex[:12],
                         "text": redact_sensitive(text, limit=4000),
                         "status": "queued", "at": time.time()})
        return self.update(task_id, messages=messages[-100:])

    def edit_message(self, task_id: str, message_id: str, text: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["text"] = redact_sensitive(text, limit=4000)
                item["status"] = "queued"
                item["edited_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def mark_message(self, task_id: str, message_id: str, status: str,
                     *, detail: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["status"] = str(status or "failed")[:30]
                if detail:
                    item["detail"] = redact_sensitive(detail, limit=1000)
                item["delivered_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def cancel_message(self, task_id: str, message_id: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["status"] = "cancelled"
                item["cancelled_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def reorder_messages(self, task_id: str, message_ids: list[str]) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        by_id = {str(item.get("id")): item for item in messages}
        ordered = [by_id.pop(str(mid)) for mid in message_ids if str(mid) in by_id]
        ordered.extend(item for item in messages if str(item.get("id")) in by_id)
        for idx, item in enumerate(ordered):
            item["position"] = idx
        return self.update(task_id, messages=ordered)

    def retention(self) -> dict[str, int]:
        with self._lock:
            return _merge_retention(self._load().get("retention"))

    def set_retention(self, **policy: Any) -> dict[str, int]:
        clean = _merge_retention({**self.retention(), **policy})
        with self._lock:
            data = self._load()
            data["retention"] = clean
            _next_revision(data)
            self._save(data)
        return clean

    def prune(self) -> dict[str, int]:
        with self._lock:
            data = self._load()
            before = len(data["tasks"])
            _prune_data(data)
            if len(data["tasks"]) != before:
                _next_revision(data)
                self._save(data)
            return {"removed": max(0, before - len(data["tasks"])),
                    "remaining": len(data["tasks"])}


_SYNC_LOCK = threading.Lock()
_LAST_SYNC = 0.0


def _turn_status(status: str) -> str:
    return {
        "inProgress": "running",
        "completed": "succeeded",
        "failed": "failed",
        "interrupted": "cancelled",
    }.get(str(status or ""), "queued")


def _turn_changes(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") != "fileChange":
            continue
        for change in item.get("changes") or []:
            if not isinstance(change, dict):
                continue
            out.append({
                "path": str(change.get("path") or change.get("file") or "")[:500],
                "status": str(change.get("kind") or change.get("status") or "modified")[:30],
            })
    return out


def _turn_tools(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("type") or "")
        if kind == "commandExecution":
            command = redact_sensitive(str(item.get("command") or ""), limit=500)
            output = redact_sensitive(
                str(item.get("aggregatedOutput") or ""),
                limit=DEFAULT_RETENTION["max_tool_output_chars"],
            )
            out.append({
                "name": "shell",
                "status": str(item.get("status") or "")[:30],
                "detail": command,
                "exit_code": item.get("exitCode"),
                "duration_ms": item.get("durationMs"),
                "output": output,
                "item_id": str(item.get("id") or ""),
                "at": float(item.get("completedAtMs") or 0) / 1000.0,
            })
        elif kind in {"collabAgentToolCall", "subAgentActivity"}:
            out.append({
                "name": kind,
                "status": str(item.get("status") or item.get("kind") or "")[:30],
                "detail": str(item.get("tool") or item.get("agentPath") or "")[:500],
                "item_id": str(item.get("id") or ""),
                "at": float(item.get("completedAtMs") or 0) / 1000.0,
            })
    return out[-100:]


def _turn_tests(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for tool in tools:
        command = str(tool.get("detail") or "")
        lowered = command.lower()
        if not any(word in lowered for word in (
                "test", "pytest", "unittest", "check_page", "selftest")):
            continue
        exit_code = tool.get("exit_code")
        ok = (str(tool.get("status") or "") in {"completed", "succeeded"}
              and (exit_code is None or int(exit_code) == 0))
        output = str(tool.get("output") or "")
        out.append({
            "name": command.splitlines()[0][:160] or "测试",
            "ok": bool(ok),
            "exit_code": exit_code,
            "detail": redact_sensitive(output[-1200:] if output else "", limit=1600),
            "at": tool.get("at") or time.time(),
        })
    return out[-30:]


def _approval_expired(task: dict[str, Any]) -> bool:
    approval = task.get("approval") or {}
    if approval.get("decision") != "pending" or not approval.get("live"):
        return False
    request_id = approval.get("request_id")
    if request_id is None:
        return False
    try:
        import codex_threads

        return not codex_threads.server_request_pending(request_id)
    except Exception:
        return False


def sync_recent_threads(store: TaskStore | None = None, *,
                        max_threads: int = 10, max_turns: int = 6,
                        force: bool = False) -> int:
    """Merge recent Codex turns into the task store without writing Codex state."""
    global _LAST_SYNC
    now = time.time()
    if not force and now - _LAST_SYNC < 12:
        return 0
    if not _SYNC_LOCK.acquire(blocking=False):
        return 0
    try:
        if not force and time.time() - _LAST_SYNC < 12:
            return 0
        import codex_threads

        store = store or TaskStore()
        changed = 0
        for row in codex_threads.list_threads()[:max_threads]:
            thread_id = str(row.get("id") or "")
            if not thread_id or row.get("archived"):
                continue
            try:
                data = codex_threads._rpc("thread/read", {
                    "threadId": thread_id,
                    "includeTurns": True,
                }, timeout=10)
            except Exception:
                continue
            thread = data.get("thread") or {}
            turns = list(thread.get("turns") or [])[-max_turns:]
            for turn in turns:
                source_id = str(turn.get("id") or "")
                if not source_id:
                    continue
                existing = store.find_by_source("codex_turn", source_id)
                task = existing or store.create(
                    str(thread.get("name") or thread.get("preview") or thread_id),
                    thread_id=thread_id,
                    detail="Codex 实时任务",
                )
                items = [x for x in (turn.get("items") or []) if isinstance(x, dict)]
                error = turn.get("error") or ""
                status = _turn_status(str(turn.get("status") or ""))
                tools = _turn_tools(items)
                tests = _turn_tests(tools)
                changes = _turn_changes(items)
                diff = redact_sensitive(
                    str(turn.get("diff") or task.get("diff") or ""),
                    limit=store.retention()["max_diff_chars"],
                )
                title = str(thread.get("name") or task.get("title") or thread_id)
                detail_bits = [
                    "Codex 实时任务",
                    f"{len(tools)} 次工具",
                    f"{sum(1 for x in tests if x.get('ok'))}/{len(tests)} 测试通过"
                    if tests else "暂无测试",
                ]
                if diff:
                    detail_bits.append(f"{len(changes)} 个文件变化")
                update = {
                    "source": "codex_turn",
                    "source_id": source_id,
                    "title": title,
                    "thread_id": thread_id,
                    "detail": " · ".join(detail_bits),
                    "status": status,
                    "error": redact_sensitive(str(error), limit=1000),
                    "tool_calls": tools,
                    "changes": changes,
                    "tests": tests,
                    "diff": diff,
                    "active_turn_id": source_id if status in {
                        "running", "waiting_approval"
                    } else "",
                }
                approval = task.get("approval") or {}
                if (status not in {"running", "waiting_approval"}
                        and approval.get("decision") == "pending"):
                    approval = dict(approval)
                    approval["decision"] = "expired"
                    approval["expired_at"] = time.time()
                    update["approval"] = approval
                elif _approval_expired(task):
                    approval = dict(approval)
                    approval["decision"] = "expired"
                    approval["expired_at"] = time.time()
                    update["approval"] = approval
                    if status == "waiting_approval":
                        update["status"] = "running"
                if any(task.get(key) != value for key, value in update.items()):
                    store.update(task["id"], **update)
                    changed += 1
        _LAST_SYNC = time.time()
        return changed
    finally:
        _SYNC_LOCK.release()

