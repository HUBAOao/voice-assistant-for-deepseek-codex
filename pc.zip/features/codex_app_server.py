# -*- coding: utf-8 -*-
"""Persistent JSON-lines client for Codex's local app-server protocol."""
from __future__ import annotations

import atexit
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable


_RPC_LOCK = threading.RLock()
_RPC: _AppServerClient | None = None
_SERVER_REQUEST_HANDLER: Callable[[dict], None] | None = None


def _find_codex_exe() -> str:
    configured = os.environ.get("CODEX_EXE", "").strip()
    candidates: list[Path] = [Path(configured)] if configured else []
    found = shutil.which("codex")
    if found:
        candidates.append(Path(found))
    local = Path.home() / "AppData" / "Local" / "OpenAI" / "Codex" / "bin"
    try:
        candidates.extend(
            sorted(
                local.glob("*/codex.exe"),
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
        )
    except Exception:
        pass
    for path in candidates:
        try:
            if path.is_file():
                return str(path)
        except Exception:
            pass
    return ""


find_codex_exe = _find_codex_exe


class _AppServerClient:
    """Exchange requests, notifications, and server approval prompts."""

    def __init__(self, exe: str) -> None:
        self.exe = exe
        self.proc: subprocess.Popen | None = None
        self.reader: threading.Thread | None = None
        self.seq = 0
        self.user_agent = ""
        self._condition = threading.Condition(threading.RLock())
        self._responses: dict[Any, dict] = {}
        self._server_requests: dict[Any, dict] = {}
        self._events: deque[dict] = deque(maxlen=2000)
        self._event_seq = 0
        self._closed = False
        self._request_handler: Callable[[dict], None] | None = None
        self.start()

    def start(self) -> None:
        self.stop()
        flags = 0x08000000 if sys.platform == "win32" else 0
        self.proc = subprocess.Popen(
            [self.exe, "app-server", "--stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            creationflags=flags,
        )
        with self._condition:
            self._responses.clear()
            self._server_requests.clear()
            self._events.clear()
            self._event_seq = 0
            self._closed = False
            self._condition.notify_all()

        def read_stdout() -> None:
            assert self.proc is not None and self.proc.stdout is not None
            try:
                for line in self.proc.stdout:
                    try:
                        message = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(message, dict):
                        continue
                    if message.get("id") is not None and message.get("method"):
                        with self._condition:
                            self._server_requests[message["id"]] = message
                            self._condition.notify_all()
                        handler = self._request_handler
                        if handler is not None:

                            def dispatch(item: dict = message) -> None:
                                try:
                                    handler(item)
                                except Exception:
                                    pass

                            threading.Thread(target=dispatch, daemon=True).start()
                    elif message.get("id") is not None and (
                        "result" in message or "error" in message
                    ):
                        with self._condition:
                            self._responses[message["id"]] = message
                            self._condition.notify_all()
                    elif message.get("method"):
                        with self._condition:
                            self._event_seq += 1
                            message["__seq__"] = self._event_seq
                            message["__received_at__"] = time.time()
                            self._events.append(message)
                            self._condition.notify_all()
            finally:
                with self._condition:
                    self._closed = True
                    self._condition.notify_all()

        self.reader = threading.Thread(target=read_stdout, daemon=True)
        self.reader.start()
        self.seq += 1
        result = self._exchange(
            "initialize",
            {
                "clientInfo": {
                    "name": "voice-assistant",
                    "title": "Voice Assistant",
                    "version": "1.0",
                },
                "capabilities": {"experimentalApi": True},
            },
            request_id=self.seq,
            timeout=12.0,
        )
        if not isinstance(result, dict) or "userAgent" not in result:
            raise RuntimeError("Codex app-server initialize failed")
        self.user_agent = str(result.get("userAgent") or "")
        self._send({"method": "initialized"})

    def stop(self) -> None:
        proc = self.proc
        self.proc = None
        with self._condition:
            self._closed = True
            self._condition.notify_all()
        if proc is None:
            return
        try:
            if proc.stdin:
                proc.stdin.close()
        except Exception:
            pass
        try:
            proc.terminate()
            proc.wait(timeout=2.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def alive(self) -> bool:
        return bool(self.proc is not None and self.proc.poll() is None)

    def _send(self, message: dict) -> None:
        if not self.proc or not self.proc.stdin or not self.alive():
            raise RuntimeError("Codex app-server is not running")
        self.proc.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()

    def _exchange(
        self,
        method: str,
        params: dict | None = None,
        request_id: int | None = None,
        timeout: float = 15.0,
    ) -> Any:
        rid = self.seq if request_id is None else request_id
        self._send({"id": rid, "method": method, "params": params or {}})
        deadline = time.monotonic() + timeout
        with self._condition:
            while True:
                message = self._responses.pop(rid, None)
                if message is not None:
                    break
                left = deadline - time.monotonic()
                if left <= 0:
                    self._responses.pop(rid, None)
                    raise TimeoutError("%s timed out" % method)
                if self._closed or not self.alive():
                    self._responses.pop(rid, None)
                    raise RuntimeError("Codex app-server exited")
                self._condition.wait(min(left, 0.5))
            if message.get("id") == rid:
                if "error" in message:
                    error = message.get("error")
                    if isinstance(error, dict):
                        raise RuntimeError(str(error.get("message") or error))
                    raise RuntimeError(str(error))
                return message.get("result")
        raise RuntimeError("%s returned an invalid response" % method)

    def call(
        self,
        method: str,
        params: dict | None = None,
        timeout: float = 15.0,
    ) -> Any:
        self.seq += 1
        return self._exchange(method, params, request_id=self.seq, timeout=timeout)

    def set_server_request_handler(
        self,
        handler: Callable[[dict], None] | None,
    ) -> None:
        self._request_handler = handler

    def respond(
        self,
        request_id: Any,
        *,
        result: Any = None,
        error: dict | None = None,
    ) -> None:
        with self._condition:
            request = self._server_requests.pop(request_id, None)
            if request is None:
                raise KeyError("Codex 请求已处理或已失效")
        message: dict[str, Any] = {"id": request_id}
        if error is not None:
            message["error"] = error
        else:
            message["result"] = result if result is not None else {}
        try:
            self._send(message)
        except Exception:
            with self._condition:
                self._server_requests[request_id] = request
                self._condition.notify_all()
            raise

    def has_server_request(self, request_id: Any) -> bool:
        with self._condition:
            return request_id in self._server_requests

    def server_request(self, request_id: Any) -> dict | None:
        with self._condition:
            item = self._server_requests.get(request_id)
            return dict(item) if item is not None else None

    def events_after(
        self,
        sequence: int = 0,
        timeout: float = 0.0,
    ) -> tuple[int, list[dict]]:
        deadline = time.monotonic() + max(0.0, timeout)
        with self._condition:
            while not any(
                int(item.get("__seq__") or 0) > int(sequence)
                for item in self._events
            ):
                left = deadline - time.monotonic()
                if left <= 0 or self._closed:
                    break
                self._condition.wait(min(left, 0.5))
            items = [
                dict(item)
                for item in self._events
                if int(item.get("__seq__") or 0) > int(sequence)
            ]
            return self._event_seq, items

    @property
    def event_cursor(self) -> int:
        with self._condition:
            return self._event_seq


def _client() -> _AppServerClient:
    global _RPC
    exe = _find_codex_exe()
    if not exe:
        raise RuntimeError("没找到 Codex 命令行程序")
    with _RPC_LOCK:
        if _RPC is None or not _RPC.alive():
            _RPC = _AppServerClient(exe)
            _RPC.set_server_request_handler(_SERVER_REQUEST_HANDLER)
        return _RPC


def _rpc(method: str, params: dict | None = None, timeout: float = 15.0) -> Any:
    global _RPC
    with _RPC_LOCK:
        for attempt in range(2):
            try:
                return _client().call(method, params, timeout=timeout)
            except Exception:
                if _RPC is not None:
                    _RPC.stop()
                _RPC = None
                if attempt:
                    raise
    raise RuntimeError("Codex app-server unavailable")


def _rpc_once(
    method: str,
    params: dict | None = None,
    timeout: float = 15.0,
) -> Any:
    with _RPC_LOCK:
        return _client().call(method, params, timeout=timeout)


def _close_rpc() -> None:
    global _RPC
    with _RPC_LOCK:
        if _RPC is not None:
            _RPC.stop()
            _RPC = None


atexit.register(_close_rpc)


def set_server_request_handler(
    handler: Callable[[dict], None] | None,
) -> None:
    global _SERVER_REQUEST_HANDLER
    with _RPC_LOCK:
        _SERVER_REQUEST_HANDLER = handler
        if _RPC is not None:
            _RPC.set_server_request_handler(handler)


def respond_server_request(request_id: Any, result: Any) -> None:
    with _RPC_LOCK:
        _client().respond(request_id, result=result)


def server_request_pending(request_id: Any) -> bool:
    with _RPC_LOCK:
        return bool(
            _RPC is not None
            and _RPC.alive()
            and _RPC.has_server_request(request_id)
        )


def poll_events(sequence: int = 0, timeout: float = 0.0) -> tuple[int, list[dict]]:
    with _RPC_LOCK:
        client = _client()
    return client.events_after(sequence, timeout=timeout)


def probe_app_server() -> dict[str, str]:
    exe = _find_codex_exe()
    if not exe:
        raise RuntimeError("没找到 Codex 命令行程序")
    client = _AppServerClient(exe)
    try:
        result = client.call(
            "thread/list",
            {
                "limit": 1,
                "useStateDbOnly": True,
                "sortKey": "recency_at",
                "sortDirection": "desc",
            },
            timeout=8.0,
        )
        if not isinstance(result, dict) or "data" not in result:
            raise RuntimeError("Codex app-server thread/list 返回格式不兼容")
        return {"exe": exe, "userAgent": client.user_agent}
    finally:
        client.stop()
