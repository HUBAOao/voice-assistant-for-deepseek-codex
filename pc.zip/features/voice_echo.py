# -*- coding: utf-8 -*-
"""Reference-aware acoustic echo cancellation for the real TTS playback path."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

import numpy as np

from features.voice_providers import AdaptiveEchoCanceller

HERE = Path(__file__).resolve().parent.parent
DEFAULT_REFERENCE = HERE / "speak_reference.npy"
DEFAULT_META = HERE / "speak_reference.json"
MAX_ECHO_DELAY_SECONDS = 0.5
MAX_ECHO_LEAD_SECONDS = 0.1
MIN_ALIGNMENT = 0.22


def _load_numpy(path: Path) -> np.ndarray | None:
    try:
        with path.open("rb") as handle:
            value = np.load(handle, allow_pickle=False)
        return np.asarray(value, dtype=np.float32).reshape(-1)
    except Exception:
        return None


def _resample(audio: np.ndarray, source_rate: int, target_rate: int) -> np.ndarray:
    if source_rate == target_rate or audio.size == 0:
        return np.asarray(audio, dtype=np.float32)
    size = max(1, int(round(audio.size * target_rate / source_rate)))
    return np.interp(
        np.linspace(0, audio.size - 1, size),
        np.arange(audio.size),
        audio,
    ).astype(np.float32)


def _best_aligned_reference(
    microphone: np.ndarray,
    reference: np.ndarray,
    offset: int,
    sample_rate: int,
) -> tuple[np.ndarray, float, int] | None:
    """Find the delayed playback block that best matches the microphone."""
    size = microphone.size
    start = max(0, offset - int(MAX_ECHO_DELAY_SECONDS * sample_rate))
    end = min(
        reference.size,
        offset + size + int(MAX_ECHO_LEAD_SECONDS * sample_rate),
    )
    region = np.asarray(reference[start:end], dtype=np.float64)
    if region.size < size:
        return None

    nfft = 1
    while nfft < region.size + size - 1:
        nfft <<= 1
    microphone64 = np.asarray(microphone, dtype=np.float64)
    correlation = np.fft.irfft(
        np.fft.rfft(region, nfft)
        * np.conj(np.fft.rfft(microphone64, nfft)),
        nfft,
    )[: region.size - size + 1]
    squared = np.square(region)
    cumulative = np.empty(region.size + 1, dtype=np.float64)
    cumulative[0] = 0.0
    np.cumsum(squared, out=cumulative[1:])
    energy = cumulative[size:] - cumulative[:-size]
    denominator = np.sqrt(
        np.maximum(energy, 0.0) * float(np.dot(microphone64, microphone64))
    ) + 1e-12
    scores = correlation / denominator
    index = int(np.argmax(np.abs(scores)))
    peak = abs(float(scores[index]))
    if not np.isfinite(peak) or peak < MIN_ALIGNMENT:
        return None

    aligned_start = start + index
    block = reference[aligned_start : aligned_start + size]
    if block.size < size:
        block = np.pad(block, (0, size - block.size))
    return np.asarray(block, dtype=np.float32), peak, aligned_start - offset


class ReferenceEchoGate:
    """Use the exact waveform sent to the speaker to remove captured echo."""

    def __init__(self, reference: Path = DEFAULT_REFERENCE,
                 metadata: Path = DEFAULT_META) -> None:
        self.reference = Path(reference)
        self.metadata = Path(metadata)
        self._lock = threading.RLock()
        self._mtime = -1.0
        self._audio = np.empty(0, dtype=np.float32)
        self._cancel = AdaptiveEchoCanceller(taps=64)
        self.last_ratio = 1.0
        self.last_used = False
        self.last_correlation = 0.0
        self.last_delay_samples = 0

    def echo_dominates(self) -> bool:
        """Whether the last block is confidently a residual of playback."""
        return bool(
            self.last_used
            and self.last_correlation >= 0.55
            and self.last_ratio <= 0.72
        )

    def _load(self) -> tuple[dict, np.ndarray] | None:
        if os.environ.get("FIN_DECK_REFERENCE_ECHO", "1") in {"0", "false", "off"}:
            return None
        try:
            meta = json.loads(self.metadata.read_text(encoding="utf-8"))
            mtime = self.reference.stat().st_mtime
        except Exception:
            return None
        with self._lock:
            if mtime != self._mtime:
                audio = _load_numpy(self.reference)
                if audio is None or not audio.size:
                    return None
                self._audio = audio
                self._mtime = mtime
            audio = self._audio
        return dict(meta), audio

    def process(self, microphone: np.ndarray, sample_rate: int,
                *, maximum_age: float = 4.0) -> np.ndarray:
        mic = np.asarray(microphone, dtype=np.float32).reshape(-1)
        self.last_used = False
        self.last_ratio = 1.0
        self.last_correlation = 0.0
        self.last_delay_samples = 0
        if mic.size == 0:
            return mic
        loaded = self._load()
        if loaded is None:
            return mic
        meta, reference = loaded
        if not meta.get("active"):
            return mic
        try:
            age = max(0.0, time.time() - float(meta.get("ts") or 0))
            if age > maximum_age:
                return mic
            reference_rate = int(meta.get("rate") or 0)
            if reference_rate <= 0:
                return mic
            ref = _resample(reference, reference_rate, int(sample_rate))
            offset = int(meta.get("offset") or 0)
            offset = int(round(offset * sample_rate / reference_rate))
            if offset < 0 or offset >= ref.size:
                return mic
            aligned = _best_aligned_reference(
                mic,
                ref,
                offset,
                int(sample_rate),
            )
            if aligned is None:
                return mic
            block, self.last_correlation, self.last_delay_samples = aligned
        except Exception:
            return mic
        raw_rms = float(np.sqrt(np.mean(mic ** 2) + 1e-12))
        ref_rms = float(np.sqrt(np.mean(block ** 2) + 1e-12))
        if raw_rms < 0.002 or ref_rms < 0.001:
            return mic
        try:
            clean = self._cancel.cancel(mic, block)
        except Exception:
            return mic
        clean_rms = float(np.sqrt(np.mean(clean ** 2) + 1e-12))
        self.last_ratio = clean_rms / max(raw_rms, 1e-12)
        self.last_used = True
        return clean if clean_rms < raw_rms * 0.92 else mic


GATE = ReferenceEchoGate()


def cancel(microphone: np.ndarray, sample_rate: int) -> np.ndarray:
    return GATE.process(microphone, sample_rate)

