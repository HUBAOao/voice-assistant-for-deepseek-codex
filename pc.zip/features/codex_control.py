# -*- coding: utf-8 -*-
"""Live Codex control bridge for approvals, diffs, steering, and recovery."""
from __future__ import annotations

import copy
import threading
import time
from pathlib import Path
from typing import Any

from features import tasks
from features.tasks import (
    TaskStore,
    _turn_changes,
    _turn_status,
    _turn_tests,
    _turn_tools,
    classify_risk,
    redact_sensitive,
)

APPROVAL_METHODS = {
    "item/commandExecution/requestApproval",
    "item/fileChange/requestApproval",
    "execCommandApproval",
    "applyPatchApproval",
}


def _available_decisions(params: dict[str, Any]) -> list[str]:
    values = []
    for item in params.get("availableDecisions") or []:
        if isinstance(item, str):
            values.append(item)
        elif isinstance(item, dict):
            values.extend(str(key) for key in item)
    return list(dict.fromkeys(values))


def _response_for(method: str, approved: bool, note: str = "") -> dict[str, Any]:
    if method == "execCommandApproval":
        return {"decision": "approved" if approved else {
            "denied": {"rejection": str(note or "用户拒绝")[:500]}
        }}
    if method == "applyPatchApproval":
        return {"decision": "approved" if approved else {
            "denied": {"rejection": str(note or "用户拒绝")[:500]}
        }}
    if method in {
            "item/commandExecution/requestApproval",
            "item/fileChange/requestApproval"}:
        return {"decision": "accept" if approved else "decline"}
    raise ValueError("不支持的 Codex 批准请求：%s" % method)


class CodexControl:
    """Own the app-server event subscription and bridge it into TaskStore."""

    def __init__(self, store: TaskStore | None = None) -> None:
        self.store = store or TaskStore()
        self._lock = threading.RLock()
        self._started = False
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._cursor = 0
        self.connected = False
        self.last_error = ""
        self.last_event_at = 0.0
        self.reconnects = 0
        self._locally_resolved: dict[Any, float] = {}

    def start(self) -> None:
        with self._lock:
            if self._started:
                return
            self._started = True
            import codex_threads

            codex_threads.set_server_request_handler(self._server_request)
            self._thread = threading.Thread(target=self._event_loop,
                                            name="findeck-codex-events",
                                            daemon=True)
            self._thread.start()

    def close(self) -> None:
        self._stop.set()

    def _server_request(self, message: dict[str, Any]) -> None:
        method = str(message.get("method") or "")
        if method not in APPROVAL_METHODS:
            return
        params = copy.deepcopy(message.get("params") or {})
        thread_id = str(params.get("threadId") or params.get("conversationId") or "")
        turn_id = str(params.get("turnId") or params.get("callId") or "")
        item_id = str(params.get("itemId") or params.get("callId") or "")
        request_id = message.get("id")
        command = params.get("command") or ""
        if isinstance(command, list):
            command = " ".join(str(part) for part in command)
        target = str(params.get("grantRoot") or params.get("cwd") or item_id)
        reason = str(params.get("reason") or "")
        if method == "applyPatchApproval":
            changes = params.get("fileChanges") or {}
            target = ", ".join(list(changes)[:8]) or target
        task = self.store.find_by_source("codex_turn", turn_id) if turn_id else None
        if task is None:
            title = "Codex 待批准操作"
            try:
                import codex_threads

                data = codex_threads._rpc_once(
                    "thread/read",
                    {"threadId": thread_id, "includeTurns": False},
                    timeout=8,
                )
                thread = data.get("thread") or {}
                title = str(thread.get("name") or thread.get("preview") or title)
            except Exception:
                pass
            task = self.store.create(title, thread_id=thread_id,
                                     detail="真实 Codex 待批准请求")
        existing = task.get("approval") or {}
        if (existing.get("request_id") == request_id
                and existing.get("decision") == "pending"):
            return
        self.store.request_approval(
            task["id"],
            str(command) or reason or "文件修改请求",
            target=target,
            risk=classify_risk(str(command) or target),
            request_id=request_id,
            method=method,
            item_id=item_id,
            thread_id=thread_id,
            turn_id=turn_id,
            reason=reason,
            available_decisions=_available_decisions(params),
            live=True,
        )
        self.store.update(
            task["id"],
            source="codex_turn",
            source_id=turn_id,
            active_turn_id=turn_id,
        )

    def resolve(self, task_id: str, approved: bool, note: str = "") -> dict[str, Any]:
        task = self.store.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        approval = task.get("approval") or {}
        if approval.get("decision") != "pending":
            raise ValueError("没有待批准请求")
        method = str(approval.get("method") or "")
        request_id = approval.get("request_id")
        import codex_threads

        if not codex_threads.server_request_pending(request_id):
            expired = dict(approval)
            expired.update({
                "decision": "expired",
                "expired_at": time.time(),
                "response_sent": False,
            })
            self.store.update(task_id, approval=expired,
                              status="running" if task.get("active_turn_id") else "failed")
            raise RuntimeError("这条 Codex 批准请求已失效，已从队列移除")
        response = _response_for(method, approved, note)
        with self._lock:
            self._locally_resolved[request_id] = time.time()
        try:
            codex_threads.respond_server_request(request_id, response)
        except Exception:
            with self._lock:
                self._locally_resolved.pop(request_id, None)
            raise
        return self.store.decide(
            task_id,
            approved,
            note,
            decision="approved" if approved else "rejected",
            response_sent=True,
        )

    def inject_message(self, task_id: str, text: str) -> dict[str, Any]:
        task = self.store.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        turn_id = str(task.get("active_turn_id") or task.get("source_id") or "")
        thread_id = str(task.get("thread_id") or "")
        if not turn_id or not thread_id:
            return self.store.queue_message(task_id, text)
        queued = self.store.queue_message(task_id, text)
        message_id = str((queued.get("messages") or [{}])[-1].get("id") or "")
        self.store.mark_message(task_id, message_id, "sending")
        import codex_threads

        try:
            result = codex_threads._rpc_once(
                "turn/steer",
                {
                    "threadId": thread_id,
                    "expectedTurnId": turn_id,
                    "input": [{"type": "text",
                               "text": redact_sensitive(text, limit=4000)}],
                },
                timeout=20,
            )
            return self.store.mark_message(
                task_id, message_id, "sent",
                detail=str(result or "已注入当前回合")[:500],
            )
        except Exception as exc:
            self.store.mark_message(task_id, message_id, "failed",
                                    detail="%s: %s" % (type(exc).__name__, exc))
            raise

    def cancel(self, task_id: str) -> dict[str, Any]:
        task = self.store.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        thread_id = str(task.get("thread_id") or "")
        turn_id = str(task.get("active_turn_id") or task.get("source_id") or "")
        if thread_id and turn_id:
            import codex_threads

            try:
                codex_threads._rpc_once(
                    "turn/interrupt",
                    {"threadId": thread_id, "turnId": turn_id},
                    timeout=15,
                )
            except Exception as exc:
                if "not found" not in str(exc).lower() and "active turn" not in str(exc).lower():
                    raise
        return self.store.update(task_id, status="cancelled")

    def start_turn(self, thread_id: str, text: str, *,
                   cwd: str = "", sandbox: str = "workspace-write",
                   approval_policy: str = "on-request") -> dict[str, Any]:
        import codex_threads

        params: dict[str, Any] = {
            "threadId": str(thread_id),
            "input": [{"type": "text",
                       "text": redact_sensitive(text, limit=4000)}],
            "approvalPolicy": str(approval_policy),
        }
        if cwd:
            params["cwd"] = str(Path(cwd).resolve())
        params["sandboxPolicy"] = {
            "type": {
                "read-only": "readOnly",
                "workspace-write": "workspaceWrite",
                "danger-full-access": "dangerFullAccess",
            }.get(str(sandbox), "workspaceWrite")
        }
        result = codex_threads._rpc_once("turn/start", params, timeout=30)
        turn = result.get("turn") if isinstance(result, dict) else {}
        turn = turn if isinstance(turn, dict) else {}
        task = self.store.create(
            str(text).strip().splitlines()[0][:80] or "Codex 任务",
            thread_id=str(thread_id),
            detail="鳍舱启动的 Codex 回合",
        )
        return self.store.update(
            task["id"],
            source="codex_turn",
            source_id=str(turn.get("id") or ""),
            active_turn_id=str(turn.get("id") or ""),
            status=_turn_status(str(turn.get("status") or "inProgress")),
        )

    def _apply_turn(self, thread_id: str, turn: dict[str, Any]) -> None:
        turn_id = str(turn.get("id") or "")
        if not turn_id:
            return
        task = self.store.find_by_source("codex_turn", turn_id)
        if task is None:
            task = self.store.create(
                "Codex 实时任务", thread_id=thread_id, detail="Codex 实时任务"
            )
            self.store.update(task["id"], source="codex_turn", source_id=turn_id)
        items = [x for x in (turn.get("items") or []) if isinstance(x, dict)]
        tools = _turn_tools(items)
        changes = _turn_changes(items)
        status = _turn_status(str(turn.get("status") or ""))
        fields: dict[str, Any] = {
            "thread_id": thread_id,
            "status": status,
            "active_turn_id": turn_id if status in {
                "running", "waiting_approval"
            } else "",
            "tool_calls": tools,
            "changes": changes,
            "tests": _turn_tests(tools),
        }
        if status in {"succeeded", "failed", "cancelled"}:
            fields["error"] = redact_sensitive(str(turn.get("error") or ""),
                                                limit=1000)
        if any(task.get(key) != value for key, value in fields.items()):
            self.store.update(task["id"], **fields)

    def _event_loop(self) -> None:
        import codex_threads

        while not self._stop.is_set():
            try:
                if self._cursor == 0:
                    self._cursor = codex_threads._client().event_cursor
                cursor, events = codex_threads.poll_events(self._cursor, timeout=0.8)
                self.connected = True
                self.last_error = ""
                self._cursor = cursor
                for event in events:
                    self.last_event_at = time.time()
                    self._handle_event(event)
            except Exception as exc:
                self.connected = False
                self.last_error = "%s: %s" % (type(exc).__name__, exc)
                time.sleep(1.2)

    def _handle_event(self, event: dict[str, Any]) -> None:
        method = str(event.get("method") or "")
        params = event.get("params") or {}
        if not isinstance(params, dict):
            return
        thread_id = str(params.get("threadId") or "")
        turn = params.get("turn") or {}
        if method in {"turn/started", "turn/completed"} and isinstance(turn, dict):
            self._apply_turn(thread_id, turn)
            if method == "turn/completed":
                try:
                    tasks.sync_recent_threads(self.store, max_threads=3,
                                              max_turns=2, force=True)
                except Exception:
                    pass
            return
        turn_id = str(params.get("turnId") or "")
        task = self.store.find_by_source("codex_turn", turn_id) if turn_id else None
        if method == "turn/diff/updated" and task:
            diff = redact_sensitive(
                str(params.get("diff") or ""),
                limit=self.store.retention()["max_diff_chars"],
            )
            if task.get("diff") != diff:
                self.store.update(task["id"], diff=diff)
            return
        if method in {"item/started", "item/completed"} and task:
            item = params.get("item") or {}
            if not isinstance(item, dict):
                return
            fresh = _turn_tools([item])
            if fresh:
                calls = list(task.get("tool_calls") or [])
                by_id = {str(call.get("item_id") or ""): idx
                         for idx, call in enumerate(calls) if call.get("item_id")}
                for call in fresh:
                    item_id = str(call.get("item_id") or "")
                    if item_id and item_id in by_id:
                        calls[by_id[item_id]] = call
                    else:
                        calls.append(call)
                tests = _turn_tests(calls)
                self.store.update(task["id"], tool_calls=calls[-100:],
                                  tests=tests)
            changes = _turn_changes([item])
            if changes:
                self.store.update(task["id"], changes=changes)
            return
        if method == "serverRequest/resolved":
            request_id = params.get("requestId")
            with self._lock:
                resolved_at = self._locally_resolved.get(request_id, 0.0)
                if time.time() - resolved_at < 30:
                    return
            for row in self.store.list(limit=200):
                approval = row.get("approval") or {}
                if (approval.get("decision") == "pending"
                        and approval.get("request_id") == request_id):
                    approval = dict(approval)
                    approval["decision"] = "resolved_external"
                    approval["resolved_at"] = time.time()
                    self.store.update(row["id"], approval=approval)
                    break

    def health(self) -> dict[str, Any]:
        return {
            "connected": bool(self.connected),
            "cursor": int(self._cursor),
            "last_error": self.last_error,
            "last_event_at": self.last_event_at,
            "reconnects": self.reconnects,
        }

    def reconnect(self) -> dict[str, Any]:
        import codex_threads

        self.reconnects += 1
        codex_threads._close_rpc()
        self._cursor = 0
        changed = tasks.sync_recent_threads(
            self.store, max_threads=10, max_turns=6, force=True
        )
        return {**self.health(), "synced": changed}


_CONTROL_LOCK = threading.RLock()
_CONTROL: CodexControl | None = None


def control(store: TaskStore | None = None) -> CodexControl:
    global _CONTROL
    with _CONTROL_LOCK:
        if _CONTROL is None:
            _CONTROL = CodexControl(store)
            _CONTROL.start()
        elif store is not None and _CONTROL.store.path != store.path:
            raise RuntimeError("Codex 控制桥已绑定到另一份任务存储")
        return _CONTROL

