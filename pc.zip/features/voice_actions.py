# -*- coding: utf-8 -*-
"""Structured voice actions, kept separate from ordinary chat text."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class VoiceAction:
    kind: str
    text: str = ""
    target: str = ""
    risk: str = "low"
    requires_approval: bool = False


_APPROVE = re.compile(r"^(?:批准|同意|允许|确认执行|可以执行)(?:这个|当前|操作|任务)*[。！!]?$")
_REJECT = re.compile(r"^(?:拒绝|不同意|不允许|别执行|不要执行)(?:这个|当前|操作|任务)*[。！!]?$")
_CANCEL = re.compile(r"^(?:取消|停止)(?:当前|这个|正在运行的)*任务[。！!]?$")
_STATUS = re.compile(r"^(?:任务状态|看看任务|看一下任务|现在跑到哪|任务进度|当前任务)[。？?]?$")
_NEW_THREAD = re.compile(r"^(?:新建|新开)(?:一个)?(?:对话|会话|任务)[。！!]?$")
_SWITCH = re.compile(
    r"^(?:切换到|切到|回到|换到)(?:会话|对话|任务)?\s*(.+?)[。！!]?$"
)
_SEND_IN = re.compile(
    r"^(?:在当前会话|当前任务)(?:里)?(?:说|发送)[：:,， ]*(.+)$"
)


def parse_voice_action(text: str) -> VoiceAction:
    """Parse explicit action language; ordinary conversation stays unknown."""
    raw = str(text or "").strip()
    plain = re.sub(r"\s+", "", raw)
    if not plain:
        return VoiceAction("unknown")
    if _APPROVE.match(plain):
        return VoiceAction("approve", risk="high", requires_approval=True)
    if _REJECT.match(plain):
        return VoiceAction("reject", risk="high", requires_approval=True)
    if _CANCEL.match(plain):
        return VoiceAction("cancel_task", risk="high", requires_approval=True)
    if _STATUS.match(plain):
        return VoiceAction("task_status")
    if _NEW_THREAD.match(plain):
        return VoiceAction("new_thread", risk="medium")
    match = _SWITCH.match(raw)
    if match:
        target = match.group(1).strip("，,。 ")
        if target in {"刚才那个任务", "刚才那个会话", "上一个任务", "上一个会话"}:
            target = "recent"
        if target:
            return VoiceAction("switch_thread", target=target, risk="low")
    match = _SEND_IN.match(raw)
    if match:
        body = match.group(1).strip()
        if body:
            return VoiceAction("send_message", text=body, risk="medium")
    return VoiceAction("unknown")


class VoiceActionRouter:
    """Execute parsed actions through surface-specific callbacks."""

    def __init__(self, handlers: dict[str, Callable[..., Any]]) -> None:
        self.handlers = dict(handlers)

    def execute(self, action: VoiceAction) -> tuple[bool, str]:
        if action.kind == "unknown":
            return False, ""
        handler = self.handlers.get(action.kind)
        if handler is None:
            return False, "这个语音动作还没有接上"
        try:
            result = handler(action)
        except Exception as exc:  # noqa: BLE001
            return False, str(exc)[:200]
        if isinstance(result, tuple) and len(result) == 2:
            return bool(result[0]), str(result[1])
        if isinstance(result, str):
            return True, result
        return bool(result), ""

