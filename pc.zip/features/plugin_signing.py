# -*- coding: utf-8 -*-
"""Portable RSA-SHA256 signing for FinDeck plugin publishers."""
from __future__ import annotations

import base64
import hashlib
import json
import math
import secrets
import time
from pathlib import Path
from typing import Any

SIGNATURE_FILE = ".findeck-signature.json"
INSTALL_SEAL_FILE = ".findeck-install.json"
SIGNATURE_FORMAT = "FINDECK-PLUGIN-SIGNATURE-1"
SIGNATURE_ALGORITHM = "RS256-PKCS1v1.5"
MIN_RSA_BITS = 2048
MAX_RSA_BITS = 4096
_SHA256_DIGEST_INFO = bytes.fromhex("3031300d060960864801650304020105000420")
_SMALL_PRIMES = (
    3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
    61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
)


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(raw: str) -> bytes:
    return base64.urlsafe_b64decode(str(raw) + "=" * (-len(str(raw)) % 4))


def _int_value(value: Any, *, field: str) -> int:
    if isinstance(value, int):
        return value
    try:
        return int.from_bytes(_unb64(str(value)), "big")
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"RSA {field} 无效") from exc


def normalize_public_key(raw: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValueError("发布者公钥必须是 JSON 对象")
    n = _int_value(raw.get("n"), field="n")
    e = _int_value(raw.get("e", 65537), field="e")
    bits = n.bit_length()
    if bits < MIN_RSA_BITS or bits > MAX_RSA_BITS:
        raise ValueError(f"RSA 公钥长度必须为 {MIN_RSA_BITS}-{MAX_RSA_BITS} 位")
    if e < 3 or e > 2**31 or e % 2 == 0:
        raise ValueError("RSA 公钥指数无效")
    value = {
        "kty": "RSA",
        "algorithm": SIGNATURE_ALGORITHM,
        "n": _b64(n.to_bytes((bits + 7) // 8, "big")),
        "e": _b64(e.to_bytes((e.bit_length() + 7) // 8, "big")),
    }
    value["key_id"] = public_key_id(value)
    return value


def public_key_id(public_key: dict[str, Any]) -> str:
    clean = {
        "kty": "RSA",
        "algorithm": SIGNATURE_ALGORITHM,
        "n": str(public_key.get("n") or ""),
        "e": str(public_key.get("e") or ""),
    }
    return "sha256:" + hashlib.sha256(canonical_json(clean)).hexdigest()[:32]


def tree_digest(folder: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(Path(folder).rglob("*"), key=lambda item: item.as_posix()):
        if not path.is_file() or path.name in {INSTALL_SEAL_FILE, SIGNATURE_FILE}:
            continue
        if "__pycache__" in path.parts or path.suffix.lower() == ".pyc":
            continue
        rel = path.relative_to(folder).as_posix().encode("utf-8")
        digest.update(len(rel).to_bytes(4, "big"))
        digest.update(rel)
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
    return digest.hexdigest()


def _encoded_message(data: bytes, size: int) -> bytes:
    digest_info = _SHA256_DIGEST_INFO + hashlib.sha256(data).digest()
    padding = size - len(digest_info) - 3
    if padding < 8:
        raise ValueError("RSA 密钥长度不足以承载 SHA-256 签名")
    return b"\x00\x01" + b"\xff" * padding + b"\x00" + digest_info


def _private_int(private_key: dict[str, Any], field: str) -> int:
    value = private_key.get(field)
    if value is None:
        raise ValueError(f"RSA 私钥缺少 {field}")
    return _int_value(value, field=field)


def sign_bytes(private_key: dict[str, Any], data: bytes) -> str:
    n = _private_int(private_key, "n")
    d = _private_int(private_key, "d")
    size = (n.bit_length() + 7) // 8
    encoded = _encoded_message(data, size)
    signature = pow(int.from_bytes(encoded, "big"), d, n)
    return _b64(signature.to_bytes(size, "big"))


def verify_bytes(public_key: dict[str, Any], data: bytes, signature: str) -> bool:
    try:
        key = normalize_public_key(public_key)
        n = _int_value(key["n"], field="n")
        e = _int_value(key["e"], field="e")
        size = (n.bit_length() + 7) // 8
        raw = _unb64(signature)
        if len(raw) != size:
            return False
        number = int.from_bytes(raw, "big")
        if number >= n:
            return False
        actual = pow(number, e, n).to_bytes(size, "big")
        return secrets.compare_digest(actual, _encoded_message(data, size))
    except Exception:  # noqa: BLE001
        return False


def _probably_prime(number: int, rounds: int = 28) -> bool:
    if number < 2:
        return False
    for prime in _SMALL_PRIMES:
        if number == prime:
            return True
        if number % prime == 0:
            return False
    odd = number - 1
    power = 0
    while odd % 2 == 0:
        power += 1
        odd //= 2
    for _ in range(rounds):
        base = secrets.randbelow(number - 3) + 2
        value = pow(base, odd, number)
        if value in (1, number - 1):
            continue
        for _ in range(power - 1):
            value = pow(value, 2, number)
            if value == number - 1:
                break
        else:
            return False
    return True


def _prime(bits: int) -> int:
    while True:
        candidate = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if _probably_prime(candidate):
            return candidate


def generate_private_key(bits: int = MIN_RSA_BITS) -> dict[str, Any]:
    if bits < MIN_RSA_BITS or bits > MAX_RSA_BITS or bits % 8:
        raise ValueError("RSA 位长无效")
    exponent = 65537
    while True:
        p = _prime(bits // 2)
        q = _prime(bits // 2)
        if p == q:
            continue
        phi = (p - 1) * (q - 1)
        if math.gcd(exponent, phi) != 1:
            continue
        n = p * q
        if n.bit_length() != bits:
            continue
        d = pow(exponent, -1, phi)
        break
    return {
        "format": "FINDECK-RSA-PRIVATE-1",
        "bits": n.bit_length(),
        "n": _b64(n.to_bytes((n.bit_length() + 7) // 8, "big")),
        "e": _b64(exponent.to_bytes(3, "big")),
        "d": _b64(d.to_bytes((d.bit_length() + 7) // 8, "big")),
        "p": _b64(p.to_bytes((p.bit_length() + 7) // 8, "big")),
        "q": _b64(q.to_bytes((q.bit_length() + 7) // 8, "big")),
    }


def public_from_private(private_key: dict[str, Any]) -> dict[str, Any]:
    return normalize_public_key({
        "n": private_key.get("n"),
        "e": private_key.get("e"),
    })


def signature_payload(folder: Path, publisher: dict[str, Any]) -> dict[str, Any]:
    folder = Path(folder)
    manifest_path = folder / "plugin.json"
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw.decode("utf-8"))
    public_key = normalize_public_key(publisher.get("public_key") or {})
    publisher_id = str(publisher.get("id") or "").strip()
    if not publisher_id:
        raise ValueError("发布者 ID 不能为空")
    return {
        "format": SIGNATURE_FORMAT,
        "algorithm": SIGNATURE_ALGORITHM,
        "signed_at": int(time.time()),
        "publisher": {
            "id": publisher_id[:80],
            "name": str(publisher.get("name") or publisher_id)[:100],
            "key_id": public_key["key_id"],
            "public_key": public_key,
        },
        "plugin": {
            "id": str(manifest.get("id") or ""),
            "version": str(manifest.get("version") or ""),
            "api": int(manifest.get("api") or 0),
            "capabilities": sorted(str(x) for x in (manifest.get("capabilities") or [])),
            "permissions": sorted(str(x) for x in (manifest.get("permissions") or [])),
            "manifest_sha256": hashlib.sha256(manifest_raw).hexdigest(),
            "tree_sha256": tree_digest(folder),
        },
    }


def sign_plugin(
    folder: Path,
    private_key: dict[str, Any],
    *,
    publisher_id: str,
    publisher_name: str = "",
) -> dict[str, Any]:
    envelope = signature_payload(Path(folder), {
        "id": publisher_id,
        "name": publisher_name or publisher_id,
        "public_key": public_from_private(private_key),
    })
    envelope["signature"] = sign_bytes(private_key, canonical_json(envelope))
    (Path(folder) / SIGNATURE_FILE).write_text(
        json.dumps(envelope, ensure_ascii=False, indent=1, sort_keys=True),
        encoding="utf-8",
    )
    return envelope


def verify_plugin(folder: Path) -> dict[str, Any]:
    folder = Path(folder)
    path = folder / SIGNATURE_FILE
    if not path.is_file():
        return {
            "signed": False,
            "valid": False,
            "trusted": False,
            "error": "插件没有发布者签名",
            "publisher": {},
        }
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
        if envelope.get("format") != SIGNATURE_FORMAT:
            raise ValueError("发布者签名格式不正确")
        if envelope.get("algorithm") != SIGNATURE_ALGORITHM:
            raise ValueError("发布者签名算法不受支持")
        publisher = envelope.get("publisher") or {}
        public_key = normalize_public_key(publisher.get("public_key") or {})
        if publisher.get("key_id") != public_key["key_id"]:
            raise ValueError("发布者密钥指纹不一致")
        signature = str(envelope.pop("signature", "") or "")
        if not verify_bytes(public_key, canonical_json(envelope), signature):
            raise ValueError("发布者签名校验失败")
        expected = signature_payload(folder, {
            "id": publisher.get("id") or "",
            "name": publisher.get("name") or "",
            "public_key": public_key,
        })
        for key in ("format", "algorithm", "publisher", "plugin"):
            if canonical_json(envelope.get(key)) != canonical_json(expected.get(key)):
                raise ValueError("插件清单或文件与该签名不一致")
        return {
            "signed": True,
            "valid": True,
            "trusted": False,
            "error": "",
            "publisher": {
                "id": str(publisher.get("id") or "")[:80],
                "name": str(publisher.get("name") or "")[:100],
                "key_id": public_key["key_id"],
                "public_key": public_key,
            },
            "signed_at": int(envelope.get("signed_at") or 0),
            "manifest_sha256": expected["plugin"]["manifest_sha256"],
            "tree_sha256": expected["plugin"]["tree_sha256"],
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "signed": True,
            "valid": False,
            "trusted": False,
            "error": str(exc)[:240],
            "publisher": {},
        }
