# -*- coding: utf-8 -*-
"""Pluggable speech providers and a reference-aware echo canceller."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import numpy as np


class STTProvider(Protocol):
    name: str

    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000) -> str: ...


class TTSProvider(Protocol):
    name: str

    def speak(self, text: str, *, interruptable: bool = True) -> Any: ...

    def stop(self) -> None: ...

    def reference_audio(self) -> np.ndarray | None: ...


class AdaptiveEchoCanceller:
    """Estimate the playback-to-microphone FIR path and subtract its echo."""

    def __init__(self, taps: int = 256, eps: float = 1e-6) -> None:
        self.taps = max(8, int(taps))
        self.eps = float(eps)
        self.weights = np.zeros(self.taps, dtype=np.float64)

    def cancel(self, microphone: np.ndarray, reference: np.ndarray) -> np.ndarray:
        mic = np.asarray(microphone, dtype=np.float64).reshape(-1)
        ref = np.asarray(reference, dtype=np.float64).reshape(-1)
        size = min(mic.size, ref.size)
        if size == 0 or size <= self.taps * 2:
            return mic.astype(np.float32)
        mic, ref = mic[:size], ref[:size]
        features = np.empty((size, self.taps), dtype=np.float64)
        for tap in range(self.taps):
            features[tap:, tap] = ref[:size - tap]
            features[:tap, tap] = 0.0
        try:
            weights, *_ = np.linalg.lstsq(features, mic, rcond=None)
        except np.linalg.LinAlgError:
            return mic.astype(np.float32)
        estimate = features @ weights
        self.weights = 0.7 * self.weights + 0.3 * weights
        out = mic - estimate
        if float(np.sqrt(np.mean(out ** 2))) > float(np.sqrt(np.mean(mic ** 2))):
            return mic.astype(np.float32)
        return out.astype(np.float32)


@dataclass
class ProviderRegistry:
    stt: dict[str, STTProvider]
    tts: dict[str, TTSProvider]

    def __init__(self) -> None:
        self.stt = {}
        self.tts = {}

    def register_stt(self, provider: STTProvider) -> None:
        self.stt[str(provider.name)] = provider

    def register_tts(self, provider: TTSProvider) -> None:
        self.tts[str(provider.name)] = provider

    def get_stt(self, name: str) -> STTProvider:
        return self.stt[str(name)]

    def get_tts(self, name: str) -> TTSProvider:
        return self.tts[str(name)]


PROVIDERS = ProviderRegistry()

