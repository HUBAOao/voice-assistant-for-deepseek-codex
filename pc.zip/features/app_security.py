# -*- coding: utf-8 -*-
"""Application-layer capabilities and rotating operation keys."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
import unicodedata
from pathlib import Path
from typing import Any

from features.secure_store import read_secure, write_secure

DEFAULT_POLICY = {
    "capability_ttl_seconds": 600,
    "rotate_days": 30,
    "max_active_devices": 8,
}
BACKUP_FORMAT = "FINSEC-BACKUP-1"
BACKUP_KDF = "PBKDF2-HMAC-SHA256"
BACKUP_ITERATIONS = 310_000
BACKUP_MIN_PASSPHRASE = 12
BACKUP_MAX_BYTES = 64 * 1024


def _security_dir() -> Path:
    try:
        import storage_paths

        return Path(storage_paths.DATA_ROOT) / "安全"
    except Exception:
        return Path(__file__).resolve().parent.parent / "安全"


def _key_path() -> Path:
    configured = os.environ.get("FIN_DECK_SECURITY_KEY", "").strip()
    return Path(configured) if configured else _security_dir() / "transport-key.bin"


def _policy_path() -> Path:
    configured = os.environ.get("FIN_DECK_SECURITY_POLICY", "").strip()
    return Path(configured) if configured else _security_dir() / "policy.json"


def _meta_path() -> Path:
    configured = os.environ.get("FIN_DECK_SECURITY_META", "").strip()
    return Path(configured) if configured else _security_dir() / "key-meta.json"


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(raw: str) -> bytes:
    return base64.urlsafe_b64decode(str(raw) + "=" * (-len(str(raw)) % 4))


def _device_digest(device_id: str) -> str:
    return hashlib.sha256(str(device_id or "").encode("utf-8")).hexdigest()[:20]


def _xor_keystream(key: bytes, nonce: bytes, size: int) -> bytes:
    """HMAC counter-mode stream used by the portable standard-library backup."""
    out = bytearray()
    counter = 0
    while len(out) < size:
        block = hmac.new(
            key,
            b"FINSEC-STREAM-1" + nonce + counter.to_bytes(8, "big"),
            hashlib.sha256,
        ).digest()
        out.extend(block)
        counter += 1
    return bytes(out[:size])


def _derive_backup_keys(passphrase: str, salt: bytes, iterations: int) -> tuple[bytes, bytes]:
    normalized = unicodedata.normalize("NFC", str(passphrase or "")).encode("utf-8")
    material = hashlib.pbkdf2_hmac("sha256", normalized, salt, iterations, dklen=64)
    return material[:32], material[32:]


class AppSecurity:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._key: bytes | None = None
        self._key_file = _key_path()
        self._policy_file = _policy_path()
        self._meta_file = _meta_path()

    def policy(self) -> dict[str, int]:
        value = dict(DEFAULT_POLICY)
        try:
            raw = json.loads(read_secure(self._policy_file).decode("utf-8"))
            for key in value:
                number = int((raw or {}).get(key))
                if number > 0:
                    value[key] = number
        except Exception:
            pass
        value["capability_ttl_seconds"] = min(
            86400, max(60, value["capability_ttl_seconds"])
        )
        value["rotate_days"] = min(3650, max(1, value["rotate_days"]))
        value["max_active_devices"] = min(50, max(1, value["max_active_devices"]))
        return value

    def set_policy(self, **updates: Any) -> dict[str, int]:
        value = self.policy()
        for key in value:
            if key not in updates:
                continue
            try:
                number = int(updates[key])
            except (TypeError, ValueError):
                continue
            if number > 0:
                value[key] = number
        value["capability_ttl_seconds"] = min(
            86400, max(60, value["capability_ttl_seconds"])
        )
        value["rotate_days"] = min(3650, max(1, value["rotate_days"]))
        value["max_active_devices"] = min(50, max(1, value["max_active_devices"]))
        with self._lock:
            write_secure(self._policy_file,
                         json.dumps(value, ensure_ascii=False).encode("utf-8"))
        return value

    def _read_meta(self) -> dict[str, Any]:
        try:
            raw = json.loads(self._meta_file.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _write_meta(self, meta: dict[str, Any]) -> None:
        self._meta_file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._meta_file.with_name(self._meta_file.name + ".tmp")
        tmp.write_text(
            json.dumps(meta, ensure_ascii=False, indent=1, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(tmp, self._meta_file)

    def _remember_key(self, key: bytes, *, source: str = "local") -> None:
        current = self._read_meta()
        now = int(time.time())
        self._write_meta({
            "version": 1,
            "key_id": hashlib.sha256(key).hexdigest()[:16],
            "created_at": int(current.get("created_at") or now),
            "rotated_at": now,
            "generation": max(1, int(current.get("generation") or 0) + 1),
            "source": str(source or "local")[:24],
        })

    def _ensure_key_meta(self, key: bytes) -> dict[str, Any]:
        meta = self._read_meta()
        key_id = hashlib.sha256(key).hexdigest()[:16]
        if meta.get("key_id") != key_id:
            self._remember_key(key, source="observed")
            meta = self._read_meta()
        return meta

    def _read_key(self) -> bytes:
        with self._lock:
            if self._key is not None:
                return self._key
            try:
                key = read_secure(self._key_file)
            except Exception:
                key = b""
            if len(key) != 32:
                key = self._new_key()
            elif self._rotation_due():
                key = self._new_key()
            self._key = key
            return key

    def _new_key(self) -> bytes:
        key = secrets.token_bytes(32)
        write_secure(self._key_file, key)
        self._key = key
        self._remember_key(key)
        return key

    def _rotation_due(self) -> bool:
        try:
            age = time.time() - self._key_file.stat().st_mtime
            return age > self.policy()["rotate_days"] * 86400
        except OSError:
            return False

    def rotate(self, reason: str = "manual") -> dict[str, Any]:
        with self._lock:
            key = secrets.token_bytes(32)
            write_secure(self._key_file, key)
            self._key = key
            self._remember_key(key, source=reason)
        return self.summary()

    def summary(self) -> dict[str, Any]:
        policy = self.policy()
        try:
            age = max(0.0, time.time() - self._key_file.stat().st_mtime)
        except OSError:
            age = 0.0
        key = self._read_key()
        meta = self._read_meta()
        key_id = hashlib.sha256(key).hexdigest()[:16]
        if meta.get("key_id") != key_id:
            self._remember_key(key, source="observed")
            meta = self._read_meta()
        return {
            "ok": True,
            "algorithm": "HMAC-SHA256 capability",
            "key_age_days": round(age / 86400, 2),
            "rotation_due": age > policy["rotate_days"] * 86400,
            "key_id": key_id,
            "key_generation": int(meta.get("generation") or 1),
            "key_created_at": int(meta.get("created_at") or 0),
            "policy": policy,
        }

    def issue(self, *, device_id: str = "", device_epoch: int = 0) -> dict[str, Any]:
        now = int(time.time())
        ttl = self.policy()["capability_ttl_seconds"]
        key = self._read_key()
        meta = self._ensure_key_meta(key)
        payload = {
            "v": 2,
            "iat": now,
            "exp": now + ttl,
            "nonce": secrets.token_urlsafe(18),
            "device": _device_digest(device_id),
            "device_epoch": max(0, int(device_epoch or 0)),
            "kid": hashlib.sha256(key).hexdigest()[:16],
            "key_generation": max(1, int(meta.get("generation") or 1)),
        }
        raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
        signature = hmac.new(key, raw, hashlib.sha256).digest()
        return {
            "capability": _b64(raw) + "." + _b64(signature),
            "expires_at": payload["exp"],
            "ttl": ttl,
            "task": "device-bound-operation",
        }

    def verify(
        self,
        capability: str,
        *,
        device_id: str | None = None,
        device_epoch: int | None = None,
        require_device: bool = False,
    ) -> dict[str, Any]:
        try:
            encoded, signature = str(capability or "").split(".", 1)
            raw = _unb64(encoded)
            got = _unb64(signature)
        except Exception as exc:
            raise ValueError("安全凭据格式不正确") from exc
        want = hmac.new(self._read_key(), raw, hashlib.sha256).digest()
        if not hmac.compare_digest(got, want):
            raise ValueError("安全凭据签名无效")
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise ValueError("安全凭据内容无效") from exc
        now = time.time()
        if int(payload.get("exp") or 0) <= now:
            raise ValueError("安全凭据已过期")
        if int(payload.get("iat") or 0) > now + 60:
            raise ValueError("安全凭据时间无效")
        meta = self._ensure_key_meta(self._read_key())
        if int(payload.get("key_generation") or 0) != int(meta.get("generation") or 0):
            raise ValueError("操作密钥已变更，请重新领取凭据")
        if require_device:
            if not str(payload.get("device") or ""):
                raise ValueError("安全凭据未绑定设备")
            if device_id is None or not hmac.compare_digest(
                str(payload.get("device") or ""), _device_digest(device_id)
            ):
                raise ValueError("安全凭据不属于这台设备")
            if int(payload.get("device_epoch") or 0) != int(device_epoch or 0):
                raise ValueError("设备授权已变更，请重新领取凭据")
        return payload

    def sign_payload(self, namespace: str, raw: bytes) -> str:
        """Return a device-local HMAC seal for installed plugin content."""
        scope = str(namespace or "").strip().encode("utf-8")
        if not scope:
            raise ValueError("签名用途不能为空")
        with self._lock:
            digest = hmac.new(
                self._read_key(),
                b"FINDECK-LOCAL-SEAL-1\0" + scope + b"\0" + bytes(raw),
                hashlib.sha256,
            ).hexdigest()
        return digest

    def verify_payload(self, namespace: str, raw: bytes, signature: str) -> bool:
        """Verify a local seal without exposing the operation key."""
        try:
            want = self.sign_payload(namespace, raw)
        except Exception:
            return False
        return hmac.compare_digest(str(signature or ""), want)

    def export_backup(self, passphrase: str) -> dict[str, Any]:
        """Create a portable encrypted envelope. The DPAPI key never leaves as plaintext."""
        phrase = str(passphrase or "")
        if len(phrase) < BACKUP_MIN_PASSPHRASE:
            raise ValueError("恢复口令至少需要 12 个字符")
        with self._lock:
            key = bytes(self._read_key())
            salt = secrets.token_bytes(16)
            nonce = secrets.token_bytes(16)
            header = {
                "format": BACKUP_FORMAT,
                "kdf": BACKUP_KDF,
                "iterations": BACKUP_ITERATIONS,
                "salt": _b64(salt),
                "nonce": _b64(nonce),
                "created_at": int(time.time()),
                "key_id": hashlib.sha256(key).hexdigest()[:16],
            }
            header_raw = json.dumps(
                header, separators=(",", ":"), sort_keys=True
            ).encode("utf-8")
            enc_key, mac_key = _derive_backup_keys(
                phrase, salt, BACKUP_ITERATIONS
            )
            ciphertext = bytes(a ^ b for a, b in zip(
                key, _xor_keystream(enc_key, nonce, len(key))
            ))
            tag = hmac.new(
                mac_key,
                b"FINSEC-BACKUP-AUTH-1" + header_raw + ciphertext,
                hashlib.sha256,
            ).digest()
            envelope = {
                "header": header,
                "ciphertext": _b64(ciphertext),
                "tag": _b64(tag),
            }
            text = json.dumps(envelope, ensure_ascii=False, indent=1)
            return {
                "backup": text,
                "format": BACKUP_FORMAT,
                "key_id": header["key_id"],
                "created_at": header["created_at"],
            }

    def restore_backup(self, backup: str, passphrase: str) -> dict[str, Any]:
        """Verify and atomically restore a portable operation-key envelope."""
        phrase = str(passphrase or "")
        if len(phrase) < BACKUP_MIN_PASSPHRASE:
            raise ValueError("恢复口令至少需要 12 个字符")
        raw_backup = str(backup or "").strip()
        if not raw_backup or len(raw_backup.encode("utf-8")) > BACKUP_MAX_BYTES:
            raise ValueError("恢复包为空或过大")
        try:
            envelope = json.loads(raw_backup)
            header = envelope["header"]
            ciphertext = _unb64(envelope["ciphertext"])
            tag = _unb64(envelope["tag"])
            salt = _unb64(header["salt"])
            nonce = _unb64(header["nonce"])
            iterations = int(header["iterations"])
        except Exception as exc:
            raise ValueError("恢复包格式不正确") from exc
        if header.get("format") != BACKUP_FORMAT or header.get("kdf") != BACKUP_KDF:
            raise ValueError("恢复包格式不受支持")
        if not 50_000 <= iterations <= 2_000_000:
            raise ValueError("恢复包参数超出安全范围")
        if len(ciphertext) != 32 or len(salt) != 16 or len(nonce) != 16:
            raise ValueError("恢复包内容损坏")
        header_raw = json.dumps(
            header, separators=(",", ":"), sort_keys=True
        ).encode("utf-8")
        enc_key, mac_key = _derive_backup_keys(phrase, salt, iterations)
        want = hmac.new(
            mac_key,
            b"FINSEC-BACKUP-AUTH-1" + header_raw + ciphertext,
            hashlib.sha256,
        ).digest()
        if not hmac.compare_digest(tag, want):
            raise ValueError("恢复口令错误或恢复包已被篡改")
        key = bytes(a ^ b for a, b in zip(
            ciphertext, _xor_keystream(enc_key, nonce, len(ciphertext))
        ))
        if len(key) != 32:
            raise ValueError("恢复包内容无效")
        with self._lock:
            try:
                previous = read_secure(self._key_file)
            except Exception:
                previous = b""
            if len(previous) == 32:
                write_secure(
                    self._key_file.with_name(self._key_file.name + ".previous"),
                    previous,
                )
            write_secure(self._key_file, key)
            self._key = key
            current = self._read_meta()
            now = int(time.time())
            self._write_meta({
                "version": 1,
                "key_id": hashlib.sha256(key).hexdigest()[:16],
                "created_at": int(header.get("created_at") or now),
                "rotated_at": now,
                # A restore can bring back the same bytes under another install.
                # A time-based watermark prevents capabilities from another key
                # generation (or installation) becoming valid again.
                "generation": max(
                    int(current.get("generation") or 0) + 1,
                    int(time.time() * 1000),
                ),
                "source": "restored-backup",
            })
            result = self.summary()
            result["restored_key_id"] = header.get("key_id") or ""
            result["backup_created_at"] = int(header.get("created_at") or 0)
            return result


SECURITY = AppSecurity()


def issue(device_id: str = "", device_epoch: int = 0) -> dict[str, Any]:
    return SECURITY.issue(device_id=device_id, device_epoch=device_epoch)


def verify(
    capability: str,
    *,
    device_id: str | None = None,
    device_epoch: int | None = None,
    require_device: bool = False,
) -> dict[str, Any]:
    return SECURITY.verify(
        capability,
        device_id=device_id,
        device_epoch=device_epoch,
        require_device=require_device,
    )

