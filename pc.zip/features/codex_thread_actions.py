# -*- coding: utf-8 -*-
"""Open and mutate Codex threads through deep links, UI Automation, and RPC."""
from __future__ import annotations

import os
import subprocess
import sys
import time
from typing import Any
from urllib.parse import quote, urlencode

from features import codex_app_server
from features.codex_ui_bridge import current_title, run, run_with_name
from features.codex_thread_catalog import (
    DB,
    _sections,
    list_projects,
    list_threads,
    ui_current_title,
)


def current_name() -> str:
    return ui_current_title()


def current_thread_id() -> str:
    current = ui_current_title()
    if not current:
        return ""
    try:
        import sqlite3

        if DB.exists():
            connection = sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True)
            try:
                row = connection.execute(
                    "select id from threads where title=? or name=? "
                    "order by coalesce(recency_at_ms,updated_at_ms) desc limit 1",
                    (current, current),
                ).fetchone()
                if row:
                    return str(row[0])
            finally:
                connection.close()
    except Exception:
        pass
    return ""


def _open_deeplink(route: str) -> bool:
    url = "codex://threads/" + route
    try:
        if sys.platform == "win32":
            os.startfile(url)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(
                ["xdg-open", url],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        return True
    except Exception:
        return False


def open_new_thread(project_id: str = "") -> tuple[bool, str]:
    project_id = str(project_id or "").strip()
    query = "?" + urlencode({"projectId": project_id}) if project_id else ""
    if not _open_deeplink("new" + query):
        ok, output = run(["-Action", "new"], timeout=15.0)
        if not ok:
            return False, output[:120] or "打不开新对话"
    return True, "新对话"


def open_thread(
    name: str,
    thread_id: str = "",
    dry_run: bool = False,
) -> tuple[bool, str]:
    """Open a thread by stable id, then verify its title when possible."""
    name = str(name or "").strip()
    thread_id = str(thread_id or "").strip()
    if not name and not thread_id:
        return False, "没给会话名"
    if dry_run:
        ok, output = run_with_name(
            name,
            ["-Action", "open", "-DryRun"],
            timeout=30.0,
        )
        if ok and ("WOULD_CLICK" in output or "CLICKED" in output):
            return True, output
        if "NOT_FOUND" in output:
            return False, "侧栏里没找到这个会话（可能被折叠/滚出可视区了）"
        return False, output[:120]
    if thread_id:
        if current_thread_id() == thread_id:
            return True, name or thread_id
        if _open_deeplink(quote(thread_id, safe="")):
            for _ in range(12):
                time.sleep(0.15)
                if not name or ui_current_title() == name:
                    return True, name or thread_id
    ok, output = run_with_name(name, ["-Action", "open"], timeout=30.0)
    if not ok:
        return False, output[:120]
    if "CLICKED" in output:
        return True, name
    if "NOT_FOUND" in output:
        return False, "侧栏里没找到这个会话（可能被折叠/滚出可视区了）"
    if "NO_WINDOW" in output:
        return False, "没找到 Codex 窗口（先把它打开）"
    return False, output[:120]


def rename_thread(thread_id: str, new_name: str) -> tuple[bool, str]:
    new_name = str(new_name or "").strip()
    if not thread_id or not new_name:
        return False, "新名字不能为空"
    try:
        codex_app_server._rpc(
            "thread/name/set",
            {"threadId": thread_id, "name": new_name},
        )
        return True, new_name
    except Exception as error:
        return False, str(error)[:120]


def set_read_state(
    thread_id: str,
    read: bool,
    revision: str = "",
) -> tuple[bool, str]:
    try:
        expected = str(revision or "")
        if not expected:
            data = codex_app_server._rpc(
                "thread/read",
                {"threadId": thread_id, "includeTurns": False},
            )
            state = data.get("readState") if isinstance(data, dict) else {}
            expected = str((state or {}).get("revision") or "")
        if not expected:
            return False, "读不到会话的已读状态"
        codex_app_server._rpc(
            "thread/readState/update",
            {
                "threadId": thread_id,
                "expectedRevision": expected,
                "operation": {"type": "read" if read else "unread"},
            },
        )
        return True, "已标为已读" if read else "已标为未读"
    except Exception as error:
        return False, str(error)[:120]


def set_pinned(thread_id: str, pinned: bool) -> tuple[bool, str]:
    try:
        sections = _sections()
        pinned_section = next(
            (
                section
                for section in sections
                if str(section.get("name") or "").casefold()
                in {"pinned", "置顶", "已置顶", "top"}
            ),
            None,
        )
        if pinned:
            if pinned_section is None:
                result = codex_app_server._rpc(
                    "threadSection/create",
                    {"name": "Pinned"},
                )
                pinned_section = (
                    result.get("section") if isinstance(result, dict) else None
                )
            if not pinned_section:
                return False, "电脑上没有置顶分组"
            sid = str(pinned_section.get("id") or "")
        else:
            sid = None
        codex_app_server._rpc(
            "thread/section/move",
            {"threadId": thread_id, "sectionId": sid},
        )
        return True, "已置顶" if pinned else "已取消置顶"
    except Exception as error:
        return False, str(error)[:120]


def move_to_project(thread_id: str, project_id: str) -> tuple[bool, str]:
    try:
        pid = str(project_id or "").strip()
        codex_app_server._rpc(
            "thread/metadata/update",
            {"threadId": thread_id, "projectId": pid},
        )
        if not pid:
            return True, "已移出项目"
        name = next((item["name"] for item in list_projects() if item["id"] == pid), pid)
        return True, "已移动到 " + name
    except Exception as error:
        return False, str(error)[:120]


def thread_action(
    action: str,
    thread_id: str,
    **payload: Any,
) -> tuple[bool, str]:
    action = str(action or "").strip().lower()
    thread_id = str(thread_id or "").strip()
    if not thread_id:
        return False, "没给会话 ID"
    if action == "rename":
        return rename_thread(thread_id, str(payload.get("name") or ""))
    if action == "pin":
        return set_pinned(thread_id, bool(payload.get("pinned", True)))
    if action == "read":
        return set_read_state(
            thread_id,
            bool(payload.get("read", True)),
            str(payload.get("revision") or ""),
        )
    if action == "project":
        return move_to_project(thread_id, str(payload.get("project_id") or ""))
    if action == "archive":
        from features.codex_thread_lifecycle import archive_thread

        return archive_thread(
            thread_id,
            bool(payload.get("archived", True)),
            str(payload.get("title") or payload.get("name") or ""),
        )
    if action == "delete":
        from features.codex_thread_lifecycle import delete_thread

        return delete_thread(
            thread_id,
            str(payload.get("title") or payload.get("name") or ""),
        )
    return False, "不支持的会话操作"


def available() -> bool:
    ok, output = run(["-Action", "list"])
    return ok and "NO_WINDOW" not in output
