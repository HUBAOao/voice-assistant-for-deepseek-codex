# -*- coding: utf-8 -*-
"""Bridge Codex thread helpers through the PowerShell UI Automation script."""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path


HERE = Path(__file__).resolve().parents[1]
SCRIPT = HERE / "codex_threads.ps1"


def run(args: list[str], timeout: float = 25.0) -> tuple[bool, str]:
    if not SCRIPT.exists():
        return False, "NO_SCRIPT"
    try:
        process = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(SCRIPT),
            ]
            + args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=0x08000000 if sys.platform == "win32" else 0,
        )
        output = ((process.stdout or "") + (process.stderr or "")).strip()
        return process.returncode == 0, output
    except Exception as error:
        return False, "%s: %s" % (type(error).__name__, error)


def run_with_name(
    name: str,
    extra: list[str],
    timeout: float = 30.0,
) -> tuple[bool, str]:
    target = Path(tempfile.gettempdir()) / "va-thread-name.txt"
    try:
        target.write_text(str(name), encoding="utf-8")
    except Exception as error:
        return False, "临时文件写不了：%s" % error
    return run(extra + ["-NameFile", str(target)], timeout=timeout)


def current_title() -> str:
    ok, output = run(["-Action", "list"], timeout=8.0)
    if not ok or "NO_WINDOW" in output:
        return ""
    for line in output.splitlines():
        if "\t" in line and line.rstrip().endswith("\t1"):
            return line.rsplit("\t", 1)[0].strip()
    return ""
