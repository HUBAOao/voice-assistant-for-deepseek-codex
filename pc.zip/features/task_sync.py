# -*- coding: utf-8 -*-
"""Mirror recent Codex turns into the local task store."""
from __future__ import annotations

import threading
import time
from typing import Any

from features.task_policy import DEFAULT_RETENTION, redact_sensitive
from features.task_store import TaskStore


SYNC_LOCK = threading.Lock()
LAST_SYNC = 0.0


def turn_status(status: str) -> str:
    return {
        "inProgress": "running",
        "completed": "succeeded",
        "failed": "failed",
        "interrupted": "cancelled",
    }.get(str(status or ""), "queued")


def turn_changes(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") != "fileChange":
            continue
        for change in item.get("changes") or []:
            if not isinstance(change, dict):
                continue
            result.append(
                {
                    "path": str(
                        change.get("path") or change.get("file") or ""
                    )[:500],
                    "status": str(
                        change.get("kind")
                        or change.get("status")
                        or "modified"
                    )[:30],
                }
            )
    return result


def turn_tools(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for item in items:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("type") or "")
        if kind == "commandExecution":
            command = redact_sensitive(
                str(item.get("command") or ""),
                limit=500,
            )
            output = redact_sensitive(
                str(item.get("aggregatedOutput") or ""),
                limit=DEFAULT_RETENTION["max_tool_output_chars"],
            )
            result.append(
                {
                    "name": "shell",
                    "status": str(item.get("status") or "")[:30],
                    "detail": command,
                    "exit_code": item.get("exitCode"),
                    "duration_ms": item.get("durationMs"),
                    "output": output,
                    "item_id": str(item.get("id") or ""),
                    "at": float(item.get("completedAtMs") or 0) / 1000.0,
                }
            )
        elif kind in {"collabAgentToolCall", "subAgentActivity"}:
            result.append(
                {
                    "name": kind,
                    "status": str(
                        item.get("status") or item.get("kind") or ""
                    )[:30],
                    "detail": str(
                        item.get("tool") or item.get("agentPath") or ""
                    )[:500],
                    "item_id": str(item.get("id") or ""),
                    "at": float(item.get("completedAtMs") or 0) / 1000.0,
                }
            )
    return result[-100:]


def turn_tests(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for tool in tools:
        command = str(tool.get("detail") or "")
        lowered = command.lower()
        if not any(
            word in lowered
            for word in ("test", "pytest", "unittest", "check_page", "selftest")
        ):
            continue
        exit_code = tool.get("exit_code")
        ok = (
            str(tool.get("status") or "") in {"completed", "succeeded"}
            and (exit_code is None or int(exit_code) == 0)
        )
        output = str(tool.get("output") or "")
        result.append(
            {
                "name": command.splitlines()[0][:160] or "测试",
                "ok": bool(ok),
                "exit_code": exit_code,
                "detail": redact_sensitive(
                    output[-1200:] if output else "",
                    limit=1600,
                ),
                "at": tool.get("at") or time.time(),
            }
        )
    return result[-30:]


def approval_expired(task: dict[str, Any]) -> bool:
    approval = task.get("approval") or {}
    if approval.get("decision") != "pending" or not approval.get("live"):
        return False
    request_id = approval.get("request_id")
    if request_id is None:
        return False
    try:
        import codex_threads

        return not codex_threads.server_request_pending(request_id)
    except Exception:
        return False


def sync_recent_threads(
    store: TaskStore | None = None,
    *,
    max_threads: int = 10,
    max_turns: int = 6,
    force: bool = False,
) -> int:
    """Merge recent Codex turns without writing Codex state."""
    global LAST_SYNC
    now = time.time()
    if not force and now - LAST_SYNC < 12:
        return 0
    if not SYNC_LOCK.acquire(blocking=False):
        return 0
    try:
        if not force and time.time() - LAST_SYNC < 12:
            return 0
        import codex_threads

        store = store or TaskStore()
        changed = 0
        for row in codex_threads.list_threads()[:max_threads]:
            thread_id = str(row.get("id") or "")
            if not thread_id or row.get("archived"):
                continue
            try:
                data = codex_threads._rpc(
                    "thread/read",
                    {"threadId": thread_id, "includeTurns": True},
                    timeout=10,
                )
            except Exception:
                continue
            thread = data.get("thread") or {}
            turns = list(thread.get("turns") or [])[-max_turns:]
            for turn in turns:
                source_id = str(turn.get("id") or "")
                if not source_id:
                    continue
                existing = store.find_by_source("codex_turn", source_id)
                task = existing or store.create(
                    str(
                        thread.get("name")
                        or thread.get("preview")
                        or thread_id
                    ),
                    thread_id=thread_id,
                    detail="Codex 实时任务",
                )
                items = [
                    item
                    for item in turn.get("items") or []
                    if isinstance(item, dict)
                ]
                error = turn.get("error") or ""
                status = turn_status(str(turn.get("status") or ""))
                tools = turn_tools(items)
                tests = turn_tests(tools)
                changes = turn_changes(items)
                diff = redact_sensitive(
                    str(turn.get("diff") or task.get("diff") or ""),
                    limit=store.retention()["max_diff_chars"],
                )
                title = str(
                    thread.get("name") or task.get("title") or thread_id
                )
                details = [
                    "Codex 实时任务",
                    f"{len(tools)} 次工具",
                    (
                        f"{sum(1 for item in tests if item.get('ok'))}/"
                        f"{len(tests)} 测试通过"
                        if tests
                        else "暂无测试"
                    ),
                ]
                if diff:
                    details.append(f"{len(changes)} 个文件变化")
                update = {
                    "source": "codex_turn",
                    "source_id": source_id,
                    "title": title,
                    "thread_id": thread_id,
                    "detail": " · ".join(details),
                    "status": status,
                    "error": redact_sensitive(str(error), limit=1000),
                    "tool_calls": tools,
                    "changes": changes,
                    "tests": tests,
                    "diff": diff,
                    "active_turn_id": (
                        source_id
                        if status in {"running", "waiting_approval"}
                        else ""
                    ),
                }
                approval = task.get("approval") or {}
                if (
                    status not in {"running", "waiting_approval"}
                    and approval.get("decision") == "pending"
                ):
                    approval = dict(approval)
                    approval["decision"] = "expired"
                    approval["expired_at"] = time.time()
                    update["approval"] = approval
                elif approval_expired(task):
                    approval = dict(approval)
                    approval["decision"] = "expired"
                    approval["expired_at"] = time.time()
                    update["approval"] = approval
                    if status == "waiting_approval":
                        update["status"] = "running"
                if any(task.get(key) != value for key, value in update.items()):
                    store.update(task["id"], **update)
                    changed += 1
        LAST_SYNC = time.time()
        return changed
    finally:
        SYNC_LOCK.release()
