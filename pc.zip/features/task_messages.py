# -*- coding: utf-8 -*-
"""Queued follow-up messages attached to persistent tasks."""
from __future__ import annotations

import time
import uuid
from typing import Any

from features.task_policy import redact_sensitive


class TaskMessageMixin:
    def queue_message(self, task_id: str, text: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        messages.append(
            {
                "id": uuid.uuid4().hex[:12],
                "text": redact_sensitive(text, limit=4000),
                "status": "queued",
                "at": time.time(),
            }
        )
        return self.update(task_id, messages=messages[-100:])

    def edit_message(
        self,
        task_id: str,
        message_id: str,
        text: str,
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["text"] = redact_sensitive(text, limit=4000)
                item["status"] = "queued"
                item["edited_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def mark_message(
        self,
        task_id: str,
        message_id: str,
        status: str,
        *,
        detail: str = "",
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["status"] = str(status or "failed")[:30]
                if detail:
                    item["detail"] = redact_sensitive(detail, limit=1000)
                item["delivered_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def cancel_message(self, task_id: str, message_id: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["status"] = "cancelled"
                item["cancelled_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def reorder_messages(
        self,
        task_id: str,
        message_ids: list[str],
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        by_id = {str(item.get("id")): item for item in messages}
        ordered = [
            by_id.pop(str(message_id))
            for message_id in message_ids
            if str(message_id) in by_id
        ]
        ordered.extend(
            item for item in messages if str(item.get("id")) in by_id
        )
        for index, item in enumerate(ordered):
            item["position"] = index
        return self.update(task_id, messages=ordered)
