# -*- coding: utf-8 -*-
"""Thread-safe persistent storage for task approvals and activity."""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from pathlib import Path
from typing import Any

from features.secure_store import read_secure, write_secure
from features.task_messages import TaskMessageMixin
from features.task_policy import (
    DEFAULT_RETENTION,
    STATUSES,
    classify_risk,
    merge_retention,
    next_revision,
    prune_data,
    redact_sensitive,
    sanitize_data,
)


class TaskStore(TaskMessageMixin):
    """Small thread-safe JSON task store with atomic secure writes."""

    def __init__(self, path: Path | None = None) -> None:
        configured = os.environ.get("FIN_DECK_TASKS_FILE", "").strip()
        if path is None and configured:
            path = Path(configured)
        if path is None:
            try:
                import storage_paths

                path = storage_paths.DATA_ROOT / "任务" / "tasks.json"
            except Exception:
                path = Path(__file__).resolve().parent.parent / "任务" / "tasks.json"
        self.path = Path(path)
        self._lock = threading.RLock()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(read_secure(self.path).decode("utf-8"))
            if isinstance(data, dict) and isinstance(data.get("tasks"), dict):
                return data
        except Exception:
            pass
        return {
            "version": 2,
            "revision": 1,
            "tasks": {},
            "retention": dict(DEFAULT_RETENTION),
        }

    def _save(self, data: dict[str, Any]) -> None:
        data.setdefault("version", 2)
        data.setdefault("revision", 1)
        prune_data(data)
        sanitize_data(data)
        write_secure(
            self.path,
            json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"),
        )

    @staticmethod
    def _event(task: dict[str, Any], kind: str, detail: str = "") -> None:
        events = task.setdefault("events", [])
        events.append(
            {
                "at": time.time(),
                "kind": str(kind)[:40],
                "detail": str(detail)[:300],
            }
        )
        if len(events) > 200:
            del events[:-200]

    def create(
        self,
        title: str,
        *,
        thread_id: str = "",
        detail: str = "",
    ) -> dict[str, Any]:
        title = str(title or "").strip() or "未命名任务"
        now = time.time()
        task = {
            "id": "task_" + uuid.uuid4().hex[:16],
            "title": title[:160],
            "detail": str(detail or "")[:1000],
            "thread_id": str(thread_id or ""),
            "status": "queued",
            "created_at": now,
            "updated_at": now,
            "tool_calls": [],
            "tests": [],
            "changes": [],
            "messages": [],
            "approval": None,
            "error": "",
            "diff": "",
            "active_turn_id": "",
            "revision": 0,
            "events": [],
        }
        self._event(task, "created")
        with self._lock:
            data = self._load()
            task["revision"] = next_revision(data)
            data["tasks"][task["id"]] = task
            self._save(data)
        return dict(task)

    def get(self, task_id: str) -> dict[str, Any] | None:
        with self._lock:
            task = self._load()["tasks"].get(str(task_id))
            return dict(task) if task else None

    def find_by_source(
        self,
        source: str,
        source_id: str,
    ) -> dict[str, Any] | None:
        with self._lock:
            for task in self._load()["tasks"].values():
                if (
                    task.get("source") == str(source)
                    and task.get("source_id") == str(source_id)
                ):
                    return dict(task)
        return None

    def list(
        self,
        *,
        status: str = "",
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        with self._lock:
            tasks = list(self._load()["tasks"].values())
        if status:
            tasks = [task for task in tasks if task.get("status") == status]
        tasks.sort(
            key=lambda task: float(task.get("updated_at") or 0),
            reverse=True,
        )
        return [dict(task) for task in tasks[: max(1, int(limit))]]

    def snapshot(self, *, after: int = 0, limit: int = 100) -> dict[str, Any]:
        with self._lock:
            data = self._load()
        cursor = max(1, int(data.get("revision") or 1))
        tasks = []
        for task in data["tasks"].values():
            if not isinstance(task, dict):
                continue
            if after and int(task.get("revision") or 0) <= int(after):
                continue
            tasks.append(dict(task))
        tasks.sort(
            key=lambda task: float(task.get("updated_at") or 0),
            reverse=True,
        )
        return {
            "items": tasks[: max(1, int(limit))],
            "ids": sorted(str(task_id) for task_id in data["tasks"]),
            "cursor": cursor,
            "reset": bool(after and int(after) > cursor),
            "retention": merge_retention(data.get("retention")),
        }

    def update(self, task_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            data = self._load()
            task = data["tasks"].get(str(task_id))
            if not task:
                raise KeyError("任务不存在")
            status = fields.get("status")
            if status and status not in STATUSES:
                raise ValueError("未知任务状态：%s" % status)
            for key, value in fields.items():
                if key in {"id", "created_at", "events"}:
                    continue
                task[key] = value
            task["updated_at"] = time.time()
            task["revision"] = next_revision(data)
            self._event(task, "updated", ",".join(sorted(fields)))
            self._save(data)
            return dict(task)

    def request_approval(
        self,
        task_id: str,
        command: str,
        *,
        target: str = "",
        risk: str = "",
        request_id: Any = None,
        method: str = "",
        item_id: str = "",
        thread_id: str = "",
        turn_id: str = "",
        reason: str = "",
        available_decisions: list[str] | None = None,
        live: bool = False,
    ) -> dict[str, Any]:
        risk = str(risk or classify_risk(command)).lower()
        if risk not in {"low", "medium", "high"}:
            risk = "high"
        approval = {
            "command": redact_sensitive(str(command or ""), limit=2000),
            "target": redact_sensitive(str(target or ""), limit=500),
            "risk": risk,
            "requested_at": time.time(),
            "decision": "pending",
            "request_id": request_id,
            "method": str(method or "")[:120],
            "item_id": str(item_id or "")[:160],
            "thread_id": str(thread_id or "")[:160],
            "turn_id": str(turn_id or "")[:160],
            "reason": redact_sensitive(str(reason or ""), limit=500),
            "available_decisions": list(available_decisions or [])[:12],
            "live": bool(live),
        }
        return self.update(task_id, status="waiting_approval", approval=approval)

    def decide(
        self,
        task_id: str,
        approved: bool,
        note: str = "",
        *,
        decision: str = "",
        response_sent: bool = False,
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        approval = task.get("approval") or {}
        if approval.get("decision") != "pending":
            raise ValueError("没有待批准请求")
        approval.update(
            {
                "decision": str(
                    decision or ("approved" if approved else "rejected")
                ),
                "decided_at": time.time(),
                "note": redact_sensitive(str(note or ""), limit=500),
                "response_sent": bool(response_sent),
            }
        )
        status = (
            "running"
            if approved or approval.get("method")
            else "cancelled"
        )
        return self.update(task_id, status=status, approval=approval)

    def add_tool_call(
        self,
        task_id: str,
        name: str,
        *,
        status: str = "running",
        detail: str = "",
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        calls = list(task.get("tool_calls") or [])
        calls.append(
            {
                "name": str(name)[:120],
                "status": str(status)[:30],
                "detail": redact_sensitive(detail, limit=1000),
                "at": time.time(),
            }
        )
        return self.update(task_id, tool_calls=calls[-100:])

    def add_test(
        self,
        task_id: str,
        name: str,
        ok: bool,
        *,
        detail: str = "",
    ) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        tests = list(task.get("tests") or [])
        tests.append(
            {
                "name": str(name)[:160],
                "ok": bool(ok),
                "detail": redact_sensitive(detail, limit=2000),
                "at": time.time(),
            }
        )
        return self.update(task_id, tests=tests[-100:])

    def set_changes(
        self,
        task_id: str,
        changes: list[dict[str, Any]],
    ) -> dict[str, Any]:
        clean = []
        for item in list(changes or [])[:500]:
            if not isinstance(item, dict):
                continue
            clean.append(
                {
                    "path": str(item.get("path") or "")[:500],
                    "status": str(item.get("status") or "modified")[:30],
                    "added": int(item.get("added") or 0),
                    "removed": int(item.get("removed") or 0),
                }
            )
        return self.update(task_id, changes=clean)

    def retention(self) -> dict[str, int]:
        with self._lock:
            return merge_retention(self._load().get("retention"))

    def set_retention(self, **policy: Any) -> dict[str, int]:
        clean = merge_retention({**self.retention(), **policy})
        with self._lock:
            data = self._load()
            data["retention"] = clean
            next_revision(data)
            self._save(data)
        return clean

    def prune(self) -> dict[str, int]:
        with self._lock:
            data = self._load()
            before = len(data["tasks"])
            prune_data(data)
            if len(data["tasks"]) != before:
                next_revision(data)
                self._save(data)
            return {
                "removed": max(0, before - len(data["tasks"])),
                "remaining": len(data["tasks"]),
            }
