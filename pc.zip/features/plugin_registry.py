# -*- coding: utf-8 -*-
"""Versioned, opt-in plugin discovery and lifecycle management for FinDeck."""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import sys
import tempfile
import threading
import time
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from types import ModuleType
from typing import Any

from features.plugin_signing import (
    normalize_public_key,
    public_key_id,
    tree_digest,
    verify_plugin,
)
from features.plugin_rollback import PluginRollbackMixin

PLUGIN_API = 1
ALLOWED_CAPABILITIES = {
    "command", "page", "stt", "tts", "task-provider",
}
ALLOWED_PERMISSIONS = {
    "clipboard", "codex", "filesystem-read", "filesystem-write",
    "microphone", "network", "notifications", "playback", "tasks",
}
PLUGIN_ARCHIVE_MAX = 8 * 1024 * 1024
PLUGIN_TREE_MAX = 24 * 1024 * 1024
PLUGIN_FILES_MAX = 240
PLUGIN_SEAL_FILE = ".findeck-install.json"
_PLUGIN_ID = re.compile(r"^[a-z][a-z0-9._-]{1,63}$")
_ROOT_LOCK = threading.RLock()


@dataclass(frozen=True)
class PluginRecord:
    id: str
    name: str
    version: str
    api: int
    entrypoint: Path
    capabilities: tuple[str, ...]
    permissions: tuple[str, ...]
    source: Path
    description: str = ""
    error: str = ""

    def public(self) -> dict[str, Any]:
        value = asdict(self)
        value["entrypoint"] = str(self.entrypoint)
        value["source"] = str(self.source)
        value["capabilities"] = list(self.capabilities)
        value["permissions"] = list(self.permissions)
        return value


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _tree_digest(folder: Path) -> str:
    return tree_digest(folder)


class PluginRegistry:
    """Discover manifests without executing code; loading is always explicit."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self._records: dict[str, PluginRecord] = {}
        self._modules: dict[str, ModuleType] = {}

    def _record(self, folder: Path, manifest_path: Path, raw: Any) -> PluginRecord:
        if not isinstance(raw, dict):
            raise ValueError("manifest 必须是 JSON 对象")
        plugin_id = str(raw.get("id") or folder.name).strip()
        if not _PLUGIN_ID.fullmatch(plugin_id):
            raise ValueError("plugin id 格式不正确")
        try:
            api = int(raw.get("api") or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError("插件 API 版本不正确") from exc
        if api != PLUGIN_API:
            raise ValueError("插件 API 版本不兼容")
        entry = str(raw.get("entrypoint") or "").strip()
        if not entry or Path(entry).is_absolute():
            raise ValueError("entrypoint 必须是插件目录内的相对路径")
        entrypoint = (folder / entry).resolve()
        if not _inside(entrypoint, folder) or entrypoint.suffix.lower() != ".py":
            raise ValueError("entrypoint 越界或不是 Python 文件")
        if not entrypoint.is_file():
            raise ValueError("entrypoint 文件不存在")
        caps = tuple(
            sorted({
                str(item).strip().lower()
                for item in (raw.get("capabilities") or [])
                if str(item).strip()
            })
        )
        unknown = set(caps) - ALLOWED_CAPABILITIES
        if unknown:
            raise ValueError("未知插件能力：" + ", ".join(sorted(unknown)))
        permissions = tuple(
            sorted({
                str(item).strip().lower()
                for item in (raw.get("permissions") or [])
                if str(item).strip()
            })
        )
        unknown_permissions = set(permissions) - ALLOWED_PERMISSIONS
        if unknown_permissions:
            raise ValueError(
                "未知插件权限：" + ", ".join(sorted(unknown_permissions))
            )
        return PluginRecord(
            id=plugin_id,
            name=str(raw.get("name") or plugin_id)[:80],
            version=str(raw.get("version") or "0.0.0")[:40],
            api=PLUGIN_API,
            entrypoint=entrypoint,
            capabilities=caps,
            permissions=permissions,
            source=manifest_path,
            description=str(raw.get("description") or "")[:500],
        )

    def discover(self) -> dict[str, PluginRecord]:
        """Read manifests from `<root>/<plugin>/plugin.json`."""
        found: dict[str, PluginRecord] = {}
        if not self.root.is_dir():
            self._records = {}
            return {}
        root = self.root.resolve()
        for folder in sorted(self.root.iterdir(), key=lambda item: item.name):
            if (not folder.is_dir() or folder.name.startswith((".", "_"))
                    or folder.is_symlink() or not _inside(folder, root)):
                continue
            manifest_path = folder / "plugin.json"
            if not manifest_path.is_file() or manifest_path.is_symlink():
                continue
            try:
                raw = json.loads(manifest_path.read_text(encoding="utf-8"))
                record = self._record(folder, manifest_path, raw)
                if record.id in found:
                    raise ValueError("plugin id 重复")
                found[record.id] = record
            except Exception as exc:  # noqa: BLE001
                record = PluginRecord(
                    id=folder.name[:64],
                    name=folder.name[:80],
                    version="0",
                    api=0,
                    entrypoint=manifest_path,
                    capabilities=(),
                    permissions=(),
                    source=manifest_path,
                    error=str(exc)[:240],
                )
                found[record.id] = record
        self._records = found
        return dict(found)

    def status(self, *, enabled: set[str] | None = None) -> list[dict[str, Any]]:
        active = set(enabled or ())
        rows = []
        for record in self.discover().values():
            item = record.public()
            item["enabled"] = record.id in active
            item["loaded"] = record.id in self._modules
            rows.append(item)
        rows.sort(key=lambda item: (bool(item.get("error")), item["id"]))
        return rows

    def load(self, plugin_id: str, *, context: Any) -> ModuleType:
        """Load one validated plugin and call its `register(context)` hook."""
        if plugin_id not in self._records:
            self.discover()
        record = self._records.get(str(plugin_id))
        if record is None or record.error:
            raise ValueError("插件不存在或清单无效")
        if plugin_id in self._modules:
            return self._modules[plugin_id]
        module_name = "findeck_plugin_" + re.sub(r"[^a-z0-9_]", "_", plugin_id)
        spec = importlib.util.spec_from_file_location(module_name, record.entrypoint)
        if spec is None or spec.loader is None:
            raise ValueError("无法创建插件模块")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
            hook = getattr(module, "register", None)
            if callable(hook):
                hook(context)
        except Exception:
            sys.modules.pop(module_name, None)
            raise
        self._modules[plugin_id] = module
        return module

    def unload(self, plugin_id: str, *, context: Any | None = None) -> None:
        """Call optional lifecycle hooks and remove the plugin module."""
        plugin_id = str(plugin_id)
        module = self._modules.pop(plugin_id, None)
        if module is None:
            return
        for hook_name in ("deactivate", "unregister"):
            hook = getattr(module, hook_name, None)
            if not callable(hook):
                continue
            try:
                hook(context)
            except Exception:
                # One plugin's cleanup bug must not keep it resident.
                pass
        module_name = getattr(module, "__name__", "")
        if module_name:
            sys.modules.pop(module_name, None)

    def load_enabled(self, enabled: set[str], *, context: Any) -> dict[str, str]:
        """Load only explicitly enabled plugins; report failures without crashing core."""
        if not self._records:
            self.discover()
        loaded: dict[str, str] = {}
        for plugin_id in sorted(set(enabled)):
            try:
                self.load(plugin_id, context=context)
                loaded[plugin_id] = "loaded"
            except Exception as exc:  # noqa: BLE001
                loaded[plugin_id] = "error: " + str(exc)[:180]
        return loaded


class PluginContext:
    """Capability-restricted registration surface handed to one plugin."""

    def __init__(self, plugin_id: str, capabilities: set[str]) -> None:
        from features.voice_providers import PROVIDERS

        self.plugin_id = plugin_id
        self.capabilities = set(capabilities)
        self.providers = PROVIDERS
        self.commands: dict[str, Any] = {}
        self._stt: set[str] = set()
        self._tts: set[str] = set()

    def _require(self, capability: str) -> None:
        if capability not in self.capabilities:
            raise PermissionError(f"插件未声明 {capability} 能力")

    def register_stt(self, provider: Any) -> None:
        self._require("stt")
        name = str(provider.name)
        if name in self.providers.stt and name not in self._stt:
            raise ValueError("STT provider 名称已被占用")
        self.providers.register_stt(provider)
        self._stt.add(name)

    def register_tts(self, provider: Any) -> None:
        self._require("tts")
        name = str(provider.name)
        if name in self.providers.tts and name not in self._tts:
            raise ValueError("TTS provider 名称已被占用")
        self.providers.register_tts(provider)
        self._tts.add(name)

    def register_command(self, name: str, handler: Any) -> None:
        self._require("command")
        clean = str(name or "").strip()
        if not clean or not callable(handler):
            raise ValueError("命令名称或处理函数无效")
        if clean in self.commands:
            raise ValueError("插件命令名称重复")
        self.commands[clean] = handler

    def cleanup(self) -> None:
        for name in self._stt:
            self.providers.unregister_stt(name)
        for name in self._tts:
            self.providers.unregister_tts(name)
        self._stt.clear()
        self._tts.clear()
        self.commands.clear()


class PluginHost(PluginRollbackMixin):
    """Product-facing lifecycle manager. Installation never enables execution."""

    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root) if root is not None else _default_root()
        self.registry = PluginRegistry(self.root)
        self._lock = threading.RLock()
        self._contexts: dict[str, PluginContext] = {}
        self._enabled: set[str] = set()
        self._errors: dict[str, str] = {}
        self._started = False
        self._state_path = self.root / "plugins-state.json"
        self._publisher_path = self.root / "trusted-publishers.bin"
        self._trash = self.root / ".trash"
        self._market_client: Any | None = None

    def _load_state(self) -> None:
        try:
            raw = json.loads(self._state_path.read_text(encoding="utf-8"))
            enabled = raw.get("enabled") if isinstance(raw, dict) else []
            self._enabled = {
                str(item) for item in (enabled or [])
                if _PLUGIN_ID.fullmatch(str(item))
            }
        except Exception:
            self._enabled = set()

    def _save_state(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        tmp = self._state_path.with_name(self._state_path.name + ".tmp")
        tmp.write_text(json.dumps({
            "version": 1,
            "enabled": sorted(self._enabled),
            "updated_at": int(time.time()),
        }, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, self._state_path)

    def _load_publishers(self) -> dict[str, Any]:
        try:
            from features.secure_store import read_secure

            raw = json.loads(read_secure(self._publisher_path).decode("utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _save_publishers(self, data: dict[str, Any]) -> None:
        from features.secure_store import write_secure

        write_secure(
            self._publisher_path,
            json.dumps(data, ensure_ascii=False, sort_keys=True).encode("utf-8"),
        )

    def publishers(self) -> list[dict[str, Any]]:
        data = self._load_publishers()
        rows = []
        for publisher_id, record in sorted((data.get("publishers") or {}).items()):
            for key_id, key in sorted((record.get("keys") or {}).items()):
                rows.append({
                    "id": publisher_id,
                    "name": str(record.get("name") or publisher_id),
                    "key_id": key_id,
                    "public_key": key,
                    "trusted_at": int(record.get("trusted_at") or 0),
                })
        return rows

    def _publisher_trusted(self, publisher: dict[str, Any]) -> bool:
        publisher_id = str(publisher.get("id") or "")
        key_id = str(publisher.get("key_id") or "")
        record = (self._load_publishers().get("publishers") or {}).get(publisher_id)
        return bool(record and key_id in (record.get("keys") or {}))

    def trust_publisher(
        self,
        publisher: dict[str, Any],
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("信任插件发布者需要明确确认")
        publisher_id = str((publisher or {}).get("id") or "").strip()
        if not publisher_id:
            raise ValueError("发布者 ID 不能为空")
        public_key = normalize_public_key((publisher or {}).get("public_key") or {})
        key_id = public_key_id(public_key)
        with self._lock:
            data = self._load_publishers()
            publishers = data.setdefault("publishers", {})
            record = publishers.setdefault(publisher_id, {
                "name": str(publisher.get("name") or publisher_id)[:100],
                "keys": {},
                "trusted_at": int(time.time()),
            })
            record["name"] = str(
                publisher.get("name") or record.get("name") or publisher_id
            )[:100]
            record.setdefault("keys", {})[key_id] = public_key
            data["version"] = 1
            self._save_publishers(data)
        return {
            "ok": True,
            "publisher": {
                "id": publisher_id,
                "name": record["name"],
                "key_id": key_id,
                "public_key": public_key,
            },
            "publishers": self.publishers(),
        }

    def trust_plugin(self, plugin_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("信任插件发布者需要明确确认")
        with self._lock:
            if not self._records:
                self.registry.discover()
            record = self.registry._records.get(str(plugin_id))
            if record is None or record.error:
                raise ValueError("插件不存在或清单无效")
            signature = self._signature_state(record.source.parent)
            if not signature.get("signed") or not signature.get("valid"):
                raise ValueError(signature.get("error") or "插件签名无效")
            return self.trust_publisher(
                signature["publisher"], confirm=True
            )

    def untrust_publisher(self, publisher_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("撤销发布者信任需要明确确认")
        with self._lock:
            data = self._load_publishers()
            publishers = data.get("publishers") or {}
            if str(publisher_id) not in publishers:
                raise ValueError("发布者不在信任列表中")
            publishers.pop(str(publisher_id), None)
            data["publishers"] = publishers
            data["version"] = 1
            self._save_publishers(data)
        return {"ok": True, "publishers": self.publishers()}

    def _signature_state(self, folder: Path) -> dict[str, Any]:
        state = verify_plugin(folder)
        if state.get("signed") and state.get("valid"):
            state["trusted"] = self._publisher_trusted(state.get("publisher") or {})
        return state

    def _seal(self, folder: Path, record: PluginRecord) -> dict[str, Any]:
        digest = _tree_digest(folder)
        from features.app_security import SECURITY

        publisher_signature = self._signature_state(folder)
        signature_path = folder / ".findeck-signature.json"
        signature_digest = (
            hashlib.sha256(signature_path.read_bytes()).hexdigest()
            if signature_path.is_file() else ""
        )
        integrity = digest + ":" + signature_digest if signature_digest else digest
        local_signature = SECURITY.sign_payload(
            f"plugin:{record.id}:{record.version}", integrity.encode("ascii")
        )
        seal = {
            "format": "FINDECK-PLUGIN-SEAL-1",
            "id": record.id,
            "version": record.version,
            "tree_sha256": digest,
            "signature": local_signature,
            "installed_at": int(time.time()),
            "permissions": list(record.permissions),
            "publisher": publisher_signature.get("publisher") or {},
        }
        if signature_digest:
            seal["publisher_signature_sha256"] = signature_digest
        return seal

    def _verify_seal(self, folder: Path, record: PluginRecord) -> tuple[bool, str]:
        try:
            meta = json.loads((folder / PLUGIN_SEAL_FILE).read_text(encoding="utf-8"))
            if meta.get("format") != "FINDECK-PLUGIN-SEAL-1":
                return False, "安装签名格式不正确"
            if meta.get("id") != record.id or meta.get("version") != record.version:
                return False, "清单与安装签名不一致"
            digest = _tree_digest(folder)
            if digest != meta.get("tree_sha256"):
                return False, "插件文件在安装后被修改"
            signature_digest = ""
            if "publisher_signature_sha256" in meta:
                signature_path = folder / ".findeck-signature.json"
                if not signature_path.is_file():
                    return False, "发布者签名文件在安装后被移除"
                signature_digest = hashlib.sha256(
                    signature_path.read_bytes()
                ).hexdigest()
                if signature_digest != meta.get("publisher_signature_sha256"):
                    return False, "发布者签名文件在安装后被修改"
            from features.app_security import SECURITY

            signed_digest = (
                digest + ":" + signature_digest
                if "publisher_signature_sha256" in meta else digest
            )
            ok = SECURITY.verify_payload(
                f"plugin:{record.id}:{record.version}",
                signed_digest.encode("ascii"),
                str(meta.get("signature") or ""),
            )
            return (True, "") if ok else (False, "安装签名无效或本机密钥已更换")
        except Exception as exc:  # noqa: BLE001
            return False, str(exc)[:180]

    def _row(self, record: PluginRecord) -> dict[str, Any]:
        item = record.public()
        folder = record.source.parent
        sealed, seal_error = self._verify_seal(folder, record)
        publisher_signature = self._signature_state(folder)
        item.update({
            "enabled": record.id in self._enabled,
            "loaded": record.id in self._contexts,
            "sealed": sealed,
            "error": record.error or seal_error,
            "last_error": self._errors.get(record.id, ""),
            "publisher_signature": publisher_signature,
            "publisher": publisher_signature.get("publisher") or {},
        })
        rollback = self._rollback_candidate(
            record.id,
            current_version=record.version,
        )
        item["rollback_available"] = rollback is not None
        item["rollback_version"] = (
            rollback[1].version if rollback is not None else ""
        )
        return item

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            self.registry.discover()
            rows = [self._row(record) for record in self.registry._records.values()]
            rows.sort(key=lambda item: (bool(item["error"]), item["id"]))
            return {
                "ok": True,
                "api": PLUGIN_API,
                "root": str(self.root),
                "allowed_capabilities": sorted(ALLOWED_CAPABILITIES),
                "allowed_permissions": sorted(ALLOWED_PERMISSIONS),
                "plugins": rows,
                "publishers": self.publishers(),
                "started": self._started,
            }

    def start(self) -> dict[str, Any]:
        with self._lock:
            if self._started:
                return self.snapshot()
            self.root.mkdir(parents=True, exist_ok=True)
            self._load_state()
            self.registry.discover()
            for plugin_id in sorted(self._enabled):
                try:
                    self._enable_locked(plugin_id)
                except Exception as exc:  # noqa: BLE001
                    self._errors[plugin_id] = str(exc)[:240]
            self._started = True
            return self.snapshot()

    def _enable_locked(self, plugin_id: str) -> dict[str, Any]:
        if plugin_id in self._contexts:
            self._enabled.add(plugin_id)
            return self._row(self.registry._records[plugin_id])
        record = self.registry._records.get(plugin_id)
        if record is None or record.error:
            raise ValueError("插件不存在或清单无效")
        sealed, why = self._verify_seal(record.source.parent, record)
        if not sealed:
            raise ValueError("插件未通过本机安装签名：" + why)
        publisher_signature = self._signature_state(record.source.parent)
        if publisher_signature.get("signed") and not publisher_signature.get("valid"):
            raise ValueError(
                "插件发布者签名无效：" + str(publisher_signature.get("error") or "")
            )
        context = PluginContext(plugin_id, set(record.capabilities))
        try:
            module = self.registry.load(plugin_id, context=context)
            activate = getattr(module, "activate", None)
            if callable(activate):
                activate(context)
        except Exception:
            context.cleanup()
            self.registry.unload(plugin_id, context=context)
            raise
        self._contexts[plugin_id] = context
        self._enabled.add(plugin_id)
        self._errors.pop(plugin_id, None)
        return self._row(record)

    def enable(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            result = self._enable_locked(str(plugin_id))
            try:
                self._save_state()
            except Exception:
                self._disable_locked(str(plugin_id))
                raise
            return result

    def _disable_locked(self, plugin_id: str) -> None:
        context = self._contexts.pop(plugin_id, None)
        if context is not None:
            try:
                self.registry.unload(plugin_id, context=context)
            finally:
                context.cleanup()
        self._enabled.discard(plugin_id)

    def disable(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            self._save_state()
            self.registry.discover()
            record = self.registry._records.get(plugin_id)
            if record is None:
                return {"id": plugin_id, "enabled": False}
            return self._row(record)

    def reload(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            try:
                result = self._enable_locked(plugin_id)
                self._save_state()
                return result
            except Exception as exc:
                self._errors[plugin_id] = str(exc)[:240]
                self._enabled.discard(plugin_id)
                self._save_state()
                raise

    def remove(self, plugin_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("移除插件需要明确确认")
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            self.registry.discover()
            record = self.registry._records.get(plugin_id)
            if record is None:
                raise ValueError("插件不存在")
            folder = record.source.parent
            self._trash.mkdir(parents=True, exist_ok=True)
            target = self._trash / f"{plugin_id}-{time.time_ns()}"
            os.replace(folder, target)
            self._errors.pop(plugin_id, None)
            self._save_state()
            self.registry.discover()
            return {"id": plugin_id, "removed": True, "recoverable_at": str(target)}

    @staticmethod
    def _safe_archive(raw: bytes) -> dict[str, bytes]:
        if not raw or len(raw) > PLUGIN_ARCHIVE_MAX:
            raise ValueError("插件包为空或超过 8 MB")
        files: dict[str, bytes] = {}
        total = 0
        actual_total = 0
        try:
            archive = zipfile.ZipFile(io.BytesIO(raw))
        except zipfile.BadZipFile as exc:
            raise ValueError("插件包不是有效的 ZIP") from exc
        with archive:
            entries = archive.infolist()
            if len(entries) > PLUGIN_FILES_MAX:
                raise ValueError("插件包文件数量过多")
            for info in entries:
                name = info.filename.replace("\\", "/")
                path = PurePosixPath(name)
                if (not name or name.startswith("/") or ".." in path.parts
                        or ":" in path.parts[0]):
                    raise ValueError("插件包包含越界路径")
                mode = (int(info.external_attr) >> 16) & 0o170000
                if mode == 0o120000:
                    raise ValueError("插件包不能包含符号链接")
                if int(info.flag_bits) & 0x1:
                    raise ValueError("插件包不能包含加密文件")
                if info.is_dir():
                    continue
                total += int(info.file_size)
                if total > PLUGIN_TREE_MAX or int(info.file_size) > PLUGIN_ARCHIVE_MAX:
                    raise ValueError("插件解压后体积超过限制")
                try:
                    chunks: list[bytes] = []
                    actual = 0
                    with archive.open(info) as source:
                        while True:
                            chunk = source.read(256 * 1024)
                            if not chunk:
                                break
                            actual += len(chunk)
                            actual_total += len(chunk)
                            if actual > PLUGIN_ARCHIVE_MAX:
                                raise ValueError("插件单个文件解压后过大")
                            if actual_total > PLUGIN_TREE_MAX:
                                raise ValueError("插件解压后总体积超过限制")
                            chunks.append(chunk)
                    files[name] = b"".join(chunks)
                except Exception as exc:  # noqa: BLE001
                    if isinstance(exc, ValueError):
                        raise
                    raise ValueError("插件包内容损坏") from exc
        return files

    def install_archive(
        self,
        raw: bytes,
        *,
        confirmed_permissions: set[str] | None = None,
        require_signature: bool = False,
        allowed_publishers: set[str] | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            self.start()
            files = self._safe_archive(raw)
            manifest_candidates = [
                name for name in files
                if name == "plugin.json" or name.endswith("/plugin.json")
            ]
            if len(manifest_candidates) != 1:
                raise ValueError("插件包必须只有一个 plugin.json")
            manifest_name = manifest_candidates[0]
            base = manifest_name[:-len("plugin.json")]
            if base and base.count("/") != 1:
                raise ValueError("插件包只能有一个顶层目录")
            temp_root = Path(tempfile.mkdtemp(prefix=".staging-", dir=self.root))
            staging = temp_root / "plugin"
            staging.mkdir()
            try:
                for name, content in files.items():
                    if not name.startswith(base):
                        raise ValueError("插件包包含清单目录之外的文件")
                    rel = name[len(base):]
                    if not rel:
                        continue
                    target = staging / PurePosixPath(rel)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(content)
                manifest_path = staging / "plugin.json"
                raw_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                record = self.registry._record(staging, manifest_path, raw_manifest)
                publisher_signature = self._signature_state(staging)
                if require_signature and (
                    not publisher_signature.get("signed")
                    or not publisher_signature.get("valid")
                ):
                    raise ValueError(
                        "插件市场只接受有效发布者签名："
                        + str(publisher_signature.get("error") or "签名无效")
                    )
                publisher = publisher_signature.get("publisher") or {}
                if allowed_publishers and publisher.get("id") not in allowed_publishers:
                    raise ValueError("插件发布者不在市场目录允许的范围内")
                required = set(record.permissions)
                confirmed = set(confirmed_permissions or ())
                if confirmed != required:
                    return {
                        "ok": False,
                        "needs_confirmation": True,
                        "plugin": {
                            "id": record.id,
                            "name": record.name,
                            "version": record.version,
                            "description": record.description,
                            "capabilities": list(record.capabilities),
                            "permissions": list(record.permissions),
                            "publisher_signature": publisher_signature,
                            "publisher": publisher,
                        },
                    }
                if require_signature and not publisher_signature.get("trusted"):
                    return {
                        "ok": False,
                        "needs_trust": True,
                        "plugin": {
                            "id": record.id,
                            "name": record.name,
                            "version": record.version,
                            "permissions": list(record.permissions),
                            "publisher_signature": publisher_signature,
                            "publisher": publisher,
                        },
                    }
                self.registry.discover()
                destination = self.root / record.id
                backup = None
                was_enabled = record.id in self._contexts
                if destination.exists():
                    self._disable_locked(record.id)
                    self._trash.mkdir(parents=True, exist_ok=True)
                    backup = self._trash / f"{record.id}-{time.time_ns()}"
                    os.replace(destination, backup)
                try:
                    os.replace(staging, destination)
                    seal = self._seal(destination, record)
                    (destination / PLUGIN_SEAL_FILE).write_text(
                        json.dumps(seal, ensure_ascii=False, indent=1),
                        encoding="utf-8",
                    )
                    self.registry.discover()
                    installed = self.registry._records.get(record.id)
                    if installed is None:
                        raise ValueError("插件安装后无法重新读取")
                    self._enabled.discard(record.id)
                    self._save_state()
                    result = self._row(installed)
                    result["ok"] = True
                    result["installed"] = True
                    return result
                except Exception:
                    if destination.exists():
                        shutil.rmtree(destination, ignore_errors=True)
                    if backup is not None and backup.exists():
                        os.replace(backup, destination)
                        self.registry.discover()
                        if was_enabled:
                            try:
                                self._enable_locked(record.id)
                            except Exception:
                                pass
                        self._save_state()
                    raise
            finally:
                shutil.rmtree(temp_root, ignore_errors=True)

    def run_command(self, name: str, *args: Any, **kwargs: Any) -> Any:
        clean = str(name or "").strip()
        with self._lock:
            for context in self._contexts.values():
                handler = context.commands.get(clean)
                if handler is not None:
                    return handler(*args, **kwargs)
        raise KeyError("插件命令不存在")

    def market(self) -> Any:
        if self._market_client is None:
            from features.plugin_market import PluginMarket

            self._market_client = PluginMarket(self)
        return self._market_client

    def market_snapshot(self) -> dict[str, Any]:
        return self.market().snapshot()


def _default_root() -> Path:
    configured = os.environ.get("FIN_DECK_PLUGIN_ROOT", "").strip()
    if configured:
        return Path(configured)
    try:
        import storage_paths

        return Path(storage_paths.DATA_ROOT) / "插件"
    except Exception:
        return Path(__file__).resolve().parent.parent / "插件"


PLUGIN_HOST = PluginHost()
