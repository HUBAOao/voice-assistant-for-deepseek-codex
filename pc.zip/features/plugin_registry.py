# -*- coding: utf-8 -*-
"""Versioned, opt-in plugin discovery and lifecycle management."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any

from features.plugin_archive import (
    PLUGIN_ARCHIVE_MAX,
    PLUGIN_FILES_MAX,
    PLUGIN_TREE_MAX,
    PluginArchiveMixin,
)
from features.plugin_loader import (
    ALLOWED_CAPABILITIES,
    ALLOWED_PERMISSIONS,
    PLUGIN_API,
    PLUGIN_ID,
    PluginRecord,
    PluginRegistry,
    inside,
)
from features.plugin_rollback import PluginRollbackMixin
from features.plugin_trust import (
    PLUGIN_SEAL_FILE,
    PluginTrustMixin,
    tree_digest_for,
)


_PLUGIN_ID = PLUGIN_ID


def _inside(path: Path, root: Path) -> bool:
    return inside(path, root)


def _tree_digest(folder: Path) -> str:
    return tree_digest_for(folder)


class PluginContext:
    """Capability-restricted registration surface handed to one plugin."""

    def __init__(self, plugin_id: str, capabilities: set[str]) -> None:
        from features.voice_providers import PROVIDERS

        self.plugin_id = plugin_id
        self.capabilities = set(capabilities)
        self.providers = PROVIDERS
        self.commands: dict[str, Any] = {}
        self._stt: set[str] = set()
        self._tts: set[str] = set()

    def _require(self, capability: str) -> None:
        if capability not in self.capabilities:
            raise PermissionError(f"插件未声明 {capability} 能力")

    def register_stt(self, provider: Any) -> None:
        self._require("stt")
        name = str(provider.name)
        if name in self.providers.stt and name not in self._stt:
            raise ValueError("STT provider 名称已被占用")
        self.providers.register_stt(provider)
        self._stt.add(name)

    def register_tts(self, provider: Any) -> None:
        self._require("tts")
        name = str(provider.name)
        if name in self.providers.tts and name not in self._tts:
            raise ValueError("TTS provider 名称已被占用")
        self.providers.register_tts(provider)
        self._tts.add(name)

    def register_command(self, name: str, handler: Any) -> None:
        self._require("command")
        clean = str(name or "").strip()
        if not clean or not callable(handler):
            raise ValueError("命令名称或处理函数无效")
        if clean in self.commands:
            raise ValueError("插件命令名称重复")
        self.commands[clean] = handler

    def cleanup(self) -> None:
        for name in self._stt:
            self.providers.unregister_stt(name)
        for name in self._tts:
            self.providers.unregister_tts(name)
        self._stt.clear()
        self._tts.clear()
        self.commands.clear()


class PluginHost(
    PluginTrustMixin,
    PluginArchiveMixin,
    PluginRollbackMixin,
):
    """Product-facing lifecycle manager. Installation never enables execution."""

    def __init__(self, root: str | Path | None = None) -> None:
        self.root = Path(root) if root is not None else _default_root()
        self.registry = PluginRegistry(self.root)
        self._lock = threading.RLock()
        self._contexts: dict[str, PluginContext] = {}
        self._enabled: set[str] = set()
        self._errors: dict[str, str] = {}
        self._started = False
        self._state_path = self.root / "plugins-state.json"
        self._publisher_path = self.root / "trusted-publishers.bin"
        self._trash = self.root / ".trash"
        self._market_client: Any | None = None

    def _load_state(self) -> None:
        try:
            raw = json.loads(self._state_path.read_text(encoding="utf-8"))
            enabled = raw.get("enabled") if isinstance(raw, dict) else []
            self._enabled = {
                str(item)
                for item in (enabled or [])
                if PLUGIN_ID.fullmatch(str(item))
            }
        except Exception:
            self._enabled = set()

    def _save_state(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        target = self._state_path.with_name(self._state_path.name + ".tmp")
        target.write_text(
            json.dumps(
                {
                    "version": 1,
                    "enabled": sorted(self._enabled),
                    "updated_at": int(time.time()),
                },
                ensure_ascii=False,
                indent=1,
            ),
            encoding="utf-8",
        )
        os.replace(target, self._state_path)

    def _row(self, record: PluginRecord) -> dict[str, Any]:
        item = record.public()
        folder = record.source.parent
        sealed, seal_error = self._verify_seal(folder, record)
        publisher_signature = self._signature_state(folder)
        item.update(
            {
                "enabled": record.id in self._enabled,
                "loaded": record.id in self._contexts,
                "sealed": sealed,
                "error": record.error or seal_error,
                "last_error": self._errors.get(record.id, ""),
                "publisher_signature": publisher_signature,
                "publisher": publisher_signature.get("publisher") or {},
            }
        )
        rollback = self._rollback_candidate(
            record.id,
            current_version=record.version,
        )
        item["rollback_available"] = rollback is not None
        item["rollback_version"] = (
            rollback[1].version if rollback is not None else ""
        )
        return item

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            self.registry.discover()
            rows = [
                self._row(record)
                for record in self.registry._records.values()
            ]
            rows.sort(key=lambda item: (bool(item["error"]), item["id"]))
            return {
                "ok": True,
                "api": PLUGIN_API,
                "root": str(self.root),
                "allowed_capabilities": sorted(ALLOWED_CAPABILITIES),
                "allowed_permissions": sorted(ALLOWED_PERMISSIONS),
                "plugins": rows,
                "publishers": self.publishers(),
                "started": self._started,
            }

    def start(self) -> dict[str, Any]:
        with self._lock:
            if self._started:
                return self.snapshot()
            self.root.mkdir(parents=True, exist_ok=True)
            self._load_state()
            self.registry.discover()
            for plugin_id in sorted(self._enabled):
                try:
                    self._enable_locked(plugin_id)
                except Exception as error:
                    self._errors[plugin_id] = str(error)[:240]
            self._started = True
            return self.snapshot()

    def _enable_locked(self, plugin_id: str) -> dict[str, Any]:
        if plugin_id in self._contexts:
            self._enabled.add(plugin_id)
            return self._row(self.registry._records[plugin_id])
        record = self.registry._records.get(plugin_id)
        if record is None or record.error:
            raise ValueError("插件不存在或清单无效")
        sealed, error = self._verify_seal(record.source.parent, record)
        if not sealed:
            raise ValueError("插件未通过本机安装签名：" + error)
        publisher_signature = self._signature_state(record.source.parent)
        if (
            publisher_signature.get("signed")
            and not publisher_signature.get("valid")
        ):
            raise ValueError(
                "插件发布者签名无效："
                + str(publisher_signature.get("error") or "")
            )
        context = PluginContext(plugin_id, set(record.capabilities))
        try:
            module = self.registry.load(plugin_id, context=context)
            activate = getattr(module, "activate", None)
            if callable(activate):
                activate(context)
        except Exception:
            context.cleanup()
            self.registry.unload(plugin_id, context=context)
            raise
        self._contexts[plugin_id] = context
        self._enabled.add(plugin_id)
        self._errors.pop(plugin_id, None)
        return self._row(record)

    def enable(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            result = self._enable_locked(str(plugin_id))
            try:
                self._save_state()
            except Exception:
                self._disable_locked(str(plugin_id))
                raise
            return result

    def _disable_locked(self, plugin_id: str) -> None:
        context = self._contexts.pop(plugin_id, None)
        if context is not None:
            try:
                self.registry.unload(plugin_id, context=context)
            finally:
                context.cleanup()
        self._enabled.discard(plugin_id)

    def disable(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            self._save_state()
            self.registry.discover()
            record = self.registry._records.get(plugin_id)
            if record is None:
                return {"id": plugin_id, "enabled": False}
            return self._row(record)

    def reload(self, plugin_id: str) -> dict[str, Any]:
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            try:
                result = self._enable_locked(plugin_id)
                self._save_state()
                return result
            except Exception as error:
                self._errors[plugin_id] = str(error)[:240]
                self._enabled.discard(plugin_id)
                self._save_state()
                raise

    def run_command(self, name: str, *args: Any, **kwargs: Any) -> Any:
        clean = str(name or "").strip()
        with self._lock:
            for context in self._contexts.values():
                handler = context.commands.get(clean)
                if handler is not None:
                    return handler(*args, **kwargs)
        raise KeyError("插件命令不存在")

    def market(self) -> Any:
        if self._market_client is None:
            from features.plugin_market import PluginMarket

            self._market_client = PluginMarket(self)
        return self._market_client

    def market_snapshot(self) -> dict[str, Any]:
        return self.market().snapshot()


def _default_root() -> Path:
    configured = os.environ.get("FIN_DECK_PLUGIN_ROOT", "").strip()
    if configured:
        return Path(configured)
    try:
        import storage_paths

        return Path(storage_paths.DATA_ROOT) / "插件"
    except Exception:
        return Path(__file__).resolve().parent.parent / "插件"


PLUGIN_HOST = PluginHost()


__all__ = [
    "ALLOWED_CAPABILITIES",
    "ALLOWED_PERMISSIONS",
    "PLUGIN_API",
    "PLUGIN_ARCHIVE_MAX",
    "PLUGIN_FILES_MAX",
    "PLUGIN_HOST",
    "PLUGIN_SEAL_FILE",
    "PLUGIN_TREE_MAX",
    "PluginContext",
    "PluginHost",
    "PluginRecord",
    "PluginRegistry",
]
