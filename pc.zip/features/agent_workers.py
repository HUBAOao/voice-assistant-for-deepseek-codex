# -*- coding: utf-8 -*-
"""Local Codex worker and Git worktree orchestration."""
from __future__ import annotations

import json
import re
import subprocess
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class WorktreeRecord:
    path: Path
    head: str
    branch: str = ""
    detached: bool = False


@dataclass
class AgentJob:
    id: str
    prompt: str
    cwd: str
    status: str = "queued"
    created_at: float = field(default_factory=time.time)
    started_at: float = 0.0
    finished_at: float = 0.0
    exit_code: int | None = None
    output: str = ""
    error: str = ""


def _safe_name(name: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9._-]+", "-", str(name or "").strip()).strip("-")
    return (value or "agent")[:48]


class WorktreeManager:
    def __init__(self, repo: Path, root: Path | None = None) -> None:
        self.repo = Path(repo).resolve()
        self.root = Path(root or (self.repo / ".worktrees")).resolve()

    def _git(self, *args: str, timeout: float = 30.0) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.repo),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )

    def list(self) -> list[WorktreeRecord]:
        proc = self._git("worktree", "list", "--porcelain")
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "git worktree list failed")
        records = []
        current: dict[str, Any] = {}
        for line in (proc.stdout or "").splitlines() + [""]:
            if not line:
                if current.get("worktree"):
                    records.append(WorktreeRecord(
                        path=Path(current["worktree"]),
                        head=str(current.get("HEAD") or ""),
                        branch=str(current.get("branch") or "").removeprefix("refs/heads/"),
                        detached=str(current.get("detached") or "") == "detached",
                    ))
                current = {}
                continue
            key, _, value = line.partition(" ")
            current[key] = value
        return records

    def create(self, name: str, *, base: str = "HEAD") -> WorktreeRecord:
        path = self.root / _safe_name(name)
        if path.exists():
            raise FileExistsError(str(path))
        self.root.mkdir(parents=True, exist_ok=True)
        proc = self._git("worktree", "add", "--detach", str(path), base, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "git worktree add failed")
        for record in self.list():
            if record.path.resolve() == path.resolve():
                return record
        return WorktreeRecord(path=path, head="", detached=True)


def codex_exec_command(*, cwd: str, sandbox: str = "workspace-write",
                       model: str = "", extra: list[str] | None = None) -> list[str]:
    cmd = ["codex", "exec", "--json", "-C", str(cwd), "-s", sandbox]
    if model:
        cmd.extend(["-m", model])
    if extra:
        cmd.extend(str(item) for item in extra)
    cmd.append("-")
    return cmd


class AgentPool:
    """Bounded local Codex worker pool; jobs never start without submit()."""

    def __init__(self, max_workers: int = 3) -> None:
        self.max_workers = max(1, min(10, int(max_workers)))
        self._sem = threading.BoundedSemaphore(self.max_workers)
        self._lock = threading.RLock()
        self._jobs: dict[str, AgentJob] = {}
        self._threads: dict[str, threading.Thread] = {}

    def submit(self, prompt: str, *, cwd: str, model: str = "",
               sandbox: str = "workspace-write") -> AgentJob:
        job = AgentJob(id="job_" + uuid.uuid4().hex[:16], prompt=str(prompt),
                       cwd=str(Path(cwd).resolve()))
        with self._lock:
            self._jobs[job.id] = job
        thread = threading.Thread(target=self._run, args=(job, model, sandbox), daemon=True)
        self._threads[job.id] = thread
        thread.start()
        return job

    def _run(self, job: AgentJob, model: str, sandbox: str) -> None:
        with self._sem:
            job.status = "running"
            job.started_at = time.time()
            try:
                proc = subprocess.Popen(
                    codex_exec_command(cwd=job.cwd, sandbox=sandbox, model=model),
                    cwd=job.cwd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                output, _ = proc.communicate(job.prompt, timeout=6 * 3600)
                job.exit_code = proc.returncode
                job.output = str(output or "")[-30000:]
                job.status = "succeeded" if proc.returncode == 0 else "failed"
            except Exception as exc:  # noqa: BLE001
                job.error = str(exc)[:1000]
                job.status = "failed"
            finally:
                job.finished_at = time.time()

    def get(self, job_id: str) -> AgentJob | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return AgentJob(**asdict(job)) if job else None

    def list(self) -> list[AgentJob]:
        with self._lock:
            return [AgentJob(**asdict(job)) for job in self._jobs.values()]

    def wait(self, job_id: str, timeout: float = 30.0) -> AgentJob | None:
        thread = self._threads.get(job_id)
        if thread:
            thread.join(max(0.0, timeout))
        return self.get(job_id)

