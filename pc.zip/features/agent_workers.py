# -*- coding: utf-8 -*-
"""Local Codex worker and Git worktree orchestration."""
from __future__ import annotations

import json
import os
import re
import subprocess
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class WorktreeRecord:
    path: Path
    head: str
    branch: str = ""
    detached: bool = False


@dataclass
class AgentJob:
    id: str
    prompt: str
    cwd: str
    status: str = "queued"
    created_at: float = field(default_factory=time.time)
    started_at: float = 0.0
    finished_at: float = 0.0
    exit_code: int | None = None
    output: str = ""
    error: str = ""


def _safe_name(name: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9._-]+", "-", str(name or "").strip()).strip("-")
    return (value or "agent")[:48]


class WorktreeManager:
    def __init__(self, repo: Path, root: Path | None = None) -> None:
        self.repo = Path(repo).resolve()
        self.root = Path(root or (self.repo / ".worktrees")).resolve()

    def _git(self, *args: str, timeout: float = 30.0) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=str(self.repo),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )

    def list(self) -> list[WorktreeRecord]:
        proc = self._git("worktree", "list", "--porcelain")
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "git worktree list failed")
        records = []
        current: dict[str, Any] = {}
        for line in (proc.stdout or "").splitlines() + [""]:
            if not line:
                if current.get("worktree"):
                    records.append(WorktreeRecord(
                        path=Path(current["worktree"]),
                        head=str(current.get("HEAD") or ""),
                        branch=str(current.get("branch") or "").removeprefix("refs/heads/"),
                        detached=str(current.get("detached") or "") == "detached",
                    ))
                current = {}
                continue
            key, _, value = line.partition(" ")
            current[key] = value
        return records

    def create(self, name: str, *, base: str = "HEAD") -> WorktreeRecord:
        path = self.root / _safe_name(name)
        if path.exists():
            raise FileExistsError(str(path))
        self.root.mkdir(parents=True, exist_ok=True)
        proc = self._git("worktree", "add", "--detach", str(path), base, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "git worktree add failed")
        for record in self.list():
            if record.path.resolve() == path.resolve():
                return record
        return WorktreeRecord(path=path, head="", detached=True)

    def remove(self, path: str | Path, *, force: bool = False) -> None:
        """Remove only a managed, clean worktree."""
        target = Path(path).resolve()
        if not target.is_relative_to(self.root):
            raise ValueError("只能移除鳍舱管理的 worktree")
        records = {item.path.resolve(): item for item in self.list()}
        if target == self.repo or target not in records:
            raise ValueError("worktree 不存在或不受管理")
        if not force:
            proc = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=str(target), capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=20,
            )
            if proc.returncode != 0 or (proc.stdout or "").strip():
                raise RuntimeError("worktree 有未提交改动，拒绝自动移除")
        args = ["worktree", "remove"]
        if force:
            args.append("--force")
        args.append(str(target))
        proc = self._git(*args, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(proc.stderr.strip() or "git worktree remove failed")


def codex_exec_command(*, cwd: str, sandbox: str = "workspace-write",
                       model: str = "", extra: list[str] | None = None) -> list[str]:
    cmd = ["codex", "exec", "--json", "-C", str(cwd), "-s", sandbox]
    if model:
        cmd.extend(["-m", model])
    if extra:
        cmd.extend(str(item) for item in extra)
    cmd.append("-")
    return cmd


class AgentPool:
    """Bounded local Codex worker pool; jobs never start without submit()."""

    def __init__(self, max_workers: int = 3) -> None:
        self.max_workers = max(1, min(10, int(max_workers)))
        self._sem = threading.BoundedSemaphore(self.max_workers)
        self._lock = threading.RLock()
        self._jobs: dict[str, AgentJob] = {}
        self._threads: dict[str, threading.Thread] = {}

    def submit(self, prompt: str, *, cwd: str, model: str = "",
               sandbox: str = "workspace-write") -> AgentJob:
        job = AgentJob(id="job_" + uuid.uuid4().hex[:16], prompt=str(prompt),
                       cwd=str(Path(cwd).resolve()))
        with self._lock:
            self._jobs[job.id] = job
        thread = threading.Thread(target=self._run, args=(job, model, sandbox), daemon=True)
        self._threads[job.id] = thread
        thread.start()
        return job

    def _run(self, job: AgentJob, model: str, sandbox: str) -> None:
        with self._sem:
            job.status = "running"
            job.started_at = time.time()
            try:
                proc = subprocess.Popen(
                    codex_exec_command(cwd=job.cwd, sandbox=sandbox, model=model),
                    cwd=job.cwd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                output, _ = proc.communicate(job.prompt, timeout=6 * 3600)
                job.exit_code = proc.returncode
                job.output = str(output or "")[-30000:]
                job.status = "succeeded" if proc.returncode == 0 else "failed"
            except Exception as exc:  # noqa: BLE001
                job.error = str(exc)[:1000]
                job.status = "failed"
            finally:
                job.finished_at = time.time()

    def get(self, job_id: str) -> AgentJob | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return AgentJob(**asdict(job)) if job else None

    def list(self) -> list[AgentJob]:
        with self._lock:
            return [AgentJob(**asdict(job)) for job in self._jobs.values()]

    def wait(self, job_id: str, timeout: float = 30.0) -> AgentJob | None:
        thread = self._threads.get(job_id)
        if thread:
            thread.join(max(0.0, timeout))
        return self.get(job_id)


class AgentOperations:
    """Safe public surface for bounded workers and managed worktrees."""

    def __init__(self, repo: Path) -> None:
        self.repo = Path(repo).resolve()
        self.worktrees = WorktreeManager(self.repo)
        self.pool = AgentPool(max_workers=3)

    def list(self) -> dict[str, Any]:
        trees = []
        for item in self.worktrees.list():
            trees.append({
                "path": str(item.path),
                "head": item.head[:12],
                "branch": item.branch,
                "detached": item.detached,
                "managed": item.path.resolve().is_relative_to(self.worktrees.root),
            })
        jobs = []
        for job in self.pool.list():
            value = asdict(job)
            value["output"] = value.get("output", "")[-8000:]
            jobs.append(value)
        jobs.sort(key=lambda item: item.get("created_at") or 0, reverse=True)
        return {
            "ok": True,
            "repo": str(self.repo),
            "worktree_root": str(self.worktrees.root),
            "max_workers": self.pool.max_workers,
            "worktrees": trees,
            "jobs": jobs,
        }

    def create_worktree(self, name: str, *, base: str = "HEAD") -> dict[str, Any]:
        record = self.worktrees.create(name, base=base)
        return {
            "path": str(record.path),
            "head": record.head,
            "branch": record.branch,
            "detached": record.detached,
        }

    def remove_worktree(self, path: str, *, force: bool = False) -> None:
        self.worktrees.remove(path, force=force)

    def _safe_cwd(self, raw: str = "") -> Path:
        target = Path(raw).resolve() if raw else self.repo
        if target != self.repo and not target.is_relative_to(self.worktrees.root):
            raise ValueError("Agent 只能跑在项目根或鳍舱管理的 worktree")
        if not target.is_dir():
            raise ValueError("Agent 工作目录不存在")
        return target

    def submit(self, prompt: str, *, cwd: str = "", model: str = "",
               sandbox: str = "workspace-write") -> dict[str, Any]:
        if not str(prompt or "").strip():
            raise ValueError("Agent 任务不能为空")
        if sandbox not in {"read-only", "workspace-write"}:
            raise ValueError("Agent 默认只允许只读或工作区写入沙箱")
        place = self._safe_cwd(cwd)
        job = self.pool.submit(str(prompt), cwd=str(place), model=model,
                               sandbox=sandbox)
        return asdict(job)

    def get(self, job_id: str) -> dict[str, Any] | None:
        job = self.pool.get(job_id)
        return asdict(job) if job else None


_OPS_LOCK = threading.RLock()
_OPS: AgentOperations | None = None


def operations() -> AgentOperations:
    global _OPS
    with _OPS_LOCK:
        if _OPS is None:
            configured = Path(os.environ.get("FIN_DECK_REPO", "")
                              or Path(__file__).resolve().parents[3])
            _OPS = AgentOperations(configured)
        return _OPS

