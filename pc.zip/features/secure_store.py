# -*- coding: utf-8 -*-
"""At-rest encryption with Windows DPAPI and portable OS-keyring backends."""
from __future__ import annotations

import base64
import ctypes
import hashlib
import hmac
import json
import os
import secrets
import shutil
import subprocess
import sys
from pathlib import Path

LEGACY_MAGIC = b"FDSEC1\n"
MAGIC = b"FDSEC2\n"
CRYPTPROTECT_UI_FORBIDDEN = 0x1
CRYPTPROTECT_LOCAL_MACHINE = 0x4
_KEYRING_CACHE: dict[str, bytes] = {}


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", ctypes.c_uint32),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def backend_name() -> str:
    if sys.platform == "win32":
        return "Windows DPAPI"
    if sys.platform == "darwin" and shutil.which("security"):
        return "macOS Keychain"
    if sys.platform.startswith("linux") and shutil.which("secret-tool"):
        return "Linux Secret Service"
    return "unavailable"


def available() -> bool:
    return backend_name() != "unavailable"


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(raw: str) -> bytes:
    return base64.urlsafe_b64decode(str(raw) + "=" * (-len(str(raw)) % 4))


def _blob(raw: bytes) -> tuple[_DATA_BLOB, ctypes.Array]:
    buf = ctypes.create_string_buffer(raw)
    return (
        _DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))),
        buf,
    )


def _dpapi(data: bytes, *, protect_data: bool) -> bytes:
    if sys.platform != "win32":
        raise RuntimeError("这份数据由 Windows DPAPI 加密，只能在原 Windows 用户下读取")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    source, keepalive = _blob(data)
    target = _DATA_BLOB()
    if protect_data:
        fn = crypt32.CryptProtectData
        ok = fn(
            ctypes.byref(source),
            ctypes.c_wchar_p("FinDeck local data"),
            None, None, None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(target),
        )
    else:
        fn = crypt32.CryptUnprotectData
        ok = fn(
            ctypes.byref(source), None, None, None, None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(target),
        )
    _ = keepalive
    if not ok:
        raise OSError(ctypes.get_last_error(), "DPAPI operation failed")
    try:
        return ctypes.string_at(target.pbData, target.cbData)
    finally:
        kernel32.LocalFree(target.pbData)


def _run_keyring(args: list[str], *, input_data: bytes | None = None) -> bytes:
    proc = subprocess.run(
        args,
        input=input_data,
        capture_output=True,
        timeout=8,
        check=False,
    )
    if proc.returncode != 0:
        message = (proc.stderr or proc.stdout or b"").decode("utf-8", "replace")
        raise RuntimeError(message.strip()[:240] or "系统密钥环不可用")
    return proc.stdout or b""


def _keyring_lookup() -> bytes:
    backend = backend_name()
    if backend == "macOS Keychain":
        try:
            raw = _run_keyring([
                "security", "find-generic-password",
                "-s", "FinDeck",
                "-a", "secure-master",
                "-w",
            ])
        except RuntimeError:
            raw = b""
    elif backend == "Linux Secret Service":
        proc = subprocess.run(
            [
                "secret-tool", "lookup",
                "service", "FinDeck",
                "account", "secure-master",
            ],
            capture_output=True,
            timeout=8,
            check=False,
        )
        raw = proc.stdout if proc.returncode == 0 else b""
    else:
        raise RuntimeError("当前平台没有可用的系统密钥环")
    try:
        key = _unb64(raw.decode("ascii").strip())
    except Exception:
        key = b""
    return key if len(key) == 32 else b""


def _keyring_store(key: bytes) -> None:
    value = _b64(key)
    backend = backend_name()
    if backend == "macOS Keychain":
        _run_keyring([
            "security", "add-generic-password",
            "-U",
            "-s", "FinDeck",
            "-a", "secure-master",
            "-l", "FinDeck secure master key",
            "-w", value,
        ])
        return
    if backend == "Linux Secret Service":
        _run_keyring(
            [
                "secret-tool", "store",
                "--label", "FinDeck secure master key",
                "service", "FinDeck",
                "account", "secure-master",
            ],
            input_data=(value + "\n").encode("ascii"),
        )
        return
    raise RuntimeError("当前平台没有可用的系统密钥环")


def _master_key() -> bytes:
    backend = backend_name()
    if backend == "Windows DPAPI":
        raise RuntimeError("Windows 使用 DPAPI 直接保护数据，不创建独立主密钥")
    if backend in _KEYRING_CACHE:
        return _KEYRING_CACHE[backend]
    key = _keyring_lookup()
    if not key:
        key = secrets.token_bytes(32)
        _keyring_store(key)
    _KEYRING_CACHE[backend] = key
    return key


def _stream_xor(key: bytes, nonce: bytes, namespace: bytes, data: bytes) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < len(data):
        out.extend(hmac.new(
            key,
            namespace + nonce + counter.to_bytes(8, "big"),
            hashlib.sha256,
        ).digest())
        counter += 1
    return bytes(a ^ b for a, b in zip(data, out))


def _envelope_keys(master: bytes, nonce: bytes) -> tuple[bytes, bytes]:
    enc = hmac.new(master, b"FinDeck secure-store encryption" + nonce,
                   hashlib.sha256).digest()
    mac = hmac.new(master, b"FinDeck secure-store authentication" + nonce,
                   hashlib.sha256).digest()
    return enc, mac


def _encrypt_envelope(raw: bytes, master: bytes) -> bytes:
    if len(master) != 32:
        raise ValueError("加密主密钥长度不正确")
    nonce = secrets.token_bytes(16)
    enc, mac_key = _envelope_keys(master, nonce)
    ciphertext = _stream_xor(enc, nonce, b"FINSEC2-STREAM", raw)
    tag = hmac.new(
        mac_key,
        b"FINDECK-SECURE-STORE-2\x00" + nonce + ciphertext,
        hashlib.sha256,
    ).digest()
    body = json.dumps({
        "version": 2,
        "nonce": _b64(nonce),
        "ciphertext": _b64(ciphertext),
        "tag": _b64(tag),
        "backend": backend_name(),
    }, separators=(",", ":")).encode("ascii")
    return MAGIC + body


def _decrypt_envelope(raw: bytes, master: bytes) -> bytes:
    if not raw.startswith(MAGIC):
        raise ValueError("不是 FinDeck 安全存储 v2 数据")
    body = json.loads(raw[len(MAGIC):].decode("ascii"))
    if int(body.get("version") or 0) != 2:
        raise ValueError("安全存储版本不受支持")
    nonce = _unb64(str(body.get("nonce") or ""))
    ciphertext = _unb64(str(body.get("ciphertext") or ""))
    tag = _unb64(str(body.get("tag") or ""))
    if len(nonce) != 16 or len(tag) != 32 or len(master) != 32:
        raise ValueError("安全存储头部无效")
    enc, mac_key = _envelope_keys(master, nonce)
    expected = hmac.new(
        mac_key,
        b"FINDECK-SECURE-STORE-2\x00" + nonce + ciphertext,
        hashlib.sha256,
    ).digest()
    if not hmac.compare_digest(tag, expected):
        raise ValueError("安全存储校验失败，数据可能被篡改")
    return _stream_xor(enc, nonce, b"FINSEC2-STREAM", ciphertext)


def protect(raw: bytes, *, machine: bool = False) -> bytes:
    _ = machine
    if sys.platform == "win32":
        return LEGACY_MAGIC + _dpapi(raw, protect_data=True)
    return _encrypt_envelope(raw, _master_key())


def unprotect(raw: bytes) -> bytes:
    if raw.startswith(LEGACY_MAGIC):
        return _dpapi(raw[len(LEGACY_MAGIC):], protect_data=False)
    if raw.startswith(MAGIC):
        return _decrypt_envelope(raw, _master_key())
    raise ValueError("无法识别的安全存储格式")


def write_secure(path: Path, raw: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform != "win32":
        try:
            os.chmod(path.parent, 0o700)
        except OSError:
            pass
    payload = protect(raw)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(payload)
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, path)


def read_secure(path: Path) -> bytes:
    raw = Path(path).read_bytes()
    if raw.startswith((LEGACY_MAGIC, MAGIC)):
        return unprotect(raw)
    return raw
