# -*- coding: utf-8 -*-
"""At-rest encryption using Windows DPAPI, with explicit unsupported fallback."""
from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes
from pathlib import Path

MAGIC = b"FDSEC1\n"
CRYPTPROTECT_UI_FORBIDDEN = 0x1
CRYPTPROTECT_LOCAL_MACHINE = 0x4


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def available() -> bool:
    return sys.platform == "win32"


def _blob(raw: bytes) -> tuple[_DATA_BLOB, ctypes.Array]:
    buf = ctypes.create_string_buffer(raw)
    return (
        _DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))),
        buf,
    )


def _crypt(data: bytes, *, protect: bool) -> bytes:
    if not available():
        raise RuntimeError("当前平台没有可用的 DPAPI")
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    source, keepalive = _blob(data)
    target = _DATA_BLOB()
    if protect:
        fn = crypt32.CryptProtectData
        ok = fn(
            ctypes.byref(source),
            ctypes.c_wchar_p("FinDeck local data"),
            None, None, None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(target),
        )
    else:
        fn = crypt32.CryptUnprotectData
        ok = fn(
            ctypes.byref(source), None, None, None, None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(target),
        )
    _ = keepalive
    if not ok:
        raise OSError(ctypes.get_last_error(), "DPAPI operation failed")
    try:
        return ctypes.string_at(target.pbData, target.cbData)
    finally:
        kernel32.LocalFree(target.pbData)


def protect(raw: bytes, *, machine: bool = False) -> bytes:
    # CryptProtectData's scope is controlled by optional entropy; default user scope.
    # machine is retained in the API for future explicit scope implementation.
    _ = machine
    return _crypt(raw, protect=True)


def unprotect(raw: bytes) -> bytes:
    return _crypt(raw, protect=False)


def write_secure(path: Path, raw: bytes) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = MAGIC + protect(raw)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(payload)
    os.replace(tmp, path)


def read_secure(path: Path) -> bytes:
    raw = Path(path).read_bytes()
    if raw.startswith(MAGIC):
        return unprotect(raw[len(MAGIC):])
    return raw

