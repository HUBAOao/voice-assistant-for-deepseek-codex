# -*- coding: utf-8 -*-
"""Publisher trust, plugin seals, and signing verification."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

from features.plugin_loader import PluginRecord
from features.plugin_signing import (
    normalize_public_key,
    public_key_id,
    tree_digest,
    verify_plugin,
)


PLUGIN_SEAL_FILE = ".findeck-install.json"


def tree_digest_for(folder: Path) -> str:
    return tree_digest(folder)


class PluginTrustMixin:
    """Persist trusted publisher keys and verify local install seals."""

    def _load_publishers(self) -> dict[str, Any]:
        try:
            from features.secure_store import read_secure

            raw = json.loads(read_secure(self._publisher_path).decode("utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _save_publishers(self, data: dict[str, Any]) -> None:
        from features.secure_store import write_secure

        write_secure(
            self._publisher_path,
            json.dumps(data, ensure_ascii=False, sort_keys=True).encode("utf-8"),
        )

    def publishers(self) -> list[dict[str, Any]]:
        data = self._load_publishers()
        rows = []
        for publisher_id, record in sorted(
            (data.get("publishers") or {}).items()
        ):
            for key_id, key in sorted((record.get("keys") or {}).items()):
                rows.append(
                    {
                        "id": publisher_id,
                        "name": str(record.get("name") or publisher_id),
                        "key_id": key_id,
                        "public_key": key,
                        "trusted_at": int(record.get("trusted_at") or 0),
                    }
                )
        return rows

    def _publisher_trusted(self, publisher: dict[str, Any]) -> bool:
        publisher_id = str(publisher.get("id") or "")
        key_id = str(publisher.get("key_id") or "")
        record = (self._load_publishers().get("publishers") or {}).get(publisher_id)
        return bool(record and key_id in (record.get("keys") or {}))

    def trust_publisher(
        self,
        publisher: dict[str, Any],
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("信任插件发布者需要明确确认")
        publisher_id = str((publisher or {}).get("id") or "").strip()
        if not publisher_id:
            raise ValueError("发布者 ID 不能为空")
        public_key = normalize_public_key(
            (publisher or {}).get("public_key") or {}
        )
        key_id = public_key_id(public_key)
        with self._lock:
            data = self._load_publishers()
            publishers = data.setdefault("publishers", {})
            record = publishers.setdefault(
                publisher_id,
                {
                    "name": str(publisher.get("name") or publisher_id)[:100],
                    "keys": {},
                    "trusted_at": int(time.time()),
                },
            )
            record["name"] = str(
                publisher.get("name") or record.get("name") or publisher_id
            )[:100]
            record.setdefault("keys", {})[key_id] = public_key
            data["version"] = 1
            self._save_publishers(data)
        return {
            "ok": True,
            "publisher": {
                "id": publisher_id,
                "name": record["name"],
                "key_id": key_id,
                "public_key": public_key,
            },
            "publishers": self.publishers(),
        }

    def trust_plugin(
        self,
        plugin_id: str,
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("信任插件发布者需要明确确认")
        with self._lock:
            if not self._records:
                self.registry.discover()
            record = self.registry._records.get(str(plugin_id))
            if record is None or record.error:
                raise ValueError("插件不存在或清单无效")
            signature = self._signature_state(record.source.parent)
            if not signature.get("signed") or not signature.get("valid"):
                raise ValueError(signature.get("error") or "插件签名无效")
            return self.trust_publisher(
                signature["publisher"],
                confirm=True,
            )

    def untrust_publisher(
        self,
        publisher_id: str,
        *,
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("撤销发布者信任需要明确确认")
        with self._lock:
            data = self._load_publishers()
            publishers = data.get("publishers") or {}
            if str(publisher_id) not in publishers:
                raise ValueError("发布者不在信任列表中")
            publishers.pop(str(publisher_id), None)
            data["publishers"] = publishers
            data["version"] = 1
            self._save_publishers(data)
        return {"ok": True, "publishers": self.publishers()}

    def _signature_state(self, folder: Path) -> dict[str, Any]:
        state = verify_plugin(folder)
        if state.get("signed") and state.get("valid"):
            state["trusted"] = self._publisher_trusted(
                state.get("publisher") or {}
            )
        return state

    def _seal(self, folder: Path, record: PluginRecord) -> dict[str, Any]:
        digest = tree_digest_for(folder)
        from features.app_security import SECURITY

        publisher_signature = self._signature_state(folder)
        signature_path = folder / ".findeck-signature.json"
        signature_digest = (
            hashlib.sha256(signature_path.read_bytes()).hexdigest()
            if signature_path.is_file()
            else ""
        )
        integrity = (
            digest + ":" + signature_digest if signature_digest else digest
        )
        local_signature = SECURITY.sign_payload(
            f"plugin:{record.id}:{record.version}",
            integrity.encode("ascii"),
        )
        seal = {
            "format": "FINDECK-PLUGIN-SEAL-1",
            "id": record.id,
            "version": record.version,
            "tree_sha256": digest,
            "signature": local_signature,
            "installed_at": int(time.time()),
            "permissions": list(record.permissions),
            "publisher": publisher_signature.get("publisher") or {},
        }
        if signature_digest:
            seal["publisher_signature_sha256"] = signature_digest
        return seal

    def _verify_seal(
        self,
        folder: Path,
        record: PluginRecord,
    ) -> tuple[bool, str]:
        try:
            meta = json.loads(
                (folder / PLUGIN_SEAL_FILE).read_text(encoding="utf-8")
            )
            if meta.get("format") != "FINDECK-PLUGIN-SEAL-1":
                return False, "安装签名格式不正确"
            if meta.get("id") != record.id or meta.get("version") != record.version:
                return False, "清单与安装签名不一致"
            digest = tree_digest_for(folder)
            if digest != meta.get("tree_sha256"):
                return False, "插件文件在安装后被修改"
            signature_digest = ""
            if "publisher_signature_sha256" in meta:
                signature_path = folder / ".findeck-signature.json"
                if not signature_path.is_file():
                    return False, "发布者签名文件在安装后被移除"
                signature_digest = hashlib.sha256(
                    signature_path.read_bytes()
                ).hexdigest()
                if signature_digest != meta.get("publisher_signature_sha256"):
                    return False, "发布者签名文件在安装后被修改"
            from features.app_security import SECURITY

            signed_digest = (
                digest + ":" + signature_digest
                if "publisher_signature_sha256" in meta
                else digest
            )
            ok = SECURITY.verify_payload(
                f"plugin:{record.id}:{record.version}",
                signed_digest.encode("ascii"),
                str(meta.get("signature") or ""),
            )
            return (True, "") if ok else (False, "安装签名无效或本机密钥已更换")
        except Exception as error:
            return False, str(error)[:180]
