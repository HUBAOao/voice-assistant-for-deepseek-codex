# -*- coding: utf-8 -*-
"""Archive, unarchive, and permanently delete Codex threads."""
from __future__ import annotations

import os
import tempfile
import time
from pathlib import Path
from urllib.parse import quote

from features import codex_app_server
from features.codex_thread_actions import (
    _open_deeplink,
    current_thread_id,
    open_thread,
)
from features.codex_thread_catalog import list_threads
from features.codex_ui_bridge import run_with_name


def _label_file(prefix: str, labels: list[str]) -> Path:
    path = Path(tempfile.gettempdir()) / ("va-%s-%s.txt" % (prefix, os.getpid()))
    path.write_text("\n".join(labels), encoding="utf-8")
    return path


def _ui_manage(
    action: str,
    name: str,
    menu: list[str],
    confirm: list[str] | None = None,
) -> tuple[bool, str]:
    menu_file = _label_file("thread-menu", menu)
    args = ["-Action", action, "-MenuFile", str(menu_file)]
    if confirm:
        confirm_file = _label_file("thread-confirm", confirm)
        args += ["-ConfirmFile", str(confirm_file)]
    ok, output = run_with_name(name, args, timeout=35.0)
    if not ok:
        return False, output[:120]
    if "CLICKED_MENU" in output or "ARCHIVE_SENT" in output or "CONFIRMED" in output:
        return True, output[-40:]
    if "CONFIRM_NOT_FOUND" in output:
        return False, "桌面对话框里没找到删除确认按钮"
    if "NOT_FOUND" in output:
        return False, "电脑端没有找到这条会话"
    return False, output[:120]


def _row_by_id(thread_id: str) -> dict | None:
    return next(
        (row for row in list_threads() if row.get("id") == thread_id),
        None,
    )


def _restore_thread(row: dict | None) -> None:
    if not row or row.get("archived"):
        return
    try:
        if current_thread_id() != str(row.get("id") or ""):
            open_thread(str(row.get("name") or ""), str(row.get("id") or ""))
    except Exception:
        pass


def archive_thread(
    thread_id: str,
    archived: bool = True,
    name: str = "",
) -> tuple[bool, str]:
    row = _row_by_id(thread_id)
    name = str(name or (row or {}).get("name") or "").strip()
    if archived:
        if not name:
            return False, "没找到会话名"
        previous = next(
            (item for item in list_threads() if item.get("current")),
            None,
        )
        if current_thread_id() != thread_id:
            ok, message = open_thread(name, thread_id)
            if not ok:
                return False, message
        ok, message = _ui_manage("archivecurrent", name, [])
        if not ok:
            _restore_thread(previous)
            return False, message
        time.sleep(0.35)
        changed = _row_by_id(thread_id)
        _restore_thread(previous)
        if changed is None or not changed.get("archived"):
            return False, "电脑端没有确认归档成功"
        return True, "已归档"

    previous = next(
        (item for item in list_threads() if item.get("current")),
        None,
    )
    if not _open_deeplink(quote(thread_id, safe="")):
        return False, "打不开已归档会话"
    time.sleep(0.65)
    ok, message = _ui_manage(
        "unarchive",
        name,
        [
            "Unarchive and open",
            "Unarchive this chat",
            "Unarchive chat",
            "取消归档聊天",
            "取消归档",
        ],
    )
    if not ok:
        return False, message
    time.sleep(0.45)
    changed = _row_by_id(thread_id)
    if changed is None or changed.get("archived"):
        _restore_thread(previous)
        return False, "电脑端没有确认取消归档成功"
    _restore_thread(previous)
    return True, "已取消归档"


def delete_thread(thread_id: str, name: str = "") -> tuple[bool, str]:
    row = _row_by_id(thread_id)
    name = str(name or (row or {}).get("name") or "").strip()
    if not name:
        return False, "没找到会话名"
    previous = next(
        (item for item in list_threads() if item.get("current")),
        None,
    )
    try:
        codex_app_server._rpc("thread/delete", {"threadId": thread_id})
    except Exception:
        ok, message = archive_thread(thread_id, True, name)
        if not ok:
            _restore_thread(previous)
            return False, message
        try:
            codex_app_server._rpc("thread/delete", {"threadId": thread_id})
        except Exception as error:
            _restore_thread(previous)
            return False, "会话已归档，但永久删除失败：" + str(error)[:90]
    time.sleep(0.45)
    if _row_by_id(thread_id) is not None:
        _restore_thread(previous)
        return False, "电脑端没有确认删除成功"
    _restore_thread(previous)
    return True, "会话已永久删除"
