# -*- coding: utf-8 -*-
"""Atomic, sealed plugin rollback without expanding the registry core."""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path
from typing import Any


class PluginRollbackMixin:
    """Mixin for PluginHost; all transaction state stays inside the host lock."""

    def _rollback_candidate(
        self,
        plugin_id: str,
        *,
        current_version: str = "",
    ) -> tuple[Path, Any] | None:
        folder = self._trash
        if not folder.is_dir():
            return None
        prefix = str(plugin_id) + "-"
        candidates: list[tuple[int, Path, Any]] = []
        for item in folder.iterdir():
            name = item.name
            suffix = name[len(prefix):] if name.startswith(prefix) else ""
            if (
                not suffix.isdigit()
                or not item.is_dir()
                or item.is_symlink()
            ):
                continue
            manifest_path = item / "plugin.json"
            if not manifest_path.is_file() or manifest_path.is_symlink():
                continue
            try:
                raw = json.loads(manifest_path.read_text(encoding="utf-8"))
                record = self.registry._record(item, manifest_path, raw)
                if record.error or record.id != plugin_id:
                    continue
                if current_version and record.version == current_version:
                    continue
                sealed, _ = self._verify_seal(item, record)
                if sealed:
                    candidates.append((int(suffix), item, record))
            except Exception:  # noqa: BLE001
                continue
        if not candidates:
            return None
        _, path, record = max(candidates, key=lambda item: item[0])
        return path, record

    def rollback(self, plugin_id: str, *, confirm: bool = False) -> dict[str, Any]:
        """Restore the newest valid previous version and keep it disabled."""
        if confirm is not True:
            raise ValueError("回滚插件需要明确确认")
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self.registry.discover()
            record = self.registry._records.get(plugin_id)
            if record is None or record.error:
                raise ValueError("插件不存在或清单无效")
            candidate = self._rollback_candidate(
                plugin_id,
                current_version=record.version,
            )
            if candidate is None:
                raise ValueError("没有通过本机签名校验的可回滚版本")
            backup_path, backup_record = candidate
            destination = record.source.parent
            self._disable_locked(plugin_id)
            self._trash.mkdir(parents=True, exist_ok=True)
            displaced = self._trash / f"{plugin_id}-{time.time_ns()}"
            from_version = record.version
            os.replace(destination, displaced)
            try:
                os.replace(backup_path, destination)
                self.registry.discover()
                restored = self.registry._records.get(plugin_id)
                if restored is None or restored.error:
                    raise ValueError("回滚后的插件清单无法读取")
                sealed, why = self._verify_seal(destination, restored)
                if not sealed:
                    raise ValueError("回滚后的插件未通过本机签名：" + why)
                self._enabled.discard(plugin_id)
                self._errors.pop(plugin_id, None)
                self._save_state()
                result = self._row(restored)
                result.update({
                    "ok": True,
                    "rolled_back": True,
                    "from_version": from_version,
                    "to_version": backup_record.version,
                })
                return result
            except Exception:
                if destination.exists():
                    shutil.rmtree(destination, ignore_errors=True)
                if displaced.exists():
                    os.replace(displaced, destination)
                self.registry.discover()
                raise
