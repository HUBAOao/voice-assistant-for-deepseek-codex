# -*- coding: utf-8 -*-
"""Low-latency turn state and barge-in primitives for voice conversations."""
from __future__ import annotations

import difflib
import re
import threading
import time
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class DuplexEvent:
    kind: str
    at: float
    detail: str = ""


class STTProvider(Protocol):
    def transcribe(self, audio): ...


class TTSProvider(Protocol):
    def speak(self, text: str, *, interruptable: bool = True): ...

    def stop(self) -> None: ...


def normalized(text: str) -> str:
    return re.sub(r"[\s，,。.！!？?；;：:、]+", "", str(text or "")).lower()


def likely_echo(text: str, reference: str, *, threshold: float = 0.72) -> bool:
    """Detect a transcript that is probably the assistant's own TTS output."""
    a, b = normalized(text), normalized(reference)
    if len(a) < 4 or len(b) < 4:
        return False
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    if len(short) >= 8 and short in long_:
        return True
    return difflib.SequenceMatcher(None, a, b).ratio() >= float(threshold)


class DuplexController:
    """Track user/assistant turns and detect sustained speech during playback."""

    def __init__(self, *, barge_threshold: float = 0.06,
                 speech_frames: int = 4) -> None:
        self.barge_threshold = float(barge_threshold)
        self.speech_frames = max(1, int(speech_frames))
        self._lock = threading.RLock()
        self._above = 0
        self.assistant_text = ""
        self.assistant_speaking = False
        self.user_speaking = False
        self.started_at = 0.0
        self.events: list[DuplexEvent] = []

    def _event(self, kind: str, detail: str = "") -> DuplexEvent:
        event = DuplexEvent(kind, time.time(), str(detail)[:300])
        self.events.append(event)
        if len(self.events) > 200:
            del self.events[:-200]
        return event

    def assistant_start(self, text: str) -> DuplexEvent:
        with self._lock:
            self.assistant_text = str(text or "")
            self.assistant_speaking = True
            self.started_at = time.time()
            self._above = 0
            return self._event("assistant_start", self.assistant_text)

    def assistant_stop(self) -> DuplexEvent:
        with self._lock:
            self.assistant_speaking = False
            self.assistant_text = ""
            self._above = 0
            return self._event("assistant_stop")

    def user_interrupt(self) -> DuplexEvent:
        with self._lock:
            self.user_speaking = False
            self.assistant_speaking = False
            self.assistant_text = ""
            self._above = 0
            return self._event("user_interrupt")

    def audio_frame(self, level: float) -> DuplexEvent | None:
        """Consume one audio level and return a barge-in event when sustained."""
        with self._lock:
            if not self.assistant_speaking:
                self._above = 0
                return None
            self._above = self._above + 1 if float(level) >= self.barge_threshold else 0
            if self._above < self.speech_frames:
                return None
            self._above = 0
            self.user_speaking = True
            self.assistant_speaking = False
            return self._event("barge_in", f"level={float(level):.3f}")

    def accept_transcript(self, text: str) -> tuple[bool, str]:
        """Mark a transcript as accepted or rejected as assistant echo."""
        with self._lock:
            if self.assistant_speaking and likely_echo(text, self.assistant_text):
                self._event("echo_rejected", text)
                return False, "echo"
            self.user_speaking = False
            self._event("transcript", text)
            return True, "accepted"


DUPLEX = DuplexController()

