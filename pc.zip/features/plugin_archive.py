# -*- coding: utf-8 -*-
"""Safe plugin ZIP inspection and transactional installation."""
from __future__ import annotations

import io
import json
import os
import shutil
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from features.plugin_loader import PluginRecord
from features.plugin_trust import PLUGIN_SEAL_FILE


PLUGIN_ARCHIVE_MAX = 8 * 1024 * 1024
PLUGIN_TREE_MAX = 24 * 1024 * 1024
PLUGIN_FILES_MAX = 240


class PluginArchiveMixin:
    """Reject unsafe archives and swap validated plugin folders atomically."""

    @staticmethod
    def _safe_archive(raw: bytes) -> dict[str, bytes]:
        if not raw or len(raw) > PLUGIN_ARCHIVE_MAX:
            raise ValueError("插件包为空或超过 8 MB")
        files: dict[str, bytes] = {}
        total = 0
        actual_total = 0
        try:
            archive = zipfile.ZipFile(io.BytesIO(raw))
        except zipfile.BadZipFile as error:
            raise ValueError("插件包不是有效的 ZIP") from error
        with archive:
            entries = archive.infolist()
            if len(entries) > PLUGIN_FILES_MAX:
                raise ValueError("插件包文件数量过多")
            for info in entries:
                name = info.filename.replace("\\", "/")
                path = PurePosixPath(name)
                if (
                    not name
                    or name.startswith("/")
                    or ".." in path.parts
                    or ":" in path.parts[0]
                ):
                    raise ValueError("插件包包含越界路径")
                mode = (int(info.external_attr) >> 16) & 0o170000
                if mode == 0o120000:
                    raise ValueError("插件包不能包含符号链接")
                if int(info.flag_bits) & 0x1:
                    raise ValueError("插件包不能包含加密文件")
                if info.is_dir():
                    continue
                total += int(info.file_size)
                if total > PLUGIN_TREE_MAX or int(info.file_size) > PLUGIN_ARCHIVE_MAX:
                    raise ValueError("插件解压后体积超过限制")
                try:
                    chunks: list[bytes] = []
                    actual = 0
                    with archive.open(info) as source:
                        while True:
                            chunk = source.read(256 * 1024)
                            if not chunk:
                                break
                            actual += len(chunk)
                            actual_total += len(chunk)
                            if actual > PLUGIN_ARCHIVE_MAX:
                                raise ValueError("插件单个文件解压后过大")
                            if actual_total > PLUGIN_TREE_MAX:
                                raise ValueError("插件解压后总体积超过限制")
                            chunks.append(chunk)
                    files[name] = b"".join(chunks)
                except Exception as error:
                    if isinstance(error, ValueError):
                        raise
                    raise ValueError("插件包内容损坏") from error
        return files

    def remove(self, plugin_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("移除插件需要明确确认")
        with self._lock:
            self.start()
            plugin_id = str(plugin_id)
            self._disable_locked(plugin_id)
            self.registry.discover()
            record = self.registry._records.get(plugin_id)
            if record is None:
                raise ValueError("插件不存在")
            folder = record.source.parent
            self._trash.mkdir(parents=True, exist_ok=True)
            target = self._trash / f"{plugin_id}-{time.time_ns()}"
            os.replace(folder, target)
            self._errors.pop(plugin_id, None)
            self._save_state()
            self.registry.discover()
            return {
                "id": plugin_id,
                "removed": True,
                "recoverable_at": str(target),
            }

    def install_archive(
        self,
        raw: bytes,
        *,
        confirmed_permissions: set[str] | None = None,
        require_signature: bool = False,
        allowed_publishers: set[str] | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            self.start()
            files = self._safe_archive(raw)
            manifests = [
                name
                for name in files
                if name == "plugin.json" or name.endswith("/plugin.json")
            ]
            if len(manifests) != 1:
                raise ValueError("插件包必须只有一个 plugin.json")
            manifest_name = manifests[0]
            base = manifest_name[: -len("plugin.json")]
            if base and base.count("/") != 1:
                raise ValueError("插件包只能有一个顶层目录")
            temp_root = Path(tempfile.mkdtemp(prefix=".staging-", dir=self.root))
            staging = temp_root / "plugin"
            staging.mkdir()
            try:
                for name, content in files.items():
                    if not name.startswith(base):
                        raise ValueError("插件包包含清单目录之外的文件")
                    relative = name[len(base) :]
                    if not relative:
                        continue
                    target = staging / PurePosixPath(relative)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(content)
                manifest_path = staging / "plugin.json"
                raw_manifest = json.loads(
                    manifest_path.read_text(encoding="utf-8")
                )
                record = self.registry._record(
                    staging,
                    manifest_path,
                    raw_manifest,
                )
                publisher_signature = self._signature_state(staging)
                if require_signature and (
                    not publisher_signature.get("signed")
                    or not publisher_signature.get("valid")
                ):
                    raise ValueError(
                        "插件市场只接受有效发布者签名："
                        + str(publisher_signature.get("error") or "签名无效")
                    )
                publisher = publisher_signature.get("publisher") or {}
                if (
                    allowed_publishers
                    and publisher.get("id") not in allowed_publishers
                ):
                    raise ValueError("插件发布者不在市场目录允许的范围内")
                required = set(record.permissions)
                confirmed = set(confirmed_permissions or ())
                if confirmed != required:
                    return {
                        "ok": False,
                        "needs_confirmation": True,
                        "plugin": {
                            "id": record.id,
                            "name": record.name,
                            "version": record.version,
                            "description": record.description,
                            "capabilities": list(record.capabilities),
                            "permissions": list(record.permissions),
                            "publisher_signature": publisher_signature,
                            "publisher": publisher,
                        },
                    }
                if require_signature and not publisher_signature.get("trusted"):
                    return {
                        "ok": False,
                        "needs_trust": True,
                        "plugin": {
                            "id": record.id,
                            "name": record.name,
                            "version": record.version,
                            "permissions": list(record.permissions),
                            "publisher_signature": publisher_signature,
                            "publisher": publisher,
                        },
                    }
                return self._install_staging(record, staging)
            finally:
                shutil.rmtree(temp_root, ignore_errors=True)

    def _install_staging(
        self,
        record: PluginRecord,
        staging: Path,
    ) -> dict[str, Any]:
        self.registry.discover()
        destination = self.root / record.id
        backup = None
        was_enabled = record.id in self._contexts
        if destination.exists():
            self._disable_locked(record.id)
            self._trash.mkdir(parents=True, exist_ok=True)
            backup = self._trash / f"{record.id}-{time.time_ns()}"
            os.replace(destination, backup)
        try:
            os.replace(staging, destination)
            seal = self._seal(destination, record)
            (destination / PLUGIN_SEAL_FILE).write_text(
                json.dumps(seal, ensure_ascii=False, indent=1),
                encoding="utf-8",
            )
            self.registry.discover()
            installed = self.registry._records.get(record.id)
            if installed is None:
                raise ValueError("插件安装后无法重新读取")
            self._enabled.discard(record.id)
            self._save_state()
            result = self._row(installed)
            result["ok"] = True
            result["installed"] = True
            return result
        except Exception:
            if destination.exists():
                shutil.rmtree(destination, ignore_errors=True)
            if backup is not None and backup.exists():
                os.replace(backup, destination)
                self.registry.discover()
                if was_enabled:
                    try:
                        self._enable_locked(record.id)
                    except Exception:
                        pass
                self._save_state()
            raise
