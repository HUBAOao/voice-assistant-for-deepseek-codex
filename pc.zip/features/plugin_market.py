# -*- coding: utf-8 -*-
"""HTTPS plugin catalog discovery with signed-package enforcement."""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from features.plugin_registry import PluginHost

CATALOG_FORMAT = "FINDECK-PLUGIN-CATALOG-1"
MAX_CATALOG_BYTES = 512 * 1024
MAX_PACKAGE_BYTES = 8 * 1024 * 1024
_ID = "abcdefghijklmnopqrstuvwxyz0123456789.-"


def _fetch(url: str, limit: int) -> bytes:
    parsed = urllib.parse.urlparse(url)
    local_http = (
        parsed.scheme == "http"
        and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
        and os.environ.get("FIN_DECK_MARKET_ALLOW_HTTP") == "1"
    )
    if parsed.scheme != "https" and not local_http:
        raise ValueError("插件市场源必须使用 HTTPS")
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "FinDeck-Plugin-Market/1.0"},
    )
    with urllib.request.urlopen(request, timeout=12) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("插件市场响应超过体积限制")
    return raw


def _source_id(url: str) -> str:
    return hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]


def _clean_url(base: str, raw: Any) -> str:
    value = urllib.parse.urljoin(base, str(raw or "").strip())
    parsed = urllib.parse.urlparse(value)
    local_http = (
        parsed.scheme == "http"
        and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
        and os.environ.get("FIN_DECK_MARKET_ALLOW_HTTP") == "1"
    )
    if parsed.scheme != "https" and not local_http:
        raise ValueError("插件下载地址必须使用 HTTPS")
    return value


class PluginMarket:
    def __init__(self, host: "PluginHost") -> None:
        self.host = host
        self.root = Path(host.root)
        self.path = self.root / "plugin-market.json"
        self._lock = threading.RLock()

    def _load(self) -> dict[str, Any]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _save(self, data: dict[str, Any]) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True),
            encoding="utf-8",
        )
        os.replace(tmp, self.path)

    def _catalog(self, source: dict[str, Any]) -> dict[str, Any]:
        url = str(source.get("url") or "")
        raw = _fetch(url, MAX_CATALOG_BYTES)
        try:
            value = json.loads(raw.decode("utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise ValueError("市场目录不是有效 JSON") from exc
        if not isinstance(value, dict) or value.get("format") != CATALOG_FORMAT:
            raise ValueError("市场目录格式不受支持")
        plugins = value.get("plugins")
        if not isinstance(plugins, list) or len(plugins) > 500:
            raise ValueError("市场目录插件列表无效")
        clean = []
        seen = set()
        for item in plugins:
            if not isinstance(item, dict):
                continue
            plugin_id = str(item.get("id") or "").strip()
            version = str(item.get("version") or "").strip()
            publisher = str(item.get("publisher") or "").strip()
            digest = str(item.get("sha256") or "").strip().lower()
            if (not plugin_id or plugin_id in seen or len(plugin_id) > 64
                    or not version or not publisher or len(digest) != 64):
                continue
            if any(ch not in _ID for ch in plugin_id.lower()):
                continue
            try:
                download_url = _clean_url(url, item.get("url"))
            except ValueError:
                continue
            seen.add(plugin_id)
            clean.append({
                "id": plugin_id,
                "name": str(item.get("name") or plugin_id)[:80],
                "version": version[:40],
                "description": str(item.get("description") or "")[:500],
                "publisher": publisher[:80],
                "key_id": str(item.get("key_id") or "")[:100],
                "sha256": digest,
                "url": download_url,
                "permissions": sorted({
                    str(x)[:40] for x in (item.get("permissions") or [])
                    if str(x).strip()
                }),
            })
        return {
            "format": CATALOG_FORMAT,
            "name": str(value.get("name") or source.get("name") or "插件市场")[:80],
            "updated_at": int(value.get("updated_at") or time.time()),
            "plugins": clean,
            "sha256": hashlib.sha256(raw).hexdigest(),
        }

    def add_source(
        self,
        url: str,
        *,
        name: str = "",
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("添加插件市场源需要明确确认")
        url = str(url or "").strip()
        parsed = urllib.parse.urlparse(url)
        local_http = (
            parsed.scheme == "http"
            and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
            and os.environ.get("FIN_DECK_MARKET_ALLOW_HTTP") == "1"
        )
        if parsed.scheme != "https" and not local_http:
            raise ValueError("插件市场源必须使用 HTTPS")
        source = {
            "id": _source_id(url),
            "url": url,
            "name": str(name or parsed.hostname or "插件市场")[:80],
            "added_at": int(time.time()),
        }
        catalog = self._catalog(source)
        source.update({
            "name": catalog["name"],
            "catalog": catalog,
            "updated_at": int(time.time()),
            "error": "",
        })
        with self._lock:
            data = self._load()
            sources = data.setdefault("sources", {})
            sources[source["id"]] = source
            data["version"] = 1
            self._save(data)
        return {"ok": True, "source": self._public_source(source)}

    def refresh(self, source_id: str = "") -> dict[str, Any]:
        with self._lock:
            data = self._load()
            sources = data.get("sources") or {}
            targets = [source_id] if source_id else list(sources)
            for key in targets:
                source = sources.get(key)
                if not isinstance(source, dict):
                    continue
                try:
                    catalog = self._catalog(source)
                    source.update({
                        "name": catalog["name"],
                        "catalog": catalog,
                        "updated_at": int(time.time()),
                        "error": "",
                    })
                except Exception as exc:  # noqa: BLE001
                    source["error"] = str(exc)[:240]
            data["sources"] = sources
            data["version"] = 1
            self._save(data)
        return self.snapshot()

    def remove_source(self, source_id: str, *, confirm: bool = False) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("移除插件市场源需要明确确认")
        with self._lock:
            data = self._load()
            sources = data.get("sources") or {}
            if str(source_id) not in sources:
                raise ValueError("插件市场源不存在")
            sources.pop(str(source_id), None)
            data["sources"] = sources
            data["version"] = 1
            self._save(data)
        return self.snapshot()

    @staticmethod
    def _public_source(source: dict[str, Any]) -> dict[str, Any]:
        catalog = source.get("catalog") or {}
        return {
            "id": str(source.get("id") or ""),
            "name": str(source.get("name") or "插件市场"),
            "url": str(source.get("url") or ""),
            "updated_at": int(source.get("updated_at") or 0),
            "error": str(source.get("error") or ""),
            "catalog_sha256": str(catalog.get("sha256") or ""),
            "plugins": list(catalog.get("plugins") or []),
        }

    def snapshot(self) -> dict[str, Any]:
        data = self._load()
        sources = [
            self._public_source(source)
            for source in (data.get("sources") or {}).values()
            if isinstance(source, dict)
        ]
        sources.sort(key=lambda item: item["name"])
        return {
            "ok": True,
            "sources": sources,
            "plugin_count": sum(len(item["plugins"]) for item in sources),
            "requires_publisher_signature": True,
            "notice": "市场包必须带有效发布者签名；仍需先信任发布者并确认权限。",
        }

    def install(
        self,
        source_id: str,
        plugin_id: str,
        *,
        confirmed_permissions: set[str] | None = None,
        confirm: bool = False,
    ) -> dict[str, Any]:
        if confirm is not True:
            raise ValueError("安装市场插件需要明确确认")
        with self._lock:
            source = ((self._load().get("sources") or {}).get(str(source_id)) or {})
            catalog = source.get("catalog") or {}
            item = next(
                (row for row in catalog.get("plugins") or []
                 if row.get("id") == str(plugin_id)),
                None,
            )
            if not item:
                raise ValueError("市场目录里没有这个插件")
            raw = _fetch(str(item["url"]), MAX_PACKAGE_BYTES)
            digest = hashlib.sha256(raw).hexdigest()
            if digest != item["sha256"]:
                raise ValueError("插件下载内容与市场校验值不一致")
            result = self.host.install_archive(
                raw,
                confirmed_permissions=confirmed_permissions,
                require_signature=True,
                allowed_publishers={str(item["publisher"])},
            )
            result["market"] = {
                "source": source_id,
                "plugin": plugin_id,
                "sha256": digest,
                "publisher": item["publisher"],
            }
            return result
