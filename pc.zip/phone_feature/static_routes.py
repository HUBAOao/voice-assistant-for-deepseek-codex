# -*- coding: utf-8 -*-
"""Static assets and binary downloads for the phone HTTP entry.

Authentication, device pairing and capability checks stay in ``phone_link``.
This module only resolves already-authenticated paths into an HTTP response.
"""
from __future__ import annotations

import json
import mimetypes
import urllib.parse
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class StaticResult:
    status: int
    body: bytes
    content_type: str
    headers: tuple[tuple[str, str], ...] = ()
    audit: tuple[str, str] | None = None


def _json_error(message: str, status: int = 404) -> StaticResult:
    return StaticResult(
        status,
        json.dumps(
            {"ok": False, "err": message},
            ensure_ascii=False,
        ).encode("utf-8"),
        "application/json; charset=utf-8",
    )


def _bytes_result(
    body: bytes,
    content_type: str,
    *,
    cache: str = "no-store",
    headers: tuple[tuple[str, str], ...] = (),
    audit: tuple[str, str] | None = None,
) -> StaticResult:
    return StaticResult(
        status=200,
        body=body,
        content_type=content_type,
        headers=(("Cache-Control", cache),) + headers,
        audit=audit,
    )


def get_route(
    path: str,
    query: dict[str, list[str]],
    *,
    page_bytes: Callable[[], bytes],
    phone_ui_root: Path,
    icon_png: Callable[[int], bytes],
    apk_file: Path,
    shot_path: Callable[[str], Path | None],
    local_image_path: Callable[[str], Path | None],
    audio_path: Callable[[str], Path | None],
    file_path: Callable[[str], Path | None],
    upload_path: Callable[[str], Path | None],
) -> StaticResult | None:
    """Resolve one authenticated static or binary GET request."""
    if path in ("/", "/index.html"):
        return _bytes_result(page_bytes(), "text/html; charset=utf-8")

    if path.startswith("/phone-assets/"):
        relative = path[len("/phone-assets/"):]
        try:
            base = phone_ui_root.resolve()
            asset = (phone_ui_root / relative).resolve()
            asset.relative_to(base)
        except Exception:
            asset = None
        if (
            asset is None
            or not asset.is_file()
            or asset.suffix.lower() not in {".js", ".css", ".json"}
        ):
            return _json_error("not found")
        content_type = mimetypes.guess_type(str(asset))[0] or "text/plain"
        return _bytes_result(
            asset.read_bytes(),
            content_type + "; charset=utf-8",
        )

    if path in ("/icon-192.png", "/icon.png", "/icon-512.png"):
        size = 512 if path == "/icon-512.png" else 192
        body = icon_png(size)
        if not body:
            return _json_error("no icon")
        return _bytes_result(body, "image/png", cache="max-age=86400")

    if path == "/sw.js":
        body = (
            "self.addEventListener('install', e => e.skipWaiting());\n"
            "self.addEventListener('activate', e => e.clients.claim());\n"
            "self.addEventListener('fetch', e => {});\n"
        ).encode("utf-8")
        return _bytes_result(
            body,
            "application/javascript; charset=utf-8",
        )

    if path in ("/app.apk", "/语音助手-手机端.apk"):
        if not apk_file.exists():
            return _json_error("这台电脑上还没有手机端安装包")
        return _bytes_result(
            apk_file.read_bytes(),
            "application/vnd.android.package-archive",
            headers=((
                "Content-Disposition",
                'attachment; filename="voice-assistant.apk"',
            ),),
        )

    resolver: Callable[[str], Path | None] | None = None
    name = ""
    if path.startswith("/shot/"):
        resolver = shot_path
        name = urllib.parse.unquote(path[len("/shot/"):])
        error = "no such shot"
    elif path == "/api/image":
        resolver = local_image_path
        name = (query.get("path") or [""])[0]
        error = "invalid image"
    elif path.startswith("/audio/"):
        resolver = audio_path
        name = urllib.parse.unquote(path[len("/audio/"):])
        error = "no such audio"
    elif path.startswith("/file/"):
        resolver = file_path
        name = urllib.parse.unquote(path[len("/file/"):])
        error = "no such file"
    elif path.startswith("/uploaded/"):
        resolver = upload_path
        name = urllib.parse.unquote(path[len("/uploaded/"):])
        error = "no such upload"
    else:
        return None

    try:
        target = resolver(name)
    except Exception:
        target = None
    if target is None:
        return _json_error(error)

    suffix = target.suffix.lower()
    content_type = {
        ".png": "image/png",
        ".webp": "image/webp",
        ".gif": "image/gif",
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".m4a": "audio/mp4",
        ".ogg": "audio/ogg",
        ".opus": "audio/ogg",
        ".aac": "audio/aac",
        ".flac": "audio/flac",
    }.get(suffix)
    content_type = content_type or (
        mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    )
    headers: list[tuple[str, str]] = []
    audit: tuple[str, str] | None = None
    if path.startswith("/shot/"):
        audit = ("看屏幕", name)
    elif path.startswith("/audio/"):
        audit = ("试听", target.name)
        quoted = urllib.parse.quote(target.name)
        headers.extend((
            ("Content-Disposition", f"inline; filename*=UTF-8''{quoted}"),
            ("Accept-Ranges", "none"),
        ))
    elif path.startswith("/file/"):
        audit = ("取文件", target.name)
        quoted = urllib.parse.quote(target.name)
        headers.append((
            "Content-Disposition",
            f"attachment; filename*=UTF-8''{quoted}",
        ))
        content_type = "application/octet-stream"
    return _bytes_result(
        target.read_bytes(),
        content_type,
        headers=tuple(headers),
        audit=audit,
    )
