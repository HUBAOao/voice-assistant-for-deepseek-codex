"""Request identity, pairing helpers and small HTTP framing primitives.

These functions deliberately do not own the HTTP server.  PhoneLink keeps route
dispatch and side effects while authentication and device identity stay
repeatable and testable here.
"""

from __future__ import annotations

import gzip
import json
import secrets
from dataclasses import dataclass
from typing import Callable


DEV_COOKIE = "va_dev"
MAX_REQUEST_BYTES = 200 * 1024 * 1024
GZIP_THRESHOLD = 600


@dataclass(frozen=True)
class CallerIdentity:
    address: str
    public: bool


@dataclass(frozen=True)
class DeviceIdentity:
    device_id: str
    fresh: bool
    set_cookie: str = ""


def caller_identity(peer: str, forwarded_for: str = "") -> CallerIdentity:
    """Use the proxy-appended X-Forwarded-For entry for public requests."""
    address = str(peer or "?")
    if address in ("127.0.0.1", "::1"):
        forwarded = [
            part.strip() for part in str(forwarded_for or "").split(",")
            if part.strip()
        ]
        if forwarded:
            return CallerIdentity(forwarded[-1], True)
    return CallerIdentity(address, False)


def supplied_token(query: dict, header: str = "") -> str:
    values = query.get("k") or [""]
    query_token = values[0] if values else ""
    return str(query_token or header or "")


def token_valid(supplied: str, expected: str) -> bool:
    return bool(supplied) and bool(expected) and secrets.compare_digest(
        str(supplied), str(expected)
    )


def device_cookie(device_id: str) -> str:
    return f"{DEV_COOKIE}={device_id}; Path=/; Max-Age=31536000; SameSite=Lax; HttpOnly"


def device_identity(
    cookie_header: str,
    user_agent: str,
    address: str,
    *,
    find_device: Callable[[str, str], str],
    new_device_id: Callable[[], str],
) -> DeviceIdentity:
    """Reuse a durable cookie or recognizable client instead of creating duplicates."""
    for part in str(cookie_header or "").split(";"):
        key, _, value = part.strip().partition("=")
        if key == DEV_COOKIE and value.strip():
            return DeviceIdentity(value.strip(), False)
    known = str(find_device(str(user_agent or ""), str(address or "")) or "")
    if known:
        return DeviceIdentity(known, False)
    created = str(new_device_id() or "")
    return DeviceIdentity(created, True, device_cookie(created))


def pairing_api_response(api_request: bool, code: str) -> tuple[int, dict] | None:
    """Return the JSON rejection for API calls; page requests keep their HTML page."""
    if not api_request:
        return None
    return 403, {"ok": False, "err": "pairing", "code": str(code or "")}


def request_length(raw_length: str, maximum: int = MAX_REQUEST_BYTES) -> int:
    """Return a safe body length, or zero for invalid/oversized requests."""
    try:
        value = int(raw_length or 0)
    except (TypeError, ValueError):
        return 0
    return value if 0 < value <= int(maximum) else 0


def json_object(raw: bytes) -> dict:
    try:
        value = json.loads(raw or b"{}")
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def encoded_response(
    body: bytes,
    accept_encoding: str = "",
    *,
    threshold: int = GZIP_THRESHOLD,
) -> tuple[bytes, str]:
    """Compress large responses when the client advertises gzip."""
    if "gzip" not in str(accept_encoding or "").lower() or len(body) <= threshold:
        return body, ""
    try:
        return gzip.compress(body, 6), "gzip"
    except Exception:
        return body, ""
