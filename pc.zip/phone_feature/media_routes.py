# -*- coding: utf-8 -*-
"""Phone media discovery, upload and voice-command routes."""
from __future__ import annotations

import time
import urllib.parse
from collections.abc import Callable
from pathlib import Path
from typing import Any


IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif"}
MAX_UPLOAD_BYTES = 200 * 1024 * 1024
MAX_VOICE_BYTES = 40 * 1024 * 1024


def get_route(path: str) -> tuple[int, dict] | None:
    """Return media list payloads; binary file responses stay in HTTP owner."""
    if path == "/api/shots":
        try:
            import screen_share

            items = screen_share.list_shots()
            display = screen_share.screen_info()
        except Exception:
            items = []
            display = {}
        return 200, {"ok": True, "items": items, "display": display}
    if path == "/api/files":
        try:
            import file_share

            items = file_share.list_files()
            uploads = file_share.list_uploads(5)
        except Exception:
            items, uploads = [], []
        return 200, {"ok": True, "items": items, "uploads": uploads}
    if path == "/api/audios":
        try:
            import file_share

            items = file_share.list_audios()
        except Exception:
            items = []
        return 200, {"ok": True, "items": items}
    return None


def post_route(
    path: str,
    query: dict[str, list[str]],
    raw: bytes,
    *,
    on_image: Callable[[Path], Any] | None = None,
    on_voice: Callable[[bytes], str] | None = None,
) -> tuple[int, dict, tuple[str, str] | None] | None:
    """Handle raw media POST bodies without coupling them to the HTTP class."""
    if path == "/api/upload":
        if not raw or len(raw) > MAX_UPLOAD_BYTES:
            return 400, {"ok": False, "err": "大小不对"}, None
        try:
            import file_share

            name = (query.get("name") or [f"手机文件-{int(time.time())}.bin"])[0]
            saved = file_share.save_upload(urllib.parse.unquote(name), raw)
        except Exception:
            saved = None
        if saved is None:
            return 500, {"ok": False, "err": "存不下"}, None
        paste = (query.get("paste") or ["0"])[0] in ("1", "true", "yes")
        if paste and saved.suffix.lower() in IMAGE_SUFFIXES and on_image is not None:
            try:
                on_image(saved)
            except Exception:
                pass
        return (
            200,
            {"ok": True, "name": saved.name, "kb": round(len(raw) / 1024, 1)},
            ("传文件", saved.name),
        )
    if path == "/api/voice":
        if not raw or len(raw) > MAX_VOICE_BYTES:
            return 400, {"ok": False, "err": "录音大小不对"}, None
        if on_voice is None:
            return 503, {"ok": False, "err": "这台电脑上的语音助手没接这个口"}, None
        try:
            text = on_voice(raw) or ""
        except Exception as exc:  # noqa: BLE001
            return 500, {"ok": False, "err": str(exc)[:120]}, None
        return 200, {"ok": True, "text": text}, ("发语音", str(text)[:40])
    return None
