# -*- coding: utf-8 -*-
"""Phone console HTTP payloads for tasks, security, plugins and agents.

Authentication and capability verification stay in ``phone_link.py``.  This
module only owns route payloads so the HTTP entrypoint does not accumulate
every product surface.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any


SECURE_POST_PATHS = frozenset({
    "/api/tasks/action",
    "/api/security/action",
    "/api/plugins/action",
    "/api/plugins/install",
    "/api/device-acceptance/action",
    "/api/agents/action",
})


def _error(exc: Exception, size: int = 160) -> tuple[int, dict]:
    return 400, {"ok": False, "err": str(exc)[:size]}


def get_route(
    path: str,
    query: dict[str, list[str]],
    *,
    transport: Callable[[], Any] | None = None,
    current_device: Callable[[], str] | None = None,
) -> tuple[int, dict] | None:
    try:
        if path == "/api/tasks":
            from features.tasks import TaskStore, sync_recent_threads

            if (query.get("sync") or ["0"])[0] == "1":
                sync_recent_threads(TaskStore())
            try:
                after = max(0, int((query.get("after") or ["0"])[0]))
            except Exception:
                after = 0
            snapshot = TaskStore().snapshot(
                after=after,
                limit=int((query.get("limit") or ["60"])[0]),
            )
            status = {"connected": True, "last_error": ""}
            if transport:
                try:
                    status = dict(transport().health())
                except Exception as exc:  # noqa: BLE001
                    status = {"connected": False, "last_error": str(exc)[:160]}
            return 200, {"ok": True, **snapshot, "transport": status}
        if path == "/api/security":
            from phone_feature.security_console import snapshot

            return 200, {
                "ok": True,
                **snapshot(current_device=(current_device() if current_device else "")),
            }
        if path == "/api/plugins":
            from phone_feature.plugin_console import snapshot

            return 200, snapshot()
        if path == "/api/device-acceptance":
            from phone_feature.device_acceptance import snapshot

            return 200, snapshot(
                current_device=(current_device() if current_device else "")
            )
        if path == "/api/agents":
            from features.agent_workers import operations

            return 200, operations().list()
    except Exception as exc:  # noqa: BLE001
        return 500, {"ok": False, "err": str(exc)[:200]}
    return None


def post_route(
    path: str,
    data: dict,
    *,
    raw: bytes = b"",
    headers: dict[str, str] | None = None,
    transport: Callable[[], Any] | None = None,
    current_device: Callable[[], str] | None = None,
) -> tuple[int, dict, tuple[str, str] | None] | None:
    try:
        if path == "/api/tasks/action":
            from features.tasks import TaskStore

            store = TaskStore()
            bridge = transport() if transport else None
            action = str(data.get("action") or "").strip().lower()
            task_id = str(data.get("id") or "").strip()
            if action == "create":
                task = store.create(
                    str(data.get("title") or ""),
                    thread_id=str(data.get("thread_id") or ""),
                    detail=str(data.get("detail") or ""),
                )
            elif action in {"approve", "reject"}:
                if bridge is None:
                    raise RuntimeError("Codex 批准桥未连接")
                task = bridge.resolve(
                    task_id, action == "approve", str(data.get("note") or "")
                )
            elif action == "cancel":
                task = (bridge.cancel(task_id) if bridge is not None
                        else store.update(task_id, status="cancelled"))
            elif action == "message":
                task = (
                    bridge.inject_message(task_id, str(data.get("text") or ""))
                    if bridge is not None
                    else store.queue_message(task_id, str(data.get("text") or ""))
                )
            elif action == "message_edit":
                task = store.edit_message(
                    task_id, str(data.get("message_id") or ""),
                    str(data.get("text") or ""),
                )
            elif action == "message_cancel":
                task = store.cancel_message(
                    task_id, str(data.get("message_id") or "")
                )
            elif action == "message_reorder":
                task = store.reorder_messages(
                    task_id, list(data.get("message_ids") or [])
                )
            else:
                return 400, {"ok": False, "err": "未知任务操作"}, None
            return 200, {"ok": True, "task": task}, (
                "任务操作", f"{action} · {task_id or task['id']}"
            )
        if path == "/api/security/action":
            from phone_feature.security_console import perform

            action = str(data.get("action") or "").strip().lower()
            result = perform(data)
            return 200, {"ok": True, **result}, ("安全", action)
        if path == "/api/plugins/action":
            from phone_feature.plugin_console import perform

            action = str(data.get("action") or "").strip().lower()
            result = perform(data)
            return 200, {"ok": True, **result}, ("插件", action)
        if path == "/api/plugins/install":
            from phone_feature.plugin_console import install

            if not raw:
                raise ValueError("没有收到插件包")
            normalized = {
                str(key).lower(): str(value)
                for key, value in (headers or {}).items()
            }
            confirmed = json.loads(
                normalized.get("x-findeck-plugin-permissions") or "[]"
            )
            if not isinstance(confirmed, list):
                raise ValueError("权限确认格式不正确")
            result = install(
                raw,
                confirmed_permissions={str(item) for item in confirmed},
            )
            audit = (("插件", f"安装 {result.get('id') or ''}")
                     if result.get("installed") else None)
            return 200, result, audit
        if path == "/api/device-acceptance/action":
            from phone_feature.device_acceptance import update

            result = update(
                current_device=(current_device() if current_device else ""),
                data=data,
            )
            return 200, result, ("设备验收", str(data.get("id") or ""))
        if path == "/api/agents/action":
            from features.agent_workers import operations

            ops = operations()
            action = str(data.get("action") or "").strip().lower()
            if action == "create-worktree":
                result = ops.create_worktree(
                    str(data.get("name") or ""),
                    base=str(data.get("base") or "HEAD"),
                )
            elif action == "submit":
                result = ops.submit(
                    str(data.get("prompt") or ""),
                    cwd=str(data.get("cwd") or ""),
                    model=str(data.get("model") or ""),
                    sandbox=str(data.get("sandbox") or "workspace-write"),
                )
            elif action == "remove-worktree":
                if data.get("confirm") is not True:
                    raise ValueError("移除 worktree 需要明确确认")
                ops.remove_worktree(
                    str(data.get("path") or ""), force=bool(data.get("force"))
                )
                result = {"removed": True}
            elif action == "reconnect":
                bridge = transport() if transport else None
                if bridge is None:
                    raise RuntimeError("Codex 控制桥未连接")
                result = bridge.reconnect()
            else:
                return 400, {"ok": False, "err": "未知 Agent 操作"}, None
            return 200, {"ok": True, "result": result}, ("Agent", action)
    except Exception as exc:  # noqa: BLE001
        status, body = _error(exc, 240)
        return status, body, None
    return None
