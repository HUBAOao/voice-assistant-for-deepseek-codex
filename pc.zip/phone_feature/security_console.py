# -*- coding: utf-8 -*-
"""Security console use-cases shared by phone HTTP and desktop callers."""
from __future__ import annotations

from typing import Any

from features.app_security import SECURITY
from features.tasks import TaskStore
from phone_feature.security import device_forget_all, device_groups, group_revoke


def snapshot(*, current_device: str = "") -> dict[str, Any]:
    """Return non-secret security state and a redacted device summary."""
    groups = []
    for group in device_groups():
        entries = list(group.get("ids") or [])
        groups.append({
            "key": group.get("key") or "",
            "ids": entries,
            "name": group.get("name") or "",
            "ip": group.get("ip") or "",
            "last": group.get("last") or 0,
            "ok": bool(group.get("ok")),
            "revoked": bool(group.get("revoked")),
            "current": bool(current_device) and current_device in set(entries),
            "entries": len(entries),
        })
    return {
        **SECURITY.summary(),
        "retention": TaskStore().retention(),
        "devices": groups,
        "current_device": current_device,
    }


def perform(data: dict[str, Any]) -> dict[str, Any]:
    """Execute one authenticated security action and return JSON-ready fields."""
    action = str(data.get("action") or "").strip().lower()
    if action == "rotate-key":
        return {"security": SECURITY.rotate()}
    if action == "policy":
        policy = SECURITY.set_policy(
            capability_ttl_seconds=data.get("capability_ttl_seconds"),
            rotate_days=data.get("rotate_days"),
            max_active_devices=data.get("max_active_devices"),
        )
        return {"security": {**SECURITY.summary(), "policy": policy}}
    if action == "retention":
        policy = TaskStore().set_retention(
            terminal_days=data.get("terminal_days"),
            max_tasks=data.get("max_tasks"),
            max_diff_chars=data.get("max_diff_chars"),
            max_tool_output_chars=data.get("max_tool_output_chars"),
        )
        return {"retention": policy}
    if action == "prune":
        return {"pruned": TaskStore().prune()}
    if action == "backup-key":
        return {"backup": SECURITY.export_backup(
            str(data.get("passphrase") or "")
        )}
    if action == "restore-key":
        return {"security": SECURITY.restore_backup(
            str(data.get("backup") or ""),
            str(data.get("passphrase") or ""),
        )}
    if action == "revoke-device":
        if data.get("confirm") is not True:
            raise ValueError("吊销设备需要明确确认")
        ids = data.get("ids")
        if not isinstance(ids, list):
            ids = [data.get("id")]
        clean = [str(item) for item in ids if str(item or "").strip()]
        if not clean:
            raise ValueError("没有选中设备")
        return {"revoked": group_revoke(clean)}
    if action == "revoke-all-devices":
        if data.get("confirm") is not True:
            raise ValueError("吊销全部设备需要明确确认")
        return {"revoked": device_forget_all(), "rotated": True}
    raise ValueError("未知安全操作")
