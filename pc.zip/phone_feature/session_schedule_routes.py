# -*- coding: utf-8 -*-
"""HTTP payloads for phone conversation switching and schedules.

The legacy ``/api/`` URLs stay stable; this module only moves their payload
handling out of the socket handler.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any


SECURE_POST_PATHS = frozenset({
    "/api/cmd",
    "/api/submit",
    "/api/send-media",
    "/api/upload",
    "/api/voice",
    "/api/threads/action",
    "/api/threads/new",
    "/api/target",
    "/api/schedule",
})


def _windows(callbacks: dict[str, Callable[[], Any] | None]) -> dict:
    items: list = []
    get_windows = callbacks.get("get_windows")
    if get_windows:
        try:
            items = list(get_windows() or [])
        except Exception:
            items = []

    windows = []
    opened = ""
    for item in items:
        if isinstance(item, dict):
            name = str(item.get("title") or item.get("name") or "")
            is_current = bool(item.get("current"))
        else:
            name, is_current = str(item), False
        if not name:
            continue
        if is_current:
            opened = name
        windows.append({
            "title": name,
            "current": is_current,
            "id": str(item.get("id") or "") if isinstance(item, dict) else "",
            "name": name,
            "pinned": bool(item.get("pinned")) if isinstance(item, dict) else False,
            "project": str(item.get("project") or "") if isinstance(item, dict) else "",
            "project_id": str(item.get("project_id") or "")
            if isinstance(item, dict) else "",
            "archived": bool(item.get("archived")) if isinstance(item, dict) else False,
            "unread": bool(item.get("unread")) if isinstance(item, dict) else False,
            "updated_at": int(item.get("updated_at") or 0)
            if isinstance(item, dict) else 0,
            "created_at": int(item.get("created_at") or 0)
            if isinstance(item, dict) else 0,
            "preview": str(item.get("preview") or "")[:160]
            if isinstance(item, dict) else "",
            "section_id": str(item.get("section_id") or "")
            if isinstance(item, dict) else "",
            "section": str(item.get("section") or "")
            if isinstance(item, dict) else "",
            "status": str(item.get("status") or "")
            if isinstance(item, dict) else "",
            "read_revision": str(item.get("read_revision") or "")
            if isinstance(item, dict) else "",
        })

    current = ""
    current_id = ""
    get_target = callbacks.get("get_target")
    get_target_id = callbacks.get("get_target_id")
    if get_target:
        try:
            current = str(get_target() or "")
        except Exception:
            current = ""
    if get_target_id:
        try:
            current_id = str(get_target_id() or "")
        except Exception:
            current_id = ""

    projects: list = []
    get_projects = callbacks.get("get_projects")
    if get_projects:
        try:
            projects = list(get_projects() or [])
        except Exception:
            projects = []
    return {
        "ok": True,
        "current": opened,
        "chosen": current,
        "chosen_id": current_id,
        "windows": windows,
        "projects": projects,
    }


def get_route(
    path: str,
    *,
    get_windows: Callable[[], Any] | None = None,
    get_target: Callable[[], Any] | None = None,
    get_target_id: Callable[[], Any] | None = None,
    get_projects: Callable[[], Any] | None = None,
    get_schedule: Callable[[], Any] | None = None,
    get_replies: Callable[[], Any] | None = None,
) -> tuple[int, dict] | None:
    """Return a JSON response for a conversation/schedule GET."""
    if path == "/api/windows":
        return 200, _windows({
            "get_windows": get_windows,
            "get_target": get_target,
            "get_target_id": get_target_id,
            "get_projects": get_projects,
        })
    if path == "/api/schedule":
        items = []
        if get_schedule:
            try:
                items = list(get_schedule() or [])
            except Exception:
                items = []
        return 200, {"ok": True, "items": items}
    if path == "/api/replies":
        items = []
        if get_replies:
            try:
                items = list(get_replies() or [])
            except Exception:
                items = []
        return 200, {"ok": True, "items": items}
    return None


def post_route(
    path: str,
    data: dict,
    *,
    on_thread_action: Callable[[str, str, dict], tuple[bool, str]] | None = None,
    on_new_thread: Callable[[str], tuple[bool, str]] | None = None,
    on_target: Callable[..., tuple[bool, str]] | None = None,
    get_target: Callable[[], Any] | None = None,
    on_schedule: Callable[[str, dict], tuple[bool, str]] | None = None,
) -> tuple[int, dict, tuple[str, str] | None] | None:
    """Return ``status, body, audit`` for a conversation/schedule mutation."""
    if path == "/api/threads/action":
        action = str(data.get("action") or "").strip().lower()
        thread_id = str(data.get("id") or "").strip()
        if not action or not thread_id:
            return 400, {"ok": False, "err": "会话 ID 或操作缺失"}, None
        if not on_thread_action:
            return 503, {"ok": False, "err": "电脑端会话管理还没接上"}, None
        try:
            ok, message = on_thread_action(action, thread_id, data)
        except Exception as exc:  # noqa: BLE001
            ok, message = False, str(exc)[:120]
        return (200, {"ok": bool(ok), "msg": message},
                ("会话操作", f"{action} · {message}"))

    if path == "/api/threads/new":
        if not on_new_thread:
            return 503, {"ok": False, "err": "电脑端新对话入口还没接上"}, None
        try:
            ok, message = on_new_thread(str(data.get("project_id") or ""))
        except Exception as exc:  # noqa: BLE001
            ok, message = False, str(exc)[:120]
        return 200, {"ok": bool(ok), "msg": message}, ("新对话", message)

    if path == "/api/target":
        title = str(data.get("title") or "")
        thread_id = str(data.get("id") or "")
        if on_target:
            try:
                try:
                    ok, message = on_target(title, thread_id)
                except TypeError:
                    ok, message = on_target(title)
            except Exception as exc:  # noqa: BLE001
                ok, message = False, str(exc)[:80]
        else:
            ok, message = False, "电脑那边没准备好"
        current = message if ok else ""
        if get_target and ok:
            try:
                current = str(get_target() or "") or message
            except Exception:
                current = message
        return 200, {"ok": bool(ok), "msg": message, "current": current}, None

    if path == "/api/schedule":
        action = str(data.get("action") or "").strip()
        if not action:
            return 400, {"ok": False, "err": "empty"}, None
        if not on_schedule:
            return 503, {"ok": False, "err": "电脑上这个口没接"}, None
        try:
            ok, message = on_schedule(action, data)
        except Exception as exc:  # noqa: BLE001
            return 500, {"ok": False, "err": str(exc)[:120]}, None
        item = data.get("item") if isinstance(data.get("item"), dict) else {}
        audit = (
            "日程" if action != "toggle" else "日程开关",
            str(item.get("text") or data.get("text") or "")[:40],
        )
        return 200, {"ok": bool(ok), "msg": message}, audit
    return None
