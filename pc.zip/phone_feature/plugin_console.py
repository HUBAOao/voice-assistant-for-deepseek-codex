# -*- coding: utf-8 -*-
"""Phone-facing plugin management use-cases."""
from __future__ import annotations

from typing import Any

from features.plugin_registry import PLUGIN_HOST


def snapshot() -> dict[str, Any]:
    data = PLUGIN_HOST.snapshot()
    data["market"] = PLUGIN_HOST.market_snapshot()
    return data


def perform(data: dict[str, Any]) -> dict[str, Any]:
    action = str(data.get("action") or "").strip().lower()
    plugin_id = str(data.get("id") or "").strip()
    if action == "enable":
        return {"plugin": PLUGIN_HOST.enable(plugin_id)}
    if action == "disable":
        return {"plugin": PLUGIN_HOST.disable(plugin_id)}
    if action == "reload":
        return {"plugin": PLUGIN_HOST.reload(plugin_id)}
    if action == "rollback":
        return {"plugin": PLUGIN_HOST.rollback(
            plugin_id, confirm=data.get("confirm") is True
        )}
    if action == "remove":
        return {"result": PLUGIN_HOST.remove(
            plugin_id, confirm=data.get("confirm") is True
        )}
    if action == "trust_publisher":
        return PLUGIN_HOST.trust_publisher(
            data.get("publisher") or {},
            confirm=data.get("confirm") is True,
        )
    if action == "trust_plugin":
        return PLUGIN_HOST.trust_plugin(
            plugin_id, confirm=data.get("confirm") is True
        )
    if action == "untrust_publisher":
        return PLUGIN_HOST.untrust_publisher(
            str(data.get("publisher_id") or plugin_id),
            confirm=data.get("confirm") is True,
        )
    market = PLUGIN_HOST.market()
    if action == "market_add":
        return market.add_source(
            str(data.get("url") or ""),
            name=str(data.get("name") or ""),
            confirm=data.get("confirm") is True,
        )
    if action == "market_remove":
        return market.remove_source(
            str(data.get("source_id") or ""),
            confirm=data.get("confirm") is True,
        )
    if action in {"market_refresh", "market_refresh_all"}:
        return market.refresh(
            "" if action == "market_refresh_all"
            else str(data.get("source_id") or "")
        )
    if action == "market_install":
        confirmed = data.get("confirmed_permissions")
        return market.install(
            str(data.get("source_id") or ""),
            str(data.get("id") or ""),
            confirmed_permissions=set(confirmed or []),
            confirm=data.get("confirm") is True,
        )
    raise ValueError("未知插件操作")


def install(raw: bytes, *, confirmed_permissions: set[str] | None = None) -> dict[str, Any]:
    return PLUGIN_HOST.install_archive(
        raw, confirmed_permissions=confirmed_permissions
    )
