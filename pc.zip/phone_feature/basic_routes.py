# -*- coding: utf-8 -*-
"""Small, stable phone HTTP routes kept separate from the socket handler.

Authentication and capability checks remain in :mod:`phone_link`.  These
helpers only construct payloads and invoke the callbacks supplied by the
running application.
"""
from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path
from typing import Any


BASIC_SECURE_POST_PATHS = frozenset({
    "/api/cmd",
    "/api/send-media",
})


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return value if isinstance(value, dict) else {}


def _mtime_ns(path: Path) -> str:
    try:
        return str(path.stat().st_mtime_ns)
    except Exception:
        return ""


def get_route(
    path: str,
    query: dict[str, list[str]],
    *,
    get_log: Callable[..., Any],
    get_state: Callable[[], Any],
    speak_file: Path,
    balance_file: Path,
    page_file: Path,
    apk_file: Path,
    pc_version: Callable[[], str],
    phone_version: Callable[[], str],
    get_info: Callable[[], Any] | None = None,
) -> tuple[int, dict, bool] | None:
    """Return ``status, body, allow_cors`` for a supported basic GET."""
    if path == "/api/log":
        try:
            since = int((query.get("since") or ["0"])[0])
        except Exception:
            since = 0
        try:
            state = dict(get_state() or {})
        except Exception:
            state = {}
        keyword = (query.get("q") or [""])[0].strip()
        try:
            lines = get_log(since, keyword) or []
        except TypeError:
            lines = get_log(since) or []
        return 200, {
            "ok": True,
            "online": True,
            "state": state.get("state_text", ""),
            "busy": bool(state.get("busy")),
            "lines": lines,
        }, False

    if path == "/api/state":
        try:
            state = get_state() or {}
        except Exception:
            state = {}
        return 200, state if isinstance(state, dict) else {}, True

    if path == "/api/speak":
        return 200, _read_json(speak_file), True

    if path == "/api/balance":
        return 200, _read_json(balance_file), True

    if path == "/api/version":
        try:
            apk_kb = round(apk_file.stat().st_size / 1024, 1)
        except Exception:
            apk_kb = 0
        return 200, {
            "ok": True,
            "pc": pc_version(),
            "phone": phone_version(),
            "page_rev": _mtime_ns(page_file),
            "apk": apk_file.name,
            "apk_kb": apk_kb,
        }, False

    if path == "/api/info":
        info: dict = {}
        if get_info:
            try:
                value = get_info() or {}
            except Exception:
                value = {}
            if isinstance(value, dict):
                info = dict(value)
        info["ok"] = True
        return 200, info, False

    return None


def post_route(
    path: str,
    data: dict,
    *,
    on_command: Callable[[str], Any] | None = None,
    on_stop: Callable[[], Any] | None = None,
    on_submit: Callable[[], Any] | None = None,
    on_media_command: Callable[[str], Any] | None = None,
) -> tuple[int, dict, tuple[str, str] | None] | None:
    """Return ``status, body, audit`` for the original command endpoints."""
    if path == "/api/cmd":
        text = str(data.get("text") or "").strip()
        if not text:
            return 400, {"ok": False, "err": "empty"}, None
        if on_command is None:
            return 503, {"ok": False, "err": "电脑端命令入口还没接上"}, None
        try:
            on_command(text)
        except Exception as exc:  # noqa: BLE001
            return 500, {"ok": False, "err": str(exc)[:80]}, None
        return 200, {"ok": True}, ("发命令", text[:60])

    if path == "/api/stop":
        try:
            if on_stop:
                on_stop()
        except Exception:
            pass
        return 200, {"ok": True}, ("喊停", "")

    if path == "/api/submit":
        try:
            if on_submit:
                on_submit()
        except Exception as exc:  # noqa: BLE001
            return 500, {"ok": False, "err": str(exc)[:80]}, None
        return 200, {"ok": True}, None

    if path == "/api/send-media":
        text = str(data.get("text") or "").strip()
        if not text:
            return 400, {"ok": False, "err": "empty"}, None
        try:
            if on_media_command:
                on_media_command(text)
        except Exception as exc:  # noqa: BLE001
            return 500, {"ok": False, "err": str(exc)[:80]}, None
        return 200, {"ok": True}, ("发附件文字", text[:60])

    return None
