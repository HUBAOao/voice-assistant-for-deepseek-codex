"""Stable ordering for authenticated phone HTTP route modules."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable

from phone_feature.basic_routes import (
    BASIC_SECURE_POST_PATHS,
    get_route as basic_get,
    post_route as basic_post,
)
from phone_feature.console_routes import (
    SECURE_POST_PATHS as CONSOLE_SECURE_POST_PATHS,
    get_route as console_get,
    post_route as console_post,
)
from phone_feature.history_routes import (
    SECURE_POST_PATHS as HISTORY_SECURE_POST_PATHS,
    get_route as history_get,
    post_route as history_post,
)
from phone_feature.media_routes import (
    get_route as media_get,
    post_route as media_post,
)
from phone_feature.session_schedule_routes import (
    SECURE_POST_PATHS as ACTION_SECURE_POST_PATHS,
    get_route as session_get,
    post_route as session_post,
)
from phone_feature.static_routes import get_route as static_get


@dataclass(frozen=True)
class RouteResponse:
    body: Any
    status: int = 200
    content_type: str = "application/json; charset=utf-8"
    headers: tuple[tuple[str, str], ...] = ()
    audit: tuple[str, str] | None = None

    def encoded(self) -> bytes:
        if isinstance(self.body, bytes):
            return self.body
        return json.dumps(self.body, ensure_ascii=False).encode("utf-8")


def secure_post_paths() -> frozenset[str]:
    return frozenset(
        BASIC_SECURE_POST_PATHS
        | CONSOLE_SECURE_POST_PATHS
        | HISTORY_SECURE_POST_PATHS
        | ACTION_SECURE_POST_PATHS
    )


def _json_result(result) -> RouteResponse | None:
    if result is None:
        return None
    if len(result) == 3:
        status, body, cors = result
        headers = (
            (("Access-Control-Allow-Origin", "*"),)
            if cors
            else ()
        )
        return RouteResponse(body, status, headers=headers)
    status, body = result
    return RouteResponse(body, status)


def _mutation_result(result) -> RouteResponse | None:
    if result is None:
        return None
    if len(result) == 3:
        status, body, audit = result
        return RouteResponse(body, status, audit=audit)
    status, body = result
    return RouteResponse(body, status)


def dispatch_get(
    path: str,
    query: dict[str, list[str]],
    *,
    static_call: Callable[[], Any],
    basic_call: Callable[[], Any],
    media_call: Callable[[], Any],
    session_call: Callable[[], Any],
    console_call: Callable[[], Any],
    history_call: Callable[[], Any],
) -> RouteResponse | None:
    """Run the legacy GET order through one testable dispatcher."""
    static_result = static_call()
    if static_result is not None:
        return RouteResponse(
            static_result.body,
            static_result.status,
            static_result.content_type,
            tuple(static_result.headers),
            static_result.audit,
        )
    for call in (
        basic_call,
        media_call,
        session_call,
        console_call,
        history_call,
    ):
        response = _json_result(call())
        if response is not None:
            return response
    return None


def dispatch_post(
    path: str,
    query: dict[str, list[str]],
    raw: bytes,
    data: dict,
    headers: dict[str, str],
    *,
    basic_call: Callable[[], Any],
    console_call: Callable[[], Any],
    session_call: Callable[[], Any],
    history_call: Callable[[], Any],
    media_call: Callable[[], Any],
) -> RouteResponse | None:
    """Keep the existing mutation precedence after authentication succeeds."""
    del path, query, raw, data, headers  # retained in the stable public signature
    for call in (
        basic_call,
        console_call,
        session_call,
        history_call,
        media_call,
    ):
        response = _mutation_result(call())
        if response is not None:
            return response
    return None


def route_get_arguments(
    path: str,
    query: dict[str, list[str]],
    *,
    static_args: dict,
    basic_args: dict,
    media_args: dict | None = None,
    session_args: dict,
    console_args: dict,
    history_args: dict | None = None,
) -> dict[str, Callable[[], Any]]:
    """Bind route calls so the HTTP handler only owns transport concerns."""
    return {
        "static_call": lambda: static_get(path, query, **static_args),
        "basic_call": lambda: basic_get(path, query, **basic_args),
        "media_call": lambda: media_get(path),
        "session_call": lambda: session_get(path, **session_args),
        "console_call": lambda: console_get(path, query, **console_args),
        "history_call": lambda: history_get(path, query),
    }


def route_post_arguments(
    path: str,
    query: dict[str, list[str]],
    raw: bytes,
    data: dict,
    headers: dict[str, str],
    *,
    basic_callbacks: dict,
    console_args: dict,
    session_callbacks: dict,
    media_callbacks: dict,
) -> dict[str, Callable[[], Any]]:
    """Bind the legacy POST callbacks without exposing them to the socket layer."""
    return {
        "basic_call": lambda: basic_post(path, data, **basic_callbacks),
        "console_call": lambda: console_post(
            path,
            data,
            raw=raw,
            headers=headers,
            **console_args,
        ),
        "session_call": lambda: session_post(
            path,
            data,
            **session_callbacks,
        ),
        "history_call": lambda: history_post(path, data),
        "media_call": lambda: media_post(path, query, raw, **media_callbacks),
    }
