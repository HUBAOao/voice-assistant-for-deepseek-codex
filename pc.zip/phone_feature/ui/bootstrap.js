// Start live chat only after every deferred phone module is ready.
refreshAvatars();
pull();
setInterval(pull, 2000);
