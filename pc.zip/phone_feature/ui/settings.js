// FinDeck phone settings and app-only controls.
// Loaded after the main page script; shares DOM, look and web bridge state.

function nativeHaptic(milliseconds = 12) {
  try {
    if (window.VoiceApp && typeof VoiceApp.haptic === "function") {
      VoiceApp.haptic(milliseconds);
      return;
    }
  } catch (e) {}
  try { if (navigator.vibrate) navigator.vibrate(milliseconds); } catch (e) {}
}

// Android share/process-text target: insert text, never auto-send.
window.onAndroidSharedText = function(text) {
  const box = document.getElementById("box");
  if (!box || !document.body.contains(box)) return false;
  let incoming = String(text || "").replace(/\r\n?/g, "\n");
  if (!incoming.trim()) return false;
  incoming = incoming.slice(0, 120000);
  const current = String(box.value || "");
  box.value = current.trim()
    ? current.replace(/\s*$/, "") + "\n" + incoming
    : incoming;
  box.dispatchEvent(new Event("input", {bubbles: true}));
  try { box.focus(); } catch (e) {}
  nativeHaptic(10);
  return true;
};

function nativeShareText(title, text) {
  const body = String(text || "");
  if (!body.trim()) return false;
  try {
    if (window.VoiceApp && typeof VoiceApp.shareText === "function") {
      VoiceApp.shareText(String(title || "鳍舱对话"), body);
      return true;
    }
  } catch (e) {}
  if (navigator.share) {
    navigator.share({title: String(title || "鳍舱对话"), text: body}).catch(() => {});
    return true;
  }
  try {
    if (window.VoiceApp && typeof VoiceApp.copyText === "function") {
      return VoiceApp.copyText(body);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(body);
      return true;
    }
  } catch (e) {}
  return false;
}

function shareCurrentConversation() {
  const rows = [...document.querySelectorAll("#log .row")]
    .map(row => (row.innerText || "").trim())
    .filter(Boolean);
  const text = rows.slice(-240).join("\n\n");
  const title = (typeof convLabel === "string" && convLabel)
    ? "鳍舱 · " + convLabel : "鳍舱对话";
  if (!nativeShareText(title, text || location.href)) {
    alert("这台设备暂时不能分享，可以先长按消息复制。");
  }
  togglePlus(false);
}

function speakLatestReply() {
  const rows = [...document.querySelectorAll('#log .row[data-kind="ai"]')];
  const latest = rows.length ? rows[rows.length - 1].querySelector(".btext") : null;
  const text = latest ? String(latest.textContent || "").trim().slice(0, 8000) : "";
  if (!text) {
    alert("现在还没有可朗读的回复。");
    return;
  }
  try {
    if (window.VoiceApp && typeof VoiceApp.speakReply === "function") {
      if (VoiceApp.speakReply(text)) {
        nativeHaptic(8);
        return;
      }
    }
  } catch (e) {}
  try {
    if (window.speechSynthesis && window.SpeechSynthesisUtterance) {
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(new SpeechSynthesisUtterance(text));
      return;
    }
  } catch (e) {}
  alert("这台设备暂时不能朗读。");
}

const speakTile = document.getElementById("tispeak");
if (speakTile) {
  speakTile.onclick = () => {
    togglePlus(false);
    speakLatestReply();
  };
}

function pickInk(hex) {                       // 深色主题配绿/蓝用深字，浅色配浅字
  const n = parseInt(hex.slice(1), 16);
  const lum = 0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
  return lum > 150 ? "#10261a" : "#ffffff";
}

function save() {
  localStorage.setItem("look", JSON.stringify(look));
  applyLook();
  document.querySelectorAll("#sheet .sw span, #sheet .chips b").forEach(e => e.classList.remove("on"));
  document.getElementById("sw-accent").innerHTML = "";
  document.getElementById("sw-bg").innerHTML = "";
  document.getElementById("sw-font").innerHTML = "";
  document.getElementById("sw-anim").innerHTML = "";
  buildSheet();
}

document.getElementById("gear").onclick = () => {
  const s = document.getElementById("sheet");
  if (s.classList.contains("open")) {
    s.classList.remove("open");
    document.getElementById("sheetbg").classList.remove("on");
  } else {
    openSheet();
  }
};
document.getElementById("drawerSettings").onclick = () => {
  openSheet();
};
function closeSettingsCats() {
  document.querySelectorAll(".settings-cat.open").forEach(sec => {
    sec.classList.remove("open");
    const group = sec.querySelector(".settings-group");
    if (group) group.style.maxHeight = "0px";
  });
}
function openSettingsCat(name) {
  closeSettingsCats();
  if (!name) return;
  const sec = document.querySelector('.settings-cat[data-cat="' + name + '"]');
  if (!sec) return;
  const group = sec.querySelector(".settings-group");
  sec.classList.add("open");
  if (group) requestAnimationFrame(() => {
    group.style.maxHeight = group.scrollHeight + "px";
    setTimeout(() => sec.scrollIntoView({block: "nearest", behavior: "smooth"}), 120);
  });
  if (name === "pet") setTimeout(petMark, 80);
}
document.querySelectorAll(".settings-cat-head").forEach(head => {
  head.onclick = () => {
    const sec = head.closest(".settings-cat");
    const wasOpen = sec.classList.contains("open");
    if (wasOpen) {
      closeSettingsCats();
    } else {
      openSettingsCat(sec.dataset.cat);
    }
  };
});
window.addEventListener("resize", () => {
  document.querySelectorAll(".settings-cat.open .settings-group").forEach(group => {
    group.style.maxHeight = group.scrollHeight + "px";
  });
});
/** 打开设置抽屉；传分类名可直接展开该大类。 */
function openSheet(target) {
  const s = document.getElementById("sheet");
  closeSettingsCats();
  s.classList.add("open");
  document.getElementById("sheetbg").classList.add("on");
  loadSecurity();
  if (target === true) target = "connection";
  if (typeof target === "string") openSettingsCat(target);
}
document.getElementById("bgurl").onchange = e => {
  look.bgurl = e.target.value.trim();
  if (look.bgurl) look.bgimg = "";
  save();
};

// ---- 在 APP 里才有的：扫码 / 刷新 / 改地址（以前是底下那三个丑按钮，现在都进设置） ----
if (window.VoiceApp) {
  document.getElementById("connsec").style.display = "block";
  const cur = document.getElementById("cururl");
  try { cur.value = window.VoiceApp.url(); } catch (e) { cur.value = ""; }
  document.getElementById("editurl").onclick = () => window.VoiceApp.editUrl();
  document.getElementById("scanbtn").onclick = () => window.VoiceApp.scan();
  document.getElementById("reloadbtn").onclick = () => window.VoiceApp.reload();
  document.getElementById("reseturl").onclick = () => {
    // 恢复出厂地址：跟"修改"那条路走同一个原生弹窗（里面也有恢复按钮）
    window.VoiceApp.editUrl();
  };
  // 电脑忙完的提醒开关（APP 里才有的前台服务）
  const mark = () => {
    let on = true;
    try { on = window.VoiceApp.notifyOn(); } catch (e) {}
    document.getElementById("notifyon").classList.toggle("on", on);
    document.getElementById("notifyoff").classList.toggle("on", !on);
  };
  window.refreshNativeNotifyState = mark;
  document.getElementById("notifyon").onclick = () => {
    try { window.VoiceApp.setNotify(true); } catch (e) {}
    mark();
  };
  document.getElementById("notifyoff").onclick = () => {
    try { window.VoiceApp.setNotify(false); } catch (e) {}
    mark();
  };
  mark();
}
const petOnBtn = document.getElementById("peton");
const petOffBtn = document.getElementById("petoff");
const petTip = document.getElementById("pettip");
let petState = false;
function petMark() {
  if (window.VoiceApp && typeof window.VoiceApp.petOn === "function") {
    try { petState = !!window.VoiceApp.petOn(); } catch (e) {}
  }
  petOnBtn.classList.toggle("on", petState);
  petOffBtn.classList.toggle("on", !petState);
  petTip.textContent = window.VoiceApp
    ? "开关后回到桌面查看；首次开启需要允许“显示在其他应用上层”。"
    : "悬浮桌宠只能在手机 APP 内开关。";
}
petOnBtn.onclick = () => {
  if (!window.VoiceApp) return;
  petState = true;
  try {
    if (typeof window.VoiceApp.setPet === "function") window.VoiceApp.setPet(true);
    else if (window.VoiceApp.petToggle) window.VoiceApp.petToggle();
  } catch (e) {}
  petMark();
  setTimeout(petMark, 350);
};
petOffBtn.onclick = () => {
  if (!window.VoiceApp) return;
  petState = false;
  try {
    if (typeof window.VoiceApp.setPet === "function") window.VoiceApp.setPet(false);
    else if (window.VoiceApp.petToggle) window.VoiceApp.petToggle();
  } catch (e) {}
  petMark();
  setTimeout(petMark, 350);
};
petMark();
window.onNativeResume = function() {
  try {
    if (typeof window.refreshNativeNotifyState === "function") {
      window.refreshNativeNotifyState();
    }
  } catch (e) {}
  try { petMark(); } catch (e) {}
  try { if (typeof catchUp === "function") catchUp(); } catch (e) {}
  try { if (typeof checkUpdate === "function") checkUpdate(); } catch (e) {}
};
document.getElementById("sheetdone").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
document.getElementById("tishare").onclick = shareCurrentConversation;
document.getElementById("sheetclose").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
if (/Android/i.test(navigator.userAgent)) {
  // 已经装在 APP 里（有 VoiceApp 这个桥）就不用再劝装 APP 了；关过一次也不再冒出来
  if (!window.VoiceApp && localStorage.getItem("hideInstall") !== "1") {
    document.getElementById("app").style.display = "block";
  }
  document.getElementById("apklink").href = "app.apk?k=" + encodeURIComponent(KEY);
}
document.getElementById("appx").onclick = () => {
  localStorage.setItem("hideInstall", "1");
  document.getElementById("app").style.display = "none";
};
document.getElementById("updx").onclick = () => {
  // 记住"这个版本我看见了"——同一个版本不再烦你，等手机端再出新版才提醒
  localStorage.setItem("updSeen", document.getElementById("updver").textContent || "");
  document.getElementById("upd").style.display = "none";
};
