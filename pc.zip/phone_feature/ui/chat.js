// FinDeck phone chat bubbles, conversation swipe and avatars.
// Loaded after the main inline script; shared page state comes from earlier scripts.

function displayConvName(conv) {
  const clean = String(conv || "").replace(/\s+/g, " ").trim();
  if (clean && clean !== "本机" && clean !== "自动") return clean;
  const current = String(convLabel || "").replace(/\s+/g, " ").trim();
  return current && current !== "自动" ? current : "对话";
}
function imageDisplaySrc(raw) {
  const s = String(raw || "").trim().replace(/^<|>$/g, "");
  if (/^(https?:|data:|blob:)/i.test(s) || s.startsWith("/") || s.startsWith("shot/")) return s;
  return "/api/image?k=" + encodeURIComponent(KEY) + "&path=" + encodeURIComponent(s);
}
function splitMessageImages(text) {
  let body = String(text || "");
  const images = [];
  body = body.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (all, alt, raw) => {
    const src = String(raw || "").trim().replace(/\s+["'][^"']*["']\s*$/, "").replace(/^<|>$/g, "");
    if (src) images.push({kind:"image", src:imageDisplaySrc(src), download:imageDisplaySrc(src),
                          name:alt || "图片"});
    return "";
  });
  const localRe = /(?:https?:\/\/[^\s<>"'）】]+|[A-Za-z]:[\\/][^\s<>"'）】]+)\.(?:png|jpe?g|webp|gif|bmp|avif)(?:\?[^\s<>"'）】]*)?/gi;
  body = body.replace(localRe, src => {
    images.push({kind:"image", src:imageDisplaySrc(src), download:imageDisplaySrc(src),
                 name:"图片"});
    return "";
  });
  return {text:body.replace(/\n{3,}/g, "\n\n").trim(), images};
}
function renderMessageMedia(bubble, items) {
  if (!items || !items.length) return;
  const wrap = document.createElement("div");
  wrap.className = "msg-media";
  for (const item of items) {
    if (item.kind === "file") {
      const a = document.createElement("a");
      a.className = "msg-file";
      a.href = item.download || item.src || "#";
      a.download = item.name || "";
      a.dataset.attachId = item.id || "";
      const meta = document.createElement("span");
      meta.textContent = "FILE";
      const info = document.createElement("i");
      info.style.cssText = "font-style:normal;min-width:0";
      const name = document.createElement("b");
      name.textContent = item.name || "文件";
      const size = document.createElement("span");
      size.textContent = item.sizeText || "附件";
      info.appendChild(name); info.appendChild(size);
      a.appendChild(meta); a.appendChild(info);
      wrap.appendChild(a);
      continue;
    }
    const holder = document.createElement("div");
    holder.className = "msg-image";
    holder.dataset.attachId = item.id || "";
    const img = document.createElement("img");
    img.alt = item.name || "图片";
    img.loading = "lazy";
    img.src = item.src;
    holder.appendChild(img);
    holder.onclick = () => viewerOpen(item.download || item.src, item.name);
    wrap.appendChild(holder);
  }
  bubble.appendChild(wrap);
}
function add(cls, text, at, raw, conv, merge, anim = true, attachments = null) {
  const cleanConv = displayConvName(conv);
  // 每句话都是独立一行、独立时间；只把连续同会话、同发言方的头像合成一组。
  const groupConv = cleanConv;
  const beforePush = anim
    ? new Map([...logEl.querySelectorAll(".row")].map(r => [r, r.getBoundingClientRect().top]))
    : null;
  const row = document.createElement("div"); row.className = "row";
  if (cls === "me") row.className = "row right";
  if (cls === "done") row.className = "row center";
  row.dataset.kind = cls;
  row.dataset.conv = groupConv;
  {
    const cur = String(convLabel || "").trim();
    const c = groupConv;
    if (c && cur && cur !== "自动" && c !== cur &&
        !["本机", "对话", "自动"].includes(c)) {
      row.classList.add("other-conv");
    }
  }
  const sameGroup = (cls === "me" || cls === "ai") && lastChatRow &&
    lastChatRow.isConnected && lastChatRow.dataset.kind === cls &&
    String(lastChatRow.dataset.conv || "") === groupConv &&
    lastChatRow.classList.contains("other-conv") === row.classList.contains("other-conv");
  const sameGroupEl = sameGroup ? lastChatRow.closest(".chat-group") : null;
  row.classList.add(sameGroup ? "group-cont" : "group-head");
  let b_avatar = null;
  if (cls === "me" || cls === "ai") {
    const av = document.createElement("span");
    av.className = "av " + (cls === "me" ? "right" : "left");
    fillAvatar(av, cls);
    if (cls === "ai") row.appendChild(av);
    if (cls === "me") b_avatar = av;          // 自己的头像放在气泡后面
  }
  const parsed = splitMessageImages(text);
  const b = document.createElement("div"); b.className = "bubble " + cls;
  const bodyText = document.createElement("span");
  bodyText.className = "btext";
  bodyText.textContent = parsed.text;
  if (parsed.text) b.appendChild(bodyText);
  renderMessageMedia(b, [...parsed.images, ...(attachments || [])]);
  const t = document.createElement("span");
  t.className = "t";
  // 显示的是**这句话什么时候说的**（电脑日志里的时间），不是你什么时候打开这个页面
  t.textContent = at || new Date().toLocaleTimeString("zh-CN",
                                                      {hour: "2-digit", minute: "2-digit"});
  const meta = document.createElement("div");
  meta.className = "bmeta";
  meta.appendChild(t);
  if (groupConv) {
    const c = document.createElement("span");
    c.className = "conv";
    c.textContent = " · " + groupConv;
    c.title = groupConv;
    meta.appendChild(c);
  }
  b.appendChild(meta);
  // 长按复制（手机上很有用：AI 回答里常要挑一段拿走）
  b.addEventListener("contextmenu", e => { e.preventDefault();
    b._lastCtx = Date.now();
    navigator.clipboard && navigator.clipboard.writeText(
      (b.querySelector(".btext") || {}).textContent || text);
    b.style.filter = "brightness(1.3)"; setTimeout(() => b.style.filter = "", 160);
  });
  if (cls === "ai") {
    const bubbleConvTitle = () => {
      const cv = b.querySelector(".conv");
      return cv ? cv.textContent.replace(/^\s*·\s*/, "").trim() : "";
    };
    b.addEventListener("click", e => {
      if (Date.now() - convSwipeMovedAt < 420) {
        e.stopPropagation();
        return;
      }
      if (b._lastCtx && Date.now() - b._lastCtx < 700) return;
      const title = bubbleConvTitle();
      if (!title || title === "本机") return;
      e.stopPropagation();
      showConvPop(row, title);
    });
    b.addEventListener("touchstart", e => {
      const title = bubbleConvTitle();
      if (title && title !== "本机") convSwipeStart(e, row, title);
    }, {passive: true});
    b.addEventListener("touchmove", convSwipeMove, {passive: false});
    b.addEventListener("touchend", convSwipeEnd, {passive: true});
    b.addEventListener("touchcancel", convSwipeEnd, {passive: true});
  }
  row.appendChild(b);
  if (cls === "me" && b_avatar) row.appendChild(b_avatar);
  if (cls === "ai") appendRawToRow(row, raw, text);
  if (sameGroupEl && sameGroupEl.isConnected &&
      sameGroupEl.lastElementChild === lastChatRow) {
    // 直接接进现有组，毛玻璃与光晕不重建，最新一句不会出现短暂分块。
    sameGroupEl.appendChild(row);
  } else {
    logEl.appendChild(row);
    regroupChatRows();
  }
  if (beforePush) playPushIn(beforePush, row);
  if (cls === "ai" || cls === "me") lastChatRow = row;
  else lastChatRow = null;
  const trow = document.getElementById("thinkrow");
  if (trow) logEl.appendChild(trow);   // 「正在思考…」永远挂在最底下
  // 一条新消息：从一个小点慢慢长大（设置里「气泡动画」关掉就不做）
  if (look.anim !== false) {
    row.classList.add("born");
    setTimeout(() => row.classList.remove("born"), 760);
  }
  logEl.scrollTop = logEl.scrollHeight;
  return row;
}

function appendRawToRow(row, raw, text) {
  if (!row || !raw || !String(raw).trim() ||
      String(raw).trim() === String(text || "").trim()) return;
  let link = row.querySelector(".rawlink");
  let box = row.querySelector(".rawtext");
  if (!link || !box) {
    const rawwrap = document.createElement("div");
    rawwrap.className = "rawwrap";
    rawwrap.style.cssText = "margin:4px 0 10px 54px";
    link = document.createElement("span");
    link.className = "rawlink";
    link.textContent = "看原话";
    link.style.cssText =
      "display:inline-flex;align-items:center;gap:6px;background:var(--line);color:var(--fg);" +
      "border:1px solid rgba(255,255,255,.07);border-radius:999px;padding:4px 12px;" +
      "font-size:12.5px;letter-spacing:.3px;cursor:pointer;user-select:none";
    const dotIc = document.createElement("span");
    dotIc.textContent = "≡";
    dotIc.style.cssText = "font-size:13px;opacity:.75";
    link.prepend(dotIc);
    box = document.createElement("div");
    box.className = "rawtext";
    box.style.cssText = "display:none;margin-top:7px;white-space:pre-wrap;line-height:1.75;" +
                        "color:var(--fg);background:var(--panel);border:1px solid var(--line);" +
                        "border-radius:10px;padding:10px 12px;" +
                        "font-size:12.5px;max-height:46vh;overflow-y:auto";
    link.onclick = () => {
      const on = box.style.display === "none";
      box.style.display = on ? "block" : "none";
      link.textContent = on ? "收起原话" : "看原话";
    };
    rawwrap.appendChild(link);
    rawwrap.appendChild(box);
    row.appendChild(rawwrap);
  }
  const s = String(raw);
  box.textContent = box.textContent ? (box.textContent + "\n\n" + s) : s;
}

/** 服务器补回来的会话名：时间后面那行小字。 */
function setBubbleConv(row, conv) {
  const clean = displayConvName(conv);
  if (!row || !clean) return;
  const b = row.querySelector(".bubble");
  if (!b) return;
  let meta = b.querySelector(".bmeta");
  if (!meta) {
    meta = document.createElement("div");
    meta.className = "bmeta";
    b.appendChild(meta);
  }
  let c = meta.querySelector(".conv");
  if (!c) {
    c = document.createElement("span");
    c.className = "conv";
    meta.appendChild(c);
  }
  c.textContent = " · " + clean;
  c.title = clean;
  row.dataset.conv = clean;
  regroupChatRows();
  const cur = String(convLabel || "").trim();
  const other = !!cur && cur !== "自动" && clean !== cur &&
    !["本机", "对话", "自动"].includes(clean);
  row.classList.toggle("other-conv", other);
  b.classList.toggle("other-conv", other);
}

function refreshConvTint() {
  const cur = String(convLabel || "").trim();
  document.querySelectorAll("#log .row[data-conv]").forEach(row => {
    const c = String(row.dataset.conv || "").trim();
    const other = !!c && !!cur && cur !== "自动" &&
      c !== cur && !["本机", "对话", "自动"].includes(c);
    row.classList.toggle("other-conv", other);
    const bubble = row.querySelector(".bubble");
    if (bubble) bubble.classList.toggle("other-conv", other);
  });
  regroupChatRows();
}

let convPopRow = null;
let convPopTitle = "";
let convPopWidth = 0;
let convDrag = null;
let convSwipeMovedAt = 0;
function hideConvPop() {
  const pop = document.getElementById("convpop");
  pop.classList.remove("on");
  pop.setAttribute("aria-hidden", "true");
  pop.style.transition = "";
  pop.style.transform = "";
  if (convPopRow) {
    convPopRow.classList.remove("conv-swiped");
    convPopRow.style.removeProperty("--conv-shift");
  }
  convPopRow = null;
  convPopTitle = "";
  convPopWidth = 0;
}
function showConvPop(row, title) {
  const pop = document.getElementById("convpop");
  const btn = document.getElementById("convpopbtn");
  if (convPopRow && convPopRow !== row) hideConvPop();
  convPopRow = row;
  convPopTitle = title;
  const same = !!convLabel && title === convLabel;
  btn.disabled = same;
  btn.textContent = title || "对话";
  btn.setAttribute("aria-label", same ? (title + "，当前会话") : ("切换到 " + title));
  pop.style.transition = "";
  pop.style.transform = "";
  const r = row.getBoundingClientRect();
  convPopWidth = Math.min(innerWidth * .42, 172);
  pop.style.setProperty("top", Math.max(0, Math.round(r.top)) + "px", "important");
  pop.style.setProperty("height", Math.max(58, Math.round(r.height)) + "px", "important");
  pop.classList.remove("on");
  row.classList.remove("conv-swiped");
  requestAnimationFrame(() => {
    row.style.setProperty("--conv-shift", (-convPopWidth) + "px");
    row.classList.add("conv-swiped");
    pop.classList.add("on");
  });
  pop.setAttribute("aria-hidden", "false");
}
function convSwipeStart(e, row, title) {
  if (e.touches.length !== 1) return;
  e.stopPropagation();
  const t = e.touches[0];
  const width = convPopRow === row && convPopWidth
    ? convPopWidth : Math.min(innerWidth * .42, 172);
  convDrag = {row, title, x:t.clientX, y:t.clientY, width,
    open:convPopRow === row, shift:convPopRow === row ? -width : 0};
}
function convSwipeMove(e) {
  if (!convDrag || e.touches.length !== 1) return;
  const t = e.touches[0];
  const dx = t.clientX - convDrag.x;
  const dy = t.clientY - convDrag.y;
  if (!convDrag.open && Math.abs(dx) <= Math.abs(dy)) return;
  if (dx > 0 && !convDrag.open) return;
  if (dx < 0 && convDrag.open) return;
  convSwipeMovedAt = Date.now();
  e.preventDefault();
  e.stopPropagation();
  let shift = convDrag.open
    ? Math.max(-convDrag.width, Math.min(0, -convDrag.width + dx))
    : Math.max(-convDrag.width, Math.min(0, dx));
  convDrag.shift = shift;
  const pop = document.getElementById("convpop");
  if (!convDrag.open) {
    const r = convDrag.row.getBoundingClientRect();
    pop.style.setProperty("top", Math.max(0, Math.round(r.top)) + "px", "important");
    pop.style.setProperty("height", Math.max(58, Math.round(r.height)) + "px", "important");
    convPopRow = convDrag.row;
    convPopTitle = convDrag.title;
    convPopWidth = convDrag.width;
    const same = !!convLabel && convDrag.title === convLabel;
    const btn = document.getElementById("convpopbtn");
    btn.disabled = same;
    btn.textContent = convDrag.title || "对话";
    btn.setAttribute("aria-label", same
      ? (convDrag.title + "，当前会话") : ("切换到 " + convDrag.title));
    pop.classList.add("on");
  }
  convDrag.row.style.transition = "none";
  convDrag.row.style.transform = "translate3d(" + shift + "px,0,0)";
  pop.style.transition = "none";
  pop.style.transform = "translate3d(" + (convDrag.width + shift) + "px,0,0)";
}
function convSwipeEnd() {
  if (!convDrag) return;
  const d = convDrag;
  convDrag = null;
  const pop = document.getElementById("convpop");
  d.row.style.transition = "";
  d.row.style.transform = "";
  pop.style.transition = "";
  pop.style.transform = "";
  const keepOpen = d.open
    ? d.shift <= -d.width * .68
    : d.shift <= -d.width * .32;
  if (keepOpen) {
    convPopRow = d.row;
    convPopTitle = d.title;
    convPopWidth = d.width;
    d.row.style.setProperty("--conv-shift", (-d.width) + "px");
    d.row.classList.add("conv-swiped");
    pop.classList.add("on");
    pop.setAttribute("aria-hidden", "false");
  } else {
    hideConvPop();
  }
}
document.getElementById("convpopbtn").onclick = (e) => {
  e.stopPropagation();
  const title = convPopTitle;
  hideConvPop();
  if (title && title !== convLabel) setConv(title);
};
document.addEventListener("click", (e) => {
  if (!e.target.closest("#convpop")) hideConvPop();
});
document.getElementById("convpop").addEventListener("touchstart", e => {
  if (convPopRow) convSwipeStart(e, convPopRow, convPopTitle);
}, {passive: true});
document.getElementById("convpop").addEventListener("touchmove", convSwipeMove, {passive: false});
document.getElementById("convpop").addEventListener("touchend", convSwipeEnd, {passive: true});

/** 往一个头像位里填东西：图标 / 手机选的图 / emoji / 不显示。 */
function fillAvatar(el, who) {
  const v = who === "me" ? (look.avMe ?? "icon") : (look.avAi ?? "icon");
  el.innerHTML = "";
  if (v === "" ) { el.style.display = "none"; return; }
  el.style.display = "flex";
  if (v === "icon") {
    const img = document.createElement("img");
    img.src = ICON_AV;
    img.style.width = "100%"; img.style.height = "100%"; img.style.objectFit = "cover";
    el.appendChild(img);
  } else if (v.startsWith("emoji:")) {
    el.textContent = v.slice(6);
  } else {
    const img = document.createElement("img");
    img.src = v;
    img.style.width = "100%"; img.style.height = "100%"; img.style.objectFit = "cover";
    el.appendChild(img);
  }
}

/** 换头像之后，把已经显示出来的那些也一起换掉。 */
function refreshAvatars() {
  document.querySelectorAll("#log .row").forEach(row => {
    const who = row.dataset.kind;
    const av = row.querySelector(".av");
    if (av && (who === "me" || who === "ai")) fillAvatar(av, who);
  });
  const head = document.getElementById("avhead");
  if (head) fillAvatar(head, "ai");
}
