// FinDeck replies, schedules, balance, remote access and page lifecycle.

async function pullRaws(manual) {
  const box = document.getElementById("body-raws");
  if (!box) return;
  box.innerHTML = '<div style="color:var(--dim);font-size:13px">正在读电脑上的原话…</div>';
  try {
    const r = await fetch("/api/replies" + Q + (manual ? "&t=" + Date.now() : ""));
    const d = await r.json();
    const items = (d && d.items) ? d.items : [];
    if (!items.length) {
      box.innerHTML = '<div style="color:var(--dim);font-size:13px">电脑那边还没念过回答。</div>';
      return;
    }
    box.innerHTML =
      '<div style="color:var(--dim);font-size:12px;margin:2px 0 10px">' +
      '这里是电脑回答的<b>原话</b>（念出来的那份会去掉 Markdown、代码块这些，听着顺一点）。' +
      '最新的在最上面。</div>' +
      items.map(function (it) {
        return '<div class="f"><div style="color:var(--dim);font-size:11.5px">' +
          esc(it.at || "") + " · " + esc(it.name || "") + "</div>" +
          '<div style="margin-top:5px;white-space:pre-wrap;line-height:1.7">' +
          esc(it.text || "") + "</div></div>";
      }).join("");
  } catch (e) {
    box.innerHTML = '<div style="color:#ff9a9a;font-size:13px">读不到：' + e + "</div>";
  }
}

// ---- 日程页：读电脑上那份日程，手机上能加 / 改 / 删 / 停用 ----
let schedItems = [];
let schedEdit = -1;
function esc(s) {
  return String(s === null || s === undefined ? "" : s).replace(/[&<>"]/g, function (c) {
    return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c];
  });
}
async function pullSchedule(manual) {
  const box = document.getElementById("body-sched");
  if (!box) return;
  box.innerHTML = '<div style="color:var(--dim);font-size:13px">正在读电脑上的日程…</div>';
  try {
    const r = await fetch("/api/schedule" + Q + (manual ? "&t=" + Date.now() : ""));
    const d = await r.json();
    schedItems = (d && d.items) ? d.items : [];
    renderSchedule();
  } catch (e) {
    box.innerHTML = '<div style="color:#ff9a9a;font-size:13px">读不到日程：' + e +
      '<br><span style="color:var(--dim)">（电脑上的助手还开着吗？）</span></div>';
  }
}
function schedKinds(sel) {
  const ks = [["daily", "每天"], ["weekly", "每周"], ["monthly", "每月"], ["once", "只一次"]];
  return ks.map(function (k) {
    return '<option value="' + k[0] + '"' + (k[0] === sel ? " selected" : "") + ">" + k[1] + "</option>";
  }).join("");
}
function renderSchedule() {
  const box = document.getElementById("body-sched");
  if (!box) return;
  let html = "";
  if (!schedItems.length) {
    html += '<div style="color:var(--dim);font-size:13px;margin:4px 0 10px">电脑上还没有日程。</div>';
  }
  schedItems.forEach(function (it) {
    html += '<div class="f"' + (it.enabled ? "" : ' style="opacity:.45"') + ">" +
      '<b style="font-size:16px">' + esc(it.time || "--:--") + "</b>" +
      '<span style="color:var(--dim);font-size:11.5px;margin-left:8px">' + esc(it.when || "") + "</span>" +
      '<div style="margin-top:5px">' + esc(it.text || "") + "</div>" +
      '<div style="margin-top:7px">' +
      '<b class="chip" data-act="toggle" data-i="' + it.i + '">' + (it.enabled ? "停用" : "启用") + "</b> " +
      '<b class="chip" data-act="edit" data-i="' + it.i + '">改</b> ' +
      '<b class="chip" data-act="del" data-i="' + it.i + '">删</b>' +
      "</div></div>";
  });
  const cur = (schedEdit >= 0 && schedItems[schedEdit]) ? schedItems[schedEdit] : null;
  html += '<div class="f" id="schedform">' +
    '<div style="font-weight:600;margin-bottom:8px">' + (cur ? "改这一条" : "加一条日程") + "</div>" +
    '<div style="display:flex;gap:8px;align-items:center">' +
    '<input type="time" id="schedtime" value="' + esc(cur ? cur.time : "09:00") + '">' +
    '<input type="text" id="schedtext" placeholder="到点做什么" value="' + esc(cur ? cur.text : "") + '"' +
    ' style="flex:1;min-width:0">' +
    "</div>" +
    '<div style="margin-top:8px"><select id="schedkind" style="width:100%">' +
    schedKinds(cur ? cur.kind : "daily") + "</select></div>" +
    '<div id="schedwd" style="margin-top:8px"></div>' +
    '<div id="schedmore" style="margin-top:8px"></div>' +
    '<button class="ghost" id="schedsave" style="height:38px;margin-top:10px;width:100%">' +
    (cur ? "存回电脑" : "存到电脑上") + "</button>" +
    (cur ? '<button class="ghost" id="schedcancel" style="height:36px;margin-top:6px;width:100%">不改了</button>' : "") +
    "</div>";
  box.innerHTML = html;
  const kindSel = document.getElementById("schedkind");
  kindSel.onchange = function () { schedExtra(cur); };
  schedExtra(cur);
  document.getElementById("schedsave").onclick = function () { schedSave(cur); };
  const cx = document.getElementById("schedcancel");
  if (cx) cx.onclick = function () { schedEdit = -1; renderSchedule(); };
  box.querySelectorAll(".chip[data-act]").forEach(function (b) {
    b.onclick = function () { schedAct(b.dataset.act, parseInt(b.dataset.i, 10)); };
  });
}
/** 按"每天/每周/每月/只一次"显示不同的补充项。 */
function schedExtra(cur) {
  const kind = document.getElementById("schedkind").value;
  const wd = document.getElementById("schedwd");
  const more = document.getElementById("schedmore");
  const days = ["一", "二", "三", "四", "五", "六", "日"];
  let picked = (cur && cur.weekdays) ? cur.weekdays.slice() : [];
  if (kind === "weekly") {
    wd.innerHTML = days.map(function (d, i) {
      return '<b class="wd' + (picked.indexOf(i) >= 0 ? " on" : "") + '" data-d="' + i + '">' + d + "</b>";
    }).join("");
    wd.querySelectorAll(".wd").forEach(function (b) {
      b.onclick = function () {
        const i = parseInt(b.dataset.d, 10);
        const k = picked.indexOf(i);
        if (k >= 0) picked.splice(k, 1); else picked.push(i);
        b.classList.toggle("on", picked.indexOf(i) >= 0);
      };
    });
  } else {
    wd.innerHTML = "";
  }
  if (kind === "monthly") {
    const md = (cur && cur.monthday) ? cur.monthday : 1;
    more.innerHTML = '每月 <input type="text" id="schedmd" value="' + md +
      '" style="width:60px;text-align:center"> 号';
  } else if (kind === "once") {
    const dt = (cur && cur.date) ? cur.date : new Date().toISOString().slice(0, 10);
    more.innerHTML = '<input type="date" id="scheddate" value="' + dt + '">';
  } else {
    more.innerHTML = "";
  }
}
async function schedAct(act, i) {
  if (act === "edit") { schedEdit = i; renderSchedule(); return; }
  if (act === "del" && !confirm("把这条日程删掉？")) return;
  try {
    const d = await securePost("/api/schedule", {action: act, i: i});
    if (!d.ok) alert("没成：" + (d.msg || ""));
    schedEdit = -1;
    await pullSchedule(true);
  } catch (e) { alert("没成：" + e); }
}
async function schedSave(cur) {
  const item = {
    time: document.getElementById("schedtime").value || "09:00",
    text: document.getElementById("schedtext").value || "",
    kind: document.getElementById("schedkind").value
  };
  const wd = document.getElementById("schedwd");
  if (item.kind === "weekly") {
    item.weekdays = [];
    wd.querySelectorAll(".wd.on").forEach(function (b) {
      item.weekdays.push(parseInt(b.dataset.d, 10));
    });
    if (!item.weekdays.length) { alert("选一个星期几"); return; }
  }
  if (item.kind === "monthly") {
    const md = document.getElementById("schedmd");
    item.monthday = md ? (parseInt(md.value, 10) || 1) : 1;
  }
  if (item.kind === "once") {
    const dt = document.getElementById("scheddate");
    item.date = dt ? dt.value : "";
  }
  if (!String(item.text).trim()) { alert("写点内容吧"); return; }
  try {
    const d = await securePost("/api/schedule", {
      action: cur ? "save" : "add", i: cur ? cur.i : -1, item: item});
    if (!d.ok) { alert("没成：" + (d.msg || "")); return; }
    schedEdit = -1;
    await pullSchedule(true);
  } catch (e) { alert("没成：" + e); }
}
// 把已经做好的两块面板（屏幕 / 文件）搬进各自的子页里
(function moveIntoPages() {
  const shots = document.getElementById("shots");
  const files = document.getElementById("files");
  if (shots) {
    const t = shots.querySelector("#shottoggle");
    if (t) t.style.display = "none";
    document.getElementById("body-shots").appendChild(shots);
    shots.classList.add("open");
    shots.style.margin = "0";
  }
  if (files) {
    const t = files.querySelector("#filetoggle");
    if (t) t.style.display = "none";
    document.getElementById("body-files").appendChild(files);
    files.classList.add("open");
    files.style.margin = "0";
  }
})();

// ---- 搜历史：让电脑把带关键词的那几行挑出来 ----
document.getElementById("searchgo").onclick = doSearch;
document.getElementById("searchbox").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); doSearch(); }
});
async function doSearch() {
  const kw = document.getElementById("searchbox").value.trim();
  if (!kw) return;
  const out = document.getElementById("searchout");
  out.innerHTML = "搜…";
  try {
    const r = await fetch("/api/log?since=0&q=" + encodeURIComponent(kw) + "&k=" + encodeURIComponent(KEY));
    const d = await r.json();
    out.innerHTML = "";
    const head = document.createElement("div");
    head.style.color = "var(--dim)";
    head.style.fontSize = "12px";
    head.textContent = "找到 " + (d.lines || []).length + " 条带「" + kw + "」的";
    out.appendChild(head);
    for (const it of (d.lines || [])) {
      const row = document.createElement("div");
      row.className = "row" + (it.kind === "me" ? " right" : "");
      const b = document.createElement("div");
      b.className = "bubble " + it.kind;
      b.textContent = it.text;
      row.appendChild(b);
      out.appendChild(row);
    }
  } catch (e) {
    out.textContent = "搜不了，连不上电脑";
  }
}

// 手机端的"语音说话"按钮已经去掉了（按用户要求）——录音和识别还是电脑那边的事，
// 手机上直接打字或者点 ＋ 里的快捷指令。
// 电脑识别完会把文字回来（APP 通过 evaluateJavascript 调这个）
window.onVoiceResult = (text) => {
  if (text) { add("me", text); }
  setTimeout(pull, 900);
};

// 页面里要是哪里报错了，别静悄悄地"点了没反应" —— 直接在顶上红条写出来，
// 这样你截个图发我，我一眼就知道卡在哪。
window.onerror = (msg, src, line) => {
  try {
    let bar = document.getElementById("errbar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "errbar";
      bar.style.cssText = "position:fixed;left:0;right:0;top:0;z-index:99;background:#7a1f1f;"
        + "color:#fff;font-size:12px;padding:6px 10px;";
      document.body.appendChild(bar);
    }
    bar.textContent = "页面出错了：" + msg + "（第 " + line + " 行）";
  } catch (e) {}
  return false;
};
box.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); document.getElementById("send").click(); }
});
applyLook();
buildSheet();
// 从后台切回来（或页面被系统重载）时立刻补一次，别等 2 秒的定时器：
// 用户反馈"问了之后退到后台，回来就看不到了"——那时定时器常被系统冻住，
// 回来如果不主动拉一次，界面上就一直停在被冻住那一刻。
function catchUp() {
  pulling = false;              // 万一卡在"上一次请求还没回来"，放开闸
  if (typeof pull === "function") pull();
  // 回来看到底：新消息在下面
  try { logEl.scrollTop = logEl.scrollHeight; } catch (e) {}
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") catchUp();
});
window.addEventListener("pageshow", catchUp);
window.addEventListener("focus", catchUp);
setInterval(() => pullShots(false), 3000);
checkUpdate();

// ---- 名字（默认跟电脑上那个一样） + 版本显示 ----
async function loadInfo() {
  try {
    const r = await fetch("/api/info" + Q);
    const d = await r.json();
    const nm = look.name || d.name || "大肥鱼";
    document.getElementById("appname").textContent = nm;
    document.title = nm;
    const nl = document.getElementById("nameline");
    if (nl && !nl.value) nl.placeholder = d.name || "大肥鱼";
    const vl = document.getElementById("verline");
    if (vl) {
      const pv = vl.dataset.phone || "";
      vl.textContent = "手机端 " + (pv || "—") + " · 电脑端 " + ("v" + (d.pc || "?"));
    }
    siteBase = String(d.update_url || "").trim();     // 公网下载页网址（有就用它）
    // 外网固定地址（Tailscale）：不在同一个 Wi-Fi 时用这条
    remoteUrl = String(d.fixed_url || "").trim();
    tsApk = String(d.tailscale_apk || "").trim();
    const fu = document.getElementById("fixedurl");
    if (fu) {
      fu.textContent = remoteUrl || (d.remote_hint || "外网访问不可用");
      fu.style.color = remoteUrl ? "var(--fg)" : "var(--dim)";
    }
    const tst = document.getElementById("tstip");
    if (tst && d.remote_tip) tst.textContent = d.remote_tip;
    // 公网地址开着的时候，手机什么都不用装 —— 那两个「装 / 开 Tailscale」「后台自动连」
    // 就是多余的了，藏起来，免得让人以为还得开 VPN（用户明确问过这个）。
    if (d.funnel_on) {
      const lab = document.getElementById("remotelab");
      if (lab) lab.textContent = "外网访问（公网地址 · 手机什么都不用装）";
      ["tssetup", "tsalways"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
      });
      if (tst) tst.textContent = "手机不用装任何东西：把上面这条地址发到手机上打开就行；" +
        "用 APP 的话点「用这条地址连」，或者扫电脑上的二维码。家里同一个 Wi-Fi 时，" +
        "用局域网那条（设置里的「手机网址」）最快。";
    }
    // 记住它：APP 里万一局域网连不上，能拿这条外网地址兜底
    try { if (remoteUrl) localStorage.setItem("remote", remoteUrl); } catch (e) {}
    try {
      if (remoteUrl && window.VoiceApp && VoiceApp.rememberRemote) VoiceApp.rememberRemote(remoteUrl);
      if (tsApk && window.VoiceApp && VoiceApp.rememberApk) VoiceApp.rememberApk(tsApk);
    } catch (e) {}
    // 署名 / 版权（跟电脑端「关于」一个来源：都读电脑上那个 version.py，改一处两边都变）
    const set = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text || "";
    };
    set("aboutauthor", d.author ? ("作者：" + d.author) : "作者：—");
    set("aboutcontact", d.contact ? ("邮箱：" + d.contact) : "邮箱：—");
    set("aboutcopy", d.copyright || "");
    set("aboutfree", d.free || "");
    set("aboutnotice", d.notice || "");
  } catch (e) {}
}
function shortTokens(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return "—";
  if (v >= 1e9) return (v / 1e9).toFixed(1) + "B";
  if (v >= 1e6) return (v / 1e6).toFixed(1) + "M";
  if (v >= 1e3) return (v / 1e3).toFixed(1) + "K";
  return String(Math.round(v));
}
function shortMoney(n, currency) {
  const v = Number(n);
  if (!Number.isFinite(v)) return "—";
  const sign = String(currency || "CNY").toUpperCase() === "CNY" ? "¥" : "$";
  return sign + v.toFixed(v > 0 && v < 0.1 ? 4 : 2);
}
let balanceTurnSig = "";
try { balanceTurnSig = localStorage.getItem("balanceTurnSig") || ""; } catch (e) {}
let balanceToastTimer = 0;
function showSpendToast(turn, bal) {
  const toast = document.getElementById("balanceToast");
  if (!toast) return;
  const input = Number(turn.input) || 0;
  const cached = Math.min(input, Number(turn.cached) || 0);
  const output = Number(turn.output) || 0;
  const fresh = Math.max(0, input - cached) + output;
  const total = Number(turn.total) || fresh;
  const label = "吃掉 " + shortTokens(fresh || total) + " token"
    + (total > (fresh || 1) * 1.5 ? "（含缓存 " + shortTokens(total) + "）" : "")
    + " · ≈" + shortMoney(turn.costCNY, bal.currency);
  toast.textContent = label;
  toast.classList.remove("show");
  void toast.offsetWidth;
  toast.classList.add("show");
  clearTimeout(balanceToastTimer);
  balanceToastTimer = setTimeout(() => toast.classList.remove("show"), 5200);
}
async function refreshBalance() {
  const remain = document.getElementById("balanceRemain");
  const spend = document.getElementById("balanceSpend");
  if (!remain || !spend) return;
  try {
    const r = await fetch("/api/balance?k=" + encodeURIComponent(KEY)
      + "&t=" + Date.now(), {cache:"no-store"});
    const d = await r.json();
    const bal = d.balance || {};
    const turn = d.lastTurn || {};
    const today = Number((d.spend || {}).today);
    if (d.enabled === false || d.ok === false || !Number.isFinite(Number(bal.total))) {
      remain.textContent = d.enabled === false ? "余额关" : "未连接";
      spend.textContent = "本轮 — tok / ¥—";
      return;
    }
    remain.textContent = shortMoney(bal.total, bal.currency);
    spend.textContent = "本轮 " + shortTokens(turn.total) + " tok / "
      + shortMoney(turn.costCNY, bal.currency);
    const sig = [turn.at || 0, turn.total || 0, turn.costCNY || 0].join("|");
    if (Number(turn.total) > 0 && balanceTurnSig && sig !== balanceTurnSig) {
      showSpendToast(turn, bal);
    }
    if (Number(turn.total) > 0 && sig !== balanceTurnSig) {
      balanceTurnSig = sig;
      try { localStorage.setItem("balanceTurnSig", sig); } catch (e) {}
    }
    spend.title = "今日已花 " + shortMoney(today, bal.currency)
      + "；余额更新于 "
      + (bal.checkedAt ? new Date(Number(bal.checkedAt)).toLocaleTimeString("zh-CN",
          {hour:"2-digit", minute:"2-digit"}) : "—");
  } catch (e) {
    remain.textContent = "未连接";
    spend.textContent = "本轮 — tok / ¥—";
  }
}
// ---- 外网那一栏：复制 / 装-开 Tailscale / 用这条地址连 ----
// （以前这三样被误塞进了下面 nameline.onchange 里面，结果"点了没反应" —— 搬出来。）
function wireRemote() {
  const fc = document.getElementById("fixedcopy");
  if (fc) {
    fc.onclick = () => {
      if (!remoteUrl) {
        alert("电脑那边外网访问还没开。请在电脑上打开 设置 → 智能 → 外网访问 → 一键开启");
        return;
      }
      if (navigator.clipboard) {
        navigator.clipboard.writeText(remoteUrl).then(
          () => { fc.textContent = "已复制"; setTimeout(() => fc.textContent = "复制", 1500); },
          () => alert("复制不了，手动抄一下吧：" + remoteUrl));
      } else {
        alert(remoteUrl);
      }
    };
  }
  const setup = document.getElementById("tssetup");
  if (setup) {
    setup.onclick = () => {
      if (window.VoiceApp && VoiceApp.tailscale) {
        VoiceApp.tailscale(tsApk);      // APP 里：帮它下 APK，装好直接打开
      } else if (tsApk) {
        location.href = tsApk;          // 浏览器里：下载官方 APK
      } else {
        alert("电脑上还没填下载站网址，没法自动下 APK。可以自己在应用商店搜 Tailscale");
      }
    };
  }
  const use = document.getElementById("fixeduse");
  if (use) {
    use.onclick = () => {
      if (!remoteUrl) { alert("还没有外网地址：先在电脑上点「一键开启」"); return; }
      if (window.VoiceApp && VoiceApp.useUrl) VoiceApp.useUrl(remoteUrl);
      else location.href = remoteUrl;
    };
  }
  // 「后台自动连」：去安卓的 VPN 设置，把 Tailscale 设成"始终开启" —— 设一次，
  // 以后只要开鳍舱这一个 APP，在家走局域网、在外走 Tailscale，全自动。
  const always = document.getElementById("tsalways");
  if (always) {
    always.onclick = () => {
      if (window.VoiceApp && VoiceApp.alwaysOn) {
        VoiceApp.alwaysOn();
      } else {
        alert("这一步要在 APP 里做：打开鳍舱 APP → 设置 → 外网访问 → 「后台自动连」。"
              + "（浏览器里没法改手机的 VPN 设置）");
      }
    };
  }
}
wireRemote();
document.getElementById("nameline").onchange = (e) => {
  look.name = e.target.value.trim();
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
  const nm = look.name || "大肥鱼";
  document.getElementById("appname").textContent = nm;
  document.title = nm;
};
loadInfo();
refreshBalance();
setInterval(refreshBalance, 10000);
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js?k=" + encodeURIComponent(KEY)).catch(() => {});
}
// 页面改动后自动跟上电脑端的最新版本；首次仍需手动刷新一次来装载这段逻辑。
const PAGE_REV = (document.querySelector('meta[name="page-rev"]') || {}).content || "";
async function checkPageRevision() {
  try {
    const r = await fetch("/api/version?k=" + encodeURIComponent(KEY), {cache: "no-store"});
    const d = await r.json();
    if (PAGE_REV && d.page_rev && d.page_rev !== PAGE_REV) location.reload();
  } catch (e) {}
}
setTimeout(checkPageRevision, 1200);
setInterval(checkPageRevision, 10000);
// 左侧设置抽屉跟手横滑：向左拖收起，松手决定回弹或关闭。
const sheetEl = document.getElementById("sheet");
const sheetHead = document.getElementById("sheethead");
if (sheetEl && sheetHead) {
  let sheetX = null, sheetDx = 0;
  sheetHead.addEventListener("touchstart", (e) => {
    const t = e.touches[0]; if (!t) return;
    sheetX = t.clientX; sheetDx = 0;
  }, {passive: true});
  sheetHead.addEventListener("touchmove", (e) => {
    if (sheetX === null) return;
    const t = e.touches[0]; if (!t) return;
    sheetDx = Math.min(0, t.clientX - sheetX);
    if (sheetDx < 0) {
      sheetEl.style.transition = "none";
      sheetEl.style.transform = "translateX(" + sheetDx + "px)";
    }
  }, {passive: true});
  sheetHead.addEventListener("touchend", () => {
    if (sheetX === null) return;
    sheetEl.style.transition = "";
    sheetEl.style.transform = "";
    if (sheetDx < -72) {
      sheetEl.classList.remove("open");
      document.getElementById("sheetbg").classList.remove("on");
    }
    sheetX = null; sheetDx = 0;
  }, {passive: true});
}

// Windows 10 Reveal 微光：桌面/触控笔才有，跟随指针位置，不改变布局。
document.addEventListener("pointermove", (e) => {
  if (e.pointerType === "touch") return;
  const el = e.target.closest(
    "#drawerTabs button, #convdrawer .drow, #pluspanel .tile, " +
    "#quick b, #sheet .chips b, #send, #stop, #plus");
  if (!el) return;
  const box = el.classList.contains("tile") ? el.querySelector(".box") : el;
  if (!box) return;
  const r = box.getBoundingClientRect();
  box.style.setProperty("--rx", Math.round((e.clientX - r.left) / r.width * 100) + "%");
  box.style.setProperty("--ry", Math.round((e.clientY - r.top) / r.height * 100) + "%");
}, {passive: true});

if (new URLSearchParams(location.search).has("debug")) {
  setTimeout(() => {
    const rect = (el) => {
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return {x: Math.round(r.x), w: Math.round(r.width), right: Math.round(r.right)};
    };
    const rows = [...document.querySelectorAll(".row.right")].map(row => ({
      row: rect(row), bubble: rect(row.querySelector(".bubble")),
    }));
    const pre = document.createElement("pre");
    pre.id = "layoutDebug";
    pre.textContent = JSON.stringify({
      innerWidth, log: rect(document.getElementById("log")), rows,
    }, null, 2);
    document.body.appendChild(pre);
  }, 2500);
}
