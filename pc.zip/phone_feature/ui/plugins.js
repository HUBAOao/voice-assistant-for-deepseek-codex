// FinDeck phone management surfaces: plugins and real-device acceptance.
// Loaded after the main page script, sharing its Q and securePost helpers.

let pluginPullGeneration = 0;
let pluginActionGeneration = 0;

function setPluginStatus(text, danger = false) {
  const box = document.getElementById("pluginStatus");
  box.textContent = text || "";
  box.style.color = danger ? "#ff9b9b" : "";
}

function pluginStatusText(item) {
  if (item.last_error) return "最近失败：" + item.last_error;
  if (item.error) return item.error;
  if (item.loaded) return "已启用并运行";
  if (item.enabled) return "已启用，等待下一次加载";
  return item.sealed ? "已安装，未启用" : "未通过本机安装签名";
}

function publisherText(signature) {
  if (!signature || !signature.signed) return "发布者未签名（本机侧载）";
  const publisher = signature.publisher || {};
  if (!signature.valid) return "发布者签名无效：" + (signature.error || "");
  return "发布者 " + (publisher.name || publisher.id || "未知")
    + " · " + (publisher.key_id || "")
    + (signature.trusted ? " · 已信任" : " · 尚未信任");
}

async function pluginAction(id, action, extra = {}) {
  const generation = ++pluginActionGeneration;
  setPluginStatus("正在处理扩展…");
  const d = await securePost("/api/plugins/action",
    Object.assign({action, id}, extra));
  if (generation !== pluginActionGeneration) return false;
  if (!d.ok) setPluginStatus(d.err || "插件操作失败", true);
  else setPluginStatus("扩展操作已完成。");
  await pullPlugins(true);
  return d.ok;
}

async function pullPlugins(manual = false) {
  const generation = ++pluginPullGeneration;
  const summary = document.getElementById("pluginSummary");
  const box = document.getElementById("pluginList");
  try {
    const r = await fetch("/api/plugins" + Q, {cache: "no-store"});
    const d = await r.json();
    if (generation !== pluginPullGeneration) return;
    if (!d.ok) throw new Error(d.err || "读取失败");
    const rows = Array.isArray(d.plugins) ? d.plugins : [];
    summary.textContent = rows.length
      ? rows.length + " 个已安装 · "
        + rows.filter(x => x.loaded).length + " 个运行中 · API " + d.api
      : "还没有插件。选择 ZIP 包后会先展示能力和权限，确认后才安装。";
    box.innerHTML = "";
    for (const item of rows) {
      const card = document.createElement("div");
      card.className = "taskCard";
      const title = document.createElement("div");
      title.className = "taskTitle";
      title.textContent = item.name + " · v" + item.version;
      card.appendChild(title);
      const meta = document.createElement("div");
      meta.className = "taskMeta";
      meta.textContent = (item.description || item.id)
        + "\n能力：" + ((item.capabilities || []).join(", ") || "无")
        + " · 权限：" + ((item.permissions || []).join(", ") || "无")
        + "\n" + publisherText(item.publisher_signature);
      card.appendChild(meta);
      const state = document.createElement("div");
      state.className = "taskMeta";
      state.textContent = pluginStatusText(item);
      card.appendChild(state);
      const actions = document.createElement("div");
      actions.className = "taskActions three";
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = item.enabled ? "停用" : "启用";
      toggle.disabled = !item.enabled && (!item.sealed || !!item.error);
      toggle.onclick = () => pluginAction(
        item.id, item.enabled ? "disable" : "enable");
      const reload = document.createElement("button");
      reload.type = "button"; reload.textContent = "重载";
      reload.disabled = !item.enabled;
      reload.onclick = () => pluginAction(item.id, "reload");
      const rollback = document.createElement("button");
      rollback.type = "button";
      rollback.textContent = "回滚";
      rollback.hidden = !item.rollback_available;
      rollback.onclick = () => {
        if (confirm("回滚「" + item.name + "」到 v"
            + item.rollback_version + "？\n\n回滚后插件保持关闭。")) {
          pluginAction(item.id, "rollback", {confirm: true});
        }
      };
      const remove = document.createElement("button");
      remove.type = "button"; remove.className = "danger";
      remove.textContent = "移除";
      remove.onclick = () => {
        if (confirm("移除「" + item.name + "」？文件会移到可恢复的回收目录。")) {
          pluginAction(item.id, "remove", {confirm: true});
        }
      };
      actions.appendChild(toggle);
      actions.appendChild(reload);
      actions.appendChild(rollback);
      actions.appendChild(remove);
      card.appendChild(actions);
      if (item.publisher_signature && item.publisher_signature.signed
          && item.publisher_signature.valid
          && !item.publisher_signature.trusted) {
        const trust = document.createElement("div");
        trust.className = "taskActions";
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "信任此发布者";
        button.onclick = () => {
          const publisher = item.publisher_signature.publisher || {};
          if (confirm("信任发布者「" + (publisher.name || publisher.id)
              + "」\n密钥：" + (publisher.key_id || "")
              + "\n\n以后来自这把密钥的市场插件可直接通过签名校验。")) {
            pluginAction(item.id, "trust_plugin", {confirm: true});
          }
        };
        trust.appendChild(button);
        card.appendChild(trust);
      }
      box.appendChild(card);
    }
    if (!rows.length) {
      const empty = document.createElement("div");
      empty.className = "taskMeta";
      empty.textContent = "插件目录：" + (d.root || "");
      box.appendChild(empty);
    }
    renderMarket(d.market || {}, d.publishers || []);
  } catch (e) {
    if (generation === pluginPullGeneration) {
      summary.textContent = "读取失败：" + e;
      setPluginStatus("扩展列表读取失败，可在原地重试。", true);
    }
  }
}

function renderMarket(market, knownPublishers) {
  const summary = document.getElementById("marketSummary");
  const box = document.getElementById("marketList");
  const publishers = document.getElementById("publisherList");
  const sources = Array.isArray(market.sources) ? market.sources : [];
  summary.textContent = sources.length
    ? sources.length + " 个市场源 · " + (market.plugin_count || 0)
      + " 个插件 · 市场只接受有效发布者签名"
    : "还没有市场源。添加 HTTPS 目录地址后再安装；市场包仍需信任发布者。";
  box.innerHTML = "";
  for (const source of sources) {
    const card = document.createElement("div");
    card.className = "taskCard";
    const title = document.createElement("div");
    title.className = "taskTitle";
    title.textContent = source.name + (source.error ? " · 刷新失败" : "");
    card.appendChild(title);
    const meta = document.createElement("div");
    meta.className = "taskMeta";
    meta.textContent = source.url + (source.error ? "\n" + source.error : "");
    card.appendChild(meta);
    for (const item of source.plugins || []) {
      const row = document.createElement("div");
      row.className = "taskCard";
      const name = document.createElement("div");
      name.className = "taskTitle";
      name.textContent = item.name + " · v" + item.version;
      const info = document.createElement("div");
      info.className = "taskMeta";
      info.textContent = (item.description || item.id)
        + "\n发布者：" + item.publisher
        + " · 权限：" + ((item.permissions || []).join(", ") || "无");
      const actions = document.createElement("div");
      actions.className = "taskActions";
      const install = document.createElement("button");
      install.type = "button";
      install.textContent = "检查并安装";
      install.onclick = () => marketInstall(source.id, item);
      actions.appendChild(install);
      row.appendChild(name);
      row.appendChild(info);
      row.appendChild(actions);
      card.appendChild(row);
    }
    const actions = document.createElement("div");
    actions.className = "taskActions";
    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.textContent = "刷新此源";
    refresh.onclick = () => pluginAction(
      "", "market_refresh", {source_id: source.id});
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "danger";
    remove.textContent = "移除源";
    remove.onclick = () => {
      if (confirm("移除市场源「" + source.name + "」？已安装插件不受影响。")) {
        pluginAction("", "market_remove", {
          source_id: source.id, confirm: true
        });
      }
    };
    actions.appendChild(refresh);
    actions.appendChild(remove);
    card.appendChild(actions);
    box.appendChild(card);
  }
  publishers.textContent = "";
  if (!knownPublishers.length) {
    publishers.textContent = "还没有已信任的发布者。";
    return;
  }
  const title = document.createElement("div");
  title.className = "taskTitle";
  title.textContent = "已信任发布者";
  publishers.appendChild(title);
  for (const publisher of knownPublishers) {
    const row = document.createElement("div");
    row.className = "taskActions";
    const label = document.createElement("div");
    label.className = "taskMeta";
    label.textContent = publisher.name + " · " + (publisher.key_id || "");
    const revoke = document.createElement("button");
    revoke.type = "button";
    revoke.className = "danger";
    revoke.textContent = "撤销信任";
    revoke.onclick = () => {
      if (confirm("撤销发布者「" + publisher.name
          + "」的信任？已安装插件保留。")) {
        pluginAction("", "untrust_publisher", {
          publisher_id: publisher.id, confirm: true
        });
      }
    };
    row.appendChild(label);
    row.appendChild(revoke);
    publishers.appendChild(row);
  }
}

async function marketInstall(sourceId, item) {
  const generation = ++pluginActionGeneration;
  try {
    setPluginStatus("正在下载并校验 " + item.name + "…");
    let out = await securePost("/api/plugins/action", {
      action: "market_install", source_id: sourceId, id: item.id, confirm: true
    });
    if (generation !== pluginActionGeneration) return;
    if (out.needs_confirmation) {
      const plugin = out.plugin || {};
      const permissions = Array.isArray(plugin.permissions)
        ? plugin.permissions : (item.permissions || []);
      if (!confirm("安装市场插件「" + (plugin.name || item.name) + "」？\n\n"
          + "发布者：" + ((plugin.publisher || {}).name || item.publisher)
          + "\n权限：" + (permissions.join(", ") || "无")
          + "\n\n下载包通过签名与 SHA-256 校验后，仍需手动启用。")) {
        setPluginStatus("已取消，没有安装。");
        return;
      }
      out = await securePost("/api/plugins/action", {
        action: "market_install", source_id: sourceId, id: item.id,
        confirmed_permissions: permissions, confirm: true
      });
      if (generation !== pluginActionGeneration) return;
    }
    if (out.needs_trust) {
      const publisher = (out.plugin || {}).publisher
        || (out.publisher_signature || {}).publisher || {};
      if (!confirm("这个市场包的发布者尚未信任。\n\n"
          + "发布者：" + (publisher.name || publisher.id || item.publisher)
          + "\n密钥：" + (publisher.key_id || item.key_id || "")
          + "\n\n确认信任后再重试安装？")) {
        setPluginStatus("已取消，没有安装。");
        return;
      }
      const trusted = await securePost("/api/plugins/action", {
        action: "trust_publisher", publisher, confirm: true
      });
      if (!trusted.ok) throw new Error(trusted.err || "信任发布者失败");
      out = await securePost("/api/plugins/action", {
        action: "market_install", source_id: sourceId, id: item.id,
        confirmed_permissions: item.permissions || [], confirm: true
      });
      if (generation !== pluginActionGeneration) return;
    }
    if (!out.ok || !out.installed) throw new Error(out.err || "安装失败");
    setPluginStatus("已安装 " + out.name + " v" + out.version
      + "，保持关闭状态。");
    await pullPlugins(true);
  } catch (err) {
    setPluginStatus("市场安装失败：" + err, true);
  }
}

document.getElementById("pluginRefresh").onclick = () => pullPlugins(true);
document.getElementById("marketAdd").onclick = async () => {
  const generation = ++pluginActionGeneration;
  const input = document.getElementById("marketSource");
  const url = (input.value || "").trim();
  if (!url) return;
  if (!confirm("添加插件市场源？\n\n" + url
      + "\n\n目录本身只负责发现；安装时仍强制校验发布者签名。")) return;
  try {
    const out = await securePost("/api/plugins/action", {
      action: "market_add", url, confirm: true
    });
    if (generation !== pluginActionGeneration) return;
    if (!out.ok) throw new Error(out.err || "添加失败");
    input.value = "";
    await pullPlugins(true);
  } catch (err) {
    setPluginStatus("添加市场源失败：" + err, true);
  }
};
document.getElementById("marketRefresh").onclick =
  () => pluginAction("", "market_refresh_all");
document.getElementById("pluginChoose").onclick =
  () => document.getElementById("pluginFile").click();
document.getElementById("pluginFile").onchange = async e => {
  const generation = ++pluginActionGeneration;
  const file = e.target.files && e.target.files[0];
  e.target.value = "";
  if (!file) return;
  setPluginStatus("正在检查 " + file.name + "…");
  try {
    const raw = await file.arrayBuffer();
    let out = await securePostRaw("/api/plugins/install", raw);
    if (generation !== pluginActionGeneration) return;
    if (out.needs_confirmation) {
      const plugin = out.plugin || {};
      const permissions = Array.isArray(plugin.permissions)
        ? plugin.permissions : [];
      const capabilities = Array.isArray(plugin.capabilities)
        ? plugin.capabilities : [];
      const text = "安装「" + (plugin.name || plugin.id || file.name) + "」？\n\n"
        + "版本：" + (plugin.version || "未知") + "\n"
        + "能力：" + (capabilities.join(", ") || "无") + "\n"
        + "声明权限：" + (permissions.join(", ") || "无") + "\n\n"
        + "安装不会自动执行；确认权限后仍需手动启用。"
        + "权限是声明，不是安全沙箱。";
      if (!confirm(text)) {
        setPluginStatus("已取消，没有写入插件。");
        return;
      }
      out = await securePostRaw("/api/plugins/install", raw, {
        "X-FinDeck-Plugin-Permissions": JSON.stringify(permissions)
      });
      if (generation !== pluginActionGeneration) return;
    }
    if (!out.ok || !out.installed) {
      throw new Error(out.err || "安装失败");
    }
    setPluginStatus("已安装 " + out.name + " v" + out.version
      + "，保持关闭状态。");
    await pullPlugins(true);
  } catch (err) {
    setPluginStatus("安装失败：" + err, true);
  }
};
