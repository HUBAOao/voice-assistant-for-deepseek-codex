// FinDeck page authentication, theme, avatars and update helpers.

// Shared touch intent for the two drawer-entry gestures. Other scrolling and
// gestures keep their existing thresholds.
(() => {
  const ARM_DISTANCE = 42;
  const AXIS_RATIO = 1.25;
  function axisIntent(dx, dy) {
    const horizontal = Math.abs(Number(dx) || 0);
    const vertical = Math.abs(Number(dy) || 0);
    if (Math.max(horizontal, vertical) < ARM_DISTANCE) return "";
    if (horizontal >= vertical * AXIS_RATIO) return dx < 0 ? "left" : "right";
    if (vertical >= horizontal * AXIS_RATIO) return dy < 0 ? "up" : "down";
    return "";
  }
  function travelPastArm(delta) {
    const value = Number(delta) || 0;
    if (Math.abs(value) < ARM_DISTANCE) return 0;
    return value - Math.sign(value) * ARM_DISTANCE;
  }
  window.FinDeckGesture = Object.freeze({
    ARM_DISTANCE,
    AXIS_RATIO,
    axisIntent,
    travelPastArm,
  });
})();

const KEY = new URLSearchParams(location.search).get("k") || "";
const Q = "?k=" + encodeURIComponent(KEY);
let capabilityValue = "";
let capabilityUntil = 0;
let capabilityPromise = null;
async function getCapability(force = false) {
  if (!force && capabilityValue && Date.now() / 1000 < capabilityUntil - 20) {
    return capabilityValue;
  }
  if (capabilityPromise) return capabilityPromise;
  capabilityPromise = (async () => {
    const r = await fetch("/api/security/session" + Q, {cache: "no-store"});
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d.ok || !d.capability) {
      throw new Error(d.err || "领取操作凭据失败");
    }
    capabilityValue = String(d.capability);
    capabilityUntil = Number(d.expires_at || 0);
    return capabilityValue;
  })();
  try {
    return await capabilityPromise;
  } finally {
    capabilityPromise = null;
  }
}
async function securePost(path, body) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const cap = await getCapability(attempt > 0);
    const r = await fetch(path + Q, {
      method: "POST",
      headers: {"Content-Type": "application/json",
                "X-FinDeck-Capability": cap},
      body: JSON.stringify(body || {})
    });
    const d = await r.json().catch(() => ({}));
    if (r.status === 403 && d.need_capability && !attempt) continue;
    return d;
  }
  return {ok: false, err: "操作凭据失效"};
}
async function securePostRaw(path, body, headers = {}) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const cap = await getCapability(attempt > 0);
    const sep = path.includes("?") ? "&" : "?";
    const r = await fetch(path + sep + "k=" + encodeURIComponent(KEY), {
      method: "POST",
      headers: Object.assign({
        "Content-Type": "application/octet-stream",
        "X-FinDeck-Capability": cap
      }, headers || {}),
      body
    });
    const d = await r.json().catch(() => ({}));
    if (r.status === 403 && d.need_capability && !attempt) continue;
    return d;
  }
  return {ok: false, err: "操作凭据失效"};
}
// 公网下载页的网址（电脑设置里填过才有）。有了它，更新就以**网站上的文件**为准。
let siteBase = "";
// 外网那条固定地址（电脑上 Tailscale 开着才有）和它的官方 APK 地址。
// 手机不在同一个 Wi-Fi 时，就是靠这两样切过去。
let remoteUrl = "";
let tsApk = "";
const mine = [];                 // 我刚发出去的几句（防止日志回读时显示两条）
const ACCENTS = ["#3ddc84", "#4aa8ff", "#b06bff", "#f0a13c", "#ff6b9d", "#22d3ee"];
// 头像：默认就是程序那个图标（服务端已经在发 /icon-192.png），也能从手机相册选。
const ICON_AV = "icon-192.png?k=" + encodeURIComponent(
  new URLSearchParams(location.search).get("k") || "");
const AV_EMOJI = ["🐟", "🐰", "🐱", "🤖", "🧑", "😎", "🌙", "🍀"];
const BGS = [["深色", "#1b1b1f", "#26262d", "#33333c", "#f2f2f5"],
             ["纯黑", "#000000", "#111419", "#252c35", "#edf1f4"],
             ["浅色", "#f3f4f6", "#ffffff", "#d9dee5", "#171b20"],
             ["藏青", "#0d1522", "#172238", "#2b3b57", "#eef2ff"]];
function colorTriplet(value, fallback) {
  const match = /^#([0-9a-f]{6})$/i.exec(String(value || ""));
  const source = match ? match[1] : fallback;
  const number = parseInt(source, 16);
  return [
    (number >> 16) & 255,
    (number >> 8) & 255,
    number & 255
  ].join(",");
}
let look = JSON.parse(localStorage.getItem("look") || "{}");
if (!look.__minimal) {
  if (!look.accent || ["#3ddc84", "#f2c45e"].includes(look.accent)) {
    look.accent = "#7c9cf5";
    look.accentInk = "#0d1426";
  }
  if (!look.bg || ["深色", "深海终端"].includes(look.bgName)) {
    look.bg = BGS[0];
    look.bgName = "极简深色";
  }
  look.__minimal = true;
  look.__deepsea = true;
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (e) {}
}
if (!look.__apple) {
  if (!look.accent || look.accent === "#7c9cf5") {
    look.accent = "#5b7cf0";
    look.accentInk = "#ffffff";
  }
  look.__apple = true;
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (e) {}
}
if (!look.__revert) {
  if (!look.accent || ["#5b7cf0", "#7c9cf5", "#f2c45e"].includes(look.accent)) {
    look.accent = "#3ddc84";
    look.accentInk = "#10261a";
  }
  if (!look.bg || ["极简深色", "深海终端", "深色"].includes(look.bgName)) {
    look.bg = BGS[0];
    look.bgName = "深色";
  }
  look.__revert = true;
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (e) {}
}
let lastSentAt = 0;

function chatColorVars(hex, alpha) {
  const clean = String(hex || "#3ddc84").replace("#", "");
  const full = clean.length === 3 ? clean.split("").map(x => x + x).join("") : clean;
  const ar = parseInt(full.slice(0, 2), 16) || 61;
  const ag = parseInt(full.slice(2, 4), 16) || 220;
  const ab = parseInt(full.slice(4, 6), 16) || 132;
  const br = 7, bg = 16, bb = 12;
  const mix = (x, y) => Math.round(x * 0.74 + y * 0.26);
  return {
    ai: "rgba(16,18,23," + alpha + ")",
    me: "rgba(" + mix(ar, br) + "," + mix(ag, bg) + "," + mix(ab, bb) + "," + alpha + ")",
  };
}

/** 应用外观：主题色 / 背景 / 字号 / 动画开关（存在手机上，换页面也记得）。 */
function applyLook() {
  const a = look.accent || "#3ddc84";
  const bg = look.bg || BGS[0];
  const r = document.documentElement.style;
  r.setProperty("--accent", a);
  r.setProperty("--accent-ink", (look.accentInk || "#10261a"));
  r.setProperty("--bg", bg[1]);
  r.setProperty("--panel", bg[2]);
  r.setProperty("--line", bg[3]);
  r.setProperty("--fg", bg[4]);
  r.setProperty("--dim", bg[4] === "#171b20" ? "#66707b" : "#8d98a6");
  r.setProperty("--font", (look.font || "15px"));
  const chatAlpha = Math.max(.05, Math.min(1,
    look.chatAlpha === undefined ? .55 : Number(look.chatAlpha) || .55));
  const chatColors = chatColorVars(a, chatAlpha);
  r.setProperty("--chat-bg-ai", chatColors.ai);
  r.setProperty("--chat-bg-me", chatColors.me);
  const chatBlur = Math.max(0, Math.min(24,
    look.chatBlur === undefined ? 6 : Number(look.chatBlur) || 0));
  r.setProperty("--chat-blur", chatBlur + "px");
  const topAlpha = Math.max(.05, Math.min(1,
    look.topAlpha === undefined ? .82 : Number(look.topAlpha) || .82));
  const bottomAlpha = Math.max(.05, Math.min(1,
    look.bottomAlpha === undefined ? .82 : Number(look.bottomAlpha) || .82));
  const topBlur = Math.max(0, Math.min(32,
    look.topBlur === undefined ? 28 : Number(look.topBlur) || 0));
  const bottomBlur = Math.max(0, Math.min(32,
    look.bottomBlur === undefined ? 28 : Number(look.bottomBlur) || 0));
  r.setProperty("--top-alpha", topAlpha);
  r.setProperty("--bottom-alpha", bottomAlpha);
  r.setProperty("--top-blur", topBlur + "px");
  r.setProperty("--bottom-blur", bottomBlur + "px");
  const bottomTint = String(look.bottomTint || "#11161c");
  r.setProperty("--bottom-tint", colorTriplet(bottomTint, "11161c"));
  const wall = look.bgimg || look.bgurl || "";
  const layer = document.getElementById("wallpaper");
  if (layer) {
    layer.style.backgroundImage = wall ? "url('" + wall + "')" : "";
    layer.style.opacity = String(look.wallAlpha === undefined ? 1 : look.wallAlpha);
  }
  const wa = document.getElementById("wallalpha");
  if (wa) {
    const pct = Math.round((look.wallAlpha === undefined ? 1 : look.wallAlpha) * 100);
    wa.value = String(pct);
    const wv = document.getElementById("wallval");
    if (wv) wv.textContent = pct + "%";
  }
  const ca = document.getElementById("chatAlpha");
  if (ca) {
    const pct = Math.round(chatAlpha * 100);
    ca.value = String(pct);
    const cv = document.getElementById("chatAlphaVal");
    if (cv) cv.textContent = pct + "%";
  }
  const cb = document.getElementById("chatBlur");
  if (cb) {
    const blur = Math.round(chatBlur);
    cb.value = String(blur);
    const bv = document.getElementById("chatBlurVal");
    if (bv) bv.textContent = blur + "px";
  }
  const bottomTintInput = document.getElementById("bottomTint");
  if (bottomTintInput) {
    bottomTintInput.value = /^#[0-9a-f]{6}$/i.test(bottomTint)
      ? bottomTint.toLowerCase() : "#11161c";
  }
  const chromeSliders = [
    ["topAlpha", Math.round(topAlpha * 100), "%"],
    ["topBlur", Math.round(topBlur), "px"],
    ["bottomAlpha", Math.round(bottomAlpha * 100), "%"],
    ["bottomBlur", Math.round(bottomBlur), "px"],
  ];
  for (const [id, value, unit] of chromeSliders) {
    const input = document.getElementById(id);
    if (input) input.value = String(value);
    const label = document.getElementById(id + "Val");
    if (label) label.textContent = value + unit;
  }
  const anim = look.anim !== false;
  document.body.classList.toggle("noanim", !anim);   // 关掉动画时，新气泡也别做出生的动画
  document.querySelectorAll(".bubble").forEach(b => {
    b.style.animation = anim ? "" : "none";
  });
  updateColorChip();
}

function updateColorChip() {
  const hex = String(look.accent || "#3ddc84").toUpperCase();
  const chip = document.getElementById("colorChip");
  const label = document.getElementById("colorHex");
  const picker = document.getElementById("accentPicker");
  if (chip) chip.style.background = hex;
  if (label) label.textContent = hex;
  if (picker) picker.value = hex.toLowerCase();
}

document.getElementById("colorChip").onclick = () => {
  document.getElementById("accentPicker").click();
};
document.getElementById("accentPicker").oninput = (e) => {
  const hex = String(e.target.value || "#3ddc84");
  look.accent = hex;
  look.accentInk = pickInk(hex);
  document.documentElement.style.setProperty("--accent", hex);
  document.documentElement.style.setProperty("--accent-ink", look.accentInk);
  updateColorChip();
};
document.getElementById("accentPicker").onchange = () => save();

function buildSheet() {
  const sw = document.getElementById("sw-accent");
  ACCENTS.forEach(c => {
    const s = document.createElement("span");
    s.style.background = c;
    if ((look.accent || ACCENTS[0]) === c) s.className = "on";
    s.onclick = () => { look.accent = c; look.accentInk = pickInk(c); save(); };
    sw.appendChild(s);
  });
  const bg = document.getElementById("sw-bg");
  BGS.forEach(b => {
    const s = document.createElement("b");
    s.textContent = b[0];
    if ((look.bgName || "深色") === b[0]) s.className = "on";
    s.onclick = () => { look.bg = b; look.bgName = b[0]; save(); };
    bg.appendChild(s);
  });
  const fo = document.getElementById("sw-font");
  [["小", "14px"], ["中", "15px"], ["大", "17px"]].forEach(([n, v]) => {
    const s = document.createElement("b");
    s.textContent = n;
    if ((look.font || "15px") === v) s.className = "on";
    s.onclick = () => { look.font = v; save(); };
    fo.appendChild(s);
  });
  const an = document.getElementById("sw-anim");
  [["开", true], ["关", false]].forEach(([n, v]) => {
    const s = document.createElement("b");
    s.textContent = n;
    if ((look.anim !== false) === v) s.className = "on";
    s.onclick = () => { look.anim = v; save(); };
    an.appendChild(s);
  });
  document.getElementById("bgurl").value = look.bgurl || "";
  const prev = document.getElementById("wallprev");
  if (look.bgimg) {
    prev.src = look.bgimg; prev.style.display = "block";
  } else {
    prev.style.display = "none";
  }
}

// 壁纸：直接从手机的相册里选。手机上拍的图动辄好几兆，localStorage 放不下，
// 所以先在手机里缩到 1600 宽、压成 jpeg 再存（一般 100~400KB）。
document.getElementById("pickself").onclick = () => document.getElementById("wallfile").click();
// 壁纸透明度：拖动就实时预览，松手存下来（存手机上）
document.getElementById("wallalpha").oninput = (e) => {
  look.wallAlpha = Math.max(0.05, Math.min(1, Number(e.target.value) / 100));
  document.getElementById("wallval").textContent = e.target.value + "%";
  document.getElementById("wallpaper").style.opacity = String(look.wallAlpha);
};
document.getElementById("wallalpha").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("chatAlpha").oninput = (e) => {
  look.chatAlpha = Math.max(.05, Math.min(1, Number(e.target.value) / 100));
  document.getElementById("chatAlphaVal").textContent = e.target.value + "%";
  const c = chatColorVars(look.accent || "#3ddc84", look.chatAlpha);
  document.documentElement.style.setProperty("--chat-bg-ai", c.ai);
  document.documentElement.style.setProperty("--chat-bg-me", c.me);
};
document.getElementById("chatAlpha").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("chatBlur").oninput = (e) => {
  look.chatBlur = Math.max(0, Math.min(24, Number(e.target.value) || 0));
  document.getElementById("chatBlurVal").textContent = Math.round(look.chatBlur) + "px";
  document.documentElement.style.setProperty("--chat-blur", Math.round(look.chatBlur) + "px");
};
document.getElementById("chatBlur").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("topAlpha").oninput = (e) => {
  look.topAlpha = Math.max(.05, Math.min(1, Number(e.target.value) / 100));
  document.getElementById("topAlphaVal").textContent = e.target.value + "%";
  document.documentElement.style.setProperty("--top-alpha", look.topAlpha);
};
document.getElementById("topAlpha").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("topBlur").oninput = (e) => {
  look.topBlur = Math.max(0, Math.min(32, Number(e.target.value) || 0));
  document.getElementById("topBlurVal").textContent = Math.round(look.topBlur) + "px";
  document.documentElement.style.setProperty("--top-blur", Math.round(look.topBlur) + "px");
};
document.getElementById("topBlur").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("bottomAlpha").oninput = (e) => {
  look.bottomAlpha = Math.max(.05, Math.min(1, Number(e.target.value) / 100));
  document.getElementById("bottomAlphaVal").textContent = e.target.value + "%";
  document.documentElement.style.setProperty("--bottom-alpha", look.bottomAlpha);
};
document.getElementById("bottomAlpha").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("bottomBlur").oninput = (e) => {
  look.bottomBlur = Math.max(0, Math.min(32, Number(e.target.value) || 0));
  document.getElementById("bottomBlurVal").textContent = Math.round(look.bottomBlur) + "px";
  document.documentElement.style.setProperty("--bottom-blur", Math.round(look.bottomBlur) + "px");
};
document.getElementById("bottomBlur").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("bottomTint").oninput = (e) => {
  look.bottomTint = String(e.target.value || "#11161c");
  document.documentElement.style.setProperty(
    "--bottom-tint",
    colorTriplet(look.bottomTint, "11161c")
  );
};
document.getElementById("bottomTint").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("clearwall").onclick = () => {
  look.bgimg = ""; look.bgurl = "";
  localStorage.setItem("look", JSON.stringify(look));
  applyLook();
  document.getElementById("bgurl").value = "";
  document.getElementById("wallprev").style.display = "none";
};
document.getElementById("wallfile").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  // 先给个反馈，免得看着像"点了没反应"
  const ding = document.getElementById("sheetdone");
  const old = ding.textContent;
  ding.textContent = "正在处理这张图…";
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      let data = "";
      try {                                  // 正常路：缩到 1600 宽再压（省地方）
        const maxw = 1600;
        const scale = Math.min(1, maxw / img.width);
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        let q = 0.82;
        data = c.toDataURL("image/jpeg", q);
        while (data.length > 3_500_000 && q > 0.4) {     // 太大了就再压一点
          q -= 0.15;
          data = c.toDataURL("image/jpeg", q);
        }
      } catch (err) {                        // 万一 canvas 不给用，就用原图
        data = fr.result;
      }
      look.bgimg = data;
      try {
        localStorage.setItem("look", JSON.stringify(look));
      } catch (err) {
        document.getElementById("sheetdone").textContent = "图太大，换张小点的";
        return;
      }
      ding.textContent = old;
      applyLook();
      document.getElementById("wallprev").src = data;
      document.getElementById("wallprev").style.display = "block";
    };
    img.onerror = () => { ding.textContent = old; };
    img.src = fr.result;
  };
  fr.onerror = () => { ding.textContent = old; };
  fr.readAsDataURL(f);
  e.target.value = "";
};

// ---- 头像 ----
let avWho = "me";                       // 这一次点的是换谁的头像
function buildAvQuick() {
  const box = document.getElementById("avquick");
  box.innerHTML = "";
  AV_EMOJI.forEach((em) => {
    const b = document.createElement("b");
    b.textContent = em;
    b.onclick = () => { setAvatar(avWho, "emoji:" + em); };
    box.appendChild(b);
  });
}
function setAvatar(who, value) {
  if (who === "me") { look.avMe = value; } else { look.avAi = value; }
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (e) {}
  refreshAvatars();
}
document.getElementById("pickavme").onclick = () => { avWho = "me"; document.getElementById("avfile").click(); };
document.getElementById("pickavai").onclick = () => { avWho = "ai"; document.getElementById("avfile").click(); };
document.getElementById("avicon").onclick = () => setAvatar(avWho, "icon");
document.getElementById("avee").onclick = () => setAvatar(avWho, "");
document.getElementById("avfile").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const ding = document.getElementById("sheetdone");
  const old = ding.textContent;
  ding.textContent = "正在处理这张头像…";
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      let data = "";
      try {                                    // 正常路：正方形裁一下、缩到 128
        const side = Math.min(img.width, img.height);
        const c = document.createElement("canvas");
        c.width = c.height = 128;
        c.getContext("2d").drawImage(
          img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 128, 128);
        data = c.toDataURL("image/jpeg", 0.85);
      } catch (err) {                          // canvas 不给用就用原图
        data = fr.result;
      }
      ding.textContent = old;
      setAvatar(avWho, data);
    };
    img.onerror = () => { ding.textContent = old; };
    img.src = fr.result;
  };
  fr.onerror = () => { ding.textContent = old; };
  fr.readAsDataURL(f);
  e.target.value = "";
};
buildAvQuick();

// 更新：只看**手机端自己的版本**（电脑端美化之类的不打扰手机）
// 一是一进页面自动查（有新版就在上面弹条横幅），二是设置里那个常驻的按钮
// （用户要求：设置里要有个随时能点的入口，不能只靠横幅）。
let updLatest = "";
let updDownloadUrl = "";
function apkUrl() {
  // 必须给绝对地址：安卓那边 Uri.parse 认不了相对地址（这就是以前"一键更新用不了"的原因之一）
  return location.origin + "/app.apk?k=" + encodeURIComponent(KEY);
}
function doUpdate() {
  const now = document.getElementById("updnow");
  if (window.VoiceApp && window.VoiceApp.openUpdate) {
    if (now) now.textContent = "正在下载新版…（装的时候跟着系统提示点「更新」）";
    window.VoiceApp.openUpdate(updDownloadUrl || apkUrl());
  } else {                       // 浏览器里打开的：只能去下，浏览器不会自动装
    if (now) now.textContent = "浏览器里装不了，用 APP 打开这条网址再点一次";
    window.open(apkUrl(), "_blank");
  }
}
async function refreshUpdRow() {
  const now = document.getElementById("updnow");
  const btn = document.getElementById("updbtn");
  if (!now || !btn) return;
  const appv = (window.VoiceApp && window.VoiceApp.version) ? window.VoiceApp.version() : "";
  if (!appv) {
    now.textContent = "浏览器打开的：装个 APP 就能一键更新";
    btn.textContent = "下载 APP";
    btn.onclick = doUpdate;
    return;
  }
  now.textContent = "正在检查…";
  updDownloadUrl = "";
  try {
    // 版本信息以**网站上那份数据**为准（GitHub 上的 version.json）：网站一刷新，这边就提示更新。
    // 万一那一页还没起来，退回老接口读，保证"能提示"这件事不会因为一个接口没了就哑掉。
    let d = {};
    try {
      const mf = await updateManifest();
      if (!mf) throw new Error("清单读不到");
      d = {phone: (mf.phone || {}).version || "", pc: (mf.pc || {}).version || ""};
      const raw = String((mf.phone || {}).url || "").trim();
      if (raw) {
        const base = String(siteBase || "").replace(/\/+$/, "") + "/";
        const url = new URL(raw, base);
        if (url.protocol === "http:" || url.protocol === "https:") {
          updDownloadUrl = url.href;
        }
      }
    } catch (e0) {
      const r = await fetch("/api/version?k=" + encodeURIComponent(KEY));
      d = await r.json();
      updDownloadUrl = apkUrl();
    }
    const num = v => parseInt(String(v).split(".").pop(), 10) || 0;
    updLatest = String(d.phone || "");
    if (updLatest && num(updLatest) > num(appv)) {
      now.textContent = "有新版 v" + updLatest + "（你现在 v" + appv + "）";
      btn.textContent = "一键更新";
    } else {
      now.textContent = "已经是最新（v" + appv + "）";
      btn.textContent = "再看一眼";
    }
    btn.onclick = () => (updLatest && num(updLatest) > num(appv)) ? doUpdate()
                                                                  : refreshUpdRow();
  } catch (e) {
    now.textContent = "检查更新失败：连不上电脑？";
    btn.textContent = "重试";
    btn.onclick = refreshUpdRow;
  }
}
async function checkUpdate() {
  const appv = (window.VoiceApp && window.VoiceApp.version) ? window.VoiceApp.version() : "";
  if (appv) {
    // 版本号挪进设置了，页面上不显示（用户要求）
    const vl = document.getElementById("verline");
    if (vl) vl.dataset.phone = "v" + appv;
  }
  try {
    const r = await fetch("/api/version?k=" + encodeURIComponent(KEY));
    const d = await r.json();
    const num = v => parseInt(String(v).split(".").pop(), 10) || 0;
    if (appv && d.phone && num(d.phone) > num(appv)
        && localStorage.getItem("updSeen") !== ("v" + d.phone)) {
      document.getElementById("updver").textContent = "v" + d.phone;
      document.getElementById("myver").textContent = "v" + appv;
      document.getElementById("upd").style.display = "block";
      document.getElementById("updlink").onclick = function (e) {
        e.preventDefault();
        doUpdate();
      };
    }
  } catch (e) {}
  refreshUpdRow();
}
