// Serial, retryable outgoing-message state for the legacy WebView.
// Keep transport and DOM work in media.js; this file only owns queue state so
// the ordering and attachment-resume rules can be exercised without a phone.
(function (root) {
  "use strict";

  let sequence = 0;

  class FinDeckSendQueue {
    constructor(limit = 20) {
      this.limit = Math.max(1, Number(limit) || 20);
      this.items = [];
      this.active = null;
    }

    enqueue(input) {
      if (this.items.length >= this.limit) {
        throw new Error("最多同时排队 " + this.limit + " 条消息");
      }
      const source = input || {};
      const attachments = Array.isArray(source.attachments)
        ? source.attachments.map(item => item)
        : [];
      const item = {
        id: "send-" + (++sequence),
        text: String(source.text || ""),
        conv: String(source.conv || "自动"),
        attachments,
        row: source.row || null,
        mine: source.mine || null,
        state: "queued",
        error: "",
        queuedAt: Date.now(),
        acceptedAt: 0,
      };
      this.items.push(item);
      return item;
    }

    start() {
      if (this.active) return null;
      const item = this.items.find(entry => entry.state === "queued");
      if (!item) return null;
      item.state = "sending";
      item.error = "";
      this.active = item;
      return item;
    }

    fail(id, error) {
      const item = this.items.find(entry => entry.id === id);
      if (!item) return null;
      item.state = "failed";
      item.error = String(error || "发送失败");
      if (this.active && this.active.id === id) this.active = null;
      return item;
    }

    retry(id) {
      const item = this.items.find(entry => entry.id === id);
      if (!item || item.state !== "failed") return null;
      item.state = "queued";
      item.error = "";
      item.queuedAt = Date.now();
      return item;
    }

    complete(id) {
      const index = this.items.findIndex(entry => entry.id === id);
      if (index < 0) return null;
      const item = this.items[index];
      item.state = "accepted";
      item.acceptedAt = Date.now();
      this.items.splice(index, 1);
      if (this.active && this.active.id === id) this.active = null;
      return item;
    }

    markUploaded(id, attachmentId, remoteName, remoteUrl) {
      const item = this.items.find(entry => entry.id === id);
      if (!item) return false;
      const attachment = item.attachments.find(
        entry => String(entry.id || "") === String(attachmentId || "")
      );
      if (!attachment) return false;
      attachment.uploaded = true;
      attachment.remoteName = String(remoteName || attachment.file.name || "");
      attachment.remoteUrl = String(
        remoteUrl || "/uploaded/" + encodeURIComponent(attachment.remoteName)
      );
      return true;
    }

    nextAttachment(id) {
      const item = this.items.find(entry => entry.id === id);
      if (!item) return null;
      return item.attachments.find(entry => !entry.uploaded) || null;
    }

    snapshot() {
      return this.items.map(item => ({
        id: item.id,
        text: item.text,
        conv: item.conv,
        state: item.state,
        error: item.error,
        attachments: item.attachments.map(attachment => ({
          id: attachment.id,
          name: attachment.file && attachment.file.name
            ? attachment.file.name : "",
          uploaded: !!attachment.uploaded,
          remoteName: attachment.remoteName || "",
          remoteUrl: attachment.remoteUrl || "",
        })),
      }));
    }
  }

  root.FinDeckSendQueue = FinDeckSendQueue;
})(typeof window !== "undefined" ? window : globalThis);
