// FinDeck phone history filtering and archive restore.
// Loaded after the main page script; shares log renderer and paging state.

let historyConversations = [];
const selectedHistoryConvs = new Set();
let historyQuickDays = -1;
let historyResultCount = 0;

function localDate(d = new Date()) {
  const z = n => String(n).padStart(2, "0");
  return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate());
}
function setQuickDate(days) {
  historyQuickDays = Number(days);
  document.querySelectorAll(".filterQuick b").forEach(b =>
    b.classList.toggle("on", Number(b.dataset.days) === historyQuickDays));
  if (historyQuickDays < 0) return;
  const to = new Date();
  const from = new Date();
  if (historyQuickDays > 0) from.setDate(from.getDate() - historyQuickDays + 1);
  document.getElementById("historyFrom").value = localDate(from);
  document.getElementById("historyTo").value = localDate(to);
  updateHistorySummary();
}
function updateHistorySummary() {
  const from = document.getElementById("historyFrom").value;
  const to = document.getElementById("historyTo").value;
  let dates = "全部日期";
  if (from || to) dates = (from || "最早") + " → " + (to || "今天");
  const convs = selectedHistoryConvs.size
    ? (selectedHistoryConvs.size + " 个对话") : "全部对话";
  document.getElementById("filterSummary").textContent = dates + " · " + convs;
}
function renderHistoryConversations() {
  const box = document.getElementById("filterConvs");
  box.innerHTML = "";
  if (!historyConversations.length) {
    box.innerHTML = '<button type="button" disabled>还没有历史对话</button>';
    return;
  }
  for (const item of historyConversations) {
    const b = document.createElement("button");
    b.type = "button";
    b.dataset.conv = item.title;
    b.title = item.title + " · " + item.count + " 条";
    b.textContent = item.title + " (" + item.count + ")";
    b.classList.toggle("on", selectedHistoryConvs.has(item.title));
    b.onclick = () => {
      if (selectedHistoryConvs.has(item.title)) selectedHistoryConvs.delete(item.title);
      else selectedHistoryConvs.add(item.title);
      b.classList.toggle("on", selectedHistoryConvs.has(item.title));
      updateHistorySummary();
    };
    box.appendChild(b);
  }
}
async function loadHistoryConversations() {
  try {
    const r = await fetch("/api/history/convs" + Q);
    const d = await r.json();
    historyConversations = d.items || [];
    renderHistoryConversations();
  } catch (e) {}
}
async function loadHistoryArchives() {
  const box = document.getElementById("historyRestoreList");
  try {
    const r = await fetch("/api/history/archives" + Q);
    const d = await r.json();
    box.innerHTML = "";
    const items = d.items || [];
    if (!items.length) {
      box.innerHTML = '<div style="color:var(--dim);font-size:11px;padding:10px 2px">没有可恢复的归档</div>';
      return;
    }
    for (const item of items) {
      const b = document.createElement("button");
      b.type = "button";
      b.innerHTML = "";
      const label = document.createElement("span");
      label.textContent = item.from + " → " + item.to;
      const count = document.createElement("small");
      count.textContent = item.count + " 条 · 恢复";
      b.appendChild(label); b.appendChild(count);
      b.onclick = async () => {
        const res = await securePost("/api/history/restore", {name:item.name});
        if (!res.ok) { alert(res.err || "恢复失败"); return; }
        await loadHistoryArchives();
        clearHistoryFilter();
      };
      box.appendChild(b);
    }
  } catch (e) {}
}
async function openHistoryPanel() {
  const p = document.getElementById("historyPanel");
  p.classList.add("open");
  p.setAttribute("aria-hidden", "false");
  await Promise.all([loadHistoryConversations(), loadHistoryArchives()]);
  setTimeout(() => document.getElementById("historySearch").focus(), 180);
}
function closeHistoryPanel() {
  const p = document.getElementById("historyPanel");
  p.classList.remove("open");
  p.setAttribute("aria-hidden", "true");
}
function historyFadeOut() {
  const nodes = [...logEl.querySelectorAll(".chat-group"), ...logEl.children];
  for (const n of nodes) n.classList.add("filter-hiding");
  const reduced = matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  return new Promise(resolve => setTimeout(resolve, reduced ? 0 : 170));
}
function highlightHistoryKeyword(root, keyword) {
  const needle = String(keyword || "").trim();
  if (!needle) return;
  const lower = needle.toLocaleLowerCase();
  const rx = new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
  for (const el of root.querySelectorAll(".btext")) {
    const text = el.textContent || "";
    if (!text.toLocaleLowerCase().includes(lower)) continue;
    const frag = document.createDocumentFragment();
    let last = 0;
    for (const m of text.matchAll(rx)) {
      if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
      const mark = document.createElement("mark");
      mark.className = "historyHit";
      mark.textContent = m[0];
      frag.appendChild(mark);
      last = m.index + m[0].length;
    }
    if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
    el.replaceChildren(frag);
  }
}
async function applyHistoryFilter() {
  const keyword = document.getElementById("historySearch").value.trim();
  const from = document.getElementById("historyFrom").value;
  const to = document.getElementById("historyTo").value;
  const convs = [...selectedHistoryConvs];
  await historyFadeOut();
  historyFilterActive = true;
  logEl.replaceChildren();
  lastChatRow = null;
  const params = new URLSearchParams({
    k:KEY, q:keyword, from, to, archive:"1", limit:"5000"
  });
  if (convs.length) params.set("convs", convs.join("\x1f"));
  try {
    const r = await fetch("/api/history?" + params.toString(), {cache:"no-store"});
    const d = await r.json();
    const items = d.items || [];
    historyResultCount = items.length;
    if (!items.length) {
      add("sys", "没有符合筛选条件的聊天记录");
    } else {
      for (const it of items) {
        add(it.kind, it.text, it.at, it.raw || "", it.conv || "对话", false, false);
      }
      highlightHistoryKeyword(logEl, keyword);
    }
    document.getElementById("filterbtn").classList.add("on");
    closeHistoryPanel();
    setTimeout(() => { logEl.scrollTop = logEl.scrollHeight; }, 50);
  } catch (e) {
    add("sys", "历史筛选失败：连不上电脑");
  }
}
async function clearHistoryFilter() {
  if (!historyFilterActive) {
    closeHistoryPanel();
    return;
  }
  await historyFadeOut();
  historyFilterActive = false;
  document.getElementById("filterbtn").classList.remove("on");
  logEl.replaceChildren();
  lastChatRow = null;
  since = 0;
  lastN = 0;
  first = true;
  closeHistoryPanel();
  pulling = false;
  pull();
}
document.getElementById("filterbtn").onclick = () => {
  if (document.getElementById("historyPanel").classList.contains("open")) closeHistoryPanel();
  else openHistoryPanel();
};
document.getElementById("historyClose").onclick = closeHistoryPanel;
document.addEventListener("keydown", e => {
  if (e.key === "Escape" &&
      document.getElementById("historyPanel").classList.contains("open")) {
    closeHistoryPanel();
  }
});
document.getElementById("filterToggle").onclick = () => {
  document.getElementById("filterToggle").classList.toggle("on");
  document.getElementById("filterBody").classList.toggle("open");
};
document.getElementById("historyFrom").onchange = () => {
  historyQuickDays = -1;
  document.querySelectorAll(".filterQuick b").forEach(b => b.classList.remove("on"));
  updateHistorySummary();
};
document.getElementById("historyTo").onchange = document.getElementById("historyFrom").onchange;
document.querySelectorAll(".filterQuick b").forEach(b => b.onclick = () => setQuickDate(b.dataset.days));
document.getElementById("filterApply").onclick = applyHistoryFilter;
document.getElementById("filterReset").onclick = clearHistoryFilter;
document.getElementById("historySearch").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); applyHistoryFilter(); }
});
document.getElementById("historyClear").onclick = async () => {
  if (!confirm("清除当前 60 天内的历史消息？清除前会先存到电脑归档。")) return;
  const d = await securePost("/api/history/clear", {});
  if (!d.ok) { alert(d.err || "清除失败"); return; }
  await clearHistoryFilter();
  await loadHistoryArchives();
  alert("已清除 " + d.count + " 条，已保存为 " + d.archive);
};
document.getElementById("historyRestoreToggle").onclick = () => {
  const list = document.getElementById("historyRestoreList");
  list.hidden = !list.hidden;
  if (!list.hidden) loadHistoryArchives();
};
setQuickDate(-1);
updateHistorySummary();
