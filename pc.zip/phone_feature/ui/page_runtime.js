// FinDeck live chat stream, page switching, security and agent controls.

const logEl = document.getElementById("log");
const box = document.getElementById("box");
const caretDot = document.getElementById("caretDot");
let since = 0, first = true;
let lastChatRow = null;
let caretFrame = 0;
function queueCaret() {
  if (caretFrame) return;
  caretFrame = requestAnimationFrame(() => {
    caretFrame = 0;
    updateCaretDot();
  });
}
function updateCaretDot() {
  if (!caretDot) return;
  const focused = document.activeElement === box;
  const collapsed = box.selectionStart === box.selectionEnd;
  if (!focused || !collapsed) {
    caretDot.classList.remove("on");
    return;
  }
  const cs = getComputedStyle(box);
  const mirror = document.createElement("div");
  mirror.style.cssText =
    "position:fixed;left:-10000px;top:0;visibility:hidden;pointer-events:none;" +
    "white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;box-sizing:border-box;" +
    "width:" + box.clientWidth + "px;" +
    "font:" + cs.font + ";line-height:" + cs.lineHeight + ";" +
    "letter-spacing:" + cs.letterSpacing + ";text-align:" + cs.textAlign + ";" +
    "padding:" + cs.padding + ";border:" + cs.borderWidth + " " + cs.borderStyle + " transparent;";
  mirror.append(document.createTextNode(box.value.slice(0, box.selectionStart)));
  const marker = document.createElement("span");
  marker.textContent = "\u200b";
  mirror.appendChild(marker);
  document.body.appendChild(mirror);
  const r = marker.getBoundingClientRect();
  const mr = mirror.getBoundingClientRect();
  const left = r.left - mr.left - box.scrollLeft;
  const top = r.top - mr.top - box.scrollTop + Math.max(0, (r.height - 8) / 2);
  mirror.remove();
  // 圆点放在文字插入点右侧，和上一个字留 4px 空隙。
  caretDot.style.left = Math.max(0, left + 4) + "px";
  caretDot.style.top = Math.max(0, top) + "px";
  caretDot.classList.add("on");
}
["focus", "blur", "input", "click", "keyup", "keydown", "select", "scroll",
 "compositionend"].forEach(ev => box.addEventListener(ev, queueCaret));
box.addEventListener("blur", () => caretDot.classList.remove("on"));
document.addEventListener("selectionchange", () => {
  if (document.activeElement === box) queueCaret();
});
window.addEventListener("resize", queueCaret);
function playPushIn(before, newRow) {
  if (!before || look.anim === false ||
      (window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches)) return;
  requestAnimationFrame(() => {
    for (const [row, top] of before) {
      if (!row || !row.isConnected) continue;
      const dy = top - row.getBoundingClientRect().top;
      if (Math.abs(dy) < 1) continue;
      row.style.transition = "none";
      row.style.transform = "translateY(" + dy + "px)";
      row.style.willChange = "transform";
      requestAnimationFrame(() => {
        row.style.transition = "transform .28s cubic-bezier(.16,1,.3,1)";
        row.style.transform = "translateY(0)";
        setTimeout(() => {
          row.style.transition = "";
          row.style.transform = "";
          row.style.willChange = "";
        }, 320);
      });
    }
    newRow.style.opacity = "0";
    newRow.style.transform = "translateY(10px)";
    requestAnimationFrame(() => {
      newRow.style.transition = "opacity .2s ease, transform .24s cubic-bezier(.16,1,.3,1)";
      newRow.style.opacity = "1";
      newRow.style.transform = "translateY(0)";
      setTimeout(() => {
        newRow.style.transition = "";
        newRow.style.transform = "";
      }, 280);
    });
  });
}
/** 连续同会话、同发言方包成一个组：组首头像，整组共用一层光晕。 */
function regroupChatRows() {
  for (const old of [...logEl.querySelectorAll(':scope > .chat-group')]) {
    old.replaceWith(...old.children);
  }
  const nodes = [...logEl.children];
  let i = 0;
  while (i < nodes.length) {
    const first = nodes[i];
    if (!first.matches('.row[data-kind="ai"], .row[data-kind="me"]')) {
      i++;
      continue;
    }
    const kind = first.dataset.kind;
    const conv = String(first.dataset.conv || "");
    const group = document.createElement("div");
    const other = first.classList.contains("other-conv");
    group.className = "chat-group kind-" + kind + (other ? " other" : " current");
    group.dataset.conv = conv;
    logEl.insertBefore(group, first);
    let j = i;
    while (j < nodes.length) {
      const row = nodes[j];
      if (!row.matches('.row[data-kind="ai"], .row[data-kind="me"]') ||
          row.dataset.kind !== kind ||
          String(row.dataset.conv || "") !== conv ||
          row.classList.contains("other-conv") !== other) break;
      row.classList.toggle("group-head", j === i);
      row.classList.toggle("group-cont", j !== i);
      group.appendChild(row);
      j++;
    }
    i = j;
  }
}
let pulling = false;                 // 上一次还没回来就不再发请求（防并发）
let lastN = 0;                       // 已经显示过的最大日志行号
let lastBusy = false;                // 上一次的"电脑在忙吗"（用 busy 字段判断）
let historyFilterActive = false;     // 筛选历史时暂停把实时消息插入当前列表
/** 忙的时候在聊天栏顶部亮一条蓝色光带，忙完立刻熄灭。 */
function setThinking(on) {
  const band = document.getElementById("thinkband");
  if (!band) return;
  band.classList.toggle("on", !!on);
  band.setAttribute("aria-hidden", on ? "false" : "true");
}
function purgeStatusRows() {
  document.querySelectorAll("#log .row.center").forEach(row => {
    if (row.id === "thinkrow") return;
    const t = row.textContent || "";
    if (t.includes("正在思考") || t.includes("思考结束") || t.includes("处理完了")) {
      row.remove();
    }
  });
}
/** 服务器回读到本机刚发的句子时，合并到原气泡，不新加一条。 */
function mergeLocalEcho(it) {
  const i = mine.findIndex(m => m.text === it.text && (Date.now() - m.at) < 20000);
  if (i < 0) return false;
  setBubbleConv(mine[i].el, it.conv);
  mine.splice(i, 1);
  return true;
}
async function pull() {
  if (pulling) return;
  pulling = true;
  try {
    const initialPull = first;
    if (first) { first = false; purgeStatusRows(); }
    const r = await fetch("/api/log?since=" + since + "&k=" + encodeURIComponent(KEY));
    if (!r.ok) throw new Error(r.status);
    const d = await r.json();
    // 右边那行"说唤醒词"之类的小字去掉了：只在连不上时提示一句
    const stEl = document.getElementById("state");
    // 状态图标：一眼看出它现在在干啥（待命 / 在听你说 / 正在想 / 已发送 / 已静音 / 已暂停 / 连不上）
    const rawState = String(d.state || "");
    const sk = rawState.split("·")[0].trim();
    let label = "待命（说唤醒词）", color = "#3ddc84";
    if (!d.online) { label = "连不上"; color = "#7f7f8a"; }
    else if (d.mute === true || /静音/.test(rawState)) { label = "已静音"; color = "#ffd166"; }
    else if (d.paused === true || sk === "paused") { label = "已暂停"; color = "#ffb020"; }
    else if (d.busy === true) { label = "正在想…"; color = "#4aa3ff"; }
    else if (sk === "hearing") { label = "在听你说"; color = "#3ddc84"; }
    else if (sk === "thinking") { label = "正在识别"; color = "#4aa3ff"; }
    else if (sk === "sent" || sk === "copied") { label = "已发送"; color = "#22d3ee"; }
    else if (sk === "listening") { label = "在等你说"; color = "#3ddc84"; }
    stEl.textContent = label;
    stEl.style.color = color;
    // 出声状态图标：喇叭有波 = 会说话；带一道斜杠 = 静音中
    const spk = document.getElementById("spk");
    if (spk) {
      const muted = (d.mute === true);
      spk.innerHTML = muted
        ? '<svg class="ic-m" viewBox="0 0 24 24" style="stroke:#ffd166"><path d="M5 9v6h3l4 3V6L8 9z"/><path d="M16.5 9.5l4 5M20.5 9.5l-4 5"/></svg>'
        : '<svg class="ic-m" viewBox="0 0 24 24" style="stroke:#3ddc84"><path d="M5 9v6h3l4 3V6L8 9z"/><path d="M15.5 9.5a3.5 3.5 0 0 1 0 5M18 7.5a6.5 6.5 0 0 1 0 9"/></svg>';
      spk.title = muted ? "静音中（你说它照办，只是不出声）" : "会出声";
    }
    const dot = document.getElementById("dot");
    dot.style.background = color;
    dot.classList.toggle("live", !!d.online);
    // 「它现在在干啥」只做一条**活的**提示：忙时出现，忙完立刻移除，
    // 不写进聊天记录（用户要求不要留下“正在思考 / 思考结束 / 处理完了”）。
    const busyNow = (d.busy === true);
    setThinking(busyNow);
    lastBusy = busyNow;
    // （输入栏上面那个「正在思考 ···」的浮动小气泡整个去掉了 —— 用户说"上面弄干净点"。
    //   它忙不忙看顶上的状态就行，不用在输入栏上面挂三个跳动的点。）
    for (const it of d.lines) {
      // 按"日志行号"去重：并发请求、重连、页面重绘都不会把同一行塞两遍
      if (it.n <= lastN) { since = Math.max(since, it.n); continue; }
      lastN = it.n;
      since = it.n;
      if (it.kind === "ai") {
        lastSentAt = 0;                                // 它回话了 → 收掉思考提示
        setTimeout(refreshBalance, 900);
      }
      if (historyFilterActive) continue;
      // 本地已经显示过的那句别再显示一遍（真机反馈"手机发出去会重复"就是这个）
      // 服务器回读可能先标成「本机」、随后才补真实会话名，所以回声按文字合并。
      if (it.kind === "me" && mergeLocalEcho(it)) continue;
      add(it.kind, it.text, it.at, it.raw, it.conv,
          !!it.stream && !initialPull, !initialPull);
    }
  } catch (e) {
    document.getElementById("state").textContent = "连不上";
    document.getElementById("dot").style.background = "#e05252";
    document.getElementById("dot").classList.remove("live");
  } finally {
    pulling = false;
  }
}
async function post(path, body) {
  try {
    if (["/api/cmd", "/api/submit", "/api/send-media"].includes(path)) {
      return await securePost(path, body);
    }
    await fetch(path + "?k=" + encodeURIComponent(KEY), {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify(body || {})});
  } catch (e) {}
}
function togglePlus(on) {
  const p = document.getElementById("pluspanel");
  const b = document.getElementById("plus");
  const open = (on === undefined) ? !p.classList.contains("open") : !!on;
  p.classList.toggle("open", open);
  b.classList.toggle("on", open);
  // 面板是**占位置**的（不盖输入框、不盖聊天区）：聊天区自己会被顶上去，
  // 打开时滚到底，看着就跟微信一样。（以前是"盖上去 + 给聊天区补 padding"，
  // 结果输入框被压没了、动画还卡。）
  const lg = document.getElementById("log");
  if (open && lg) setTimeout(function () { lg.scrollTop = lg.scrollHeight; }, 120);
}
function openPage(id) {
  togglePlus(false);
  document.getElementById(id).classList.add("open");
  if (id === "page-shots") pullShots(true);
  if (id === "page-files") pullFiles(true);
  if (id === "page-sched") pullSchedule(true);
  if (id === "page-raws") pullRaws(true);
  if (id === "page-wins") pullWins(true);
  if (id === "page-tasks") pullTasks(true);
  if (id === "page-plugins" && typeof pullPlugins === "function") pullPlugins(true);
  if (id === "page-acceptance" && typeof pullAcceptance === "function") pullAcceptance(true);
  if (id === "page-search") setTimeout(() => document.getElementById("searchbox").focus(), 180);
  syncTaskTimer();
}
function closePages() {
  document.querySelectorAll(".page.open").forEach(p => p.classList.remove("open"));
  syncTaskTimer();
}
document.getElementById("taskAdd").onclick = async () => {
  const input = document.getElementById("taskTitle");
  const title = input.value.trim();
  if (!title) { input.focus(); return; }
  input.value = "";
  await taskAction("create", "", {title});
};
async function loadSecurity() {
  try {
    const r = await fetch("/api/security" + Q, {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    const policy = d.policy || {};
    document.getElementById("securityState").textContent =
      d.algorithm + " · 密钥 " + d.key_age_days + " 天 · 第 "
      + (d.key_generation || 1) + " 代"
      + (d.rotation_due ? " · 建议轮换" : " · 状态正常");
    document.getElementById("retentionDays").value =
      Number((d.retention || {}).terminal_days || 14);
    document.getElementById("retentionTasks").value =
      Number((d.retention || {}).max_tasks || 200);
    document.getElementById("capabilityTtl").value =
      Math.max(1, Math.round(Number(policy.capability_ttl_seconds || 600) / 60));
    document.getElementById("keyRotateDays").value =
      Number(policy.rotate_days || 30);
    document.getElementById("maxDevices").value =
      Number(policy.max_active_devices || 8);
    const box = document.getElementById("securityDevices");
    box.innerHTML = "";
    const groups = Array.isArray(d.devices) ? d.devices : [];
    if (!groups.length) {
      const empty = document.createElement("div");
      empty.className = "taskMeta";
      empty.textContent = "名单为空；下一台设备连接时需要重新配对。";
      box.appendChild(empty);
    }
    for (const group of groups) {
      const row = document.createElement("div");
      row.className = "securityDevice";
      const text = document.createElement("div");
      const title = document.createElement("b");
      title.textContent = (group.name || "未命名设备")
        + (group.current ? " · 当前" : "") + (group.ok ? "" : " · 已吊销");
      const detail = document.createElement("small");
      const when = Number(group.last || 0)
        ? new Date(Number(group.last) * 1000).toLocaleString()
        : "时间未知";
      detail.textContent = (group.ip || "来源未知") + " · " + when
        + " · " + (group.entries || 0) + " 个入口";
      text.appendChild(title);
      text.appendChild(detail);
      row.appendChild(text);
      if (group.ok) {
        const revoke = document.createElement("button");
        revoke.type = "button";
        revoke.className = "ghost";
        revoke.textContent = "吊销";
        revoke.onclick = async () => {
          const extra = group.current
            ? "\n\n这是当前设备，吊销后手机会立刻失去控制权限，需要回到电脑重新配对。"
            : "";
          if (!confirm("吊销「" + (group.name || "这台设备") + "」？" + extra)) return;
          const out = await securePost("/api/security/action", {
            action: "revoke-device",
            ids: group.ids,
            confirm: true
          });
          if (!out.ok) alert(out.err || "吊销失败");
          if (group.current) {
            capabilityValue = ""; capabilityUntil = 0;
          }
          await loadSecurity();
        };
        row.appendChild(revoke);
      }
      box.appendChild(row);
    }
  } catch (e) {
    document.getElementById("securityState").textContent = "读取失败：" + e;
  }
}
document.getElementById("retentionSave").onclick = async () => {
  const d = await securePost("/api/security/action", {
    action: "retention",
    terminal_days: Number(document.getElementById("retentionDays").value),
    max_tasks: Number(document.getElementById("retentionTasks").value)
  });
  if (!d.ok) alert(d.err || "保存失败");
  await loadSecurity();
};
document.getElementById("securityPolicySave").onclick = async () => {
  const d = await securePost("/api/security/action", {
    action: "policy",
    capability_ttl_seconds:
      Math.round(Number(document.getElementById("capabilityTtl").value) * 60),
    rotate_days: Number(document.getElementById("keyRotateDays").value),
    max_active_devices: Number(document.getElementById("maxDevices").value)
  });
  if (!d.ok) alert(d.err || "保存失败");
  capabilityValue = ""; capabilityUntil = 0;
  await loadSecurity();
};
document.getElementById("securityRotate").onclick = async () => {
  if (!confirm("轮换应用层操作密钥？当前手机页会自动换新凭据，其他旧凭据立即失效。")) return;
  const d = await securePost("/api/security/action", {action: "rotate-key"});
  if (!d.ok) alert(d.err || "轮换失败");
  capabilityValue = ""; capabilityUntil = 0;
  await loadSecurity();
};
document.getElementById("securityExport").onclick = async () => {
  const passphrase = prompt("设置恢复包口令（至少 12 个字符，遗失无法找回）");
  if (!passphrase) return;
  if (passphrase.length < 12) {
    alert("恢复包口令至少需要 12 个字符");
    return;
  }
  if (prompt("再输入一次恢复包口令") !== passphrase) {
    alert("两次口令不一致");
    return;
  }
  const d = await securePost("/api/security/action", {
    action: "backup-key", passphrase
  });
  if (!d.ok || !d.backup || !d.backup.backup) {
    alert(d.err || "导出失败");
    return;
  }
  const text = d.backup.backup;
  document.getElementById("securityBackup").value = text;
  try {
    const blob = new Blob([text], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "FinDeck-operation-key-" + (d.backup.key_id || "backup") + ".json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  } catch (e) {}
  alert("恢复包已导出。它仍由口令加密，请和口令分开保存。");
};
document.getElementById("securityRestore").onclick = async () => {
  const backup = document.getElementById("securityBackup").value.trim();
  if (!backup) {
    alert("先把整段恢复包贴到输入框里");
    return;
  }
  const passphrase = prompt("输入恢复包口令（至少 12 个字符）");
  if (!passphrase) return;
  if (!confirm("恢复会替换当前操作密钥，并让所有旧操作凭据立即失效。继续？")) return;
  const d = await securePost("/api/security/action", {
    action: "restore-key", backup, passphrase
  });
  if (!d.ok) {
    alert(d.err || "恢复失败");
    return;
  }
  capabilityValue = ""; capabilityUntil = 0;
  document.getElementById("securityBackup").value = "";
  alert("操作密钥已恢复；旧凭据已失效，页面会领取新的短时凭据。");
  await loadSecurity();
};
document.getElementById("securityRevokeAll").onclick = async () => {
  if (!confirm("吊销全部设备并轮换操作密钥？所有手机和浏览器都必须回电脑重新配对。")) return;
  const d = await securePost("/api/security/action", {
    action: "revoke-all-devices", confirm: true, rotate_key: true
  });
  if (!d.ok) alert(d.err || "吊销失败");
  capabilityValue = ""; capabilityUntil = 0;
  alert("已吊销 " + Number(d.revoked || 0) + " 条设备记录，操作密钥已轮换。");
  await loadSecurity();
};
let agentBusy = false;
async function pullAgents(manual = false) {
  if (agentBusy) return;
  agentBusy = true;
  const summary = document.getElementById("agentSummary");
  const box = document.getElementById("agentList");
  try {
    const r = await fetch("/api/agents" + Q, {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    const trees = Array.isArray(d.worktrees) ? d.worktrees : [];
    const jobs = Array.isArray(d.jobs) ? d.jobs : [];
    summary.textContent = d.max_workers + " 个并行槽 · " + trees.length
      + " 个 worktree · " + jobs.length + " 个 Agent 任务";
    box.innerHTML = "";
    for (const tree of trees) {
      const row = document.createElement("div");
      row.className = "agentRow";
      row.textContent = (tree.managed ? "鳍舱管理 · " : "项目根 · ")
        + tree.path + " · " + (tree.head || "HEAD");
      if (tree.managed) {
        const run = document.createElement("button");
        run.type = "button"; run.textContent = "派 Agent";
        run.onclick = async () => {
          const prompt = prompt("给这个 worktree 派一个 Codex 任务");
          if (!prompt || !prompt.trim()) return;
          const out = await securePost("/api/agents/action", {
            action: "submit", prompt: prompt.trim(), cwd: tree.path
          });
          if (!out.ok) alert(out.err || "提交失败");
          await pullAgents(true);
        };
        row.appendChild(run);
      }
      box.appendChild(row);
    }
    for (const job of jobs.slice(0, 20)) {
      const row = document.createElement("div");
      row.className = "agentRow";
      row.textContent = job.status + " · " + job.id.slice(0, 18) + "\n"
        + String(job.prompt || "").slice(0, 180)
        + (job.error ? "\n" + job.error : "")
        + (job.output ? "\n" + String(job.output).slice(-600) : "");
      box.appendChild(row);
    }
  } catch (e) {
    summary.textContent = "Agent 状态读取失败：" + e;
    if (manual) box.textContent = String(e);
  } finally {
    agentBusy = false;
  }
}
document.getElementById("agentRefresh").onclick = () => pullAgents(true);
document.getElementById("agentCreate").onclick = async () => {
  const input = document.getElementById("agentWorktreeName");
  const name = input.value.trim();
  if (!name) { input.focus(); return; }
  const d = await securePost("/api/agents/action",
    {action: "create-worktree", name});
  if (!d.ok) alert(d.err || "新建失败");
  else input.value = "";
  await pullAgents(true);
};
document.getElementById("agentPanel").addEventListener("toggle", e => {
  if (e.target.open) pullAgents(false);
});
const plusButton = document.getElementById("plus");
plusButton.onclick = () => togglePlus();
plusButton.addEventListener("keydown", e => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    togglePlus();
  }
});
document.getElementById("plusbg").onclick = () => togglePlus(false);   // 点空白处收起来
document.getElementById("sheetbg").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
document.querySelectorAll(".page [data-back]").forEach(b => { b.onclick = closePages; });
// 子页里点空白处（或者点顶上那条标题）也能关掉
document.querySelectorAll(".page").forEach(pg => {
  pg.addEventListener("click", (e) => {
    if (e.target.closest("button,a,input,summary,details,.tile,.f,.listrow,img,.chip,b")) {
      return;                       // 点到能操作的东西就别关
    }
    closePages();
  });
});
document.querySelectorAll("#pluspanel .tile[data-page]").forEach(row => {
  row.onclick = () => {
    // 「对话会话」直接开左边那个抽屉（跟滑一下出来的是同一个）
    if (row.dataset.page === "wins") { togglePlus(false); openDrawer(); return; }
    openPage("page-" + row.dataset.page);
  };
});
// ＋ 里的「扫码」：直接调 APP 的扫码（浏览器里打开这个页面时给个提示）
let phoneMute = false;
document.getElementById("timute").onclick = async () => {
  togglePlus(false);
  const say = phoneMute ? "恢复出声" : "静音";
  phoneMute = !phoneMute;
  document.getElementById("timutetxt").textContent = phoneMute ? "恢复" : "静音";
  add("me", say);
  await post("/api/cmd", {text: say});
  setTimeout(pull, 700);
};
document.getElementById("tiscan").onclick = () => {
  togglePlus(false);
  if (window.VoiceApp && window.VoiceApp.scan) window.VoiceApp.scan();
  else alert("这一步要在 APP 里做：打开鳍舱 APP → 右下角「＋」→ 扫码。浏览器里没法调摄像头扫码。");
};
document.getElementById("tilook").onclick = () => { togglePlus(false); openSheet("appearance"); };
document.getElementById("ticonn").onclick = () => { togglePlus(false); openSheet(true); };
document.getElementById("tiavatar").onclick = () => {
  togglePlus(false); openSheet("appearance");
  const sec = document.getElementById("avsec");
  if (sec) setTimeout(() => sec.scrollIntoView({block: "center", behavior: "smooth"}), 240);
};
document.getElementById("tipaste").onclick = async () => {
  togglePlus(false);
  let text = "";
  try {
    if (window.VoiceApp && typeof VoiceApp.readClipboardText === "function") {
      text = String(VoiceApp.readClipboardText() || "");
    } else if (navigator.clipboard && navigator.clipboard.readText) {
      text = await navigator.clipboard.readText();
    }
  } catch (e) {
    text = "";
  }
  if (!text) {
    alert("系统剪贴板里没有可粘贴的文字。");
    return;
  }
  const start = Number.isFinite(box.selectionStart) ? box.selectionStart : box.value.length;
  const end = Number.isFinite(box.selectionEnd) ? box.selectionEnd : start;
  box.setRangeText(text, start, end, "end");
  box.dispatchEvent(new Event("input", {bubbles: true}));
  box.focus();
  if (typeof queueCaret === "function") queueCaret();
  nativeHaptic(8);
};
// 「＋」菜单里那几个快捷指令：一点就走
document.querySelectorAll("#pluspanel .tile[data-cmd]").forEach(t => {
  t.onclick = async () => {
    const cmd = t.dataset.cmd;
    togglePlus(false);
    add("me", cmd);
    mine.push({text: cmd, at: Date.now()});
    lastSentAt = Date.now();
    if (navigator.vibrate) navigator.vibrate(12);
    await post("/api/cmd", {text: cmd});
    pull();
  };
});
// ---- 看原话：手机上读电脑那边回答的**原文**（念出去的是清理过的版本）----
