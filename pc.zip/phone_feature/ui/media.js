// FinDeck phone attachments, sending, screenshots, files and media viewer.
// Loaded after the main script; uses its authenticated request helpers.

const pendingAttachments = [];
let attachSeq = 0;
function sizeText(bytes) {
  const n = Number(bytes || 0);
  return n > 1024 * 1024 ? (n / 1024 / 1024).toFixed(1) + " MB"
       : Math.max(1, Math.round(n / 1024)) + " KB";
}
function renderAttachTray() {
  const tray = document.getElementById("attachTray");
  const list = document.getElementById("attachList");
  list.innerHTML = "";
  for (const item of pendingAttachments) {
    const cell = document.createElement("div");
    cell.className = "attach-item";
    if (item.isImage) {
      const img = document.createElement("img");
      img.src = item.preview;
      img.alt = item.file.name;
      cell.appendChild(img);
    } else {
      const icon = document.createElement("div");
      icon.className = "ficon";
      icon.textContent = item.file.name.slice(-12);
      cell.appendChild(icon);
    }
    const rm = document.createElement("button");
    rm.className = "rm";
    rm.type = "button";
    rm.textContent = "×";
    rm.setAttribute("aria-label", "移除 " + item.file.name);
    rm.onclick = () => {
      const i = pendingAttachments.indexOf(item);
      if (i >= 0) pendingAttachments.splice(i, 1);
      if (item.preview) URL.revokeObjectURL(item.preview);
      renderAttachTray();
    };
    cell.appendChild(rm);
    list.appendChild(cell);
  }
  const on = pendingAttachments.length > 0;
  tray.classList.toggle("on", on);
  document.body.classList.toggle("has-attachments", on);
}
function stageFiles(files) {
  for (const file of files) {
    if (!file) continue;
    const isImage = String(file.type || "").startsWith("image/") ||
      /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(file.name);
    pendingAttachments.push({
      id:"att" + (++attachSeq), file, isImage,
      preview:isImage ? URL.createObjectURL(file) : "",
    });
  }
  renderAttachTray();
  if (pendingAttachments.length) box.focus();
}
async function uploadAttachment(item) {
  const d = await securePostRaw("/api/upload?name=" + encodeURIComponent(item.file.name)
    + (item.isImage ? "&paste=1" : ""), item.file);
  if (!d.ok) throw new Error(d.err || "upload failed");
  item.remoteName = d.name;
  item.remoteUrl = "/uploaded/" + encodeURIComponent(d.name) + Q;
  return item;
}
const sendButton = document.getElementById("send");
sendButton.onclick = async () => {
  const t = box.value.trim();
  if (!t && !pendingAttachments.length) return;
  sendButton.classList.remove("sending");
  void sendButton.offsetWidth;
  sendButton.classList.add("sending");
  const localConv = convLabel || "自动";
  const sending = pendingAttachments.slice();
  const media = sending.map(item => ({
    id:item.id, kind:item.isImage ? "image" : "file",
    name:item.file.name, sizeText:sizeText(item.file.size),
    src:item.isImage ? item.preview : "data:,", download:item.isImage ? item.preview : "",
  }));
  const localRow = add("me", t, null, null, localConv, false, true, media);
  box.value = "";
  box.style.height = "";
  pendingAttachments.splice(0);
  renderAttachTray();
  queueCaret();
  if (t) mine.push({text: t, conv: localConv, at: Date.now(), el: localRow});
  lastSentAt = Date.now();
  nativeHaptic(12);                                  // 发出去了，给一下手感
  let uploadedImages = 0;
  for (const item of sending) {
    try {
      await uploadAttachment(item);
      uploadedImages += item.isImage ? 1 : 0;
      const holder = localRow.querySelector('[data-attach-id="' + item.id + '"]');
      if (holder && item.isImage) {
        const img = holder.querySelector("img");
        if (img) img.src = item.remoteUrl;
        holder.onclick = () => viewerOpen(item.remoteUrl, item.file.name);
      } else if (holder && item.remoteUrl) {
        holder.href = item.remoteUrl; holder.download = item.file.name;
      }
      if (item.preview) URL.revokeObjectURL(item.preview);
    } catch (e) {
      const holder = localRow.querySelector('[data-attach-id="' + item.id + '"]');
      if (holder) holder.style.opacity = ".5";
    }
  }
  if (sending.length) {
    if (t) await post("/api/send-media", {text:t});
    else if (uploadedImages) await post("/api/submit", {});
  } else {
    await post("/api/cmd", {text:t});
  }
  pull();
};
sendButton.addEventListener("animationend", e => {
  if (e.target.tagName && e.target.tagName.toLowerCase() === "svg")
    sendButton.classList.remove("sending");
});
document.getElementById("stop").onclick = () => post("/api/stop", {});
// ---- 电脑屏幕：截图 / 录屏 ----
let shotName = "";
let recordSeconds = 8;
document.getElementById("shottoggle").onclick = () => {
  const box = document.getElementById("shots");
  box.classList.toggle("open");
  document.getElementById("shottoggle").textContent = box.classList.contains("open") ? "收起" : "展开";
  if (box.classList.contains("open")) pullShots(true);
};
document.getElementById("shotbtn").onclick = async () => {
  document.getElementById("shotmeta").textContent = "正在抓取全部显示器的原始分辨率…";
  await post("/api/cmd", {text: "截图发手机"});
  setTimeout(() => pullShots(true), 900);
};
document.getElementById("recbtn").onclick = async () => {
  document.getElementById("shotmeta").textContent =
    "正在录 " + recordSeconds + " 秒全屏 MP4（全部显示器）…";
  await post("/api/cmd", {text: "录 " + recordSeconds + " 秒发手机"});
  setTimeout(() => pullShots(true), 1600);
};
document.querySelectorAll("#recdurations b").forEach(b => {
  b.onclick = () => {
    recordSeconds = Math.max(3, Math.min(30, Number(b.dataset.sec) || 8));
    document.querySelectorAll("#recdurations b").forEach(x =>
      x.classList.toggle("on", x === b));
    document.querySelector("#recbtn span").textContent = "录 " + recordSeconds + " 秒";
  };
});
function showShotItem(it) {
  shotName = String(it.name || "");
  const img = document.getElementById("shotimg");
  const video = document.getElementById("shotvideo");
  const stage = document.getElementById("shotstage");
  const src = "shot/" + encodeURIComponent(shotName) + Q + "&t=" + Date.now();
  const ext = shotName.toLowerCase().split(".").pop();
  const isVideo = ["mp4", "webm", "webp", "gif"].includes(ext);
  stage.classList.remove("empty");
  if (isVideo && (ext === "mp4" || ext === "webm")) {
    img.style.display = "none"; img.removeAttribute("src");
    video.style.display = "block"; video.src = src;
  } else {
    video.pause(); video.style.display = "none"; video.removeAttribute("src");
    img.style.display = "block"; img.src = src;
    img.onclick = () => viewerOpen(src, shotName);
  }
  document.getElementById("shotmeta").textContent =
    (it.kind === "video" ? "录像" : "截图") + " · " + shotName + " · " + it.kb + " KB";
  document.querySelectorAll("#shotlist .chip").forEach(c =>
    c.classList.toggle("on", c.dataset.name === shotName));
}
async function pullShots(force) {
  if (!document.getElementById("shots").classList.contains("open")) return;
  try {
    const r = await fetch("/api/shots" + Q);
    const d = await r.json();
    const screen = d.display || {};
    if (screen.width && screen.height) {
      document.getElementById("screenres").textContent =
        (screen.count || 1) + "屏 · " + screen.width + "×" + screen.height
        + " · 原画截图 / 录屏≤5120";
    }
    const items = d.items || [];
    if (!items.length) {
      document.getElementById("shotstage").classList.add("empty");
      document.getElementById("shotimg").style.display = "none";
      document.getElementById("shotvideo").style.display = "none";
      return;
    }
    const top = items[0];
    if (top.name === shotName && !force) return;
    const list = document.getElementById("shotlist");
    list.innerHTML = "";
    for (const it of items.slice(0, 12)) {
      const c = document.createElement("span");
      c.className = "chip";
      c.dataset.name = it.name;
      c.textContent = (it.kind === "video" ? "录像 " : "截图 ")
        + it.name.replace(/\.[^.]+$/, "").slice(-11);
      c.onclick = () => showShotItem(it);
      list.appendChild(c);
    }
    showShotItem(top);
  } catch (e) {}
}

// ---- 看大图：页面内自己的查看器（捏合 / 双击放大、拖动、点空白或 ✕ 退出）----
let vScale = 1, vx = 0, vy = 0, vDist = 0, vDrag = null, vLastTap = 0;
function vApply() {
  const im = document.getElementById("viewerimg");
  im.style.transform = "translate(" + vx + "px," + vy + "px) scale(" + vScale + ")";
}
function vReset() { vScale = 1; vx = 0; vy = 0; vApply(); }
function vZoom(f) {
  vScale = Math.max(1, Math.min(6, vScale * f));
  if (vScale <= 1.01) { vx = 0; vy = 0; }
  vApply();
}
function viewerOpen(src, fileName) {
  const v = document.getElementById("viewer");
  const im = document.getElementById("viewerimg");
  const load = document.getElementById("viewerload");
  const save = document.getElementById("viewersave");
  im.style.transform = "";
  v.style.transform = "";
  v.style.opacity = "";
  vScale = 1; vx = 0; vy = 0;
  load.style.display = "block";
  load.textContent = "正在取图…";
  im.onload = function () { load.style.display = "none"; };
  im.onerror = function () { load.textContent = "这张图没取到，退出重试一下"; };
  im.src = src;
  save.href = src;
  save.download = fileName || "";
  save.classList.add("on");
  v.style.display = "flex";
}
function viewerClose() {
  const v = document.getElementById("viewer");
  v.style.display = "none";
  v.style.transform = "";
  v.style.opacity = "";
  document.getElementById("viewersave").classList.remove("on");
  document.getElementById("viewerimg").src = "";
}
(function wireViewer() {
  const v = document.getElementById("viewer");
  const im = document.getElementById("viewerimg");
  if (!v || !im) return;
  document.getElementById("viewerx").onclick = viewerClose;
  v.addEventListener("click", function (e) { if (e.target === v) viewerClose(); });
  let closeSwipe = null;
  v.addEventListener("touchstart", function (e) {
    if (vScale > 1.05 || e.touches.length !== 1 ||
        e.target.closest("#viewerx, #viewersave")) return;
    closeSwipe = {y:e.touches[0].clientY, dy:0};
  }, {passive:true});
  v.addEventListener("touchmove", function (e) {
    if (!closeSwipe || e.touches.length !== 1) return;
    closeSwipe.dy = Math.max(0, e.touches[0].clientY - closeSwipe.y);
    if (closeSwipe.dy > 4) {
      v.style.transition = "none";
      v.style.transform = "translateY(" + closeSwipe.dy + "px)";
      v.style.opacity = String(Math.max(.28, 1 - closeSwipe.dy / 360));
      e.preventDefault();
    }
  }, {passive:false});
  function endCloseSwipe() {
    if (!closeSwipe) return;
    const close = closeSwipe.dy > 110;
    closeSwipe = null;
    v.style.transition = close ? "transform .18s ease, opacity .18s ease" : "";
    if (close) {
      v.style.transform = "translateY(110%)";
      v.style.opacity = "0";
      setTimeout(viewerClose, 170);
    } else {
      v.style.transform = "";
      v.style.opacity = "";
    }
  }
  v.addEventListener("touchend", endCloseSwipe, {passive:true});
  v.addEventListener("touchcancel", endCloseSwipe, {passive:true});
  const pts = {};
  function n() { return Object.keys(pts).length; }
  im.addEventListener("pointerdown", function (e) {
    pts[e.pointerId] = {x: e.clientX, y: e.clientY};
    try { im.setPointerCapture(e.pointerId); } catch (err) { }
    if (n() === 1) vDrag = {x: e.clientX - vx, y: e.clientY - vy};
    if (n() === 2) vDist = 0;
    e.preventDefault();
  });
  im.addEventListener("pointermove", function (e) {
    if (!pts[e.pointerId]) return;
    pts[e.pointerId] = {x: e.clientX, y: e.clientY};
    const k = n();
    if (k === 1 && vScale > 1.05 && vDrag) {
      vx = e.clientX - vDrag.x;
      vy = e.clientY - vDrag.y;
      vApply();
    } else if (k === 2) {
      const ks = Object.keys(pts);
      const d = Math.hypot(pts[ks[0]].x - pts[ks[1]].x, pts[ks[0]].y - pts[ks[1]].y);
      if (vDist > 0 && d > 0) vZoom(d / vDist);
      vDist = d;
    }
    e.preventDefault();
  });
  function up(e) {
    const single = n() === 1;
    delete pts[e.pointerId];
    vDist = 0;
    vDrag = null;
    if (single) {                       // 双击放大 / 还原
      const now = Date.now();
      if (now - vLastTap < 320) {
        if (vScale > 1.05) { vReset(); } else { vScale = 2.6; vApply(); }
        vLastTap = 0;
      } else {
        vLastTap = now;
      }
    }
  }
  im.addEventListener("pointerup", up);
  im.addEventListener("pointercancel", up);
  v.addEventListener("wheel", function (e) {      // 电脑上开这页时也能放大
    vZoom(e.deltaY < 0 ? 1.15 : 0.87);
    e.preventDefault();
  }, {passive: false});
})();
// ---- 文件：电脑发来的 / 跟电脑要 / 传到电脑 ----
document.getElementById("filetoggle").onclick = () => {
  const box = document.getElementById("files");
  box.classList.toggle("open");
  document.getElementById("filetoggle").textContent = box.classList.contains("open") ? "收起" : "展开";
  if (box.classList.contains("open")) { pullFiles(); pullAudios(); }
};
// ---- 试听：电脑上生成的语音样本，点一条直接在手机上播 ----
async function pullAudios() {
  const box = document.getElementById("audiolist");
  if (!box) return;
  try {
    const r = await fetch("/api/audios" + Q);
    const d = await r.json();
    const items = d.items || [];
    box.innerHTML = "";
    const m = document.getElementById("audiometa");
    if (m) m.textContent = items.length ? ("共 " + items.length + " 条") : "";
    if (!items.length) {
      box.innerHTML = '<div style="color:var(--dim);font-size:12px;padding:4px 0">' +
                      '还没有试听文件 —— 在电脑上生成音频后会自动出现在这里</div>';
      return;
    }
    for (const it of items) {
      const wrap = document.createElement("div");
      wrap.style.cssText = "margin:8px 0;padding:10px;border:1px solid var(--line);" +
                           "border-radius:11px;background:var(--panel)";
      const nm = document.createElement("div");
      nm.style.cssText = "font-size:13px;margin-bottom:8px;word-break:break-all";
      nm.textContent = it.name + (it.at ? "　·　" + it.at : "");
      const au = document.createElement("audio");
      au.controls = true;
      au.preload = "none";
      au.style.cssText = "width:100%;height:36px";
      au.src = "audio/" + encodeURIComponent(it.name) + Q;
      wrap.appendChild(nm);
      wrap.appendChild(au);
      box.appendChild(wrap);
    }
  } catch (e) {}
}
document.getElementById("audiorefresh").onclick = pullAudios;
// 优先用"公网那个下载页"当更新来源（电脑上设置里填过就用它）；
// 没填就退回电脑上的 /api/version（保证断网时也能提示）。
async function updateManifest() {
  const sites = [];
  // 结尾多一个斜杠也能认（不用正则，免得 Python 那边把反斜杠当转义）
  let base = siteBase;
  while (base.endsWith("/")) base = base.slice(0, -1);
  if (base) sites.push(base + "/version.json");
  for (const u of sites) {
    try {
      const r = await fetch(u, {cache: "no-store"});
      const mf = await r.json();
      if (mf && mf.ok) return mf;
    } catch (e) { /* 换下一个来源 */ }
  }
  return null;
}
// 手机切"发到哪个对话窗口"：列电脑上现有的窗口，点一下切过去
function winRow(title, sub, current) {
  const row = document.createElement("div");
  row.style.cssText = "display:flex;gap:8px;align-items:center;padding:11px 10px;margin:6px 0;" +
    "border:1px solid var(--line);border-radius:11px;font-size:14px;cursor:pointer;" +
    (current ? "background:#2a4a3a;border-color:#3ddc84;" : "background:var(--panel);");
  const t = document.createElement("div");
  t.style.cssText = "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
  t.innerHTML = "<b>" + title + "</b>" +
    (sub ? "<div style='color:var(--dim);font-size:11px;margin-top:2px'>" + sub + "</div>" : "");
  row.appendChild(t);
  if (current) {
    const c = document.createElement("span");
    c.textContent = "当前";
    c.style.cssText = "color:#3ddc84;font-size:12px;flex:0 0 auto";
    row.appendChild(c);
  }
  return row;
}
async function pullWins() {
  const box = document.getElementById("body-wins");
  box.innerHTML = "<div style='color:var(--dim);font-size:13px'>正在读电脑上的会话…</div>";
  try {
    const r = await fetch("/api/windows" + Q);
    const d = await r.json();
    box.innerHTML = "";
    const opened = String(d.current || "");     // 电脑上此刻开着的是哪个
    const chosen = String(d.chosen || "");      // 手机选的是哪个
    const autoRow = winRow("自动", "电脑上开着哪个会话，就发到哪个", chosen === "");
    autoRow.onclick = () => setWin("");
    box.appendChild(autoRow);
    (d.windows || []).forEach(w => {
      const bits = [];
      if (w.title === opened) bits.push("电脑上正开着");
      if (w.title === chosen) bits.push("手机发的话去这儿");
      const row = winRow(w.title, bits.join(" · "), w.title === chosen);
      row.onclick = () => setWin(w.title);
      box.appendChild(row);
    });
    if (!(d.windows || []).length) {
      const e = document.createElement("div");
      e.style.cssText = "color:var(--dim);font-size:12px;margin-top:10px";
      e.textContent = "没读到会话 —— 先把电脑上的 Codex 打开（侧栏里有对话才行）。";
      box.appendChild(e);
    }
    const re = document.createElement("button");
    re.className = "ghost";
    re.textContent = "刷新";
    re.style.cssText = "margin-top:12px;height:36px;font-size:13px";
    re.onclick = pullWins;
    box.appendChild(re);
  } catch (e) {
    box.innerHTML = "<div style='color:var(--dim);font-size:13px'>拉不到窗口列表：" + e + "</div>";
  }
}
async function setWin(title) {
  try {
    const d = await securePost("/api/target", {title: title});
    if (!d.ok) {
      alert("没切成：" + (d.msg || "电脑上的会话没有切换成功"));
      return;
    }
    await pullWins();
  } catch (e) {
    alert("没切成：" + e);
  }
}
async function pullFiles() {
  if (!document.getElementById("files").classList.contains("open")) return;
  try {
    const r = await fetch("/api/files" + Q);
    const d = await r.json();
    const box = document.getElementById("filelist");
    box.innerHTML = "";
    if (!(d.items || []).length) {
      box.innerHTML = '<div class="f" style="color:var(--dim)">还没有文件 —— 在电脑上说' +
                      '「把 xxx 发到手机」，或者在下面输入文件名要一个</div>';
    }
    for (const it of (d.items || [])) {
      const row = document.createElement("div");
      row.className = "f";
      const a = document.createElement("a");
      a.href = "file/" + encodeURIComponent(it.name) + Q;
      a.textContent = "📄 " + it.name;
      const s = document.createElement("span");
      s.textContent = it.kb > 1024 ? (it.kb / 1024).toFixed(1) + " MB" : it.kb + " KB";
      row.appendChild(a); row.appendChild(s);
      box.appendChild(row);
    }
    if (d.uploads && d.uploads.length) {
      document.getElementById("filemeta").textContent =
        "手机传给电脑的最近一个：" + d.uploads[0].name + "（在电脑的 手机上传\ 里）";
    }
  } catch (e) {}
}
document.getElementById("askbtn").onclick = async () => {
  const v = document.getElementById("askfile").value.trim();
  if (!v) return;
  document.getElementById("filemeta").textContent = "跟电脑要 " + v + " …";
  await post("/api/cmd", {text: "把" + v + "发到手机"});
  setTimeout(pullFiles, 1500);
};
document.getElementById("upbtn").onclick = () => document.getElementById("upfile").click();
// ---- 手机发图片：选相册里的图（可多选）→ 传到电脑 → 直接贴进对话窗口让 AI 看图 ----
document.getElementById("tiimg").onclick = () => {
  togglePlus(false);
  document.getElementById("imgfile").click();
};
document.getElementById("tifile").onclick = () => {
  togglePlus(false);
  document.getElementById("sendfile").click();
};
document.getElementById("imgfile").onchange = e => {
  stageFiles(Array.from(e.target.files || []));
  e.target.value = "";
};
document.getElementById("sendfile").onchange = e => {
  stageFiles(Array.from(e.target.files || []));
  e.target.value = "";
};
document.getElementById("upfile").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  document.getElementById("filemeta").textContent =
    "正在传到电脑：" + f.name + "（" + (f.size / 1024).toFixed(0) + " KB）";
  try {
    const d = await securePostRaw("/api/upload?name=" + encodeURIComponent(f.name), f);
    document.getElementById("filemeta").textContent = d.ok
      ? "传好了：" + f.name + "（电脑上的「手机上传」文件夹里）"
      : ("传失败：" + (d.err || ""));
  } catch (err) {
    document.getElementById("filemeta").textContent = "传失败：连不上电脑";
  }
  e.target.value = "";
  pullFiles();
};

// ---- 微信聊天框右下角那个「＋」：点一下从底下滑出功能菜单 ----
/** 手机返回键：有开着的东西就关掉，返回 1；什么都没有就返回 0（交给 APP 去退）。 */
window.onAndroidBack = () => {
  if (document.getElementById("viewer").style.display === "flex") {
    viewerClose();                        // 看大图时先退图，而不是退页面
    return 1;
  }
  if (document.getElementById("historyPanel").classList.contains("open")) {
    closeHistoryPanel();
    return 1;
  }
  if (pendingAttachments.length) {
    for (const item of pendingAttachments) {
      if (item.preview) URL.revokeObjectURL(item.preview);
    }
    pendingAttachments.splice(0);
    renderAttachTray();
    return 1;
  }
  const pageOpen = document.querySelector(".page.open");
  if (pageOpen) { closePages(); return 1; }
  if (document.getElementById("sheet").classList.contains("open")) {
    document.getElementById("sheet").classList.remove("open");
    document.getElementById("sheetbg").classList.remove("on");
    return 1;
  }
  if (document.getElementById("pluspanel").classList.contains("open")) {
    togglePlus(false);
    return 1;
  }
  return 0;
};
