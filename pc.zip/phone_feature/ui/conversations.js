// FinDeck phone conversation drawer, actions and touch gestures.
// Loaded after the main script; uses its renderer and request helpers.

// ---- Codex 风格会话抽屉 ----
const drawer = document.getElementById("convdrawer");
const convbg = document.getElementById("convbg");
let drawerOpen = false;
let drawerTimer = null;
let convLabel = "";
let drawerFilter = "all";
let lastDrawerData = null;
let drawerRenderedKey = "";
let drawerSearch = "";
let convBusy = false;
let actionThread = null;
let dialogResolve = null;
let suppressRowClickUntil = 0;
const collapsedGroups = new Set();
try {
  const savedDrawer = JSON.parse(localStorage.getItem("drawerCacheV2") || "null");
  if (savedDrawer && savedDrawer.data && Array.isArray(savedDrawer.data.windows)) {
    lastDrawerData = savedDrawer.data;
  }
  const savedCollapsed = JSON.parse(localStorage.getItem("drawerCollapsedV1") || "[]");
  if (Array.isArray(savedCollapsed)) savedCollapsed.forEach(k => collapsedGroups.add(String(k)));
} catch (e) {}

const convSearchEl = document.getElementById("convsearch");
const convSearchClear = document.getElementById("convsearchclear");

function convThreadKey(w) {
  return String((w && (w.id || w.title)) || "");
}
function saveCollapsedGroups() {
  try { localStorage.setItem("drawerCollapsedV1", JSON.stringify([...collapsedGroups])); } catch (e) {}
}
function convTimeText(ms) {
  const n = Number(ms || 0);
  if (!n) return "";
  const t = n < 100000000000 ? n * 1000 : n;
  const d = new Date(t);
  if (Number.isNaN(d.getTime())) return "";
  const now = new Date();
  const diff = now.getTime() - t;
  if (diff >= 0 && diff < 60000) return "刚刚";
  if (diff >= 0 && diff < 3600000) return Math.max(1, Math.floor(diff / 60000)) + " 分钟前";
  if (d.toDateString() === now.toDateString()) {
    return d.toLocaleTimeString("zh-CN", {hour:"2-digit", minute:"2-digit"});
  }
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return "昨天";
  if (d.getFullYear() === now.getFullYear()) {
    return (d.getMonth() + 1) + "月" + d.getDate() + "日";
  }
  return d.getFullYear() + "/" + (d.getMonth() + 1) + "/" + d.getDate();
}
function convToast(text) {
  let el = document.getElementById("convToast");
  if (!el) {
    el = document.createElement("div");
    el.id = "convToast";
    document.getElementById("convdrawer").appendChild(el);
  }
  el.textContent = text || "";
  el.classList.add("show");
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove("show"), 2200);
}
function closeConvAction() {
  document.getElementById("convActionBg").classList.remove("on");
  const sheet = document.getElementById("convActionSheet");
  sheet.classList.remove("on");
  sheet.setAttribute("aria-hidden", "true");
  actionThread = null;
}
function convDialogClose(value) {
  document.getElementById("convDialogBg").classList.remove("on");
  const dlg = document.getElementById("convDialog");
  dlg.classList.remove("on");
  dlg.setAttribute("aria-hidden", "true");
  const resolve = dialogResolve;
  dialogResolve = null;
  if (resolve) resolve(value);
}
function convDialogOpen(opts) {
  if (dialogResolve) convDialogClose(null);
  const dlg = document.getElementById("convDialog");
  const input = document.getElementById("convDialogInput");
  const choices = document.getElementById("convDialogChoices");
  const ok = document.getElementById("convDialogOk");
  const cancel = document.getElementById("convDialogCancel");
  document.getElementById("convDialogTitle").textContent = opts.title || "会话";
  document.getElementById("convDialogMsg").textContent = opts.message || "";
  input.hidden = opts.input == null;
  input.value = opts.input || "";
  input.placeholder = opts.placeholder || "";
  choices.innerHTML = "";
  (opts.choices || []).forEach(choice => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "ca-action";
    const ci = document.createElement("span"); ci.className = "ci";
    ci.textContent = choice.icon || ""; b.appendChild(ci);
    const tx = document.createElement("span"); tx.textContent = choice.label; b.appendChild(tx);
    b.onclick = () => convDialogClose(choice.value);
    choices.appendChild(b);
  });
  choices.hidden = !(opts.choices && opts.choices.length);
  ok.textContent = opts.okText || "确定";
  ok.className = opts.danger ? "danger" : "primary";
  ok.onclick = () => convDialogClose(opts.input == null ? true : input.value.trim());
  cancel.onclick = () => convDialogClose(null);
  document.getElementById("convDialogBg").classList.add("on");
  dlg.classList.add("on");
  dlg.setAttribute("aria-hidden", "false");
  return new Promise(resolve => {
    dialogResolve = resolve;
    if (!input.hidden) setTimeout(() => { input.focus(); input.select(); }, 180);
  });
}

function convGroup(title, items, options) {
  const box = document.getElementById("convlist");
  const key = String((options && options.key) || title);
  const head = document.createElement("div");
  head.className = "conv-group-head" + (collapsedGroups.has(key) ? " collapsed" : "") +
                   (options && options.projectId != null ? " has-new" : "");
  const chev = document.createElement("span"); chev.className = "chev"; chev.textContent = "⌄";
  const name = document.createElement("span"); name.className = "gname"; name.textContent = title;
  const count = document.createElement("span"); count.className = "gcount"; count.textContent = items.length || "";
  head.append(chev, name, count);
  if (options && options.projectId != null) {
    const add = document.createElement("button");
    add.type = "button"; add.className = "gnew"; add.textContent = "＋";
    add.setAttribute("aria-label", "在此项目中新建对话");
    add.onclick = e => { e.stopPropagation(); createNewConv(options.projectId); };
    head.appendChild(add);
  }
  head.onclick = () => {
    if (collapsedGroups.has(key)) collapsedGroups.delete(key); else collapsedGroups.add(key);
    saveCollapsedGroups(); drawerRender(lastDrawerData);
  };
  box.appendChild(head);
  if (!collapsedGroups.has(key)) items.forEach(w => convOne(w, false));
}

function convOne(w, auto) {
  const box = document.getElementById("convlist");
  const opened = String((lastDrawerData && lastDrawerData.current) || "");
  const chosen = String((lastDrawerData && lastDrawerData.chosen) || "");
  const same = auto ? !chosen : (w.id && lastDrawerData && lastDrawerData.chosen_id
    ? String(w.id) === String(lastDrawerData.chosen_id)
    : String(w.title || "") === chosen);
  const row = document.createElement("div");
  row.className = "drow" + (same ? " now" : "") + (auto ? " auto-row" : "") +
                  (!auto && w.unread ? " unread" : "") + (!auto && w.archived ? " archived" : "");
  row.dataset.title = auto ? "" : String(w.title || "");
  row.dataset.id = auto ? "" : String(w.id || "");
  const main = document.createElement("div"); main.className = "drow-main";
  const dot = document.createElement("span"); dot.className = "unread-dot";
  const copy = document.createElement("div"); copy.className = "drow-copy";
  const nm = document.createElement("span"); nm.className = "nm";
  nm.textContent = auto ? "自动 · 跟随电脑当前对话" : (w.title || "未命名对话");
  copy.appendChild(nm);
  if (!auto && w.preview && w.preview !== w.title) {
    const pv = document.createElement("span"); pv.className = "preview"; pv.textContent = w.preview;
    copy.appendChild(pv);
  }
  const meta = document.createElement("span"); meta.className = "row-meta";
  const tm = document.createElement("span"); tm.textContent = auto ? "手机发送跟随电脑" : convTimeText(w.updated_at);
  if (tm.textContent) meta.appendChild(tm);
  if (!auto && w.current) {
    const st = document.createElement("span"); st.className = "row-state"; st.textContent = "电脑正打开";
    meta.appendChild(st);
  }
  if (!auto && same) {
    const st = document.createElement("span"); st.className = "row-state"; st.textContent = "已选";
    meta.appendChild(st);
  }
  if (!auto && w.pinned) {
    const p = document.createElement("span"); p.className = "pinmark"; p.textContent = "置顶";
    meta.appendChild(p);
  }
  if (!auto && w.archived) {
    const p = document.createElement("span"); p.textContent = "已归档";
    meta.appendChild(p);
  }
  if (meta.children.length) copy.appendChild(meta);
  const more = document.createElement("button");
  more.type = "button"; more.className = "rowmore"; more.textContent = "⋯";
  more.setAttribute("aria-label", "会话操作");
  more.onclick = e => { e.stopPropagation(); showConvActions(w); };
  main.append(dot, copy, more);
  row.appendChild(main);
  row.onclick = () => {
    if (Date.now() < suppressRowClickUntil) return;
    if (navigator.vibrate) navigator.vibrate(4);
    setConv(auto ? "" : w.title, auto ? "" : (w.id || ""));
  };
  let holdTimer = null, holdX = 0, holdY = 0;
  row.addEventListener("touchstart", e => {
    if (auto || e.touches.length !== 1) return;
    holdX = e.touches[0].clientX; holdY = e.touches[0].clientY;
    holdTimer = setTimeout(() => {
      holdTimer = null; suppressRowClickUntil = Date.now() + 700;
      if (navigator.vibrate) navigator.vibrate(18);
      showConvActions(w);
    }, 520);
  }, {passive:true});
  row.addEventListener("touchmove", e => {
    if (!holdTimer || !e.touches.length) return;
    if (Math.abs(e.touches[0].clientX - holdX) > 8 ||
        Math.abs(e.touches[0].clientY - holdY) > 8) {
      clearTimeout(holdTimer); holdTimer = null;
    }
  }, {passive:true});
  const cancelHold = () => { if (holdTimer) { clearTimeout(holdTimer); holdTimer = null; } };
  row.addEventListener("touchend", cancelHold, {passive:true});
  row.addEventListener("touchcancel", cancelHold, {passive:true});
  box.appendChild(row);
}

function drawerRender(d, note, addedKeys, removedTitles) {
  if (!d) return;
  const box = document.getElementById("convlist");
  const wins = Array.isArray(d.windows) ? d.windows.slice() : [];
  lastDrawerData = d;
  drawerRenderedKey = JSON.stringify(wins);
  convLabel = String(d.chosen || d.current || "自动");
  refreshConvTint();
  box.innerHTML = "";
  const q = drawerSearch.trim().toLocaleLowerCase("zh-CN");
  const match = w => !q || [w.title, w.project, w.preview]
    .some(v => String(v || "").toLocaleLowerCase("zh-CN").includes(q));
  const visible = wins.filter(match);
  const active = visible.filter(w => !w.archived);
  const archived = visible.filter(w => w.archived);
  const pinned = active.filter(w => w.pinned);
  const projectRows = active.filter(w => !w.pinned && w.project);
  const recent = active.filter(w => !w.pinned && !w.project);
  const projects = Array.isArray(d.projects) ? d.projects.slice() : [];
  const projectMap = new Map();
  projects.forEach(p => projectMap.set(String(p.name), {id:String(p.id), items:[]}));
  projectRows.forEach(w => {
    const name = String(w.project || "未命名项目");
    if (!projectMap.has(name)) projectMap.set(name, {id:String(w.project_id || ""), items:[]});
    projectMap.get(name).items.push(w);
  });

  if ((addedKeys && addedKeys.size) || (removedTitles && removedTitles.length)) {
    const diff = document.createElement("div"); diff.id = "drawerDiff";
    const addNames = [...(addedKeys || [])].slice(0,3).map(k => {
      const w = wins.find(x => convThreadKey(x) === k); return w ? w.title : k;
    });
    const parts = [];
    if (addNames.length) parts.push("新增：" + addNames.join("、"));
    if (removedTitles && removedTitles.length) parts.push("移除：" + removedTitles.slice(0,3).join("、"));
    diff.textContent = parts.join("  ·  "); box.appendChild(diff);
    setTimeout(() => diff.classList.add("show"), 20);
    setTimeout(() => diff.remove(), 3000);
  }

  if (!q && (drawerFilter === "all" || drawerFilter === "recent")) {
    const head = document.createElement("div"); head.className = "conv-group-head";
    head.innerHTML = '<span class="chev">⌄</span><span class="gname">跟随电脑</span><span class="gcount"></span>';
    box.appendChild(head); convOne({title:"自动"}, true);
  }
  if (drawerFilter === "all" || drawerFilter === "projects") {
    for (const [name, group] of projectMap) {
      if (q && !name.toLocaleLowerCase("zh-CN").includes(q) && !group.items.some(match)) continue;
      if (drawerFilter === "projects" || group.items.length || !q) {
        convGroup(name, group.items, {key:"project:" + name, projectId:group.id});
      }
    }
    if (drawerFilter === "projects" && !projectMap.size) {
      const e = document.createElement("div"); e.className = "conv-empty"; e.textContent = "还没有项目";
      box.appendChild(e);
    }
  }
  if ((drawerFilter === "all" || drawerFilter === "pinned") && pinned.length) {
    convGroup("置顶", pinned, {key:"pinned"});
  }
  if ((drawerFilter === "all" || drawerFilter === "recent") && recent.length) {
    convGroup("最近", recent, {key:"recent"});
  }
  if (drawerFilter === "archived") {
    if (archived.length) convGroup("已归档", archived, {key:"archived"});
    if (!archived.length) {
      const e = document.createElement("div"); e.className = "conv-empty"; e.textContent = q ? "没有匹配的归档会话" : "还没有归档会话";
      box.appendChild(e);
    }
  }
  if (!box.children.length) {
    const e = document.createElement("div"); e.className = "conv-empty";
    e.textContent = wins.length ? "没有匹配的会话或项目" :
      "没读到会话。先把电脑上的 Codex 打开。";
    box.appendChild(e);
  }
  const labels = {projects:"项目", pinned:"置顶", recent:"最近", archived:"归档"};
  const counts = {
    projects:projectMap.size, pinned:pinned.length, recent:recent.length, archived:archived.length,
  };
  document.querySelectorAll("#drawerTabs button").forEach(b => {
    const k = b.dataset.cat;
    b.classList.toggle("on", k === drawerFilter);
    b.textContent = labels[k] + (counts[k] ? " " + counts[k] : "");
  });
  const who = document.getElementById("convwho");
  if (who) who.textContent = d.chosen ? ("手机发送到：" + d.chosen) :
    (d.current ? ("跟随电脑 · " + d.current) : "跟随电脑当前对话");
  try { localStorage.setItem("drawerCacheV2", JSON.stringify({at:Date.now(),data:d})); } catch (e) {}
}

document.querySelectorAll("#drawerTabs button").forEach(b => {
  b.onclick = () => {
    if (navigator.vibrate) navigator.vibrate(4);
    const next = b.dataset.cat || "all";
    drawerFilter = drawerFilter === next ? "all" : next;
    if (lastDrawerData) drawerRender(lastDrawerData);
  };
});
convSearchEl.addEventListener("input", () => {
  drawerSearch = convSearchEl.value;
  convSearchClear.classList.toggle("on", !!drawerSearch);
  if (lastDrawerData) drawerRender(lastDrawerData);
});
convSearchClear.onclick = () => {
  convSearchEl.value = ""; drawerSearch = ""; convSearchClear.classList.remove("on");
  if (lastDrawerData) drawerRender(lastDrawerData); convSearchEl.focus();
};

function drawerKeys(d) {
  return new Set((d && Array.isArray(d.windows) ? d.windows : []).map(convThreadKey));
}
function drawerTitleMap(d) {
  const m = new Map();
  (d && Array.isArray(d.windows) ? d.windows : []).forEach(w => m.set(convThreadKey(w), w.title));
  return m;
}
async function pullConvs(manual) {
  if (convBusy) return;
  convBusy = true;
  const box = document.getElementById("convlist");
  const hadCache = !!(lastDrawerData && Array.isArray(lastDrawerData.windows));
  if (box && !hadCache) box.innerHTML = "<div class='conv-empty'>正在读取电脑上的会话…</div>";
  try {
    const r = await fetch("/api/windows" + Q + (manual ? "&t=" + Date.now() : ""));
    const d = await r.json();
    const old = lastDrawerData;
    const oldKeys = drawerKeys(old), newKeys = drawerKeys(d);
    const added = new Set([...newKeys].filter(k => !oldKeys.has(k)));
    const removed = [...oldKeys].filter(k => !newKeys.has(k));
    const removedTitles = removed.map(k => drawerTitleMap(old).get(k) || k);
    const changed = !old || JSON.stringify(old.windows || []) !== JSON.stringify(d.windows || []) ||
      JSON.stringify(old.projects || []) !== JSON.stringify(d.projects || []) ||
      old.current !== d.current || old.chosen !== d.chosen;
    if (drawerOpen && changed) {
      drawerRender(d, "", added, removedTitles);
    } else if (drawerOpen && d) {
      lastDrawerData = d;
      const who = document.getElementById("convwho");
      if (who) who.textContent = d.chosen ? ("手机发送到：" + d.chosen) : "跟随电脑当前对话";
    } else {
      lastDrawerData = d;
      convLabel = String(d.chosen || d.current || "自动");
      refreshConvTint();
    }
  } catch (e) {
    if (box && !hadCache) {
      box.innerHTML = "<div class='conv-empty'>拉不到会话。检查电脑上的鳍舱和 Codex 是否开着。</div>";
    } else {
      const who = document.getElementById("convwho"); if (who) who.textContent = "刷新失败，显示上次加载";
    }
  } finally { convBusy = false; }
}

async function setConv(title, threadId) {
  try {
    const d = await securePost("/api/target", {title: title, id: threadId || ""});
    if (!d.ok) {
      alert("没切成：" + (d.msg || "电脑端没有确认切换"));
      await pullConvs(true);
      return false;
    }
    convLabel = String(d.current || title || "自动");
    refreshConvTint();
    closeDrawer();
    add("done", "已经切到：" + (d.current || title || "自动"), null, null,
        d.current || title || "自动");
    pullConvs(true);
    return true;
  } catch (e) {
    alert("没切成：" + e);
    return false;
  }
}

async function performConvAction(action, payload) {
  if (!actionThread) return false;
  const thread = actionThread;
  closeConvAction();
  try {
    const d = await securePost("/api/threads/action", Object.assign(
      {action:action,id:thread.id,title:thread.title}, payload || {}));
    convToast(d.ok ? (d.msg || "已完成") : ("操作失败：" + (d.msg || "未知错误")));
    if (d.ok) setTimeout(() => pullConvs(true), 180);
    return !!d.ok;
  } catch (e) {
    convToast("操作失败：" + e);
    return false;
  }
}

async function showConvActions(w) {
  if (!w || !w.id) { convToast("这个会话暂时没有可管理的 ID"); return; }
  actionThread = w;
  const actions = document.getElementById("caActions");
  actions.innerHTML = "";
  document.getElementById("caTitle").textContent = w.title || "会话操作";
  const add = (icon, label, fn, danger) => {
    const b = document.createElement("button"); b.type = "button";
    b.className = "ca-action" + (danger ? " danger" : "");
    const ci = document.createElement("span"); ci.className = "ci"; ci.textContent = icon;
    const tx = document.createElement("span"); tx.textContent = label;
    b.append(ci, tx); b.onclick = fn; actions.appendChild(b);
  };
  add("✎", "重命名", async () => {
    const name = await convDialogOpen({
      title:"重命名会话", message:"名称会同步到 Codex 桌面端。", input:w.title,
      placeholder:"会话名称", okText:"保存",
    });
    if (name != null && name !== w.title) performConvAction("rename", {name:name});
    else if (name != null) closeConvAction();
  });
  add("⌖", w.pinned ? "取消置顶" : "置顶", () => {
    performConvAction("pin", {pinned:!w.pinned});
  });
  add("◉", w.unread ? "标为已读" : "标为未读", () => {
    performConvAction("read", {read:!!w.unread, revision:w.read_revision || ""});
  });
  add("▣", "移动到项目", async () => {
    const projects = (lastDrawerData && Array.isArray(lastDrawerData.projects))
      ? lastDrawerData.projects : [];
    const choices = projects.map(p => ({icon:"▣", label:p.name, value:String(p.id)}));
    choices.push({icon:"—", label:"移出项目", value:""});
    const pid = await convDialogOpen({
      title:"移动到项目", message:"选择会话要归属的项目。", choices:choices,
    });
    if (pid != null) performConvAction("project", {project_id:pid});
    else closeConvAction();
  });
  add("⌄", w.archived ? "取消归档" : "归档", () => {
    performConvAction("archive", {archived:!w.archived});
  });
  add("⌫", "永久删除", async () => {
    const ok = await convDialogOpen({
      title:"永久删除会话？",
      message:"会删除这条会话及其子会话，无法从 Codex 撤销。",
      okText:"永久删除", danger:true,
    });
    if (ok) performConvAction("delete", {});
    else closeConvAction();
  }, true);
  document.getElementById("convActionBg").classList.add("on");
  const sheet = document.getElementById("convActionSheet");
  sheet.classList.add("on"); sheet.setAttribute("aria-hidden", "false");
}

async function createNewConv(projectId) {
  try {
    const d = await securePost("/api/threads/new", {project_id:projectId || ""});
    if (!d.ok) { convToast("新建失败：" + (d.msg || "电脑端没有打开新对话")); return; }
    closeDrawer();
    add("done", "已经打开新对话", null, null, "自动");
    setTimeout(() => pullConvs(true), 350);
  } catch (e) { convToast("新建失败：" + e); }
}

function openDrawer() {
  drawerOpen = true;
  drawer.style.transition = "";
  drawer.style.transform = "";
  drawer.classList.add("open");
  convbg.classList.add("on");
  if (lastDrawerData) {
    if (!document.getElementById("convlist").children.length ||
        drawerRenderedKey !== JSON.stringify(lastDrawerData.windows || [])) {
      drawerRender(lastDrawerData, "上次加载，正在后台刷新");
    }
  }
  pullConvs(false);
  if (drawerTimer) clearInterval(drawerTimer);
  drawerTimer = setInterval(() => { if (drawerOpen) pullConvs(); }, 8000);
}
function closeDrawer() {
  drawerOpen = false;
  if (drawerTimer) { clearInterval(drawerTimer); drawerTimer = null; }
  drawer.style.transition = "";
  drawer.style.transform = "";
  drawer.classList.remove("open");
  convbg.classList.remove("on");
}
convbg.onclick = closeDrawer;
document.getElementById("convclose").onclick = closeDrawer;
document.getElementById("convnew").onclick = () => createNewConv("");
document.getElementById("caClose").onclick = closeConvAction;
document.getElementById("convActionBg").onclick = closeConvAction;
document.getElementById("convDialogBg").onclick = () => convDialogClose(null);
pullConvs(true);
if (new URLSearchParams(location.search).has("drawer")) {
  setTimeout(openDrawer, 450);
}

// 左边缘右滑开抽屉 / 抽屉上左滑收起。独立监听，避免被消息气泡的手势截断。
const drawerEdge = document.getElementById("drawerEdge");
let edgeSwipe = null;
drawerEdge.addEventListener("touchstart", e => {
  if (drawerOpen || document.getElementById("sheet").classList.contains("open") ||
      document.getElementById("viewer").style.display === "flex" ||
      e.touches.length !== 1) return;
  edgeSwipe = {x:e.touches[0].clientX, y:e.touches[0].clientY, dx:0, active:false};
}, {passive:true});
drawerEdge.addEventListener("touchmove", e => {
  if (!edgeSwipe || e.touches.length !== 1) return;
  const t = e.touches[0];
  edgeSwipe.dx = Math.max(0, t.clientX - edgeSwipe.x);
  if (edgeSwipe.dx > 6) {
    edgeSwipe.active = true;
    const w = Math.min(380, innerWidth * .84);
    const pct = Math.min(1, edgeSwipe.dx / w);
    drawer.style.transition = "none";
    drawer.style.transform = "translate3d(" + (-102 + 102 * pct) + "%,0,0)";
    convbg.classList.add("on");
    e.preventDefault();
  }
}, {passive:false});
function finishEdgeSwipe() {
  if (!edgeSwipe) return;
  const active = edgeSwipe.active, dx = edgeSwipe.dx;
  edgeSwipe = null;
  drawer.style.transition = "";
  drawer.style.transform = "";
  if (active && dx > Math.min(120, innerWidth * .20)) openDrawer();
  else { convbg.classList.remove("on"); }
}
drawerEdge.addEventListener("touchend", finishEdgeSwipe, {passive:true});
drawerEdge.addEventListener("touchcancel", finishEdgeSwipe, {passive:true});

let drawerSwipe = null;
drawer.addEventListener("touchstart", e => {
  if (!drawerOpen || e.touches.length !== 1) return;
  drawerSwipe = {x:e.touches[0].clientX, y:e.touches[0].clientY, dx:0, active:false};
}, {passive:true});
drawer.addEventListener("touchmove", e => {
  if (!drawerSwipe || e.touches.length !== 1) return;
  const dx = e.touches[0].clientX - drawerSwipe.x;
  const dy = e.touches[0].clientY - drawerSwipe.y;
  if (!drawerSwipe.active && (dx >= 0 || Math.abs(dx) < Math.abs(dy) + 4)) return;
  drawerSwipe.active = true;
  drawerSwipe.dx = Math.min(0, dx);
  const w = Math.min(380, innerWidth * .84);
  const pct = Math.max(0, 1 + drawerSwipe.dx / w);
  drawer.style.transition = "none";
  drawer.style.transform = "translate3d(" + (-102 + 102 * pct) + "%,0,0)";
  e.preventDefault();
}, {passive:false});
function finishDrawerSwipe() {
  if (!drawerSwipe) return;
  const close = drawerSwipe.active && drawerSwipe.dx < -Math.min(90, innerWidth * .16);
  drawerSwipe = null;
  drawer.style.transition = "";
  drawer.style.transform = "";
  if (close) closeDrawer(); else if (drawerOpen) openDrawer();
}
drawer.addEventListener("touchend", finishDrawerSwipe, {passive:true});
drawer.addEventListener("touchcancel", finishDrawerSwipe, {passive:true});

// 左侧会话列表：顶部下拉刷新（替代原来的刷新按钮）。
const drawerPullEl = document.getElementById("drawerPull");
let drawerPullY = null, drawerPullDy = 0, drawerPulling = false;
const convlistEl = document.getElementById("convlist");
convlistEl.addEventListener("touchstart", e => {
  if (e.touches.length !== 1 || convlistEl.scrollTop > 0) return;
  drawerPullY = e.touches[0].clientY;
  drawerPullDy = 0;
  drawerPulling = false;
}, {passive: true});
convlistEl.addEventListener("touchmove", e => {
  if (drawerPullY === null || e.touches.length !== 1) return;
  const dy = e.touches[0].clientY - drawerPullY;
  if (dy <= 0) return;
  drawerPullDy = Math.min(72, dy * .55);
  if (drawerPullDy > 3) drawerPulling = true;
  if (drawerPulling) {
    drawerPullEl.classList.add("pulling");
    drawerPullEl.querySelector("span").textContent =
      drawerPullDy >= 46 ? "松手刷新" : "下拉刷新";
    e.preventDefault();
  }
}, {passive: false});
async function finishDrawerPull() {
  if (drawerPullY === null) return;
  drawerPullY = null;
  if (!drawerPulling) return;
  drawerPulling = false;
  if (drawerPullDy < 46) {
    drawerPullEl.classList.remove("pulling");
    return;
  }
  drawerPullEl.classList.remove("pulling");
  drawerPullEl.classList.add("refreshing");
  drawerPullEl.querySelector("span").textContent = "正在刷新";
  await pullConvs(true);
  drawerPullEl.querySelector("span").textContent = "已刷新";
  setTimeout(() => drawerPullEl.classList.remove("refreshing"), 420);
}
convlistEl.addEventListener("touchend", finishDrawerPull, {passive: true});
convlistEl.addEventListener("touchcancel", finishDrawerPull, {passive: true});

// 手势：聊天区往左滑一下 → 抽屉出来（用户要的）；
// 从左边缘往右拖 → 抽屉跟手出来（推特那种）。
let _tx = 0, _ty = 0, _tt = 0, _drag = false, _touched = false;

function gestureStart(e) {
  const t = e.touches[0];
  if (!t) return;
  if (e.target.closest("textarea, input, #drawerTabs, #sheet, #pluspanel")) {
    _touched = false;
    return;
  }
  _tx = t.clientX; _ty = t.clientY; _tt = Date.now();
  _drag = false;
  _touched = true;
}

function gestureMove(e) {
  if (!_touched) return;
  const t = e.touches[0];
  if (!t) return;
  const dx = t.clientX - _tx, dy = t.clientY - _ty;
  if (Math.abs(dx) < Math.abs(dy)) return;        // 竖着划就给页面滚动
  // 触发范围放大到左半屏：不用非要从最边缘那几十像素开始。
  if (!drawerOpen && dx > 0) {
    _drag = true;
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = Math.min(1, dx / w);
    drawer.style.transition = "none";
    drawer.style.transform = "translate3d(" + (-102 + 102 * pct) + "%,0,0)";
    if (pct > 0.12) convbg.classList.add("on");
  } else if (drawerOpen && dx < 0) {              // 打开着往回拖
    _drag = true;
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = Math.max(0, 1 + dx / w);
    drawer.style.transition = "none";
    drawer.style.transform = "translate3d(" + (-102 + 102 * pct) + "%,0,0)";
  }
}

function gestureEnd(e) {
  if (!_touched) return;
  _touched = false;
  const t = (e.changedTouches && e.changedTouches[0]) || null;
  const dx = t ? t.clientX - _tx : 0;
  const dy = t ? t.clientY - _ty : 0;
  const dt = Date.now() - _tt;
  if (_drag) {                                    // 拖拽收尾
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = drawerOpen ? 1 + dx / w : dx / w;
    drawer.style.transition = "";
    drawer.style.transform = "";
    if (pct > 0.35) { openDrawer(); } else { closeDrawer(); }
    return;
  }
  // 快速横滑：往左滑一下也把抽屉叫出来（用户要的手势）；往右滑则关掉
  if (dt < 500 && Math.abs(dx) > 60 && Math.abs(dy) < 45) {
    if (dx < 0 && !drawerOpen) { openDrawer(); }
    else if (dx > 0 && drawerOpen) { closeDrawer(); }
  }
}

const gesArea = document.body;
if (gesArea) {
  gesArea.addEventListener("touchstart", gestureStart, {passive: true});
  gesArea.addEventListener("touchmove", gestureMove, {passive: true});
  gesArea.addEventListener("touchend", gestureEnd, {passive: true});
  gesArea.addEventListener("touchcancel", gestureEnd, {passive: true});
}
