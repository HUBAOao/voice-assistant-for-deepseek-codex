// FinDeck phone task console: approval, steer, tests and diff review.
// Loaded after the main page script; shares authenticated request helpers.

let taskTimer = null;
const taskItems = new Map();
let taskCursor = 0;
let taskFirstLoad = true;
let taskTransportOnline = true;
const TASK_STATUS = {
  queued: "排队", running: "运行中", waiting_approval: "待批准",
  succeeded: "完成", failed: "失败", cancelled: "已取消"
};
function taskTime(ts) {
  const n = Number(ts || 0);
  if (!n) return "";
  const d = new Date(n * 1000);
  const z = v => String(v).padStart(2, "0");
  return z(d.getMonth() + 1) + "-" + z(d.getDate()) + " " + z(d.getHours()) + ":" + z(d.getMinutes());
}
async function taskAction(action, id, extra = {}) {
  const d = await securePost("/api/tasks/action", Object.assign({action, id}, extra));
  if (!d.ok) alert(d.err || "任务操作失败");
  if (d.task && d.task.id) taskItems.set(d.task.id, d.task);
  await pullTasks(true);
}
async function pullTasks(manual = false) {
  try {
    const after = taskFirstLoad ? 0 : taskCursor;
    const r = await fetch("/api/tasks" + Q + "&limit=100&sync=1&after=" + after,
                          {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    if (d.reset) taskItems.clear();
    for (const task of (Array.isArray(d.items) ? d.items : [])) taskItems.set(task.id, task);
    if (Array.isArray(d.ids)) {
      const keep = new Set(d.ids);
      for (const id of taskItems.keys()) if (!keep.has(id)) taskItems.delete(id);
    }
    taskCursor = Number(d.cursor || taskCursor);
    taskFirstLoad = false;
    taskTransportOnline = !!((d.transport || {}).connected);
    renderTasks(d.transport || {});
  } catch (e) {
    taskTransportOnline = false;
    renderTasks({connected: false, last_error: String(e)});
    if (manual) document.getElementById("taskSummary").textContent = "读取失败：" + e;
  }
}
function renderTasks(transport) {
    const items = Array.from(taskItems.values())
      .sort((a, b) => Number(b.updated_at || 0) - Number(a.updated_at || 0));
    const waiting = items.filter(x => x.status === "waiting_approval").length;
    document.getElementById("taskSummary").textContent =
      items.length + " 个任务" + (waiting ? " · " + waiting + " 个等待批准" : "");
    const trans = document.getElementById("taskTransport");
    trans.classList.toggle("taskOffline", !taskTransportOnline);
    trans.textContent = taskTransportOnline ? "Codex 实时通道已连接，状态会断线后补回"
      : "连接中断，保留当前状态；恢复后自动补齐" +
        ((transport || {}).last_error ? " · " + transport.last_error : "");
    const box = document.getElementById("tasklist");
    box.innerHTML = "";
    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "taskEmpty";
      empty.textContent = "还没有任务。新建一个后，批准、工具、测试和只读 diff 会出现在这里。";
      box.appendChild(empty);
      return;
    }
    for (const task of items) {
      const card = document.createElement("div");
      card.className = "taskCard " + (task.status === "waiting_approval" ? "approval" :
                                      task.status === "running" ? "running" :
                                      task.status === "failed" ? "failed" : "");
      const top = document.createElement("div");
      top.className = "taskTop";
      const title = document.createElement("div");
      title.className = "taskTitle";
      title.textContent = task.title || "未命名任务";
      const status = document.createElement("span");
      status.className = "taskStatus";
      status.textContent = TASK_STATUS[task.status] || task.status || "未知";
      top.appendChild(title); top.appendChild(status);
      card.appendChild(top);

      const meta = document.createElement("div");
      meta.className = "taskMeta";
      const bits = [];
      if (task.thread_id) bits.push("会话 " + task.thread_id);
      bits.push("更新 " + taskTime(task.updated_at));
      if (task.detail) bits.push(task.detail);
      meta.textContent = bits.join(" · ");
      card.appendChild(meta);

      const approval = task.approval;
      if (approval && approval.decision === "pending") {
        const pre = document.createElement("div");
        pre.className = "taskApproval";
        pre.textContent = "风险 " + (approval.risk || "high") + " · "
          + (approval.target ? "对象 " + approval.target + "\n" : "")
          + (approval.command || "");
        card.appendChild(pre);
        const act = document.createElement("div");
        act.className = "taskActions";
        const yes = document.createElement("button");
        yes.className = "primary"; yes.textContent = "批准";
        yes.onclick = () => taskAction("approve", task.id);
        const no = document.createElement("button");
        no.className = "danger"; no.textContent = "拒绝";
        no.onclick = () => taskAction("reject", task.id);
        act.appendChild(yes); act.appendChild(no);
        card.appendChild(act);
      } else if (task.status === "running") {
        const act = document.createElement("div");
        act.className = "taskActions";
        const queue = document.createElement("button");
        queue.textContent = "排队消息";
        queue.onclick = () => {
          const text = prompt("运行中追加消息");
          if (text && text.trim()) taskAction("message", task.id, {text: text.trim()});
        };
        const stop = document.createElement("button");
        stop.className = "danger"; stop.textContent = "取消任务";
        stop.onclick = () => taskAction("cancel", task.id);
        act.appendChild(queue); act.appendChild(stop);
        card.appendChild(act);
      }

      const messages = Array.isArray(task.messages)
        ? task.messages.filter(x => x && ["queued", "sending", "failed"].includes(x.status)) : [];
      for (let idx = 0; idx < messages.length; idx++) {
        const message = messages[idx];
        const row = document.createElement("div");
        row.className = "taskMessage";
        const text = document.createElement("span");
        const label = message.status === "failed" ? "注入失败：" :
                      message.status === "sending" ? "正在注入：" : "排队：";
        text.textContent = label + (message.text || "");
        const edit = document.createElement("button");
        edit.type = "button"; edit.textContent = "✎"; edit.title = "编辑排队消息";
        edit.onclick = () => {
          const next = prompt("编辑排队消息", message.text || "");
          if (next !== null && next.trim()) {
            taskAction("message_edit", task.id,
              {message_id: message.id, text: next.trim()});
          }
        };
        const cancel = document.createElement("button");
        cancel.type = "button"; cancel.textContent = "×"; cancel.title = "取消排队消息";
        cancel.onclick = () => taskAction("message_cancel", task.id,
          {message_id: message.id});
        row.appendChild(text); row.appendChild(edit); row.appendChild(cancel);
        card.appendChild(row);
      }

      const review = document.createElement("details");
      review.className = "taskReview";
      const tools = Array.isArray(task.tool_calls) ? task.tool_calls.slice(-12) : [];
      const tests = Array.isArray(task.tests) ? task.tests.slice(-8) : [];
      const changes = Array.isArray(task.changes) ? task.changes : [];
      review.open = task.status === "waiting_approval";
      const summary = document.createElement("summary");
      summary.textContent = "运行审查 · " + tools.length + " 工具 · "
        + tests.filter(x => x.ok).length + "/" + tests.length + " 测试 · "
        + changes.length + " 文件" + (task.diff ? " · diff" : "");
      review.appendChild(summary);
      for (const tool of tools) {
        const row = document.createElement("div");
        const failed = tool.status === "failed" ||
          (tool.exit_code !== null && tool.exit_code !== undefined && Number(tool.exit_code) !== 0);
        row.className = "taskTool " + (failed ? "bad" : "ok");
        const bits = [tool.status || "unknown", tool.name || "tool"];
        if (tool.exit_code !== null && tool.exit_code !== undefined)
          bits.push("exit " + tool.exit_code);
        if (tool.duration_ms) bits.push(Math.round(Number(tool.duration_ms)) + "ms");
        row.textContent = bits.join(" · ") + "\n" + (tool.detail || "")
          + (tool.output ? "\n" + tool.output.slice(-1600) : "");
        review.appendChild(row);
      }
      for (const test of tests) {
        const row = document.createElement("div");
        row.className = "taskTool " + (test.ok ? "ok" : "bad");
        row.textContent = (test.ok ? "✓ " : "✗ ") + test.name
          + (test.detail ? "\n" + test.detail : "");
        review.appendChild(row);
      }
      if (changes.length) {
        const row = document.createElement("div");
        row.className = "taskMeta";
        row.textContent = changes.slice(-40).map(x =>
          "· " + (x.path || "") + " · " + (x.status || "modified")).join("\n");
        review.appendChild(row);
      }
      if (task.diff) {
        const pre = document.createElement("pre");
        pre.className = "taskDiff";
        pre.textContent = task.diff;
        review.appendChild(pre);
      }
      card.appendChild(review);
      box.appendChild(card);
    }
}
function syncTaskTimer() {
  if (taskTimer) { clearInterval(taskTimer); taskTimer = null; }
  if (document.getElementById("page-tasks").classList.contains("open")) {
    taskTimer = setInterval(() => pullTasks(false), 4000);
  }
}
