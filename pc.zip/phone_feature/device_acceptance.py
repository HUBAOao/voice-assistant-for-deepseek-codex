# -*- coding: utf-8 -*-
"""Evidence ledger for checks that require a real Android device."""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from pathlib import Path
from typing import Any

CHECKS = {
    "acoustic_echo": {
        "title": "声学回声",
        "detail": "电脑连续朗读时，手机麦克风收不到自己的播报；停播后可正常接收用户新指令。",
    },
    "false_wake": {
        "title": "误唤醒",
        "detail": "电视、音乐或旁人说话连续 10 分钟，不应产生发送、批准或切会话动作。",
    },
    "lock_background": {
        "title": "锁屏与后台",
        "detail": "锁屏并退到后台 10 分钟，通知轮询、断线重连和回前台后的会话状态保持正常。",
    },
    "real_notification": {
        "title": "真实通知",
        "detail": "系统通知可见、带声音或震动；点击通知回到鳍舱，后台服务保持前台状态。",
    },
}
VALID_STATUS = {"pending", "passed", "failed"}
_LOCK = threading.RLock()


def _path() -> Path:
    configured = os.environ.get("FIN_DECK_ACCEPTANCE_FILE", "").strip()
    if configured:
        return Path(configured)
    try:
        import storage_paths

        root = Path(storage_paths.DATA_ROOT)
    except Exception:
        root = Path(__file__).resolve().parent.parent / "数据"
    return root / "设备验收.json"


def _device_key(device_id: str) -> str:
    return hashlib.sha256(str(device_id or "unknown").encode("utf-8")).hexdigest()[:20]


def _load() -> dict[str, Any]:
    try:
        raw = json.loads(_path().read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save(data: dict[str, Any]) -> None:
    path = _path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(
        json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True),
        encoding="utf-8",
    )
    os.replace(tmp, path)


def _rows(record: dict[str, Any]) -> list[dict[str, Any]]:
    checks = record.get("checks") if isinstance(record, dict) else {}
    rows = []
    for key, base in CHECKS.items():
        state = (checks or {}).get(key) or {}
        status = str(state.get("status") or "pending")
        if status not in VALID_STATUS:
            status = "pending"
        rows.append({
            "id": key,
            "title": base["title"],
            "detail": base["detail"],
            "status": status,
            "note": str(state.get("note") or "")[:240],
            "updated_at": int(state.get("updated_at") or 0),
        })
    return rows


def snapshot(*, current_device: str = "") -> dict[str, Any]:
    with _LOCK:
        data = _load()
        key = _device_key(current_device)
        record = (data.get("devices") or {}).get(key, {})
        rows = _rows(record)
        completed = sum(1 for row in rows if row["status"] == "passed")
        failed = sum(1 for row in rows if row["status"] == "failed")
        return {
            "ok": True,
            "device": key if current_device else "",
            "checks": rows,
            "passed": completed,
            "failed": failed,
            "total": len(rows),
            "complete": completed == len(rows) and failed == 0,
            "updated_at": int(record.get("updated_at") or 0),
            "platform": record.get("platform") or {},
            "notice": "这里记录鱼片真机验收结论；界面模拟和代码测试不能代替真机通过。",
        }


def update(*, current_device: str, data: dict[str, Any]) -> dict[str, Any]:
    if data.get("confirm") is not True:
        raise ValueError("记录真机验收结论需要明确确认")
    check_id = str(data.get("id") or "").strip()
    if check_id not in CHECKS:
        raise ValueError("未知验收项")
    status = str(data.get("status") or "").strip().lower()
    if status not in {"passed", "failed", "pending"}:
        raise ValueError("验收状态只能是通过、失败或待验")
    note = str(data.get("note") or "").strip()[:240]
    platform = data.get("platform") if isinstance(data.get("platform"), dict) else {}
    if status != "pending" and not (
        str(platform.get("sdk") or "").strip()
        and str(platform.get("model") or "").strip()
    ):
        raise ValueError("通过或失败结论必须从 Android APK 提交原生设备信息")
    platform = {
        str(key)[:40]: str(value)[:160]
        for key, value in list(platform.items())[:24]
    }
    with _LOCK:
        all_data = _load()
        devices = all_data.setdefault("devices", {})
        key = _device_key(current_device)
        record = devices.setdefault(key, {"checks": {}})
        record.setdefault("checks", {})[check_id] = {
            "status": status,
            "note": note,
            "updated_at": int(time.time()),
        }
        if platform:
            record["platform"] = platform
        record["updated_at"] = int(time.time())
        _save(all_data)
    return snapshot(current_device=current_device)
