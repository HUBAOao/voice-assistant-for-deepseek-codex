# -*- coding: utf-8 -*-
"""HTTP payloads for phone chat-history browsing and archive recovery."""
from __future__ import annotations

from typing import Any

import chat_history


SECURE_POST_PATHS = frozenset({
    "/api/history/clear",
    "/api/history/restore",
})


def _error(exc: Exception) -> dict[str, Any]:
    return {"ok": False, "err": str(exc)[:120]}


def get_route(path: str, query: dict[str, list[str]]) -> tuple[int, dict] | None:
    """Return a JSON response for a history GET, or None when not handled."""
    try:
        if path == "/api/history":
            convs = [x for x in (query.get("convs") or [""])[0].split("\x1f") if x]
            items = chat_history.query(
                keyword=(query.get("q") or [""])[0],
                convs=convs,
                date_from=(query.get("from") or [""])[0],
                date_to=(query.get("to") or [""])[0],
                include_archive=(query.get("archive") or ["1"])[0] != "0",
                limit=int((query.get("limit") or ["5000"])[0]),
            )
            return 200, {"ok": True, "items": items}
        if path == "/api/history/convs":
            return 200, {"ok": True, "items": chat_history.conversations()}
        if path == "/api/history/archives":
            return 200, {"ok": True, "items": chat_history.archive_list()}
    except Exception as exc:  # noqa: BLE001
        return 500, _error(exc)
    return None


def post_route(path: str, body: dict) -> tuple[int, dict] | None:
    """Return a JSON response for a history mutation, or None when not handled."""
    try:
        if path == "/api/history/clear":
            return 200, chat_history.clear_active()
        if path == "/api/history/restore":
            return 200, chat_history.restore_archive(str(body.get("name") or ""))
    except Exception as exc:  # noqa: BLE001
        return 500, _error(exc)
    return None
