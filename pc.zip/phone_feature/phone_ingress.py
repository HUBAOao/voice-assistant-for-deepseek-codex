# -*- coding: utf-8 -*-
"""Thread-safe ingress queues shared by the phone route and voice runtime."""
from __future__ import annotations

import threading
from collections import deque
from collections.abc import Callable
from typing import Any


class PhoneIngressQueue:
    """Own phone commands, media text, images and submit requests.

    The HTTP thread only enqueues work.  The voice runtime drains the same
    queues later, so the two threads never share mutable lists directly.
    One submit flag also prevents repeated ``consume_submit`` calls from
    injecting more than one Enter keystroke.
    """

    def __init__(
        self,
        *,
        lock_factory: Callable[[], Any] = threading.Lock,
    ) -> None:
        self._lock = lock_factory()
        self._commands: deque[tuple[str, str]] = deque()
        self._media: deque[str] = deque()
        self._images: deque[Any] = deque()
        self._submit_requested = False

    def push_command(self, text: str, task_id: str = "") -> None:
        with self._lock:
            self._commands.append((str(task_id or ""), str(text or "")))

    def take_command(self) -> tuple[str, str] | None:
        with self._lock:
            if not self._commands:
                return None
            return self._commands.popleft()

    def push_media(self, text: str) -> bool:
        value = str(text or "").strip()
        if not value:
            return False
        with self._lock:
            self._media.append(value)
        return True

    def take_media(self) -> str:
        with self._lock:
            return self._media.popleft() if self._media else ""

    def push_image(self, path: Any) -> None:
        with self._lock:
            self._images.append(path)

    def take_image(self) -> Any | None:
        with self._lock:
            return self._images.popleft() if self._images else None

    def request_submit(self) -> None:
        with self._lock:
            self._submit_requested = True

    def consume_submit(self) -> bool:
        with self._lock:
            requested = self._submit_requested
            self._submit_requested = False
            return requested

    def counts(self) -> dict[str, int | bool]:
        """Return a side-effect-free snapshot for diagnostics and tests."""
        with self._lock:
            return {
                "commands": len(self._commands),
                "media": len(self._media),
                "images": len(self._images),
                "submit": self._submit_requested,
            }
