# -*- coding: utf-8 -*-
"""集中记忆归档：把「所有对话 + 本地记忆」收成一份可看的文件。

重要：**只在用户明确说「归档」或点「归档」按钮时才生成**，不做定时、不做开机自动。
用户说「查看记忆归档」时只打开上次生成的那份，不会顺手重建。
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import subprocess
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ARCHIVE_MD = HERE / "集中记忆归档.md"
ARCHIVE_JSON = HERE / "集中记忆归档.json"
ARCHIVE_LOG = HERE / "集中记忆归档-记录.jsonl"

CODEX_DB = Path.home() / ".codex" / "thread_history_1.sqlite"
STATE_DB = Path.home() / ".codex" / "state_5.sqlite"

MAX_MSG_CHARS = 6000
MAX_LOG_LINES = 500


def _ts_text(ms: int | float | None) -> str:
    try:
        return datetime.fromtimestamp(float(ms) / 1000).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _read_text(path: Path, limit: int = 0) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""
    if limit > 0:
        lines = text.splitlines()
        if len(lines) > limit:
            text = "\n".join(lines[-limit:])
    return text.strip()


def _redact(text: str, secrets: list[str] | None = None) -> str:
    text = str(text or "")
    for secret in secrets or []:
        if secret and len(secret) >= 8:
            text = text.replace(secret, "***")
    text = re.sub(r"(?i)\b(token|key|secret|password)\s*[=:]\s*[^\s,;，。]{8,}",
                  r"\1=***", text)
    text = re.sub(r"[?&]k=[A-Za-z0-9_-]{16,}", "?k=***", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]{16,}", "sk-***", text)
    return text


def _known_secrets(base_dir: Path) -> list[str]:
    out = []
    try:
        token = (base_dir / "phone-token.txt").read_text(encoding="utf-8").strip()
        if token:
            out.append(token)
    except Exception:
        pass
    return out


def _thread_titles(state_db: Path) -> dict[str, dict]:
    if not state_db.is_file():
        return {}
    try:
        con = sqlite3.connect("file:" + state_db.as_posix() + "?mode=ro",
                              uri=True, timeout=3.0)
        try:
            rows = con.execute(
                "select id, title, created_at, updated_at, cwd from threads").fetchall()
        finally:
            con.close()
    except Exception:
        return {}
    out = {}
    for tid, title, created, updated, cwd in rows:
        clean_title = re.sub(r"\s+", " ", str(title or "")).strip()
        if len(clean_title) > 80:
            clean_title = clean_title[:80] + "…"
        out[str(tid)] = {
            "title": clean_title,
            "created_at": int(created or 0) * 1000,
            "updated_at": int(updated or 0) * 1000,
            "cwd": str(cwd or "").replace("\\\\?\\", ""),
        }
    return out


def _conversations(thread_db: Path, state_db: Path,
                   secrets: list[str]) -> list[dict]:
    if not thread_db.is_file():
        return []
    try:
        con = sqlite3.connect("file:" + thread_db.as_posix() + "?mode=ro",
                              uri=True, timeout=5.0)
        try:
            rows = con.execute(
                "select thread_id, item_type, created_at_ms, item_json "
                "from thread_items where item_type in ('userMessage','agentMessage') "
                "order by created_at_ms asc").fetchall()
        finally:
            con.close()
    except Exception:
        return []

    titles = _thread_titles(state_db)
    by_thread: dict[str, dict] = {}
    for tid, kind, ts, raw in rows:
        tid = str(tid)
        try:
            item = json.loads(raw)
        except Exception:
            continue
        if kind == "userMessage":
            parts = item.get("content") or []
            text = "".join(str(p.get("text") or "") for p in parts
                           if isinstance(p, dict))
            role = "你"
        else:
            phase = str(item.get("phase") or "")
            if phase and phase != "final_answer":
                continue                      # 过程话不放进记忆正文
            text = str(item.get("text") or "")
            role = "我"
        text = _redact(text, secrets).strip()
        if not text:
            continue
        row = by_thread.setdefault(tid, {
            "id": tid, "title": "", "created_at": 0, "updated_at": 0,
            "cwd": "", "messages": [],
        })
        row["messages"].append({"ts": int(ts or 0), "role": role, "text": text})
        row["created_at"] = row["created_at"] or int(ts or 0)
        row["updated_at"] = int(ts or 0)

    for tid, row in by_thread.items():
        meta = titles.get(tid, {})
        row["title"] = meta.get("title") or ""
        row["cwd"] = meta.get("cwd") or ""
        if not row["title"] and row["messages"]:
            first = next((m["text"] for m in row["messages"] if m["role"] == "你"), "")
            row["title"] = re.sub(r"\s+", " ", first)[:42] or "未命名会话"
        row["messages"] = [{
            **m,
            "text": (m["text"][:MAX_MSG_CHARS] + "\n…（已截断）"
                     if len(m["text"]) > MAX_MSG_CHARS else m["text"]),
        } for m in row["messages"]]

    return sorted(by_thread.values(), key=lambda r: r["updated_at"], reverse=True)


def _local_memory(base_dir: Path, secrets: list[str]) -> dict:
    cfg = _read_json(base_dir / "config.json", {})
    facts = _read_json(base_dir / "memory.json", [])
    ledger = _read_json(base_dir / "ledger.json", [])
    achievements = _read_json(base_dir / "achievements.json", {})
    return {
        "facts": [f for f in facts if isinstance(f, dict)],
        "notes": _read_text(base_dir / "notes.md"),
        "ledger": [r for r in ledger if isinstance(r, dict)],
        "schedules": cfg.get("schedules") if isinstance(cfg.get("schedules"), list) else [],
        "diary": _read_text(base_dir / "diary.md"),
        "achievements": achievements if isinstance(achievements, dict) else {},
        "transcripts": _redact(_read_text(base_dir / "transcripts.md",
                                          MAX_LOG_LINES), secrets),
        "said": _redact(_read_text(base_dir / "said.md", MAX_LOG_LINES), secrets),
        "syslog": _redact(_read_text(base_dir / "syslog.md", MAX_LOG_LINES), secrets),
    }


def _markdown(info: dict) -> str:
    local = info["local"]
    stats = info["stats"]
    lines = [
        "# 集中记忆归档",
        "",
        f"> 生成时间：{info['generated_at']}",
        "> 这份文件是**手动触发**生成的；不会自动更新，也不会自动读取。",
        f"> 覆盖：{stats['threads']} 个会话 / {stats['user_messages']} 条你说的话 / "
        f"{stats['answers']} 条回答；{stats.get('first_date') or '—'} ~ "
        f"{stats.get('last_date') or '—'}",
        "",
        "## 一、事实记忆",
        "",
    ]
    facts = local["facts"]
    if facts:
        for row in facts:
            date = row.get("date") or _ts_text(float(row.get("ts") or 0) * 1000)
            lines.append(f"- {date}：{row.get('text', '')}")
    else:
        lines.append("（还没有「记住」过什么事）")

    lines += ["", "## 二、便签", "", local["notes"] or "（空）", ""]

    lines += ["## 三、记账", ""]
    if local["ledger"]:
        for row in local["ledger"]:
            lines.append(f"- {row.get('date', '')} {row.get('item') or row.get('note') or ''}"
                         f"：{row.get('amount', '')} 元")
    else:
        lines.append("（还没有记过账）")

    lines += ["", "## 四、日程与提醒", ""]
    if local["schedules"]:
        for row in local["schedules"]:
            lines.append(f"- {json.dumps(row, ensure_ascii=False)}")
    else:
        lines.append("（没有设置日程）")

    lines += ["", "## 五、日记", "", local["diary"] or "（空）", ""]

    ach = local["achievements"]
    days = ach.get("days") if isinstance(ach.get("days"), list) else []
    lines += ["## 六、使用记录", ""]
    lines.append(f"- 用过 {len(days)} 天；成就数据："
                 f"{json.dumps(ach, ensure_ascii=False)[:800] or '（空）'}")
    lines += ["", "### 你最近说过的（语音输入，最近 500 条）", "",
              local["transcripts"] or "（空）", "",
              "### 它最近念过的（最近 500 条）", "",
              local["said"] or "（空）", ""]

    lines += ["## 七、全部对话", ""]
    if not info["conversations"]:
        lines.append("（没有读到 Codex 会话库）")
    for idx, conv in enumerate(info["conversations"], 1):
        lines += [
            f"### {idx}. {conv['title'] or '未命名会话'}",
            "",
            f"- 会话 ID：`{conv['id']}`",
            f"- 时间：{_ts_text(conv['created_at'])} ~ {_ts_text(conv['updated_at'])}",
        ]
        if conv.get("cwd"):
            lines.append(f"- 项目：`{conv['cwd']}`")
        lines.append("")
        for msg in conv["messages"]:
            lines += [f"**{msg['role']}**（{_ts_text(msg['ts'])}）：", "",
                      msg["text"], ""]

    lines += [
        "---",
        "",
        "说明：以后说「集中记忆归档」会重新生成并覆盖这份文件；"
        "说「查看记忆归档」只打开它，不会重新生成。",
        "",
    ]
    return "\n".join(lines)


def build_archive(base_dir: Path | None = None,
                  thread_db: Path | None = None,
                  state_db: Path | None = None) -> dict:
    """生成一份新的集中记忆归档。只有明确调用时才会写文件。"""
    base = Path(base_dir or HERE)
    thread_db = Path(thread_db or CODEX_DB)
    state_db = Path(state_db or STATE_DB)
    secrets = _known_secrets(base)
    conversations = _conversations(thread_db, state_db, secrets)
    local = _local_memory(base, secrets)

    all_ms = [msg["ts"] for conv in conversations for msg in conv["messages"]]
    stats = {
        "threads": len(conversations),
        "user_messages": sum(1 for c in conversations for m in c["messages"]
                             if m["role"] == "你"),
        "answers": sum(1 for c in conversations for m in c["messages"]
                       if m["role"] == "我"),
        "first_date": _ts_text(min(all_ms))[:10] if all_ms else "",
        "last_date": _ts_text(max(all_ms))[:10] if all_ms else "",
        "facts": len(local["facts"]),
        "notes_chars": len(local["notes"]),
        "ledger_rows": len(local["ledger"]),
        "schedule_rows": len(local["schedules"]),
    }
    info = {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "generated_ts": time.time(),
        "stats": stats,
        "conversations": conversations,
        "local": local,
    }

    md_path = base / ARCHIVE_MD.name
    json_path = base / ARCHIVE_JSON.name
    md = _markdown(info)
    md_path.write_text(md, encoding="utf-8-sig")
    json_path.write_text(json.dumps(info, ensure_ascii=False, indent=2),
                         encoding="utf-8")
    try:
        with (base / ARCHIVE_LOG.name).open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({
                "at": info["generated_at"],
                "stats": stats,
                "md_bytes": md_path.stat().st_size,
                "json_bytes": json_path.stat().st_size,
            }, ensure_ascii=False) + "\n")
    except Exception:
        pass
    info["md_path"] = str(md_path)
    info["json_path"] = str(json_path)
    info["md_bytes"] = md_path.stat().st_size
    return info


def summary(base_dir: Path | None = None) -> dict | None:
    base = Path(base_dir or HERE)
    data = _read_json(base / ARCHIVE_JSON.name, None)
    return data if isinstance(data, dict) else None


def describe(info: dict | None = None) -> str:
    info = info or summary()
    if not info:
        return "还没有归档过。说「集中记忆归档」，我才会开始归档。"
    s = info.get("stats") or {}
    return (f"归档好了：{s.get('threads', 0)} 个会话，"
            f"{s.get('user_messages', 0)} 条你说的话，"
            f"{s.get('answers', 0)} 条回答。设置里点「查看」就能看。")


def open_archive(base_dir: Path | None = None) -> tuple[bool, str]:
    """打开上次生成的归档；不会顺手重新生成。"""
    base = Path(base_dir or HERE)
    path = base / ARCHIVE_MD.name
    if not path.is_file():
        return False, "还没有归档，先说「集中记忆归档」，我才会生成。"
    try:
        subprocess.Popen(["notepad.exe", str(path)])
        return True, "记忆归档已经打开了。"
    except Exception:
        try:
            os.startfile(str(path))
            return True, "记忆归档已经打开了。"
        except Exception as exc:            # noqa: BLE001
            return False, f"归档文件打不开：{exc}"


def parse_command(text: str) -> str | None:
    """识别「归档」/「查看」两种指令；没提到记忆归档就返回 None。"""
    s = re.sub(r"\s+", "", str(text or ""))
    if not s:
        return None
    memory_words = ("记忆", "对话", "聊天记录")
    archive_words = ("归档", "档案", "集中记忆", "记忆汇总", "记忆整理",
                     "整理", "汇总", "收拢", "打包")
    if not any(w in s for w in memory_words):
        return None
    if not any(w in s for w in archive_words):
        return None
    if any(w in s for w in ("查看", "打开", "看看", "看一眼", "调出", "显示")):
        return "view"
    if any(w in s for w in ("归档", "整理", "汇总", "收拢", "集中", "打包")):
        return "build"
    return None
