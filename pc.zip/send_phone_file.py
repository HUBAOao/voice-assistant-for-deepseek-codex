#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Publish one desktop file as a WeChat-style chat message for the phone."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import chat_file_inbox
import file_share


def main() -> int:
    parser = argparse.ArgumentParser(
        description="把电脑文件发到手机聊天气泡，手机可从气泡里下载。"
    )
    parser.add_argument("file", help="电脑上的文件路径")
    parser.add_argument("--name", default="", help="手机里显示的文件名")
    parser.add_argument("--conversation", default="", help="目标会话名")
    args = parser.parse_args()

    source = Path(args.file).expanduser()
    if not source.is_file():
        print(f"找不到文件：{source}", file=sys.stderr)
        return 2
    shared = file_share.add_file(source, args.name)
    if shared is None:
        print("复制到手机分享目录失败", file=sys.stderr)
        return 3
    event = chat_file_inbox.publish_file(shared, args.conversation)
    print(json.dumps(event, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
