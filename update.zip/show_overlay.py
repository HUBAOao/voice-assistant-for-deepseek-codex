#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一键叫出悬浮窗（桌面快捷方式就是调它）。

三种情况自动处理：
  悬浮窗已经在显示          -> 把它提到最前面，别的什么都不做
  语音程序在跑、浮窗被关了   -> 只把浮窗拉回来
  语音程序也没在跑          -> 先把语音程序启动起来（它会带着浮窗）
"""

from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

HERE = Path(__file__).resolve().parent
STATUS = HERE / "status.json"
MUTEX_NAME = "VoiceAssistantOverlay_v1"
VOICE_MUTEX = "VoiceAssistantVoice_v1"
OVERLAY_TITLE = "语音助手"


def log(text: str) -> None:
    """没有控制台也不至于啥都看不见：同时写进 tiny 日志。"""
    try:
        (HERE / "show-overlay.log").write_text(text + "\n", encoding="utf-8")
    except Exception:
        pass
    if sys.stdout is not None:
        try:
            print(text)
        except Exception:
            pass


def overlay_running() -> bool:
    """用 OpenMutex 检查（只打开不创建，免得自己把互斥体占住）。"""
    SYNCHRONIZE = 0x00100000
    k = ctypes.windll.kernel32
    handle = k.OpenMutexW(SYNCHRONIZE, False, MUTEX_NAME)
    if handle:
        k.CloseHandle(handle)
        return True
    return False


def named_mutex_exists(name: str) -> bool:
    SYNCHRONIZE = 0x00100000
    k = ctypes.windll.kernel32
    handle = k.OpenMutexW(SYNCHRONIZE, False, name)
    if handle:
        k.CloseHandle(handle)
        return True
    return False


def pid_alive(pid: int) -> bool:
    if not pid:
        return False
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    k = ctypes.windll.kernel32
    handle = k.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return False
    k.CloseHandle(handle)
    return True


def voice_pid() -> int:
    """语音程序在不在：先看互斥体（最可靠），再看状态文件里的进程号。"""
    if named_mutex_exists(VOICE_MUTEX):
        return -1
    try:
        data = json.loads(STATUS.read_text(encoding="utf-8"))
        pid = int(data.get("pid") or 0)
    except Exception:
        return 0
    return pid if pid_alive(pid) else 0


def find_overlay_window() -> int:
    u = ctypes.windll.user32
    found = 0
    # 浮窗的标题是"你给它起的名字"（默认大肥鱼），不是固定叫"语音助手"，
    # 所以这里要把配置里的名字也认上，不然改名之后"叫它出来"就找不到窗口了。
    names = {OVERLAY_TITLE, "大肥鱼"}
    try:
        cfg = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
        name = str(cfg.get("name") or "").strip()
        if name:
            names.add(name)
    except Exception:
        pass
    EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _lparam):
        nonlocal found
        buf = ctypes.create_unicode_buffer(256)
        u.GetWindowTextW(hwnd, buf, 256)
        if buf.value in names and buf.value != "在听":
            found = hwnd
            return False
        return True

    u.EnumWindows(EnumProc(cb), None)
    return found


def raise_overlay() -> None:
    hwnd = find_overlay_window()
    if not hwnd:
        return
    u = ctypes.windll.user32
    u.ShowWindow(hwnd, 9)          # SW_RESTORE
    u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010)  # HWND_TOPMOST, NOSIZE|NOMOVE|NOACTIVATE


def pythonw() -> Path:
    candidate = Path(sys.executable).with_name("pythonw.exe")
    return candidate if candidate.exists() else Path(sys.executable)


def main() -> int:
    if overlay_running():
        raise_overlay()
        log("悬浮窗已经在显示了，已把它提到最前面。")
        return 0

    if voice_pid():
        subprocess.Popen([str(pythonw()), str(HERE / "overlay.py")], cwd=str(HERE))
        log("语音程序在跑，已把悬浮窗拉回来。")
        return 0

    script = HERE / "talk.cmd"
    if not script.exists():
        script = HERE / "start.cmd"
    log(f"语音程序没在跑，正在启动（无窗口）：{script.name} 的对话模式")
    # 用 pythonw 直接跑 stt.py：不再弹黑色控制台，界面上只有悬浮窗
    subprocess.Popen(
        [str(pythonw()), str(HERE / "stt.py"), "--mode", "talk"],
        cwd=str(HERE),
    )
    time.sleep(1.0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
