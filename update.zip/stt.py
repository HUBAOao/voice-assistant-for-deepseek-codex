#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
语音转文字（本地离线，faster-whisper）

麦克风说话 -> 本地识别 -> 打印 + 自动复制到剪贴板 + 追加写入 transcripts.md

用法示例：
    python stt.py                  # 按住 * 说话，松开就识别（默认）
    python stt.py --key f9         # 换成按住 F9 说话
    python stt.py --mode auto      # 不用按键：直接说话，停顿后自动识别
    python stt.py --ptt            # 回车开始录音，再回车结束
    python stt.py --once           # 只识别一句就退出
    python stt.py --list-devices   # 查看麦克风设备
    python stt.py --input USB      # 用名字包含 USB 的麦克风
    python stt.py --model large-v3 # 换更大的模型（更准、更慢）
"""

from __future__ import annotations

import atexit
import collections
import ctypes
import importlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
import random
from datetime import datetime
from pathlib import Path

import numpy as np
import sounddevice as sd

import wake_levels
import phone_link
from voice_feature.desktop_runtime_assembly import (
    DesktopRuntimeDependencies,
    assemble_desktop_runtime,
)
from voice_feature.runtime_service_assembly import (
    RuntimeServiceDependencies,
    assemble_runtime_services,
)
from voice_feature.runtime_main_foreground import (
    ForegroundPlatformDependencies,
    PreparedForegroundDependencies,
    run_prepared_foreground,
)
import version                      # 署名 / 版权 / 版本号都从这儿来（手机设置里那一栏也要用）
import remote_access                # 外网访问（Tailscale）状态：手机设置里要显示
import screen_share
import file_share
import memory_archive
import chat_history
from features.duplex import DUPLEX, likely_echo
from features.voice_echo import cancel as cancel_reference_echo
from voice_feature.audio_io import (
    open_stream as _audio_open_stream,
    resample_to_16k as _audio_resample_to_16k,
    rms as _audio_rms,
)
from voice_feature.capture import Recorder as _CaptureRecorder
from voice_feature.runtime_support import (
    append_log as _append_log,
    build_test_summary,
    record_ptt as _record_ptt,
    wait_for_enter,
)
from voice_feature.transcriber import Transcriber as _FeatureTranscriber
from voice_feature import personal_commands as _personal
from voice_feature import talk_state as _talk
from voice_feature.audio_capture import (
    has_utterance,
    not_heard_due,
)
from voice_feature.cli_options import build_argument_parser
from voice_feature.mute_commands import dispatch_mute_command, mute_command
from voice_feature.instance_guard import SingleInstanceGuard
from voice_feature.runtime_lifecycle import RuntimeLifecycle
from voice_feature.runtime_audio_setup import (
    AudioRuntimeDependencies,
)
from voice_feature.runtime_startup import apply_low_profile, start_enabled_plugins
from voice_feature.runtime_bootstrap import (
    RuntimeBootstrapDependencies,
)
from voice_feature.runtime_cli_modes import (
    RuntimeCliModeDependencies,
)
from voice_feature.runtime_entry_pipeline import (
    RuntimeEntryDependencies,
    prepare_runtime_entry,
)
from voice_feature.runtime_config_assembly import (
    ConfigRuntime,
    ConfigRuntimeDependencies,
)
from voice_feature.runtime_gate_wiring import (
    RuntimeGateWiringDependencies,
    assemble_runtime_gate_wiring,
)
from voice_feature.runtime_reminder_assembly import (
    ReminderRuntimeDependencies,
    assemble_reminder_runtime,
)
from voice_feature.runtime_session_state import create_runtime_session_state
from voice_feature.runtime_startup_callbacks import (
    DesktopCallbackDependencies,
    DesktopRuntimeCallbacks,
    SavedRuntimeTargets,
)
from voice_feature.runtime_utterance_assembly import (
    RuntimeUtteranceDependencies,
    assemble_utterance_runtime,
)
from voice_feature.runtime_utterance_dispatch import UtteranceDispatch
from voice_feature.runtime_workers import (
    ForegroundTrackerWorker,
    HeartbeatWorker,
)
from voice_feature.send_verification import verify_sent_delivery

HERE = Path(__file__).resolve().parent
TARGET_SR = 16000
STATUS_FILE = HERE / "status.json"
CONTROL_FILE = HERE / "control.json"
CONFIG_FILE = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"     # 唤醒词自检结果，写出来给悬浮窗显示
SPEAK_STATUS_FILE = HERE / "speak.json"
SPEAK_STOP_FILE = HERE / "speak_stop.json"   # 写一下就＝让正在念的那句立刻闭嘴
ACHV_FILE = HERE / "achievements.json"
DIARY_FILE = HERE / "diary.md"
SAID_FILE = HERE / "said.md"                 # 只记"真的说给它听"的句子（给日记用）
SYSLOG_FILE = HERE / "syslog.md"

# 「电脑在忙吗」：把你那句话发给 Codex 的那一刻置 True，回答念完置 False。
# 手机上那条「正在思考…」就看它（比只看回复读取器稳，不会时有时无）。
BUSY = {"on": False, "at": 0.0}             # 系统日志：说过什么、它做了什么，全记

# 「静音」：按一下它**立刻闭嘴**，但照样听得见你说话（语音输入不受影响）；再按一下才恢复出声。
# 跟"暂停"（连听都停）不是一回事 —— 用户要的就是"我不听你说，但你能听我说"。
MUTE = {"on": False}

# 手机入口正在处理一条命令时，电脑这边不要出声（提示语、应答语、回答都不念）。
# 用线程局部变量：电脑自己的语音命令照常说话，只有手机这条工作线程静音。
_SPEAK_CTX = threading.local()

# 发送校验发现"没进去"时把这句话记下来，用户说「重发一遍」就再发它
LAST_UNSENT = {"text": "", "at": 0.0}
NOTES_FILE = HERE / "notes.md"               # 便签
LEDGER_FILE = HERE / "ledger.json"           # 记账本
MANUAL_EXIT = HERE / "manual-exit.json"      # 你自己点的"退出"：看门狗看到它就不重启
HEARTBEAT = HERE / "heartbeat.json"          # 心跳：不管我在忙什么，每 5 秒写一次
OVERLAY_READY = HERE / "overlay_ready.json"  # 悬浮窗"我把窗口显示出来了"的回执
REPLY_READER = None                          # 「自动念回答」的后台线程（见 reply_reader.py）
VOICE_MUTEX = "VoiceAssistantVoice_v1"
_instance_guard: SingleInstanceGuard | None = None
_heartbeat_lifecycle: RuntimeLifecycle | None = None
_ASR_LOCK = threading.Lock()   # 自检和正常识别可能同时想用模型，串起来
# 开会自动闭嘴：为真时 speak() 只写字幕不出声
_MUTE_SPEAK = {"on": False}
# 它最近念过的话。判断"这句是不是它自己在说"要用——念完之后 speak.json 里的字就没了，
# 光靠那个文件会漏判（漏判的后果是它把自己的问候当指令发出去）
_SPOKEN: list[tuple[float, str]] = []

# ---------------------------------------------------------------- 隐私
# 说到这些词，那一行就不记原文（或者干脆不记）
PRIVACY_WORDS = ("密码", "口令", "验证码", "身份证", "银行卡", "信用卡", "手机号",
                 "账号", "密钥", "token", "api key", "private key", "社保", "护照")
PRIVATE = {"until": 0.0, "clear_ask": False}   # "别记这段" 的临时静默期；清空确认

from voice_feature.parsing import (
    DEFAULT_STOP_WORDS,
    _BRIEF_WORDS,
    _CN_NUM,
    _FOCUS_TIME,
    _GAME_START,
    _GAME_STOP,
    _LEDGER_HEADS,
    _MATH_WORDS,
    _NOTE_HEADS,
    _OPEN_VERBS,
    _QUERY_LEDGER,
    _QUERY_NOTE,
    _REMIND_PATTERNS,
    _SEARCH_HEADS,
    _TRANSFORM_WORDS,
    _UNIT_FAMILY,
    _UNIT_SCALE,
    _UNITS,
    _VK_MEDIA,
    _VK_VOLUME,
    _VOICE_OPEN_ENABLED,
    _safe_eval,
    apply_corrections,
    cn_number,
    is_standalone_command,
    is_stop_word,
    parse_brief,
    parse_calc,
    parse_convert,
    parse_correction,
    parse_focus,
    parse_game,
    parse_ledger,
    parse_media,
    parse_note,
    parse_open,
    parse_reminder,
    repeated_after_miss,
    parse_search,
    parse_transform,
)
def privacy_until() -> bool:
    return time.time() < PRIVATE["until"]


def privacy_clean(text: str) -> str:
    """落盘前过一道隐私：静默期整句不记；敏感词那句打码。"""
    if privacy_until():
        return "（这几分钟按你说的不记录）"
    low = (text or "").lower()
    if any(w in low for w in PRIVACY_WORDS):
        return "（这行含敏感词，已隐去）"
    return text


def privacy_note(text: str) -> bool:
    """这句要不要因为隐私不打码地记？（给调用方判断用）"""
    return not privacy_until() and not any(
        w in (text or "").lower() for w in PRIVACY_WORDS)


def remember_spoken(text: str) -> None:
    text = (text or "").strip()
    if not text:
        return
    _SPOKEN.append((time.time(), text))
    del _SPOKEN[:-6]


def recent_spoken(window: float = 20.0) -> list[str]:
    now = time.time()
    return [t for ts, t in _SPOKEN if now - ts <= window]


def show_instead_of_speaking(text: str) -> None:
    """开会模式下不出声，但要把这句话放到字幕位（status.json 的 text 字段）。"""
    try:
        data = json.loads(STATUS_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    data.update({"text": text[:80], "ts": time.time()})
    try:
        tmp = STATUS_FILE.with_name("status.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(STATUS_FILE)
    except Exception:
        pass


def syslog(tag: str, text: str) -> None:
    """系统日志：你说过什么、它发了什么、念了什么、做了什么动作，全记一行。

    文件太大就砍掉前面一半，免得无限长大。
    """
    text = privacy_clean(text)
    line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {text}\n"
    try:
        with SYSLOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line)
        if SYSLOG_FILE.stat().st_size > 2_000_000:
            keep = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
            SYSLOG_FILE.write_text("\n".join(keep[-4000:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def syslog_search(keywords: list[str], limit: int = 5) -> list[str]:
    """在系统日志里找同时包含这些词的行（最近的优先）。"""
    words = [w for w in (keywords or []) if w]
    if not words:
        return []
    try:
        lines = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    hits = [ln for ln in lines if all(w in ln for w in words)]
    return hits[-limit:][::-1]


def acquire_single_instance(name: str = VOICE_MUTEX) -> bool:
    """同一时间只允许一个语音程序：两个一起跑会重复发送、抢状态文件。"""
    global _instance_guard
    _instance_guard = SingleInstanceGuard(
        name=name,
        lock_path=HERE / "instance.lock",
    )
    return _instance_guard.acquire()


class Status:
    """把当前状态写给悬浮窗看（原子替换，避免读到半个文件）。"""

    def __init__(self, hint: str = "") -> None:
        self.hint = hint
        self.pid = os.getpid()
        self._last_level = 0.0
        self.state = "starting"
        self.mood = ""            # 语气：急 / 平常 / 轻（悬浮窗拿它调颜色和形态）
        self.mood_ts = 0.0        # 语气是什么时候判出来的（悬浮窗过一会儿就不认了）
        self.bands: list = []     # 音浪柱子高度（0~1），开启音浪模式时才有
        self.focus = 0.0          # 番茄钟还剩多少秒（0 = 没在专注）
        self._last: dict = {}

    def set(self, state: str, text: str | None = None, hint: str | None = None,
            level: float = 0.0, mood: str | None = None,
            focus: float | None = None) -> None:
        self.state = state
        if mood is not None:
            self.mood = mood
            self.mood_ts = time.time()
        if focus is not None:
            self.focus = focus
        data = {
            "state": state,
            "text": text or "",
            "hint": hint if hint is not None else self.hint,
            "level": round(min(1.0, max(0.0, level)), 3),
            "mood": self.mood,
            "mood_ts": round(self.mood_ts, 2),
            "bands": self.bands,
            "focus": round(max(0.0, self.focus), 1),
            "ts": time.time(),
            "pid": self.pid,
        }
        self._write(data)

    def patch(self, **fields) -> None:
        """只改几个字段（比如番茄钟倒计时），别动状态和字幕。"""
        data = dict(getattr(self, "_last", {}) or {})
        if not data:
            return
        if "focus" in fields:
            self.focus = float(fields["focus"])
        data.update({k: v for k, v in fields.items()})
        data["ts"] = time.time()
        self._write(data)

    def set_mood(self, mood: str) -> None:
        """语气只在"真听懂了"的时候才盖章；空字符串表示恢复平常。"""
        self.mood = mood or ""
        self.mood_ts = time.time() if mood else 0.0
        self.patch(mood=self.mood, mood_ts=round(self.mood_ts, 2))

    def _write(self, data: dict) -> None:
        self._last = dict(data)
        try:
            tmp = STATUS_FILE.with_name("status.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            for attempt in range(3):
                # 悬浮窗可能正开着这个文件读，Windows 下替换会偶发失败，重试一下
                try:
                    tmp.replace(STATUS_FILE)
                    break
                except OSError:
                    if attempt == 2:
                        raise
                    time.sleep(0.02)
        except Exception:
            pass

    def level(self, level: float, state: str = "hearing", text: str = "",
              bands: list | None = None) -> bool:
        """录音过程中高频更新音量（给悬浮窗做跳动效果），限流到 ~7 次/秒。"""
        now = time.time()
        if now - self._last_level < 0.15:
            return False
        self._last_level = now
        if bands is not None:
            self.bands = bands
        self.set(state, text=text, level=level)
        return True


class RemoteControl:
    """读悬浮窗按钮写下的命令（暂停 / 继续）。

    悬浮窗是独立进程，直接调函数不行，所以用一个小文件当"信箱"：
    浮窗写 control.json，这边每 0.25 秒看一眼，时间戳比上次新就执行。
    """

    def __init__(self, on_action) -> None:
        self.on_action = on_action
        # 记住"我启动之前"最后一条命令的时间戳：旧命令不能拿来执行，
        # 否则上一轮点过的暂停会让新启动的程序一上来就停着。
        try:
            self.last_ts = float(json.loads(CONTROL_FILE.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            self.last_ts = 0.0
        self.next_check = 0.0
        self._apply(action=None)

    def _apply(self, action: str | None) -> None:
        if action:
            self.on_action(action)

    def poll(self) -> None:
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.25
        try:
            data = json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= self.last_ts:
            return
        self.last_ts = ts
        self._apply(str(data.get("action") or ""))


def start_heartbeat(lifecycle: RuntimeLifecycle | None = None) -> None:
    """独立心跳线程：不管主循环在忙什么（录长句、训练唤醒词），每 5 秒写一次。

    看门狗原来靠"status.json 新不新"判断死没死，结果主循环一忙 40 秒就被误判成
    挂了、多拉一个进程起来（虽然被单实例锁挡住，但日志会吓人）。
    """
    global _heartbeat_lifecycle
    lifecycle = lifecycle or _heartbeat_lifecycle or RuntimeLifecycle()
    _heartbeat_lifecycle = lifecycle
    HeartbeatWorker(HEARTBEAT).start(lifecycle)


def start_overlay() -> subprocess.Popen | None:
    """把悬浮窗拉起来（用 pythonw，不闪黑框）。

    起来之后要等它写一张"我已经把窗口显示出来了"的回执（overlay_ready.json）。
    为什么要这么麻烦：pythonw 没有控制台，悬浮窗要是崩了、卡住了、或者窗口建出来
    但是透明的（看不见），主程序这边完全不知道 —— 用户就看到"有语音、没悬浮窗"。
    现在超过 6 秒没回执就重来一次，还不行就说出原因，让用户知道自己该怎么办。
    """
    script = HERE / "overlay.py"
    if not script.exists():
        return None
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
    detail = ""
    for attempt in (1, 2):
        started = time.time()
        # 把悬浮窗的报错接到日志上：它要是"模块级导入"就炸了（比如缺 Pillow），
        # 根本没走到自己的错误处理，什么都留不下 —— 用户那边就是"没悬浮窗也没报错"。
        err_fh = None
        try:
            err_fh = open(HERE / "overlay-error.log", "a", encoding="utf-8",
                          errors="replace")
            err_fh.write(f"\n=== 启动悬浮窗 {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            err_fh.flush()
        except Exception:
            err_fh = None
        try:
            proc = subprocess.Popen([str(runner), str(script)], cwd=str(HERE),
                                    creationflags=flags, stderr=err_fh)
        except Exception as exc:  # noqa: BLE001
            print(f"（悬浮窗没起来：{exc}）")
            return None
        detail = wait_overlay_ready(started, 20.0 if attempt == 1 else 25.0, proc)
        if err_fh is not None:
            try:
                err_fh.close()
            except Exception:
                pass
        if not detail:
            return proc
        detail = overlay_failure_reason(detail)
        print(f"（悬浮窗第 {attempt} 次没起来：{detail}）")
        try:
            proc.kill()
        except Exception:
            pass
        time.sleep(0.6)
    # 两次都不行：语音还能用，但要让你知道，而且告诉你日志在哪
    try:
        if any(k in detail for k in ("No module named", "ImportError", "DLL load failed")):
            # 最常见的就是这个：新装的机器缺运行库（Pillow / pystray）
            speak("缺一个运行库，双击程序目录里的「修复依赖」就能装好，语音还能用")
        else:
            speak("悬浮窗起不来，语音还能用。日志在程序目录，文件名是 overlay-error 点 log")
    except Exception:
        pass
    syslog("浮", f"悬浮窗起不来：{detail}")
    print("   （如果是缺运行库：双击程序目录里的「修复依赖.cmd」就能补上）", flush=True)
    return None


def wait_overlay_ready(started: float, timeout: float = 12.0, proc=None) -> str:
    """等悬浮窗的"准备好了"回执。成功返回空串，否则返回一句原因。

    顺便盯着进程：它要是刚起来就退了（比如缺 Pillow 这种导入错误），
    立刻就能说出"起后就退了"，不用白等十几秒。
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc is not None and proc.poll() is not None:
            time.sleep(0.4)          # 让它把 stderr 写完
            return f"它起来后就退了（退出码 {proc.returncode}）"
        try:
            data = json.loads(OVERLAY_READY.read_text(encoding="utf-8"))
            if float(data.get("ts") or 0) >= started:
                if not data.get("visible", True):
                    return "窗口建出来了，但是没显示（可能在屏幕外面）"
                return ""
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.25)
    return f"{timeout:.0f} 秒之内没把窗口显示出来"


def overlay_failure_reason(fallback: str) -> str:
    """能读到崩溃日志就用日志里最后一句，读不到就用兜底说法。"""
    log = HERE / "overlay-error.log"
    try:
        lines = [ln for ln in log.read_text(encoding="utf-8", errors="replace").splitlines()
                 if ln.strip()]
        if lines:
            return lines[-1].strip()[:200]
    except Exception:  # noqa: BLE001
        pass
    exit_log = HERE / "overlay-exit.log"
    try:
        lines = [ln for ln in exit_log.read_text(encoding="utf-8", errors="replace").splitlines()
                 if ln.strip()]
        if lines:
            return lines[-1].strip()[:200]
    except Exception:  # noqa: BLE001
        pass
    return fallback


def start_pet() -> subprocess.Popen | None:
    """把桌宠拉起来（素材不在就跳过）。"""
    # 优先用新的大肥鱼 Live2D 桌宠（Electron 壳，透明置顶窗口）
    live_dir = HERE / "pet_live"
    live_exe = live_dir / "node_modules" / "electron" / "dist" / "electron.exe"
    if live_exe.exists() and (live_dir / "main.js").exists():
        flags = 0x08000000 if os.name == "nt" else 0
        try:
            proc = subprocess.Popen([str(live_exe), str(live_dir)],
                                    cwd=str(live_dir), creationflags=flags)
            print("桌宠已就位（大肥鱼 Live2D）")
            return proc
        except Exception as exc:                                # noqa: BLE001
            print(f"（Live2D 桌宠没起来：{exc}）")
            return None
    # 老的像素桌宠不要了（用户明确说过）：没有 Live2D 就不显示桌宠
    return None


def start_tray() -> None:
    """右下角托盘图标：浮窗关了也能从那里找回来。"""
    script = HERE / "tray.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([str(runner), str(script)], cwd=str(HERE), creationflags=flags)
        print("托盘图标已就位（右下角）")
    except Exception:
        pass


def start_watchdog() -> None:
    """把看门狗也拉起来：它会在主程序挂掉时自动重启（自己带单实例锁）。"""
    script = HERE / "watchdog.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([str(runner), str(script)], cwd=str(HERE), creationflags=flags)
        print("看门狗已就位（主程序挂掉会自动重启）")
    except Exception:
        pass


def build_greeting(cfg: dict, wake: str) -> str:
    """把问候语里的占位符换掉：{name} 名字、{wake} 唤醒词、{time} 早上/中午/下午/晚上。"""
    text = str(cfg.get("greeting_text") or "").strip()
    if not text:
        return ""
    hour = datetime.now().hour
    if 5 <= hour < 11:
        part = "早上"
    elif 11 <= hour < 13:
        part = "中午"
    elif 13 <= hour < 18:
        part = "下午"
    else:
        part = "晚上"
    return (text.replace("{name}", str(cfg.get("name") or "语音助手"))
                .replace("{wake}", wake or "语音助手")
                .replace("{user}", str(cfg.get("user_name") or ""))
                .replace("{time}", part))


# 用"自称"说的应答语：{w} 就是自称（比如「大肥鱼这就办」）
SELF_ACKS = ("{w}这就办", "{w}收到", "{w}来了", "好嘞，{w}这就去", "{w}马上办",
             "{w}记住了", "交给{w}吧", "好，{w}出手", "{w}来啦", "{w}在呢")
# 自称说的勤不勤：三档
SELF_RATE = {"off": 0.0, "sometimes": 0.35, "often": 0.75}


def self_who(cfg: dict) -> str:
    """自称是哪几个字（自称关掉、或者名字空着，就是空串）。"""
    if not bool(cfg.get("self_talk", True)):
        return ""
    return str(cfg.get("self_name") or cfg.get("name") or "").strip()


def self_chance(cfg: dict) -> float:
    """这次要不要用自称来说话（0 = 不说，越大越爱说）。"""
    return SELF_RATE.get(str(cfg.get("self_freq") or "sometimes"), 0.35)


def ack_phrase(cfg: dict) -> str:
    """用户说完一句之后的那句应答。

    「应答语」里可以写**好几条**，用 | 或者换行隔开，每次随机挑一条说
    （比如「好的我这就做|好嘞|收到|来了」），听着就不会那么机械。
    有时候会用**自称**来说这句（「大肥鱼这就办」），
    再按频率决定要不要在末尾带上你对它的称呼。
    """
    raw = str(cfg.get("ack_text") or "我知道了")
    parts = [p.strip() for p in re.split(r"[|\n；;]+", raw) if p.strip()]
    base = random.choice(parts) if parts else "我知道了"
    who = self_who(cfg)
    if who and random.random() < self_chance(cfg):
        base = random.choice(SELF_ACKS).format(w=who)      # 用自称说
    user = str(cfg.get("user_name") or "").strip()
    freq = str(cfg.get("name_freq") or "sometimes")
    if user and freq in ("sometimes", "often"):
        if freq == "often" or random.random() < 0.4:
            base = f"{base}，{user}"
    return base


def self_phrase(cfg: dict, what: str = "完成任务啦") -> str:
    """可爱的自称，比如「大肥鱼完成任务啦」。

    三档频率（设置 → 基本 → 「自称频率」）：off 从不说 / sometimes 有时 /
    often 经常。关掉自称、或者这次不轮到它，就返回空串（调用处直接跳过）。
    """
    who = self_who(cfg)
    if not who:
        return ""
    if random.random() > self_chance(cfg):
        return ""
    return f"{who}{what}"


def speak_greeting(text: str, delay: float = 3.0) -> None:
    """开机问候：过几秒再念，别和启动时的杂音撞一起。用独立进程念，互不干扰。"""
    if not text:
        return
    script = HERE / "say.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0

    def later() -> None:
        time.sleep(max(0.0, delay))
        try:
            remember_spoken(text)
            subprocess.Popen([str(runner), str(script), text], cwd=str(HERE), creationflags=flags)
            syslog("念", f"（开机问候）{text}")
            print(f"（已经念了开机问候：{text}）", flush=True)
        except Exception as exc:  # noqa: BLE001
            print(f"（开机问候没念出来：{exc}）", flush=True)

    threading.Thread(target=later, daemon=True).start()


def speak(text: str, wait: bool = False) -> None:
    # 手机发来的命令：回复只回手机，不在电脑上出声。
    if getattr(_SPEAK_CTX, "silent", False):
        try:
            syslog("念", str(text))       # 只写手机对话流，不启动 TTS
        except Exception:
            pass
        print(f"   ↳ 📱 （手机命令，电脑不出声）{str(text)[:40]}", flush=True)
        return
    # 「静音」：用户按了静音就一直不出声（但还听得见你说话、你照样能语音输入）。
    # 一按就立刻闭嘴这件事由 toggle-mute 那边调 shut_up() 完成。
    if MUTE["on"]:
        print(f"   ↳ 🔇 （静音中，不念了）{str(text)[:40]}", flush=True)
        return
    # 用户要求：他还在说话的时候，它不许开口（等他说完再说）
    try:
        for _ in range(60):            # 最多等 6 秒
            if str(getattr(status, 'state', '')) != 'hearing':
                break
            time.sleep(0.1)
    except Exception:
        pass
    """让 say.py 念一句（独立进程，不干扰识别）。

    wait=True：等它念完再返回 —— 朗读排队用（一次只出一句，绝不重叠出声）。
    """
    remember_spoken(text)
    if _MUTE_SPEAK["on"]:            # 开会模式：只出字幕不出声
        syslog("念", f"（开会中，改口型）{text[:60]}")
        show_instead_of_speaking(text)
        return
    syslog("念", text)
    script = HERE / "say.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        proc = subprocess.Popen([str(runner), str(script), text], cwd=str(HERE),
                                creationflags=flags)
        DUPLEX.assistant_start(text)
        if wait:
            proc.wait()
            DUPLEX.assistant_stop()
        else:
            def _watch_tts() -> None:
                try:
                    proc.wait()
                finally:
                    DUPLEX.assistant_stop()

            threading.Thread(target=_watch_tts, daemon=True).start()
    except Exception:
        DUPLEX.assistant_stop()


# ------------------------------------------------------------------ 提醒 / 定时
# ---------------------------------------------------------------- 闭嘴 / 闭麦

def speaking_now() -> bool:
    """朗读进程现在是不是正在出声。"""
    try:
        data = json.loads(SPEAK_STATUS_FILE.read_text(encoding="utf-8"))
        return bool(data.get("active")) and time.time() - float(data.get("ts") or 0) < 1.5
    except Exception:
        return False


def shut_up() -> None:
    try:
        DUPLEX.user_interrupt()
    except Exception:
        pass
    # 顺便让"念回答"的线程也停下（你一喊停，它就别接着念了）
    try:
        if REPLY_READER is not None:
            REPLY_READER.stop()
    except Exception:
        pass
    try:
        import phone_stream
        phone_stream.STREAMER.stop()
    except Exception:
        pass
    try:
        SPEAK_STOP_FILE.write_text(json.dumps({"ts": time.time()}), encoding="utf-8")
    except Exception:
        pass


def self_spoken_text() -> str:
    """它此刻正在念的那句（用来判断录到的是不是它自己）。"""
    try:
        data = json.loads(SPEAK_STATUS_FILE.read_text(encoding="utf-8"))
        return str(data.get("text") or "")
    except Exception:
        return ""


def sounds_like(a: str, b: str) -> bool:
    """两段话算不算"同一句"——判断这句是不是它自己在念。

    **判得严一点**：只有整句几乎一模一样才算"自己的声音"。
    以前宽（包含 3 个字就算、相似度 0.45 就算），于是它刚把回答念完，
    你接着说话时只要重复了几个词（"我看到 23:33:11 那句设置展开的时候"），
    就会被你自己的话反判成"它在念"，你的话直接被丢掉 —— 真机丢过好几次。
    它自己在念的时候，录回来的是**几乎一整句**（TTS 念得清楚，错字很少），
    所以要"整句被包住"或者"最长重合 ≥ 短句的 75% 且 ≥8 字"才算数。
    """
    import difflib

    aa = re.sub(r"[\s，,。.！!？?]", "", a or "")
    bb = re.sub(r"[\s，,。.！!？?]", "", b or "")
    if len(aa) < 3 or len(bb) < 3:
        return False
    short, long_ = (aa, bb) if len(aa) <= len(bb) else (bb, aa)
    if len(short) >= 8 and short in long_:          # 整句被包住 → 就是它在念
        return True
    # 最长公共子串：念出来再录回去，字常会错几个，但总会有一大段是重合的
    best, prev = 0, [0] * (len(bb) + 1)
    for i in range(1, len(aa) + 1):
        cur = [0] * (len(bb) + 1)
        for j in range(1, len(bb) + 1):
            if aa[i - 1] == bb[j - 1]:
                cur[j] = prev[j - 1] + 1
                best = max(best, cur[j])
        prev = cur
    if best >= 8 and best >= len(short) * 0.75:     # 大半句都对上 → 也是它在念
        return True
    return difflib.SequenceMatcher(None, aa, bb).ratio() >= 0.7


_LNK_CACHE: dict = {"files": [], "ts": 0.0}
_DOC_CACHE: dict = {"files": [], "ts": 0.0}
# 常见的系统程序（开始菜单里常常找不到）
_APP_ALIASES = {
    "记事本": "notepad.exe", "计算器": "calc.exe", "画图": "mspaint.exe",
    "写字板": "write.exe", "任务管理器": "taskmgr.exe", "资源管理器": "explorer.exe",
    "命令提示符": "cmd.exe", "文件资源管理器": "explorer.exe",
    "设置": "ms-settings:", "系统设置": "ms-settings:", "截图": "ms-screenclip:",
    "相机": "microsoft.windows.camera:", "闹钟": "ms-clock:", "便签": "ms-stickynotes:",
}


def _start_menu_lnks() -> list[Path]:
    """开始菜单里的程序快捷方式（含桌面上的），5 分钟内缓存一次。"""
    if _LNK_CACHE["files"] and time.time() - _LNK_CACHE["ts"] < 300:
        return _LNK_CACHE["files"]
    roots = []
    for env in ("ProgramData", "APPDATA"):
        base = os.environ.get(env)
        if base:
            roots.append(Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    for name in ("Desktop", "桌面"):
        p = Path(os.path.expanduser("~")) / name
        if p.is_dir():
            roots.append(p)
    found: list[Path] = []
    for root in roots:
        try:
            found.extend(p for p in root.rglob("*.lnk"))
        except Exception:
            pass
        if len(found) > 4000:
            break
    _LNK_CACHE.update(files=found, ts=time.time())
    return found


def _doc_files() -> list[Path]:
    """桌面/文档/下载里的文件，用来"打开上周的报告"这种。"""
    if _DOC_CACHE["files"] and time.time() - _DOC_CACHE["ts"] < 120:
        return _DOC_CACHE["files"]
    home = Path(os.path.expanduser("~"))
    found: list[Path] = []
    for name in ("Desktop", "桌面", "Documents", "文档", "Downloads", "下载"):
        root = home / name
        if not root.is_dir():
            continue
        try:
            for p in root.rglob("*"):
                if len(found) > 6000:
                    break
                if p.is_file() and p.suffix.lower() not in (".tmp", ".lnk", ".url"):
                    found.append(p)
        except Exception:
            pass
    _DOC_CACHE.update(files=found, ts=time.time())
    return found


def _pick_best(key: str, items, ignore_case: bool = True) -> tuple[object, int]:
    best, score = None, 0
    for it in items:
        name = Path(it).stem if ignore_case else str(it)
        if ignore_case:
            name = name.lower()
        hit = sum(1 for ch in key if ch and ch in name)
        if key and key in name:
            hit += 100
        if hit > score:
            best, score = it, hit
    return best, score


def open_named(target: str) -> str | None:
    """按名字打开程序或文件；返回打开了什么（或者 None）。

    注意：网页文件（.html/.url 这些）一律不当成"要打开的东西" —— 双击它们会拉起
    浏览器，用户会觉得"它自己把微软浏览器打开了"。除非你话里明说要浏览器/网页。
    """
    key = re.sub(r"[\s的了个吧呢啊，,。.！!]", "", target or "").lower()
    if not key:
        return None
    wants_browser = any(w in key for w in ("浏览器", "网页", "网址", "网站", "链接"))
    web_suffix = (".html", ".htm", ".url", ".webloc", ".mhtml")

    def ok_file(p) -> bool:
        return wants_browser or Path(p).suffix.lower() not in web_suffix

    # 常见的系统程序先查别名：它们多半没有开始菜单快捷方式
    for alias, cmd in _APP_ALIASES.items():
        if alias in key:
            try:
                os.startfile(cmd)
                return alias
            except Exception:
                try:
                    subprocess.Popen(cmd, shell=True)
                    return alias
                except Exception:
                    break
    need = max(2, min(4, len(key)))
    best, score = _pick_best(key, [p for p in _start_menu_lnks() if ok_file(p)])
    if best is not None and score >= need:
        try:
            os.startfile(str(best))
            return Path(best).stem
        except Exception:
            pass
    best, score = _pick_best(key, [p for p in _doc_files() if ok_file(p)])
    if best is not None and score >= need:
        try:
            os.startfile(str(best))
            return Path(best).name
        except Exception:
            pass
    return None


# ---------------------------------------------------------------- 上下文指代

_REPEAT_WORDS = ("再来一次", "跟刚才一样", "和刚才一样", "重复一遍", "再说一遍", "重新发一遍",
                 "再发一遍", "同上")

# Whisper 在"音乐/电视/杂音"上最爱吐的固定几句（中文数据集的残留）。
# 它们跟用户没关系，出现就当没听见——不然电视开着会一直往聊天窗口吐字。
# 只说得出、正常人不这么讲话的几句——命中就直接丢
HALLUCINATIONS = (
    "请不吝点赞", "不吝点赞", "打赏支持", "明镜与点点", "点点栏目", "明镜与点点栏目",
    "字幕组", "中文字幕", "字幕由", "下期再见", "更多精彩内容", "欢迎订阅本",
    "本视频", "感谢收看", "谢谢观看", "谢谢大家的观看",
    # 视频字幕腔的常见"鬼话"，模型在杂音上很容易蹦出这些
    "一键三连", "点个赞", "点赞订阅", "订阅频道", "别忘了订阅", "关注我",
    "感谢观看", "感谢大家的观看", "谢谢大家观看", "下期见", "我们下期见",
    "大家好我是", "今天给大家", "本期的", "记得点赞", "欢迎点赞", "欢迎收看",
    "字幕志愿者", "翻译字幕", "自动生成字幕", "未经作者授权", "禁止转载",
    "更多内容请", "视频就到这里", "今天的视频", "老规矩", "拜拜",
)
# 这些词本身很正常（"帮我订阅…转发…"），要凑够三个才当幻觉
HALLUCINATION_WEAK = ("点赞", "订阅", "转发", "打赏", "栏目", "字幕", "观看",
                      "关注", "收藏", "投币", "三连", "频道", "视频", "直播",
                      "广告", "节目", "感谢", "谢谢", "再来一首", "歌手", "歌词",
                      "专辑", "歌曲", "音乐", "演出", "伴奏", "演唱")
# 一听就是"歌曲/演唱会字幕"的词：单独出现在短句里，基本不是你在下命令
MUSIC_WORDS = ("歌手", "歌曲", "演唱", "伴奏", "专辑", "歌词", "音乐", "演出", "原唱")


def is_hallucination(text: str) -> bool:
    """是不是识别引擎在杂音/背景乐上编出来的废话。

    三道判断：
      ① 命中固定句（"请不吝点赞…"这种整句）
      ② 这些词凑够三个（"点赞 订阅 转发"）
      ③ 短句里**除了这些词没别的**（单独蹦出"点赞""转发""周杰伦的歌手名"这类）
         外加：带网址、带"字幕"的，一律当幻觉。
    """
    raw = text or ""
    try:
        if speaking_now() and likely_echo(raw, self_spoken_text()):
            return True
    except Exception:
        pass
    # 网址要在"去掉标点之前"看，不然 www.xxx.com 被抠掉点就认不出来了
    if re.search(r"(www\.|https?://|\.com|\.cn|\.net|\.tv)", raw, re.I):
        return True
    plain = re.sub(r"[\s，,。.！!？?、；;：:]", "", raw)
    if len(plain) < 2:
        return False
    if any(w in plain for w in HALLUCINATIONS):
        return True
    if "字幕" in plain:
        return True
    if len(plain) <= 10 and any(w in plain for w in MUSIC_WORDS):
        return True          # "周杰伦 歌手" 这种：短句里冒出歌名/歌手味的词
    weak = [w for w in HALLUCINATION_WEAK if w in plain]
    if len(weak) >= 3:
        return True
    if weak and len(plain) <= 10:
        # 把命中的词抠掉，剩下的几乎没内容 → 这句只是几个套话拼起来的
        rest = plain
        for w in weak:
            rest = rest.replace(w, "")
        if len(rest) <= 2:
            return True
    return False


def parse_repeat(text: str) -> bool:
    plain = (text or "").replace(" ", "").strip("。，,.！! ")
    return any(w in plain for w in _REPEAT_WORDS) and len(plain) <= 8


# ---------------------------------------------------------------- 语音日记 / 成就

def diary_lines(day: str) -> list[str]:
    """挑出某一天"真的说给它听"的话（噪声被转成的句子不算）。"""
    out = []
    for name in ("said.md", "transcripts.md"):
        path = HERE / name
        if not path.exists():
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue
        for line in lines:
            line = line.strip()
            if not line.startswith("- ") or day not in line:
                continue
            body = line.split(" ", 2)
            if len(body) >= 3:
                body = re.sub(r"^\d{1,2}:\d{2}(:\d{2})?\s*", "", body[2].strip())
                if body.startswith("（忽略）"):
                    continue
                out.append(body)
        if out:
            break                    # said.md 有就用它，别两份都算
    return out


def diary_summary(day: str) -> str:
    lines = diary_lines(day)
    if not lines:
        return "今天你没跟我说过话，明天见。"
    longest = sorted(lines, key=len, reverse=True)[:3]
    head = f"今天你跟我说了 {len(lines)} 句话。"
    body = "印象最深的几句：" + "；".join(s[:40] for s in longest) + "。"
    return head + body


ACHIEVEMENTS = [
    ("wake", 1, "初次唤醒", "它第一次被你叫醒"),
    ("wake", 100, "百次唤醒", "累计叫醒它 100 次"),
    ("wake", 1000, "千次唤醒", "累计叫醒它 1000 次"),
    ("note", 1, "第一个便签", "第一次让它记东西"),
    ("ledger", 1, "开始记账", "第一次让它记账"),
    ("focus", 1, "第一颗番茄", "第一次开番茄钟"),
    ("game", 1, "陪我玩", "第一次跟它玩游戏"),
    ("game", 5, "游戏搭子", "一共玩了 5 局"),
    ("correct", 1, "教它说话", "第一次教它纠错"),
]


def read_achv() -> dict:
    try:
        data = json.loads(ACHV_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data.setdefault("counts", {})
            data.setdefault("unlocked", {})
            data.setdefault("days", [])
            return data
    except Exception:
        pass
    return {"counts": {}, "unlocked": {}, "days": []}


def bump_achv(kind: str, n: int = 1) -> list[str]:
    """给某个计数器加数，返回这次新解锁的成就名。"""
    data = read_achv()
    counts = data["counts"]
    counts[kind] = int(counts.get(kind, 0)) + n
    today = datetime.now().strftime("%Y-%m-%d")
    days = data["days"]
    if today not in days:
        days.append(today)
        days[:] = days[-60:]
    earned = []
    for key, need, name, _desc in ACHIEVEMENTS:
        if key == kind and counts[kind] >= need and name not in data["unlocked"]:
            data["unlocked"][name] = today
            earned.append(name)
    try:
        ACHV_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return earned


def spectrum_bands(block: np.ndarray, sr: int, count: int = 12) -> list[float]:
    """把一小段音频压成几根"音浪"柱子的高度（0~1）。"""
    if block.size < 64:
        return [0.0] * count
    win = np.hanning(block.size)
    spec = np.abs(np.fft.rfft(block * win))
    freqs = np.fft.rfftfreq(block.size, 1.0 / sr)
    edges = np.logspace(np.log10(70), np.log10(min(11000, sr / 2 - 100)), count + 1)
    out = []
    for i in range(count):
        lo, hi = edges[i], edges[i + 1]
        sel = (freqs >= lo) & (freqs < hi)
        val = float(np.mean(spec[sel])) if np.any(sel) else 0.0
        out.append(min(1.0, val / (block.size * 0.06)))
    peak = max(out)
    if peak <= 0.02:
        return [round(v * 6, 3) for v in out]     # 太安静：整体压扁，别把底噪放大成满格
    out = [min(1.0, v / peak * 0.92) for v in out]
    return [round(v, 3) for v in out]


MEM_FILE = HERE / "memory.json"
VP_FILE = HERE / "voiceprint.json"


def read_ledger() -> list[dict]:
    """读记账本（给周报和"今天花了多少"用）。"""
    try:
        data = json.loads(LEDGER_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


_VK_CTRL, _VK_ALT = 0x11, 0x12
_PAGE_CMDS = [
    (("新建标签页", "新建标签", "新标签页"), 0x54, (_VK_CTRL,)),
    (("关闭标签页", "关闭标签", "关掉这个标签"), 0x57, (_VK_CTRL,)),
    (("刷新一下", "刷新页面", "刷新"), 0x74, ()),
    (("返回上一页", "后退", "退回去"), 0x25, (_VK_ALT,)),
    (("前进一页", "前进"), 0x27, (_VK_ALT,)),
    (("地址栏", "输入网址"), 0x4C, (_VK_CTRL,)),
    (("往下翻", "下一屏"), 0x22, ()),
    (("往上翻", "上一屏"), 0x21, ()),
    (("翻到最后", "到底部"), 0x23, ()),
    (("回到最上面", "回到顶部"), 0x24, ()),
]


def _combo(vk: int, *mods: int) -> None:
    for m in mods:
        _key(m)
    _key(vk)
    _key(vk, up=True)
    for m in reversed(mods):
        _key(m, up=True)


def parse_page_cmd(text: str) -> tuple[str, int, tuple] | None:
    """网页 / 滚动类指令：新标签页、刷新、往下翻、回到顶部……"""
    plain = (text or "").replace(" ", "").strip("。，,.！! ")
    if not plain or len(plain) > 12:
        return None
    for words, vk, mods in _PAGE_CMDS:
        for w in words:
            if w in plain:
                return (w, vk, mods)
    return None


def clipboard_text() -> str:
    """读剪贴板里的文字（没有就返回空串）。"""
    if os.name != "nt":
        return ""
    CF_UNICODETEXT = 13
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.GetClipboardData.restype = ctypes.c_void_p
    try:
        if not user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
            return ""
        if not user32.OpenClipboard(None):
            return ""
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return ""
            try:
                return ctypes.wstring_at(ptr)
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
    except Exception:
        return ""


def selected_text() -> str:
    """模拟 Ctrl+C 取当前选中的文字；剪贴板没变化就说明其实没选中东西。"""
    if os.name != "nt":
        return ""
    u = ctypes.windll.user32
    before = u.GetClipboardSequenceNumber()
    _combo(0x43, _VK_CTRL)          # Ctrl+C
    time.sleep(0.12)
    if u.GetClipboardSequenceNumber() == before:
        return ""
    return clipboard_text().strip()


def image_to_clipboard(img) -> bool:
    """把一张 PIL 图放进剪贴板（CF_DIB），别的程序就能直接粘贴。"""
    if os.name != "nt":
        return False
    import struct

    from PIL import Image as _Img

    rgb = img.convert("RGB")
    r, g, b = rgb.split()
    bgra = _Img.merge("RGBA", (b, g, r, _Img.new("L", rgb.size, 0)))
    data = bgra.transpose(_Img.FLIP_TOP_BOTTOM).tobytes()
    w, h = rgb.size
    header = struct.pack("<IiiHHIIiiII", 40, w, h, 1, 32, 0, len(data), 2835, 2835, 0, 0)
    blob = header + data
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    try:
        if not user32.OpenClipboard(None):
            return False
        try:
            user32.EmptyClipboard()
            handle = kernel32.GlobalAlloc(0x0002, len(blob))
            if not handle:
                return False
            ptr = kernel32.GlobalLock(handle)
            ctypes.memmove(ptr, blob, len(blob))
            kernel32.GlobalUnlock(handle)
            user32.SetClipboardData(8, handle)      # CF_DIB
        finally:
            user32.CloseClipboard()
    except Exception:
        return False
    return True


def grab_screen() -> bool:
    """截主屏塞进剪贴板。"""
    try:
        from PIL import ImageGrab

        return image_to_clipboard(ImageGrab.grab())
    except Exception as exc:  # noqa: BLE001
        print(f"   （截图失败：{type(exc).__name__}）", flush=True)
        return False


def memory_all() -> list[dict]:
    """Compatibility wrapper; tests may redirect MEM_FILE."""
    return _personal.memory_all(MEM_FILE)


def memory_add(text: str) -> bool:
    return _personal.memory_add(MEM_FILE, text)


def memory_find(query: str, limit: int = 3) -> list[dict]:
    return _personal.memory_find(MEM_FILE, query, limit)


parse_remember = _personal.parse_remember
parse_ask_memory = _personal.parse_ask_memory


def weekly_report() -> str:
    """这周：说了多少句、花了多少、用了我几天。"""
    from datetime import timedelta

    start = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    try:
        lines = SAID_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        lines = []
    week = [ln for ln in lines if ln.startswith("- ") and ln[2:12] >= start]
    rows = [r for r in read_ledger() if str(r.get("date", "")) >= start]
    spent = sum(r["amount"] for r in rows)
    days = [d for d in read_achv().get("days", []) if d >= start]
    head = f"这周你跟我说了 {len(week)} 句话，用了我 {len(days)} 天。"
    money = f"一共花了 {spent:g} 块。" if spent else "这周没记过账。"
    top = ""
    if week:
        longest = sorted((re.sub(r"^-\s+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+", "", ln)
                          for ln in week), key=len, reverse=True)[:2]
        top = "印象最深的：" + "；".join(s[:26] for s in longest) + "。"
    return head + money + top


def last_input_age() -> float:
    """距离你上次动键盘/鼠标过了多少秒。"""
    if os.name != "nt":
        return 0.0

    class _LII(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    info = _LII()
    info.cbSize = ctypes.sizeof(_LII)
    try:
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
            return 0.0
        ticks = ctypes.windll.kernel32.GetTickCount()
        return max(0.0, (ticks - info.dwTime) / 1000.0)
    except Exception:
        return 0.0


MEETING_APPS = ("腾讯会议", "zoom", "teams", "钉钉", "飞书", "lark", "webex", "瞩目",
                "classin", "meet -", "会议")


def foreground_hwnd() -> int:
    if os.name != "nt":
        return 0
    try:
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def foreground_title() -> str:
    if os.name != "nt":
        return ""
    try:
        u = ctypes.windll.user32
        buf = ctypes.create_unicode_buffer(256)
        u.GetWindowTextW(u.GetForegroundWindow(), buf, 256)
        return buf.value or ""
    except Exception:
        return ""


def in_meeting() -> bool:
    title = foreground_title().lower()
    return any(app in title for app in MEETING_APPS)


def is_our_window(hwnd: int) -> bool:
    """这个窗口是不是我们自己开的？（悬浮窗、设置面板、日志窗口这些）"""
    if not hwnd or os.name != "nt":
        return False
    try:
        pid = ctypes.c_ulong()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value) == os.getpid()
    except Exception:
        return False


def pick_send_target(cfg: dict, target_arg, tracker, log=print) -> tuple:
    """这句话该发到哪个窗口。

    以前这里有个 bug：条件是「开了跟随当前窗口 **并且** 没设 target」——
    可 config 里本来就写着 target=ChatGPT，所以那个开关**永远是死的**：
    你在别的对话窗口说话时，它照样往 ChatGPT 那个窗口发（或者发到你上一个用过的窗口），
    看起来就是"别的对话不触发"。

    现在的规矩：
      1. 开了「跟着当前窗口发」→ 发给当前前台窗口（要是我们自己的窗口就跳过）
      2. 没开 → 按 target 找标题匹配的窗口（比如 ChatGPT）
      3. 都找不到 → 用你上一个用过的窗口
    """
    def fallback() -> tuple:
        if target_arg:
            hwnd, title = find_window(target_arg)
            if hwnd:
                return hwnd, title
        if tracker:
            return tracker.hwnd, tracker.title
        return 0, ""

    if cfg.get("follow_foreground"):
        fg = foreground_hwnd()
        if fg and not is_our_window(fg):
            return fg, foreground_title()
        if fg:
            log("   ↳ （前台是我们自己的窗口，改用上一个用过的窗口）")
    return fallback()


def voice_enroll(audio: np.ndarray, sr: int) -> bool:
    return _personal.voice_enroll(audio, sr, VP_FILE)


def voice_score(audio: np.ndarray, sr: int) -> float | None:
    return _personal.voice_score(audio, sr, VP_FILE)


voice_features = _personal.voice_features
background_noise = _personal.background_noise


def level_state(v: float) -> str:
    """麦克风电平够大才算「听到声音」，否则就是在等你说。

    用户反馈：以前录音回调里一律写 hearing，等于「听到声音了」常亮；
    要的是**我说话的时候才出现**。
    """
    try:
        return "hearing" if float(v or 0) >= 0.05 else "listening"
    except Exception:
        return "listening"


def start_reminder(seconds: float, what: str, paste: bool = False, target_hwnd: int = 0) -> None:
    """到点了：念出来 + 写进日志；可选把提醒也发到目标窗口。"""
    def fire() -> None:
        text = f"提醒你：{what}"
        speak(text)
        try:
            with (HERE / "transcripts.md").open("a", encoding="utf-8") as fh:
                fh.write(f"- {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ⏰ {text}\n")
        except Exception:
            pass
        print(f"\n⏰ {text}", flush=True)
        if paste and target_hwnd:
            paste_into(f"⏰ {text}", target_hwnd, press_enter=True, clear_first=True)

    timer = threading.Timer(max(1.0, seconds), fire)
    timer.daemon = True
    timer.start()


def run_shortcut(text: str, cfg: dict) -> str:
    """自定义快捷指令：说中短语就执行（url: / app: / say:）。返回执行的动作。"""
    shortcuts = cfg.get("shortcuts") or {}
    if not isinstance(shortcuts, dict):
        return ""
    for phrase, action in shortcuts.items():
        if not phrase or not action or phrase not in text:
            continue
        action = str(action).strip()
        try:
            if action.startswith("url:"):
                webbrowser.open(action[4:].strip())
            elif action.startswith("app:"):
                subprocess.Popen(action[4:].strip(), shell=True)
            elif action.startswith("say:"):
                speak(action[4:].strip())
            else:
                continue
        except Exception as exc:  # noqa: BLE001
            print(f"（快捷指令失败：{exc}）", flush=True)
            continue
        return f"{phrase} → {action}"
    return ""


# ------------------------------------------------------------------ 日程表
_WEEK = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6, "天": 6}


def day_match(days: str, today: int) -> bool:
    """today: 0=周一 … 6=周日。支持 每天 / 工作日 / 周末 / 周一,周三 / 一三五。"""
    days = (days or "每天").strip()
    if not days or days in ("每天", "每日", "天天", "all"):
        return True
    if days in ("工作日", "周一至周五", "周一到周五"):
        return today <= 4
    if days in ("周末", "周六周日", "周六,周日"):
        return today >= 5
    picked = set()
    for ch in days:
        if ch in _WEEK:
            picked.add(_WEEK[ch])
    return today in picked if picked else True


def start_scheduler(get_target, paste_text) -> None:
    """后台线程：每分钟看一眼日程表，到点就把内容发出去（并念一遍）。"""
    fired: set[tuple[int, str]] = set()

    def loop() -> None:
        while True:
            try:
                cfg = load_config()
                items = cfg.get("schedules") or []
                now = datetime.now()
                stamp = now.strftime("%Y-%m-%d %H:%M")
                import sched as sched_mod

                today = datetime.now().date()
                for i, item in enumerate(items):
                    if not isinstance(item, dict) or item.get("enabled", True) is False:
                        continue
                    when = str(item.get("time") or "").strip()
                    text = str(item.get("text") or "").strip()
                    if not when or not text:
                        continue
                    key = (i, stamp)
                    if key in fired or when != now.strftime("%H:%M"):
                        continue
                    # 新规则（每天/每周/每月/单次）和老写法都支持
                    if "kind" in item:
                        if not sched_mod.matches(item, today):
                            continue
                    elif not day_match(str(item.get("days") or "每天"), now.weekday()):
                        continue
                    fired.add(key)
                    print(f"\n🗓 日程到点：{text}", flush=True)
                    if cfg.get("schedule_speak", True):
                        speak(text)
                    # 提醒模块只出声；指令模块才把内容发出去
                    if item.get("kind_module") != "remind":
                        hwnd = get_target()
                        if hwnd:
                            paste_text(text, hwnd)
                        done_phrase = self_phrase(cfg)
                        if done_phrase:
                            speak(done_phrase)
                    try:
                        with (HERE / "transcripts.md").open("a", encoding="utf-8") as fh:
                            fh.write(f"- {now.strftime('%Y-%m-%d %H:%M:%S')} 🗓 {text}\n")
                    except Exception:
                        pass
                if len(fired) > 400:
                    fired.clear()
            except Exception as exc:  # noqa: BLE001
                print(f"（日程检查出错：{exc}）", flush=True)
            time.sleep(20)

    threading.Thread(target=loop, daemon=True).start()


def load_config() -> dict:
    """读同目录的 config.json；没有或读坏了就用空配置。"""
    path = HERE / "config.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️ config.json 读不了（{exc}），先按默认设置走。")
        return {}


def total_ram_gb() -> float:
    """物理内存有多少 GB（低配机器主要看这个）。"""
    if os.name != "nt":
        return 8.0

    class _MEM(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_uint), ("dwMemoryLoad", ctypes.c_uint),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

    try:
        st = _MEM()
        st.dwLength = ctypes.sizeof(_MEM)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return st.ullTotalPhys / (1024 ** 3)
    except Exception:
        pass
    return 8.0


def detect_profile() -> tuple[str, dict]:
    """看这台机器什么档次，返回 (档位, 说明)。

    低配判定：没有 NVIDIA 显卡驱动、内存少于 8G、或者 CPU 核心少于 6。
    低配模式下自动：小模型 + int8 + 关实时字幕 + 关特效 + 30 帧 + 节能。
    """
    force = (os.environ.get("STT_FORCE_PROFILE") or "").strip().lower()
    cuda = False
    try:
        cuda = register_cuda_dlls()
    except Exception:
        cuda = False
    ram = total_ram_gb()
    cores = os.cpu_count() or 4
    if force in ("lite", "high"):        # 手动指定（自己知道机器行不行，或测试用）
        return force, {"why": "手动指定 " + force, "ram": ram, "cores": cores, "cuda": cuda}
    if not cuda or ram < 8.0 or cores < 6:
        why = ("没找到 NVIDIA 显卡" if not cuda else
               f"内存只有 {ram:.0f}G" if ram < 8.0 else f"只有 {cores} 核")
        return "lite", {"why": why, "ram": ram, "cores": cores, "cuda": cuda}
    return "high", {"why": "显卡+内存都够", "ram": ram, "cores": cores, "cuda": cuda}


def register_cuda_dlls() -> bool:
    """把 pip 装的 cuBLAS / cuDNN 目录加进 DLL 搜索路径（Windows 上显卡加速的前提）。

    返回 True 表示找到了 cuBLAS，可以尝试用显卡。
    """
    if os.name != "nt" or not hasattr(os, "add_dll_directory"):
        return True
    found = False
    dll_dirs: list[str] = []
    for pkg in ("nvidia.cublas", "nvidia.cudnn"):
        try:
            root = Path(importlib.import_module(pkg).__path__[0])
        except Exception:
            continue
        for folder in root.rglob("bin"):
            try:
                os.add_dll_directory(str(folder))
            except OSError:
                pass
            dll_dirs.append(str(folder))
            if any(folder.glob("cublas64_12.dll")):
                found = True
    if dll_dirs:  # 有些库按 PATH 找依赖，两边都喂上
        os.environ["PATH"] = os.pathsep.join(
            dll_dirs + [os.environ.get("PATH", "")]
        )
    if not found:
        try:
            ctypes.WinDLL("cublas64_12.dll")
            found = True
        except OSError:
            found = False
    return found


# ---------------------------------------------------------------- 输出/剪贴板

def setup_console() -> None:
    # 用 pythonw 跑（没有控制台）时，sys.stdout/stderr 是 None，
    # 这时候 print 会直接报错。改成写日志文件，出问题也还能查。
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            try:
                stream = open(HERE / "voice.log", "a", encoding="utf-8", buffering=1)
            except Exception:
                stream = open(os.devnull, "w", encoding="utf-8")
            setattr(sys, name, stream)
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleOutputCP(65001)
            kernel32.SetConsoleTitleW("语音助手")
        except Exception:
            pass


def copy_to_clipboard(text: str) -> bool:
    """写入 Windows 剪贴板（Unicode），不依赖第三方库。"""
    if os.name != "nt":
        return False
    CF_UNICODETEXT, GMEM_MOVEABLE = 13, 0x0002
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    try:
        if not user32.OpenClipboard(None):
            return False
        try:
            user32.EmptyClipboard()
            size = (len(text) + 1) * ctypes.sizeof(ctypes.c_wchar)
            handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, size)
            if not handle:
                return False
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return False
            ctypes.memmove(ptr, ctypes.create_unicode_buffer(text), size)
            kernel32.GlobalUnlock(handle)
            return bool(user32.SetClipboardData(CF_UNICODETEXT, handle))
        finally:
            user32.CloseClipboard()
    except Exception:
        return False


# ------------------------------------------------------------------ 音频采集

def list_devices() -> None:
    print("可用录音设备：")
    for i, dev in enumerate(sd.query_devices()):
        if dev["max_input_channels"] > 0:
            api = sd.query_hostapis(dev["hostapi"])["name"]
            mark = " <- 默认" if i == sd.default.device[0] else ""
            print(f"  [{i:>2}] {dev['name']}  ({api}, {dev['max_input_channels']}ch){mark}")


def resolve_device(spec: str | None, warn=print):
    if spec is None or spec == "":
        return None
    if spec.lstrip("-").isdigit():
        return int(spec)
    matches = [
        i for i, d in enumerate(sd.query_devices())
        if d["max_input_channels"] > 0 and spec.lower() in d["name"].lower()
    ]
    if not matches:
        warn(f"⚠️ 没找到名字包含 “{spec}” 的麦克风，先用系统默认设备。接好麦克风后重开即可。")
        return None
    # 同一支麦克风在 MME/DirectSound/WASAPI 下会重复出现，优先 WASAPI（延时更低、音质更稳）
    def api_rank(i: int) -> int:
        name = sd.query_hostapis(sd.query_devices(i)["hostapi"])["name"]
        return {"Windows WASAPI": 0, "Windows DirectSound": 1, "MME": 2}.get(name, 3)

    return sorted(matches, key=api_rank)[0]


def open_stream(device, samplerate: int = TARGET_SR):
    """返回 (stream, 实际采样率)。设备不支持 16k 时退回设备默认采样率。"""
    return _audio_open_stream(device, samplerate)


def resample_to_16k(audio: np.ndarray, sr: int) -> np.ndarray:
    return _audio_resample_to_16k(audio, sr)


def rms(block: np.ndarray) -> float:
    return _audio_rms(block)


CJK = r"\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uff00-\uffef"
# 给 Whisper 的提示词，它对含混的音频有时会把提示词本身当成识别结果吐出来
ASR_PROMPT = "以下是普通话的句子，请加标点。"
# 注意：识别引擎吐回来的回声**不一定是完整那句** —— 经常只回半截
# （比如"以下是普通话的"），所以这里每一段都要能单独匹配上，不然就被当成你说的话发出去。
_PROMPT_ECHO = re.compile(
    r"(以下是普通话(的)?(句子)?[，,]?|请加标点[。.]?|加标点[。.]?|普通话的句子)")
# 回声有时只剩两个残字（"以下"、"以下是"），这种碎片单独出现时没人会这么说话
_ECHO_FRAGMENT = {"以下", "以下是", "请加", "加标点", "普通话", "的句子", "句子"}
_PUNCT = {",": "，", ".": "。", "?": "？", "!": "！", ";": "；", ":": "："}
# Whisper 偶尔会吐出这些半角/变体标点，直接换成正体
_PUNCT_FIX = {
    "\ufe50": "，", "\ufe51": "、", "\ufe52": "。", "\uff61": "。",
    "\uff0e": "。", "\uff1f": "？", "\uff01": "！", "\uff1b": "；", "\uff1a": "：",
}


def normalize_zh(text: str) -> str:
    """Whisper 常输出半角标点，中文场景下换成全角更像正常句子。"""
    text = "".join(_PUNCT_FIX.get(ch, ch) for ch in text)
    out = []
    for i, ch in enumerate(text):
        if ch in _PUNCT:
            before = text[i - 1] if i > 0 else ""
            after = text[i + 1] if i + 1 < len(text) else ""
            if re.match(f"[{CJK}]", before) or re.match(f"[{CJK}]", after):
                out.append(_PUNCT[ch])
                continue
        out.append(ch)
    text = "".join(out)
    # 同一小段连着重复三次以上，基本是安静环境下的复读幻觉，压成一次
    text = re.sub(r"(.{3,30}?)\1{2,}", r"\1", text)
    # 把提示词回声去掉；去掉后啥都不剩就当成没识别到
    cleaned = _PROMPT_ECHO.sub("", text).strip("，,、 ")
    # 两头还可能粘着回声的碎渣：「取消 以下」要能变回「取消」，不然取消就失效了
    cleaned = re.sub(r"^(以下(是)?|请加标点?|加标点)[，,、\s]*", "", cleaned)
    cleaned = re.sub(r"[，,、\s]*(以下(是)?|请加标点?|加标点)$", "", cleaned)
    cleaned = cleaned.strip("，,、 ")
    if cleaned in _ECHO_FRAGMENT:          # 只剩残字 → 也是回声，当没听见
        cleaned = ""
    return cleaned if re.search(r"[\w\u4e00-\u9fff]", cleaned) else ""


def _word_pattern(word: str) -> str:
    """允许字与字之间夹标点/空格，比如"发，送"也能认出"发送"。"""
    return r"[\s，,、。.!！?？]*".join(re.escape(ch) for ch in word)


# 同音字容错：Whisper 说"大肥鱼"时常吐"大飞鱼/大肥与悦"这类同音错字，
# 逐字比对就会漏掉，所以再用不带声调的拼音比一遍。
try:
    from pypinyin import Style as _PinStyle
    from pypinyin import lazy_pinyin as _lazy_pinyin

    _HAS_PINYIN = True
except Exception:                       # 没装 pypinyin 也不影响：退回原来的逐字匹配
    _HAS_PINYIN = False

_HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
_ALNUM = re.compile(r"[0-9A-Za-z]" + "|" + _HAN.pattern)


def _unit_syllable(chunk: str) -> str:
    """一个字/一段字符的拼音（不带声调）；拿不到就原样返回，便于退化比对。"""
    if not _HAS_PINYIN:
        return chunk.lower()
    got = _lazy_pinyin(chunk, style=_PinStyle.NORMAL)
    return (got[0] if got else chunk).lower()


def _fuzzy_span(text: str, word: str) -> tuple[int, int] | None:
    """按拼音找触发词，返回命中的 (首字下标, 末字下标)；没找到返回 None。

    比逐字匹配宽：声调不管，所以"大肥鱼 / 大飞鱼 / 打肥鱼 / 大肥于"都算中；
    但"大鲨鱼 / 大白鱼"拼音不一样，不会误触发。
    末字额外允许把连着的同音字一起吃掉（"大肥与悦"里的"与悦"），
    避免把多出来的那个字留在正文里。
    """
    if not _HAS_PINYIN or not word:
        return None
    want = [_unit_syllable(ch) for ch in word if _ALNUM.match(ch)]
    if not want:
        return None
    units = [(i, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
    n = len(units)
    last = len(want) - 1
    for start in range(n):
        k = 0
        idx = start
        end = None
        while k < len(want) and idx < n:
            syl = units[idx][1]
            if k == last:
                if not syl.startswith(want[k]):
                    break
                end = idx
                while end + 1 < n and units[end + 1][1].startswith(want[k]):
                    end += 1
            else:
                if syl != want[k]:
                    break
                end = idx
            idx += 1
            k += 1
        if k == len(want) and end is not None:
            return units[start][0], units[end][0]
    return None


# 命令关键词：Whisper 常把"专注"写成"砖住"、"番茄钟"写成"翻切中"，
# 按拼音把它们换回正确写法，后面的判断就都能认出来了。
# 注意：**"取消"不在这里** —— 见下面的 cancel_hit。像"取消"这种两字词塞进来，
# 会把"别取笑他了"这种正经话改成"别取消他了"（真的改过，用户的话被换掉），
# 取消词自己有严格的判定。
_CANON = ("专注模式", "结束专注", "专注", "番茄钟", "记一下", "记一笔", "记账",
          "帮我决定", "猜数字", "早间播报", "变身", "提醒我")


def canonize(text: str) -> str:
    """把听着像命令词的同音错字换回正确写法（只在拼音完全对得上时才换）。"""
    if not _HAS_PINYIN or not text:
        return text
    for word in _CANON:
        want = [_unit_syllable(ch) for ch in word]
        if not want:
            continue
        units = [(i, ch, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
        for s in range(len(units) - len(want) + 1):
            if [u[2] for u in units[s:s + len(want)]] != want:
                continue
            a, b = units[s][0], units[s + len(want) - 1][0]
            if text[a:b + 1] != word:
                text = text[:a] + word + text[b + 1:]
            break
    return text


def _leading_span(text: str, word: str) -> tuple[int, int] | None:
    """句首少了头一个字也算数：录音开头常被吞掉，"飞鱼把颜色…"其实是在喊"大肥鱼"。

    只认句首，而且要求连续两个字完全对上，所以"这条飞鱼真好看"这种不会误触发。
    """
    want = [_unit_syllable(ch) for ch in word if _ALNUM.match(ch)]
    if len(want) < 3 or not _HAS_PINYIN:
        return None
    units = [(i, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
    if len(units) < 2:
        return None
    for run in range(len(want) - 1, 1, -1):          # 3 字的词先试 2 字
        for at in (0, len(want) - run):
            piece = want[at:at + run]
            if [u[1] for u in units[:run]] == piece:
                return units[0][0], units[run - 1][0]
    return None


def extract_word(text: str, words: list[str], fuzzy: bool = True,
                 leading: bool = True) -> tuple[str, bool]:
    """把触发词从句子里摘出来，返回 (剩下的正文, 有没有出现触发词)。

    fuzzy / leading 是唤醒档位里的两个开关：同音字容错、开头吞字容错。
    """
    hit = False
    out = text
    for word in words:
        if not word:
            continue
        pattern = re.compile(_word_pattern(word))
        if pattern.search(out):
            hit = True
            out = pattern.sub("", out)
            continue
        span = _fuzzy_span(out, word) if fuzzy else None   # 逐字没中，再按同音字找一次
        if span is not None:
            hit = True
            out = out[:span[0]] + out[span[1] + 1:]
            continue
        span = _leading_span(out, word) if leading else None   # 开头被吞掉半个词
        if span is not None:
            hit = True
            out = out[:span[0]] + out[span[1] + 1:]
    return out.strip(" ，,、。.!！?？"), hit


# ---------------------------------------------------------------------------
# 取消词：**严格判定**。
# 以前是拿唤醒档位那套"同音容错"去整句里找取消词，于是：
#   · "取笑他""去小卖部"这种一听就是正经话的，也可能被当成取消；
#   · 更糟的是 canonize 会把"别取笑他了"改成"别取消他了"，你发出去的话被换掉。
# 现在规矩很简单 —— **整句话就是那个取消词才算数**：
#   ① 整句（去掉标点、去掉尾巴上的语气词）正好等于取消词："取消" / "取消吧" / "取消掉"；
#   ② 整句跟取消词一样长、拼音一模一样："取笑" → "取消"（真同音，Whisper 常这么写）；
# 其余一概不算取消，原话照发。句子里夹着"取消"的长句（"帮我取消明天的提醒"）
# 从来就不是取消指令，它是你要发给 AI 的话。
_CANCEL_TAIL = "吧了呀啊哦噢呢嘛哈嗯的掉咯"
_CANCEL_PUNCT = re.compile(r"[\s，,、。.!！?？~～…\-—_*·]+")


def cancel_hit(text: str, words: list[str]) -> bool:
    """整句就是取消词吗（允许同音、允许后面带个语气词）？严格版。"""
    plain = _CANCEL_PUNCT.sub("", text or "")
    if not plain:
        return False
    cands = {plain}
    core = plain
    while core and core[-1] in _CANCEL_TAIL:      # 取消吧 / 取消掉 / 取消了啊
        core = core[:-1]
        cands.add(core)
    for word in words:
        w = (word or "").strip()
        if not w:
            continue
        if w in cands:
            return True
        if not _HAS_PINYIN:
            continue
        want = [_unit_syllable(ch) for ch in w]
        if not want:
            continue
        for c in cands:                            # 同音但整句等长：取笑 → 取消
            if len(c) == len(w) and [_unit_syllable(ch) for ch in c] == want:
                return True
    return False


def looks_like_wake(text: str, words: list[str]) -> bool:
    """这句是不是"喊唤醒词喊错了字"？

    真机出过：你说「大肥鱼」，Whisper 写成「大肥大」—— 唤醒没触发，这句反而被当成
    "你要发的话"发进聊天窗口了。这种"就这么几个字、前两个音跟唤醒词一样"的短句，
    一律当唤醒处理（叮一声接着听你说），绝不往外发。
    """
    plain = re.sub(r"[\s，,。.!！?？~～…\-—_*·]+", "", text or "")
    if not plain or not words:
        return False
    for word in words:
        w = re.sub(r"[\s，,。.!！?？]+", "", word or "")
        if len(w) < 3 or len(plain) > len(w) + 1:
            continue                      # 太长的一定是正经话，不是喊错字
        want = [_unit_syllable(ch) for ch in w[:2]]        # 只看前两个音
        got = [_unit_syllable(ch) for ch in plain]
        if len(got) >= 2 and got[:2] == want:
            return True                    # 就这么几个字，前两个音对上了 → 当你在喊它
    return False


def join_sentences(parts: list[str], lang: str) -> str:
    """中文句子直接拼，英文之间补空格。"""
    if not parts:
        return ""
    if lang.startswith("zh"):
        return "".join(parts)
    out = parts[0]
    for part in parts[1:]:
        out += " " + part
    return out


def guess_mood(audio: np.ndarray, sr: int, text: str) -> str:
    """从"说得多快、多响"猜个语气，给悬浮窗调颜色和形态用。

    只看语速和音量，不做模型推断 —— 猜错也就是颜色变一下，不会有别的后果。
    """
    step = max(1, int(sr * 0.02))
    blocks = [audio[i:i + step] for i in range(0, max(1, audio.size - step), step)]
    levels = [float(np.sqrt(np.mean(np.square(b)) + 1e-12)) for b in blocks if b.size]
    if not levels:
        return ""
    peak = max(levels)
    voiced = sum(1 for v in levels if v > 0.02)
    seconds = max(0.4, voiced * 0.02)
    chars = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text or ""))
    speed = chars / seconds
    if speed >= 5.2 or peak >= 0.30:
        return "急"
    if speed <= 3.0 or peak <= 0.055:
        return "轻"
    return ""


def clear_all_data() -> int:
    """把便签/记账/记忆/日志/成就/日记全清掉，返回删了几个文件。"""
    victims = [SYSLOG_FILE, SAID_FILE, DIARY_FILE, MEM_FILE, LEDGER_FILE, ACHV_FILE,
               VP_FILE, HERE / "transcripts.md", HERE / "last.txt", HERE / "notes.md"]
    done = 0
    for path in victims:
        try:
            if path.exists():
                path.unlink()
                done += 1
        except Exception:
            pass
    return done


BACKUP_DIR = HERE / "导出"


def backup_dir() -> Path:
    """导出包 / 诊断包统一放这儿（<程序目录>\\导出），并把这个文件夹设成"隐藏"。

    以前是直接扔桌面，桌面上很快就堆一串 zip。现在好好藏起来：
    要看得见的话 —— 设置 → 功能 → 备份与诊断 → 「打开文件夹」。
    """
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(str(BACKUP_DIR), 0x02)  # 隐藏
            except Exception:
                pass
        return BACKUP_DIR
    except Exception:
        return HERE          # 实在建不出来也别往桌面写


def unique_path(path: Path) -> Path:
    """同一分钟里点了两次导出，别把前一个覆盖掉：后面挂个 -2、-3。"""
    if not path.exists():
        return path
    for i in range(2, 100):
        cand = path.with_name(f"{path.stem}-{i}{path.suffix}")
        if not cand.exists():
            return cand
    return path


def diag_pack() -> Path | None:
    """出问题时打一个"诊断包"：日志尾巴 + 配置（去掉敏感项）+ 版本环境。

    给维护的人看的时候，比"我这边好像坏了"有用得多。
    """
    import platform
    import zipfile

    out = unique_path(backup_dir() /
                      f"语音助手诊断-{datetime.now().strftime('%Y%m%d-%H%M')}.zip")
    secret = {"voice", "corrections"}
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            info = [f"时间：{datetime.now():%Y-%m-%d %H:%M:%S}",
                    f"系统：{platform.platform()}",
                    f"Python：{sys.version.split()[0]}",
                    f"目录：{HERE}"]
            try:
                import sounddevice as _sd

                info.append(f"音频设备数：{len(_sd.query_devices())}")
            except Exception:
                pass
            zf.writestr("环境.txt", "\n".join(info) + "\n")
            for name in ("voice.log", "syslog.md", "watchdog.log", "overlay-exit.log",
                         "pet-error.log", "tray-error.log", "last-crash.txt"):
                path = HERE / name
                if not path.exists():
                    continue
                try:
                    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
                    zf.writestr(name, "\n".join(lines[-400:]) + "\n")
                except Exception:
                    pass
            try:
                data = load_config()
                for k in secret:
                    data.pop(k, None)
                zf.writestr("config.json", json.dumps(data, ensure_ascii=False, indent=2))
            except Exception:
                pass
    except Exception:
        return None
    return out


def export_data() -> Path | None:
    """把数据打包（藏进导出文件夹），方便换电脑或备份。"""
    import zipfile

    out = unique_path(backup_dir() /
                      f"语音助手数据-{datetime.now().strftime('%Y%m%d-%H%M')}.zip")
    files = [SYSLOG_FILE, SAID_FILE, DIARY_FILE, MEM_FILE, LEDGER_FILE, ACHV_FILE,
             VP_FILE, CONFIG_FILE, HERE / "transcripts.md", HERE / "notes.md"]
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in files:
                if path.exists():
                    zf.write(path, path.name)
    except Exception:
        return None
    return out


def import_data() -> tuple[int, str]:
    """从最新的一份导出包里恢复数据（先备份现在的）。

    先看新的"导出"文件夹；老版本留在桌面的包也照样认。
    """
    import zipfile

    folders = [backup_dir()]
    desktop = Path(os.path.expanduser("~")) / "Desktop"
    if not desktop.is_dir():
        desktop = Path(os.path.expanduser("~")) / "桌面"
    if desktop.is_dir():
        folders.append(desktop)          # 兼容老版本直接扔桌面的包
    packs = sorted(p for folder in folders for p in folder.glob("语音助手数据-*.zip"))
    if not packs:
        return 0, "没找到导出包（设置 → 功能 → 备份与诊断 里可以导出一份）"
    newest = packs[-1]
    # 先把包整个读进内存，再备份现在的数据 —— 不然"自动备份"可能刚好和
    # 要导入的那个包撞名（同一分钟里导出两次），把源包覆盖掉，就白导了。
    try:
        with zipfile.ZipFile(newest) as zf:
            payload = [(name, zf.read(name)) for name in zf.namelist()
                       if Path(name).name == name]       # 只认平铺的文件名，防目录穿越
    except Exception as exc:  # noqa: BLE001
        return 0, f"导入失败：{type(exc).__name__}"
    backup = export_data()
    n = 0
    for name, blob in payload:
        try:
            (HERE / name).write_bytes(blob)
            n += 1
        except Exception:  # noqa: BLE001
            pass
    tip = f"，导入前的旧数据备份在 {backup.name}" if backup else ""
    return n, f"恢复了 {n} 个文件{tip}"


def newer_package() -> tuple[Path, str] | None:
    """看看旁边有没有比本机新的一份（安装包解压出来的、更新包解压出来的都算）。"""
    import importlib.util

    import version as mine

    for pkg in sorted(HERE.parent.glob("*")):
        if not pkg.is_dir() or pkg.resolve() == HERE.resolve():
            continue
        if not (pkg / "version.py").exists():
            continue
        try:
            spec = importlib.util.spec_from_file_location("pkg_version", pkg / "version.py")
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if getattr(mod, "UPDATES", 0) > mine.UPDATES:
                return pkg, getattr(mod, "APP_VERSION", "?")
        except Exception:
            continue
    return None


def apply_update(pkg: Path) -> int:
    """把安装包里更新的程序文件覆盖到本机（不动配置和模型）。"""
    keep = {"config.json", "version.py.bak"}
    copied = 0
    for path in list(pkg.glob("*.py")) + list(pkg.glob("*.ico")) + list(pkg.glob("*.png")):
        if path.name in keep:
            continue
        try:
            (HERE / path.name).write_bytes(path.read_bytes())
            copied += 1
        except Exception:
            pass
    for assets in pkg.glob("assets/*"):          # 背景图、桌宠素材这些也一起更新
        if not assets.is_file():
            continue
        try:
            target = HERE / "assets" / assets.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(assets.read_bytes())
            copied += 1
        except Exception:
            pass
    for doc in ("使用教程.html", "使用教程.md", "说明书.html", "说明书.md",
                "README-FIRST.txt", "使用说明.txt"):   # 文档也跟上
        src = pkg / doc
        if not src.is_file():
            continue
        try:
            (HERE / doc).write_bytes(src.read_bytes())
            copied += 1
        except Exception:
            pass
    return copied


def chars_per_second(audio: np.ndarray, sr: int, text: str) -> float:
    """这句话说得有多快（字/秒），疲劳提醒用它做基准。"""
    step = max(1, int(sr * 0.02))
    blocks = [audio[i:i + step] for i in range(0, max(1, audio.size - step), step)]
    voiced = sum(1 for b in blocks if b.size and float(np.sqrt(np.mean(b ** 2))) > 0.02)
    seconds = max(0.4, voiced * 0.02)
    return len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text or "")) / seconds


def decode_audio_file(path: str) -> np.ndarray:
    """读一个音频/视频文件成 16k 单声道浮点数组。"""
    from faster_whisper.audio import decode_audio

    return decode_audio(path, sampling_rate=TARGET_SR)


# ------------------------------------------------------------------ 按键监听

_VK_NAMED = {
    "space": 0x20, "空格": 0x20,
    "shift": 0x10, "ctrl": 0x11, "control": 0x11, "alt": 0x12,
    "multiply": 0x6A, "numpad*": 0x6A, "numpad+": 0x6B, "numpad-": 0x6D, "numpad/": 0x6F,
}


class KeyWatcher:
    """全局检测某个键是否被按住（不依赖窗口焦点）。"""

    def __init__(self, spec: str):
        if os.name != "nt":
            raise SystemExit("按住说话模式目前只支持 Windows。")
        user32 = ctypes.windll.user32
        user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        user32.GetAsyncKeyState.restype = ctypes.c_short
        self._user32 = user32
        self.spec = spec

        s = spec.strip().lower()
        if s in ("*", "星号"):
            # 小键盘 * 优先，同时兼容 Shift+8 打出的 *
            self._codes = [(0x6A, None)]
            self._shift_pair = (0x10, 0x38)
        elif s in ("-", "－", "减号"):
            # 主键盘的 - 键和小键盘 - 都认
            self._codes = [(0x2D, None), (0x6D, None)]
            self._shift_pair = None
        elif s in _VK_NAMED:
            self._codes = [(_VK_NAMED[s], None)]
            self._shift_pair = None
        elif len(s) == 2 and s[0] == "f" and s[1].isdigit() and 1 <= int(s[1]) <= 9:
            self._codes = [(0x6F + int(s[1]), None)]
            self._shift_pair = None
        elif s in ("f10", "f11", "f12"):
            self._codes = [(0x70 + int(s[1:]) - 10, None)]
            self._shift_pair = None
        elif len(spec.strip()) == 1:
            self._codes = [(ord(spec.strip().upper()), None)]
            self._shift_pair = None
        else:
            raise SystemExit(
                f"认不出这个键：{spec}。可以用 * / space / f9 / a ~ z / 0 ~ 9 / numpad+ 这类写法。"
            )

    def _down(self, vk: int) -> bool:
        return bool(self._user32.GetAsyncKeyState(vk) & 0x8000)

    def down(self) -> bool:
        if any(self._down(vk) for vk, _ in self._codes):
            return True
        if self._shift_pair:
            return self._down(self._shift_pair[0]) and self._down(self._shift_pair[1])
        return False


def beep(freq: int, ms: int, enabled: bool) -> None:
    """用系统提示音告诉用户"开始/结束"了，不用盯着窗口。"""
    if not enabled or os.name != "nt":
        return
    try:
        import winsound

        winsound.Beep(freq, ms)
    except Exception:
        pass


def soft_pet_notify(enabled: bool) -> None:
    """发送成功提示：沿用桌宠 poke 的低音轮廓，音量压低、快速衰减。"""
    if not enabled:
        return
    try:
        sr = 22050
        dur = .16
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        wave = (
            np.sin(2 * np.pi * 220 * t)
            + .28 * np.sin(2 * np.pi * 330 * t)
        ) * np.exp(-t * 24)
        wave *= np.minimum(1, t / .008) * .055
        sd.play(wave.astype(np.float32), sr, blocking=False)
        sd.wait()
    except Exception:
        try:
            import winsound
            winsound.Beep(220, 55)
        except Exception:
            pass


# ------------------------------------------------------- 前台窗口 / 自动发送

def _win32():
    """拿到 user32 / kernel32，并把签名配好（64 位下窗口句柄必须按指针处理）。"""
    from ctypes import wintypes

    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    if _win32.ready:
        return u, k
    u.GetForegroundWindow.restype = wintypes.HWND
    u.SetForegroundWindow.argtypes = [wintypes.HWND]
    u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.c_void_p]
    u.GetWindowThreadProcessId.restype = wintypes.DWORD
    u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    u.BringWindowToTop.argtypes = [wintypes.HWND]
    u.SetFocus.argtypes = [wintypes.HWND]
    u.IsIconic.argtypes = [wintypes.HWND]
    u.IsWindowVisible.argtypes = [wintypes.HWND]
    u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u.EnumWindows.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    u.keybd_event.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, wintypes.DWORD, ctypes.c_void_p]
    k.GetConsoleWindow.restype = wintypes.HWND
    k.GetCurrentThreadId.restype = wintypes.DWORD
    _win32.ready = True
    return u, k


_win32.ready = False


class ForegroundTracker:
    """记住"你上一個在用的窗口"，这样粘文字时不会粘到我们这个黑窗口里。"""

    SKIP = {
        "ConsoleWindowClass", "Progman", "WorkerW", "Shell_TrayWnd",
        "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow",
        "XamlExplorerHostIslandWindow", "ForegroundStaging", "ApplicationFrameWindow",
    }

    def __init__(self) -> None:
        self.console = _win32()[1].GetConsoleWindow()
        self.hwnd = 0
        self.title = ""

    def _class_name(self, hwnd: int) -> str:
        buf = ctypes.create_unicode_buffer(256)
        _win32()[0].GetClassNameW(hwnd, buf, 256)
        return buf.value

    def poll(self) -> None:
        hwnd = _win32()[0].GetForegroundWindow()
        if not hwnd or hwnd == self.console:
            return
        if self._class_name(hwnd) in self.SKIP:
            return
        buf = ctypes.create_unicode_buffer(512)
        _win32()[0].GetWindowTextW(hwnd, buf, 512)
        if not buf.value:  # 没有标题的窗口一般是辅助窗口
            return
        self.hwnd, self.title = hwnd, buf.value


def _key(vk: int, up: bool = False) -> None:
    _win32()[0].keybd_event(vk, 0, 2 if up else 0, None)
    time.sleep(0.02)


def focus_window(hwnd: int) -> bool:
    """把目标窗口切到最前面，并确认真的切过去了。

    Windows 不允许后台程序随便抢前台，所以要用 AttachThreadInput 把我们的线程
    和当前前台窗口的线程"绑"一下，再 SetForegroundWindow；不行就退回 Alt 那一招。
    """
    u = _win32()[0]
    if not hwnd:
        return False
    if u.GetForegroundWindow() == hwnd:
        return True
    if u.IsIconic(hwnd):  # 最小化了就先还原
        u.ShowWindow(hwnd, 9)  # SW_RESTORE
        time.sleep(0.25)

    our_thread = _win32()[1].GetCurrentThreadId()
    fg = u.GetForegroundWindow()
    fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
    attached = False
    if fg_thread and fg_thread != our_thread:
        attached = bool(u.AttachThreadInput(fg_thread, our_thread, True))
    try:
        u.BringWindowToTop(hwnd)
        u.SetForegroundWindow(hwnd)
    finally:
        if attached:
            u.AttachThreadInput(fg_thread, our_thread, False)

    time.sleep(0.2)
    if u.GetForegroundWindow() != hwnd:  # 兜底：敲一下 Alt 再抢一次
        _key(0x12)
        u.SetForegroundWindow(hwnd)
        _key(0x12, up=True)
        time.sleep(0.2)
    return u.GetForegroundWindow() == hwnd


def find_window(pattern: str) -> tuple[int, str]:
    """按标题关键字找一个可见窗口，返回 (句柄, 标题)。"""
    from ctypes import wintypes

    u = _win32()[0]
    hits: list[tuple[int, str]] = []
    target = pattern.lower()

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        if not u.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        if buf.value and target in buf.value.lower():
            hits.append((hwnd, buf.value))
            return False  # 找到第一个就停
        return True

    u.EnumWindows(cb, None)
    return hits[0] if hits else (0, "")


# 手机那边可以挑"这句话发到哪个聊天窗口"（手机上那个「对话窗口」页）。
# 空字符串 = 交回自动（跟电脑上的规矩：跟随前台 / 按 target 找）。
PHONE_WINDOW: dict[str, str] = {"title": "", "id": ""}

# 系统壳子类的窗口名（列"能当聊天窗口"的时候要跳过）。
# 注意：WindowTracker.SKIP 是定义在 main() 里的嵌套类，模块级拿不到它 ——
# 以前这里引用它就抛 AttributeError，被 except 吞掉，结果窗口列表永远是空的。
WINDOW_SKIP_CLASSES = {
    "ConsoleWindowClass", "Progman", "WorkerW", "Shell_TrayWnd",
    "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow",
    "XamlExplorerHostIslandWindow", "ForegroundStaging", "ApplicationFrameWindow",
    "CEF-OSC-WIDGET", "MultitaskingViewFrame", "TaskListThumbnailWnd",
    "Windows.UI.Composition.DesktopWindowContentBridge",
}
# 标题里带这些词的一般不是"聊天窗口"，是各种浮层/输入法/系统提示
WINDOW_SKIP_WORDS = ("overlay", "输入体验", "text input application",
                     "program manager", "default ime", "msctfime",
                     "windows input experience", "nvidia share")


def list_chat_windows() -> list[dict]:
    """电脑上现在有哪些窗口可以当"聊天窗口"（手机页面上列出来给人挑）。

    只挑：看得见的、有标题的、不是我们自己的、不是系统壳子的、尺寸像正经窗口的。
    同一个标题只留一个（很多程序会有一堆同名的辅助窗）。
    """
    from ctypes import wintypes

    u = _win32()[0]
    found: list[str] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        try:
            if not u.IsWindowVisible(hwnd) or is_our_window(hwnd):
                return True
            buf = ctypes.create_unicode_buffer(512)
            u.GetWindowTextW(hwnd, buf, 512)
            title = buf.value.strip()
            if not title or len(title) > 120:
                return True
            low = title.lower()
            if any(w in low for w in WINDOW_SKIP_WORDS):
                return True
            cls = ctypes.create_unicode_buffer(256)
            u.GetClassNameW(hwnd, cls, 256)
            if cls.value in WINDOW_SKIP_CLASSES:
                return True
            rect = wintypes.RECT()
            u.GetWindowRect(hwnd, ctypes.byref(rect))
            if rect.right - rect.left < 240 or rect.bottom - rect.top < 160:
                return True                      # 工具条、气泡提示不算
            if title not in found:
                found.append(title)
        except Exception:
            pass
        return True

    u.EnumWindows(cb, None)
    return [{"title": t} for t in found]


def exact_window(title: str) -> int:
    """按标题**一模一样**找窗口（比关键字匹配靠谱，避免"Codex"匹到一串）。"""
    from ctypes import wintypes

    u = _win32()[0]
    want = str(title or "").strip().lower()
    if not want:
        return 0
    hit = {"hwnd": 0}

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        if not u.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        if buf.value.strip().lower() == want:
            hit["hwnd"] = int(hwnd)
            return False
        return True

    u.EnumWindows(cb, None)
    return hit["hwnd"]


def phone_window() -> tuple[int, str]:
    """手机选了某个 Codex 会话时，目标就是 Codex 窗口。

    （用户澄清过："对话窗口"是他和我的**会话**，不是电脑窗口。会话是在 App 里点的，
    所以这里只要把目标定在 Codex 窗口上，发送前再确保它开在那个会话上就行。）
    """
    title = str(PHONE_WINDOW.get("title") or "").strip()
    if not title:
        return 0, ""
    hwnd, win_title = find_window("ChatGPT")
    if not hwnd:
        hwnd, win_title = find_window("Codex")
    return (hwnd, win_title) if hwnd else (0, "")


def set_phone_window(title: str, thread_id: str = "") -> tuple[bool, str]:
    """手机那边选会话：真的去点 App 侧栏里那个会话，让它切过去。

    传空字符串 = 切回"自动"（电脑上开着哪个就发哪个）。
    """
    title = str(title or "").strip()
    thread_id = str(thread_id or "").strip()
    if not title:
        PHONE_WINDOW["title"] = ""
        PHONE_WINDOW["id"] = ""
        saved = ""
    else:
        try:
            import codex_threads

            ok, msg = codex_threads.open_thread(title, thread_id)
        except Exception as exc:            # noqa: BLE001
            ok, msg = False, f"{type(exc).__name__}: {exc}"
        if not ok:
            return False, str(msg)[:80]
        # 点击成功不等于页面真的切过去了；确认当前会话标题再保存目标。
        try:
            actual = ""
            actual_id = ""
            for _ in range(6):
                time.sleep(0.2)
                actual = str(codex_threads.current_name() or "").strip()
                if thread_id:
                    actual_id = str(codex_threads.current_thread_id() or "").strip()
                if actual == title and (not thread_id or not actual_id or actual_id == thread_id):
                    break
            if actual and actual != title:
                return False, f"点击后仍在「{actual}」，没有切到「{title}」"
            if thread_id and actual_id and actual_id != thread_id:
                return False, f"点到同名会话「{actual}」，不是指定的那一条"
        except Exception:
            pass
        PHONE_WINDOW["title"] = title
        PHONE_WINDOW["id"] = thread_id
        saved = title
    try:                        # 记进配置，重启之后还是这个
        data = load_config()
        data["phone_target"] = saved
        data["phone_target_id"] = thread_id if saved else ""
        CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                               encoding="utf-8")
    except Exception:
        pass
    syslog("窗", f"手机切对话窗口：{saved or '自动'}")
    return True, saved or "自动"


def phone_thread_action(action: str, thread_id: str,
                        payload: dict | None = None) -> tuple[bool, str]:
    """Manage one Codex thread without writing its SQLite database directly."""
    payload = dict(payload or {})
    try:
        import codex_threads

        ok, msg = codex_threads.thread_action(action, thread_id, **payload)
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"[:120]
    if not ok:
        return False, msg

    target_id = str(PHONE_WINDOW.get("id") or "")
    if target_id == str(thread_id or ""):
        if action == "rename":
            PHONE_WINDOW["title"] = str(msg or "").strip()
            try:
                data = load_config()
                data["phone_target"] = PHONE_WINDOW["title"]
                data["phone_target_id"] = target_id
                CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
            except Exception:
                pass
        elif action == "archive" and bool(payload.get("archived", True)):
            set_phone_window("")
        elif action == "delete":
            set_phone_window("")
    return True, msg


def phone_new_thread(project_id: str = "") -> tuple[bool, str]:
    """Open Codex's new-chat screen and let phone sends follow its foreground."""
    try:
        import codex_threads

        ok, msg = codex_threads.open_new_thread(project_id)
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"[:120]
    if ok:
        set_phone_window("")
    return ok, msg


def paste_into(
    text: str,
    hwnd: int | None = None,
    press_enter: bool = True,
    clear_first: bool = True,
) -> bool:
    """把文字粘到目标窗口（默认回车发送）。返回是否真的粘到了那个窗口。

    clear_first 会先全选再粘贴，免得输入框里原有内容被一起发出去。
    """
    if not copy_to_clipboard(text):
        return False
    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    if clear_first:
        _key(0x11)          # Ctrl
        _key(0x41)          # A：全选，等一下粘贴就会把它替换掉
        _key(0x41, up=True)
        _key(0x11, up=True)
        time.sleep(0.12)
    _key(0x11)          # Ctrl
    _key(0x56)          # V
    _key(0x56, up=True)
    _key(0x11, up=True)
    time.sleep(0.18)
    if press_enter and focused:
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


def type_text_hwnd(text: str, hwnd: int | None, press_enter: bool = False) -> bool:
    """一个字一个字敲进去（走 SendInput 的 Unicode 通道），不碰剪贴板。

    有些窗口粘贴会出问题（比如聊天框里贴进去变成附件、或者把全文选中删了），
    那就用这个模式当打字机使。
    """
    if os.name != "nt" or not text:
        return False
    ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                    ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                    ("dwExtraInfo", ULONG_PTR)]

    class _U(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", ctypes.c_ulong), ("u", _U)]

    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    buf = []
    for ch in text:
        code = ord(ch)
        buf.append(INPUT(type=1, u=_U(ki=KEYBDINPUT(0, code, 0x0004, 0, 0))))
        buf.append(INPUT(type=1, u=_U(ki=KEYBDINPUT(0, code, 0x0004 | 0x0002, 0, 0))))
        if len(buf) >= 40:
            arr = (INPUT * len(buf))(*buf)
            ctypes.windll.user32.SendInput(len(buf), ctypes.byref(arr), ctypes.sizeof(INPUT))
            buf = []
            time.sleep(0.02)
    if buf:
        arr = (INPUT * len(buf))(*buf)
        ctypes.windll.user32.SendInput(len(buf), ctypes.byref(arr), ctypes.sizeof(INPUT))
    if press_enter:
        time.sleep(0.2)
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


def paste_clipboard(hwnd: int | None, press_enter: bool = True,
                    clear_first: bool = False) -> bool:
    """把"已经在剪贴板里的东西"粘到目标窗口（图/文都行），不动剪贴板本身。"""
    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    if clear_first:
        _combo(0x41, _VK_CTRL)          # Ctrl+A
    _combo(0x56, _VK_CTRL)              # Ctrl+V
    if press_enter:
        time.sleep(0.2)
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


class Recorder(_CaptureRecorder):
    """Compatibility wrapper preserving stt-level monkeypatches and logging."""

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("open_stream_fn", lambda device, rate: open_stream(device, rate))
        kwargs.setdefault("resample_fn", resample_to_16k)
        kwargs.setdefault("rms_fn", rms)
        kwargs.setdefault("syslog_fn", syslog)
        super().__init__(*args, **kwargs)


# -------------------------------------------------------------------- 识别

class Transcriber(_FeatureTranscriber):
    """Compatibility wrapper wiring local cleanup and CUDA fallback callbacks."""

    def __init__(self, model_name: str, device: str, compute_type: str | None,
                 language: str, hotwords: str = ""):
        super().__init__(
            model_name, device, compute_type, language, hotwords,
            model_root=HERE,
            cuda_ready_fn=register_cuda_dlls,
            asr_prompt=ASR_PROMPT,
            asr_lock=_ASR_LOCK,
            hallucination_fn=is_hallucination,
            normalize_fn=normalize_zh,
            target_sr=TARGET_SR,
            log=lambda text: print(text, flush=True),
        )


# ---------------------------------------------------------------------- 唤醒词自检


class _FakeStream:
    """把一段内存里的音频假装成麦克风流，好让 Recorder 走一遍真实的判停逻辑。"""

    def __init__(self, audio: np.ndarray) -> None:
        self.audio = audio
        self.i = 0

    def read(self, n: int):
        chunk = self.audio[self.i:self.i + n]
        self.i += n
        if chunk.size < n:                     # 音频放完了：模拟"一直没有下一句"
            raise EOFError("测试音频放完了")
        if chunk.ndim == 1:
            chunk = chunk.reshape(-1, 1)
        return chunk, False


def _resample(audio: np.ndarray, sr_from: int, sr_to: int) -> np.ndarray:
    if sr_from == sr_to or audio.size == 0:
        return audio
    n = int(round(audio.size * sr_to / sr_from))
    return np.interp(np.linspace(0, audio.size - 1, n),
                     np.arange(audio.size), audio).astype(np.float32)


def _onset_index(audio: np.ndarray, sr: int, floor: float = 0.02) -> int:
    """第一个"够响"的采样点。合成语音前后都有一段静音，
    要模拟"开头被吞掉"必须从真正发声的地方开始掐，不然只掐掉了静音。"""
    step = max(1, int(sr * 0.01))
    for i in range(0, max(1, audio.size - step), step):
        if rms(audio[i:i + step]) > floor:
            return i
    return 0


def simulate_capture(audio: np.ndarray, sr: int, params: dict) -> np.ndarray | None:
    """按当前档位把音频喂给真实的 Recorder，看能不能被判成"一句人话"。"""
    rec = Recorder(_FakeStream(audio), sr, 1.0, 8.0,
                   min_voiced=params["min_voiced"],
                   noise_mult=params["noise_mult"],
                   confirm=params["confirm"])
    try:
        threshold = rec.calibrate(0.4)
        return rec.record_utterance(threshold)
    except EOFError:                            # 一直没触发 → 这句没接住
        return None


def wake_selftest(transcriber, cfg: dict, log=print) -> dict:
    """唤醒词自检：合成几段测试语音，走一遍真实的"判停 → 识别 → 匹配"。"""
    name, params = wake_levels.params(cfg)
    words = [w.strip() for w in str(cfg.get("wake_word") or "").split(",") if w.strip()][:3]
    result: dict = {"ts": time.time(), "ok": True, "level": name, "params": params,
                    "wake": words, "cases": [], "passed": 0, "total": 0, "summary": ""}
    if not words:
        result.update(ok=False, summary="没设置唤醒词，跳过自检")
        return result
    try:
        import say
    except Exception as exc:  # noqa: BLE001
        result.update(ok=False, summary=f"读不到 say.py，跳过自检（{type(exc).__name__}）")
        return result

    voice = str(cfg.get("voice") or "zh-CN-XiaoyiNeural")
    rate = str(cfg.get("rate") or "+8%")
    mic_sr = 48000
    old_hot = transcriber.hotwords
    if params.get("hotwords"):
        cancels = [w.strip() for w in str(cfg.get("cancel_word") or "").split(",") if w.strip()]
        transcriber.hotwords = " ".join(words + cancels)
    else:
        transcriber.hotwords = ""
    rng = np.random.default_rng(20261007)
    # (类型, 噪声强度, 音量系数, 掐掉开头多少毫秒)：覆盖日常最容易翻车的几种情况。
    # 后面三项只测第一个唤醒词，不然词一多要跑很久。
    plan = [("干净", 0.0, 1.0, 0), ("底噪", 0.012, 1.0, 0),
            ("小声", 0.006, 0.35, 0), ("吞字", 0.0, 1.0, 120)]
    try:
        for word in words:
            try:
                mp3 = say.edge_mp3(word, voice, rate)
                audio, sr = say.decode_audio(mp3)
            except Exception as exc:  # noqa: BLE001
                result.update(ok=False, wake=words,
                              summary=f"合成测试语音失败（{type(exc).__name__}），离线时跳过自检")
                return result
            base = _resample(np.asarray(audio, dtype=np.float32), sr, mic_sr)
            for kind, noise, gain, cut_ms in (plan if word == words[0] else plan[:2]):
                clip = base * gain
                if cut_ms:                      # 模拟录音开头被吞掉一小截（从真正发声处算）
                    clip = clip[_onset_index(clip, mic_sr) + int(cut_ms / 1000 * mic_sr):]
                if noise > 0:
                    clip = clip + rng.normal(0, noise, clip.size).astype(np.float32)
                peak = float(np.max(np.abs(clip))) or 1.0
                if peak > 0.85:
                    clip = clip / peak * 0.85
                clip = np.concatenate([np.zeros(int(0.6 * mic_sr), np.float32), clip,
                                       np.zeros(int(1.6 * mic_sr), np.float32)])
                captured = simulate_capture(clip, mic_sr, params)
                text, hit = "", False
                if captured is not None and captured.size:
                    text = transcriber.transcribe(captured)
                    hit = extract_word(text, [word], fuzzy=params["fuzzy"],
                                       leading=params["leading"])[1]
                result["cases"].append({"wake": word, "kind": kind, "noise": noise,
                                        "gain": gain, "cut_ms": cut_ms,
                                        "captured": captured is not None,
                                        "text": text, "hit": bool(hit)})
                log(f"   自检 {word}·{kind} → {text!r} "
                    f"{'✓' if hit else '✗'}")
    finally:
        transcriber.hotwords = old_hot

    result["total"] = len(result["cases"])
    result["passed"] = sum(1 for c in result["cases"] if c["hit"])
    result["summary"] = build_test_summary(result, name)
    return result


# ---------------------------------------------------------------------- 主流程

def append_log(path: Path, text: str) -> None:
    _append_log(path, text, privacy_clean)


def record_ptt(recorder: Recorder) -> np.ndarray:
    return _record_ptt(recorder)


def main() -> int:
    global _heartbeat_lifecycle
    runtime_lifecycle = RuntimeLifecycle()
    _heartbeat_lifecycle = runtime_lifecycle
    saved_targets = SavedRuntimeTargets(PHONE_WINDOW, MUTE)

    entry = prepare_runtime_entry(
        RuntimeEntryDependencies(
            raw_args=sys.argv[1:],
            lifecycle=runtime_lifecycle,
            bootstrap=RuntimeBootstrapDependencies(
                setup_console=setup_console,
                make_instance_guard=lambda: SingleInstanceGuard(
                    name=VOICE_MUTEX,
                    lock_path=HERE / "instance.lock",
                ),
                load_config=load_config,
                start_plugins=lambda: start_enabled_plugins(emit=print),
                restore_saved_state=saved_targets.restore,
                detect_profile=detect_profile,
                apply_low_profile=lambda saved, profile, hardware: (
                    apply_low_profile(
                        saved, profile, hardware, CONFIG_FILE, emit=print
                    )
                ),
                build_parser=lambda saved, default_input, default_out: (
                    build_argument_parser(
                        saved,
                        default_input=default_input,
                        default_out=default_out,
                    )
                ),
                start_heartbeat=start_heartbeat,
                register_atexit=atexit.register,
                default_input=lambda saved: (
                    os.environ.get("STT_INPUT") or saved.get("input") or None
                ),
                default_out=str(HERE / "transcripts.md"),
                manual_exit=MANUAL_EXIT,
                emit=lambda text: print(text, flush=True),
            ),
            cli=RuntimeCliModeDependencies(
                list_devices=list_devices,
                foreground_tracker_factory=ForegroundTracker,
                find_window=find_window,
                paste_into=paste_into,
                transcriber_factory=Transcriber,
                append_log=append_log,
                copy_to_clipboard=copy_to_clipboard,
            ),
            audio=AudioRuntimeDependencies(
                resolve_device=resolve_device,
                open_stream=open_stream,
                input_name=lambda device: (
                    sd.query_devices(device)["name"]
                    if device is not None
                    else sd.query_devices(sd.default.device[0])["name"]
                ),
                make_transcriber=Transcriber,
                wake_params=wake_levels.params,
                wake_description=wake_levels.describe,
                make_recorder=Recorder,
                emit=lambda text: print(text, flush=True),
            ),
            make_tracker=ForegroundTracker,
            create_session_state=create_runtime_session_state,
            stop_words=DEFAULT_STOP_WORDS,
            emit=lambda text: print(text, flush=True),
        )
    )
    if entry.exit_code is not None:
        return entry.exit_code
    startup = entry.startup
    audio = entry.audio
    assert startup is not None and audio is not None
    instance_guard = startup.instance_guard
    cfg = startup.cfg
    PROFILE = startup.profile
    HW = startup.hardware
    args = startup.args

    device, stream = audio.device, audio.stream
    rate, name = audio.rate, audio.input_name
    transcriber = audio.transcriber
    mode = audio.mode
    silence = audio.silence
    level_name = audio.level_name
    level = audio.level
    wake_words = audio.wake_words
    cancel_words = audio.cancel_words
    min_voiced = audio.min_voiced
    recorder = audio.recorder
    tracker = entry.tracker
    assert entry.session_state is not None
    (spoken_flag, stop_words, self_speech, self_voice_miss, dictation,
     music, last_sent,
     hotkey, sit, hourly, fatigue, ticker, voiceprint, editing,
     pet_proc, not_heard, hint, followup, talk_state, mic_capture
     ) = entry.session_state.as_tuple()

    entrypoint_callbacks = DesktopRuntimeCallbacks(
        DesktopCallbackDependencies(
            wake_words=wake_words,
            talk_state=talk_state,
            followup_seconds=followup,
            status_provider=lambda: status,
            bump_achievements=bump_achv,
            speak=speak,
            beep=lambda freq, ms: beep(freq, ms, args.beep),
            selected_text=selected_text,
            syslog=syslog,
            emit=lambda text: print(text, flush=True),
            spoken_flag=spoken_flag,
        )
    )
    arm_followup = entrypoint_callbacks.arm_followup
    award = entrypoint_callbacks.award
    say_selected = entrypoint_callbacks.say_selected
    on_speech = entrypoint_callbacks.on_speech

    # ------------------------------------------------------------ 听写模式
    CRASH_MARK = HERE / "last-crash.txt"

    # ------------------------------------------------------------ 热键 / 定时提醒 / 开会闭嘴
    desktop = assemble_desktop_runtime(
        DesktopRuntimeDependencies(
            status_factory=Status,
            hint=hint,
            config=cfg,
            wake_words=wake_words,
            speak=speak,
            syslog=syslog,
            beep=lambda freq, ms: beep(freq, ms, args.beep),
            arm_followup=arm_followup,
            award=award,
            load_config=load_config,
            save_config=lambda data: CONFIG_FILE.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            ),
            diary_summary=diary_summary,
            read_achievements=read_achv,
            write_achievements=lambda data: ACHV_FILE.write_text(
                json.dumps(data, ensure_ascii=False),
                encoding="utf-8",
            ),
            diary_file=DIARY_FILE,
            now=datetime.now,
            notes_file=NOTES_FILE,
            ledger_file=LEDGER_FILE,
            weather_line=_personal.weather_line,
            private=PRIVATE,
            last_sent=last_sent,
            transcriber=transcriber,
            target=args.target,
            current_target_hwnd=lambda: tracker.hwnd if tracker else 0,
            query_device=sd.query_devices,
            device=device,
            find_window=find_window,
            clipboard_text=clipboard_text,
            copy_to_clipboard=copy_to_clipboard,
            paste_clipboard=paste_clipboard,
            paste_into=paste_into,
            focus_window=focus_window,
            send_ctrl_z=lambda: _combo(0x5A, _VK_CTRL),
            export_data=export_data,
            import_data=import_data,
            diag_pack=diag_pack,
            newer_package=newer_package,
            apply_update=apply_update,
            lifecycle=runtime_lifecycle,
            crash_file=CRASH_MARK,
            no_overlay=bool(args.no_overlay),
            feed=args.feed,
            test_paste=bool(args.test_paste),
            start_overlay=start_overlay,
            start_pet=start_pet,
            start_watchdog=start_watchdog,
            start_tray=start_tray,
            emit=lambda text: print(text, flush=True),
        )
    )
    status = desktop.status
    tutorial = desktop.tutorial
    tutorial_say = desktop.tutorial_say
    say_diary = desktop.say_diary
    maybe_night_diary = desktop.maybe_night_diary
    focus_active = desktop.focus_active
    focus_left = desktop.focus_left
    focus_start = desktop.focus_start
    focus_stop = desktop.focus_stop
    focus_tick = desktop.focus_tick
    read_ledger = desktop.read_ledger
    add_note = desktop.add_note
    add_ledger = desktop.add_ledger
    say_ledger = desktop.say_ledger
    say_notes = desktop.say_notes
    game_start = desktop.game_start
    do_pick = desktop.do_pick
    game_feed = desktop.game_feed
    brief_now = desktop.brief_now
    transform = desktop.transform
    overlay_process = desktop.overlay
    self_check = desktop.self_check
    do_export = desktop.do_export
    do_import = desktop.do_import
    do_diagnose = desktop.do_diagnose
    do_update = desktop.do_update
    apply_update_now = desktop.apply_update_now
    undo_last = desktop.undo_last
    type_into_focused = desktop.type_into_focused
    pet_proc = desktop.pet_proc
    config_runtime = ConfigRuntime(
        ConfigRuntimeDependencies(
            args=args,
            config=cfg,
            config_file=CONFIG_FILE,
            load_config=load_config,
            mode=mode,
            wake_words=wake_words,
            cancel_words=cancel_words,
            wake_levels=wake_levels,
            level=level,
            recorder=recorder,
            music=music,
            pet_proc=pet_proc,
            start_pet=start_pet,
            transcriber=transcriber,
            status=status,
            wake_test_file=WAKE_TEST_FILE,
            wake_selftest=wake_selftest,
            speak=speak,
            runtime_lifecycle=runtime_lifecycle,
            emit=lambda text: print(text, flush=True),
        )
    )
    reload_wake_settings = config_runtime.reload_wake_settings
    start_wake_test = config_runtime.start_wake_test
    reminder_runtime = assemble_reminder_runtime(
        ReminderRuntimeDependencies(
            config=cfg,
            ticker=ticker,
            hourly=hourly,
            sit=sit,
            fatigue=fatigue,
            mute_speak=_MUTE_SPEAK,
            in_meeting=in_meeting,
            last_input_age=last_input_age,
            speak=speak,
            syslog=syslog,
            status=status,
            now=datetime.now,
            clock=time.time,
            emit=lambda text: print(text, flush=True),
        )
    )
    maybe_reminders = reminder_runtime.run

    # ---- 手机、交互、发送后与周期服务统一交给独立装配 ----
    handle_lock = threading.RLock()
    utterance_dispatch = UtteranceDispatch(
        timeout=30,
        emit=lambda text: print(text, flush=True),
    )
    services = assemble_runtime_services(
        RuntimeServiceDependencies(
            args=args,
            config=cfg,
            config_file=CONFIG_FILE,
            app_dir=HERE,
            syslog_file=SYSLOG_FILE,
            voiceprint_file=VP_FILE,
            said_file=SAID_FILE,
            manual_exit=MANUAL_EXIT,
            status=status,
            busy=BUSY,
            mute=MUTE,
            editing=editing,
            hotkey=hotkey,
            level_state=level_state,
            phone_window_state=PHONE_WINDOW,
            voiceprint=voiceprint,
            wake_words=wake_words,
            rate=rate,
            transcriber=transcriber,
            cancel_reference_echo=cancel_reference_echo,
            handle_lock=handle_lock,
            handle_command=lambda text: utterance_dispatch.handle(
                None,
                pre_text=text,
                from_phone=True,
            ),
            speech_context=_SPEAK_CTX,
            phone_window=phone_window,
            pick_send_target=lambda: pick_send_target(
                cfg,
                args.target,
                tracker,
            ),
            focus_window=focus_window,
            press_enter=lambda: _key(0x0D),
            paste_into=paste_into,
            paste_clipboard=paste_clipboard,
            image_to_clipboard=lambda path: image_to_clipboard(
                __import__("PIL.Image", fromlist=["Image"]).open(
                    str(path)
                )
            ),
            set_phone_window=set_phone_window,
            phone_thread_action=phone_thread_action,
            phone_new_thread=phone_new_thread,
            on_stop=shut_up,
            calibrate=lambda: (
                mic_capture["recovery"].safe_calibrate()
                if mic_capture["recovery"] is not None
                else recorder.calibrate()
            ),
            record=lambda *record_args, **record_kwargs: (
                mic_capture["recovery"].safe_record(
                    *record_args,
                    **record_kwargs,
                )
                if mic_capture["recovery"] is not None
                else recorder.record_utterance(
                    *record_args,
                    **record_kwargs,
                )
            ),
            has_utterance=has_utterance,
            voice_features=voice_features,
            copy_to_clipboard=copy_to_clipboard,
            type_text_hwnd=type_text_hwnd,
            is_paused=lambda: bool(pause["paused"]),
            python_executable=sys.executable,
            load_config=load_config,
            syslog=syslog,
            speak=speak,
            shut_up=shut_up,
            beep=lambda freq, ms: beep(freq, ms, args.beep),
            read_selected=say_selected,
            do_export=do_export,
            do_import=do_import,
            do_diagnose=do_diagnose,
            start_wake_test=start_wake_test,
            runtime_lifecycle=runtime_lifecycle,
            get_reply_reader=lambda: REPLY_READER,
            reply_reader_module=importlib.import_module("reply_reader"),
            reload_phone_link=lambda: importlib.reload(phone_link),
            phone_link_module=phone_link,
            version_module=version,
            remote_access_module=remote_access,
            chat_history_module=chat_history,
            remote_factory=RemoteControl,
            self_who=self_who,
            ack_phrases=SELF_ACKS,
            list_chat_windows=list_chat_windows,
            last_sent=last_sent,
            fatigue=fatigue,
            last_unsent=LAST_UNSENT,
            chars_per_second=chars_per_second,
            privacy_clean=privacy_clean,
            verify_delivery=verify_sent_delivery,
            datetime_factory=datetime,
            background_noise=background_noise,
            reload_wake_settings=reload_wake_settings,
            focus_tick=focus_tick,
            night_diary=maybe_night_diary,
            reminders=maybe_reminders,
            overlay_process=overlay_process,
            ticker=ticker,
            start_overlay=start_overlay,
            no_overlay=bool(args.no_overlay),
            feed=bool(args.feed),
            test_paste=bool(args.test_paste),
            mic_capture=mic_capture,
            clock=time.time,
            emit=lambda text, **kwargs: print(text, **kwargs),
        )
    )
    phone_adapter = services.phone_adapter
    current_phone_thread_id = phone_adapter.current_thread_id
    current_phone_thread_name = phone_adapter.current_thread_name
    switch_phone_thread = phone_adapter.switch_thread
    public_update_url = phone_adapter.public_update_url
    phone = services.phone
    phone_ingress = phone.ingress
    pause = phone.pause
    task_store = phone.task_store
    live_codex = phone.live_codex
    phone_commands = phone.commands
    phone_state_runtime = phone.state_runtime
    phone_info_runtime = phone.info_runtime
    phone_history_deps = phone.history_deps
    phone_push = phone_commands.push
    drain_phone_commands = phone_commands.drain
    phone_worker = phone_commands.worker
    phone_got_image = phone_commands.got_image
    paste_phone_images = phone_commands.paste_images
    phone_state = phone.state
    update_source = phone.update_source
    phone_info = phone.info
    phone_schedule_list = phone.schedule_list
    phone_schedule_do = phone.schedule_do
    phone_raw_reply = phone.raw_reply
    phone_replies = phone.replies
    phone_voice = phone.voice
    phone_log = phone.history
    interaction = services.interaction
    _set_cfg = interaction.set_config
    restart_program = interaction.restart_program
    train_wake_voice = interaction.train_wake_voice
    wake_voice_ok = interaction.wake_voice_ok
    send_it = interaction.send_it
    confirm_ok = interaction.confirm_ok
    control_runtime = services.control_runtime
    check_hotkey = control_runtime.check_hotkey
    global REPLY_READER
    reply_runtime = services.reply_runtime
    REPLY_READER = reply_runtime.reader
    delivery_tracking = services.delivery_tracking
    send_gate = services.send_gate
    gate_runtime = assemble_runtime_gate_wiring(
        RuntimeGateWiringDependencies(
            speaking_now=speaking_now,
            shut_up=shut_up,
            stop_words=stop_words,
            is_stop_word=is_stop_word,
            last_unsent=LAST_UNSENT,
            pick_send_target=lambda: pick_send_target(
                cfg,
                args.target,
                tracker,
            ),
            send=send_it,
            busy=BUSY,
            status=status,
            speak=speak,
            syslog=syslog,
            emit=lambda text: print(text, flush=True),
            mute=MUTE,
            mute_command=mute_command,
            dispatch_mute=dispatch_mute_command,
            self_speech=self_speech,
            self_voice_miss=self_voice_miss,
            self_spoken_text=self_spoken_text,
            recent_spoken=recent_spoken,
            sounds_like=sounds_like,
            repeated_after_miss=repeated_after_miss,
            extract_word=extract_word,
            wake_words=wake_words,
            wake_level=level,
            dictation=dictation,
            is_standalone_command=is_standalone_command,
            dispatch_dictation=_talk.dispatch_dictation_action,
            beep=lambda freq, ms: beep(freq, ms, args.beep),
            type_text=type_into_focused,
            syslog_file=SYSLOG_FILE,
            cancel_words=cancel_words,
            listen_timeout=float(args.wake_timeout),
            talk_state=talk_state,
            looks_like_wake=looks_like_wake,
            cancel_hit=cancel_hit,
            wake_voice_ok=wake_voice_ok,
            award=award,
            arm_followup=arm_followup,
            once=bool(args.once),
        )
    )
    command_gate = gate_runtime.command_gate
    wake_gate = gate_runtime.wake_gate
    finish_structured_action = gate_runtime.finish_structured_action

    utterance_dispatch.bind(assemble_utterance_runtime(
        RuntimeUtteranceDependencies(
            args=args,
            config=cfg,
            config_file=CONFIG_FILE,
            app_dir=HERE,
            mode=mode,
            rate=rate,
            transcriber=transcriber,
            status=status,
            not_heard=not_heard,
            voiceprint=voiceprint,
            editing=editing,
            last_sent=last_sent,
            music=music,
            private=PRIVATE,
            tutorial=tutorial,
            busy=BUSY,
            target=args.target,
            tracker=tracker,
            command_gate=command_gate,
            wake_gate=wake_gate,
            send_gate=send_gate,
            delivery_tracking=delivery_tracking,
            task_store=task_store,
            cancel_reference_echo=cancel_reference_echo,
            not_heard_due=not_heard_due,
            speak=speak,
            syslog=syslog,
            emit=print,
            append_log=append_log,
            guess_mood=guess_mood,
            canonize=canonize,
            apply_corrections=apply_corrections,
            is_hallucination=is_hallucination,
            voice_enroll=voice_enroll,
            voice_score=voice_score,
            is_standalone_command=is_standalone_command,
            phone_new_thread=phone_new_thread,
            set_phone_window=set_phone_window,
            done=finish_structured_action,
            arm_followup=arm_followup,
            load_config=load_config,
            beep=lambda freq, ms: beep(freq, ms, args.beep),
            run_shortcut=run_shortcut,
            parse_repeat=parse_repeat,
            syslog_search=syslog_search,
            weekly_report=weekly_report,
            find_window=find_window,
            press_key=_key,
            open_named=open_named,
            paste_clipboard=paste_clipboard,
            grab_screen=grab_screen,
            get_reply_reader=lambda: REPLY_READER,
            focus_active=focus_active,
            focus_left=focus_left,
            focus_start=focus_start,
            focus_stop=focus_stop,
            transform=transform,
            brief_now=brief_now,
            say_diary=say_diary,
            tutorial_say=tutorial_say,
            game_feed=game_feed,
            game_start=game_start,
            say_ledger=say_ledger,
            say_notes=say_notes,
            add_ledger=add_ledger,
            add_note=add_note,
            clear_all_data=clear_all_data,
            undo_last=undo_last,
            do_export=do_export,
            do_import=do_import,
            do_update=do_update,
            apply_update_now=apply_update_now,
            diag_pack=diag_pack,
            self_check=self_check,
            train_wake_voice=train_wake_voice,
            set_config=_set_cfg,
            schedule_restart=lambda: threading.Timer(
                1.0, restart_program
            ).start(),
            read_selected=say_selected,
            start_reminder=start_reminder,
            copy_to_clipboard=copy_to_clipboard,
            send_it=send_it,
            confirm_ok=confirm_ok,
            soft_pet_notify=soft_pet_notify,
            ack_phrase=ack_phrase,
            clock=time.time,
        )
    ))
    handle = utterance_dispatch.handle

    return run_prepared_foreground(
        PreparedForegroundDependencies(
            entry=entry,
            handle=handle,
            handle_lock=handle_lock,
            services=services,
            status=status,
            lifecycle=runtime_lifecycle,
            on_speech=on_speech,
            platform=ForegroundPlatformDependencies(
                find_window=find_window,
                paste_text=paste_into,
                record_ptt=record_ptt,
                has_utterance=has_utterance,
                level_state=level_state,
                resolve_device=resolve_device,
                open_stream=open_stream,
                make_recorder=Recorder,
                syslog=syslog,
                shut_up=shut_up,
                speaking_now=speaking_now,
                duplex=DUPLEX,
                cancel_reference_echo=cancel_reference_echo,
                spectrum_bands=spectrum_bands,
                transcriber=transcriber,
                key_watcher_factory=KeyWatcher,
                tracker_worker_factory=ForegroundTrackerWorker,
                start_scheduler=start_scheduler,
                build_greeting=build_greeting,
                speak_greeting=speak_greeting,
                speak=speak,
                beep=lambda freq, ms: beep(freq, ms, args.beep),
                crash_file=CRASH_MARK,
                emit=lambda text: print(text, flush=True),
                decode_audio_file=decode_audio_file,
                target_rate=TARGET_SR,
            ),
        )
    )


if __name__ == "__main__":
    raise SystemExit(main())
