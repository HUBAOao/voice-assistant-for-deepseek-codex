#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
语音转文字（本地离线，faster-whisper）

麦克风说话 -> 本地识别 -> 打印 + 自动复制到剪贴板 + 追加写入 transcripts.md

用法示例：
    python stt.py                  # 按住 * 说话，松开就识别（默认）
    python stt.py --key f9         # 换成按住 F9 说话
    python stt.py --mode auto      # 不用按键：直接说话，停顿后自动识别
    python stt.py --ptt            # 回车开始录音，再回车结束
    python stt.py --once           # 只识别一句就退出
    python stt.py --list-devices   # 查看麦克风设备
    python stt.py --input USB      # 用名字包含 USB 的麦克风
    python stt.py --model large-v3 # 换更大的模型（更准、更慢）
"""

from __future__ import annotations

import argparse
import collections
import ctypes
import importlib
import json
import os
import re
import subprocess
import sys
import threading
import time
import webbrowser
import random
from datetime import datetime
from pathlib import Path

import numpy as np
import sounddevice as sd

import wake_levels
import reply_reader
import phone_link
import version                      # 署名 / 版权 / 版本号都从这儿来（手机设置里那一栏也要用）
import remote_access                # 外网访问（Tailscale）状态：手机设置里要显示
import screen_share
import file_share

HERE = Path(__file__).resolve().parent
TARGET_SR = 16000
STATUS_FILE = HERE / "status.json"
CONTROL_FILE = HERE / "control.json"
CONFIG_FILE = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"     # 唤醒词自检结果，写出来给悬浮窗显示
SPEAK_STATUS_FILE = HERE / "speak.json"
SPEAK_STOP_FILE = HERE / "speak_stop.json"   # 写一下就＝让正在念的那句立刻闭嘴
ACHV_FILE = HERE / "achievements.json"
DIARY_FILE = HERE / "diary.md"
SAID_FILE = HERE / "said.md"                 # 只记"真的说给它听"的句子（给日记用）
SYSLOG_FILE = HERE / "syslog.md"             # 系统日志：说过什么、它做了什么，全记
NOTES_FILE = HERE / "notes.md"               # 便签
LEDGER_FILE = HERE / "ledger.json"           # 记账本
MANUAL_EXIT = HERE / "manual-exit.json"      # 你自己点的"退出"：看门狗看到它就不重启
HEARTBEAT = HERE / "heartbeat.json"          # 心跳：不管我在忙什么，每 5 秒写一次
OVERLAY_READY = HERE / "overlay_ready.json"  # 悬浮窗"我把窗口显示出来了"的回执
REPLY_READER = None                          # 「自动念回答」的后台线程（见 reply_reader.py）
VOICE_MUTEX = "VoiceAssistantVoice_v1"
_mutex_handle = None  # 保住句柄，进程活着它就活着
_ASR_LOCK = threading.Lock()   # 自检和正常识别可能同时想用模型，串起来
# 开会自动闭嘴：为真时 speak() 只写字幕不出声
_MUTE_SPEAK = {"on": False}
# 它最近念过的话。判断"这句是不是它自己在说"要用——念完之后 speak.json 里的字就没了，
# 光靠那个文件会漏判（漏判的后果是它把自己的问候当指令发出去）
_SPOKEN: list[tuple[float, str]] = []

# ---------------------------------------------------------------- 隐私
# 说到这些词，那一行就不记原文（或者干脆不记）
PRIVACY_WORDS = ("密码", "口令", "验证码", "身份证", "银行卡", "信用卡", "手机号",
                 "账号", "密钥", "token", "api key", "private key", "社保", "护照")
PRIVATE = {"until": 0.0, "clear_ask": False}   # "别记这段" 的临时静默期；清空确认


def privacy_until() -> bool:
    return time.time() < PRIVATE["until"]


def privacy_clean(text: str) -> str:
    """落盘前过一道隐私：静默期整句不记；敏感词那句打码。"""
    if privacy_until():
        return "（这几分钟按你说的不记录）"
    low = (text or "").lower()
    if any(w in low for w in PRIVACY_WORDS):
        return "（这行含敏感词，已隐去）"
    return text


def privacy_note(text: str) -> bool:
    """这句要不要因为隐私不打码地记？（给调用方判断用）"""
    return not privacy_until() and not any(
        w in (text or "").lower() for w in PRIVACY_WORDS)


def remember_spoken(text: str) -> None:
    text = (text or "").strip()
    if not text:
        return
    _SPOKEN.append((time.time(), text))
    del _SPOKEN[:-6]


def recent_spoken(window: float = 20.0) -> list[str]:
    now = time.time()
    return [t for ts, t in _SPOKEN if now - ts <= window]


def show_instead_of_speaking(text: str) -> None:
    """开会模式下不出声，但要把这句话放到字幕位（status.json 的 text 字段）。"""
    try:
        data = json.loads(STATUS_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    data.update({"text": text[:80], "ts": time.time()})
    try:
        tmp = STATUS_FILE.with_name("status.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp.replace(STATUS_FILE)
    except Exception:
        pass


def syslog(tag: str, text: str) -> None:
    """系统日志：你说过什么、它发了什么、念了什么、做了什么动作，全记一行。

    文件太大就砍掉前面一半，免得无限长大。
    """
    text = privacy_clean(text)
    line = f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} [{tag}] {text}\n"
    try:
        with SYSLOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(line)
        if SYSLOG_FILE.stat().st_size > 2_000_000:
            keep = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
            SYSLOG_FILE.write_text("\n".join(keep[-4000:]) + "\n", encoding="utf-8")
    except Exception:
        pass


def syslog_search(keywords: list[str], limit: int = 5) -> list[str]:
    """在系统日志里找同时包含这些词的行（最近的优先）。"""
    words = [w for w in (keywords or []) if w]
    if not words:
        return []
    try:
        lines = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    hits = [ln for ln in lines if all(w in ln for w in words)]
    return hits[-limit:][::-1]


def acquire_single_instance(name: str = VOICE_MUTEX) -> bool:
    """同一时间只允许一个语音程序：两个一起跑会重复发送、抢状态文件。"""
    global _mutex_handle
    if os.name != "nt":
        return True
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateMutexW.restype = ctypes.c_void_p
    k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
    _mutex_handle = k32.CreateMutexW(None, False, name)
    if not _mutex_handle:
        return True  # 拿不到句柄就算了，别拦着人家用
    return ctypes.get_last_error() != 183  # ERROR_ALREADY_EXISTS


class Status:
    """把当前状态写给悬浮窗看（原子替换，避免读到半个文件）。"""

    def __init__(self, hint: str = "") -> None:
        self.hint = hint
        self.pid = os.getpid()
        self._last_level = 0.0
        self.state = "starting"
        self.mood = ""            # 语气：急 / 平常 / 轻（悬浮窗拿它调颜色和形态）
        self.mood_ts = 0.0        # 语气是什么时候判出来的（悬浮窗过一会儿就不认了）
        self.bands: list = []     # 音浪柱子高度（0~1），开启音浪模式时才有
        self.focus = 0.0          # 番茄钟还剩多少秒（0 = 没在专注）
        self._last: dict = {}

    def set(self, state: str, text: str | None = None, hint: str | None = None,
            level: float = 0.0, mood: str | None = None,
            focus: float | None = None) -> None:
        self.state = state
        if mood is not None:
            self.mood = mood
            self.mood_ts = time.time()
        if focus is not None:
            self.focus = focus
        data = {
            "state": state,
            "text": text or "",
            "hint": hint if hint is not None else self.hint,
            "level": round(min(1.0, max(0.0, level)), 3),
            "mood": self.mood,
            "mood_ts": round(self.mood_ts, 2),
            "bands": self.bands,
            "focus": round(max(0.0, self.focus), 1),
            "ts": time.time(),
            "pid": self.pid,
        }
        self._write(data)

    def patch(self, **fields) -> None:
        """只改几个字段（比如番茄钟倒计时），别动状态和字幕。"""
        data = dict(getattr(self, "_last", {}) or {})
        if not data:
            return
        if "focus" in fields:
            self.focus = float(fields["focus"])
        data.update({k: v for k, v in fields.items()})
        data["ts"] = time.time()
        self._write(data)

    def set_mood(self, mood: str) -> None:
        """语气只在"真听懂了"的时候才盖章；空字符串表示恢复平常。"""
        self.mood = mood or ""
        self.mood_ts = time.time() if mood else 0.0
        self.patch(mood=self.mood, mood_ts=round(self.mood_ts, 2))

    def _write(self, data: dict) -> None:
        self._last = dict(data)
        try:
            tmp = STATUS_FILE.with_name("status.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            for attempt in range(3):
                # 悬浮窗可能正开着这个文件读，Windows 下替换会偶发失败，重试一下
                try:
                    tmp.replace(STATUS_FILE)
                    break
                except OSError:
                    if attempt == 2:
                        raise
                    time.sleep(0.02)
        except Exception:
            pass

    def level(self, level: float, state: str = "hearing", text: str = "",
              bands: list | None = None) -> bool:
        """录音过程中高频更新音量（给悬浮窗做跳动效果），限流到 ~7 次/秒。"""
        now = time.time()
        if now - self._last_level < 0.15:
            return False
        self._last_level = now
        if bands is not None:
            self.bands = bands
        self.set(state, text=text, level=level)
        return True


class RemoteControl:
    """读悬浮窗按钮写下的命令（暂停 / 继续）。

    悬浮窗是独立进程，直接调函数不行，所以用一个小文件当"信箱"：
    浮窗写 control.json，这边每 0.25 秒看一眼，时间戳比上次新就执行。
    """

    def __init__(self, on_action) -> None:
        self.on_action = on_action
        # 记住"我启动之前"最后一条命令的时间戳：旧命令不能拿来执行，
        # 否则上一轮点过的暂停会让新启动的程序一上来就停着。
        try:
            self.last_ts = float(json.loads(CONTROL_FILE.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            self.last_ts = 0.0
        self.next_check = 0.0
        self._apply(action=None)

    def _apply(self, action: str | None) -> None:
        if action:
            self.on_action(action)

    def poll(self) -> None:
        now = time.time()
        if now < self.next_check:
            return
        self.next_check = now + 0.25
        try:
            data = json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= self.last_ts:
            return
        self.last_ts = ts
        self._apply(str(data.get("action") or ""))


def start_heartbeat() -> None:
    """独立心跳线程：不管主循环在忙什么（录长句、训练唤醒词），每 5 秒写一次。

    看门狗原来靠"status.json 新不新"判断死没死，结果主循环一忙 40 秒就被误判成
    挂了、多拉一个进程起来（虽然被单实例锁挡住，但日志会吓人）。
    """
    def beat() -> None:
        while True:
            try:
                HEARTBEAT.write_text(
                    json.dumps({"pid": os.getpid(), "ts": time.time()}), encoding="utf-8")
            except Exception:
                pass
            time.sleep(5)

    t = threading.Thread(target=beat, daemon=True)
    t.start()


def start_overlay() -> subprocess.Popen | None:
    """把悬浮窗拉起来（用 pythonw，不闪黑框）。

    起来之后要等它写一张"我已经把窗口显示出来了"的回执（overlay_ready.json）。
    为什么要这么麻烦：pythonw 没有控制台，悬浮窗要是崩了、卡住了、或者窗口建出来
    但是透明的（看不见），主程序这边完全不知道 —— 用户就看到"有语音、没悬浮窗"。
    现在超过 6 秒没回执就重来一次，还不行就说出原因，让用户知道自己该怎么办。
    """
    script = HERE / "overlay.py"
    if not script.exists():
        return None
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
    detail = ""
    for attempt in (1, 2):
        try:
            OVERLAY_READY.unlink()
        except OSError:
            pass
        started = time.time()
        # 把悬浮窗的报错接到日志上：它要是"模块级导入"就炸了（比如缺 Pillow），
        # 根本没走到自己的错误处理，什么都留不下 —— 用户那边就是"没悬浮窗也没报错"。
        err_fh = None
        try:
            err_fh = open(HERE / "overlay-error.log", "a", encoding="utf-8",
                          errors="replace")
            err_fh.write(f"\n=== 启动悬浮窗 {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            err_fh.flush()
        except Exception:
            err_fh = None
        try:
            proc = subprocess.Popen([str(runner), str(script)], cwd=str(HERE),
                                    creationflags=flags, stderr=err_fh)
        except Exception as exc:  # noqa: BLE001
            print(f"（悬浮窗没起来：{exc}）")
            return None
        detail = wait_overlay_ready(started, 12.0 if attempt == 1 else 15.0, proc)
        if err_fh is not None:
            try:
                err_fh.close()
            except Exception:
                pass
        if not detail:
            return proc
        detail = overlay_failure_reason(detail)
        print(f"（悬浮窗第 {attempt} 次没起来：{detail}）")
        try:
            proc.kill()
        except Exception:
            pass
        time.sleep(0.6)
    # 两次都不行：语音还能用，但要让你知道，而且告诉你日志在哪
    try:
        if any(k in detail for k in ("No module named", "ImportError", "DLL load failed")):
            # 最常见的就是这个：新装的机器缺运行库（Pillow / pystray）
            speak("缺一个运行库，双击程序目录里的「修复依赖」就能装好，语音还能用")
        else:
            speak("悬浮窗起不来，语音还能用。日志在程序目录，文件名是 overlay-error 点 log")
    except Exception:
        pass
    syslog("浮", f"悬浮窗起不来：{detail}")
    print("   （如果是缺运行库：双击程序目录里的「修复依赖.cmd」就能补上）", flush=True)
    return None


def wait_overlay_ready(started: float, timeout: float = 12.0, proc=None) -> str:
    """等悬浮窗的"准备好了"回执。成功返回空串，否则返回一句原因。

    顺便盯着进程：它要是刚起来就退了（比如缺 Pillow 这种导入错误），
    立刻就能说出"起后就退了"，不用白等十几秒。
    """
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc is not None and proc.poll() is not None:
            time.sleep(0.4)          # 让它把 stderr 写完
            return f"它起来后就退了（退出码 {proc.returncode}）"
        try:
            data = json.loads(OVERLAY_READY.read_text(encoding="utf-8"))
            if float(data.get("ts") or 0) >= started:
                if not data.get("visible", True):
                    return "窗口建出来了，但是没显示（可能在屏幕外面）"
                return ""
        except Exception:  # noqa: BLE001
            pass
        time.sleep(0.25)
    return f"{timeout:.0f} 秒之内没把窗口显示出来"


def overlay_failure_reason(fallback: str) -> str:
    """能读到崩溃日志就用日志里最后一句，读不到就用兜底说法。"""
    log = HERE / "overlay-error.log"
    try:
        lines = [ln for ln in log.read_text(encoding="utf-8", errors="replace").splitlines()
                 if ln.strip()]
        if lines:
            return lines[-1].strip()[:200]
    except Exception:  # noqa: BLE001
        pass
    exit_log = HERE / "overlay-exit.log"
    try:
        lines = [ln for ln in exit_log.read_text(encoding="utf-8", errors="replace").splitlines()
                 if ln.strip()]
        if lines:
            return lines[-1].strip()[:200]
    except Exception:  # noqa: BLE001
        pass
    return fallback


def start_pet() -> subprocess.Popen | None:
    """把桌宠拉起来（素材不在就跳过）。"""
    script = HERE / "pet.py"
    if not script.exists() or not (HERE / "assets" / "pet").is_dir():
        return None
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        proc = subprocess.Popen([str(runner), str(script)], cwd=str(HERE), creationflags=flags)
        print("桌宠已就位（DeepSeek 娘会在桌面上走来走去）")
        return proc
    except Exception as exc:  # noqa: BLE001
        print(f"（桌宠没起来：{exc}）")
        return None


def start_tray() -> None:
    """右下角托盘图标：浮窗关了也能从那里找回来。"""
    script = HERE / "tray.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([str(runner), str(script)], cwd=str(HERE), creationflags=flags)
        print("托盘图标已就位（右下角）")
    except Exception:
        pass


def start_watchdog() -> None:
    """把看门狗也拉起来：它会在主程序挂掉时自动重启（自己带单实例锁）。"""
    script = HERE / "watchdog.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([str(runner), str(script)], cwd=str(HERE), creationflags=flags)
        print("看门狗已就位（主程序挂掉会自动重启）")
    except Exception:
        pass


def build_greeting(cfg: dict, wake: str) -> str:
    """把问候语里的占位符换掉：{name} 名字、{wake} 唤醒词、{time} 早上/中午/下午/晚上。"""
    text = str(cfg.get("greeting_text") or "").strip()
    if not text:
        return ""
    hour = datetime.now().hour
    if 5 <= hour < 11:
        part = "早上"
    elif 11 <= hour < 13:
        part = "中午"
    elif 13 <= hour < 18:
        part = "下午"
    else:
        part = "晚上"
    return (text.replace("{name}", str(cfg.get("name") or "语音助手"))
                .replace("{wake}", wake or "语音助手")
                .replace("{user}", str(cfg.get("user_name") or ""))
                .replace("{time}", part))


# 用"自称"说的应答语：{w} 就是自称（比如「大肥鱼这就办」）
SELF_ACKS = ("{w}这就办", "{w}收到", "{w}来了", "好嘞，{w}这就去", "{w}马上办",
             "{w}记住了", "交给{w}吧", "好，{w}出手", "{w}来啦", "{w}在呢")
# 自称说的勤不勤：三档
SELF_RATE = {"off": 0.0, "sometimes": 0.35, "often": 0.75}


def self_who(cfg: dict) -> str:
    """自称是哪几个字（自称关掉、或者名字空着，就是空串）。"""
    if not bool(cfg.get("self_talk", True)):
        return ""
    return str(cfg.get("self_name") or cfg.get("name") or "").strip()


def self_chance(cfg: dict) -> float:
    """这次要不要用自称来说话（0 = 不说，越大越爱说）。"""
    return SELF_RATE.get(str(cfg.get("self_freq") or "sometimes"), 0.35)


def ack_phrase(cfg: dict) -> str:
    """用户说完一句之后的那句应答。

    「应答语」里可以写**好几条**，用 | 或者换行隔开，每次随机挑一条说
    （比如「好的我这就做|好嘞|收到|来了」），听着就不会那么机械。
    有时候会用**自称**来说这句（「大肥鱼这就办」），
    再按频率决定要不要在末尾带上你对它的称呼。
    """
    raw = str(cfg.get("ack_text") or "我知道了")
    parts = [p.strip() for p in re.split(r"[|\n；;]+", raw) if p.strip()]
    base = random.choice(parts) if parts else "我知道了"
    who = self_who(cfg)
    if who and random.random() < self_chance(cfg):
        base = random.choice(SELF_ACKS).format(w=who)      # 用自称说
    user = str(cfg.get("user_name") or "").strip()
    freq = str(cfg.get("name_freq") or "sometimes")
    if user and freq in ("sometimes", "often"):
        if freq == "often" or random.random() < 0.4:
            base = f"{base}，{user}"
    return base


def self_phrase(cfg: dict, what: str = "完成任务啦") -> str:
    """可爱的自称，比如「大肥鱼完成任务啦」。

    三档频率（设置 → 基本 → 「自称频率」）：off 从不说 / sometimes 有时 /
    often 经常。关掉自称、或者这次不轮到它，就返回空串（调用处直接跳过）。
    """
    who = self_who(cfg)
    if not who:
        return ""
    if random.random() > self_chance(cfg):
        return ""
    return f"{who}{what}"


def speak_greeting(text: str, delay: float = 3.0) -> None:
    """开机问候：过几秒再念，别和启动时的杂音撞一起。用独立进程念，互不干扰。"""
    if not text:
        return
    script = HERE / "say.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0

    def later() -> None:
        time.sleep(max(0.0, delay))
        try:
            remember_spoken(text)
            subprocess.Popen([str(runner), str(script), text], cwd=str(HERE), creationflags=flags)
            syslog("念", f"（开机问候）{text}")
            print(f"（已经念了开机问候：{text}）", flush=True)
        except Exception as exc:  # noqa: BLE001
            print(f"（开机问候没念出来：{exc}）", flush=True)

    threading.Thread(target=later, daemon=True).start()


def speak(text: str, wait: bool = False) -> None:
    """让 say.py 念一句（独立进程，不干扰识别）。

    wait=True：等它念完再返回 —— 朗读排队用（一次只出一句，绝不重叠出声）。
    """
    remember_spoken(text)
    if _MUTE_SPEAK["on"]:            # 开会模式：只出字幕不出声
        syslog("念", f"（开会中，改口型）{text[:60]}")
        show_instead_of_speaking(text)
        return
    syslog("念", text)
    script = HERE / "say.py"
    if not script.exists():
        return
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        proc = subprocess.Popen([str(runner), str(script), text], cwd=str(HERE),
                                creationflags=flags)
        if wait:
            proc.wait()
    except Exception:
        pass


# ------------------------------------------------------------------ 提醒 / 定时
_UNITS = {"秒": 1, "分钟": 60, "分": 60, "小时": 3600, "个小时": 3600, "钟头": 3600}
_CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
           "七": 7, "八": 8, "九": 9, "十": 10}


def cn_number(raw: str) -> float | None:
    """把"十""半""二十五"这类中文数字换成数字；认不出来返回 None。"""
    raw = (raw or "").strip()
    if not raw:
        return None
    if raw.isdigit():
        return float(raw)
    if raw == "半":
        return 0.5
    if raw in _CN_NUM:
        return float(_CN_NUM[raw])
    if "十" in raw:
        head, _, tail = raw.partition("十")
        return float(_CN_NUM.get(head, 1) * 10 + (_CN_NUM.get(tail, 0) if tail else 0))
    return None


_REMIND_PATTERNS = [
    re.compile(r"([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:之后|以后|后)?\s*(?:提醒我|提醒|叫我|喊我|告诉)\s*[,，:：]?\s*(.*)"),
    re.compile(r"(?:提醒我|提醒|叫我|喊我|告诉我)\s*[,，:：]?\s*([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:之后|以后|后)?\s*(.*)"),
    re.compile(r"(?:定|设)?\s*(?:个)?\s*([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:的)?\s*(?:闹钟|定时|提醒)\s*(.*)"),
]


def parse_reminder(text: str):
    """识别"10 分钟后提醒我喝水"这类说法，返回 (秒数, 提醒内容)。"""
    for pattern in _REMIND_PATTERNS:
        m = pattern.search(text)
        if not m:
            continue
        count = cn_number(m.group(1))
        if not count:
            continue
        unit = m.group(2)
        what = (m.group(3) or "").strip("。，,.！! ")
        seconds = count * _UNITS.get(unit, 60)
        if 0 < seconds <= 12 * 3600:
            return max(1, int(seconds)), (what or "时间到了")
    return None


# ---------------------------------------------------------------- 番茄钟

_FOCUS_TIME = re.compile(r"([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|钟头)")


def parse_focus(text: str) -> int | None:
    """识别番茄钟/专注：返回分钟数；-1 表示"结束"；不是这类话返回 None。

    故意收得紧一点：光说"专注"不算，得带"番茄钟""专注模式""开始专注"或者时长，
    不然"我要专注工作"这种聊天会被当成下令。
    """
    if not text:
        return None
    plain = text.replace(" ", "")
    if any(w in plain for w in ("结束专注", "结束番茄", "停止专注", "停止番茄", "退出专注")):
        return -1
    hit = ("番茄钟" in plain or "番茄" in plain
           or "专注模式" in plain or "开始专注" in plain or "专注计时" in plain)
    m = _FOCUS_TIME.search(plain)
    if not hit and not (m and "专注" in plain):
        return None
    if "还剩" in plain or "还有多久" in plain or "剩多久" in plain:
        return 0                        # 0 = 只问还剩多久
    if m:
        count = cn_number(m.group(1)) or 25
        minutes = count * 60 if m.group(2) in ("小时", "个小时", "钟头") else count
    else:
        minutes = 25                    # 经典的番茄钟时长
    return max(1, min(180, int(minutes)))


# ---------------------------------------------------------------- 便签 / 记账

_NOTE_HEADS = ("记一下", "记一笔笔记", "记个笔记", "记笔记", "记下", "备忘", "帮我记")
_LEDGER_HEADS = ("记一笔", "记账", "花了", "花销", "支出", "买了")
_QUERY_NOTE = ("念一下笔记", "我记了什么", "念笔记", "看看笔记", "我的笔记")
_QUERY_LEDGER = ("花了多少", "花了多少钱", "今天花了", "这个月花了", "账本", "记的账")


def parse_note(text: str) -> str | None:
    """识别"记一下 XXX"。返回要记的内容。"""
    plain = (text or "").strip()
    for head in _NOTE_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1].strip("。，,.！!：: ")
            body = re.sub(r"^[一下个点把]+", "", body).strip("。，,.！!：: ")
            return body or None
    return None


def parse_ledger(text: str) -> tuple[str, float] | None:
    """识别"记一笔 买菜 30""买咖啡花了32块"。返回 (名目, 金额)。"""
    plain = (text or "").replace(" ", "")
    if not plain or not any(h in plain for h in _LEDGER_HEADS):
        return None
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:块|元|块钱|毛|角)?", plain)
    if not m:
        return None
    amount = float(m.group(1))
    if "毛" in plain or "角" in plain:
        amount = amount / 10
    name = plain
    for head in _LEDGER_HEADS:
        name = name.replace(head, "")
    name = re.sub(r"(\d+(?:\.\d+)?)\s*(?:块|元|块钱|毛|角)?", "", name)
    # 只去掉"我/今天/花了"这类纯前缀；"买""打"开头可能是名目本身（买菜、打车），别乱砍
    name = re.sub(r"^(?:我|你|刚刚|刚才|今天|今早|昨晚)", "", name)
    name = re.sub(r"^(?:买了|花了|付了|打了|花了钱)", "", name)
    name = name.strip("。，,.！!：:的了 ")
    return (name or "没写名目", amount)


# ---------------------------------------------------------------- 小游戏

_GAME_START = {
    "guess": ("猜数字", "猜个数", "玩猜数字"),
    "pick": ("帮我决定", "帮我选", "做个选择", "帮我挑"),
}
_GAME_STOP = ("不玩了", "结束游戏", "退出游戏", "别玩了")


def parse_game(text: str) -> tuple[str, str] | None:
    """识别小游戏指令，返回 (游戏, 附带内容)。"""
    plain = (text or "").replace(" ", "")
    if not plain:
        return None
    if any(w in plain for w in _GAME_STOP):
        return ("stop", "")
    for game, words in _GAME_START.items():
        for w in words:
            if w in plain:
                return (game, plain.split(w, 1)[1].strip("。，,.！!：: "))
    return None


# ---------------------------------------------------------------- 早间播报 / 变身

_BRIEF_WORDS = ("早间播报", "今天什么安排", "今天有什么安排", "今天的安排", "播报一下",
                "今天怎么样", "早上好")
_TRANSFORM_WORDS = ("变身", "换个样子", "换个造型", "换个主题", "换皮肤")


def parse_brief(text: str) -> bool:
    return any(w in (text or "").replace(" ", "") for w in _BRIEF_WORDS)


def parse_transform(text: str) -> bool:
    return any(w in (text or "").replace(" ", "") for w in _TRANSFORM_WORDS)


# ---------------------------------------------------------------- 闭嘴 / 闭麦

DEFAULT_STOP_WORDS = ["停", "停下", "别念了", "别说了", "闭嘴", "安静", "不用念了"]


def is_stop_word(text: str, words: list[str] | None = None) -> bool:
    """一喊就让它闭嘴。只认很短的句子，免得正常说话里带个"停"就误伤。"""
    plain = (text or "").strip("。，,.！!？? ")
    if not plain or len(plain) > 8:
        return False
    for w in (words or DEFAULT_STOP_WORDS):
        if not w:
            continue
        # 两个词以上：出现在短句里就算（"你安静点"）；单字口令要更严格，不然"停车位"会误伤
        if len(w) >= 2 and w in plain and len(plain) <= len(w) + 3:
            return True
        if plain == w or (plain.startswith(w) and len(plain) <= len(w) + 2):
            return True
    return False


def speaking_now() -> bool:
    """朗读进程现在是不是正在出声。"""
    try:
        data = json.loads(SPEAK_STATUS_FILE.read_text(encoding="utf-8"))
        return bool(data.get("active")) and time.time() - float(data.get("ts") or 0) < 1.5
    except Exception:
        return False


def shut_up() -> None:
    # 顺便让"念回答"的线程也停下（你一喊停，它就别接着念了）
    try:
        if REPLY_READER is not None:
            REPLY_READER.stop()
    except Exception:
        pass
    try:
        SPEAK_STOP_FILE.write_text(json.dumps({"ts": time.time()}), encoding="utf-8")
    except Exception:
        pass


def self_spoken_text() -> str:
    """它此刻正在念的那句（用来判断录到的是不是它自己）。"""
    try:
        data = json.loads(SPEAK_STATUS_FILE.read_text(encoding="utf-8"))
        return str(data.get("text") or "")
    except Exception:
        return ""


def sounds_like(a: str, b: str) -> bool:
    """两段话算不算"同一句"——判断这句是不是它自己在念。

    **判得严一点**：只有整句几乎一模一样才算"自己的声音"。
    以前宽（包含 3 个字就算、相似度 0.45 就算），于是它刚把回答念完，
    你接着说话时只要重复了几个词（"我看到 23:33:11 那句设置展开的时候"），
    就会被你自己的话反判成"它在念"，你的话直接被丢掉 —— 真机丢过好几次。
    它自己在念的时候，录回来的是**几乎一整句**（TTS 念得清楚，错字很少），
    所以要"整句被包住"或者"最长重合 ≥ 短句的 75% 且 ≥8 字"才算数。
    """
    import difflib

    aa = re.sub(r"[\s，,。.！!？?]", "", a or "")
    bb = re.sub(r"[\s，,。.！!？?]", "", b or "")
    if len(aa) < 3 or len(bb) < 3:
        return False
    short, long_ = (aa, bb) if len(aa) <= len(bb) else (bb, aa)
    if len(short) >= 8 and short in long_:          # 整句被包住 → 就是它在念
        return True
    # 最长公共子串：念出来再录回去，字常会错几个，但总会有一大段是重合的
    best, prev = 0, [0] * (len(bb) + 1)
    for i in range(1, len(aa) + 1):
        cur = [0] * (len(bb) + 1)
        for j in range(1, len(bb) + 1):
            if aa[i - 1] == bb[j - 1]:
                cur[j] = prev[j - 1] + 1
                best = max(best, cur[j])
        prev = cur
    if best >= 8 and best >= len(short) * 0.75:     # 大半句都对上 → 也是它在念
        return True
    return difflib.SequenceMatcher(None, aa, bb).ratio() >= 0.7


_SEARCH_HEADS = ("搜一下", "搜索", "找一下我说过", "我说过关于", "翻一下日志", "查一下日志",
                 "日志里", "我说过什么关于")


def repeated_after_miss(text: str, miss: dict, now: float | None = None,
                        window: float = 120.0) -> bool:
    """这句是不是"刚刚被当成我自己的声音丢掉"的同一句？

    是 → 那就**一定是你说的**：它自己不会把同一句连念两遍。所以第二遍照常当你的话处理。
    （真机出过：它刚念完回答，你接着说话被误判丢掉；你再说一遍，还是被丢掉 —— 用户提的这招。）
    """
    last = str((miss or {}).get("text") or "")
    if not last:
        return False
    now = time.time() if now is None else now
    if now - float((miss or {}).get("at") or 0.0) >= window:
        return False
    return sounds_like(text, last)


def parse_search(text: str) -> str | None:
    """「搜一下我说过关于奶粉的话」→ 关键词「奶粉」。"""
    plain = (text or "").strip("。，,.！! ")
    for head in _SEARCH_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1]
            body = re.sub(r"^(关于|有关|我说的|我说过|的话|吗|呢|？|\?)+", "", body).strip()
            body = re.sub(r"(的话|吗|呢|？|\?)$", "", body).strip()
            return body or None
    return None


# ---------------------------------------------------------------- 自学习纠错

def parse_correction(text: str) -> tuple[str, str] | None:
    """**已停用**（用户 2026-10-09 要求去掉：「全是误判」）。

    原来是「以后把胡包改成胡宝」「不是胡包是胡宝」→ (错, 对)，会往 config.json 里存一条
    替换规则，以后所有话里都替换掉。用户反馈：他随口说的一句话经常被当成"教它改错字"，
    然后就念一句"记住了，以后××写成××"、那句话还被改掉 —— 全是误判。所以直接停掉：
    不再学新规则（这里恒返回 None），旧的规则也不再应用（见 apply_corrections）。
    """
    return None


def apply_corrections(text: str, table: dict | None) -> str:
    """**已停用**：一律原样返回（连旧的替换表也不用了）。"""
    return text


# ---------------------------------------------------------------- 口算 / 换算

_MATH_WORDS = [("乘以", "*"), ("乘上", "*"), ("乘", "*"), ("×", "*"), ("x", "*"), ("X", "*"),
               ("加上", "+"), ("加", "+"), ("减去", "-"), ("减", "-"),
               ("除以", "/"), ("除", "/"), ("÷", "/"),
               ("的平方", "**2"), ("平方", "**2"), ("的立方", "**3"), ("立方", "**3"),
               ("点", "."), ("等于几", ""), ("等于多少", ""), ("是多少", ""), ("得多少", ""),
               ("等于", ""), ("帮我算", ""), ("算一下", ""), ("算算", ""), ("计算", ""),
               ("请问", ""), ("多少", ""), ("几", ""), ("？", ""), ("?", "")]


def _safe_eval(expr: str) -> float | None:
    """只允许数字和 + - * / ** ( ) 的算式求值。"""
    import ast

    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        return None

    def walk(node) -> float:
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return float(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            val = walk(node.operand)
            return val if isinstance(node.op, ast.UAdd) else -val
        if isinstance(node, ast.BinOp):
            a, b = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Add):
                return a + b
            if isinstance(node.op, ast.Sub):
                return a - b
            if isinstance(node.op, ast.Mult):
                return a * b
            if isinstance(node.op, ast.Div):
                return a / b
            if isinstance(node.op, ast.Pow):
                return a ** b
        raise ValueError("不支持的算式")

    try:
        return walk(tree)
    except Exception:
        return None


def parse_calc(text: str) -> tuple[str, float] | None:
    """本地算数：「127乘34」「200的百分之15」「9的平方」→ (算式, 结果)。"""
    plain = apply_corrections((text or "").strip(), None)
    if not plain or not re.search(r"[0-9０-９]", plain):
        return None
    for src, dst in zip("０１２３４５６７８９", "0123456789"):
        plain = plain.replace(src, dst)
    m = re.search(r"(\d+(?:\.\d+)?)\s*的\s*百分之\s*(\d+(?:\.\d+)?)", plain)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        return (f"{a:g} 的百分之 {b:g}", a * b / 100)
    expr = plain
    for src, dst in _MATH_WORDS:
        expr = expr.replace(src, dst)
    expr = expr.replace(" ", "").replace("，", "").replace(",", "").replace("。", "")
    if not re.fullmatch(r"[0-9+\-*/().]+", expr) or not re.search(r"[+\-*/]", expr):
        return None
    value = _safe_eval(expr)
    if value is None:
        return None
    show = expr.replace("**2", " 的平方").replace("**3", " 的立方")
    show = show.replace("*", " × ").replace("/", " ÷ ")
    return (show, value)


_UNIT_SCALE = {
    "毫米": 0.001, "厘米": 0.01, "分米": 0.1, "米": 1.0, "千米": 1000.0, "公里": 1000.0,
    "英寸": 0.0254, "英尺": 0.3048, "英里": 1609.344, "海里": 1852.0,
    "克": 1.0, "千克": 1000.0, "公斤": 1000.0, "斤": 500.0, "两": 50.0,
    "吨": 1000000.0, "磅": 453.59237, "盎司": 28.349523125,
    "毫升": 0.001, "升": 1.0, "立方米": 1000.0,
    "秒": 1.0, "分钟": 60.0, "小时": 3600.0, "天": 86400.0, "周": 604800.0,
}
_UNIT_FAMILY = {
    "毫米": "长度", "厘米": "长度", "分米": "长度", "米": "长度", "千米": "长度",
    "公里": "长度", "英寸": "长度", "英尺": "长度", "英里": "长度", "海里": "长度",
    "克": "重量", "千克": "重量", "公斤": "重量", "斤": "重量", "两": "重量",
    "吨": "重量", "磅": "重量", "盎司": "重量",
    "毫升": "体积", "升": "体积", "立方米": "体积",
    "秒": "时间", "分钟": "时间", "小时": "时间", "天": "时间", "周": "时间",
}


def parse_convert(text: str) -> str | None:
    """单位换算：「3斤是多少克」「5公里多少米」。温度单独处理。"""
    plain = (text or "").replace(" ", "").replace("？", "").replace("?", "")
    if not plain:
        return None
    if "摄氏" in plain or "华氏" in plain:
        m = re.search(r"(-?\d+(?:\.\d+)?)\s*(摄氏|华氏)?\s*度?", plain)
        if m:
            value = float(m.group(1))
            src = m.group(2) or ("华氏" if "华氏" in plain else "摄氏")
            if src == "华氏":
                return f"{value:g} 华氏度等于 {(value - 32) * 5 / 9:.1f} 摄氏度"
            return f"{value:g} 摄氏度等于 {value * 9 / 5 + 32:.1f} 华氏度"
    units = sorted(_UNIT_SCALE, key=len, reverse=True)
    found = [u for u in units if u in plain]
    if len(found) < 2:
        return None
    num = re.search(r"(\d+(?:\.\d+)?)", plain)
    if num:
        value = float(num.group(1))
    else:                                    # 支持"一公斤多少克"这种中文数字
        cn = re.search(r"([一二两三四五六七八九十半]+)", plain)
        value = cn_number(cn.group(1)) if cn else None
        if not value:
            return None
    src = found[0] if plain.find(found[0]) < plain.find(found[1]) else found[1]
    dst = found[1] if src == found[0] else found[0]
    if _UNIT_FAMILY.get(src) != _UNIT_FAMILY.get(dst):
        return None
    result = value * _UNIT_SCALE[src] / _UNIT_SCALE[dst]
    return f"{value:g} {src} 等于 {result:.4g} {dst}"


# ---------------------------------------------------------------- 媒体键 / 找东西

_VK_MEDIA = {"下一首": 0xB0, "下一曲": 0xB0, "切歌": 0xB0, "换首歌": 0xB0,
             "上一首": 0xB1, "上一曲": 0xB1, "回到上一首": 0xB1,
             "播放暂停": 0xB3, "暂停播放": 0xB3, "继续播放": 0xB3}
_VK_VOLUME = {"声音大点": 0xAF, "音量大点": 0xAF, "大声点": 0xAF, "声音大一点": 0xAF,
              "声音小点": 0xAE, "音量小点": 0xAE, "小声点": 0xAE, "声音小一点": 0xAE,
              "静音": 0xAD, "取消静音": 0xAD}


def parse_media(text: str) -> tuple[str, int] | None:
    """媒体控制。带"音乐/歌/播放器"的句子才当媒体指令，免得和暂停键打架。"""
    plain = (text or "").replace(" ", "")
    if not plain:
        return None
    for word, vk in _VK_VOLUME.items():
        if word in plain:
            return (word, vk)
    music_ctx = any(w in plain for w in ("音乐", "歌", "播放器", "声音", "视频"))
    for word, vk in _VK_MEDIA.items():
        if word in plain:
            return (word, vk)
    if music_ctx:
        if "暂停" in plain or "停一下" in plain:
            return ("暂停音乐", 0xB3)
        if "播放" in plain or "继续" in plain:
            return ("播放音乐", 0xB3)
    return None


_OPEN_VERBS = ("帮我打开", "给我打开", "打开", "开一下", "启动", "运行", "打开一下")


def parse_open(text: str) -> str | None:
    plain = (text or "").strip("。，,.！! ")
    for verb in _OPEN_VERBS:
        if plain.startswith(verb):
            target = plain[len(verb):].strip("。，,.！! 一下 ")
            return target or None
    return None


_LNK_CACHE: dict = {"files": [], "ts": 0.0}
_DOC_CACHE: dict = {"files": [], "ts": 0.0}
# 常见的系统程序（开始菜单里常常找不到）
_APP_ALIASES = {
    "记事本": "notepad.exe", "计算器": "calc.exe", "画图": "mspaint.exe",
    "写字板": "write.exe", "任务管理器": "taskmgr.exe", "资源管理器": "explorer.exe",
    "命令提示符": "cmd.exe", "文件资源管理器": "explorer.exe",
    "设置": "ms-settings:", "系统设置": "ms-settings:", "截图": "ms-screenclip:",
    "相机": "microsoft.windows.camera:", "闹钟": "ms-clock:", "便签": "ms-stickynotes:",
}


def _start_menu_lnks() -> list[Path]:
    """开始菜单里的程序快捷方式（含桌面上的），5 分钟内缓存一次。"""
    if _LNK_CACHE["files"] and time.time() - _LNK_CACHE["ts"] < 300:
        return _LNK_CACHE["files"]
    roots = []
    for env in ("ProgramData", "APPDATA"):
        base = os.environ.get(env)
        if base:
            roots.append(Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs")
    for name in ("Desktop", "桌面"):
        p = Path(os.path.expanduser("~")) / name
        if p.is_dir():
            roots.append(p)
    found: list[Path] = []
    for root in roots:
        try:
            found.extend(p for p in root.rglob("*.lnk"))
        except Exception:
            pass
        if len(found) > 4000:
            break
    _LNK_CACHE.update(files=found, ts=time.time())
    return found


def _doc_files() -> list[Path]:
    """桌面/文档/下载里的文件，用来"打开上周的报告"这种。"""
    if _DOC_CACHE["files"] and time.time() - _DOC_CACHE["ts"] < 120:
        return _DOC_CACHE["files"]
    home = Path(os.path.expanduser("~"))
    found: list[Path] = []
    for name in ("Desktop", "桌面", "Documents", "文档", "Downloads", "下载"):
        root = home / name
        if not root.is_dir():
            continue
        try:
            for p in root.rglob("*"):
                if len(found) > 6000:
                    break
                if p.is_file() and p.suffix.lower() not in (".tmp", ".lnk", ".url"):
                    found.append(p)
        except Exception:
            pass
    _DOC_CACHE.update(files=found, ts=time.time())
    return found


def _pick_best(key: str, items, ignore_case: bool = True) -> tuple[object, int]:
    best, score = None, 0
    for it in items:
        name = Path(it).stem if ignore_case else str(it)
        if ignore_case:
            name = name.lower()
        hit = sum(1 for ch in key if ch and ch in name)
        if key and key in name:
            hit += 100
        if hit > score:
            best, score = it, hit
    return best, score


def open_named(target: str) -> str | None:
    """按名字打开程序或文件；返回打开了什么（或者 None）。

    注意：网页文件（.html/.url 这些）一律不当成"要打开的东西" —— 双击它们会拉起
    浏览器，用户会觉得"它自己把微软浏览器打开了"。除非你话里明说要浏览器/网页。
    """
    key = re.sub(r"[\s的了个吧呢啊，,。.！!]", "", target or "").lower()
    if not key:
        return None
    wants_browser = any(w in key for w in ("浏览器", "网页", "网址", "网站", "链接"))
    web_suffix = (".html", ".htm", ".url", ".webloc", ".mhtml")

    def ok_file(p) -> bool:
        return wants_browser or Path(p).suffix.lower() not in web_suffix

    # 常见的系统程序先查别名：它们多半没有开始菜单快捷方式
    for alias, cmd in _APP_ALIASES.items():
        if alias in key:
            try:
                os.startfile(cmd)
                return alias
            except Exception:
                try:
                    subprocess.Popen(cmd, shell=True)
                    return alias
                except Exception:
                    break
    need = max(2, min(4, len(key)))
    best, score = _pick_best(key, [p for p in _start_menu_lnks() if ok_file(p)])
    if best is not None and score >= need:
        try:
            os.startfile(str(best))
            return Path(best).stem
        except Exception:
            pass
    best, score = _pick_best(key, [p for p in _doc_files() if ok_file(p)])
    if best is not None and score >= need:
        try:
            os.startfile(str(best))
            return Path(best).name
        except Exception:
            pass
    return None


# ---------------------------------------------------------------- 上下文指代

_REPEAT_WORDS = ("再来一次", "跟刚才一样", "和刚才一样", "重复一遍", "再说一遍", "重新发一遍",
                 "再发一遍", "同上")

# Whisper 在"音乐/电视/杂音"上最爱吐的固定几句（中文数据集的残留）。
# 它们跟用户没关系，出现就当没听见——不然电视开着会一直往聊天窗口吐字。
# 只说得出、正常人不这么讲话的几句——命中就直接丢
HALLUCINATIONS = (
    "请不吝点赞", "不吝点赞", "打赏支持", "明镜与点点", "点点栏目", "明镜与点点栏目",
    "字幕组", "中文字幕", "字幕由", "下期再见", "更多精彩内容", "欢迎订阅本",
    "本视频", "感谢收看", "谢谢观看", "谢谢大家的观看",
    # 视频字幕腔的常见"鬼话"，模型在杂音上很容易蹦出这些
    "一键三连", "点个赞", "点赞订阅", "订阅频道", "别忘了订阅", "关注我",
    "感谢观看", "感谢大家的观看", "谢谢大家观看", "下期见", "我们下期见",
    "大家好我是", "今天给大家", "本期的", "记得点赞", "欢迎点赞", "欢迎收看",
    "字幕志愿者", "翻译字幕", "自动生成字幕", "未经作者授权", "禁止转载",
    "更多内容请", "视频就到这里", "今天的视频", "老规矩", "拜拜",
)
# 这些词本身很正常（"帮我订阅…转发…"），要凑够三个才当幻觉
HALLUCINATION_WEAK = ("点赞", "订阅", "转发", "打赏", "栏目", "字幕", "观看",
                      "关注", "收藏", "投币", "三连", "频道", "视频", "直播",
                      "广告", "节目", "感谢", "谢谢", "再来一首", "歌手", "歌词",
                      "专辑", "歌曲", "音乐", "演出", "伴奏", "演唱")
# 一听就是"歌曲/演唱会字幕"的词：单独出现在短句里，基本不是你在下命令
MUSIC_WORDS = ("歌手", "歌曲", "演唱", "伴奏", "专辑", "歌词", "音乐", "演出", "原唱")


def is_hallucination(text: str) -> bool:
    """是不是识别引擎在杂音/背景乐上编出来的废话。

    三道判断：
      ① 命中固定句（"请不吝点赞…"这种整句）
      ② 这些词凑够三个（"点赞 订阅 转发"）
      ③ 短句里**除了这些词没别的**（单独蹦出"点赞""转发""周杰伦的歌手名"这类）
         外加：带网址、带"字幕"的，一律当幻觉。
    """
    raw = text or ""
    # 网址要在"去掉标点之前"看，不然 www.xxx.com 被抠掉点就认不出来了
    if re.search(r"(www\.|https?://|\.com|\.cn|\.net|\.tv)", raw, re.I):
        return True
    plain = re.sub(r"[\s，,。.！!？?、；;：:]", "", raw)
    if len(plain) < 2:
        return False
    if any(w in plain for w in HALLUCINATIONS):
        return True
    if "字幕" in plain:
        return True
    if len(plain) <= 10 and any(w in plain for w in MUSIC_WORDS):
        return True          # "周杰伦 歌手" 这种：短句里冒出歌名/歌手味的词
    weak = [w for w in HALLUCINATION_WEAK if w in plain]
    if len(weak) >= 3:
        return True
    if weak and len(plain) <= 10:
        # 把命中的词抠掉，剩下的几乎没内容 → 这句只是几个套话拼起来的
        rest = plain
        for w in weak:
            rest = rest.replace(w, "")
        if len(rest) <= 2:
            return True
    return False


def parse_repeat(text: str) -> bool:
    plain = (text or "").replace(" ", "").strip("。，,.！! ")
    return any(w in plain for w in _REPEAT_WORDS) and len(plain) <= 8


# ---------------------------------------------------------------- 语音日记 / 成就

def diary_lines(day: str) -> list[str]:
    """挑出某一天"真的说给它听"的话（噪声被转成的句子不算）。"""
    out = []
    for name in ("said.md", "transcripts.md"):
        path = HERE / name
        if not path.exists():
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except Exception:
            continue
        for line in lines:
            line = line.strip()
            if not line.startswith("- ") or day not in line:
                continue
            body = line.split(" ", 2)
            if len(body) >= 3:
                body = re.sub(r"^\d{1,2}:\d{2}(:\d{2})?\s*", "", body[2].strip())
                if body.startswith("（忽略）"):
                    continue
                out.append(body)
        if out:
            break                    # said.md 有就用它，别两份都算
    return out


def diary_summary(day: str) -> str:
    lines = diary_lines(day)
    if not lines:
        return "今天你没跟我说过话，明天见。"
    longest = sorted(lines, key=len, reverse=True)[:3]
    head = f"今天你跟我说了 {len(lines)} 句话。"
    body = "印象最深的几句：" + "；".join(s[:40] for s in longest) + "。"
    return head + body


ACHIEVEMENTS = [
    ("wake", 1, "初次唤醒", "它第一次被你叫醒"),
    ("wake", 100, "百次唤醒", "累计叫醒它 100 次"),
    ("wake", 1000, "千次唤醒", "累计叫醒它 1000 次"),
    ("note", 1, "第一个便签", "第一次让它记东西"),
    ("ledger", 1, "开始记账", "第一次让它记账"),
    ("focus", 1, "第一颗番茄", "第一次开番茄钟"),
    ("game", 1, "陪我玩", "第一次跟它玩游戏"),
    ("game", 5, "游戏搭子", "一共玩了 5 局"),
    ("correct", 1, "教它说话", "第一次教它纠错"),
]


def read_achv() -> dict:
    try:
        data = json.loads(ACHV_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            data.setdefault("counts", {})
            data.setdefault("unlocked", {})
            data.setdefault("days", [])
            return data
    except Exception:
        pass
    return {"counts": {}, "unlocked": {}, "days": []}


def bump_achv(kind: str, n: int = 1) -> list[str]:
    """给某个计数器加数，返回这次新解锁的成就名。"""
    data = read_achv()
    counts = data["counts"]
    counts[kind] = int(counts.get(kind, 0)) + n
    today = datetime.now().strftime("%Y-%m-%d")
    days = data["days"]
    if today not in days:
        days.append(today)
        days[:] = days[-60:]
    earned = []
    for key, need, name, _desc in ACHIEVEMENTS:
        if key == kind and counts[kind] >= need and name not in data["unlocked"]:
            data["unlocked"][name] = today
            earned.append(name)
    try:
        ACHV_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    return earned


def spectrum_bands(block: np.ndarray, sr: int, count: int = 12) -> list[float]:
    """把一小段音频压成几根"音浪"柱子的高度（0~1）。"""
    if block.size < 64:
        return [0.0] * count
    win = np.hanning(block.size)
    spec = np.abs(np.fft.rfft(block * win))
    freqs = np.fft.rfftfreq(block.size, 1.0 / sr)
    edges = np.logspace(np.log10(70), np.log10(min(11000, sr / 2 - 100)), count + 1)
    out = []
    for i in range(count):
        lo, hi = edges[i], edges[i + 1]
        sel = (freqs >= lo) & (freqs < hi)
        val = float(np.mean(spec[sel])) if np.any(sel) else 0.0
        out.append(min(1.0, val / (block.size * 0.06)))
    peak = max(out)
    if peak <= 0.02:
        return [round(v * 6, 3) for v in out]     # 太安静：整体压扁，别把底噪放大成满格
    out = [min(1.0, v / peak * 0.92) for v in out]
    return [round(v, 3) for v in out]


MEM_FILE = HERE / "memory.json"
VP_FILE = HERE / "voiceprint.json"


def read_ledger() -> list[dict]:
    """读记账本（给周报和"今天花了多少"用）。"""
    try:
        data = json.loads(LEDGER_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


_VK_CTRL, _VK_ALT = 0x11, 0x12
_PAGE_CMDS = [
    (("新建标签页", "新建标签", "新标签页"), 0x54, (_VK_CTRL,)),
    (("关闭标签页", "关闭标签", "关掉这个标签"), 0x57, (_VK_CTRL,)),
    (("刷新一下", "刷新页面", "刷新"), 0x74, ()),
    (("返回上一页", "后退", "退回去"), 0x25, (_VK_ALT,)),
    (("前进一页", "前进"), 0x27, (_VK_ALT,)),
    (("地址栏", "输入网址"), 0x4C, (_VK_CTRL,)),
    (("往下翻", "下一屏"), 0x22, ()),
    (("往上翻", "上一屏"), 0x21, ()),
    (("翻到最后", "到底部"), 0x23, ()),
    (("回到最上面", "回到顶部"), 0x24, ()),
]


def _combo(vk: int, *mods: int) -> None:
    for m in mods:
        _key(m)
    _key(vk)
    _key(vk, up=True)
    for m in reversed(mods):
        _key(m, up=True)


def parse_page_cmd(text: str) -> tuple[str, int, tuple] | None:
    """网页 / 滚动类指令：新标签页、刷新、往下翻、回到顶部……"""
    plain = (text or "").replace(" ", "").strip("。，,.！! ")
    if not plain or len(plain) > 12:
        return None
    for words, vk, mods in _PAGE_CMDS:
        for w in words:
            if w in plain:
                return (w, vk, mods)
    return None


def clipboard_text() -> str:
    """读剪贴板里的文字（没有就返回空串）。"""
    if os.name != "nt":
        return ""
    CF_UNICODETEXT = 13
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.GetClipboardData.restype = ctypes.c_void_p
    try:
        if not user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
            return ""
        if not user32.OpenClipboard(None):
            return ""
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return ""
            try:
                return ctypes.wstring_at(ptr)
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
    except Exception:
        return ""


def selected_text() -> str:
    """模拟 Ctrl+C 取当前选中的文字；剪贴板没变化就说明其实没选中东西。"""
    if os.name != "nt":
        return ""
    u = ctypes.windll.user32
    before = u.GetClipboardSequenceNumber()
    _combo(0x43, _VK_CTRL)          # Ctrl+C
    time.sleep(0.12)
    if u.GetClipboardSequenceNumber() == before:
        return ""
    return clipboard_text().strip()


def image_to_clipboard(img) -> bool:
    """把一张 PIL 图放进剪贴板（CF_DIB），别的程序就能直接粘贴。"""
    if os.name != "nt":
        return False
    import struct

    from PIL import Image as _Img

    rgb = img.convert("RGB")
    r, g, b = rgb.split()
    bgra = _Img.merge("RGBA", (b, g, r, _Img.new("L", rgb.size, 0)))
    data = bgra.transpose(_Img.FLIP_TOP_BOTTOM).tobytes()
    w, h = rgb.size
    header = struct.pack("<IiiHHIIiiII", 40, w, h, 1, 32, 0, len(data), 2835, 2835, 0, 0)
    blob = header + data
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    try:
        if not user32.OpenClipboard(None):
            return False
        try:
            user32.EmptyClipboard()
            handle = kernel32.GlobalAlloc(0x0002, len(blob))
            if not handle:
                return False
            ptr = kernel32.GlobalLock(handle)
            ctypes.memmove(ptr, blob, len(blob))
            kernel32.GlobalUnlock(handle)
            user32.SetClipboardData(8, handle)      # CF_DIB
        finally:
            user32.CloseClipboard()
    except Exception:
        return False
    return True


def grab_screen() -> bool:
    """截主屏塞进剪贴板。"""
    try:
        from PIL import ImageGrab

        return image_to_clipboard(ImageGrab.grab())
    except Exception as exc:  # noqa: BLE001
        print(f"   （截图失败：{type(exc).__name__}）", flush=True)
        return False


def memory_all() -> list[dict]:
    try:
        data = json.loads(MEM_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def memory_add(text: str) -> None:
    rows = memory_all()
    rows.append({"ts": time.time(), "date": datetime.now().strftime("%Y-%m-%d"),
                 "text": (text or "").strip()})
    try:
        MEM_FILE.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _shingles(text: str) -> set[str]:
    clean = re.sub(r"[\s，,。.！!？?、的了我你他她它是]|什么|哪|谁|多少|吗|呢", "", text or "")
    return {clean[i:i + 2] for i in range(max(1, len(clean) - 1))} or {clean}


def memory_find(query: str, limit: int = 3) -> list[dict]:
    """按二字片段重合度找最像的几条记忆。"""
    q = _shingles(query)
    scored = []
    for row in memory_all():
        s = _shingles(row.get("text", ""))
        if not s:
            continue
        hit = len(q & s)
        # 至少要重合两个片段，不然"我喜欢喝什么"会去匹配"我喜欢某个颜色"
        if hit < min(2, len(q)):
            continue
        score = hit / max(1, len(q))
        if score > 0.2:
            scored.append((score, row))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [row for _s, row in scored[:limit]]


_REMEMBER_HEADS = ("记住", "记牢", "帮我记住", "你要记住")
_ASK_HEADS = ("你还记得", "记得我", "我说过", "我告诉过你", "我跟你说的")


def parse_remember(text: str) -> str | None:
    """「记住我喜欢喝美式」→ 要记的内容。"""
    plain = (text or "").strip("。，,.！! ")
    for head in _REMEMBER_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1].strip("。，,.！!：: ")
            body = re.sub(r"^[一下个点把]+", "", body).strip()
            return body or None
    return None


def parse_ask_memory(text: str) -> bool:
    plain = (text or "").replace(" ", "")
    if any(h in plain for h in _ASK_HEADS):
        return True
    return plain.endswith(("吗", "？", "?")) and any(
        w in plain for w in ("我喜欢", "我住", "我叫", "我的", "我生日", "我讨厌"))


def weekly_report() -> str:
    """这周：说了多少句、花了多少、用了我几天。"""
    from datetime import timedelta

    start = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    try:
        lines = SAID_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        lines = []
    week = [ln for ln in lines if ln.startswith("- ") and ln[2:12] >= start]
    rows = [r for r in read_ledger() if str(r.get("date", "")) >= start]
    spent = sum(r["amount"] for r in rows)
    days = [d for d in read_achv().get("days", []) if d >= start]
    head = f"这周你跟我说了 {len(week)} 句话，用了我 {len(days)} 天。"
    money = f"一共花了 {spent:g} 块。" if spent else "这周没记过账。"
    top = ""
    if week:
        longest = sorted((re.sub(r"^-\s+\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+", "", ln)
                          for ln in week), key=len, reverse=True)[:2]
        top = "印象最深的：" + "；".join(s[:26] for s in longest) + "。"
    return head + money + top


def last_input_age() -> float:
    """距离你上次动键盘/鼠标过了多少秒。"""
    if os.name != "nt":
        return 0.0

    class _LII(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    info = _LII()
    info.cbSize = ctypes.sizeof(_LII)
    try:
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
            return 0.0
        ticks = ctypes.windll.kernel32.GetTickCount()
        return max(0.0, (ticks - info.dwTime) / 1000.0)
    except Exception:
        return 0.0


MEETING_APPS = ("腾讯会议", "zoom", "teams", "钉钉", "飞书", "lark", "webex", "瞩目",
                "classin", "meet -", "会议")


def foreground_hwnd() -> int:
    if os.name != "nt":
        return 0
    try:
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def foreground_title() -> str:
    if os.name != "nt":
        return ""
    try:
        u = ctypes.windll.user32
        buf = ctypes.create_unicode_buffer(256)
        u.GetWindowTextW(u.GetForegroundWindow(), buf, 256)
        return buf.value or ""
    except Exception:
        return ""


def in_meeting() -> bool:
    title = foreground_title().lower()
    return any(app in title for app in MEETING_APPS)


def is_our_window(hwnd: int) -> bool:
    """这个窗口是不是我们自己开的？（悬浮窗、设置面板、日志窗口这些）"""
    if not hwnd or os.name != "nt":
        return False
    try:
        pid = ctypes.c_ulong()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value) == os.getpid()
    except Exception:
        return False


def pick_send_target(cfg: dict, target_arg, tracker, log=print) -> tuple:
    """这句话该发到哪个窗口。

    以前这里有个 bug：条件是「开了跟随当前窗口 **并且** 没设 target」——
    可 config 里本来就写着 target=ChatGPT，所以那个开关**永远是死的**：
    你在别的对话窗口说话时，它照样往 ChatGPT 那个窗口发（或者发到你上一个用过的窗口），
    看起来就是"别的对话不触发"。

    现在的规矩：
      1. 开了「跟着当前窗口发」→ 发给当前前台窗口（要是我们自己的窗口就跳过）
      2. 没开 → 按 target 找标题匹配的窗口（比如 ChatGPT）
      3. 都找不到 → 用你上一个用过的窗口
    """
    def fallback() -> tuple:
        if target_arg:
            hwnd, title = find_window(target_arg)
            if hwnd:
                return hwnd, title
        if tracker:
            return tracker.hwnd, tracker.title
        return 0, ""

    if cfg.get("follow_foreground"):
        fg = foreground_hwnd()
        if fg and not is_our_window(fg):
            return fg, foreground_title()
        if fg:
            log("   ↳ （前台是我们自己的窗口，改用上一个用过的窗口）")
    return fallback()


def _mel_matrix(sr: int, n_fft: int, n_mels: int = 24) -> "np.ndarray":
    def hz2mel(f):
        return 2595.0 * np.log10(1.0 + f / 700.0)

    def mel2hz(m):
        return 700.0 * (10.0 ** (m / 2595.0) - 1.0)

    pts = mel2hz(np.linspace(hz2mel(80), hz2mel(min(7000, sr / 2 - 100)), n_mels + 2))
    bins = np.floor(pts / (sr / 2) * (n_fft / 2 + 1)).astype(int)
    mat = np.zeros((n_mels, n_fft // 2 + 1), dtype=np.float32)
    for i in range(n_mels):
        lo, mid, hi = bins[i], bins[i + 1], bins[i + 2]
        if not (lo < mid < hi):
            continue
        mat[i, lo:mid] = np.linspace(0, 1, mid - lo, endpoint=False)
        mat[i, mid:hi] = np.linspace(1, 0, hi - mid, endpoint=False)
    return mat


def voice_features(audio: np.ndarray, sr: int) -> list[float] | None:
    """粗略的"声音指纹"：24 维 log-mel 的均值＋标准差。只看个大概，认不准很正常。"""
    step, win = int(sr * 0.02), int(sr * 0.03)
    frames = []
    for i in range(0, max(1, audio.size - win), step):
        seg = audio[i:i + win]
        if seg.size < win:
            break
        if float(np.sqrt(np.mean(seg ** 2))) < 0.01:
            continue
        frames.append(seg * np.hanning(win))
    if len(frames) < 8:
        return None
    spec = np.abs(np.fft.rfft(np.stack(frames), n=512, axis=1))
    logmel = np.log(_mel_matrix(sr, 512) @ spec.T + 1e-6)
    vec = np.concatenate([logmel.mean(axis=1), logmel.std(axis=1)])
    vec = vec - vec.mean()
    return [float(v) for v in vec / (float(np.linalg.norm(vec)) or 1.0)]


def voice_enroll(audio: np.ndarray, sr: int) -> bool:
    feat = voice_features(audio, sr)
    if not feat:
        return False
    try:
        VP_FILE.write_text(json.dumps({"ts": time.time(), "feat": feat}), encoding="utf-8")
    except Exception:
        return False
    return True


def voice_score(audio: np.ndarray, sr: int) -> float | None:
    """和注册的声纹有多像（0~1）；没注册过返回 None。"""
    try:
        ref = json.loads(VP_FILE.read_text(encoding="utf-8")).get("feat")
    except Exception:
        return None
    feat = voice_features(audio, sr)
    if not ref or not feat:
        return None
    return float(np.dot(np.array(ref), np.array(feat)))


def background_noise(text: str, last_score: float | None, wake_score: float | None,
                     gate_on: bool) -> bool:
    """这一句要不要当"背景音"丢掉？（只有开了「只认我的声音」才会拦）

    这里有两把尺子，得分清楚：
      last_score —— 拿"你注册声纹时说的那句话"比。短句上特别不准，
                    你自己的话也能低到 0.03（真事）。
      wake_score —— 拿"唤醒词训练"的声纹比。它专门练过你的声音，
                    喊完「大肥鱼」时算出来是 0.87~0.93。
    以前只看 last_score，于是你喊完唤醒词接着说的短句被反复当背景音丢掉 ——
    现象就是"明明识别到了，却自己取消了"。现在唤醒声纹过关一律放行。
    """
    if not gate_on or last_score is None:
        return False
    if wake_score is not None and wake_score >= 0.45:
        return False
    plain = re.sub(r"[\s，,。.！!？?]", "", text or "")
    return last_score < 0.42 and len(plain) <= 8


def start_reminder(seconds: float, what: str, paste: bool = False, target_hwnd: int = 0) -> None:
    """到点了：念出来 + 写进日志；可选把提醒也发到目标窗口。"""
    def fire() -> None:
        text = f"提醒你：{what}"
        speak(text)
        try:
            with (HERE / "transcripts.md").open("a", encoding="utf-8") as fh:
                fh.write(f"- {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ⏰ {text}\n")
        except Exception:
            pass
        print(f"\n⏰ {text}", flush=True)
        if paste and target_hwnd:
            paste_into(f"⏰ {text}", target_hwnd, press_enter=True, clear_first=True)

    timer = threading.Timer(max(1.0, seconds), fire)
    timer.daemon = True
    timer.start()


def run_shortcut(text: str, cfg: dict) -> str:
    """自定义快捷指令：说中短语就执行（url: / app: / say:）。返回执行的动作。"""
    shortcuts = cfg.get("shortcuts") or {}
    if not isinstance(shortcuts, dict):
        return ""
    for phrase, action in shortcuts.items():
        if not phrase or not action or phrase not in text:
            continue
        action = str(action).strip()
        try:
            if action.startswith("url:"):
                webbrowser.open(action[4:].strip())
            elif action.startswith("app:"):
                subprocess.Popen(action[4:].strip(), shell=True)
            elif action.startswith("say:"):
                speak(action[4:].strip())
            else:
                continue
        except Exception as exc:  # noqa: BLE001
            print(f"（快捷指令失败：{exc}）", flush=True)
            continue
        return f"{phrase} → {action}"
    return ""


# ------------------------------------------------------------------ 日程表
_WEEK = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6, "天": 6}


def day_match(days: str, today: int) -> bool:
    """today: 0=周一 … 6=周日。支持 每天 / 工作日 / 周末 / 周一,周三 / 一三五。"""
    days = (days or "每天").strip()
    if not days or days in ("每天", "每日", "天天", "all"):
        return True
    if days in ("工作日", "周一至周五", "周一到周五"):
        return today <= 4
    if days in ("周末", "周六周日", "周六,周日"):
        return today >= 5
    picked = set()
    for ch in days:
        if ch in _WEEK:
            picked.add(_WEEK[ch])
    return today in picked if picked else True


def start_scheduler(get_target, paste_text) -> None:
    """后台线程：每分钟看一眼日程表，到点就把内容发出去（并念一遍）。"""
    fired: set[tuple[int, str]] = set()

    def loop() -> None:
        while True:
            try:
                cfg = load_config()
                items = cfg.get("schedules") or []
                now = datetime.now()
                stamp = now.strftime("%Y-%m-%d %H:%M")
                import sched as sched_mod

                today = datetime.now().date()
                for i, item in enumerate(items):
                    if not isinstance(item, dict) or item.get("enabled", True) is False:
                        continue
                    when = str(item.get("time") or "").strip()
                    text = str(item.get("text") or "").strip()
                    if not when or not text:
                        continue
                    key = (i, stamp)
                    if key in fired or when != now.strftime("%H:%M"):
                        continue
                    # 新规则（每天/每周/每月/单次）和老写法都支持
                    if "kind" in item:
                        if not sched_mod.matches(item, today):
                            continue
                    elif not day_match(str(item.get("days") or "每天"), now.weekday()):
                        continue
                    fired.add(key)
                    print(f"\n🗓 日程到点：{text}", flush=True)
                    if cfg.get("schedule_speak", True):
                        speak(text)
                    # 提醒模块只出声；指令模块才把内容发出去
                    if item.get("kind_module") != "remind":
                        hwnd = get_target()
                        if hwnd:
                            paste_text(text, hwnd)
                        done_phrase = self_phrase(cfg)
                        if done_phrase:
                            speak(done_phrase)
                    try:
                        with (HERE / "transcripts.md").open("a", encoding="utf-8") as fh:
                            fh.write(f"- {now.strftime('%Y-%m-%d %H:%M:%S')} 🗓 {text}\n")
                    except Exception:
                        pass
                if len(fired) > 400:
                    fired.clear()
            except Exception as exc:  # noqa: BLE001
                print(f"（日程检查出错：{exc}）", flush=True)
            time.sleep(20)

    threading.Thread(target=loop, daemon=True).start()


def load_config() -> dict:
    """读同目录的 config.json；没有或读坏了就用空配置。"""
    path = HERE / "config.json"
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception as exc:  # noqa: BLE001
        print(f"⚠️ config.json 读不了（{exc}），先按默认设置走。")
        return {}


def total_ram_gb() -> float:
    """物理内存有多少 GB（低配机器主要看这个）。"""
    if os.name != "nt":
        return 8.0

    class _MEM(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_uint), ("dwMemoryLoad", ctypes.c_uint),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

    try:
        st = _MEM()
        st.dwLength = ctypes.sizeof(_MEM)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return st.ullTotalPhys / (1024 ** 3)
    except Exception:
        pass
    return 8.0


def detect_profile() -> tuple[str, dict]:
    """看这台机器什么档次，返回 (档位, 说明)。

    低配判定：没有 NVIDIA 显卡驱动、内存少于 8G、或者 CPU 核心少于 6。
    低配模式下自动：小模型 + int8 + 关实时字幕 + 关特效 + 30 帧 + 节能。
    """
    force = (os.environ.get("STT_FORCE_PROFILE") or "").strip().lower()
    cuda = False
    try:
        cuda = register_cuda_dlls()
    except Exception:
        cuda = False
    ram = total_ram_gb()
    cores = os.cpu_count() or 4
    if force in ("lite", "high"):        # 手动指定（自己知道机器行不行，或测试用）
        return force, {"why": "手动指定 " + force, "ram": ram, "cores": cores, "cuda": cuda}
    if not cuda or ram < 8.0 or cores < 6:
        why = ("没找到 NVIDIA 显卡" if not cuda else
               f"内存只有 {ram:.0f}G" if ram < 8.0 else f"只有 {cores} 核")
        return "lite", {"why": why, "ram": ram, "cores": cores, "cuda": cuda}
    return "high", {"why": "显卡+内存都够", "ram": ram, "cores": cores, "cuda": cuda}


def register_cuda_dlls() -> bool:
    """把 pip 装的 cuBLAS / cuDNN 目录加进 DLL 搜索路径（Windows 上显卡加速的前提）。

    返回 True 表示找到了 cuBLAS，可以尝试用显卡。
    """
    if os.name != "nt" or not hasattr(os, "add_dll_directory"):
        return True
    found = False
    dll_dirs: list[str] = []
    for pkg in ("nvidia.cublas", "nvidia.cudnn"):
        try:
            root = Path(importlib.import_module(pkg).__path__[0])
        except Exception:
            continue
        for folder in root.rglob("bin"):
            try:
                os.add_dll_directory(str(folder))
            except OSError:
                pass
            dll_dirs.append(str(folder))
            if any(folder.glob("cublas64_12.dll")):
                found = True
    if dll_dirs:  # 有些库按 PATH 找依赖，两边都喂上
        os.environ["PATH"] = os.pathsep.join(
            dll_dirs + [os.environ.get("PATH", "")]
        )
    if not found:
        try:
            ctypes.WinDLL("cublas64_12.dll")
            found = True
        except OSError:
            found = False
    return found


# ---------------------------------------------------------------- 输出/剪贴板

def setup_console() -> None:
    # 用 pythonw 跑（没有控制台）时，sys.stdout/stderr 是 None，
    # 这时候 print 会直接报错。改成写日志文件，出问题也还能查。
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            try:
                stream = open(HERE / "voice.log", "a", encoding="utf-8", buffering=1)
            except Exception:
                stream = open(os.devnull, "w", encoding="utf-8")
            setattr(sys, name, stream)
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleOutputCP(65001)
            kernel32.SetConsoleTitleW("语音助手")
        except Exception:
            pass


def copy_to_clipboard(text: str) -> bool:
    """写入 Windows 剪贴板（Unicode），不依赖第三方库。"""
    if os.name != "nt":
        return False
    CF_UNICODETEXT, GMEM_MOVEABLE = 13, 0x0002
    user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
    kernel32.GlobalAlloc.restype = ctypes.c_void_p
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    user32.SetClipboardData.argtypes = [ctypes.c_uint, ctypes.c_void_p]
    try:
        if not user32.OpenClipboard(None):
            return False
        try:
            user32.EmptyClipboard()
            size = (len(text) + 1) * ctypes.sizeof(ctypes.c_wchar)
            handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, size)
            if not handle:
                return False
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return False
            ctypes.memmove(ptr, ctypes.create_unicode_buffer(text), size)
            kernel32.GlobalUnlock(handle)
            return bool(user32.SetClipboardData(CF_UNICODETEXT, handle))
        finally:
            user32.CloseClipboard()
    except Exception:
        return False


# ------------------------------------------------------------------ 音频采集

def list_devices() -> None:
    print("可用录音设备：")
    for i, dev in enumerate(sd.query_devices()):
        if dev["max_input_channels"] > 0:
            api = sd.query_hostapis(dev["hostapi"])["name"]
            mark = " <- 默认" if i == sd.default.device[0] else ""
            print(f"  [{i:>2}] {dev['name']}  ({api}, {dev['max_input_channels']}ch){mark}")


def resolve_device(spec: str | None, warn=print):
    if spec is None or spec == "":
        return None
    if spec.lstrip("-").isdigit():
        return int(spec)
    matches = [
        i for i, d in enumerate(sd.query_devices())
        if d["max_input_channels"] > 0 and spec.lower() in d["name"].lower()
    ]
    if not matches:
        warn(f"⚠️ 没找到名字包含 “{spec}” 的麦克风，先用系统默认设备。接好麦克风后重开即可。")
        return None
    # 同一支麦克风在 MME/DirectSound/WASAPI 下会重复出现，优先 WASAPI（延时更低、音质更稳）
    def api_rank(i: int) -> int:
        name = sd.query_hostapis(sd.query_devices(i)["hostapi"])["name"]
        return {"Windows WASAPI": 0, "Windows DirectSound": 1, "MME": 2}.get(name, 3)

    return sorted(matches, key=api_rank)[0]


def open_stream(device, samplerate: int = TARGET_SR):
    """返回 (stream, 实际采样率)。设备不支持 16k 时退回设备默认采样率。"""
    for sr in (samplerate, None):
        try:
            rate = int(sr or sd.query_devices(device)["default_samplerate"])
            stream = sd.InputStream(
                samplerate=rate, channels=1, dtype="float32", blocksize=1024, device=device
            )
            stream.start()
            return stream, rate
        except Exception as exc:  # noqa: BLE001
            last = exc
    raise SystemExit(f"打不开录音设备：{last}")


def resample_to_16k(audio: np.ndarray, sr: int) -> np.ndarray:
    if sr == TARGET_SR or audio.size == 0:
        return audio
    n = int(round(audio.size * TARGET_SR / sr))
    return np.interp(
        np.linspace(0, audio.size - 1, n), np.arange(audio.size), audio
    ).astype(np.float32)


def rms(block: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(block)) + 1e-12))


CJK = r"\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uff00-\uffef"
# 给 Whisper 的提示词，它对含混的音频有时会把提示词本身当成识别结果吐出来
ASR_PROMPT = "以下是普通话的句子，请加标点。"
# 注意：识别引擎吐回来的回声**不一定是完整那句** —— 经常只回半截
# （比如"以下是普通话的"），所以这里每一段都要能单独匹配上，不然就被当成你说的话发出去。
_PROMPT_ECHO = re.compile(
    r"(以下是普通话(的)?(句子)?[，,]?|请加标点[。.]?|加标点[。.]?|普通话的句子)")
# 回声有时只剩两个残字（"以下"、"以下是"），这种碎片单独出现时没人会这么说话
_ECHO_FRAGMENT = {"以下", "以下是", "请加", "加标点", "普通话", "的句子", "句子"}
_PUNCT = {",": "，", ".": "。", "?": "？", "!": "！", ";": "；", ":": "："}
# Whisper 偶尔会吐出这些半角/变体标点，直接换成正体
_PUNCT_FIX = {
    "\ufe50": "，", "\ufe51": "、", "\ufe52": "。", "\uff61": "。",
    "\uff0e": "。", "\uff1f": "？", "\uff01": "！", "\uff1b": "；", "\uff1a": "：",
}


def normalize_zh(text: str) -> str:
    """Whisper 常输出半角标点，中文场景下换成全角更像正常句子。"""
    text = "".join(_PUNCT_FIX.get(ch, ch) for ch in text)
    out = []
    for i, ch in enumerate(text):
        if ch in _PUNCT:
            before = text[i - 1] if i > 0 else ""
            after = text[i + 1] if i + 1 < len(text) else ""
            if re.match(f"[{CJK}]", before) or re.match(f"[{CJK}]", after):
                out.append(_PUNCT[ch])
                continue
        out.append(ch)
    text = "".join(out)
    # 同一小段连着重复三次以上，基本是安静环境下的复读幻觉，压成一次
    text = re.sub(r"(.{3,30}?)\1{2,}", r"\1", text)
    # 把提示词回声去掉；去掉后啥都不剩就当成没识别到
    cleaned = _PROMPT_ECHO.sub("", text).strip("，,、 ")
    # 两头还可能粘着回声的碎渣：「取消 以下」要能变回「取消」，不然取消就失效了
    cleaned = re.sub(r"^(以下(是)?|请加标点?|加标点)[，,、\s]*", "", cleaned)
    cleaned = re.sub(r"[，,、\s]*(以下(是)?|请加标点?|加标点)$", "", cleaned)
    cleaned = cleaned.strip("，,、 ")
    if cleaned in _ECHO_FRAGMENT:          # 只剩残字 → 也是回声，当没听见
        cleaned = ""
    return cleaned if re.search(r"[\w\u4e00-\u9fff]", cleaned) else ""


def _word_pattern(word: str) -> str:
    """允许字与字之间夹标点/空格，比如"发，送"也能认出"发送"。"""
    return r"[\s，,、。.!！?？]*".join(re.escape(ch) for ch in word)


# 同音字容错：Whisper 说"大肥鱼"时常吐"大飞鱼/大肥与悦"这类同音错字，
# 逐字比对就会漏掉，所以再用不带声调的拼音比一遍。
try:
    from pypinyin import Style as _PinStyle
    from pypinyin import lazy_pinyin as _lazy_pinyin

    _HAS_PINYIN = True
except Exception:                       # 没装 pypinyin 也不影响：退回原来的逐字匹配
    _HAS_PINYIN = False

_HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
_ALNUM = re.compile(r"[0-9A-Za-z]" + "|" + _HAN.pattern)


def _unit_syllable(chunk: str) -> str:
    """一个字/一段字符的拼音（不带声调）；拿不到就原样返回，便于退化比对。"""
    if not _HAS_PINYIN:
        return chunk.lower()
    got = _lazy_pinyin(chunk, style=_PinStyle.NORMAL)
    return (got[0] if got else chunk).lower()


def _fuzzy_span(text: str, word: str) -> tuple[int, int] | None:
    """按拼音找触发词，返回命中的 (首字下标, 末字下标)；没找到返回 None。

    比逐字匹配宽：声调不管，所以"大肥鱼 / 大飞鱼 / 打肥鱼 / 大肥于"都算中；
    但"大鲨鱼 / 大白鱼"拼音不一样，不会误触发。
    末字额外允许把连着的同音字一起吃掉（"大肥与悦"里的"与悦"），
    避免把多出来的那个字留在正文里。
    """
    if not _HAS_PINYIN or not word:
        return None
    want = [_unit_syllable(ch) for ch in word if _ALNUM.match(ch)]
    if not want:
        return None
    units = [(i, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
    n = len(units)
    last = len(want) - 1
    for start in range(n):
        k = 0
        idx = start
        end = None
        while k < len(want) and idx < n:
            syl = units[idx][1]
            if k == last:
                if not syl.startswith(want[k]):
                    break
                end = idx
                while end + 1 < n and units[end + 1][1].startswith(want[k]):
                    end += 1
            else:
                if syl != want[k]:
                    break
                end = idx
            idx += 1
            k += 1
        if k == len(want) and end is not None:
            return units[start][0], units[end][0]
    return None


# 命令关键词：Whisper 常把"专注"写成"砖住"、"番茄钟"写成"翻切中"，
# 按拼音把它们换回正确写法，后面的判断就都能认出来了。
# 注意：**"取消"不在这里** —— 见下面的 cancel_hit。像"取消"这种两字词塞进来，
# 会把"别取笑他了"这种正经话改成"别取消他了"（真的改过，用户的话被换掉），
# 取消词自己有严格的判定。
_CANON = ("专注模式", "结束专注", "专注", "番茄钟", "记一下", "记一笔", "记账",
          "帮我决定", "猜数字", "早间播报", "变身", "提醒我")


def canonize(text: str) -> str:
    """把听着像命令词的同音错字换回正确写法（只在拼音完全对得上时才换）。"""
    if not _HAS_PINYIN or not text:
        return text
    for word in _CANON:
        want = [_unit_syllable(ch) for ch in word]
        if not want:
            continue
        units = [(i, ch, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
        for s in range(len(units) - len(want) + 1):
            if [u[2] for u in units[s:s + len(want)]] != want:
                continue
            a, b = units[s][0], units[s + len(want) - 1][0]
            if text[a:b + 1] != word:
                text = text[:a] + word + text[b + 1:]
            break
    return text


def _leading_span(text: str, word: str) -> tuple[int, int] | None:
    """句首少了头一个字也算数：录音开头常被吞掉，"飞鱼把颜色…"其实是在喊"大肥鱼"。

    只认句首，而且要求连续两个字完全对上，所以"这条飞鱼真好看"这种不会误触发。
    """
    want = [_unit_syllable(ch) for ch in word if _ALNUM.match(ch)]
    if len(want) < 3 or not _HAS_PINYIN:
        return None
    units = [(i, _unit_syllable(ch)) for i, ch in enumerate(text) if _ALNUM.match(ch)]
    if len(units) < 2:
        return None
    for run in range(len(want) - 1, 1, -1):          # 3 字的词先试 2 字
        for at in (0, len(want) - run):
            piece = want[at:at + run]
            if [u[1] for u in units[:run]] == piece:
                return units[0][0], units[run - 1][0]
    return None


def extract_word(text: str, words: list[str], fuzzy: bool = True,
                 leading: bool = True) -> tuple[str, bool]:
    """把触发词从句子里摘出来，返回 (剩下的正文, 有没有出现触发词)。

    fuzzy / leading 是唤醒档位里的两个开关：同音字容错、开头吞字容错。
    """
    hit = False
    out = text
    for word in words:
        if not word:
            continue
        pattern = re.compile(_word_pattern(word))
        if pattern.search(out):
            hit = True
            out = pattern.sub("", out)
            continue
        span = _fuzzy_span(out, word) if fuzzy else None   # 逐字没中，再按同音字找一次
        if span is not None:
            hit = True
            out = out[:span[0]] + out[span[1] + 1:]
            continue
        span = _leading_span(out, word) if leading else None   # 开头被吞掉半个词
        if span is not None:
            hit = True
            out = out[:span[0]] + out[span[1] + 1:]
    return out.strip(" ，,、。.!！?？"), hit


# ---------------------------------------------------------------------------
# 取消词：**严格判定**。
# 以前是拿唤醒档位那套"同音容错"去整句里找取消词，于是：
#   · "取笑他""去小卖部"这种一听就是正经话的，也可能被当成取消；
#   · 更糟的是 canonize 会把"别取笑他了"改成"别取消他了"，你发出去的话被换掉。
# 现在规矩很简单 —— **整句话就是那个取消词才算数**：
#   ① 整句（去掉标点、去掉尾巴上的语气词）正好等于取消词："取消" / "取消吧" / "取消掉"；
#   ② 整句跟取消词一样长、拼音一模一样："取笑" → "取消"（真同音，Whisper 常这么写）；
# 其余一概不算取消，原话照发。句子里夹着"取消"的长句（"帮我取消明天的提醒"）
# 从来就不是取消指令，它是你要发给 AI 的话。
_CANCEL_TAIL = "吧了呀啊哦噢呢嘛哈嗯的掉咯"
_CANCEL_PUNCT = re.compile(r"[\s，,、。.!！?？~～…\-—_*·]+")


def cancel_hit(text: str, words: list[str]) -> bool:
    """整句就是取消词吗（允许同音、允许后面带个语气词）？严格版。"""
    plain = _CANCEL_PUNCT.sub("", text or "")
    if not plain:
        return False
    cands = {plain}
    core = plain
    while core and core[-1] in _CANCEL_TAIL:      # 取消吧 / 取消掉 / 取消了啊
        core = core[:-1]
        cands.add(core)
    for word in words:
        w = (word or "").strip()
        if not w:
            continue
        if w in cands:
            return True
        if not _HAS_PINYIN:
            continue
        want = [_unit_syllable(ch) for ch in w]
        if not want:
            continue
        for c in cands:                            # 同音但整句等长：取笑 → 取消
            if len(c) == len(w) and [_unit_syllable(ch) for ch in c] == want:
                return True
    return False


def looks_like_wake(text: str, words: list[str]) -> bool:
    """这句是不是"喊唤醒词喊错了字"？

    真机出过：你说「大肥鱼」，Whisper 写成「大肥大」—— 唤醒没触发，这句反而被当成
    "你要发的话"发进聊天窗口了。这种"就这么几个字、前两个音跟唤醒词一样"的短句，
    一律当唤醒处理（叮一声接着听你说），绝不往外发。
    """
    plain = re.sub(r"[\s，,。.!！?？~～…\-—_*·]+", "", text or "")
    if not plain or not words:
        return False
    for word in words:
        w = re.sub(r"[\s，,。.!！?？]+", "", word or "")
        if len(w) < 3 or len(plain) > len(w) + 1:
            continue                      # 太长的一定是正经话，不是喊错字
        want = [_unit_syllable(ch) for ch in w[:2]]        # 只看前两个音
        got = [_unit_syllable(ch) for ch in plain]
        if len(got) >= 2 and got[:2] == want:
            return True                    # 就这么几个字，前两个音对上了 → 当你在喊它
    return False


def join_sentences(parts: list[str], lang: str) -> str:
    """中文句子直接拼，英文之间补空格。"""
    if not parts:
        return ""
    if lang.startswith("zh"):
        return "".join(parts)
    out = parts[0]
    for part in parts[1:]:
        out += " " + part
    return out


def guess_mood(audio: np.ndarray, sr: int, text: str) -> str:
    """从"说得多快、多响"猜个语气，给悬浮窗调颜色和形态用。

    只看语速和音量，不做模型推断 —— 猜错也就是颜色变一下，不会有别的后果。
    """
    step = max(1, int(sr * 0.02))
    blocks = [audio[i:i + step] for i in range(0, max(1, audio.size - step), step)]
    levels = [float(np.sqrt(np.mean(np.square(b)) + 1e-12)) for b in blocks if b.size]
    if not levels:
        return ""
    peak = max(levels)
    voiced = sum(1 for v in levels if v > 0.02)
    seconds = max(0.4, voiced * 0.02)
    chars = len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text or ""))
    speed = chars / seconds
    if speed >= 5.2 or peak >= 0.30:
        return "急"
    if speed <= 3.0 or peak <= 0.055:
        return "轻"
    return ""


def clear_all_data() -> int:
    """把便签/记账/记忆/日志/成就/日记全清掉，返回删了几个文件。"""
    victims = [SYSLOG_FILE, SAID_FILE, DIARY_FILE, MEM_FILE, LEDGER_FILE, ACHV_FILE,
               VP_FILE, HERE / "transcripts.md", HERE / "last.txt", HERE / "notes.md"]
    done = 0
    for path in victims:
        try:
            if path.exists():
                path.unlink()
                done += 1
        except Exception:
            pass
    return done


BACKUP_DIR = HERE / "导出"


def backup_dir() -> Path:
    """导出包 / 诊断包统一放这儿（<程序目录>\\导出），并把这个文件夹设成"隐藏"。

    以前是直接扔桌面，桌面上很快就堆一串 zip。现在好好藏起来：
    要看得见的话 —— 设置 → 功能 → 备份与诊断 → 「打开文件夹」。
    """
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            try:
                ctypes.windll.kernel32.SetFileAttributesW(str(BACKUP_DIR), 0x02)  # 隐藏
            except Exception:
                pass
        return BACKUP_DIR
    except Exception:
        return HERE          # 实在建不出来也别往桌面写


def unique_path(path: Path) -> Path:
    """同一分钟里点了两次导出，别把前一个覆盖掉：后面挂个 -2、-3。"""
    if not path.exists():
        return path
    for i in range(2, 100):
        cand = path.with_name(f"{path.stem}-{i}{path.suffix}")
        if not cand.exists():
            return cand
    return path


def diag_pack() -> Path | None:
    """出问题时打一个"诊断包"：日志尾巴 + 配置（去掉敏感项）+ 版本环境。

    给维护的人看的时候，比"我这边好像坏了"有用得多。
    """
    import platform
    import zipfile

    out = unique_path(backup_dir() /
                      f"语音助手诊断-{datetime.now().strftime('%Y%m%d-%H%M')}.zip")
    secret = {"voice", "corrections"}
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            info = [f"时间：{datetime.now():%Y-%m-%d %H:%M:%S}",
                    f"系统：{platform.platform()}",
                    f"Python：{sys.version.split()[0]}",
                    f"目录：{HERE}"]
            try:
                import sounddevice as _sd

                info.append(f"音频设备数：{len(_sd.query_devices())}")
            except Exception:
                pass
            zf.writestr("环境.txt", "\n".join(info) + "\n")
            for name in ("voice.log", "syslog.md", "watchdog.log", "overlay-exit.log",
                         "pet-error.log", "tray-error.log", "last-crash.txt"):
                path = HERE / name
                if not path.exists():
                    continue
                try:
                    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
                    zf.writestr(name, "\n".join(lines[-400:]) + "\n")
                except Exception:
                    pass
            try:
                data = load_config()
                for k in secret:
                    data.pop(k, None)
                zf.writestr("config.json", json.dumps(data, ensure_ascii=False, indent=2))
            except Exception:
                pass
    except Exception:
        return None
    return out


def export_data() -> Path | None:
    """把数据打包（藏进导出文件夹），方便换电脑或备份。"""
    import zipfile

    out = unique_path(backup_dir() /
                      f"语音助手数据-{datetime.now().strftime('%Y%m%d-%H%M')}.zip")
    files = [SYSLOG_FILE, SAID_FILE, DIARY_FILE, MEM_FILE, LEDGER_FILE, ACHV_FILE,
             VP_FILE, CONFIG_FILE, HERE / "transcripts.md", HERE / "notes.md"]
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for path in files:
                if path.exists():
                    zf.write(path, path.name)
    except Exception:
        return None
    return out


def import_data() -> tuple[int, str]:
    """从最新的一份导出包里恢复数据（先备份现在的）。

    先看新的"导出"文件夹；老版本留在桌面的包也照样认。
    """
    import zipfile

    folders = [backup_dir()]
    desktop = Path(os.path.expanduser("~")) / "Desktop"
    if not desktop.is_dir():
        desktop = Path(os.path.expanduser("~")) / "桌面"
    if desktop.is_dir():
        folders.append(desktop)          # 兼容老版本直接扔桌面的包
    packs = sorted(p for folder in folders for p in folder.glob("语音助手数据-*.zip"))
    if not packs:
        return 0, "没找到导出包（设置 → 功能 → 备份与诊断 里可以导出一份）"
    newest = packs[-1]
    # 先把包整个读进内存，再备份现在的数据 —— 不然"自动备份"可能刚好和
    # 要导入的那个包撞名（同一分钟里导出两次），把源包覆盖掉，就白导了。
    try:
        with zipfile.ZipFile(newest) as zf:
            payload = [(name, zf.read(name)) for name in zf.namelist()
                       if Path(name).name == name]       # 只认平铺的文件名，防目录穿越
    except Exception as exc:  # noqa: BLE001
        return 0, f"导入失败：{type(exc).__name__}"
    backup = export_data()
    n = 0
    for name, blob in payload:
        try:
            (HERE / name).write_bytes(blob)
            n += 1
        except Exception:  # noqa: BLE001
            pass
    tip = f"，导入前的旧数据备份在 {backup.name}" if backup else ""
    return n, f"恢复了 {n} 个文件{tip}"


def newer_package() -> tuple[Path, str] | None:
    """看看旁边有没有比本机新的一份（安装包解压出来的、更新包解压出来的都算）。"""
    import importlib.util

    import version as mine

    for pkg in sorted(HERE.parent.glob("*")):
        if not pkg.is_dir() or pkg.resolve() == HERE.resolve():
            continue
        if not (pkg / "version.py").exists():
            continue
        try:
            spec = importlib.util.spec_from_file_location("pkg_version", pkg / "version.py")
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            if getattr(mod, "UPDATES", 0) > mine.UPDATES:
                return pkg, getattr(mod, "APP_VERSION", "?")
        except Exception:
            continue
    return None


def apply_update(pkg: Path) -> int:
    """把安装包里更新的程序文件覆盖到本机（不动配置和模型）。"""
    keep = {"config.json", "version.py.bak"}
    copied = 0
    for path in list(pkg.glob("*.py")) + list(pkg.glob("*.ico")) + list(pkg.glob("*.png")):
        if path.name in keep:
            continue
        try:
            (HERE / path.name).write_bytes(path.read_bytes())
            copied += 1
        except Exception:
            pass
    for assets in pkg.glob("assets/*"):          # 背景图、桌宠素材这些也一起更新
        if not assets.is_file():
            continue
        try:
            target = HERE / "assets" / assets.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(assets.read_bytes())
            copied += 1
        except Exception:
            pass
    for doc in ("使用教程.html", "使用教程.md", "说明书.html", "说明书.md",
                "README-FIRST.txt", "使用说明.txt"):   # 文档也跟上
        src = pkg / doc
        if not src.is_file():
            continue
        try:
            (HERE / doc).write_bytes(src.read_bytes())
            copied += 1
        except Exception:
            pass
    return copied


def chars_per_second(audio: np.ndarray, sr: int, text: str) -> float:
    """这句话说得有多快（字/秒），疲劳提醒用它做基准。"""
    step = max(1, int(sr * 0.02))
    blocks = [audio[i:i + step] for i in range(0, max(1, audio.size - step), step)]
    voiced = sum(1 for b in blocks if b.size and float(np.sqrt(np.mean(b ** 2))) > 0.02)
    seconds = max(0.4, voiced * 0.02)
    return len(re.findall(r"[\u4e00-\u9fffA-Za-z0-9]", text or "")) / seconds


def decode_audio_file(path: str) -> np.ndarray:
    """读一个音频/视频文件成 16k 单声道浮点数组。"""
    from faster_whisper.audio import decode_audio

    return decode_audio(path, sampling_rate=TARGET_SR)


# ------------------------------------------------------------------ 按键监听

_VK_NAMED = {
    "space": 0x20, "空格": 0x20,
    "shift": 0x10, "ctrl": 0x11, "control": 0x11, "alt": 0x12,
    "multiply": 0x6A, "numpad*": 0x6A, "numpad+": 0x6B, "numpad-": 0x6D, "numpad/": 0x6F,
}


class KeyWatcher:
    """全局检测某个键是否被按住（不依赖窗口焦点）。"""

    def __init__(self, spec: str):
        if os.name != "nt":
            raise SystemExit("按住说话模式目前只支持 Windows。")
        user32 = ctypes.windll.user32
        user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        user32.GetAsyncKeyState.restype = ctypes.c_short
        self._user32 = user32
        self.spec = spec

        s = spec.strip().lower()
        if s in ("*", "星号"):
            # 小键盘 * 优先，同时兼容 Shift+8 打出的 *
            self._codes = [(0x6A, None)]
            self._shift_pair = (0x10, 0x38)
        elif s in ("-", "－", "减号"):
            # 主键盘的 - 键和小键盘 - 都认
            self._codes = [(0x2D, None), (0x6D, None)]
            self._shift_pair = None
        elif s in _VK_NAMED:
            self._codes = [(_VK_NAMED[s], None)]
            self._shift_pair = None
        elif len(s) == 2 and s[0] == "f" and s[1].isdigit() and 1 <= int(s[1]) <= 9:
            self._codes = [(0x6F + int(s[1]), None)]
            self._shift_pair = None
        elif s in ("f10", "f11", "f12"):
            self._codes = [(0x70 + int(s[1:]) - 10, None)]
            self._shift_pair = None
        elif len(spec.strip()) == 1:
            self._codes = [(ord(spec.strip().upper()), None)]
            self._shift_pair = None
        else:
            raise SystemExit(
                f"认不出这个键：{spec}。可以用 * / space / f9 / a ~ z / 0 ~ 9 / numpad+ 这类写法。"
            )

    def _down(self, vk: int) -> bool:
        return bool(self._user32.GetAsyncKeyState(vk) & 0x8000)

    def down(self) -> bool:
        if any(self._down(vk) for vk, _ in self._codes):
            return True
        if self._shift_pair:
            return self._down(self._shift_pair[0]) and self._down(self._shift_pair[1])
        return False


def beep(freq: int, ms: int, enabled: bool) -> None:
    """用系统提示音告诉用户"开始/结束"了，不用盯着窗口。"""
    if not enabled or os.name != "nt":
        return
    try:
        import winsound

        winsound.Beep(freq, ms)
    except Exception:
        pass


# ------------------------------------------------------- 前台窗口 / 自动发送

def _win32():
    """拿到 user32 / kernel32，并把签名配好（64 位下窗口句柄必须按指针处理）。"""
    from ctypes import wintypes

    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    if _win32.ready:
        return u, k
    u.GetForegroundWindow.restype = wintypes.HWND
    u.SetForegroundWindow.argtypes = [wintypes.HWND]
    u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.c_void_p]
    u.GetWindowThreadProcessId.restype = wintypes.DWORD
    u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
    u.BringWindowToTop.argtypes = [wintypes.HWND]
    u.SetFocus.argtypes = [wintypes.HWND]
    u.IsIconic.argtypes = [wintypes.HWND]
    u.IsWindowVisible.argtypes = [wintypes.HWND]
    u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u.EnumWindows.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    u.keybd_event.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, wintypes.DWORD, ctypes.c_void_p]
    k.GetConsoleWindow.restype = wintypes.HWND
    k.GetCurrentThreadId.restype = wintypes.DWORD
    _win32.ready = True
    return u, k


_win32.ready = False


class ForegroundTracker:
    """记住"你上一個在用的窗口"，这样粘文字时不会粘到我们这个黑窗口里。"""

    SKIP = {
        "ConsoleWindowClass", "Progman", "WorkerW", "Shell_TrayWnd",
        "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow",
        "XamlExplorerHostIslandWindow", "ForegroundStaging", "ApplicationFrameWindow",
    }

    def __init__(self) -> None:
        self.console = _win32()[1].GetConsoleWindow()
        self.hwnd = 0
        self.title = ""

    def _class_name(self, hwnd: int) -> str:
        buf = ctypes.create_unicode_buffer(256)
        _win32()[0].GetClassNameW(hwnd, buf, 256)
        return buf.value

    def poll(self) -> None:
        hwnd = _win32()[0].GetForegroundWindow()
        if not hwnd or hwnd == self.console:
            return
        if self._class_name(hwnd) in self.SKIP:
            return
        buf = ctypes.create_unicode_buffer(512)
        _win32()[0].GetWindowTextW(hwnd, buf, 512)
        if not buf.value:  # 没有标题的窗口一般是辅助窗口
            return
        self.hwnd, self.title = hwnd, buf.value


def _key(vk: int, up: bool = False) -> None:
    _win32()[0].keybd_event(vk, 0, 2 if up else 0, None)
    time.sleep(0.02)


def focus_window(hwnd: int) -> bool:
    """把目标窗口切到最前面，并确认真的切过去了。

    Windows 不允许后台程序随便抢前台，所以要用 AttachThreadInput 把我们的线程
    和当前前台窗口的线程"绑"一下，再 SetForegroundWindow；不行就退回 Alt 那一招。
    """
    u = _win32()[0]
    if not hwnd:
        return False
    if u.GetForegroundWindow() == hwnd:
        return True
    if u.IsIconic(hwnd):  # 最小化了就先还原
        u.ShowWindow(hwnd, 9)  # SW_RESTORE
        time.sleep(0.25)

    our_thread = _win32()[1].GetCurrentThreadId()
    fg = u.GetForegroundWindow()
    fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
    attached = False
    if fg_thread and fg_thread != our_thread:
        attached = bool(u.AttachThreadInput(fg_thread, our_thread, True))
    try:
        u.BringWindowToTop(hwnd)
        u.SetForegroundWindow(hwnd)
    finally:
        if attached:
            u.AttachThreadInput(fg_thread, our_thread, False)

    time.sleep(0.2)
    if u.GetForegroundWindow() != hwnd:  # 兜底：敲一下 Alt 再抢一次
        _key(0x12)
        u.SetForegroundWindow(hwnd)
        _key(0x12, up=True)
        time.sleep(0.2)
    return u.GetForegroundWindow() == hwnd


def find_window(pattern: str) -> tuple[int, str]:
    """按标题关键字找一个可见窗口，返回 (句柄, 标题)。"""
    from ctypes import wintypes

    u = _win32()[0]
    hits: list[tuple[int, str]] = []
    target = pattern.lower()

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        if not u.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        if buf.value and target in buf.value.lower():
            hits.append((hwnd, buf.value))
            return False  # 找到第一个就停
        return True

    u.EnumWindows(cb, None)
    return hits[0] if hits else (0, "")


# 手机那边可以挑"这句话发到哪个聊天窗口"（手机上那个「对话窗口」页）。
# 空字符串 = 交回自动（跟电脑上的规矩：跟随前台 / 按 target 找）。
PHONE_WINDOW: dict[str, str] = {"title": ""}

# 系统壳子类的窗口名（列"能当聊天窗口"的时候要跳过）。
# 注意：WindowTracker.SKIP 是定义在 main() 里的嵌套类，模块级拿不到它 ——
# 以前这里引用它就抛 AttributeError，被 except 吞掉，结果窗口列表永远是空的。
WINDOW_SKIP_CLASSES = {
    "ConsoleWindowClass", "Progman", "WorkerW", "Shell_TrayWnd",
    "Shell_SecondaryTrayWnd", "Windows.UI.Core.CoreWindow",
    "XamlExplorerHostIslandWindow", "ForegroundStaging", "ApplicationFrameWindow",
    "CEF-OSC-WIDGET", "MultitaskingViewFrame", "TaskListThumbnailWnd",
    "Windows.UI.Composition.DesktopWindowContentBridge",
}
# 标题里带这些词的一般不是"聊天窗口"，是各种浮层/输入法/系统提示
WINDOW_SKIP_WORDS = ("overlay", "输入体验", "text input application",
                     "program manager", "default ime", "msctfime",
                     "windows input experience", "nvidia share")


def list_chat_windows() -> list[dict]:
    """电脑上现在有哪些窗口可以当"聊天窗口"（手机页面上列出来给人挑）。

    只挑：看得见的、有标题的、不是我们自己的、不是系统壳子的、尺寸像正经窗口的。
    同一个标题只留一个（很多程序会有一堆同名的辅助窗）。
    """
    from ctypes import wintypes

    u = _win32()[0]
    found: list[str] = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        try:
            if not u.IsWindowVisible(hwnd) or is_our_window(hwnd):
                return True
            buf = ctypes.create_unicode_buffer(512)
            u.GetWindowTextW(hwnd, buf, 512)
            title = buf.value.strip()
            if not title or len(title) > 120:
                return True
            low = title.lower()
            if any(w in low for w in WINDOW_SKIP_WORDS):
                return True
            cls = ctypes.create_unicode_buffer(256)
            u.GetClassNameW(hwnd, cls, 256)
            if cls.value in WINDOW_SKIP_CLASSES:
                return True
            rect = wintypes.RECT()
            u.GetWindowRect(hwnd, ctypes.byref(rect))
            if rect.right - rect.left < 240 or rect.bottom - rect.top < 160:
                return True                      # 工具条、气泡提示不算
            if title not in found:
                found.append(title)
        except Exception:
            pass
        return True

    u.EnumWindows(cb, None)
    return [{"title": t} for t in found]


def exact_window(title: str) -> int:
    """按标题**一模一样**找窗口（比关键字匹配靠谱，避免"Codex"匹到一串）。"""
    from ctypes import wintypes

    u = _win32()[0]
    want = str(title or "").strip().lower()
    if not want:
        return 0
    hit = {"hwnd": 0}

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def cb(hwnd, _lparam):
        if not u.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        if buf.value.strip().lower() == want:
            hit["hwnd"] = int(hwnd)
            return False
        return True

    u.EnumWindows(cb, None)
    return hit["hwnd"]


def phone_window() -> tuple[int, str]:
    """手机选了某个 Codex 会话时，目标就是 Codex 窗口。

    （用户澄清过："对话窗口"是他和我的**会话**，不是电脑窗口。会话是在 App 里点的，
    所以这里只要把目标定在 Codex 窗口上，发送前再确保它开在那个会话上就行。）
    """
    title = str(PHONE_WINDOW.get("title") or "").strip()
    if not title:
        return 0, ""
    hwnd, win_title = find_window("ChatGPT")
    if not hwnd:
        hwnd, win_title = find_window("Codex")
    return (hwnd, win_title) if hwnd else (0, "")


def set_phone_window(title: str) -> tuple[bool, str]:
    """手机那边选会话：真的去点 App 侧栏里那个会话，让它切过去。

    传空字符串 = 切回"自动"（电脑上开着哪个就发哪个）。
    """
    title = str(title or "").strip()
    if not title:
        PHONE_WINDOW["title"] = ""
        saved = ""
    else:
        try:
            import codex_threads

            ok, msg = codex_threads.open_thread(title)
        except Exception as exc:            # noqa: BLE001
            ok, msg = False, f"{type(exc).__name__}: {exc}"
        if not ok:
            return False, str(msg)[:80]
        PHONE_WINDOW["title"] = title
        saved = title
    try:                        # 记进配置，重启之后还是这个
        data = load_config()
        data["phone_target"] = saved
        CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                               encoding="utf-8")
    except Exception:
        pass
    syslog("窗", f"手机切对话窗口：{saved or '自动'}")
    return True, saved or "自动"


def paste_into(
    text: str,
    hwnd: int | None = None,
    press_enter: bool = True,
    clear_first: bool = True,
) -> bool:
    """把文字粘到目标窗口（默认回车发送）。返回是否真的粘到了那个窗口。

    clear_first 会先全选再粘贴，免得输入框里原有内容被一起发出去。
    """
    if not copy_to_clipboard(text):
        return False
    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    if clear_first:
        _key(0x11)          # Ctrl
        _key(0x41)          # A：全选，等一下粘贴就会把它替换掉
        _key(0x41, up=True)
        _key(0x11, up=True)
        time.sleep(0.12)
    _key(0x11)          # Ctrl
    _key(0x56)          # V
    _key(0x56, up=True)
    _key(0x11, up=True)
    time.sleep(0.18)
    if press_enter and focused:
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


def type_text_hwnd(text: str, hwnd: int | None, press_enter: bool = False) -> bool:
    """一个字一个字敲进去（走 SendInput 的 Unicode 通道），不碰剪贴板。

    有些窗口粘贴会出问题（比如聊天框里贴进去变成附件、或者把全文选中删了），
    那就用这个模式当打字机使。
    """
    if os.name != "nt" or not text:
        return False
    ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                    ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                    ("dwExtraInfo", ULONG_PTR)]

    class _U(ctypes.Union):
        _fields_ = [("ki", KEYBDINPUT)]

    class INPUT(ctypes.Structure):
        _fields_ = [("type", ctypes.c_ulong), ("u", _U)]

    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    buf = []
    for ch in text:
        code = ord(ch)
        buf.append(INPUT(type=1, u=_U(ki=KEYBDINPUT(0, code, 0x0004, 0, 0))))
        buf.append(INPUT(type=1, u=_U(ki=KEYBDINPUT(0, code, 0x0004 | 0x0002, 0, 0))))
        if len(buf) >= 40:
            arr = (INPUT * len(buf))(*buf)
            ctypes.windll.user32.SendInput(len(buf), ctypes.byref(arr), ctypes.sizeof(INPUT))
            buf = []
            time.sleep(0.02)
    if buf:
        arr = (INPUT * len(buf))(*buf)
        ctypes.windll.user32.SendInput(len(buf), ctypes.byref(arr), ctypes.sizeof(INPUT))
    if press_enter:
        time.sleep(0.2)
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


def paste_clipboard(hwnd: int | None, press_enter: bool = True,
                    clear_first: bool = False) -> bool:
    """把"已经在剪贴板里的东西"粘到目标窗口（图/文都行），不动剪贴板本身。"""
    focused = True
    if hwnd:
        focused = focus_window(hwnd)
    time.sleep(0.15)
    if clear_first:
        _combo(0x41, _VK_CTRL)          # Ctrl+A
    _combo(0x56, _VK_CTRL)              # Ctrl+V
    if press_enter:
        time.sleep(0.2)
        _key(0x0D)
        _key(0x0D, up=True)
    return focused


class Recorder:
    """从流里按块读取，用能量判断说话起止。"""

    def __init__(
        self,
        stream,
        samplerate: int,
        silence: float,
        max_seconds: float,
        min_voiced: float = 0.45,
        noise_mult: float = 6.0,
        confirm: int = 3,
        device=None,
    ):
        self.stream = stream
        self.device = device            # 睡醒重开麦克风要知道是哪个设备
        self.sr = samplerate
        self.blocksize = 1024
        self.noise_mult = max(1.0, float(noise_mult))
        self.confirm = max(1, int(confirm))
        # 滚动噪声底：光用一次"中位数×倍数"会被电视这种持续底噪骗，改用最近几秒的低分位
        self.noise_hist: collections.deque = collections.deque(maxlen=220)
        self.last_cut = False          # 上一句是不是"录到最长时长被切断"的
        self.silence_blocks = max(1, int(silence * samplerate / self.blocksize))
        self.max_blocks = int(max_seconds * samplerate / self.blocksize)
        self.preroll_blocks = max(1, int(0.3 * samplerate / self.blocksize))
        self.min_voiced_blocks = max(1, int(min_voiced * samplerate / self.blocksize))

    def _read(self) -> np.ndarray:
        # 睡一觉醒来之后，音频流经常就死了（Windows 睡眠会把设备句柄搞坏）,
        # 所以这里做两件事：①两次读之间隔了很久 → 认为刚睡醒，顺手检查/重开；
        # ②读的时候报错 → 自己重开一次再读，不让整个程序因为睡了一觉就废掉。
        now = time.monotonic()
        gap = now - getattr(self, "_last_read", now)
        if gap > 20.0:
            self.after_sleep(gap)
        self._last_read = now
        try:
            data, _overflowed = self.stream.read(self.blocksize)
        except Exception as exc:                # noqa: BLE001
            if self.reopen_stream(f"读不到音频（{type(exc).__name__}）"):
                data, _overflowed = self.stream.read(self.blocksize)
            else:
                raise
        return data[:, 0].copy()

    def reopen_stream(self, why: str = "") -> bool:
        """把麦克风重开一次（睡醒恢复用）。成功返回 True。"""
        if getattr(self, "_reopening", False):      # 别递归
            return False
        self._reopening = True
        try:
            try:
                self.stream.stop()
                self.stream.close()
            except Exception:
                pass
            for attempt in (1, 2, 3):
                try:
                    stream, rate = open_stream(getattr(self, "device", None), self.sr)
                except (Exception, SystemExit) as exc:      # noqa: BLE001
                    print(f"   ↳ 第 {attempt} 次重开麦克风没成：{exc}", flush=True)
                    time.sleep(1.5)
                    continue
                self.stream = stream
                if rate != self.sr:                 # 采样率变了，块长跟着重算
                    self.sr = rate
                    self.blocksize = max(256, int(round(0.064 * rate)))
                    self.silence_blocks = max(1, int(0.75 * rate / self.blocksize))
                    self.max_blocks = int(30 * rate / self.blocksize)
                    self.preroll_blocks = max(1, int(0.3 * rate / self.blocksize))
                    self.min_voiced_blocks = max(1, int(0.18 * rate / self.blocksize))
                try:
                    self.flush()                    # 把积压的旧数据丢掉
                except Exception:
                    pass
                self.noise_hist.clear()             # 环境变了，噪声底重新学
                self._last_read = time.monotonic()
                who = why or "睡醒恢复"
                print(f"   ↳ 🔌 麦克风已经重开好了（{who}）", flush=True)
                syslog("检", f"麦克风重开成功（{who}）")
                return True
            return False
        finally:
            self._reopening = False

    def after_sleep(self, gap: float) -> None:
        """刚睡醒：报一句、清掉旧的噪声底，然后试着读一下看设备还活着没。"""
        print(f"\n😴 刚才睡了大约 {gap:.0f} 秒，检查一下麦克风…", flush=True)
        syslog("检", f"检测到睡眠约 {gap:.0f} 秒，正在检查麦克风")
        self.noise_hist.clear()
        try:
            self.stream.read(self.blocksize)
            print("   ↳ 麦克风还在，继续听", flush=True)
            syslog("检", "睡醒后麦克风正常")
        except Exception as exc:                    # noqa: BLE001
            print(f"   ↳ 麦克风死了（{type(exc).__name__}），重开", flush=True)
            self.reopen_stream(f"睡醒后音频流坏了（{type(exc).__name__}）")

    def flush(self) -> None:
        """把设备缓冲区里积压的旧数据读掉。"""
        for _ in range(3):
            self._read()

    def calibrate(self, seconds: float = 0.5) -> float:
        """测环境噪音，返回起始判定阈值。

        用最近几秒的 15% 分位当"底噪"，再乘档位倍数。中位数在有人讲话/开电视时
        会往上飘，分位数稳得多。
        """
        levels = [rms(self._read()) for _ in range(max(1, int(seconds * self.sr / self.blocksize)))]
        self.noise_hist.extend(levels)
        if self.noise_hist:
            noise = float(np.percentile(np.fromiter(self.noise_hist, dtype=float), 15))
        else:
            noise = float(np.median(levels)) if levels else 0.0
        return max(noise * self.noise_mult, 0.012)

    def record_utterance(self, threshold: float, on_speech=None, tick=None,
                         on_level=None, on_partial=None, partial_every: float = 0.6
                         ) -> np.ndarray | None:
        """等到有人说话，录到停顿为止。没听到说话返回 None。

        tick 每读一块音频就调一次，返回 True 表示立刻中止（比如用户按了暂停）。
        on_partial 会边录边把"已经攒到的音频"回传，用来做实时字幕。
        """
        preroll: list[np.ndarray] = []
        frames: list[np.ndarray] = []
        silent_run = 0
        above = 0
        voiced = 0
        partial_at = 0.0
        peak = 0.0
        speaking = False

        while True:
            block = self._read()
            if tick is not None and tick():
                return None
            level = rms(block)
            self.noise_hist.append(level)          # 滚动噪声底一直跟着环境走
            if on_level:
                try:
                    on_level(level, block)
                except TypeError:
                    on_level(level)
            if not speaking:
                preroll.append(block)
                if len(preroll) > self.preroll_blocks:
                    preroll.pop(0)
                above = above + 1 if level > threshold else 0
                if above >= self.confirm:  # 连续几块够响，才认为真的开口了
                    speaking = True
                    frames = list(preroll)
                    voiced = sum(1 for b in frames if rms(b) > threshold)
                    if on_speech:
                        on_speech()
                continue

            frames.append(block)
            peak = max(peak, level)
            if on_partial is not None:          # 边录边送一点出去做实时字幕
                seconds = len(frames) * self.blocksize / self.sr
                if seconds >= 0.7 and seconds - partial_at >= partial_every:
                    partial_at = seconds
                    try:
                        on_partial(np.concatenate(frames))
                    except Exception:
                        pass
            if level > threshold:
                voiced += 1
                silent_run = 0
            else:
                silent_run += 1
            if silent_run >= self.silence_blocks or len(frames) >= self.max_blocks:
                audio = np.concatenate(frames) if frames else np.array([], dtype=np.float32)
                self.last_cut = len(frames) >= self.max_blocks
                if voiced < self.min_voiced_blocks:  # 响一下就没声了，当噪音丢掉
                    return None
                # 录了 4 秒还一直贴着门槛（峰值连 1.8 倍都不到）：这是底噪在蹭，不是人话
                if len(frames) * self.blocksize / self.sr >= 4.0 and peak < threshold * 1.8:
                    return None
                return resample_to_16k(audio, self.sr)

    def record_hold(
        self,
        key_down,
        min_seconds: float = 0.25,
        tail_blocks: int = 2,
        on_start=None,
        on_stop=None,
        meter: bool = False,
        on_level=None,
    ) -> np.ndarray | None:
        """按住键说话：空闲时持续丢弃音频让缓冲区保持最新，按下才真正记录。"""
        preroll: list[np.ndarray] = []
        while not key_down():  # 等待按键；同时把设备里的旧音频读掉，避免松手后听到的是延迟内容
            preroll.append(self._read())
            if len(preroll) > self.preroll_blocks:
                preroll.pop(0)

        if on_start:
            on_start()
        frames = list(preroll)
        peak = max((rms(b) for b in frames), default=0.0)
        started = time.time()
        while key_down() or time.time() - started < min_seconds:
            block = self._read()
            frames.append(block)
            level = rms(block)
            peak = max(peak, level)
            if on_level:
                on_level(level)
            if meter:
                n = min(24, int(level * 240))
                tip = "  （声音偏小）" if level < 0.02 else " " * 12
                sys.stdout.write("\r🎙 录音中 " + "█" * n + "·" * (24 - n) + tip)
                sys.stdout.flush()
        for _ in range(tail_blocks):  # 松手后再收一点，别吃掉尾音
            frames.append(self._read())
        if on_stop:
            on_stop()
        if meter:
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()
            if peak < 0.02:
                print("  （麦克风几乎没收到声音：换个设备试试 --list-devices / --input USB，或者凑近点）")

        audio = np.concatenate(frames) if frames else np.array([], dtype=np.float32)
        if audio.size < int(min_seconds * self.sr):
            return None
        return resample_to_16k(audio, self.sr)


# -------------------------------------------------------------------- 识别

class Transcriber:
    def __init__(self, model_name: str, device: str, compute_type: str | None, language: str,
                 hotwords: str = ""):
        cuda_ready = register_cuda_dlls()
        from faster_whisper import WhisperModel
        self.language = language
        # 热词：把这些词塞进提示词，Whisper 更容易照原样写出来
        # （"大肥鱼"被听成"大飞鱼/大肥与悦"时就靠它拉回来）
        self.hotwords = " ".join((hotwords or "").split())
        # 低配机器上用贪心解码（beam=1）比 beam=5 快两三倍，准确率只差一点点
        self.beam = 5
        self._model_ref = None
        self._model_name = model_name
        self._requested = (device, compute_type)
        # 本地 models/ 目录里有现成的模型就直接用，避免再去联网下载
        local = HERE / "models" / f"faster-whisper-{model_name}"
        if local.is_dir():
            model_ref, where = str(local), f"本地 {local.name}"
        else:
            model_ref, where = model_name, f"{model_name}（首次会联网下载）"
        self._model_ref = model_ref
        attempts: list[tuple[str, str]] = []
        if device == "cuda" and not cuda_ready:
            print("  提示：没找到 cuBLAS/cuDNN，改用 CPU（想要显卡加速见 README 的 GPU 一节）", flush=True)
        if device in ("auto", "cuda") and cuda_ready:
            attempts.append(("cuda", compute_type or "float16"))
        if device == "cpu" or device == "auto" or not cuda_ready:
            attempts.append(("cpu", compute_type or "int8"))

        self.model = None
        for dev, ctype in attempts:
            try:
                print(f"  加载模型 {where}（{dev}/{ctype}）…", flush=True)
                self.model = WhisperModel(model_ref, device=dev, compute_type=ctype)
                self.device, self.compute_type = dev, ctype
                break
            except Exception as exc:  # noqa: BLE001
                print(f"  {dev} 不可用（{type(exc).__name__}: {str(exc)[:120]}）", flush=True)
        if self.model is None:
            raise SystemExit("模型加载失败。试试 --device cpu 或者 --model small。")

    def transcribe(self, audio: np.ndarray) -> str:
        with _ASR_LOCK:
            try:
                return self._run(audio)
            except RuntimeError as exc:  # 显卡缺库等情况：退回 CPU 再试一次
                if self.device != "cuda":
                    raise
                print(f"\n  （显卡推理失败：{str(exc)[:80]}，改用 CPU）", flush=True)
                from faster_whisper import WhisperModel

                self.model = WhisperModel(self._model_ref, device="cpu", compute_type="int8")
                self.device, self.compute_type = "cpu", "int8"
                return self._run(audio)

    def _run(self, audio: np.ndarray) -> str:
        segments, _info = self.model.transcribe(
            audio,
            language=self.language,
            beam_size=self.beam,
            vad_filter=True,
            condition_on_previous_text=False,
            initial_prompt=ASR_PROMPT,
            hotwords=self.hotwords or None,
        )
        parts = []
        for seg in segments:
            # 没人说话时 Whisper 爱凭空编句子，用置信度把这类结果挡掉
            if getattr(seg, "no_speech_prob", 0.0) > 0.55:
                continue
            if getattr(seg, "avg_logprob", 0.0) < -1.2:
                continue
            # 太短的碎片（不到 0.25 秒）基本是噪声被切出来的，不要
            try:
                if float(getattr(seg, "end", 0) or 0) - float(getattr(seg, "start", 0) or 0) < 0.25:
                    continue
            except Exception:
                pass
            # 单段就长得像字幕腔的废话，也别拼进去
            if is_hallucination(seg.text):
                continue
            parts.append(seg.text)
        text = "".join(parts).strip()
        if self.language.startswith("zh"):
            text = normalize_zh(text)
        return text

    def transcribe_file(self, path: str) -> str:
        from faster_whisper.audio import decode_audio

        audio = decode_audio(path, sampling_rate=TARGET_SR)
        return self.transcribe(audio)


# ---------------------------------------------------------------------- 唤醒词自检


class _FakeStream:
    """把一段内存里的音频假装成麦克风流，好让 Recorder 走一遍真实的判停逻辑。"""

    def __init__(self, audio: np.ndarray) -> None:
        self.audio = audio
        self.i = 0

    def read(self, n: int):
        chunk = self.audio[self.i:self.i + n]
        self.i += n
        if chunk.size < n:                     # 音频放完了：模拟"一直没有下一句"
            raise EOFError("测试音频放完了")
        if chunk.ndim == 1:
            chunk = chunk.reshape(-1, 1)
        return chunk, False


def _resample(audio: np.ndarray, sr_from: int, sr_to: int) -> np.ndarray:
    if sr_from == sr_to or audio.size == 0:
        return audio
    n = int(round(audio.size * sr_to / sr_from))
    return np.interp(np.linspace(0, audio.size - 1, n),
                     np.arange(audio.size), audio).astype(np.float32)


def _onset_index(audio: np.ndarray, sr: int, floor: float = 0.02) -> int:
    """第一个"够响"的采样点。合成语音前后都有一段静音，
    要模拟"开头被吞掉"必须从真正发声的地方开始掐，不然只掐掉了静音。"""
    step = max(1, int(sr * 0.01))
    for i in range(0, max(1, audio.size - step), step):
        if rms(audio[i:i + step]) > floor:
            return i
    return 0


def simulate_capture(audio: np.ndarray, sr: int, params: dict) -> np.ndarray | None:
    """按当前档位把音频喂给真实的 Recorder，看能不能被判成"一句人话"。"""
    rec = Recorder(_FakeStream(audio), sr, 1.0, 8.0,
                   min_voiced=params["min_voiced"],
                   noise_mult=params["noise_mult"],
                   confirm=params["confirm"])
    try:
        threshold = rec.calibrate(0.4)
        return rec.record_utterance(threshold)
    except EOFError:                            # 一直没触发 → 这句没接住
        return None


def wake_selftest(transcriber, cfg: dict, log=print) -> dict:
    """唤醒词自检：合成几段测试语音，走一遍真实的"判停 → 识别 → 匹配"。"""
    name, params = wake_levels.params(cfg)
    words = [w.strip() for w in str(cfg.get("wake_word") or "").split(",") if w.strip()][:3]
    result: dict = {"ts": time.time(), "ok": True, "level": name, "params": params,
                    "wake": words, "cases": [], "passed": 0, "total": 0, "summary": ""}
    if not words:
        result.update(ok=False, summary="没设置唤醒词，跳过自检")
        return result
    try:
        import say
    except Exception as exc:  # noqa: BLE001
        result.update(ok=False, summary=f"读不到 say.py，跳过自检（{type(exc).__name__}）")
        return result

    voice = str(cfg.get("voice") or "zh-CN-XiaoyiNeural")
    rate = str(cfg.get("rate") or "+8%")
    mic_sr = 48000
    old_hot = transcriber.hotwords
    if params.get("hotwords"):
        cancels = [w.strip() for w in str(cfg.get("cancel_word") or "").split(",") if w.strip()]
        transcriber.hotwords = " ".join(words + cancels)
    else:
        transcriber.hotwords = ""
    rng = np.random.default_rng(20261007)
    # (类型, 噪声强度, 音量系数, 掐掉开头多少毫秒)：覆盖日常最容易翻车的几种情况。
    # 后面三项只测第一个唤醒词，不然词一多要跑很久。
    plan = [("干净", 0.0, 1.0, 0), ("底噪", 0.012, 1.0, 0),
            ("小声", 0.006, 0.35, 0), ("吞字", 0.0, 1.0, 120)]
    try:
        for word in words:
            try:
                mp3 = say.edge_mp3(word, voice, rate)
                audio, sr = say.decode_audio(mp3)
            except Exception as exc:  # noqa: BLE001
                result.update(ok=False, wake=words,
                              summary=f"合成测试语音失败（{type(exc).__name__}），离线时跳过自检")
                return result
            base = _resample(np.asarray(audio, dtype=np.float32), sr, mic_sr)
            for kind, noise, gain, cut_ms in (plan if word == words[0] else plan[:2]):
                clip = base * gain
                if cut_ms:                      # 模拟录音开头被吞掉一小截（从真正发声处算）
                    clip = clip[_onset_index(clip, mic_sr) + int(cut_ms / 1000 * mic_sr):]
                if noise > 0:
                    clip = clip + rng.normal(0, noise, clip.size).astype(np.float32)
                peak = float(np.max(np.abs(clip))) or 1.0
                if peak > 0.85:
                    clip = clip / peak * 0.85
                clip = np.concatenate([np.zeros(int(0.6 * mic_sr), np.float32), clip,
                                       np.zeros(int(1.6 * mic_sr), np.float32)])
                captured = simulate_capture(clip, mic_sr, params)
                text, hit = "", False
                if captured is not None and captured.size:
                    text = transcriber.transcribe(captured)
                    hit = extract_word(text, [word], fuzzy=params["fuzzy"],
                                       leading=params["leading"])[1]
                result["cases"].append({"wake": word, "kind": kind, "noise": noise,
                                        "gain": gain, "cut_ms": cut_ms,
                                        "captured": captured is not None,
                                        "text": text, "hit": bool(hit)})
                log(f"   自检 {word}·{kind} → {text!r} "
                    f"{'✓' if hit else '✗'}")
    finally:
        transcriber.hotwords = old_hot

    result["total"] = len(result["cases"])
    result["passed"] = sum(1 for c in result["cases"] if c["hit"])
    result["summary"] = build_test_summary(result, name)
    return result


def build_test_summary(result: dict, level_name: str) -> str:
    total, passed = result.get("total", 0), result.get("passed", 0)
    if not total:
        return "自检没有可用的测试项"
    if passed == total:
        return f"唤醒自检：{total} 项全部通过，当前档位「{level_name}」"
    cases = result.get("cases") or []
    missed = {c.get("kind") for c in cases if not c["hit"]}
    names = list(wake_levels.LEVELS)
    tip = ""
    if level_name in names and names.index(level_name) < len(names) - 1:
        tip = f"，可以把档位调到「{names[names.index(level_name) + 1]}」"
    if "干净" in missed:
        return (f"唤醒自检：{total} 项里 {passed} 项通过。安静环境下都认不出来，"
                f"这个唤醒词可能不好念，换个词、或者多写几个用逗号隔开{tip}")
    if "吞字" in missed:
        return (f"唤醒自检：{total} 项里 {passed} 项通过。当前档位关掉了「开头吞字」容错，"
                f"录音开头少半个字就认不出来{tip}")
    if "小声" in missed:
        return f"唤醒自检：{total} 项里 {passed} 项通过，小声说的时候接不住{tip}"
    return f"唤醒自检：{total} 项里 {passed} 项通过，有底噪时不太稳{tip}"


# ---------------------------------------------------------------------- 主流程

def append_log(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with path.open("a", encoding="utf-8") as fh:
        fh.write(f"- {stamp} {privacy_clean(text)}\n")
    (path.parent / "last.txt").write_text(privacy_clean(text) + "\n", encoding="utf-8")


def wait_for_enter(prompt: str) -> None:
    print(prompt, end="", flush=True)
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        raise SystemExit(0) from None


def record_ptt(recorder: Recorder) -> np.ndarray:
    """回车开始 / 回车结束，靠 msvcrt 非阻塞读键。"""
    import msvcrt

    recorder.flush()
    wait_for_enter("\n按回车开始说话…")
    print("● 录音中（再按回车结束）…", end="", flush=True)
    frames: list[np.ndarray] = []
    while True:
        frames.append(recorder._read())
        while msvcrt.kbhit():
            if msvcrt.getwch() in ("\r", "\n"):
                print(" 停", flush=True)
                audio = np.concatenate(frames) if frames else np.array([], dtype=np.float32)
                return resample_to_16k(audio, recorder.sr)


def main() -> int:
    setup_console()
    ap = argparse.ArgumentParser(description="本地语音转文字（faster-whisper）")
    cfg = load_config()
    # 手机上上次挑的"发到哪个对话窗口"记在配置里，重启之后接着用
    PHONE_WINDOW["title"] = str(cfg.get("phone_target") or "")
    # 先看这台机器什么档次，低配就自动降级（不然大模型 + 实时字幕能把它拖死）
    PROFILE, HW = detect_profile()
    if PROFILE == "lite" and cfg.get("auto_tune", True):
        changed: list[str] = []
        if str(cfg.get("model") or "small") not in ("tiny", "base", "small"):
            cfg["model"] = "small"
            changed.append("模型换成 small")
        for key, want in (("caption_enabled", False), ("perf_mode", "eco"),
                          ("anim_fps", 30), ("fx_trail", False), ("fx_glow", False),
                          ("fx_sparkles", False), ("fx_reflection", False),
                          ("fx_sweep", False), ("fx_ripple", False),
                          ("fx_orbit", False), ("fx_rotor", False),
                          ("fx_starflare", False), ("fx_aurora", False),
                          ("fx_heartbeat", False), ("fx_burst", False),
                          ("karaoke", False),
                          ("big_caption", False), ("wave_spectrum", False)):
            if cfg.get(key) != want:
                cfg[key] = want
                changed.append(key)
        if changed and not cfg.get("auto_tuned"):
            cfg["auto_tuned"] = True
            cfg["auto_profile"] = "lite"
            try:
                CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
                print("（低配模式：已自动调低设置 — " + "、".join(changed[:6]) + "）")
            except Exception:
                pass
        elif changed:
            print("（低配模式：本次按低配参数运行）")
        print(f"（原因：{HW['why']}；内存 {HW['ram']:.0f}G / {HW['cores']} 核 "
              f"/ 显卡 {'有' if HW['cuda'] else '无'}）")
    if cfg:
        print(f"（已读 config.json：唤醒词「{cfg.get('wake_word', '大肥鱼')}」"
              f"，模型 {cfg.get('model', 'small')}）")
    ap.add_argument("--model", default=cfg.get("model") or "small",
                    help="模型：tiny/base/small/medium/large-v3/large-v3-turbo（默认 small）")
    ap.add_argument("--lang", default=cfg.get("lang") or "zh", help="语言代码，默认 zh；英文用 en")
    ap.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    ap.add_argument("--compute-type", default=None, help="默认 cuda=float16, cpu=int8")
    default_input = os.environ.get("STT_INPUT") or cfg.get("input") or None
    ap.add_argument("--input", default=default_input,
                    help=f"麦克风序号或名字片段（config.json 里现在是 {default_input or '系统默认设备'}）")
    ap.add_argument("--default-input", action="store_true", help="用系统默认麦克风，忽略上面的设定")
    ap.add_argument("--list-devices", action="store_true")
    ap.add_argument("--mode", default="hold", choices=["hold", "auto", "enter", "talk"],
                    help="hold=按住键说话（默认），talk=说完自动发送给 AI，auto=只识别不发送，enter=回车开始/结束")
    ap.add_argument("--key", default="*", help="按住说话的键，默认 * （也支持 f9 / space / a-z 等）")
    ap.add_argument("--pause-key", default="-", help="对话模式里暂停/继续的键，默认 - （主键盘和小键盘都认）")
    ap.add_argument("--target", default=cfg.get("target") or None,
                    help="对话模式：固定发到这个窗口（标题关键字，比如 ChatGPT）；默认跟着你上一个用过的窗口")
    ap.add_argument("--test-paste", action="store_true", help="只做一次粘贴测试，不录音（排错用）")
    ap.add_argument("--feed", action="append", default=None,
                    help="不录音，用现成的音频文件跑一遍完整流程（可重复给多个文件，测试用）")
    ap.add_argument("--wake-word", "--send-word", dest="wake_word",
                    default=cfg.get("wake_word") or "大肥鱼",
                    help="对话模式：唤醒词，先说它再说话（默认「大肥鱼」，可写成 大肥鱼,喂喂）")
    ap.add_argument("--cancel-word", default=cfg.get("cancel_word") or "取消",
                    help="唤醒后说这个词就取消这次（默认「取消」）")
    ap.add_argument("--wake-timeout", type=float, default=12.0, help="唤醒后等你说多久，默认 12 秒")
    ap.add_argument("--immediate", action="store_true",
                    help="对话模式：不用唤醒词，识别完立刻发送（Siri 那种唤醒逻辑的关闭版）")
    ap.add_argument("--beep", dest="beep", action="store_true", default=True, help="开始/结束提示音（默认开）")
    ap.add_argument("--no-beep", dest="beep", action="store_false")
    ap.add_argument("--ptt", action="store_true", help="等价于 --mode enter")
    ap.add_argument("--once", action="store_true", help="只识别一句就退出")
    ap.add_argument("--no-send", action="store_true", help="talk 模式：粘上去但不按回车")
    ap.add_argument("--keep-draft", action="store_true",
                    help="talk 模式：保留输入框里原有的内容，不和这次的话一起发")
    ap.add_argument("--dry-run", action="store_true", help="talk 模式：只打印，不碰任何窗口")
    ap.add_argument("--silence", type=float, default=None, help="停顿多少秒算说完（talk 默认 1.0，其它 0.8）")
    ap.add_argument("--max-seconds", type=float, default=25.0, help="单句最长录音秒数")
    ap.add_argument("--out", default=str(HERE / "transcripts.md"), help="识别日志文件")
    ap.add_argument("--file", default=None, help="识别一个现成的音频文件，而不是用麦克风")
    ap.add_argument("--no-clipboard", action="store_true")
    ap.add_argument("--no-overlay", action="store_true", help="不显示悬浮窗")
    ap.add_argument("--no-greeting", action="store_true", help="这次启动不念开机问候")
    ap.add_argument("--allow-multiple", action="store_true", help="允许同时开多个语音程序（默认不允许）")
    args = ap.parse_args()

    if not args.allow_multiple and not acquire_single_instance():
        print("⚠️ 已经有一个语音程序在跑了（两个一起跑会重复发送，所以拦下来了）。")
        print("   想再开一个请加 --allow-multiple；想关掉旧的就在托盘/任务管理器里结束它，")
        print("   或者在旧窗口按 Ctrl+C。")
        return 1

    start_heartbeat()          # 先把心跳跑起来，看门狗那边才不会误判

    # 这次是我自己起来的（不是用户点退出），把"手动退出"的记号清掉，
    # 否则万一我等会儿崩了，看门狗会以为是你让它退的、不来救我
    try:
        MANUAL_EXIT.unlink()
    except Exception:
        pass

    if args.list_devices:
        list_devices()
        return 0

    if os.environ.get("HF_ENDPOINT") is None:
        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"  # 国内下载模型更稳
        print("（已默认使用 HF 镜像下载模型）")

    if args.test_paste:  # 排错用：不录音，只试一次"切窗口 + 粘贴"
        tracker = ForegroundTracker()
        for _ in range(4):
            tracker.poll()
            time.sleep(0.2)
        hwnd, title = find_window(args.target) if args.target else (tracker.hwnd, tracker.title)
        if not hwnd:
            print("⚠️ 没找到可以粘贴的窗口。先点一下你要发送的窗口（比如聊天窗口），再运行这条命令。")
            return 1
        print(f"目标窗口：{title}  (hwnd={hwnd})")
        ok = paste_into(
            "【粘贴测试】看到这行字说明粘贴通道是通的（没有回车，不会发出去）",
            hwnd, press_enter=False,
        )
        print("切窗口:", "成功" if ok else "失败")
        return 0 if ok else 1

    if args.file:  # 音频文件模式：直接跑一遍就退出
        transcriber = Transcriber(args.model, args.device, args.compute_type, args.lang)
        t0 = time.time()
        text = transcriber.transcribe_file(args.file)
        if not text:
            print("没识别到内容。")
            return 1
        print(f"\n📝 {text}")
        print(f"   （识别耗时 {time.time() - t0:.1f}s）")
        append_log(Path(args.out), f"[文件: {Path(args.file).name}] {text}")
        if not args.no_clipboard and copy_to_clipboard(text):
            print("   ↳ 已复制到剪贴板")
        return 0

    device = None if args.default_input else resolve_device(args.input)
    try:
        stream, rate = open_stream(device)
    except SystemExit as exc:
        print(exc)
        list_devices()
        return 2
    name = sd.query_devices(device)["name"] if device is not None else sd.query_devices(sd.default.device[0])["name"]
    print(f"麦克风：{name}  @{rate}Hz")

    # 唤醒词/取消词当热词喂给识别引擎：说出来时更容易按原样写，不被听成同音字
    hotwords = " ".join(w for w in (args.wake_word or "", args.cancel_word or "") if w)
    transcriber = Transcriber(args.model, args.device, args.compute_type, args.lang,
                              hotwords=hotwords)
    print(f"识别引擎就绪：{args.model} / {transcriber.device} / {transcriber.compute_type}")
    if transcriber.device != "cuda":
        transcriber.beam = 1        # 走 CPU 时用贪心解码，快两三倍
        print("（CPU 模式：已切到贪心解码，速度优先）")
    if PROFILE == "lite":
        print(f"这台机器按低配跑：{HW['why']}")
    if transcriber.hotwords:
        print(f"热词：{transcriber.hotwords}")
    print(f"文字会写进 {args.out}，同时复制到剪贴板。Ctrl+C 退出。")

    spoken_flag = {"first": True}
    mode = "enter" if args.ptt else args.mode
    silence = args.silence if args.silence is not None else (1.0 if mode == "talk" else 0.8)
    level_name, level = wake_levels.params(cfg)
    wake_words = [w for w in (args.wake_word or "").split(",") if w.strip()]
    cancel_words = [w for w in (args.cancel_word or "").split(",") if w.strip()]
    if mode == "talk" and args.immediate:
        wake_words = []
    # 门槛由唤醒档位决定（严格/标准/宽松/极宽松，可在悬浮窗里加自定义档）。
    # 「大肥鱼」三个字说快了也就半秒出头，门槛设太高会被当噪音丢掉。
    # 有唤醒词时漏一句只是没反应、不会乱发，所以档位只影响它；免唤醒模式一律从严。
    min_voiced = 0.62 if (mode == "talk" and not wake_words) else level["min_voiced"]
    recorder = Recorder(
        stream, rate, silence, args.max_seconds,
        min_voiced=min_voiced,
        noise_mult=level["noise_mult"], confirm=level["confirm"],
        device=device,          # 睡醒之后要是音频流死了，用它把麦克风重开
    )
    print(f"唤醒档位：{level_name}（{wake_levels.describe(level)}）")
    tracker = ForegroundTracker() if mode == "talk" else None
    armed = {"on": False, "until": 0.0}  # 唤醒词是不是已经说过了
    stop_words = [w.strip() for w in str(cfg.get("stop_words") or "").split(",") if w.strip()]
    if not stop_words:
        stop_words = list(DEFAULT_STOP_WORDS)
    self_speech = {"on": False}          # 闭麦：上一句是不是它自己在说话
    # "被当成自己的声音丢掉"的最近几句。你重复第二遍就说明那是**你在说**，不是它在念。
    self_voice_miss = {"text": "", "at": 0.0}
    dictation = {"on": False}            # 听写模式：打进光标，不发到聊天窗口
    music = {"on": bool(cfg.get("wave_spectrum"))}   # 音浪模式
    last_sent = {"text": "", "at": 0.0}  # 上下文指代："跟刚才一样"
    hotkey = {"prev": False}             # Ctrl+Alt+R 朗读选中
    sit = {"next": time.time() + 3600}   # 久坐提醒
    hourly = {"last": datetime.now().strftime("%Y-%m-%d %H")}
    fatigue = {"speeds": [], "last": 0.0}
    ticker = {"next": 0.0, "meeting": False}
    voiceprint = {"enroll": False}       # 声纹：注册完只提示，不拦截
    editing = {"on": False}              # 悬浮窗里正在改设置：这期间不抢键盘
    pet_proc = {"p": None}               # 桌宠进程
    not_heard = {"at": 0.0}              # "没听清"提示的节流
    hint = (f"说「{wake_words[0]}」唤醒" if wake_words else "直接说话就行") if mode == "talk" else ""
    followup = float(cfg.get("followup_seconds") or 0)

    def arm_followup() -> None:
        """连续对话：刚说完这一句，接下来几秒内不用再喊唤醒词。"""
        if followup <= 0 or not wake_words:
            return
        armed["on"] = True
        armed["until"] = time.time() + followup
        print(f"   ↳ 接着说要问的就行（{followup:g} 秒内免唤醒）", flush=True)
        status.set("listening", text="", hint=f"接着说就行（{followup:g} 秒内免唤醒）")

    # ------------------------------------------------------------ 番茄钟
    NOTES_FILE = HERE / "notes.md"
    LEDGER_FILE = HERE / "ledger.json"
    focus = {"end": 0.0, "minutes": 0, "total": 0.0, "shown": 0.0}
    game = {"kind": "", "data": {}, "until": 0.0}

    def focus_active() -> bool:
        return focus["end"] > time.time()

    def focus_left() -> float:
        return max(0.0, focus["end"] - time.time())

    def focus_start(minutes: int) -> None:
        focus.update(minutes=minutes, total=float(minutes) * 60,
                     end=time.time() + minutes * 60, shown=0.0)
        speak(f"好，专注 {minutes} 分钟，开始")
        print(f"   ↳ 🍅 番茄钟 {minutes} 分钟", flush=True)
        award("focus")
        focus_tick(force=True)
        arm_followup()

    def focus_stop(finished: bool = False) -> None:
        if not focus["end"]:
            return
        focus["end"] = 0.0
        status.focus = 0.0
        if finished:
            speak("时间到，起来动一动吧")
            beep(980, 120, args.beep)
            time.sleep(0.12)
            beep(1320, 160, args.beep)
            print("   ↳ 🍅 番茄钟到点", flush=True)
        else:
            speak("好，专注结束")
            print("   ↳ 🍅 番茄钟提前结束", flush=True)
        status.set("idle")

    def focus_tick(force: bool = False) -> None:
        """每秒把倒计时写给悬浮窗（它会把声音条画成一根在缩短的进度条）。"""
        if not focus["end"]:
            return
        left = focus_left()
        if left <= 0:
            focus_stop(finished=True)
            return
        now = time.time()
        if not force and now - focus["shown"] < 1.0:
            return
        focus["shown"] = now
        # 只改 focus 这一个字段：状态和实时字幕都留给主循环，互不打扰
        status.patch(focus=left)

    # ------------------------------------------------------------ 便签 / 记账
    def read_ledger() -> list[dict]:
        try:
            data = json.loads(LEDGER_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def add_note(body: str) -> None:
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        try:
            with NOTES_FILE.open("a", encoding="utf-8") as fh:
                fh.write(f"- {stamp}　{body}\n")
        except Exception:
            pass
        speak(f"记下了：{body}")
        print(f"   ↳ 📝 便签：{body}", flush=True)
        status.set("sent", text=f"📝 {body}")
        award("note")

    def add_ledger(name: str, amount: float) -> None:
        rows = read_ledger()
        rows.append({"ts": time.time(), "date": datetime.now().strftime("%Y-%m-%d"),
                     "name": name, "amount": round(amount, 2)})
        try:
            LEDGER_FILE.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        today = sum(r["amount"] for r in rows
                    if r.get("date") == datetime.now().strftime("%Y-%m-%d"))
        speak(f"记下了，{name} {amount:g} 块，今天一共 {today:g} 块")
        print(f"   ↳ 💰 {name} {amount:g}，今日合计 {today:g}", flush=True)
        status.set("sent", text=f"💰 {name} {amount:g}")
        award("ledger")

    def say_ledger() -> None:
        rows = read_ledger()
        today = datetime.now().strftime("%Y-%m-%d")
        month = today[:7]
        day_sum = sum(r["amount"] for r in rows if r.get("date") == today)
        month_sum = sum(r["amount"] for r in rows if str(r.get("date", "")).startswith(month))
        tail = ("、".join(f"{r['name']} {r['amount']:g}" for r in rows
                          if r.get("date") == today)[:60] or "还没记过")
        speak(f"今天花了 {day_sum:g} 块，这个月一共 {month_sum:g} 块。今天有：{tail}")
        status.set("sent", text=f"💰 今日 {day_sum:g} / 本月 {month_sum:g}")

    def say_notes() -> None:
        try:
            lines = [ln.strip() for ln in NOTES_FILE.read_text(encoding="utf-8").splitlines()
                     if ln.strip().startswith("-")]
        except Exception:
            lines = []
        if not lines:
            speak("还没有记过东西")
            return
        recent = lines[-5:]
        speak(f"最近记了 {len(lines)} 条。最后几条是：" +
              "；".join(ln.lstrip("- ").split("　")[-1] for ln in recent))
        status.set("sent", text=f"📝 {len(lines)} 条便签")

    # ------------------------------------------------------------ 小游戏
    IDIOMS = (
        "一心一意", "意气风发", "发扬光大", "大显身手", "手到擒来", "来日方长", "长驱直入",
        "入木三分", "分秒必争", "争先恐后", "后来居上", "上下一心", "心花怒放", "放虎归山",
        "山明水秀", "秀色可餐", "餐风露宿", "宿雨餐风", "风平浪静", "静观其变", "变本加厉",
        "厉兵秣马", "马到成功", "功成名就", "就地取材", "材大难用", "用武之地", "地久天长",
        "长话短说", "说一不二", "二话不说", "说三道四", "四面八方", "方兴未艾", "艾发衰容",
        "容光焕发", "发号施令", "令行禁止", "止戈为武", "武艺超群", "群策群力", "力争上游",
        "游刃有余", "余音绕梁", "梁上君子", "子虚乌有", "有备无患", "患得患失", "失之东隅",
        "海阔天空", "空前绝后", "后继有人", "人山人海", "海纳百川", "川流不息", "息息相关",
        "相亲相爱", "爱不释手", "手忙脚乱", "乱七八糟", "糟糠之妻", "妻离子散", "散兵游勇",
        "勇往直前", "前程万里", "里应外合", "合情合理", "理所当然", "然荻读书", "书声琅琅",
        "明日黄花", "花好月圆", "圆木警枕", "枕戈待旦", "旦夕之间", "间不容发",
    )

    def game_start(kind: str, extra: str = "") -> None:
        if kind == "stop":
            game.update(kind="", data={}, until=0.0)
            speak("好，不玩了")
            status.set("idle")
            return
        if kind == "guess":
            game.update(kind="guess", data={"answer": random.randint(1, 100), "tries": 0,
                                            "low": 1, "high": 100}, until=time.time() + 600)
            speak("我想好了一个 1 到 100 之间的数，你猜")
            status.set("listening", text="猜数字 1-100")
        elif kind == "pick":
            if not extra:
                speak("把选项说给我，比如：帮我决定 吃面还是吃饭")
                game.update(kind="pick", data={}, until=time.time() + 60)
                return
            do_pick(extra)
        elif kind == "idiom":
            first = random.choice(IDIOMS)
            game.update(kind="idiom", data={"last": first[-1], "rounds": 0},
                        until=time.time() + 600)
            speak(f"我先来：{first}。你说一个以「{first[-1]}」开头的")
            status.set("listening", text=f"成语接龙：{first}")
        print(f"   ↳ 🎮 开始游戏：{kind}", flush=True)
        award("game")

    def do_pick(extra: str) -> None:
        parts = [p for p in re.split(r"还是|或者|,|，|、|/|\s+", extra) if p.strip()]
        parts = [p.strip("。，,.！!？? ") for p in parts if p.strip("。，,.！!？? ")]
        if len(parts) < 2:
            speak("至少给我两个选项吧")
            return
        chosen = random.choice(parts)
        speak(f"我选：{chosen}")
        print(f"   ↳ 🎲 选项 {parts} → {chosen}", flush=True)
        status.set("sent", text=f"🎲 我选 {chosen}")
        beep(880, 60, args.beep)

    def game_feed(text: str) -> bool:
        """把这句话喂给正在进行的游戏；吃掉就返回 True。"""
        if not game["kind"] or time.time() > game["until"]:
            game.update(kind="", data={})
            return False
        if game["kind"] == "pick":
            do_pick(text)
            game.update(kind="")
            return True
        if game["kind"] == "guess":
            data = game["data"]
            m = re.search(r"(\d+)", text)
            if not m:
                speak("说个数字给我")
                return True
            n = int(m.group(1))
            data["tries"] += 1
            if n == data["answer"]:
                speak(f"猜对了，就是 {n}，一共猜了 {data['tries']} 次")
                status.set("sent", text=f"🎉 猜对了：{n}")
                beep(1320, 120, args.beep)
                game.update(kind="")
            elif n < data["answer"]:
                speak("小了")
                status.set("listening", text=f"{n} → 小了")
            else:
                speak("大了")
                status.set("listening", text=f"{n} → 大了")
            return True
        if game["kind"] == "idiom":
            data = game["data"]
            word = re.sub(r"[^\u4e00-\u9fff]", "", text)
            if len(word) < 2:
                speak("说个成语给我")
                return True
            if word[0] != data["last"]:
                speak(f"要从「{data['last']}」开头哦")
                return True
            data["rounds"] += 1
            nxt = [w for w in IDIOMS if w.startswith(word[-1]) and w != word]
            if not nxt:
                speak(f"「{word}」好，我接不上来了，你赢了")
                status.set("sent", text=f"🏆 你赢了（{word}）")
                game.update(kind="")
                return True
            back = random.choice(nxt)
            data["last"] = back[-1]
            speak(back)
            status.set("listening", text=f"我：{back}")
            return True
        return False

    # ------------------------------------------------------------ 早间播报
    def weather_line() -> str:
        """顺手拿一下天气（wttr.in，不用 key）；拿不到就不提天气。

        自动定位有时候会把人判到国外（走代理就会），所以设置里可以钉死城市。
        """
        try:
            import urllib.parse
            import urllib.request

            city = str(cfg.get("weather_city") or "").strip()
            where = urllib.parse.quote(city) if city else ""
            url = f"https://wttr.in/{where}?format=%l:+%C+%t+%f&lang=zh"
            req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
            with urllib.request.urlopen(req, timeout=6) as resp:
                got = resp.read().decode("utf-8", "replace").strip()
            return got if got and len(got) < 60 else ""
        except Exception:
            return ""

    def brief_now() -> None:
        now = datetime.now()
        week = "一二三四五六日"[now.weekday()]
        head = f"现在是 {now.hour} 点 {now.minute:02d} 分，星期{week}。"
        items = []
        try:
            import sched as sched_mod

            entries = cfg.get("schedules") or []
            for item in sched_mod.due_today(entries, now) if hasattr(sched_mod, "due_today") else entries:
                if item.get("time"):
                    items.append(f"{item['time']} {item.get('text', '')}".strip())
        except Exception:
            items = []
        plan = ("今天的日程有：" + "；".join(items[:5]) + "。") if items else "今天没有安排日程。"
        rows = read_ledger()
        today = now.strftime("%Y-%m-%d")
        spent = sum(r["amount"] for r in rows if r.get("date") == today)
        money = f"今天已经花了 {spent:g} 块。" if spent else ""
        speak(head + plan + money + weather_line())
        print(f"   ↳ 🌅 早间播报：{head}{plan}{money}", flush=True)
        status.set("sent", text="🌅 播报完成")

    # ------------------------------------------------------------ 变身（换主题）
    THEMES = [
        {"name": "默认", "overlay_accent": "#3ddc84", "overlay_button": "#2f7f5a",
         "overlay_talk_color": "#4aa3ff", "overlay_wave_style": "siri"},
        {"name": "深海", "overlay_accent": "#38bdf8", "overlay_button": "#1d6f9c",
         "overlay_talk_color": "#a78bfa", "overlay_wave_style": "siri"},
        {"name": "蜜桃", "overlay_accent": "#fb7185", "overlay_button": "#9f4257",
         "overlay_talk_color": "#fbbf24", "overlay_wave_style": "siri"},
        {"name": "柠檬", "overlay_accent": "#facc15", "overlay_button": "#8a6d1a",
         "overlay_talk_color": "#22d3ee", "overlay_wave_style": "bars"},
    ]

    def transform() -> None:
        fresh = load_config()
        names = [t["name"] for t in THEMES]
        cur = str(fresh.get("theme") or names[0])
        nxt = THEMES[(names.index(cur) + 1) % len(THEMES)] if cur in names else THEMES[0]
        fresh.update({k: v for k, v in nxt.items() if k != "name"})
        fresh["theme"] = nxt["name"]
        try:
            CONFIG_FILE.write_text(json.dumps(fresh, ensure_ascii=False, indent=2),
                                   encoding="utf-8")
        except Exception:
            pass
        speak(f"变身完成，现在是{nxt['name']}")
        print(f"   ↳ ✨ 主题 → {nxt['name']}", flush=True)
        status.set("sent", text=f"✨ {nxt['name']}")
        beep(1180, 70, args.beep)

    # ------------------------------------------------------------ 成就
    def award(kind: str) -> None:
        for name in bump_achv(kind):
            speak(f"解锁成就：{name}")
            status.set("sent", text=f"🏆 {name}")
            print(f"   ↳ 🏆 解锁成就：{name}", flush=True)
            beep(1320, 90, args.beep)

    # ------------------------------------------------------------ 听写模式
    CRASH_MARK = HERE / "last-crash.txt"

    def self_check(speak_it: bool = True) -> list[str]:
        """启动自检：麦克风 / 模型 / 目标窗口 / 剪贴板 / 悬浮窗。有问题就报出来。"""
        problems: list[str] = []
        try:
            dev = sd.query_devices(device)
            if int(dev.get("max_input_channels") or 0) < 1:
                problems.append("那个麦克风现在没有输入通道")
        except Exception as exc:  # noqa: BLE001
            problems.append(f"找不到麦克风（{type(exc).__name__}）")
        if getattr(transcriber, "model", None) is None:
            problems.append("识别模型没加载上")
        if args.target:
            hwnd_chk, _t = find_window(args.target)
            if not hwnd_chk:
                problems.append(f"没找到「{args.target}」窗口，发出去的东西会先放剪贴板")
        keep = clipboard_text()
        if not copy_to_clipboard("语音助手自检"):
            problems.append("剪贴板写不进去")
        elif keep:
            copy_to_clipboard(keep)                 # 把人家原来的剪贴板还回去
        if overlay is None and not args.no_overlay:
            problems.append("悬浮窗没起来")
        for p in problems:
            syslog("检", p)
        if not problems:
            syslog("检", "自检通过：麦克风/模型/窗口/剪贴板都正常")
        if speak_it and problems:
            speak("自检发现：" + "；".join(problems))
        return problems

    def do_export() -> None:
        out = export_data()
        if out:
            speak(f"数据打包好了，藏在导出文件夹里：{out.name}")
            syslog("备", f"导出数据 → {out.name}")
        else:
            speak("导出失败了")

    def do_import() -> None:
        n, msg = import_data()
        speak(("数据导入完成，" + msg) if n else msg)
        syslog("备", f"导入数据：{msg}")

    def do_diagnose() -> None:
        out = diag_pack()
        if out:
            speak(f"诊断包好了，藏在导出文件夹里：{out.name}")
            syslog("备", f"打包诊断 → {out.name}")
        else:
            speak("诊断包没打出来")

    def do_update() -> None:
        got = newer_package()
        if not got:
            speak("现在就是最新版本")
            return
        pkg, ver = got
        PRIVATE["update_pkg"] = str(pkg)
        speak(f"发现新版本 {ver}，说「开始更新」我就套用")
        syslog("更", f"发现新版本 {ver}（{pkg.name}）")

    def apply_update_now() -> None:
        pkg = PRIVATE.get("update_pkg")
        if not pkg or not Path(pkg).is_dir():
            speak("先让我检查一下更新")
            return
        n = apply_update(Path(pkg))
        speak(f"更新完成，套用了 {n} 个文件，重启一下就生效")
        syslog("更", f"套用更新：{n} 个文件")

    def undo_last() -> None:
        """撤销：先试试 Ctrl+Z 撤回发送，再把内容放回输入框让你改。"""
        if not last_sent["text"] or time.time() - last_sent["at"] > 180:
            speak("没有可以撤回的内容")
            return
        hwnd_u = (find_window(args.target)[0] if args.target
                  else (tracker.hwnd if tracker else 0))
        if hwnd_u:
            focus_window(hwnd_u)
            time.sleep(0.15)
            _combo(0x5A, _VK_CTRL)              # Ctrl+Z：试着撤销刚刚的发送
            time.sleep(0.25)
        copy_to_clipboard(last_sent["text"])
        paste_clipboard(hwnd_u, press_enter=False, clear_first=True)
        speak("试着撤回了，也把它放回输入框了，你改完自己发")
        syslog("撤", f"撤回上一条：{last_sent['text'][:40]}")
        print("   ↳ ↩️ 已撤回并放回输入框", flush=True)

    def type_into_focused(added: str) -> None:
        """听写：把文字打进当前光标位置，不发到聊天窗口。"""
        hwnd = (tracker.hwnd if tracker else 0) or 0
        if not hwnd:
            copy_to_clipboard(added)
            speak("没找到光标在哪个窗口，先放剪贴板了")
            status.set("sent", text=f"📝 {added}")
            return
        ok = paste_into(added, hwnd, press_enter=False, clear_first=False)
        print(f"   ↳ ⌨️ 听写：{added}（{'已输入' if ok else '没输进去'}）", flush=True)
        status.set("sent" if ok else "offline", text=f"⌨️ {added}")

    # ------------------------------------------------------------ 日记
    TUTORIAL = [
        ("唤醒", "先说唤醒词，听到两声提示音，再讲你要问的。也可以一口气说完："
                 "「{wake}，帮我查一下明天的天气」。没喊唤醒词的话，你说的话会被忽略，不会乱发。"),
        ("停下就发", "说完停一下，它自己就识别、自己发出去，不用按任何键。"
                     "说快了没听清，它会说一句「没听清，再说一遍」。"),
        ("接着说", "喊一次唤醒词之后，八秒内接着说就不用再喊了。想改这个时间：设置 → 智能 → 连续对话。"),
        ("暂停和继续", "按键盘上的减号「-」暂停；或者点悬浮窗右边那个开关。"
                       "暂停时它照样在录音，只是不发出去，随时能恢复。"),
        ("悬浮窗", "平时只有名字、状态、开关和底部一条声音波浪。有声音时波浪铺满底部、上下抖；"
                   "没声音就缩成中间一个小圆球。我说话的时候它会换成蓝色，说完慢慢变回来。"),
        ("设置在这里", "点悬浮窗右下角的小箭头，它会平滑长大，下半部分就是设置，不用另开窗口。"
                       "一开始是「基本」页，上面有名字、唤醒词、问候语、你的称呼。"),
        ("六个标签页", "基本管称呼和唤醒；声音管音量、语速、八种音色；外观管颜色、背景、特效；"
                       "布局能把每个元素拖到你想要的位置；智能放性能和各种开关；日程是日历和时间表。"),
        ("喊不醒怎么办", "设置 → 基本 → 唤醒档位，有严格、标准、宽松、极宽松四档，越往右越灵敏。"
                         "还能点「＋自定」自己加一档。改完唤醒词它会自动跑一次自检，把结果念给你听。"),
        ("声音条特效", "外观页里有五个开关：视觉暂留会拖一条慢慢淡掉的残影，呼吸光晕、星尘、倒影、流光。"
                       "节能模式下它们会自动关掉。"),
        ("番茄钟", "说「专注二十五分钟」或「番茄钟」，声音条会变成一根越来越短的倒计时条，"
                   "到点它念你去休息。问「还有多久」它告诉你，说「结束专注」就停。"),
        ("便签和记账", "说「记一下 明天买牛奶」存便签，说「念一下笔记」它念给你听；"
                       "说「记一笔 买菜三十」记账，问「今天花了多少」它报今天和这个月的合计。"),
        ("日程表", "设置 → 日程，日历上点某一天，那天会放大成时间表；"
                   "把右边抽屉里的模块拖进去就能定时：提醒模块只念给你听，指令模块会替你发出去。"),
        ("让它闭嘴", "它念到一半你喊「停」「别念了」它立刻停；也可以直接喊唤醒词抢话，"
                     "它会先闭嘴再听你说。它朗读的时候麦克风是闭着的，不会把自己的声音当指令。"),
        ("隐私", "说到密码、身份证、银行卡这类词，那一行不会被记下来；"
                 "说「别记这段」它会静默五分钟；说「清空所有记录」再「确定清空」能把便签、记账、记忆和日志全清掉。"),
        ("让它当打字员", "说「开始听写」，之后你说的话会直接打进光标位置，不发到聊天窗口；说「停止听写」结束。"
                         "选中一段文字按 Ctrl+Alt+R，它会念给你听。"),
        ("出问题了怎么办", "说「自检」查麦克风、模型、窗口、剪贴板；说「打包诊断」会把日志打成一个包，"
                           "藏在程序目录那个隐藏的「导出」文件夹里，设置里点「打开文件夹」就能看到；"
                           "右下角托盘图标里能打开设置、暂停、重启、退出。主程序要是挂了，看门狗会自动把它拉起来。"),
        ("教程结束", "这些记不住也没关系，随时说「教程」我再讲一遍。"
                     "想直接跳到哪一步，说「讲第几课」就行。"),
    ]
    tutorial = {"on": False, "step": 0}

    def tutorial_say(index: int) -> None:
        if not (0 <= index < len(TUTORIAL)):
            tutorial["on"] = False
            speak("教程讲完了")
            status.set("idle")
            return
        tutorial.update(on=True, step=index)
        title, body = TUTORIAL[index]
        text = body.replace("{wake}", wake_words[0] if wake_words else "大肥鱼")
        speak(f"第 {index + 1} 课，{title}。{text}")
        print(f"   ↳ 📘 教程 {index + 1}/{len(TUTORIAL)}：{title}", flush=True)
        syslog("教", f"第 {index + 1} 课：{title}")
        status.set("sent", text=f"📘 {index + 1}/{len(TUTORIAL)} {title}")

    def say_diary() -> str:
        day = datetime.now().strftime("%Y-%m-%d")
        text = diary_summary(day)
        speak(text)
        try:
            with DIARY_FILE.open("a", encoding="utf-8") as fh:
                fh.write(f"## {day}\n\n{text}\n\n")
        except Exception:
            pass
        print(f"   ↳ 📔 日记：{text[:50]}", flush=True)
        status.set("sent", text="📔 日记已生成")
        return text

    def maybe_night_diary() -> None:
        """到点自动念一遍今天的日记（每天只念一次）。"""
        if not cfg.get("diary_enabled", True):
            return
        hour = int(cfg.get("diary_hour") or 22)
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        data = read_achv()
        if now.hour < hour or data.get("diary_day") == today:
            return
        data["diary_day"] = today
        try:
            ACHV_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        print(f"   ↳ 📔 晚间日记时间", flush=True)
        say_diary()

    # ------------------------------------------------------------ 热键 / 定时提醒 / 开会闭嘴
    def say_selected() -> None:
        text = selected_text()
        if not text:
            speak("没选中文字哦")
            return
        speak(text)
        syslog("读", f"朗读选中 {len(text)} 字")
        print(f"   ↳ 🔊 朗读选中：{text[:30]}", flush=True)
        status.set("sent", text=f"🔊 朗读选中 {len(text)} 字")

    def check_hotkey() -> None:
        """Ctrl+Alt+R：把选中的字念出来。"""
        if not cfg.get("read_hotkey", True):
            return
        try:
            u = ctypes.windll.user32
            down = bool(u.GetAsyncKeyState(_VK_CTRL) & 0x8000) and \
                bool(u.GetAsyncKeyState(_VK_ALT) & 0x8000) and \
                bool(u.GetAsyncKeyState(0x52) & 0x8000)
        except Exception:
            return
        if down and not hotkey["prev"]:
            say_selected()
        hotkey["prev"] = down

    def _set_cfg(key: str, value) -> None:
        """改一项配置并立刻生效（同时写回文件）。"""
        fresh = load_config()
        fresh[key] = value
        try:
            CONFIG_FILE.write_text(json.dumps(fresh, ensure_ascii=False, indent=2),
                                   encoding="utf-8")
        except Exception:
            pass
        cfg[key] = value
        syslog("设", f"{key} = {value}")

    def restart_program() -> None:
        """重启自己：先派一个"过三秒再把我拉起来"的小进程，然后干净退出。"""
        runner = Path(sys.executable).with_name("pythonw.exe")
        if not runner.exists():
            runner = Path(sys.executable)
        flags = 0x08000000 if os.name == "nt" else 0
        code = (
            "import subprocess, time; time.sleep(3); "
            f"subprocess.Popen([r'{runner}', r'{HERE / 'stt.py'}', '--mode', 'talk'], "
            f"cwd=r'{HERE}', creationflags={flags})"
        )
        try:
            subprocess.Popen([str(runner), "-c", code], cwd=str(HERE), creationflags=flags)
            print("\n   ↳ 🔄 三秒后自动重启", flush=True)
        except Exception as exc:  # noqa: BLE001
            print(f"   （重启进程没起来：{exc}）", flush=True)
        status.set("offline", hint="正在重启…")
        raise SystemExit(0)

    def train_wake_voice() -> None:
        """念三遍唤醒词，把这三遍的声纹存下来——以后它就更认你的口音。"""
        word = wake_words[0] if wake_words else "大肥鱼"
        speak(f"好，念三遍「{word}」，每遍我都会说一句提示")
        feats: list[list[float]] = []
        for i in range(3):
            speak(f"第 {i + 1} 遍")
            time.sleep(0.4)
            audio = safe_record(safe_calibrate(), None, tick=checked_pause)
            if audio is None or audio.size < rate // 4:
                speak("这遍没听清，训练先停下，等下再来")
                return
            feat = voice_features(audio, rate)
            if feat:
                feats.append(feat)
        if len(feats) < 2:
            speak("没录到足够的声音，重试一次吧")
            return
        sims = []
        for i in range(len(feats)):
            for j in range(i + 1, len(feats)):
                sims.append(float(np.dot(np.array(feats[i]), np.array(feats[j]))))
        avg = np.mean(np.array(feats), axis=0)
        avg = avg / (float(np.linalg.norm(avg)) or 1.0)
        try:
            data = json.loads(VP_FILE.read_text(encoding="utf-8")) if VP_FILE.exists() else {}
        except Exception:
            data = {}
        data["wake_feat"] = [float(v) for v in avg]
        data["wake_ts"] = time.time()
        try:
            VP_FILE.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        low = min(sims) if sims else 0.0
        judge = "挺稳的" if low > 0.6 else "三次差别有点大"
        speak(f"记录好了，三次相似度最低 {low:.2f}，{judge}")
        syslog("声", f"唤醒词训练完成，最低相似度 {low:.2f}")
        status.set("sent", text=f"🎙 唤醒词已训练（{low:.2f}）")

    def wake_voice_ok(audio: np.ndarray) -> bool:
        """开了"只认我的声音"时，用训练数据判断这次唤醒像不像本人。"""
        if not cfg.get("voiceprint_gate", False):
            return True
        try:
            ref = json.loads(VP_FILE.read_text(encoding="utf-8")).get("wake_feat")
        except Exception:
            return True
        if not ref:
            return True
        feat = voice_features(audio, rate)
        if not feat:
            return True
        score = float(np.dot(np.array(ref), np.array(feat)))
        syslog("声", f"唤醒声纹 {score:.2f}")
        # 记下来：发出去之前那道"背景音"闸要用它 —— 唤醒声纹很像本人，就不该再当背景音丢掉
        voiceprint["wake_score"] = score
        if score < 0.45:
            print(f"   ↳ 🎙 这次唤醒不像本人（{score:.2f}），忽略", flush=True)
            return False
        return True

    def send_it(text: str, hwnd: int) -> bool:
        """按设置里的"发送方式"把文字送出去。"""
        how = str(cfg.get("send_mode") or "paste_enter")
        if how == "type":                     # 当打字机，不碰剪贴板
            return type_text_hwnd(text, hwnd, press_enter=not args.no_send)
        if how == "paste":                    # 只粘贴不回车
            copy_to_clipboard(text)
            return paste_clipboard(hwnd, press_enter=False, clear_first=not args.keep_draft)
        return paste_into(text, hwnd, press_enter=not args.no_send,
                          clear_first=not args.keep_draft)

    def confirm_ok(text: str) -> bool:
        """确认再发模式：先念一遍问"发吗"，听到"发/好/确认"才真的发。"""
        if not cfg.get("confirm_send", False):
            return True
        speak(f"要发的是：{text[:40]}。发吗？")
        print("   ↳ ❓ 等你确认（说「发」或「取消」）", flush=True)
        status.set("listening", text=f"❓ {text[:20]}… 发吗？")
        ans = safe_record(safe_calibrate(), None, tick=checked_pause,
                          on_level=lambda v, _b=None: status.level(v, "hearing"))
        if ans is None or ans.size < rate // 4:
            speak("没听清，先不发了")
            return False
        got = transcriber.transcribe(ans)
        print(f"   ↳ 你的回答：{got}", flush=True)
        # 先看"不要"再说"要" —— 否则"暂时不发"里有个"发"就被当成同意了。
        # 而且这几句都是整句判定，不靠子串猜。
        plain_ans = _CANCEL_PUNCT.sub("", got or "")
        no_words = ("取消", "不", "别", "算了", "等等", "等一下", "先不", "不用", "不建议")
        yes_words = ("发", "发送", "发吧", "好", "好嘞", "行", "可以", "确认", "对", "是的", "嗯")
        if any(w in plain_ans for w in no_words):
            speak("好，不发了")
            syslog("撤", f"确认时取消：{text[:30]}")
            return False
        if any(w in plain_ans for w in yes_words):
            return True
        speak("没听清，先不发了")
        syslog("撤", f"确认时没听清：{text[:30]}")
        return False

    def keep_overlay_alive() -> None:
        """悬浮窗要是自己退出了（你点了"只关浮窗"以外的原因），30 秒后把它拉回来。"""
        nonlocal overlay
        if overlay is None or args.no_overlay or args.feed or args.test_paste:
            return
        now_t = time.time()
        if now_t < ticker.get("overlay_check", 0.0):
            return
        ticker["overlay_check"] = now_t + 30
        if overlay.poll() is None:
            return
        print("\n🪟 悬浮窗不在了，重新拉一个", flush=True)
        syslog("检", "悬浮窗退出过，已重新启动")
        overlay = start_overlay()

    def maybe_reminders() -> None:
        """每秒看一眼：开会闭嘴 / 整点报时 / 久坐提醒 / 疲劳提醒。"""
        now_t = time.time()
        if now_t < ticker["next"]:
            return
        ticker["next"] = now_t + 1.0
        # 1) 开会自动闭嘴：检测到会议软件在前台就只出字幕
        try:
            want = in_meeting() if cfg.get("meeting_mute", True) else False
        except Exception:
            want = False
        if want != ticker["meeting"]:
            ticker["meeting"] = want
            _MUTE_SPEAK["on"] = want
            print(f"\n   ↳ {'🤫 检测到会议，只出字幕不出声' if want else '🔊 会议结束，恢复出声'}",
                  flush=True)
            syslog("会", "进入会议模式" if want else "退出会议模式")
            status.set("sent", text=("🤫 开会中，只出字幕" if want else "🔊 恢复出声"))
        # 2) 整点报时
        now = datetime.now()
        if cfg.get("hourly_chime", False):
            stamp = now.strftime("%Y-%m-%d %H")
            if stamp != hourly["last"] and now.minute == 0:
                hourly["last"] = stamp
                speak(f"现在是 {now.hour} 点")
        # 3) 久坐提醒：在用电脑（最近一分钟还在动键鼠）且连着用够久了
        if cfg.get("sit_reminder", True) and now_t >= sit["next"]:
            if last_input_age() < 60:
                sit["next"] = now_t + max(10, int(cfg.get("sit_minutes") or 60)) * 60
                speak("坐挺久了，起来动一动吧")
                syslog("提", "久坐提醒")
                print("   ↳ 🪑 久坐提醒", flush=True)
                status.set("sent", text="🪑 起来动一动")
            else:
                sit["next"] = now_t + 120
        # 4) 疲劳提醒：最近几句比平时又慢又轻，就劝你歇会儿
        if cfg.get("fatigue_reminder", True) and len(fatigue["speeds"]) >= 8:
            recent = fatigue["speeds"][-3:]
            base = sorted(fatigue["speeds"][:-3])
            mid = base[len(base) // 2]
            if mid > 0 and sum(recent) / len(recent) < mid * 0.7 and \
                    now_t - fatigue["last"] > 1800:
                fatigue["last"] = now_t
                speak("听你说话好像有点累了，歇一会儿吧")
                syslog("提", "疲劳提醒")
                print("   ↳ 😪 疲劳提醒", flush=True)
                status.set("sent", text="😪 歇一会儿吧")

    status = Status(hint=hint)
    status.set("starting")  # 先写状态再叫悬浮窗，否则它读到上一轮的旧文件会以为程序已经退出
    overlay = None if (args.no_overlay or args.feed or args.test_paste) else start_overlay()
    if cfg.get("pet_enabled", True) and not (args.no_overlay or args.feed or args.test_paste):
        pet_proc["p"] = start_pet()
    # 上次如果是崩掉的，这次先报一句；再跑一次启动自检（有问题就说）
    if CRASH_MARK.exists():
        try:
            CRASH_MARK.unlink()
        except Exception:
            pass
        syslog("检", "上次异常退出，本次已恢复")
        speak("上次我出了点问题，现在恢复了")
    if not (args.no_overlay or args.feed or args.test_paste):
        threading.Thread(target=lambda: (time.sleep(7), self_check(True)),
                         daemon=True).start()
        start_watchdog()
        if cfg.get("tray_enabled", True):
            start_tray()

    # ---- 📱 手机入口：手机浏览器连到这台电脑，发命令 / 看对话 ----
    phone_box: list[str] = []
    phone_lock = threading.Lock()
    phone_server = None

    def phone_push(text: str) -> None:
        with phone_lock:
            phone_box.append(text)

    # 语音那句和手机那句不能同时办（会撞窗口/剪贴板），用一把锁排队
    handle_lock = threading.RLock()

    def drain_phone_commands() -> None:
        """主循环里顺手就把手机发来的命令办了（走的是同一条 handle 管线）。"""
        if paste_phone_images():     # 先把手机发来的图片贴进对话窗口
            return
        while True:
            with phone_lock:
                if not phone_box:
                    return
                text = phone_box.pop(0)
            print(f"\n📱 手机发来：{text}", flush=True)
            syslog("听", f"（手机）{text}")
            try:
                with handle_lock:
                    handle(None, pre_text=text, from_phone=True)
            except Exception as exc:  # noqa: BLE001
                print(f"   （手机这条没办成：{exc}）", flush=True)

    def phone_worker() -> None:
        """手机命令的取件线程。

        为什么不用主循环的 tick：录音那个 tick 只在"正在听/说话"时才转，
        程序安安静静待着的时候手机发来的命令就没人取（实测卡在这儿）。
        """
        while True:
            time.sleep(0.4)
            try:
                with handle_lock:
                    drain_phone_commands()
            except Exception:
                pass

    def phone_state() -> dict:
        detail = str((getattr(status, "_last", {}) or {}).get("text") or status.hint or "")
        busy = False
        try:
            busy = bool(REPLY_READER.busy())      # 真的在等/念这条回答
        except Exception:
            busy = False
        return {"state_text": (f"{status.state} · {detail}" if detail else str(status.state)),
                "busy": busy}

    def update_source() -> str:
        """更新以哪个网址为准：优先设置里填的公网下载页，再退回本机这一份。"""
        try:
            custom = str(cfg.get("update_url") or "").strip()
            if custom:
                return custom.rstrip("/")
            import site_publish

            return site_publish.public_url()
        except Exception:
            return ""

    def phone_info() -> dict:
        """手机要的"这台电脑上的助手叫什么、什么版本"。"""
        return {"name": str(cfg.get("name") or "语音助手"),
                "pc": phone_link.pc_version(),
                "phone": phone_link.phone_app_version(),
                # 署名 / 版权：手机设置里那一栏用（跟电脑端「关于」同一个来源，改一处两边都变）
                "author": version.AUTHOR,
                "contact": version.CONTACT,
                "copyright": version.COPYRIGHT,
                "free": version.FREE_LINE,
                "notice": version.NOTICE,
                # 公网下载页网址（设置里填过才有）：手机那边用它当更新来源
                "update_url": update_source(),
                # 外网访问（Tailscale）：手机不在同一个 Wi-Fi 时填这条
                "fixed_url": remote_access.fixed_url(),
                "fixed_url_alt": remote_access.alt_url(),
                "remote_hint": remote_access.hint(),
                "remote_tip": remote_access.phone_hint(),
                # 公网地址（Funnel）开着的话，手机连 Tailscale 都不用装
                "funnel_on": bool(remote_access.detail().get("funnel_on")),
                "public_url": remote_access.public_url(),
                # 手机上「装 Tailscale」那个按钮要的官方 APK（挂在 GitHub Release 上）
                "tailscale_apk": remote_access.apk_url(),
                "remote_account": remote_access.detail().get("account", "")}

    # ---- 手机上那个「日程」页：读的就是 config.json 里的 schedules，跟电脑那边同一份 ----
    def phone_schedule_list() -> list:
        """手机要的日程列表（带上"每周几/每月几号"这种给人看的说法）。"""
        try:
            import sched as sched_mod
        except Exception:                                    # noqa: BLE001
            sched_mod = None
        out = []
        try:
            data = load_config()
            for i, raw in enumerate(data.get("schedules") or []):
                if not isinstance(raw, dict):
                    continue
                item = sched_mod.normalize(raw) if sched_mod else dict(raw)
                out.append({
                    "i": i,
                    "time": str(item.get("time") or ""),
                    "text": str(item.get("text") or ""),
                    "kind": str(item.get("kind") or "daily"),
                    "when": (sched_mod.describe(item) if sched_mod else ""),
                    "weekdays": [int(x) for x in (item.get("weekdays") or [])],
                    "monthday": int(item.get("monthday") or 1),
                    "date": str(item.get("date") or ""),
                    "enabled": item.get("enabled", True) is not False,
                    "module": str(item.get("kind_module") or "")})
        except Exception as exc:                             # noqa: BLE001
            print(f"（读日程失败：{exc}）")
        return out

    def phone_schedule_do(action: str, payload: dict) -> tuple:
        """手机上加/改/删日程：写回 config.json，电脑上的日程面板会自动跟着变。"""
        import sched as sched_mod
        act = str(action or "")
        item = payload.get("item") if isinstance(payload.get("item"), dict) else {}
        try:
            idx = int(payload.get("i", -1))
        except Exception:                                    # noqa: BLE001
            idx = -1
        try:
            data = load_config()
        except Exception:                                    # noqa: BLE001
            data = {}
        items = [x for x in (data.get("schedules") or []) if isinstance(x, dict)]

        if act == "add":
            new = sched_mod.normalize({
                "time": item.get("time") or "09:00",
                "text": str(item.get("text") or "").strip(),
                "kind": item.get("kind") or "daily",
                "weekdays": item.get("weekdays") or [],
                "monthday": item.get("monthday") or 1,
                "date": item.get("date") or "",
                "enabled": True})
            if not new.get("text"):
                return False, "内容不能是空的"
            items.append(new)
        elif act in ("save", "update"):
            if idx < 0 or idx >= len(items):
                return False, "找不到这条日程"
            old = items[idx]
            old["time"] = item.get("time") or old.get("time") or "09:00"
            old["text"] = str(item.get("text") or old.get("text") or "").strip()
            if not old["text"]:
                return False, "内容不能是空的"
            if item.get("kind"):
                old["kind"] = item["kind"]
            if "weekdays" in item:
                old["weekdays"] = item.get("weekdays") or []
            if item.get("monthday"):
                old["monthday"] = item.get("monthday")
            if item.get("date") is not None:
                old["date"] = item.get("date") or old.get("date") or ""
            items[idx] = sched_mod.normalize(old)
        elif act == "del":
            if idx < 0 or idx >= len(items):
                return False, "找不到这条日程"
            items.pop(idx)
        elif act == "toggle":
            if idx < 0 or idx >= len(items):
                return False, "找不到这条日程"
            items[idx]["enabled"] = not (items[idx].get("enabled", True) is not False)
        else:
            return False, "不认识这个操作"

        data["schedules"] = items
        try:
            (HERE / "config.json").write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:                             # noqa: BLE001
            return False, "存不上：%s" % exc
        try:
            syslog("日程", f"手机上改了日程（{act}）")
        except Exception:                                    # noqa: BLE001
            pass
        return True, "好了"

    phone_pics: list = []

    # ---- 手机上「看原话」：念出去的是清理过的版本，这里另存一份原文给手机看 ----
    # 只记录、不改念的内容 —— 动这里不会影响语音。
    RAW_REPLIES = HERE / "phone-replies.jsonl"

    def phone_raw_reply(name: str, text: str) -> None:
        try:
            rec = {"at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                   "name": str(name or "")[:40], "text": str(text or "")[:4000]}
            with RAW_REPLIES.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            if RAW_REPLIES.stat().st_size > 400_000:
                keep = RAW_REPLIES.read_text(
                    encoding="utf-8", errors="replace").splitlines()
                RAW_REPLIES.write_text("\n".join(keep[-60:]) + "\n", encoding="utf-8")
        except Exception:                                    # noqa: BLE001
            pass

    def phone_replies() -> list:
        """最近几条回答的原话（新的在前）。"""
        out = []
        try:
            lines = RAW_REPLIES.read_text(
                encoding="utf-8", errors="replace").splitlines()
        except Exception:                                    # noqa: BLE001
            return out
        for ln in lines[-40:]:
            try:
                rec = json.loads(ln)
                if isinstance(rec, dict):
                    out.append(rec)
            except Exception:                                # noqa: BLE001
                pass
        out.reverse()
        return out

    def phone_got_image(path) -> None:
        """手机发来的图片：排个队，让 worker 贴进聊天窗口（让 AI 能看图）。"""
        with phone_lock:
            phone_pics.append(path)

    def paste_phone_images() -> bool:
        """把手机发来的图片贴进目标窗口。一次全贴完。"""
        while True:
            with phone_lock:
                if not phone_pics:
                    return False
                path = phone_pics.pop(0)
            try:
                hwnd_pic, _t = pick_send_target(cfg, args.target, tracker)
                if image_to_clipboard(__import__("PIL.Image", fromlist=["Image"]).open(str(path))):
                    paste_clipboard(hwnd_pic, press_enter=False, clear_first=False)
                    print(f"   ↳ 📷 手机发来的图片已贴进对话窗口：{path.name}", flush=True)
                    syslog("动", f"手机发来图片，已贴进聊天窗口：{path.name}")
                else:
                    print(f"   （手机发来的图片贴不进去：{path.name}）", flush=True)
            except Exception as exc:  # noqa: BLE001
                print(f"   （手机发来的图片处理失败：{exc}）", flush=True)

    def phone_voice(wav_bytes: bytes) -> str:
        """手机录的一段语音（wav）：用本机模型识别成文字，再当成你说的话办掉。

        手机上的浏览器不让开麦克风（http 不是安全上下文），所以录音是 APP 的原生部分做的，
        录成 16k 单声道 wav 传过来 —— 不用额外装任何解码器（Python 自带 wave 就能读）。
        """
        try:
            import io as _io
            import wave as _wave

            with _wave.open(_io.BytesIO(wav_bytes), "rb") as wf:
                ch, sw, sr0, n = (wf.getnchannels(), wf.getsampwidth(),
                                  wf.getframerate(), wf.getnframes())
                raw = wf.readframes(n)
            if sw == 2:
                data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
            else:
                data = np.frombuffer(raw, dtype=np.uint8).astype(np.float32) / 128.0 - 1.0
            if ch > 1:
                data = data.reshape(-1, ch).mean(axis=1)
            if sr0 != rate and len(data) > 1:
                idx = np.linspace(0, len(data) - 1, max(1, int(len(data) * rate / sr0)))
                data = np.interp(idx, np.arange(len(data)), data).astype(np.float32)
            if data.size < rate // 4:
                return ""
            got = transcriber.transcribe(data)
        except Exception as exc:  # noqa: BLE001
            print(f"   （手机录音读不了：{exc}）", flush=True)
            return ""
        got = (got or "").strip()
        print(f"\n📱 手机说：{got}", flush=True)
        if not got:
            return ""
        phone_push(got)                 # 走同一条管线（跟手机打的字一样）
        return got

    def phone_log(since: int, keyword: str = "") -> list[dict]:
        """给手机看的对话流：只挑「你说的 / 它念的 / 它发的」，内部日志不刷上去。

        另外把"没听清 / 自己的声音 / 疑似幻觉 / 背景音"这类**噪音条目**滤掉 ——
        手机屏幕就那么大，那些是给电脑上排查用的，别占着对话流（用户反馈"没听清"老冒出来）。
        """
        out: list[dict] = []
        # 同一句话短时间内重复出现的，手机上只留一条。
        # 为什么会有重复：手机发的那句在电脑日志里会记两条 —— 一条带「（手机）」、
        # 一条是主程序自己记的；再加上朗读/重连时的重复写入，手机上就看着像刷屏
        # （用户截图反馈："同一条问题和同一句应答出现好几遍"）。
        recent: list[tuple] = []            # [(kind, 规整后的文字, 行号)]
        # 手机上只留：你说的（听）、它念的（念）、干完了（完）。
        # 「答」跟「念」是同一条回答（一个记录、一个朗读），两个都发会显示两条；
        # 「发」是"我把它发到哪个窗口了"的内部记事，手机上看着就是一行行
        # 「ChatGPT：你说的那句」小字，也去掉（用户反馈"每说一句下面就多一行"）。
        kinds = {"听": "me", "念": "ai", "完": "done"}
        noise = ("没听清", "自己的声音", "疑似幻觉", "背景音", "这句忽略", "忽略）",
                 "抢话", "重复第二遍", "开机问候")
        try:
            lines = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        except Exception:
            return out
        for i, line in enumerate(lines, start=1):
            if i <= int(since or 0):
                continue
            m = re.match(r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[(.+?)\] (.*)$", line)
            if not m:
                continue
            tag, body = m.group(1), m.group(2)
            if tag not in kinds or not body:
                continue
            if body.startswith("（") and any(w in body[:24] for w in noise):
                continue
            if keyword and keyword not in body:
                continue                      # 手机上搜历史：只要带这个关键词的
            if not keyword:
                key = (kinds[tag], body.replace("（手机）", "").strip()[:120])
                if any(k == key[0] and t == key[1] and (i - n0) <= 12
                       for k, t, n0 in recent):
                    continue                  # 12 行以内出现过一样的 → 跳过
                recent.append((key[0], key[1], i))
                if len(recent) > 60:
                    del recent[:-60]
            # 带上这条日志自己的时间（HH:MM）—— 手机上气泡显示的就是"这句话什么时候说的"，
            # 不是"你什么时候打开这个页面"（用户反馈过）。
            stamp = line[11:16] if len(line) >= 16 else ""
            # 「（手机）」这个前缀去掉再发：留着的话，手机上"本机先显示的那条"跟服务器这条
            # 文字对不上，去重失效 → 发一句话跳两个气泡（用户反馈过）。
            body_out = body.replace("（手机）", "", 1).strip() or body
            out.append({"n": i, "kind": kinds[tag], "text": body_out[:500], "at": stamp})
        return out[-60:]

    if cfg.get("phone_enabled", True) and not (args.feed or args.test_paste):
        try:
            phone_server = phone_link.PhoneLink(
                on_command=phone_push, get_state=phone_state, get_log=phone_log,
                on_stop=shut_up, port=int(cfg.get("phone_port") or phone_link.DEFAULT_PORT))
            # 手机一连上就在系统日志里记一条（排查"连不上"的时候一眼能看出来）
            phone_server.on_client = lambda ip: syslog("动", f"手机入口有设备连上：{ip}")
            phone_server.on_voice = phone_voice      # 手机按住说话 → 本机识别 → 执行
            phone_server.get_info = phone_info        # 手机上显示"它叫什么"
            phone_server.on_image = phone_got_image   # 手机发来的图片 → 贴进对话窗口
            phone_server.get_schedule = phone_schedule_list   # 手机「日程」页：读电脑上的日程
            phone_server.on_schedule = phone_schedule_do      # 手机上加/改/删日程
            phone_server.get_replies = phone_replies          # 手机「看原话」：原文一份
            # 手机上切"这句话发到哪个对话窗口"
            # 手机上列的是**我和你的会话**（Codex 里的那些对话），不是电脑窗口
            try:
                import codex_threads

                phone_server.get_windows = codex_threads.list_threads
                print("   （手机上的「对话会话」= Codex 里的会话，实时同步）")
            except Exception as exc:            # noqa: BLE001
                print(f"   （读 Codex 会话列表失败，退回电脑窗口：{exc}）")
                phone_server.get_windows = list_chat_windows
            phone_server.get_target = lambda: str(PHONE_WINDOW.get("title") or "")
            phone_server.on_target = set_phone_window
            if phone_server.start():
                print(f"📱 手机入口已开：{phone_server.url()}")
                print("   （手机连同一个 Wi-Fi，用浏览器打开上面这条网址；"
                      "出门在外面用就开设置 → 智能 → 外网访问，点「一键开启」）")
                threading.Thread(target=phone_worker, daemon=True).start()
            else:
                phone_server = None
        except Exception as exc:  # noqa: BLE001
            print(f"   （手机入口没起来：{exc}）")
            phone_server = None

    # 暂停状态（悬浮窗按钮和暂停键共用）
    pause = {"prev": False, "paused": False}

    def set_paused(value: bool, why: str = "") -> None:
        pause["paused"] = value
        if value:
            status.set("paused", hint=f"点悬浮窗的开关继续（或按 {args.pause_key}）")
            print(f"\r⏸ 已暂停{why}" + " " * 12, flush=True)
        else:
            status.set("idle" if wake_words else "listening")
            print("\r▶ 继续" + " " * 28, flush=True)
        beep(520 if value else 880, 90, args.beep)

    # ---- 配置热加载：悬浮窗里改了唤醒词/档位，不重启也生效 ----
    cfg_watch = {"next": 0.0, "mtime": 0.0}

    def reload_wake_settings() -> None:
        now = time.time()
        if now < cfg_watch["next"]:
            return
        cfg_watch["next"] = now + 1.0
        try:
            mtime = CONFIG_FILE.stat().st_mtime
        except OSError:
            return
        if mtime == cfg_watch["mtime"]:
            return
        cfg_watch["mtime"] = mtime
        fresh = load_config()
        cfg.clear()
        cfg.update(fresh)
        if not (mode == "talk" and args.immediate):
            words = [w.strip() for w in str(fresh.get("wake_word") or "").split(",") if w.strip()]
            if words and words != wake_words:
                wake_words[:] = words
                print(f"\n   ↳ 唤醒词已换成：{'、'.join(words)}", flush=True)
            cancels = [w.strip() for w in str(fresh.get("cancel_word") or "").split(",")
                       if w.strip()]
            cancel_words[:] = cancels
        new_name, new_level = wake_levels.params(fresh)
        if new_level != level:
            level.update(new_level)
            print(f"\n   ↳ 唤醒档位已换成：{new_name}（{wake_levels.describe(new_level)}）",
                  flush=True)
        # 门槛和热词都跟着最新设置走
        if mode == "talk" and not wake_words:
            recorder.min_voiced_blocks = max(
                1, int(0.62 * recorder.sr / recorder.blocksize))
        else:
            recorder.min_voiced_blocks = max(
                1, int(level["min_voiced"] * recorder.sr / recorder.blocksize))
        recorder.noise_mult = max(1.0, float(level["noise_mult"]))
        recorder.confirm = max(1, int(level["confirm"]))
        music["on"] = bool(fresh.get("wave_spectrum", False))   # 设置里的音浪开关
        # 桌宠：设置里开着就该有，没在跑就拉起来；关掉它自己会退
        if fresh.get("pet_enabled", True):
            if pet_proc["p"] is None or pet_proc["p"].poll() is not None:
                pet_proc["p"] = start_pet()
        transcriber.hotwords = (" ".join(wake_words + cancel_words)
                                if level.get("hotwords") else "")

    # ---- 唤醒词自检：改唤醒词时自动跑一次 ----
    test_state = {"running": False}

    def start_wake_test(why: str = "") -> None:
        if test_state["running"] or not wake_words:
            return
        test_state["running"] = True
        print(f"\n   ↳ 🧪 开始唤醒词自检{why}", flush=True)
        status.set("thinking", text="正在自检唤醒词…")

        def job() -> None:
            try:
                result = wake_selftest(transcriber, load_config())
                WAKE_TEST_FILE.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
                summary = result.get("summary") or "自检结束"
                print(f"   ↳ 🧪 {summary}", flush=True)
                for case in result.get("cases") or []:
                    print(f"      · {case['wake']} 噪声{case['noise']:g} 音量{case['gain']:g}"
                          f" → {case['text']!r} {'✓' if case['hit'] else '✗'}", flush=True)
                speak(summary)          # 念出来（措辞里不含唤醒词，免得把自己叫醒）
            except Exception as exc:  # noqa: BLE001
                print(f"   ↳ 🧪 自检出错：{type(exc).__name__}: {exc}", flush=True)
            finally:
                test_state["running"] = False
                status.set("idle" if wake_words else "listening")

        threading.Thread(target=job, daemon=True).start()

    def remote_action(action: str) -> None:
        if action == "pause":
            set_paused(True, "（悬浮窗按的）")
        elif action == "resume":
            set_paused(False, "（悬浮窗按的）")
        elif action == "toggle":
            set_paused(not pause["paused"])
        elif action == "wake-test":
            start_wake_test("（悬浮窗点的）")
        elif action == "editing-on":
            editing["on"] = True
            syslog("编", "你在改设置：先不抢键盘")
            print("\n   ↳ ✏️ 你在改设置，我先不抢键盘（只放剪贴板）", flush=True)
        elif action == "editing-off":
            editing["on"] = False
            print("\n   ↳ ✏️ 设置改完了，恢复粘贴", flush=True)
        elif action == "export":
            threading.Thread(target=do_export, daemon=True).start()
        elif action == "import":
            threading.Thread(target=do_import, daemon=True).start()
        elif action == "diagnose":
            threading.Thread(target=do_diagnose, daemon=True).start()
        elif action == "restart":
            restart_program()
        elif action == "quit":
            # 悬浮窗点了"退出语音程序"：把状态写清楚再干净退出
            print("\n收到悬浮窗的退出指令，正在退出…", flush=True)
            # 留个记号：这次是"你要它退"，看门狗别再把它拉起来
            try:
                MANUAL_EXIT.write_text(json.dumps({"ts": time.time()}), encoding="utf-8")
            except Exception:
                pass
            status.set("offline", hint="语音程序已退出")
            raise SystemExit(0)

    remote = RemoteControl(remote_action)
    # 「自动念回答」：发完消息之后盯着目标窗口，AI 的回答一出来就念
    # 念出来的回答顺手记进系统日志 —— 这样"共享记忆"里两边的话都全了
    global REPLY_READER
    REPLY_READER = reply_reader.ReplyReader(
        # 这里必须用"念完再返回"的那个 —— 否则排队只排了"启动进程"，
        # 两条回答会同时在出声（用户反复反馈"语音会重叠"）。
        lambda text: speak(text, wait=True),
        record=lambda text: syslog("答", text.replace("\n", " ")[:300]),
      # 只记原文给手机看（不影响念）
      on_raw=phone_raw_reply,
      # 这条回答**念完了**（只是语音这边念完了，不等于电脑那边活全干完）
      done=lambda who: syslog("完", f"（{who or '对话'}）这段语音念完了"))

    # ---- 手机网页热重载：只改了那张网页（phone_link.py）时，不用重启整个程序 ----
    # 用户明确说过："我没动悬浮窗相关的东西，就别重启悬浮窗，太浪费时间"。
    # 页面是模块级常量 PAGE，热重载模块就会换成新的一份，正在跑的 HTTP 服务
    # 下一次请求就读到新页面了（不用等 20 多秒重新加载模型）。
    page_watch = {"mtime": 0.0, "next": 0.0}

    def hot_reload_page() -> None:
        now_t = time.time()
        if now_t < page_watch["next"]:
            return
        page_watch["next"] = now_t + 2.0
        try:
            src = Path(phone_link.__file__).resolve()
            mt = src.stat().st_mtime
        except Exception:
            return
        if not page_watch["mtime"]:
            page_watch["mtime"] = mt
            return
        if mt == page_watch["mtime"]:
            return
        page_watch["mtime"] = mt
        try:
            import importlib

            importlib.reload(phone_link)
            print("🔄 手机网页已热重载（没重启程序）", flush=True)
            syslog("检", "手机网页热重载")
        except Exception as exc:            # noqa: BLE001
            print(f"（手机网页热重载失败：{exc}）", flush=True)

    def remote_tick() -> bool:
        """给录音循环当 tick 用：顺手收一下悬浮窗的按钮命令。"""
        remote.poll()
        reload_wake_settings()
        hot_reload_page()
        maybe_night_diary()
        check_hotkey()
        maybe_reminders()
        keep_overlay_alive()
        return pause["paused"]

    def on_speech() -> None:
        status.set("hearing")
        if spoken_flag["first"]:
            spoken_flag["first"] = False
            print("\r🎙 听到声音，正在识别…" + " " * 10, flush=True)
        else:
            print("\r🎙 正在识别…" + " " * 20, flush=True)

    def handle(audio: np.ndarray | None, sr: int | None = None,
               pre_text: str | None = None, from_phone: bool = False) -> bool:
        """识别并输出，返回 True 表示该退出了。

        pre_text/from_phone：手机入口发来的命令（文字已经有了，不用录音，
        也不要求喊唤醒词、不做声纹判断），走的是同一条发送/执行管线。
        """
        sr = sr or rate
        status.set("thinking")
        t0 = time.time()
        text = pre_text if pre_text is not None else transcriber.transcribe(audio)
        if not text:
            print("\r（识别不到内容，继续）" + " " * 20, flush=True)
            status.set("idle")
            # 说了半句却啥也没识别到，说一声，别让它静悄悄没了
            if audio is not None and audio.size > sr * 0.45 and time.time() - not_heard["at"] > 30:
                not_heard["at"] = time.time()
                syslog("听", "（这段没听清）")
                if cfg.get("not_heard_reply", True):      # 不想听它念就关掉这个开关
                    speak("没听清，再说一遍")
            return False
        # 语气先算出来存着，但只有在"这句真被它接收了"的时候才生效——
        # 否则背景音被识别成短句也会触发"你急了"，线条会莫名其妙变黄
        mood = guess_mood(audio, sr, text) if audio is not None else ""
        status.mood = ""
        text = canonize(text)                          # 同音错字换回命令词
        text = apply_corrections(text, cfg.get("corrections"))   # 你自己教的替换
        if is_hallucination(text):                     # 杂音上编出来的固定句子
            print("\r（这句像是电视/杂音里编出来的，丢掉）" + " " * 10, flush=True)
            syslog("噪", f"（疑似幻觉）{text[:30]}")
            status.set("idle")
            return False
        print(f"\n📝 {text}")
        if audio is not None:
            print(f"   （{len(audio) / sr:.1f}s 语音，识别耗时 {time.time() - t0:.1f}s）")
        else:
            print(f"   （手机发来的命令，耗时 {time.time() - t0:.2f}s）", flush=True)
        append_log(Path(args.out), text)
        if mode == "talk":
            # 声纹：注册中就把这句当样本；注册过就顺手算一下像不像
            if audio is not None and voiceprint["enroll"]:
                voiceprint["enroll"] = False
                ok = voice_enroll(audio, sr)
                syslog("声", "声纹注册" + ("成功" if ok else "失败（声音太短或太轻）"))
                speak("记住你的声音了" if ok else "没听清，等下再说一次")
                print(f"   ↳ 🎙 声纹注册{'成功' if ok else '失败'}", flush=True)
                status.set("sent", text="🎙 声纹已注册" if ok else "🎙 没听清")
                return False
            score = voice_score(audio, sr) if audio is not None else None
            voiceprint["last_score"] = score      # 待会儿发出去之前还要用一次
            voiceprint["wake_score"] = None       # 这句还没做过唤醒声纹检查（免得用上一句的）
            if score is not None and audio is not None:
                syslog("声", f"声纹相似度 {score:.2f}")
                if cfg.get("voiceprint_warn", False) and score < 0.55:
                    status.set("sent", text=f"⚠️ 这次不太像你的声音（{score:.2f}）")
                    print(f"   ↳ 🎙 声纹相似度偏低：{score:.2f}", flush=True)
            # ⓪ 闭嘴词：它正在念的时候，你一喊就停（不用先喊唤醒词）
            if speaking_now() and is_stop_word(text, stop_words):
                shut_up()
                status.set("sent", text="🤐 好，不说了")
                print("   ↳ 🤐 闭嘴", flush=True)
                beep(440, 70, args.beep)
                return False
            # ⓪b 闭麦：这句是它自己在说话时录到的，直接丢掉，免得把自己的声音当指令
            # 手机发来的命令不判"是不是它自己在念"（它是打字进来的，不是它的声音）
            if not from_phone and (self_speech["on"] or speaking_now()):
                # 拿"它刚念过的所有句子"比一遍：speak.json 里念完就清空了，只靠它会漏判
                candidates = [self_spoken_text()] + recent_spoken()
                mine = next((s for s in candidates if s and sounds_like(text, s)), "")
                if mine:
                    # 你重复第二遍 = 那一定是你在说（它自己不会把同一句连念两遍）。
                    # 所以刚才被误判丢掉的那句，再说一次就照常当你的话处理。
                    repeated = (self_voice_miss["text"]
                                and repeated_after_miss(text, self_voice_miss))
                    if repeated:
                        print("   ↳ 🔁 这句你刚说过一遍（上次被当成我的声音丢了），这次算你说的",
                              flush=True)
                        syslog("听", f"（重复第二遍，当你说的话）{text[:40]}")
                        self_voice_miss.update(text="", at=0.0)
                    else:
                        print("   ↳ （这句是它自己念的，忽略）", flush=True)
                        syslog("噪", f"（自己的声音）{text[:40]}")
                        self_voice_miss.update(text=text, at=time.time())
                        status.set_mood("")
                        return False
                else:
                    # 抢话：唤醒词得在**开头**（"大肥鱼，等一下"），或者整句就是那三个字。
                    # 只看"句子里有没有"的话，热词偏置偶尔会让它把随便一句听成唤醒词，
                    # 结果它把自己念到一半的话给掐了。
                    head_hit = extract_word(text[:4], wake_words, fuzzy=level["fuzzy"],
                                            leading=False)[1]
                    if head_hit or (len(text) <= 6 and extract_word(
                            text, wake_words, fuzzy=level["fuzzy"],
                            leading=level["leading"])[1]):
                        # 先闭嘴再听你说
                        shut_up()
                        print("   ↳ 🔇 你打断了它，接着听你说", flush=True)
                        syslog("听", f"（抢话）{text}")
                        time.sleep(0.15)
                    else:
                        print("   ↳ （这句像是我自己说的，忽略）", flush=True)
                        status.set_mood("")
                        return False
            # ⓪c 听写模式开关（不用先喊唤醒词，不然录到一半开不了口）
            plain_text = text.replace(" ", "")
            if any(w in plain_text for w in ("开始听写", "进入听写", "打开听写", "开启听写")):
                dictation["on"] = True
                speak("好，开始听写，你说的话直接打进光标")
                print("   ↳ ⌨️ 进入听写模式", flush=True)
                status.set("listening", text="⌨️ 听写中", hint="说完直接打进光标，说「停止听写」结束")
                beep(1180, 80, args.beep)
                return False
            if any(w in plain_text for w in ("停止听写", "结束听写", "关闭听写", "退出听写")) or (
                    dictation["on"] and is_stop_word(text, stop_words)):
                dictation["on"] = False
                speak("好，听写结束")
                print("   ↳ ⌨️ 退出听写模式", flush=True)
                status.set("idle")
                beep(620, 90, args.beep)
                return False
            # ⓪d 听写进行中：不走唤醒词那一套，直接打进光标
            if dictation["on"]:
                type_into_focused(text)
                status.set("listening", text=f"⌨️ {text}", hint="听写中，说「停止听写」结束")
                return False
            # ⓪e 问状态：本地就能答，别发到聊天窗口（手机上发「状态」也走这里）
            if plain_text in ("状态", "现在的状态", "现在状态", "什么状态", "进度",
                              "现在怎么样", "你在干嘛", "在干什么", "在干嘛呢"):
                tail = ""
                try:
                    rows = SYSLOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
                    for line in reversed(rows):
                        m = re.match(r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[(.+?)\] (.*)$", line)
                        if not m:
                            continue
                        tag, body = m.group(1), m.group(2)
                        if tag in ("听", "答") and body and "（手机）" not in body:
                            tail = f"最近一条是{'你说的' if tag == '听' else '它念的'}：{body[:40]}。"
                            break
                except Exception:
                    tail = ""
                hint_txt = str((getattr(status, "_last", {}) or {}).get("text") or "")
                answer = (f"现在状态是 {status.state}"
                          + (f"，{hint_txt}" if hint_txt else "")
                          + (f"。{tail}" if tail else "。"))
                speak(answer)
                print(f"   ↳ 📊 {answer}", flush=True)
                syslog("动", f"问状态：{answer[:60]}")
                status.set("sent", text="📊 已报状态")
                return False
            # 唤醒词在前（像"Hey Siri"）：先说唤醒词，之后说的那句才会发出去
            body, woke = extract_word(text, wake_words,
                                      fuzzy=level["fuzzy"], leading=level["leading"])
            if from_phone:
                body, woke = text, True      # 手机发来的：不用喊唤醒词，直接算"已唤醒"
            elif wake_words and not woke and looks_like_wake(text, wake_words):
                # 喊唤醒词喊错了字（真机：说「大肥鱼」被写成「大肥大」）——
                # 以前这种会被当成"你要发的话"发进聊天窗口，现在一律当唤醒：叮一声接着听你说
                body, woke = "", True
                syslog("听", f"（这句像唤醒词喊错了字：{text[:12]}）")
                print(f"   ↳ 🔔 这句像喊唤醒词（{text}），当唤醒处理", flush=True)
            if wake_words:
                # 取消词要在"去掉唤醒词之后"的正文里找，而且要求**整句就是它**（严格判定）。
                # 以前拿唤醒档位的同音容错去整句里找，误判过一串：
                #   "取笑他"、"去小卖部"、"取消订单" 都可能被当成取消，你正经说的话就没了。
                if cancel_hit(body, cancel_words):
                    armed["on"] = False
                    beep(440, 90, args.beep)
                    print("   ↳ 好，取消了")
                    syslog("撤", f"（取消）{text[:30]}")
                    status.set_mood("")
                    status.set("idle")
                    return False
                if woke:
                    status.set_mood(mood)
                    # 开了"只认我的声音"就会在这里拦（手机发来的没有录音，跳过声纹）
                    if audio is not None and not wake_voice_ok(audio):
                        status.set_mood("")
                        syslog("噪", "（声纹不像本人，忽略这次唤醒）")
                        return False
                    award("wake")
                    armed["until"] = time.time() + args.wake_timeout
                    if body:  # "大肥鱼 今天天气怎么样" 这种一口气说完的
                        armed["on"] = False
                        text_to_send = body
                        status.set("thinking", text=body)
                    else:  # 只说了唤醒词，接下来听你要问什么
                        armed["on"] = True
                        beep(880, 70, args.beep)
                        time.sleep(0.06)
                        beep(1320, 90, args.beep)
                        print(f"   ↳ 🔔 我在听，请说要问的（{args.wake_timeout:g} 秒内有效）")
                        status.set("listening", text="", hint="说吧，说完自动发出去")
                        return False
                elif armed["on"] and time.time() <= armed["until"]:
                    status.set_mood(mood)
                    armed["on"] = False
                    if looks_like_wake(text, wake_words):
                        # 免唤醒窗口里又在喊它（可能喊错字）→ 重新进入"我在听"，别把这句发出去
                        armed["until"] = time.time() + args.wake_timeout
                        print(f"   ↳ 🔔 又听到像唤醒词的一句（{text}），继续听你说", flush=True)
                        status.set("listening", text="", hint="说吧，说完自动发出去")
                        return False
                    # 免唤醒窗口里的这句也要过一遍声纹：电视、它自己的回声都在这个时候最容易混进来
                    if not wake_voice_ok(audio):
                        syslog("噪", f"（免唤醒窗口里不像本人）{text[:30]}")
                        status.set("idle", text=f"（忽略）{text}")
                        return False
                    text_to_send = text
                    status.set("thinking", text=text)
                else:
                    armed["on"] = False
                    status.set_mood("")
                    print(f"   ↳ （没听到「{wake_words[0]}」，这句忽略）")
                    status.set("idle", text=f"（忽略）{text}")
                    return False
            else:
                status.set_mood(mood)
                text_to_send = text

            # ① 快捷指令：说中自定义短语就直接执行，不发给 AI
            hit = run_shortcut(text_to_send, cfg)
            if hit:
                print(f"   ↳ ⚡ 快捷指令已执行：{hit}", flush=True)
                status.set("sent", text=f"⚡ {hit}")
                beep(980, 80, args.beep)
                arm_followup()
                time.sleep(0.6)
                return bool(args.once)

            def done() -> bool:
                arm_followup()
                time.sleep(0.4)
                return bool(args.once)

            # ①b 小游戏：正在玩就接着玩，说了开局就开局
            if game_feed(text_to_send):
                return done()
            opening = parse_game(text_to_send)
            if opening:
                game_start(*opening)
                return done()

            # ①c 番茄钟
            minutes = parse_focus(text_to_send)
            if minutes is not None:
                if minutes == -1:
                    focus_stop()
                elif minutes == 0:
                    if focus_active():
                        left = focus_left()
                        speak(f"还剩 {int(left // 60)} 分 {int(left % 60)} 秒")
                    else:
                        speak("现在没在专注哦")
                else:
                    focus_start(minutes)
                return done()

            # ①d 便签 / 记账
            if any(q in text_to_send for q in _QUERY_LEDGER):
                say_ledger()
                return done()
            if any(q in text_to_send for q in _QUERY_NOTE):
                say_notes()
                return done()
            ledger_hit = parse_ledger(text_to_send)
            if ledger_hit:
                add_ledger(*ledger_hit)
                beep(880, 70, args.beep)
                return done()
            note_body = parse_note(text_to_send)
            if note_body:
                add_note(note_body)
                beep(880, 70, args.beep)
                return done()

            # ①e 变身 / 早间播报
            if parse_transform(text_to_send):
                transform()
                return done()
            if parse_brief(text_to_send):
                brief_now()
                return done()

            # ①f 「以后把××改成××」这个自学习纠错**已经按用户要求删掉了**
            #    （他说全是误判：随口说的话常被当成教它改错字）。
            #    原来的代码在 parse_correction / apply_corrections 里，现在都停用了。
            # ①g 本地口算 / 单位换算（秒答，不占对话）
            calc = parse_calc(text_to_send)
            if calc:
                show, value = calc
                answer = (f"{show} 等于 {value:g}" if abs(value - round(value)) < 1e-9
                          else f"{show} 等于 {value:.4f}".rstrip("0").rstrip("."))
                speak(answer)
                print(f"   ↳ 🧮 {answer}", flush=True)
                status.set("sent", text=f"🧮 {answer}")
                return done()
            conv = parse_convert(text_to_send)
            if conv:
                speak(conv)
                print(f"   ↳ 📐 {conv}", flush=True)
                status.set("sent", text=f"📐 {conv}")
                return done()

            # ①h 媒体控制
            media = parse_media(text_to_send)
            if media:
                name, vk = media
                _key(vk)
                _key(vk, up=True)
                print(f"   ↳ 🎵 媒体键：{name}", flush=True)
                status.set("sent", text=f"🎵 {name}")
                beep(980, 60, args.beep)
                return done()

            # ①i 用嘴开程序 / 找文件
            wanted = parse_open(text_to_send)
            if wanted:
                opened = open_named(wanted)
                if opened:
                    speak(f"打开了{opened}")
                    print(f"   ↳ 📂 打开：{opened}", flush=True)
                    status.set("sent", text=f"📂 {opened}")
                    return done()
                print(f"   ↳ （没找到「{wanted}」，交给 AI 处理）", flush=True)

            # ①j 音浪模式 / 日记
            if "音浪" in plain_text or "频谱" in plain_text:
                want = not any(w in plain_text for w in ("关", "停", "不要", "退出"))
                fresh = load_config()
                fresh["wave_spectrum"] = want
                try:
                    CONFIG_FILE.write_text(json.dumps(fresh, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
                except Exception:
                    pass
                cfg["wave_spectrum"] = want
                music["on"] = want
                speak("音浪开了，放点音乐吧" if want else "音浪关了")
                print(f"   ↳ 🎚 音浪：{'开' if want else '关'}", flush=True)
                status.set("sent", text=f"🎚 音浪{'开' if want else '关'}")
                return done()
            if any(w in plain_text for w in ("日记", "今天我说了什么", "今天总结")):
                say_diary()
                return done()

            # ①k 上下文指代：「跟刚才一样」
            if parse_repeat(text_to_send):
                if last_sent["text"] and time.time() - last_sent["at"] < 600:
                    speak("好，再来一次")
                    print(f"   ↳ 🔁 重发：{last_sent['text'][:40]}", flush=True)
                    text_to_send = last_sent["text"]
                else:
                    speak("我还不知道要重复哪一句")
                    return done()

            # ①l 看屏幕：截屏贴进聊天窗口，让对面看图说话
            #    （设置 → 功能 → 看屏幕截图 可以关掉；关掉之后不会截屏，只会说一声）
            # ①l-1 屏幕发手机：截一张（或录一小段）放到手机入口里，手机上能直接看
            # ①l-2 发文件给手机：说「把桌面的报表.xlsx 发到手机」/「把 xxx 发给我」
            want_file = ""
            for head in ("把", "将"):
                m2 = re.search(head + r"(.{1,60}?)(发到手机|发给手机|发手机|发给我|传到手机)",
                               plain_text)
                if m2:
                    want_file = m2.group(1).strip("的 ")
                    break
            if want_file:
                if not cfg.get("screen_share", True):
                    speak("发文件我在设置里关掉了")
                    return done()
                src = file_share.find_file(want_file)
                if src:
                    dst = file_share.add_file(src)
                    print(f"   ↳ 📁 已放进手机入口：{dst.name if dst else '（失败）'}", flush=True)
                    syslog("动", f"发文件给手机：{src.name}")
                    speak(f"把{src.name}发过去了，手机上能下载")
                    status.set("sent", text=f"📁 已发到手机：{src.name[:18]}")
                else:
                    print(f"   ↳ 📁 没找到「{want_file}」", flush=True)
                    speak(f"没找到{want_file}，你可以说全一点的文件名")
                    status.set("sent", text=f"📁 没找到 {want_file[:16]}")
                return done()

            if any(w in plain_text for w in ("发手机", "手机上看看", "发到手机", "给我看看屏幕",
                                             "看看电脑屏幕", "看看我电脑")):
                if not cfg.get("screen_share", True):
                    speak("屏幕发手机我在设置里关掉了")
                    print("   ↳ 📱 屏幕发手机已关（设置 → 功能）", flush=True)
                    return done()
                # 「录 10 秒」这种就录一段，否则只截一张
                secs = 0.0
                m = re.search(r"录\s*(\d{1,2})\s*秒", plain_text)
                if m:
                    secs = float(m.group(1))
                elif any(w in plain_text for w in ("录屏", "录一段", "录像", "录制")):
                    secs = 8.0
                if secs:
                    speak(f"好，录 {int(secs)} 秒，录完手机上就能看")
                    path = screen_share.record_screen(seconds=secs)
                    if path:
                        print(f"   ↳ 📱 录屏已放进手机入口：{path.name}", flush=True)
                        syslog("动", f"录屏 {int(secs)} 秒发手机：{path.name}")
                        speak("录好了，手机上刷新一下就能看")
                    else:
                        speak("录屏没成功")
                else:
                    path = screen_share.take_shot()
                    if path:
                        print(f"   ↳ 📱 截图已放进手机入口：{path.name}", flush=True)
                        syslog("动", f"截图发手机：{path.name}")
                        speak("截好了，手机上能看到")
                    else:
                        speak("截图没成功")
                status.set("sent", text="📱 屏幕已发到手机")
                return done()

            if any(w in plain_text for w in ("看屏幕", "看看屏幕", "看下屏幕", "看看这个",
                                             "看这个", "这个报错", "截个屏", "截屏")):
                if not cfg.get("screenshot_enabled", True):
                    speak("看屏幕截图我在设置里关掉了")
                    print("   ↳ 📸 看屏幕截图已关（设置 → 功能 → 看屏幕截图）", flush=True)
                    syslog("动", "看屏幕截图：设置里关着，没截")
                    status.set("sent", text="📸 截图功能已关")
                    return done()
                if grab_screen():
                    hwnd_pic, _t = (find_window(args.target) if args.target else
                                    (tracker.hwnd if tracker else 0, ""))
                    paste_clipboard(hwnd_pic, press_enter=True, clear_first=False)
                    speak("截好图发过去了")
                    syslog("动", "截图并贴进聊天窗口")
                    print("   ↳ 📸 已截图并粘贴", flush=True)
                    status.set("sent", text="📸 截图已发")
                else:
                    speak("截图没成功")
                return done()

            # ①m 事实记忆：记住 XX / 你还记得吗
            body_mem = parse_remember(text_to_send)
            if body_mem:
                memory_add(body_mem)
                speak(f"记住了：{body_mem}")
                syslog("记", f"事实记忆：{body_mem}")
                print(f"   ↳ 🧠 记住：{body_mem}", flush=True)
                status.set("sent", text=f"🧠 {body_mem}")
                beep(980, 70, args.beep)
                return done()
            if parse_ask_memory(text_to_send):
                rows = memory_find(text_to_send)
                if rows:
                    answer = "我记得：" + "；".join(r["text"] for r in rows)
                else:
                    answer = "这个我还真没记住"
                speak(answer)
                syslog("忆", answer)
                print(f"   ↳ 🧠 {answer}", flush=True)
                status.set("sent", text=f"🧠 {answer[:40]}")
                return done()

            # ①n 搜系统日志 / 历史
            want = parse_search(text_to_send)
            if want:
                hits = syslog_search([want], 5)
                if not hits:
                    hits = [ln for ln in syslog_search([want[:2]], 5)] if len(want) >= 2 else []
                if hits:
                    speak(f"找到 {len(hits)} 条，最近的是：" +
                          "；".join(h.split("] ", 1)[-1][:30] for h in hits[:3]))
                else:
                    speak(f"日志里没找到关于{want}的内容")
                print(f"   ↳ 🔎 搜日志 {want} → {len(hits)} 条", flush=True)
                syslog("查", f"搜日志：{want}（{len(hits)} 条）")
                status.set("sent", text=f"🔎 {want}：{len(hits)} 条")
                return done()

            # ①o 周报
            if any(w in plain_text for w in ("周报", "这周怎么样", "这周总结", "本周总结")):
                report = weekly_report()
                speak(report)
                syslog("报", report)
                print(f"   ↳ 📊 周报：{report[:60]}", flush=True)
                status.set("sent", text="📊 周报已生成")
                return done()

            # ①o2 隐私 / 撤销 / 备份 / 更新 / 自检
            # 「打开教程」这类是要那个文件，不是要听教程 —— 先处理，免得被下面
            # 的"教程"分支抢走。而且**不直接拉浏览器**：只把文件在资源管理器里选中，
            # 你想看再双击（不然用户会觉得"它自己把微软浏览器打开了"）。
            if any(w in plain_text for w in ("打开教程", "图文教程", "教程文件", "看看教程")):
                doc = HERE / "使用教程.html"
                if doc.exists():
                    try:
                        subprocess.Popen(f'explorer /select,"{doc}"', shell=True)
                        speak("图文教程在这儿，双击它才会用浏览器打开")
                        syslog("教", "指出图文教程（没自动开浏览器）")
                    except Exception:
                        speak("教程文件打不开")
                else:
                    speak("没找到教程文件")
                return done()
            # 教程：说"教程"开讲，"下一步/继续"往下，"上一步"往回，"退出教程"结束
            if any(w in plain_text for w in ("使用教程", "教程", "教我怎么用", "怎么用这个")):
                if any(w in plain_text for w in ("退出", "结束", "别讲了", "不看了")):
                    tutorial["on"] = False
                    speak("好，教程结束")
                    status.set("idle")
                    return done()
                m_lesson = re.search(r"第\s*([0-9一二三四五六七八九十]+)\s*[课步节]", plain_text)
                if m_lesson:
                    raw = m_lesson.group(1)
                    num = int(raw) if raw.isdigit() else int(cn_number(raw) or 1)
                    tutorial_say(max(0, num - 1))
                    return done()
                tutorial_say(tutorial["step"] if tutorial["on"] else 0)
                return done()
            if tutorial["on"] and any(w in plain_text for w in ("下一步", "继续", "然后呢", "下一个")):
                tutorial_say(tutorial["step"] + 1)
                return done()
            if tutorial["on"] and any(w in plain_text for w in ("上一步", "回去", "前一个")):
                tutorial_say(max(0, tutorial["step"] - 1))
                return done()
            if any(w in plain_text for w in ("别记这段", "别记了", "不要记录", "别记录")):
                PRIVATE["until"] = time.time() + float(cfg.get("private_minutes") or 5) * 60
                speak("好，这几分钟我说过的话都不记")
                print("   ↳ 🕶 进入隐私静默期", flush=True)
                status.set("sent", text="🕶 暂不记录")
                return done()
            if any(w in plain_text for w in ("可以记了", "恢复记录")):
                PRIVATE["until"] = 0.0
                speak("好，恢复记录")
                status.set("sent", text="✍️ 恢复记录")
                return done()
            if "确定清空" in plain_text:
                if PRIVATE.get("clear_ask") and time.time() < float(PRIVATE["clear_ask"]):
                    n = clear_all_data()
                    PRIVATE["clear_ask"] = 0.0
                    speak(f"清掉了 {n} 个文件")
                    status.set("sent", text=f"🧹 已清空 {n} 个文件")
                    return done()
                speak("先说要清空，我再问你一次")
                return done()
            if any(w in plain_text for w in ("清空所有记录", "清空数据", "删除所有记录", "清空日志")):
                PRIVATE["clear_ask"] = time.time() + 30
                speak("这会删掉便签、记账、记忆、日志和成就。确定就说「确定清空」")
                status.set("sent", text="🧹 等你确认")
                return done()
            if any(w in plain_text for w in ("撤销", "撤回", "撤消")) and len(plain_text) <= 6:
                undo_last()
                return done()
            if any(w in plain_text for w in ("导出数据", "备份数据", "导出备份")):
                do_export()
                return done()
            if any(w in plain_text for w in ("打包诊断", "上报问题", "诊断包")):
                out = diag_pack()
                speak(f"诊断包好了，藏在导出文件夹里：{out.name}" if out
                      else "诊断包没打出来")
                syslog("诊", f"生成诊断包：{out.name if out else '失败'}")
                return done()
            if any(w in plain_text for w in ("导入数据", "恢复数据", "导入备份")):
                do_import()
                return done()
            if any(w in plain_text for w in ("检查更新", "有没有新版本")):
                do_update()
                return done()
            if "开始更新" in plain_text:
                apply_update_now()
                return done()
            if any(w in plain_text for w in ("自检", "检查一下自己")):
                problems = self_check(speak_it=False)
                speak("自检都正常" if not problems else "自检发现：" + "；".join(problems))
                status.set("sent", text="🩺 " + ("正常" if not problems else "有问题"))
                return done()
            # 天气城市：自动定位会走代理判到国外，钉死城市更靠谱
            m_city = re.search(r"(?:天气城市|以后天气|查天气的?城市)(?:设成|改成|定为|是|改成)?\s*([\u4e00-\u9fff]{2,8})", plain_text)
            if m_city:
                city = m_city.group(1)
                fresh = load_config()
                fresh["weather_city"] = city
                try:
                    CONFIG_FILE.write_text(json.dumps(fresh, ensure_ascii=False, indent=2),
                                           encoding="utf-8")
                except Exception:
                    pass
                cfg["weather_city"] = city
                speak(f"好，以后天气查{city}")
                syslog("设", f"天气城市 → {city}")
                return done()
            if any(w in plain_text for w in ("今天天气", "天气怎么样", "查天气", "天气如何")):
                line = weather_line()
                speak(line or "天气没查到，可能是网络问题")
                syslog("报", f"天气：{line or '没查到'}")
                status.set("sent", text=f"🌤 {line[:30]}" if line else "🌤 没查到")
                return done()

            # ①p 声纹 / 朗读选中
            if any(w in plain_text for w in ("注册我的声音", "记住我的声音", "声纹注册")):
                speak("你随便说一句话，我记住你的声音特征")
                print("   ↳ 🎙 声纹注册：等下一句话", flush=True)
                voiceprint["enroll"] = True
                return done()
            if any(w in plain_text for w in ("训练唤醒词", "唤醒词训练", "训练我的声音",
                                             "让唤醒词更准", "训练一下唤醒词")):
                train_wake_voice()
                return done()
            if any(w in plain_text for w in ("重启语音程序", "重启一下程序", "重新启动程序")):
                speak("好，三秒后重启")
                threading.Timer(1.0, restart_program).start()
                return done()
            # 发送方式：粘贴并回车 / 只粘贴 / 当打字机
            if "只粘贴" in plain_text and "回车" in plain_text:
                _set_cfg("send_mode", "paste")
                speak("好，以后只粘贴不回车")
                return done()
            if any(w in plain_text for w in ("当打字机", "用打字方式", "别用剪贴板")):
                _set_cfg("send_mode", "type")
                speak("好，以后一个字一个字敲进去")
                return done()
            if any(w in plain_text for w in ("粘贴并回车", "改回正常发送", "正常发送方式")):
                _set_cfg("send_mode", "paste_enter")
                speak("好，改回粘贴并回车")
                return done()
            if any(w in plain_text for w in ("确认再发", "发送前确认", "问我一下再发")):
                want = not any(w in plain_text for w in ("关", "不要", "取消"))
                _set_cfg("confirm_send", want)
                speak("好，以后发之前先问你一声" if want else "好，发之前不问了")
                return done()
            if any(w in plain_text for w in ("念一下我选中的", "朗读选中", "念选中的字")):
                say_selected()
                return done()

            # ② 提醒 / 定时：说"10 分钟后提醒我喝水"这类
            if cfg.get("reminders_enabled", True):
                reminder = parse_reminder(text_to_send)
                if reminder:
                    secs, what = reminder
                    start_reminder(secs, what, bool(cfg.get("reminder_paste")),
                                   tracker.hwnd if tracker else 0)
                    when = (f"{int(secs / 3600)} 小时" if secs >= 3600
                            else f"{int(secs / 60)} 分钟" if secs >= 60 else f"{int(secs)} 秒")
                    ack = f"好，{when}后提醒你{what}"
                    speak(ack)
                    print(f"   ↳ ⏰ {ack}", flush=True)
                    status.set("sent", text=f"⏰ {ack}")
                    beep(880, 80, args.beep)
                    arm_followup()
                    time.sleep(0.6)
                    return bool(args.once)

            hwnd, title = pick_send_target(cfg, args.target, tracker)
            # 手机那边要是挑了"发到哪个对话窗口"，就听手机的（只影响手机发来的话，
            # 电脑上你直接说话还是照旧：跟随前台 / 按 target 找）
            if from_phone:
                ph_hwnd, ph_title = phone_window()
                if ph_hwnd:
                    hwnd, title = ph_hwnd, ph_title
                    # 确保 Codex 真的开在手机选的那个会话上（点了才切；已经在那儿就不动）
                    want = str(PHONE_WINDOW.get("title") or "").strip()
                    if want and want != title:
                        try:
                            import codex_threads

                            now = codex_threads.current_name()
                            if now != want:
                                codex_threads.open_thread(want)
                                time.sleep(0.35)
                                print(f"   ↳ 手机选的是「{want}」，已经切过去了", flush=True)
                        except Exception:
                            pass
            # 最后一道闸：背景里的电视/音乐/歌声也能被识别成短句。
            # 你开了「只认我的声音」的话，就用它拦一下 —— 又不像你的声音、又很短，
            # 那多半不是你对着它说的，直接别发。
            # 但要分清两把尺子：
            #   last_score = 拿"你注册的那句话"比，短句上特别不准（你自己的话也能低到 0.03）
            #   wake_score = 拿"唤醒词训练"的声纹比，专门练过你的声音，0.45 以上就算是你
            # 以前只看 last_score，于是你喊完「大肥鱼」接着说的短句被反复当背景音丢掉 ——
            # 就是你看到的"识别到了、然后自己取消了"。现在唤醒声纹过关就一律放行。
            _sc = voiceprint.get("last_score")
            _wake_sc = voiceprint.get("wake_score")
            if background_noise(text_to_send, _sc, _wake_sc,
                                bool(cfg.get("voiceprint_gate", False))):
                print(f"   ↳ 🔇 不像你的声音（{_sc:.2f}）又很短，当背景音丢了", flush=True)
                syslog("噪", f"（背景音，声纹 {_sc:.2f}）{text_to_send[:30]}")
                status.set("idle", text="")
                return False
            if args.dry_run:
                copy_to_clipboard(text_to_send)
                print(f"   ↳ （dry-run：本来要发「{text_to_send}」，只复制了剪贴板）")
                status.set("sent", text=f"（试跑）{text_to_send}")
            elif not hwnd:
                copy_to_clipboard(text_to_send)
                print("   ↳ ⚠️ 没有可用的目标窗口：先点一下聊天窗口，文字已放剪贴板，手动 Ctrl+V")
                status.set("offline", text=f"没找到窗口，已复制：{text_to_send}")
            elif editing["on"]:
                # 你正在悬浮窗里改设置：这时候去粘贴会把你正在打字的前台窗口抢走
                copy_to_clipboard(text_to_send)
                print(f"   ↳ ✏️ 你在改设置，先不抢键盘：文字已放剪贴板（{text_to_send[:20]}…）",
                      flush=True)
                syslog("听", text_to_send)
                syslog("发", f"（你在改设置，只放了剪贴板）{text_to_send[:40]}")
                status.set("sent", text=f"📋 已复制（改设置中不抢键盘）")
            elif confirm_ok(text_to_send) and send_it(text_to_send, hwnd):
                who = title or "前台窗口"
                print(f"   ↳ 已发到「{who}」：{text_to_send}"
                      + ("（并回车）" if not args.no_send else "（未回车，自己按一下）"))
                last_sent["text"] = text_to_send      # 给"跟刚才一样"用
                last_sent["at"] = time.time()
                syslog("听", text_to_send)
                syslog("发", f"{who}：{text_to_send[:60]}")
                # 发完了：如果开了「自动念回答」，就盯着这个窗口，回答一出来就念
                if REPLY_READER is not None and cfg.get("read_reply", True) and hwnd:
                    # 把窗口标题也带上：回答排队要念"这是哪个对话"时用得上
                    # 名字优先用"我们和你的那个 Codex 会话名"（手机上显示的就是它）。
                    # 以前直接把窗口标题传进去，结果读到了浏览器标签栏那种文字，
                    # 手机上就出现「（关闭Sign in to GitHub · GitHub标签页）回答完了」这种怪东西。
                    try:
                        import codex_threads

                        conv_name = codex_threads.current_name()
                    except Exception:
                        conv_name = ""
                    REPLY_READER.watch(hwnd, text_to_send,
                                       title=conv_name or title)
                    print("   ↳ 🔊 开始念回答（说「停」就不念了；不想要可在设置里关掉）",
                          flush=True)
                if mood:
                    fatigue["speeds"].append(chars_per_second(audio, sr, text_to_send))
                    fatigue["speeds"][:] = fatigue["speeds"][-40:]
                try:                                  # 日记只记"真的说给它听"的
                    with SAID_FILE.open("a", encoding="utf-8") as fh:
                        fh.write(f"- {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} "
                                 f"{privacy_clean(text_to_send)}\n")
                except Exception:
                    pass
                status.set("sent", text=text_to_send)
            else:
                copy_to_clipboard(text_to_send)
                print(f"   ↳ ⚠️ 没能把「{title}」切到前台，文字已放剪贴板，手动 Ctrl+V")
                status.set("offline", text=f"没切到窗口，已复制：{text_to_send}")
            beep(760, 70, args.beep)
            if cfg.get("ack_enabled", True):      # 说完之后回一句（可自定义）
                speak(ack_phrase(cfg))
            arm_followup()
            time.sleep(1.2)  # 让应用消化一下，也避免把它自己的提示音听成你说话
        elif not args.no_clipboard and copy_to_clipboard(text):
            print("   ↳ 已复制到剪贴板，Ctrl+V 就能贴进对话框")
            status.set("copied", text=text)
        return bool(args.once)

    if mode == "hold":
        watcher = KeyWatcher(args.key)
        print(f"按住 {args.key} 说话，松开就识别；不用管窗口焦点。Ctrl+C 退出。")
        key_down = watcher.down
    elif mode == "talk":
        key_down = None
        tracker.poll()  # 先记一次当前窗口，启动时就能显示发送目标
        pause_key = KeyWatcher(args.pause_key)
        stop_track = threading.Event()

        def checked_pause() -> bool:
            """按一下暂停键切换 暂停/继续，返回当前是否暂停。"""
            remote.poll()
            reload_wake_settings()
            focus_tick()
            maybe_night_diary()
            check_hotkey()
            maybe_reminders()
            keep_overlay_alive()
            now = pause_key.down()
            if now and not pause["prev"]:
                set_paused(not pause["paused"])
            pause["prev"] = now
            return pause["paused"]

        def _track() -> None:
            while not stop_track.is_set():
                tracker.poll()
                stop_track.wait(0.2)

        threading.Thread(target=_track, daemon=True).start()
        if args.target:
            fixed_hwnd, fixed_title = find_window(args.target)
            if fixed_hwnd:
                target = f"{fixed_title}（固定）"
            else:
                target = f"⚠️ 找不到标题含「{args.target}」的窗口，改跟你上一个用过的窗口"
        else:
            target = tracker.title or "（还没记录到窗口，先点一下聊天窗口）"
        print(f"对话模式：直接说话，停下来约 {silence:g} 秒就自动识别并发送。")
        if wake_words:
            print(f"唤醒词：「{wake_words[0]}」。先说它，听到两声提示音后再说你要问的，说完自动发出去。")
            print(f"也可以一口气说：「{wake_words[0]}，帮我查一下明天天气」。说「{cancel_words[0]}」取消。")
        else:
            print("发送规则：不用唤醒词，识别完立刻发送。")
        print(f"当前发送目标：{target}")
        print(f"按 {args.pause_key.upper()} 暂停/继续；关掉这个窗口（或 Ctrl+C）就是退出。")
    else:
        key_down = None

    if args.feed:  # 调试用：拿现成音频把整条流程跑一遍，不用对着麦克风说话
        for path in args.feed:
            print(f"\n▶ 测试音频：{Path(path).name}")
            handle(decode_audio_file(path), TARGET_SR)
        return 0

    # 开机问候
    if cfg.get("greeting_enabled", True) and not args.no_greeting:
        greeting = build_greeting(cfg, wake_words[0] if wake_words else "")
        if greeting:
            speak_greeting(greeting, float(cfg.get("greeting_delay") or 3.0))

    # 日程表：后台每分钟检查一次
    def _sched_target() -> int:
        if args.target:
            hwnd, _title = find_window(args.target)
            return hwnd
        return tracker.hwnd if tracker else 0

    def _sched_paste(text: str, hwnd: int) -> None:
        paste_into(text, hwnd, press_enter=True, clear_first=True)

    # 麦克风掉线要能自己接回来（USB 拔了/驱动重置都会让 stream.read 抛异常）
    mic_ok = [True]

    def reconnect_mic() -> bool:
        nonlocal stream, rate, recorder, device
        print("\n🎤 麦克风掉线了，正在重连…", flush=True)
        syslog("检", "麦克风掉线，正在重连")
        try:
            stream.stop()
            stream.close()
        except Exception:
            pass
        for attempt in range(1, 7):
            time.sleep(2)
            try:
                device = None if args.default_input else resolve_device(args.input)
                stream, rate = open_stream(device)
                recorder = Recorder(
                    stream, rate, silence, args.max_seconds,
                    min_voiced=0.62 if (mode == "talk" and not wake_words)
                    else level["min_voiced"],
                    noise_mult=level["noise_mult"], confirm=level["confirm"],
                )
                print(f"🎤 接回来了（第 {attempt} 次尝试）", flush=True)
                syslog("检", "麦克风已重连")
                speak("麦克风接回来了")
                status.set("idle" if wake_words else "listening")
                return True
            except Exception:
                continue
        print("🎤 还是连不上，过一会儿再试", flush=True)
        return False

    def mic_error(exc: BaseException) -> bool:
        text = f"{type(exc).__name__} {exc}".lower()
        return "device" in text or "portaudio" in text or "stream" in text

    def safe_calibrate() -> float:
        try:
            return recorder.calibrate()
        except Exception as exc:  # noqa: BLE001
            if not mic_error(exc):
                raise
            mic_ok[0] = False
            print("\n🎤 麦克风好像不在了，准备重连", flush=True)
            return 0.05

    def safe_record(*a, **kw):
        try:
            return recorder.record_utterance(*a, **kw)
        except Exception as exc:  # noqa: BLE001
            if not mic_error(exc):
                raise
            mic_ok[0] = False
            print("\n🎤 录音中断（设备没了），准备重连", flush=True)
            return None

    start_scheduler(_sched_target, _sched_paste)

    try:
        while True:
            # 麦克风掉线（USB 拔了、驱动重置）会让 stream.read 抛异常。
            # 这里接住：重新找设备、重开流、重新校准，并告诉用户。
            if not mic_ok[0]:
                mic_ok[0] = reconnect_mic()
                if not mic_ok[0]:
                    time.sleep(3)
                    continue
            if mode == "hold":
                remote.poll()
                if pause["paused"]:      # 悬浮窗按了暂停
                    recorder._read()
                    continue
                status.set("idle", hint=f"按住 {args.key} 说话，松开识别")
                audio = recorder.record_hold(
                    key_down,
                    meter=True,
                    on_level=lambda v, _b=None: status.level(v, "hearing", text=""),
                    on_start=lambda: (beep(880, 60, args.beep), print("\r🎙 录音中…", end="", flush=True)),
                    on_stop=lambda: beep(520, 60, args.beep),
                )
                if audio is None:
                    continue
            elif mode == "enter":
                audio = record_ptt(recorder)
                if audio.size < rate // 4:
                    print("（太短，忽略）")
                    continue
            elif mode == "talk":
                if checked_pause():  # 暂停期间只丢帧，保持设备缓冲最新，随时能恢复
                    recorder._read()
                    continue
                self_speech["on"] = speaking_now()    # 它自己在说话时先闭麦
                threshold = safe_calibrate()
                if self_speech["on"]:
                    threshold *= 1.8                  # 门槛抬高，别把喇叭里的自己录进来
                spoken_flag["first"] = True
                status.set("idle" if wake_words else "listening", hint=hint)
                print("\r⌛ 在听你说话…" + " " * 24, flush=True)
                partial = {"text": "", "busy": False, "at": 0.0}

                def show_partial(chunk: np.ndarray) -> None:
                    """边录边把半截话送去识别，悬浮窗就能"边说边出字"。"""
                    if not cfg.get("caption_enabled", True):
                        return
                    if chunk.size > 7 * TARGET_SR:      # 太长了就别抢显卡，等整句
                        return
                    now = time.time()
                    if partial["busy"] or now - partial["at"] < 0.35:
                        return
                    partial["busy"] = True
                    partial["at"] = now

                    def job() -> None:
                        try:
                            got = transcriber.transcribe(chunk)
                            if got and len(got) >= len(partial["text"]):
                                partial["text"] = got
                                status.set("hearing", text=got, level=status_level["v"])
                        except Exception:
                            pass
                        finally:
                            partial["busy"] = False

                    threading.Thread(target=job, daemon=True).start()

                status_level = {"v": 0.0}
                status_bands = {"b": []}
                speech_tick = {"n": 0}

                def on_level_partial(v: float, block=None) -> None:
                    status_level["v"] = v
                    # 录音过程中它可能才开始说话（比如开机问候），所以边录边盯
                    speech_tick["n"] += 1
                    if speech_tick["n"] % 5 == 0 and speaking_now():
                        self_speech["on"] = True
                    if music["on"] and block is not None:
                        status_bands["b"] = spectrum_bands(block, rate)
                    status.level(v, "hearing", text=partial["text"],
                                 bands=status_bands["b"] if music["on"] else None)

                audio = safe_record(
                    threshold, on_speech, tick=checked_pause,
                    on_level=on_level_partial,
                    on_partial=show_partial,
                )
                if audio is None or audio.size < rate // 4:
                    continue
                # 说到最长时长被切断的：接着往下录，把几段拼成一句再说，
                # 这样长段落不会被切成好几条分别发出去
                if recorder.last_cut:
                    parts = [audio]
                    total = int(audio.size)
                    print("\r✍️ 还没说完，接着录…" + " " * 20, flush=True)
                    status.set("hearing", text="（还在说，接着说…）")
                    for _ in range(5):
                        more = safe_record(threshold, None, tick=checked_pause,
                                           on_level=on_level_partial)
                        if more is None or more.size == 0:
                            break
                        parts.append(more)
                        total += int(more.size)
                        if not recorder.last_cut or total > rate * 120:
                            break
                    audio = np.concatenate(parts)
                    print(f"\r✍️ 拼好了，共 {audio.size / rate:.0f} 秒" + " " * 10, flush=True)
            else:
                threshold = safe_calibrate()
                spoken_flag["first"] = True
                status.set("listening", hint="直接说话，停顿约 1 秒自动断句")
                print("\r⌛ 在听了，直接说话就行…" + " " * 20, flush=True)
                audio = safe_record(
                    threshold, on_speech,
                    tick=remote_tick,
                    on_level=lambda v, _b=None: status.level(v, "hearing", text=""),
                )
                if audio is None or audio.size < rate // 4:
                    print("\r（没听到说话，继续听）" + " " * 20, flush=True)
                    continue

            with handle_lock:          # 跟"手机发来的命令"排队，不抢窗口/剪贴板
                if handle(audio):
                    return 0
    except KeyboardInterrupt:
        print("\n已退出。")
        return 0
    except Exception as exc:            # noqa: BLE001
        # 出事了要说出来：写日志 + 让看门狗重启它，重启时再报一句"我恢复了"
        import traceback

        detail = "".join(traceback.format_exception(exc))
        print("\n出错了：\n" + detail, flush=True)
        syslog("错", f"程序异常退出：{type(exc).__name__}: {str(exc)[:120]}")
        try:
            (HERE / "last-crash.txt").write_text(
                f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n{detail}", encoding="utf-8")
        except Exception:
            pass
        speak("我出了点问题，正在重启")
        time.sleep(2)
        raise SystemExit(3)
    finally:
        status.set("offline", hint="语音程序已退出")
        if overlay is not None:
            try:
                overlay.terminate()
            except Exception:
                pass
        if tracker is not None:
            try:
                stop_track.set()
            except NameError:
                pass
        stream.stop()
        stream.close()


if __name__ == "__main__":
    raise SystemExit(main())
