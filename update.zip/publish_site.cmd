@echo off
rem ASCII ONLY content: cmd.exe reads .cmd in the ANSI codepage; Chinese here would break it.
rem Usage: double-click to publish the download page to the website.
setlocal EnableExtensions
title Voice Assistant - Publish Download Site
chcp 65001 >nul
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

set "PYW=%APP%\.venv\Scripts\pythonw.exe"
set "PY=%APP%\.venv\Scripts\python.exe"

if exist "%PYW%" (
    start "" /min "%PYW%" "%APP%\publish_site.py"
    exit /b 0
)
if exist "%PY%" (
    start "" /min "%PY%" "%APP%\publish_site.py"
    exit /b 0
)
echo.
echo   Python not found in .venv - run the installer first.
echo.
pause
