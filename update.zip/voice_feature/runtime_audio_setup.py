"""Device, transcriber and recorder assembly for the voice runtime.

``main()`` should receive a ready audio session instead of owning every
microphone, hotword, wake-level and recorder ordering decision.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AudioRuntimeDependencies:
    """Bound services used while opening the runtime audio path."""

    resolve_device: Callable[[Any], Any]
    open_stream: Callable[[Any], tuple[Any, int]]
    input_name: Callable[[Any], str]
    make_transcriber: Callable[..., Any]
    wake_params: Callable[[Mapping], tuple[str, Mapping]]
    wake_description: Callable[[Mapping], str]
    make_recorder: Callable[..., Any]
    emit: Callable[[str], object] = print


@dataclass(frozen=True)
class AudioRuntimeSession:
    """The complete audio state consumed by the running voice loop."""

    device: Any
    stream: Any
    rate: int
    input_name: str
    transcriber: Any
    mode: str
    silence: float
    level_name: str
    level: Mapping
    wake_words: list[str]
    cancel_words: list[str]
    min_voiced: float
    recorder: Any


def prepare_audio_runtime(
    args: Any,
    cfg: Mapping,
    profile: str,
    hardware: Mapping,
    dependencies: AudioRuntimeDependencies,
) -> AudioRuntimeSession:
    """Open and describe one deterministic audio session.

    ``SystemExit`` from device discovery or stream opening is intentionally
    propagated so the existing device-list fallback remains unchanged.
    """
    deps = dependencies
    device = None if args.default_input else deps.resolve_device(args.input)
    stream, rate = deps.open_stream(device)
    input_name = deps.input_name(device)
    deps.emit(f"麦克风：{input_name}  @{rate}Hz")

    # Wake and cancel words are also recognizer hotwords, reducing homophone
    # rewrites before the normal command dispatcher sees the transcript.
    hotwords = " ".join(
        word for word in (args.wake_word or "", args.cancel_word or "") if word
    )
    transcriber = deps.make_transcriber(
        args.model,
        args.device,
        args.compute_type,
        args.lang,
        hotwords=hotwords,
    )
    deps.emit(
        f"识别引擎就绪：{args.model} / {transcriber.device} / "
        f"{transcriber.compute_type}"
    )
    if transcriber.device != "cuda":
        transcriber.beam = 1
        deps.emit("（CPU 模式：已切到贪心解码，速度优先）")
    if profile == "lite":
        deps.emit(f"这台机器按低配跑：{hardware['why']}")
    if transcriber.hotwords:
        deps.emit(f"热词：{transcriber.hotwords}")
    deps.emit(f"文字会写进 {args.out}，同时复制到剪贴板。Ctrl+C 退出。")

    mode = "enter" if args.ptt else args.mode
    silence = (
        args.silence
        if args.silence is not None
        else (1.0 if mode == "talk" else 0.8)
    )
    level_name, level = deps.wake_params(cfg)
    wake_words = [
        word for word in (args.wake_word or "").split(",") if word.strip()
    ]
    cancel_words = [
        word for word in (args.cancel_word or "").split(",") if word.strip()
    ]
    if mode == "talk" and args.immediate:
        wake_words = []

    # Without a wake word, an accidental background phrase is more costly, so
    # immediate talk always uses the stricter voice gate.
    min_voiced = (
        0.62
        if (mode == "talk" and not wake_words)
        else level["min_voiced"]
    )
    recorder = deps.make_recorder(
        stream,
        rate,
        silence,
        args.max_seconds,
        min_voiced=min_voiced,
        noise_mult=level["noise_mult"],
        confirm=level["confirm"],
        device=device,
    )
    deps.emit(
        f"唤醒档位：{level_name}（{deps.wake_description(level)}）"
    )
    return AudioRuntimeSession(
        device=device,
        stream=stream,
        rate=rate,
        input_name=input_name,
        transcriber=transcriber,
        mode=mode,
        silence=silence,
        level_name=level_name,
        level=level,
        wake_words=wake_words,
        cancel_words=cancel_words,
        min_voiced=min_voiced,
        recorder=recorder,
    )
