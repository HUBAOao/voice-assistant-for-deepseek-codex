# -*- coding: utf-8 -*-
"""Assemble the final foreground lifecycle outside the voice entrypoint."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.runtime_capture_setup import (
    CaptureRuntimeDependencies,
    prepare_capture_runtime,
)
from voice_feature.runtime_microphone_setup import (
    MicrophoneRuntimeDependencies,
    prepare_microphone_runtime,
)
from voice_feature.runtime_run_assembly import (
    RuntimeRunDependencies,
    run_voice_runtime,
)
from voice_feature.runtime_workers import register_shutdown_resources


@dataclass(frozen=True)
class ForegroundRuntimeDependencies:
    """Values and callbacks consumed once the interaction closure is ready."""

    mode: str
    args: Any
    tracker: Any
    wake_words: list[str]
    cancel_words: list[str]
    silence: float
    runtime_lifecycle: Any
    instance_guard: Any
    pause: dict
    set_paused: Callable[[bool, str], object]
    runtime_tick: Callable[[], bool]
    remote: Any
    handle_lock: Any
    handle_audio: Callable[..., bool]
    status: Any
    cfg: dict
    self_speech: dict
    music: dict
    spoken_flag: dict
    stream: Any
    recorder: Any
    device: Any
    rate: int
    level: Mapping
    resolve_device: Callable[[Any], Any]
    open_stream: Callable[[Any], tuple[Any, int]]
    make_recorder: Callable[..., Any]
    find_window: Callable[[str], tuple[int, str]]
    paste_text: Callable[..., None]
    record_ptt: Callable[[Any], Any]
    has_utterance: Callable[[Any, int], bool]
    level_state: Callable[[float], str]
    on_hold_start: Callable[[], None]
    on_hold_stop: Callable[[], None]
    on_speech: Callable[[], None]
    before_fallback_capture: Callable[[], None]
    syslog: Callable[[str, str], object]
    shut_up: Callable[[], object]
    speaking_now: Callable[[], bool]
    duplex: dict
    cancel_reference_echo: Callable[[Any, int], Any]
    spectrum_bands: Callable[..., list[float]]
    transcriber: Any
    hint: str
    key_watcher_factory: Callable[[str], Any]
    tracker_worker_factory: Callable[[Any], Any]
    start_scheduler: Callable[[Callable[[], int], Callable[[str, int], None]], object]
    build_greeting: Callable[[dict, str], str]
    speak_greeting: Callable[[str, float], object]
    speak: Callable[[str], object]
    emit: Callable[[str], object]
    crash_file: Path
    overlay_process: Any
    phone_server: Any
    on_microphone_ready: Callable[[Any], object] | None = None


def assemble_foreground_runtime(deps: ForegroundRuntimeDependencies) -> int:
    """Run greeting, workers, capture and the foreground loop in legacy order."""
    if deps.cfg.get("greeting_enabled", True) and not deps.args.no_greeting:
        greeting = deps.build_greeting(
            deps.cfg,
            deps.wake_words[0] if deps.wake_words else "",
        )
        if greeting:
            deps.speak_greeting(
                greeting,
                float(deps.cfg.get("greeting_delay") or 3.0),
            )

    def scheduler_target() -> int:
        if deps.args.target:
            hwnd, _title = deps.find_window(deps.args.target)
            return hwnd
        return deps.tracker.hwnd if deps.tracker else 0

    def scheduler_paste(text: str, hwnd: int) -> None:
        deps.paste_text(text, hwnd, press_enter=True, clear_first=True)

    deps.start_scheduler(scheduler_target, scheduler_paste)

    def microphone_reconnected(attempt: int) -> None:
        deps.emit(f"🎤 接回来了（第 {attempt} 次尝试）")
        deps.syslog("检", "麦克风已重连")
        deps.speak("麦克风接回来了")
        deps.status.set("idle" if deps.wake_words else "listening")

    microphone_runtime = prepare_microphone_runtime(
        stream=deps.stream,
        rate=deps.rate,
        recorder=deps.recorder,
        device=deps.device,
        dependencies=MicrophoneRuntimeDependencies(
            resolve_device=deps.resolve_device,
            open_stream=deps.open_stream,
            make_recorder=deps.make_recorder,
            default_input=bool(deps.args.default_input),
            input_value=deps.args.input,
            silence=deps.silence,
            max_seconds=deps.args.max_seconds,
            mode=deps.mode,
            wake_enabled=bool(deps.wake_words),
            level=deps.level,
            on_reconnecting=lambda: (
                deps.emit("🎤 麦克风掉线了，正在重连…"),
                deps.syslog("检", "麦克风掉线，正在重连"),
            ),
            on_reconnected=microphone_reconnected,
            on_failed=lambda: deps.emit("🎤 还是连不上，过一会儿再试"),
            on_interrupted=lambda: deps.emit("🎤 麦克风好像不在了，准备重连"),
        ),
    )
    mic_recovery = microphone_runtime.recovery
    if deps.on_microphone_ready is not None:
        deps.on_microphone_ready(mic_recovery)

    capture_runtime = prepare_capture_runtime(
        CaptureRuntimeDependencies(
            mode=deps.mode,
            args=deps.args,
            tracker=deps.tracker,
            wake_words=deps.wake_words,
            cancel_words=deps.cancel_words,
            silence=deps.silence,
            runtime_lifecycle=deps.runtime_lifecycle,
            pause=deps.pause,
            set_paused=deps.set_paused,
            runtime_tick=deps.runtime_tick,
            remote=deps.remote,
            handle_lock=deps.handle_lock,
            handle_audio=deps.handle_audio,
            status=deps.status,
            microphone=mic_recovery,
            key_watcher_factory=deps.key_watcher_factory,
            tracker_worker_factory=deps.tracker_worker_factory,
            find_window=deps.find_window,
            record_ptt=deps.record_ptt,
            has_utterance=deps.has_utterance,
            on_level=lambda value: deps.status.level(
                value,
                deps.level_state(value),
                text="",
            ),
            on_hold_start=deps.on_hold_start,
            on_hold_stop=deps.on_hold_stop,
            on_speech=deps.on_speech,
            before_fallback_capture=deps.before_fallback_capture,
            cfg=deps.cfg,
            self_speech=deps.self_speech,
            music=deps.music,
            spoken_flag=deps.spoken_flag,
            syslog=deps.syslog,
            shut_up=deps.shut_up,
            speaking_now=deps.speaking_now,
            duplex=deps.duplex,
            cancel_reference_echo=deps.cancel_reference_echo,
            spectrum_bands=deps.spectrum_bands,
            transcriber=deps.transcriber,
            hint=deps.hint,
        )
    )
    register_shutdown_resources(
        deps.runtime_lifecycle,
        microphone=lambda: mic_recovery.stream,
        tracker_worker=capture_runtime.tracker_worker,
        overlay_process=deps.overlay_process,
        phone_server=deps.phone_server,
    )
    return run_voice_runtime(
        RuntimeRunDependencies(
            audio_loop=capture_runtime.audio_loop,
            runtime_lifecycle=deps.runtime_lifecycle,
            instance_guard=deps.instance_guard,
            status=deps.status,
            syslog=deps.syslog,
            speak=deps.speak,
            crash_file=deps.crash_file,
            microphone_stream=lambda: mic_recovery.stream,
            tracker_worker=capture_runtime.tracker_worker,
            overlay_process=deps.overlay_process,
            phone_server=deps.phone_server,
            emit=deps.emit,
        )
    )
