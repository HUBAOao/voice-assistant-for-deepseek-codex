# -*- coding: utf-8 -*-
"""Assemble the ordered local-command pipeline outside the STT entrypoint."""
from __future__ import annotations

import json
import subprocess
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import memory_archive
from voice_feature import personal_commands
from voice_feature.control_commands import dispatch_control_command
from voice_feature.feature_commands import (
    dispatch_game_command,
    dispatch_note_command,
    dispatch_reminder_command,
    dispatch_utility_command,
)
from voice_feature.local_command_orchestrator import (
    LocalCommandStage,
    dispatch_local_command_stages,
)
from voice_feature.local_commands import dispatch_screen_command
from voice_feature.maintenance_commands import dispatch_maintenance_command
from voice_feature.parsing import (
    _QUERY_LEDGER,
    _QUERY_NOTE,
    cn_number,
    parse_brief,
    parse_calc,
    parse_convert,
    parse_focus,
    parse_game,
    parse_ledger,
    parse_media,
    parse_note,
    parse_open,
    parse_reminder,
    parse_search,
    parse_transform,
)
from voice_feature.tutorial_commands import dispatch_tutorial_command


@dataclass(frozen=True)
class LocalCommandDependencies:
    """Live state and callbacks consumed by one local-command pass."""

    config: dict
    config_file: Path
    local_text: str
    plain_text: str
    text_to_send: str
    tutorial: dict
    tutorial_document: Path
    memory_file: Path
    last_sent: dict
    music: dict
    busy: dict
    voiceprint: dict
    private: dict
    target: str | None
    tracker: Any
    from_phone: bool
    once: bool
    speak: Callable[..., Any]
    status: Any
    syslog: Callable[[str, str], Any]
    emit: Callable[..., Any]
    load_config: Callable[[], dict]
    arm_followup: Callable[[], Any]
    beep: Callable[..., Any]
    run_shortcut: Callable[[str, dict], str | None]
    parse_repeat: Callable[[str], bool]
    syslog_search: Callable[[list[str], int], list[str]]
    weekly_report: Callable[[], str]
    find_window: Callable[[str], tuple[int, str]]
    press_key: Callable[..., Any]
    open_named: Callable[[str], str | None]
    paste_clipboard: Callable[..., Any]
    grab_screen: Callable[..., Any]
    get_reply_reader: Callable[[], Any]
    focus_active: Callable[[], bool]
    focus_left: Callable[[], float]
    focus_start: Callable[[int], Any]
    focus_stop: Callable[[], Any]
    transform: Callable[[], Any]
    brief_now: Callable[[], Any]
    say_diary: Callable[[], Any]
    tutorial_say: Callable[[int], Any]
    game_feed: Callable[[str], bool]
    game_start: Callable[[str, str], Any]
    say_ledger: Callable[[], Any]
    say_notes: Callable[[], Any]
    add_ledger: Callable[[str, float], Any]
    add_note: Callable[[str], Any]
    clear_all_data: Callable[[], int]
    undo_last: Callable[[], Any]
    do_export: Callable[[], Any]
    do_import: Callable[[], Any]
    do_update: Callable[[], Any]
    apply_update_now: Callable[[], Any]
    diag_pack: Callable[[], Any]
    self_check: Callable[..., list[str]]
    train_wake_voice: Callable[[], Any]
    set_config: Callable[[str, Any], Any]
    schedule_restart: Callable[[], Any]
    read_selected: Callable[[], Any]
    start_reminder: Callable[..., Any]


@dataclass(frozen=True)
class LocalCommandAssemblyOutcome:
    handled: bool
    terminate: bool
    text_to_send: str
    stage: str = ""


def dispatch_local_commands(
    deps: LocalCommandDependencies,
) -> LocalCommandAssemblyOutcome:
    """Run one command through the legacy ordered stages.

    The caller owns transcription, wake-word handling and message delivery.
    This assembly only consumes a validated short command and may replace
    ``text_to_send`` for the historical repeat command.
    """
    text_to_send = deps.text_to_send
    local_text = deps.local_text
    plain_text = deps.plain_text

    def done() -> bool:
        deps.arm_followup()
        time.sleep(0.4)
        return bool(deps.once)

    def current_conversation() -> str:
        try:
            import codex_threads

            return codex_threads.current_name()
        except Exception:
            return ""

    def shortcut_stage() -> bool | None:
        hit = deps.run_shortcut(local_text, deps.config)
        if not hit:
            return None
        deps.emit(f"   ↳ ⚡ 快捷指令已执行：{hit}")
        deps.status.set("sent", text=f"⚡ {hit}")
        deps.beep(980, 80)
        deps.arm_followup()
        time.sleep(0.6)
        return bool(deps.once)

    def focus_stage() -> bool | None:
        minutes = parse_focus(local_text)
        if minutes is None:
            return None
        if minutes == -1:
            deps.focus_stop()
        elif minutes == 0:
            if deps.focus_active():
                left = deps.focus_left()
                deps.speak(f"还剩 {int(left // 60)} 分 {int(left % 60)} 秒")
            else:
                deps.speak("现在没在专注哦")
        else:
            deps.focus_start(minutes)
        return done()

    def transform_stage() -> bool | None:
        if not parse_transform(local_text):
            return None
        deps.transform()
        return done()

    def brief_stage() -> bool | None:
        if not parse_brief(local_text):
            return None
        deps.brief_now()
        return done()

    def sound_mode_stage() -> bool | None:
        if "音浪" not in plain_text and "频谱" not in plain_text:
            return None
        want = not any(
            word in plain_text for word in ("关", "停", "不要", "退出")
        )
        fresh = deps.load_config()
        fresh["wave_spectrum"] = want
        try:
            deps.config_file.write_text(
                json.dumps(fresh, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass
        deps.config["wave_spectrum"] = want
        deps.music["on"] = want
        deps.speak("音浪开了，放点音乐吧" if want else "音浪关了")
        deps.emit(f"   ↳ 🎚 音浪：{'开' if want else '关'}")
        deps.status.set("sent", text=f"🎚 音浪{'开' if want else '关'}")
        return done()

    def diary_stage() -> bool | None:
        if not any(
            word in plain_text
            for word in ("日记", "今天我说了什么", "今天总结")
        ):
            return None
        deps.say_diary()
        return done()

    def repeat_stage() -> bool | None:
        nonlocal text_to_send
        if not deps.parse_repeat(local_text):
            return None
        if deps.last_sent["text"] and time.time() - deps.last_sent["at"] < 600:
            deps.speak("好，再来一次")
            deps.emit(f"   ↳ 🔁 重发：{deps.last_sent['text'][:40]}")
            text_to_send = deps.last_sent["text"]
            return None
        deps.speak("我还不知道要重复哪一句")
        return done()

    def archive_stage() -> bool | None:
        archive_cmd = memory_archive.parse_command(local_text)
        if archive_cmd == "view":
            ok, msg = memory_archive.open_archive()
            deps.speak(msg)
            deps.syslog("档", msg)
            deps.emit(f"   ↳ 📚 {msg}")
            deps.status.set("sent" if ok else "idle", text="📚 记忆归档")
            return done()
        if archive_cmd != "build":
            return None
        deps.speak("好，正在把所有对话的记忆归档，几秒就好")
        deps.syslog("档", "开始集中记忆归档")
        deps.status.set("thinking", text="正在集中记忆归档…")

        def archive_job() -> None:
            try:
                info = memory_archive.build_archive()
                answer = memory_archive.describe(info)
            except Exception as exc:  # noqa: BLE001
                answer = f"归档没成功：{exc}"
            deps.speak(answer)
            deps.syslog("档", answer)
            deps.emit(f"   ↳ 📚 {answer}")
            deps.status.set("sent", text="📚 记忆已归档")

        threading.Thread(target=archive_job, daemon=True).start()
        return done()

    def search_stage() -> bool | None:
        want = parse_search(local_text)
        if not want:
            return None
        hits = deps.syslog_search([want], 5)
        if not hits:
            hits = (
                list(deps.syslog_search([want[:2]], 5))
                if len(want) >= 2
                else []
            )
        if hits:
            deps.speak(
                f"找到 {len(hits)} 条，最近的是："
                + "；".join(
                    hit.split("] ", 1)[-1][:30] for hit in hits[:3]
                )
            )
        else:
            deps.speak(f"日志里没找到关于{want}的内容")
        deps.emit(f"   ↳ 🔎 搜日志 {want} → {len(hits)} 条")
        deps.syslog("查", f"搜日志：{want}（{len(hits)} 条）")
        deps.status.set("sent", text=f"🔎 {want}：{len(hits)} 条")
        return done()

    def weekly_stage() -> bool | None:
        if not any(
            word in plain_text
            for word in ("周报", "这周怎么样", "这周总结", "本周总结")
        ):
            return None
        report = deps.weekly_report()
        deps.speak(report)
        deps.syslog("报", report)
        deps.emit(f"   ↳ 📊 周报：{report[:60]}")
        deps.status.set("sent", text="📊 周报已生成")
        return done()

    stages = [
        LocalCommandStage("shortcut", shortcut_stage),
        LocalCommandStage(
            "game",
            lambda: dispatch_game_command(
                local_text,
                game_feed=deps.game_feed,
                parse_game=parse_game,
                game_start=deps.game_start,
                done=done,
            ),
        ),
        LocalCommandStage("focus", focus_stage),
        LocalCommandStage(
            "note",
            lambda: dispatch_note_command(
                local_text,
                query_ledger=_QUERY_LEDGER,
                query_note=_QUERY_NOTE,
                parse_ledger=parse_ledger,
                parse_note=parse_note,
                say_ledger=deps.say_ledger,
                say_notes=deps.say_notes,
                add_ledger=deps.add_ledger,
                add_note=deps.add_note,
                beep=lambda: deps.beep(880, 70),
                done=done,
            ),
        ),
        LocalCommandStage("transform", transform_stage),
        LocalCommandStage("brief", brief_stage),
        LocalCommandStage(
            "utility",
            lambda: dispatch_utility_command(
                local_text,
                parse_calc=parse_calc,
                parse_convert=parse_convert,
                parse_media=parse_media,
                parse_open=parse_open,
                speak=deps.speak,
                status=deps.status,
                beep=lambda: deps.beep(980, 60),
                press_key=deps.press_key,
                open_named=deps.open_named,
                done=done,
            ),
        ),
        LocalCommandStage("sound_mode", sound_mode_stage),
        LocalCommandStage("diary", diary_stage),
        LocalCommandStage("repeat", repeat_stage),
        LocalCommandStage(
            "screen",
            lambda: dispatch_screen_command(
                local_text,
                cfg=deps.config,
                speak=deps.speak,
                done=done,
                syslog=deps.syslog,
                status=deps.status,
                busy=deps.busy,
                resolve_target=lambda: (
                    deps.find_window(deps.target or "")
                    if deps.target
                    else (
                        deps.tracker.hwnd if deps.tracker else 0,
                        "",
                    )
                ),
                paste_clipboard=deps.paste_clipboard,
                grab_screen=deps.grab_screen,
                reply_reader=deps.get_reply_reader(),
                current_conversation=current_conversation,
                from_phone=deps.from_phone,
            ),
        ),
        LocalCommandStage("archive", archive_stage),
        LocalCommandStage(
            "memory",
            lambda: personal_commands.dispatch_memory_command(
                local_text,
                text_to_send,
                memory_file=deps.memory_file,
                speak=deps.speak,
                syslog=deps.syslog,
                status=deps.status,
                print_line=deps.emit,
                beep=lambda: deps.beep(980, 70),
                done=done,
            ),
        ),
        LocalCommandStage("search", search_stage),
        LocalCommandStage("weekly", weekly_stage),
        LocalCommandStage(
            "tutorial",
            lambda: dispatch_tutorial_command(
                plain_text=plain_text,
                tutorial=deps.tutorial,
                document=deps.tutorial_document,
                speak=deps.speak,
                say=deps.tutorial_say,
                syslog=deps.syslog,
                status=deps.status,
                done=done,
                open_document=lambda doc: subprocess.Popen(
                    f'explorer /select,"{doc}"', shell=True
                ),
                parse_number=cn_number,
            ),
        ),
        LocalCommandStage(
            "maintenance",
            lambda: dispatch_maintenance_command(
                plain_text,
                cfg=deps.config,
                private=deps.private,
                speak=deps.speak,
                syslog=deps.syslog,
                status=deps.status,
                done=done,
                clear_all_data=deps.clear_all_data,
                undo_last=deps.undo_last,
                do_export=deps.do_export,
                do_import=deps.do_import,
                do_update=deps.do_update,
                apply_update_now=deps.apply_update_now,
                diag_pack=deps.diag_pack,
                self_check=deps.self_check,
                log=deps.emit,
            ),
        ),
        LocalCommandStage(
            "weather",
            lambda: personal_commands.dispatch_weather_command(
                plain_text,
                cfg=deps.config,
                save_config=lambda data: deps.config_file.write_text(
                    json.dumps(data, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                ),
                speak=deps.speak,
                syslog=deps.syslog,
                status=deps.status,
                done=done,
                fetch_weather=lambda city: personal_commands.weather_line(city),
            ),
        ),
        LocalCommandStage(
            "voiceprint",
            lambda: personal_commands.dispatch_voiceprint_command(
                plain_text,
                voiceprint_state=deps.voiceprint,
                train_wake_voice=deps.train_wake_voice,
                speak=deps.speak,
                print_line=deps.emit,
                done=done,
            ),
        ),
        LocalCommandStage(
            "control",
            lambda: dispatch_control_command(
                plain_text,
                set_config=deps.set_config,
                speak=deps.speak,
                schedule_restart=deps.schedule_restart,
                read_selected=deps.read_selected,
                done=done,
            ),
        ),
        LocalCommandStage(
            "reminder",
            lambda: dispatch_reminder_command(
                local_text,
                enabled=bool(deps.config.get("reminders_enabled", True)),
                parse_reminder=parse_reminder,
                start_reminder=deps.start_reminder,
                paste_to_window=bool(deps.config.get("reminder_paste")),
                target_hwnd=deps.tracker.hwnd if deps.tracker else 0,
                speak=deps.speak,
                status=deps.status,
                beep=lambda: deps.beep(880, 80),
                arm_followup=deps.arm_followup,
                once=deps.once,
            ),
        ),
    ]
    result = dispatch_local_command_stages(stages)
    return LocalCommandAssemblyOutcome(
        handled=result.handled,
        terminate=result.terminate,
        text_to_send=text_to_send,
        stage=result.stage,
    )
