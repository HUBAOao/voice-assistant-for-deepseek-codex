# -*- coding: utf-8 -*-
"""Fact memory, weather and voiceprint commands for the STT loop.

The microphone loop in ``stt.py`` owns wake-word state and the UI.  This module
owns the persistent personal data and decides whether a standalone short
command was handled, while keeping the legacy wording unchanged.
"""
from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np


REMEMBER_HEADS = ("记住", "记牢", "帮我记住", "你要记住")
ASK_HEADS = ("你还记得", "记得我", "我说过", "我告诉过你", "我跟你说的")


def memory_all(path: Path) -> list[dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def memory_add(path: Path, text: str) -> bool:
    rows = memory_all(path)
    body = (text or "").strip()
    if not body:
        return False
    rows.append({
        "ts": time.time(),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "text": body,
    })
    try:
        path.write_text(
            json.dumps(rows, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return True
    except Exception:
        return False


def _shingles(text: str) -> set[str]:
    clean = re.sub(
        r"[\s，,。.！!？?、的了我你他她它是]|什么|哪|谁|多少|吗|呢",
        "",
        text or "",
    )
    return {clean[i:i + 2] for i in range(max(1, len(clean) - 1))} or {clean}


def memory_find(path: Path, query: str, limit: int = 3) -> list[dict]:
    """Find the closest fact memories by two-character overlap."""
    query_shingles = _shingles(query)
    scored: list[tuple[float, dict]] = []
    for row in memory_all(path):
        row_shingles = _shingles(str(row.get("text", "")))
        if not row_shingles:
            continue
        hit = len(query_shingles & row_shingles)
        if hit < min(2, len(query_shingles)):
            continue
        score = hit / max(1, len(query_shingles))
        if score > 0.2:
            scored.append((score, row))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [row for _score, row in scored[:limit]]


def parse_remember(text: str) -> str | None:
    """Turn ``记住我喜欢喝美式`` into ``我喜欢喝美式``."""
    plain = (text or "").strip("。，,.！! ")
    for head in REMEMBER_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1].strip("。，,.！!：: ")
            body = re.sub(r"^[一下个点把]+", "", body).strip()
            return body or None
    return None


def parse_ask_memory(text: str) -> bool:
    plain = (text or "").replace(" ", "")
    if any(head in plain for head in ASK_HEADS):
        return True
    return plain.endswith(("吗", "？", "?")) and any(
        word in plain
        for word in ("我喜欢", "我住", "我叫", "我的", "我生日", "我讨厌")
    )


def _mel_matrix(sr: int, n_fft: int, n_mels: int = 24) -> np.ndarray:
    def hz_to_mel(freq: float) -> float:
        return 2595.0 * np.log10(1.0 + freq / 700.0)

    def mel_to_hz(mel: float) -> float:
        return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)

    points = mel_to_hz(
        np.linspace(
            hz_to_mel(80),
            hz_to_mel(min(7000, sr / 2 - 100)),
            n_mels + 2,
        )
    )
    bins = np.floor(points / (sr / 2) * (n_fft / 2 + 1)).astype(int)
    matrix = np.zeros((n_mels, n_fft // 2 + 1), dtype=np.float32)
    for index in range(n_mels):
        low, middle, high = bins[index], bins[index + 1], bins[index + 2]
        if not low < middle < high:
            continue
        matrix[index, low:middle] = np.linspace(
            0, 1, middle - low, endpoint=False
        )
        matrix[index, middle:high] = np.linspace(
            1, 0, high - middle, endpoint=False
        )
    return matrix


def voice_features(audio: np.ndarray, sr: int) -> list[float] | None:
    """Build the coarse 24-band normalized voice fingerprint."""
    step, window_size = int(sr * 0.02), int(sr * 0.03)
    frames = []
    for start in range(0, max(1, audio.size - window_size), step):
        segment = audio[start:start + window_size]
        if segment.size < window_size:
            break
        if float(np.sqrt(np.mean(segment ** 2))) < 0.01:
            continue
        frames.append(segment * np.hanning(window_size))
    if len(frames) < 8:
        return None
    spectrum = np.abs(np.fft.rfft(np.stack(frames), n=512, axis=1))
    logmel = np.log(_mel_matrix(sr, 512) @ spectrum.T + 1e-6)
    vector = np.concatenate([logmel.mean(axis=1), logmel.std(axis=1)])
    vector = vector - vector.mean()
    return [
        float(value)
        for value in vector / (float(np.linalg.norm(vector)) or 1.0)
    ]


def voice_enroll(audio: np.ndarray, sr: int, path: Path) -> bool:
    feature = voice_features(audio, sr)
    if not feature:
        return False
    try:
        path.write_text(
            json.dumps({"ts": time.time(), "feat": feature}),
            encoding="utf-8",
        )
        return True
    except Exception:
        return False


def voice_score(audio: np.ndarray, sr: int, path: Path) -> float | None:
    """Compare audio with the enrolled voiceprint; return None if unavailable."""
    try:
        reference = json.loads(path.read_text(encoding="utf-8")).get("feat")
    except Exception:
        return None
    feature = voice_features(audio, sr)
    if not reference or not feature:
        return None
    return float(np.dot(np.array(reference), np.array(feature)))


def background_noise(
    text: str,
    last_score: float | None,
    wake_score: float | None,
    gate_on: bool,
    min_score: float | None = None,
) -> bool:
    """Decide whether a transcript should be discarded as background speech."""
    if not gate_on or last_score is None:
        return False
    plain = re.sub(r"[\s，,。.！!？?]", "", text or "")
    very_low = 0.22 if min_score is None else float(min_score)
    # A confirmed wake voiceprint is the strongest evidence that this is the
    # enrolled speaker. It must win over the noisier sentence-level score.
    if wake_score is not None and wake_score >= 0.45:
        return False
    # Long transcripts are costly to lose and are unlikely Whisper filler.
    # Only use the sentence-level voiceprint score to reject short utterances.
    if len(plain) >= 12:
        return False
    if last_score < very_low and len(plain) <= 8:
        return True
    return last_score < 0.42 and len(plain) <= 8


def weather_line(
    city: str,
    *,
    timeout: float = 6.0,
    opener: Callable[..., Any] | None = None,
) -> str:
    """Fetch a short current-weather line from wttr.in."""
    try:
        where = urllib.parse.quote(str(city or "").strip())
        url = f"https://wttr.in/{where}?format=%l:+%C+%t+%f&lang=zh"
        request = urllib.request.Request(
            url, headers={"User-Agent": "curl/8"}
        )
        open_url = opener or urllib.request.urlopen
        with open_url(request, timeout=timeout) as response:
            got = response.read().decode("utf-8", "replace").strip()
        return got if got and len(got) < 60 else ""
    except Exception:
        return ""


def dispatch_memory_command(
    command: str,
    full_text: str,
    *,
    memory_file: Path,
    speak: Callable[[str], Any],
    syslog: Callable[[str, str], Any],
    status: Any,
    print_line: Callable[[str], Any],
    beep: Callable[[], Any],
    done: Callable[[], bool],
) -> bool | None:
    body = parse_remember(command)
    if body:
        memory_add(memory_file, body)
        speak(f"记住了：{body}")
        syslog("记", f"事实记忆：{body}")
        print_line(f"   ↳ 🧠 记住：{body}")
        status.set("sent", text=f"🧠 {body}")
        beep()
        return done()
    if parse_ask_memory(command):
        rows = memory_find(memory_file, full_text)
        answer = (
            "我记得：" + "；".join(str(row["text"]) for row in rows)
            if rows
            else "这个我还真没记住"
        )
        speak(answer)
        syslog("忆", answer)
        print_line(f"   ↳ 🧠 {answer}")
        status.set("sent", text=f"🧠 {answer[:40]}")
        return done()
    return None


def dispatch_weather_command(
    command: str,
    *,
    cfg: dict,
    save_config: Callable[[dict], Any],
    speak: Callable[[str], Any],
    syslog: Callable[[str, str], Any],
    status: Any,
    done: Callable[[], bool],
    fetch_weather: Callable[[str], str] | None = None,
) -> bool | None:
    city_match = re.search(
        r"(?:天气城市|以后天气|查天气的?城市)"
        r"(?:设成|改成|定为|是|改成)?\s*([\u4e00-\u9fff]{2,8})",
        command,
    )
    if city_match:
        city = city_match.group(1)
        fresh = dict(cfg)
        fresh["weather_city"] = city
        save_config(fresh)
        cfg["weather_city"] = city
        speak(f"好，以后天气查{city}")
        syslog("设", f"天气城市 → {city}")
        return done()
    if any(
        word in command
        for word in ("今天天气", "天气怎么样", "查天气", "天气如何")
    ):
        getter = fetch_weather or (
            lambda value: weather_line(value)
        )
        line = getter(str(cfg.get("weather_city") or "").strip())
        speak(line or "天气没查到，可能是网络问题")
        syslog("报", f"天气：{line or '没查到'}")
        status.set(
            "sent", text=f"🌤 {line[:30]}" if line else "🌤 没查到"
        )
        return done()
    return None


def dispatch_voiceprint_command(
    command: str,
    *,
    voiceprint_state: dict,
    train_wake_voice: Callable[[], Any],
    speak: Callable[[str], Any],
    print_line: Callable[[str], Any],
    done: Callable[[], bool],
) -> bool | None:
    if any(word in command for word in (
        "注册我的声音", "记住我的声音", "声纹注册",
    )):
        speak("你随便说一句话，我记住你的声音特征")
        print_line("   ↳ 🎙 声纹注册：等下一句话")
        voiceprint_state["enroll"] = True
        return done()
    if any(word in command for word in (
        "训练唤醒词", "唤醒词训练", "训练我的声音",
        "让唤醒词更准", "训练一下唤醒词",
    )):
        train_wake_voice()
        return done()
    return None
