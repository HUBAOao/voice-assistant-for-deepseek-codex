"""Keep wake-word admission outside the main utterance closure."""
from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class RuntimeWakeGateDependencies:
    wake_words: list[str]
    wake_level: Mapping[str, Any]
    cancel_words: list[str]
    listen_timeout: float
    talk_state: Any
    extract_word: Callable[..., tuple[str, str]]
    looks_like_wake: Callable[[str, list[str]], bool]
    cancel_hit: Callable[[str, list[str]], bool]
    wake_voice_ok: Callable[[Any], bool]
    beep: Callable[[int, int], Any]
    award: Callable[[str], Any]
    status: Any
    syslog: Callable[[str, str], Any]
    emit: Callable[[str], Any]
    sleep: Callable[[float], Any] = time.sleep


@dataclass(frozen=True)
class RuntimeWakeGateOutcome:
    """Only admitted utterances continue into local commands and delivery."""

    allowed: bool
    text: str = ""


class RuntimeWakeGateAssembly:
    """Apply wake, cancel and voiceprint decisions in their legacy order."""

    def __init__(self, deps: RuntimeWakeGateDependencies) -> None:
        self.deps = deps

    def evaluate(
        self,
        text: str,
        *,
        audio: Any = None,
        mood: str = "",
        from_phone: bool = False,
    ) -> RuntimeWakeGateOutcome:
        deps = self.deps
        if not deps.wake_words:
            deps.status.set_mood(mood)
            return RuntimeWakeGateOutcome(allowed=True, text=text)

        body, woke = deps.extract_word(
            text,
            deps.wake_words,
            fuzzy=deps.wake_level["fuzzy"],
            leading=deps.wake_level["leading"],
        )
        if from_phone:
            body, woke = text, True
        looks_wrong = bool(
            deps.wake_words
            and not woke
            and deps.looks_like_wake(text, deps.wake_words)
        )
        if looks_wrong:
            body, woke = "", True
            deps.syslog("听", f"（这句像唤醒词喊错了字：{text[:12]}）")
            deps.emit(f"   ↳ 🔔 这句像喊唤醒词（{text}），当唤醒处理")

        was_armed = deps.talk_state.is_armed()
        followup_echo = bool(
            was_armed
            and not woke
            and deps.looks_like_wake(text, deps.wake_words)
        )
        voice_ok = True
        if (
            not from_phone
            and audio is not None
            and (woke or was_armed)
            and not looks_wrong
            and not followup_echo
        ):
            voice_ok = deps.wake_voice_ok(audio)
        decision = deps.talk_state.decide(
            text,
            wake_enabled=True,
            woke=woke,
            body=body,
            cancel=deps.cancel_hit(body, deps.cancel_words),
            voice_ok=voice_ok,
            followup_echo=followup_echo,
        )

        action = decision.action
        if action == "cancel":
            deps.beep(440, 90)
            deps.emit("   ↳ 好，取消了")
            deps.syslog("撤", f"（取消）{text[:30]}")
            deps.status.set_mood("")
            deps.status.set("idle")
            return RuntimeWakeGateOutcome(allowed=False)

        if action == "send":
            deps.status.set_mood(mood)
            if woke:
                deps.award("wake")
            deps.status.set("thinking", text=decision.text)
            return RuntimeWakeGateOutcome(
                allowed=True,
                text=decision.text,
            )

        if action == "listen":
            deps.status.set_mood(mood)
            deps.award("wake")
            deps.beep(880, 70)
            deps.sleep(0.06)
            deps.beep(1320, 90)
            deps.emit(
                f"   ↳ 🔔 我在听，请说要问的（{deps.listen_timeout:g} 秒内有效）"
            )
            deps.status.set("listening", text="", hint="说吧，说完自动发出去")
            return RuntimeWakeGateOutcome(allowed=False)

        if action == "listen_again":
            deps.status.set_mood(mood)
            deps.emit(f"   ↳ 🔔 又听到像唤醒词的一句（{text}），继续听你说")
            deps.status.set("listening", text="", hint="说吧，说完自动发出去")
            return RuntimeWakeGateOutcome(allowed=False)

        if action == "ignore_voice":
            deps.status.set_mood("")
            detail = (
                "（声纹不像本人，忽略这次唤醒）"
                if woke
                else f"（免唤醒窗口里不像本人）{text[:30]}"
            )
            deps.syslog("噪", detail)
            if not woke:
                deps.status.set("idle", text=f"（忽略）{text}")
            return RuntimeWakeGateOutcome(allowed=False)

        deps.status.set_mood("")
        deps.emit(f"   ↳ （没听到「{deps.wake_words[0]}」，这句忽略）")
        deps.status.set("idle", text=f"（忽略）{text}")
        return RuntimeWakeGateOutcome(allowed=False)


__all__ = [
    "RuntimeWakeGateAssembly",
    "RuntimeWakeGateDependencies",
    "RuntimeWakeGateOutcome",
]
