"""Injectable foreground reminder scheduling for meetings, time and fatigue."""
from __future__ import annotations

import time
from collections.abc import Callable, MutableMapping
from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class ReminderRuntimeDependencies:
    config: MutableMapping[str, Any]
    ticker: MutableMapping[str, Any]
    hourly: MutableMapping[str, Any]
    sit: MutableMapping[str, Any]
    fatigue: MutableMapping[str, Any]
    mute_speak: MutableMapping[str, Any]
    in_meeting: Callable[[], bool]
    last_input_age: Callable[[], float]
    speak: Callable[[str], Any]
    syslog: Callable[[str, str], Any]
    status: Any
    now: Callable[[], datetime] = datetime.now
    clock: Callable[[], float] = time.time
    emit: Callable[[str], Any] = print


class ReminderRuntime:
    """Keep the historical one-second reminder order and throttle state."""

    def __init__(self, deps: ReminderRuntimeDependencies) -> None:
        self.deps = deps

    def run(self) -> None:
        """Check meeting mute, hourly chime, sitting and fatigue reminders."""
        deps = self.deps
        now_t = deps.clock()
        if now_t < deps.ticker["next"]:
            return
        deps.ticker["next"] = now_t + 1.0

        try:
            want = (
                deps.in_meeting()
                if deps.config.get("meeting_mute", True)
                else False
            )
        except Exception:
            want = False
        if want != deps.ticker["meeting"]:
            deps.ticker["meeting"] = want
            deps.mute_speak["on"] = want
            deps.emit(
                "\n   ↳ "
                + (
                    "🤫 检测到会议，只出字幕不出声"
                    if want
                    else "🔊 会议结束，恢复出声"
                )
            )
            deps.syslog("会", "进入会议模式" if want else "退出会议模式")
            deps.status.set(
                "sent", text=("🤫 开会中，只出字幕" if want else "🔊 恢复出声")
            )

        now = deps.now()
        if deps.config.get("hourly_chime", False):
            stamp = now.strftime("%Y-%m-%d %H")
            if stamp != deps.hourly["last"] and now.minute == 0:
                deps.hourly["last"] = stamp
                deps.speak(f"现在是 {now.hour} 点")

        if (
            deps.config.get("sit_reminder", True)
            and now_t >= deps.sit["next"]
        ):
            if deps.last_input_age() < 60:
                deps.sit["next"] = (
                    now_t
                    + max(10, int(deps.config.get("sit_minutes") or 60)) * 60
                )
                deps.speak("坐挺久了，起来动一动吧")
                deps.syslog("提", "久坐提醒")
                deps.emit("   ↳ 🪑 久坐提醒")
                deps.status.set("sent", text="🪑 起来动一动")
            else:
                deps.sit["next"] = now_t + 120

        if (
            deps.config.get("fatigue_reminder", True)
            and len(deps.fatigue["speeds"]) >= 8
        ):
            recent = deps.fatigue["speeds"][-3:]
            base = sorted(deps.fatigue["speeds"][:-3])
            mid = base[len(base) // 2]
            if (
                mid > 0
                and sum(recent) / len(recent) < mid * 0.7
                and now_t - deps.fatigue["last"] > 1800
            ):
                deps.fatigue["last"] = now_t
                deps.speak("听你说话好像有点累了，歇一会儿吧")
                deps.syslog("提", "疲劳提醒")
                deps.emit("   ↳ 😪 疲劳提醒")
                deps.status.set("sent", text="😪 歇一会儿吧")


def assemble_reminder_runtime(
    deps: ReminderRuntimeDependencies,
) -> ReminderRuntime:
    return ReminderRuntime(deps)
