"""Prepare mode-specific input handling and the audio loop."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from voice_feature.audio_loop import AudioLoop, AudioLoopDependencies


@dataclass(frozen=True)
class InputRuntimeDependencies:
    mode: str
    args: Any
    tracker: Any
    wake_words: list[str]
    cancel_words: list[str]
    silence: float
    runtime_lifecycle: Any
    pause: dict
    set_paused: Callable[[bool, str], None]
    runtime_tick: Callable[[], bool]
    remote: Any
    handle_lock: Any
    handle_audio: Callable[[Any], bool]
    status: Any
    microphone: Any
    key_watcher_factory: Callable[[str], Any]
    tracker_worker_factory: Callable[[Any], Any]
    find_window: Callable[[str], tuple[int, str]]
    record_ptt: Callable[[Any], Any]
    has_utterance: Callable[[Any, int], bool]
    on_level: Callable[[float], None]
    on_hold_start: Callable[[], None]
    on_hold_stop: Callable[[], None]
    on_speech: Callable[[], None]
    before_fallback_capture: Callable[[], None]
    capture_talk_factory: Callable[[Callable[[], bool]], Callable[[], Any]]
    emit: Callable[..., Any] = print


@dataclass(frozen=True)
class InputRuntimeResult:
    audio_loop: AudioLoop
    checked_pause: Callable[[], bool]
    tracker_worker: object | None
    pause_key: object | None


def prepare_input_runtime(deps: InputRuntimeDependencies) -> InputRuntimeResult:
    """Build the exact hold/talk/plain capture path used by the STT process."""
    key_down: Callable[[], bool] | None = None
    tracker_worker = None
    pause_key = None
    checked_pause: Callable[[], bool]

    if deps.mode == "hold":
        watcher = deps.key_watcher_factory(deps.args.key)
        deps.emit(
            f"按住 {deps.args.key} 说话，松开就识别；"
            "不用管窗口焦点。Ctrl+C 退出。"
        )
        key_down = watcher.down
        checked_pause = lambda: bool(deps.pause["paused"])
    elif deps.mode == "talk":
        deps.tracker.poll()
        pause_key = deps.key_watcher_factory(deps.args.pause_key)

        def checked_pause() -> bool:
            deps.runtime_tick()
            now = pause_key.down()
            if now and not deps.pause["prev"]:
                deps.set_paused(not deps.pause["paused"], "")
            deps.pause["prev"] = now
            return bool(deps.pause["paused"])

        tracker_worker = deps.tracker_worker_factory(deps.tracker)
        tracker_worker.start(deps.runtime_lifecycle)
        if deps.args.target:
            fixed_hwnd, fixed_title = deps.find_window(deps.args.target)
            if fixed_hwnd:
                target = f"{fixed_title}（固定）"
            else:
                target = (
                    f"⚠️ 找不到标题含「{deps.args.target}」的窗口，"
                    "改跟你上一个用过的窗口"
                )
        else:
            target = deps.tracker.title or "（还没记录到窗口，先点一下聊天窗口）"
        deps.emit(
            f"对话模式：直接说话，停下来约 {deps.silence:g} 秒"
            "就自动识别并发送。"
        )
        if deps.wake_words:
            deps.emit(
                f"唤醒词：「{deps.wake_words[0]}」。先说它，听到两声提示音后"
                "再说你要问的，说完自动发出去。"
            )
            deps.emit(
                f"也可以一口气说：「{deps.wake_words[0]}，"
                f"帮我查一下明天天气」。说「{deps.cancel_words[0]}」取消。"
            )
        else:
            deps.emit("发送规则：不用唤醒词，识别完立刻发送。")
        deps.emit(f"当前发送目标：{target}")
        deps.emit(
            f"按 {deps.args.pause_key.upper()} 暂停/继续；"
            "关掉这个窗口（或 Ctrl+C）就是退出。"
        )
    else:
        checked_pause = lambda: bool(deps.pause["paused"])

    capture_talk = deps.capture_talk_factory(checked_pause)
    audio_loop = AudioLoop(
        AudioLoopDependencies(
            microphone=deps.microphone,
            mode=deps.mode,
            handle_lock=deps.handle_lock,
            handle_audio=deps.handle_audio,
            remote_poll=lambda: (
                deps.remote.poll()
                if deps.mode == "hold"
                else deps.runtime_tick()
            ),
            paused=lambda: bool(deps.pause["paused"]),
            status=deps.status,
            key_down=key_down,
            pause_key=deps.args.key,
            record_ptt=deps.record_ptt,
            has_utterance=deps.has_utterance,
            on_level=deps.on_level,
            on_hold_start=deps.on_hold_start,
            on_hold_stop=deps.on_hold_stop,
            capture_talk=capture_talk,
            on_speech=deps.on_speech,
            before_fallback_capture=deps.before_fallback_capture,
            print_line=deps.emit,
        )
    )
    return InputRuntimeResult(audio_loop, checked_pause, tracker_worker, pause_key)
