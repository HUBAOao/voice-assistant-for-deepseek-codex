"""Assemble command/wake gates and the structured-action completion callback."""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from voice_feature.runtime_command_gate_assembly import (
    RuntimeCommandGateAssembly,
    RuntimeCommandGateDependencies,
)
from voice_feature.runtime_wake_gate_assembly import (
    RuntimeWakeGateAssembly,
    RuntimeWakeGateDependencies,
)


@dataclass(frozen=True)
class RuntimeGateAssemblyDependencies:
    command: RuntimeCommandGateDependencies
    wake: RuntimeWakeGateDependencies
    arm_followup: Callable[[], Any]
    once: bool
    sleep: Callable[[float], Any] = time.sleep


@dataclass(frozen=True)
class RuntimeGateRuntime:
    command_gate: RuntimeCommandGateAssembly
    wake_gate: RuntimeWakeGateAssembly
    finish_structured_action: Callable[[], bool]


def assemble_runtime_gates(
    deps: RuntimeGateAssemblyDependencies,
) -> RuntimeGateRuntime:
    """Build the two admission gates and preserve follow-up completion semantics."""
    command_gate = RuntimeCommandGateAssembly(deps.command)
    wake_gate = RuntimeWakeGateAssembly(deps.wake)

    def finish_structured_action() -> bool:
        deps.arm_followup()
        deps.sleep(0.4)
        return bool(deps.once)

    return RuntimeGateRuntime(
        command_gate=command_gate,
        wake_gate=wake_gate,
        finish_structured_action=finish_structured_action,
    )


__all__ = [
    "RuntimeGateAssemblyDependencies",
    "RuntimeGateRuntime",
    "assemble_runtime_gates",
]
