"""Own mutable state for one voice-session without starting the audio stack."""
from __future__ import annotations

import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Callable

from voice_feature.talk_state import DictationState, TalkState


@dataclass
class RuntimeSessionState:
    """State shared by desktop, phone, gates and the foreground loop."""

    spoken_flag: dict
    stop_words: list[str]
    self_speech: dict
    self_voice_miss: dict
    dictation: Any
    music: dict
    last_sent: dict
    hotkey: dict
    sit: dict
    hourly: dict
    fatigue: dict
    ticker: dict
    voiceprint: dict
    editing: dict
    pet_proc: dict
    not_heard: dict
    hint: str
    followup: float
    talk_state: Any
    mic_capture: dict

    def as_tuple(self) -> tuple:
        """Keep the historical local names in the entrypoint after extraction."""
        return (
            self.spoken_flag,
            self.stop_words,
            self.self_speech,
            self.self_voice_miss,
            self.dictation,
            self.music,
            self.last_sent,
            self.hotkey,
            self.sit,
            self.hourly,
            self.fatigue,
            self.ticker,
            self.voiceprint,
            self.editing,
            self.pet_proc,
            self.not_heard,
            self.hint,
            self.followup,
            self.talk_state,
            self.mic_capture,
        )


def create_runtime_session_state(
    config: Mapping[str, Any],
    mode: str,
    wake_words: Sequence[str],
    wake_timeout: float,
    default_stop_words: Sequence[str],
    *,
    clock: Callable[[], float] = time.time,
    now: Callable[[], datetime] = datetime.now,
    dictation_factory: Callable[[], Any] = DictationState,
    talk_state_factory: Callable[..., Any] = TalkState,
) -> RuntimeSessionState:
    """Build the same independent mutable values previously declared in ``main()``."""
    stop_words = [
        word.strip()
        for word in str(config.get("stop_words") or "").split(",")
        if word.strip()
    ]
    if not stop_words:
        stop_words = list(default_stop_words)
    followup = float(config.get("followup_seconds") or 0)
    hint = (
        f"说「{wake_words[0]}」唤醒"
        if wake_words
        else "直接说话就行"
    ) if mode == "talk" else ""
    return RuntimeSessionState(
        spoken_flag={"first": True},
        stop_words=stop_words,
        self_speech={"on": False},
        self_voice_miss={"text": "", "at": 0.0},
        dictation=dictation_factory(),
        music={"on": bool(config.get("wave_spectrum"))},
        last_sent={"text": "", "at": 0.0},
        hotkey={"prev": False},
        sit={"next": float(clock()) + 3600},
        hourly={"last": now().strftime("%Y-%m-%d %H")},
        fatigue={"speeds": [], "last": 0.0},
        ticker={"next": 0.0, "meeting": False},
        voiceprint={"enroll": False},
        editing={"on": False},
        pet_proc={"p": None},
        not_heard={"at": 0.0},
        hint=hint,
        followup=followup,
        talk_state=talk_state_factory(
            wake_timeout=float(wake_timeout),
            followup_seconds=followup,
        ),
        mic_capture={"recovery": None},
    )


__all__ = ["RuntimeSessionState", "create_runtime_session_state"]
