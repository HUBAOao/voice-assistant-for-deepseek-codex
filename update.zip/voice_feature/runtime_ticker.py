"""Ordered foreground tick work with per-stage failure isolation."""
from __future__ import annotations

import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass


@dataclass(frozen=True)
class TickFailure:
    stage: str
    error: Exception
    count: int
    reported: bool


class RuntimeTicker:
    """Run bound foreground checks in one order without sharing a try block."""

    def __init__(
        self,
        stages: Sequence[tuple[str, Callable[[], object]]],
        *,
        clock: Callable[[], float] = time.time,
        on_error: Callable[[TickFailure], None] | None = None,
        repeat_after: float = 30.0,
    ) -> None:
        self.stages = tuple(stages)
        self._clock = clock
        self._on_error = on_error
        self._repeat_after = max(0.0, float(repeat_after))
        self._errors: dict[str, tuple[int, float]] = {}

    def run(self) -> tuple[TickFailure, ...]:
        """Run every stage once, continuing after an individual failure."""
        failures: list[TickFailure] = []
        for name, action in self.stages:
            try:
                action()
            except Exception as exc:  # noqa: BLE001
                previous = self._errors.get(name, (0, 0.0))
                count = previous[0] + 1
                now = self._clock()
                reported = (
                    count == 1
                    or self._repeat_after <= 0
                    or now - previous[1] >= self._repeat_after
                )
                if reported:
                    self._errors[name] = (count, now)
                else:
                    self._errors[name] = (count, previous[1])
                failure = TickFailure(name, exc, count, reported)
                failures.append(failure)
                if reported and self._on_error is not None:
                    try:
                        self._on_error(failure)
                    except Exception:  # noqa: BLE001
                        pass
        return tuple(failures)

    def failure_counts(self) -> dict[str, int]:
        """Return accumulated failures by stage for diagnostics and tests."""
        return {name: count for name, (count, _at) in self._errors.items()}
