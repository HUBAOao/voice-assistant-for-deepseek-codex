"""Audio capture lifecycle for the main voice runtime."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True)
class AudioLoopDependencies:
    microphone: Any
    mode: str
    handle_lock: Any
    handle_audio: Callable[[Any], bool]
    remote_poll: Callable[[], None]
    paused: Callable[[], bool]
    status: Any
    key_down: Callable[[], bool] | None
    pause_key: str
    record_ptt: Callable[[Any], Any]
    has_utterance: Callable[[Any, int], bool]
    on_level: Callable[[float], None]
    on_hold_start: Callable[[], None]
    on_hold_stop: Callable[[], None]
    capture_talk: Callable[[], Any]
    on_speech: Callable[[], None]
    before_fallback_capture: Callable[[], None]
    print_line: Callable[..., None] = print
    sleep: Callable[[float], None] = time.sleep


class AudioLoop:
    """Run recording and delivery without owning process-wide setup."""

    def __init__(self, deps: AudioLoopDependencies) -> None:
        self.deps = deps

    def run(self) -> None:
        deps = self.deps
        mic = deps.microphone
        while True:
            if not mic.available:
                if not mic.recover():
                    deps.sleep(3)
                    continue

            if deps.mode == "hold":
                deps.remote_poll()
                if deps.paused():
                    mic.recorder._read()
                    continue
                deps.status.set(
                    "idle",
                    hint=f"按住 {deps.pause_key} 说话，松手发送",
                )
                audio = mic.recorder.record_hold(
                    deps.key_down,
                    meter=True,
                    on_level=lambda value, _block=None: deps.on_level(value),
                    on_start=deps.on_hold_start,
                    on_stop=deps.on_hold_stop,
                )
                if audio is None:
                    continue
            elif deps.mode == "enter":
                audio = deps.record_ptt(mic.recorder)
                if not deps.has_utterance(audio, mic.rate):
                    deps.print_line("（太短，忽略）")
                    continue
            elif deps.mode == "talk":
                audio = deps.capture_talk()
                if audio is None:
                    continue
            else:
                deps.before_fallback_capture()
                threshold = mic.safe_calibrate()
                deps.status.set(
                    "listening",
                    hint="直接说话，停顿约 1 秒自动断句",
                )
                deps.print_line(
                    "\r⌛ 在听了，直接说话就行…" + " " * 20,
                    flush=True,
                )
                audio = mic.safe_record(
                    threshold,
                    deps.on_speech,
                    tick=deps.remote_poll,
                    on_level=lambda value, _block=None: deps.on_level(value),
                )
                if not deps.has_utterance(audio, mic.rate):
                    deps.print_line(
                        "\r（没听到说话，继续听）" + " " * 20,
                        flush=True,
                    )
                    continue

            with deps.handle_lock:
                if deps.handle_audio(audio):
                    return
