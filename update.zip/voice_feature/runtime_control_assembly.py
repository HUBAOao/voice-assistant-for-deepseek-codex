# -*- coding: utf-8 -*-
"""Bind pause, hotkey and overlay commands outside the main lifecycle."""
from __future__ import annotations

import ctypes
import json
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ControlRuntimeDependencies:
    args: Any
    config: dict
    config_file: Path
    load_config: Callable[[], dict]
    wake_words: list[str]
    pause: dict
    mute: dict
    status: Any
    editing: dict
    hotkey: dict
    syslog: Callable[[str, str], object]
    beep: Callable[[int, int], object]
    shut_up: Callable[[], object]
    runtime_lifecycle: Any
    do_export: Callable[[], object]
    do_import: Callable[[], object]
    do_diagnose: Callable[[], object]
    restart_program: Callable[[], object]
    start_wake_test: Callable[[str], object]
    read_selected: Callable[[], object]
    manual_exit: Path
    emit: Callable[[str], object] = print
    key_down: Callable[[int], bool] | None = None


class ControlRuntime:
    """Keep foreground controls deterministic and independently testable."""

    def __init__(self, deps: ControlRuntimeDependencies) -> None:
        self.deps = deps

    def set_paused(self, value: bool, why: str = "") -> None:
        deps = self.deps
        deps.pause["paused"] = value
        if value:
            deps.status.set(
                "paused",
                hint=f"点悬浮窗的开关继续（或按 {deps.args.pause_key}）",
            )
            deps.emit(f"\r⏸ 已暂停{why}" + " " * 12)
        else:
            deps.status.set("idle" if deps.wake_words else "listening")
            deps.emit("\r▶ 继续" + " " * 28)
        deps.beep(520 if value else 880, 90)

    def check_hotkey(self) -> None:
        deps = self.deps
        if not deps.config.get("read_hotkey", True):
            return
        try:
            if deps.key_down is None:
                user32 = ctypes.windll.user32
                down = (
                    bool(user32.GetAsyncKeyState(0x11) & 0x8000)
                    and bool(user32.GetAsyncKeyState(0x12) & 0x8000)
                    and bool(user32.GetAsyncKeyState(0x52) & 0x8000)
                )
            else:
                down = bool(deps.key_down(0x52))
        except Exception:
            return
        if down and not deps.hotkey["prev"]:
            deps.read_selected()
        deps.hotkey["prev"] = down

    def _write_muted(self, value: bool) -> None:
        deps = self.deps
        try:
            fresh = deps.load_config()
            fresh["muted"] = value
            deps.config_file.write_text(
                json.dumps(fresh, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def remote_action(self, action: str) -> None:
        deps = self.deps
        if action == "pause":
            self.set_paused(True, "（悬浮窗按的）")
        elif action == "resume":
            self.set_paused(False, "（悬浮窗按的）")
        elif action == "toggle":
            self.set_paused(not deps.pause["paused"])
        elif action in ("mute", "unmute", "toggle-mute"):
            want = (
                (not deps.mute["on"])
                if action == "toggle-mute"
                else action == "mute"
            )
            deps.mute["on"] = want
            if want:
                deps.shut_up()
                self._write_muted(True)
                deps.status.set(
                    "sent", text="🔇 已静音（你说你的，我不出声）"
                )
                deps.syslog("静", "你按了静音：它不念了，但还听着")
                deps.emit("\n   ↳ 🔇 静音：不念了（说话、语音输入照常）")
            else:
                self._write_muted(False)
                deps.status.set("sent", text="🔊 恢复出声")
                deps.syslog("静", "恢复出声")
                deps.emit("\n   ↳ 🔊 恢复出声")
        elif action == "wake-test":
            deps.start_wake_test("（悬浮窗点的）")
        elif action == "editing-on":
            deps.editing["on"] = True
            deps.syslog("编", "你在改设置：先不抢键盘")
            deps.emit("\n   ↳ ✏️ 你在改设置，我先不抢键盘（只放剪贴板）")
        elif action == "editing-off":
            deps.editing["on"] = False
            deps.emit("\n   ↳ ✏️ 设置改完了，恢复粘贴")
        elif action == "export":
            deps.runtime_lifecycle.start_daemon("export-data", deps.do_export)
        elif action == "import":
            deps.runtime_lifecycle.start_daemon("import-data", deps.do_import)
        elif action == "diagnose":
            deps.runtime_lifecycle.start_daemon(
                "diagnose-data", deps.do_diagnose
            )
        elif action == "restart":
            deps.restart_program()
        elif action == "quit":
            deps.emit("\n收到悬浮窗的退出指令，正在退出…")
            try:
                deps.manual_exit.write_text(
                    json.dumps({"ts": time.time()}),
                    encoding="utf-8",
                )
            except Exception:
                pass
            deps.status.set("offline", hint="语音程序已退出")
            raise SystemExit(0)
