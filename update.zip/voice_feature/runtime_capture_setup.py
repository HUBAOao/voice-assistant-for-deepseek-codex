"""Assemble talk capture and mode-specific input handling for ``main()``."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from voice_feature.audio_loop import AudioLoop
from voice_feature.runtime_input_loop import (
    InputRuntimeDependencies,
    prepare_input_runtime,
)
from voice_feature.talk_capture import (
    TalkCaptureDependencies,
    capture_talk_utterance,
)


@dataclass(frozen=True)
class CaptureRuntimeDependencies:
    """Everything the capture session needs without owning it in ``main()``."""

    mode: str
    args: Any
    tracker: Any
    wake_words: list[str]
    cancel_words: list[str]
    silence: float
    runtime_lifecycle: Any
    pause: dict
    set_paused: Callable[[bool, str], None]
    runtime_tick: Callable[[], bool]
    remote: Any
    handle_lock: Any
    handle_audio: Callable[..., bool]
    status: Any
    microphone: Any
    key_watcher_factory: Callable[[str], Any]
    tracker_worker_factory: Callable[[Any], Any]
    find_window: Callable[[str], tuple[int, str]]
    record_ptt: Callable[[Any], Any]
    has_utterance: Callable[[Any, int], bool]
    on_level: Callable[[float], None]
    on_hold_start: Callable[[], None]
    on_hold_stop: Callable[[], None]
    on_speech: Callable[[], None]
    before_fallback_capture: Callable[[], None]
    cfg: dict
    self_speech: dict
    music: dict
    spoken_flag: dict
    syslog: Callable[[str, str], None]
    shut_up: Callable[[], None]
    speaking_now: Callable[[], bool]
    duplex: dict
    cancel_reference_echo: Callable[[Any, int], Any]
    spectrum_bands: Callable[..., list[float]]
    transcriber: Any
    hint: str


@dataclass(frozen=True)
class CaptureRuntimeResult:
    """Prepared input loop plus the microphone controller it consumes."""

    audio_loop: AudioLoop
    checked_pause: Callable[[], bool]
    tracker_worker: object | None
    microphone: Any


def prepare_capture_runtime(deps: CaptureRuntimeDependencies) -> CaptureRuntimeResult:
    """Build the desktop talk capture closure and the selected input mode."""

    def build_capture_talk(
        pause_check: Callable[[], bool],
    ) -> Callable[[], Any]:
        def capture_talk() -> Any:
            return capture_talk_utterance(
                TalkCaptureDependencies(
                    recorder=deps.microphone.recorder,
                    rate=deps.microphone.rate,
                    cfg=deps.cfg,
                    self_speech=deps.self_speech,
                    music=deps.music,
                    spoken_flag=deps.spoken_flag,
                    status=deps.status,
                    syslog=deps.syslog,
                    shut_up=deps.shut_up,
                    speaking_now=deps.speaking_now,
                    duplex=deps.duplex,
                    cancel_reference_echo=deps.cancel_reference_echo,
                    spectrum_bands=deps.spectrum_bands,
                    transcriber=deps.transcriber,
                    safe_calibrate=deps.microphone.safe_calibrate,
                    safe_record=deps.microphone.safe_record,
                    checked_pause=pause_check,
                    on_speech=deps.on_speech,
                    hint=deps.hint,
                    wake_enabled=bool(deps.wake_words),
                )
            )

        return capture_talk

    input_runtime = prepare_input_runtime(
        InputRuntimeDependencies(
            mode=deps.mode,
            args=deps.args,
            tracker=deps.tracker,
            wake_words=deps.wake_words,
            cancel_words=deps.cancel_words,
            silence=deps.silence,
            runtime_lifecycle=deps.runtime_lifecycle,
            pause=deps.pause,
            set_paused=deps.set_paused,
            runtime_tick=deps.runtime_tick,
            remote=deps.remote,
            handle_lock=deps.handle_lock,
            handle_audio=deps.handle_audio,
            status=deps.status,
            microphone=deps.microphone,
            key_watcher_factory=deps.key_watcher_factory,
            tracker_worker_factory=deps.tracker_worker_factory,
            find_window=deps.find_window,
            record_ptt=deps.record_ptt,
            has_utterance=deps.has_utterance,
            on_level=deps.on_level,
            on_hold_start=deps.on_hold_start,
            on_hold_stop=deps.on_hold_stop,
            on_speech=deps.on_speech,
            before_fallback_capture=deps.before_fallback_capture,
            capture_talk_factory=build_capture_talk,
        )
    )
    return CaptureRuntimeResult(
        audio_loop=input_runtime.audio_loop,
        checked_pause=input_runtime.checked_pause,
        tracker_worker=input_runtime.tracker_worker,
        microphone=deps.microphone,
    )
