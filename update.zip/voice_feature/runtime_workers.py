# -*- coding: utf-8 -*-
"""Long-running workers and shutdown resources used by the STT entrypoint."""
from __future__ import annotations

import json
import os
import threading
import time
from collections.abc import Callable
from pathlib import Path

from voice_feature.runtime_lifecycle import RuntimeLifecycle


class HeartbeatWorker:
    """Write a process heartbeat independently of the recording loop."""

    def __init__(
        self,
        path: Path,
        *,
        interval: float = 5.0,
        pid: int | None = None,
        clock: Callable[[], float] = time.time,
        stop_event_factory: Callable[[], object] = threading.Event,
    ) -> None:
        self.path = Path(path)
        self.interval = max(0.0, float(interval))
        self.pid = os.getpid() if pid is None else int(pid)
        self._clock = clock
        self._stop = stop_event_factory()

    def write_once(self) -> None:
        try:
            self.path.write_text(
                json.dumps({"pid": self.pid, "ts": self._clock()}),
                encoding="utf-8",
            )
        except Exception:
            pass

    def run(self) -> None:
        while not self._stop.wait(0):
            self.write_once()
            if self._stop.wait(self.interval):
                return

    def start(self, lifecycle: RuntimeLifecycle) -> object:
        return lifecycle.start_daemon("heartbeat", self.run)

    def stop(self) -> None:
        self._stop.set()


class ForegroundTrackerWorker:
    """Poll the foreground window until the lifecycle asks it to stop."""

    def __init__(
        self,
        tracker,
        *,
        interval: float = 0.2,
        stop_event_factory: Callable[[], object] = threading.Event,
    ) -> None:
        self.tracker = tracker
        self.interval = max(0.0, float(interval))
        self._stop = stop_event_factory()

    def run(self) -> None:
        while not self._stop.wait(0):
            self.tracker.poll()
            if self._stop.wait(self.interval):
                return

    def start(self, lifecycle: RuntimeLifecycle) -> object:
        return lifecycle.start_daemon("foreground-tracker-worker", self.run)

    def stop(self) -> None:
        self._stop.set()


def _close_microphone(stream) -> None:
    first_error: Exception | None = None
    for operation in (stream.stop, stream.close):
        try:
            operation()
        except Exception as exc:  # noqa: BLE001
            if first_error is None:
                first_error = exc
    if first_error is not None:
        raise first_error


def register_shutdown_resources(
    lifecycle: RuntimeLifecycle,
    *,
    microphone: Callable[[], object],
    tracker_worker: ForegroundTrackerWorker | None = None,
    overlay_process=None,
    phone_server=None,
) -> None:
    """Register cleanup so clients stop after visible and capture resources."""
    if phone_server is not None:
        lifecycle.register_closeable("phone-link", phone_server.stop)
    lifecycle.register_closeable(
        "microphone",
        lambda: _close_microphone(microphone()),
    )
    if tracker_worker is not None:
        lifecycle.register_closeable("foreground-tracker", tracker_worker.stop)

    def stop_overlay() -> None:
        if overlay_process is None or overlay_process.poll() is not None:
            return
        overlay_process.terminate()

    lifecycle.register_closeable("overlay", stop_overlay)
