"""One-shot command-line modes kept outside the voice runtime's ``main``.

These paths still use the real microphone/model/window services supplied by
the caller, but their ordering and result codes are independently testable.
"""
from __future__ import annotations

import os
import time
from collections.abc import Callable, MutableMapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeCliModeDependencies:
    """Bound services used by ``--list-devices``, paste and file modes."""

    list_devices: Callable[[], object]
    foreground_tracker_factory: Callable[[], Any]
    find_window: Callable[[str | None], tuple[int, str]]
    paste_into: Callable[..., bool]
    transcriber_factory: Callable[..., Any]
    append_log: Callable[[Path, str], object]
    copy_to_clipboard: Callable[[str], bool]
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], object] = time.sleep
    emit: Callable[[str], object] = print
    environ: MutableMapping[str, str] = field(default_factory=lambda: os.environ)


def configure_model_environment(
    environ: MutableMapping[str, str],
    *,
    emit: Callable[[str], object] = print,
) -> bool:
    """Keep the historical domestic model mirror after device listing."""
    if "HF_ENDPOINT" in environ:
        return False
    environ["HF_ENDPOINT"] = "https://hf-mirror.com"
    emit("（已默认使用 HF 镜像下载模型）")
    return True


def run_cli_mode(
    args: Any,
    dependencies: RuntimeCliModeDependencies,
) -> int | None:
    """Run one utility mode, returning ``None`` to continue into voice mode."""
    deps = dependencies
    if bool(getattr(args, "list_devices", False)):
        deps.list_devices()
        return 0

    configure_model_environment(deps.environ, emit=deps.emit)

    if bool(getattr(args, "test_paste", False)):
        tracker = deps.foreground_tracker_factory()
        for _ in range(4):
            tracker.poll()
            deps.sleep(0.2)
        target = getattr(args, "target", None)
        hwnd, title = (
            deps.find_window(target)
            if target
            else (tracker.hwnd, tracker.title)
        )
        if not hwnd:
            deps.emit(
                "⚠️ 没找到可以粘贴的窗口。先点一下你要发送的窗口"
                "（比如聊天窗口），再运行这条命令。"
            )
            return 1
        deps.emit(f"目标窗口：{title}  (hwnd={hwnd})")
        ok = deps.paste_into(
            "【粘贴测试】看到这行字说明粘贴通道是通的"
            "（没有回车，不会发出去）",
            hwnd,
            press_enter=False,
        )
        deps.emit("切窗口: " + ("成功" if ok else "失败"))
        return 0 if ok else 1

    file_name = getattr(args, "file", None)
    if not file_name:
        return None
    transcriber = deps.transcriber_factory(
        args.model,
        args.device,
        args.compute_type,
        args.lang,
    )
    started = deps.clock()
    text = transcriber.transcribe_file(file_name)
    if not text:
        deps.emit("没识别到内容。")
        return 1
    deps.emit(f"\n📝 {text}")
    deps.emit(f"   （识别耗时 {deps.clock() - started:.1f}s）")
    deps.append_log(
        Path(args.out),
        f"[文件: {Path(file_name).name}] {text}",
    )
    if (
        not bool(getattr(args, "no_clipboard", False))
        and deps.copy_to_clipboard(text)
    ):
        deps.emit("   ↳ 已复制到剪贴板")
    return 0


__all__ = [
    "RuntimeCliModeDependencies",
    "configure_model_environment",
    "run_cli_mode",
]
