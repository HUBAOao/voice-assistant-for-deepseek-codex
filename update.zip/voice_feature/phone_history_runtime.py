# -*- coding: utf-8 -*-
"""Phone reply storage and filtered conversation history."""
from __future__ import annotations

import importlib
import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PhoneHistoryDependencies:
    syslog_file: Path
    raw_replies_file: Path
    last_reply_file: Path
    load_config: Callable[[], dict]
    self_who: Callable[[dict], str]
    ack_phrases: tuple[str, ...]
    phone_window_title: Callable[[], str]
    current_thread_name: Callable[[], str]
    chat_history: Any
    print_line: Callable[..., object] = print
    codex_replies_factory: Callable[[], Any] | None = None
    clock: Callable[[], datetime] = datetime.now


def append_reply(
    name: str,
    text: str,
    *,
    deps: PhoneHistoryDependencies,
    log: Callable[[str, str], None],
) -> None:
    """Keep the full reply locally and add its display marker to syslog."""
    try:
        rec = {
            "at": deps.clock().strftime("%Y-%m-%d %H:%M:%S"),
            "name": str(name or "")[:40],
            "text": str(text or "")[:30000],
        }
        with deps.raw_replies_file.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        deps.last_reply_file.write_text(
            json.dumps(
                {**rec, "ts": deps.clock().timestamp()},
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        log("复", str(text or "")[:4000])
        if deps.raw_replies_file.stat().st_size > 400_000:
            keep = deps.raw_replies_file.read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()
            deps.raw_replies_file.write_text(
                "\n".join(keep[-60:]) + "\n", encoding="utf-8"
            )
    except Exception:
        pass


def recent_replies(path: Path) -> list[dict]:
    """Return at most 40 parsed replies, newest first."""
    out: list[dict] = []
    try:
        lines = path.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()
    except Exception:
        return out
    for line in lines[-40:]:
        try:
            rec = json.loads(line)
            if isinstance(rec, dict):
                out.append(rec)
        except Exception:
            pass
    out.reverse()
    return out


def _ack_set(
    cfg: dict,
    who: str,
    phrases: tuple[str, ...],
) -> set[str]:
    ack: set[str] = set()
    try:
        raw_ack = str(cfg.get("ack_text") or "我知道了")
        ack.update(
            part.strip()
            for part in re.split(r"[|\n；;]+", raw_ack)
            if part.strip()
        )
        if who:
            ack.update(phrase.format(w=who) for phrase in phrases)
        user_name = str(cfg.get("user_name") or "").strip()
        if user_name:
            ack.update(f"{item}，{user_name}" for item in list(ack))
    except Exception:
        pass
    return ack


def build_phone_history(
    since: int,
    keyword: str,
    *,
    deps: PhoneHistoryDependencies,
) -> list[dict]:
    """Filter syslog into the compact conversation stream shown on phones."""
    out: list[dict] = []
    stream_seen: set[tuple[str, str]] = set()
    recent: list[tuple[str, str, int, int]] = []
    alias_cache = getattr(build_phone_history, "_alias_cache", {})
    build_phone_history._alias_cache = alias_cache
    kinds = {"听": "me", "念": "ai", "复": "ai", "流": "ai", "完": "done"}
    noise = (
        "没听清", "自己的声音", "疑似幻觉", "背景音", "这句忽略", "忽略）",
        "抢话", "重复第二遍", "开机问候",
    )
    cfg = deps.load_config()
    ack_values = _ack_set(cfg, deps.self_who(cfg), deps.ack_phrases)
    try:
        lines = deps.syslog_file.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()
    except Exception:
        return out

    stream_final: list[str] = []
    for line in lines:
        match = re.match(
            r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[流终\] (.*)$", line
        )
        if match:
            _conv, _, prefix = match.group(1).partition("\x1f")
            flat = "".join(str(prefix).split())
            if flat:
                stream_final.append(flat[:60])

    raw_all = recent_replies(deps.raw_replies_file)
    whole_replies = [
        str(row.get("text") or "") for row in raw_all if row.get("text")
    ]
    try:
        codex_replies = (
            deps.codex_replies_factory()
            if deps.codex_replies_factory is not None
            else importlib.import_module("codex_replies")
        )
        title_by_id = codex_replies.titles_by_id()
    except Exception:
        codex_replies = None
        title_by_id = {}

    for index, line in enumerate(lines, start=1):
        if index <= int(since or 0):
            continue
        match = re.match(
            r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d \[(.+?)\] (.*)$", line
        )
        if not match:
            continue
        tag, body = match.group(1), match.group(2)
        if not body or tag == "流终":
            continue
        stream_conv = ""
        if tag == "流":
            stream_conv, _, body = body.partition("\x1f")
            if not body:
                continue
            flat = "".join(body.split())
            key = (stream_conv, flat)
            if flat and key in stream_seen:
                continue
            if flat:
                stream_seen.add(key)
        if tag not in kinds:
            continue
        if tag == "复":
            flat = "".join(str(body).split())
            if any(
                prefix and (prefix in flat or flat[:60] in prefix)
                for prefix in stream_final
            ):
                continue
        if tag == "念" and body.strip() in ack_values:
            continue
        if body.startswith("（") and any(
            word in body[:24] for word in noise
        ):
            continue
        if keyword and keyword not in body:
            continue
        if tag == "念" and any(
            body[:24] and body[:24] in whole for whole in whole_replies
        ):
            continue
        try:
            line_ts_ms = int(
                datetime.strptime(
                    line[:19], "%Y-%m-%d %H:%M:%S"
                ).timestamp() * 1000
            )
        except Exception:
            line_ts_ms = 0
        if not keyword:
            key = (
                kinds[tag],
                body.replace("（手机）", "").strip()[:120],
            )
            if any(
                kind == key[0]
                and text == key[1]
                and (
                    index - prior_index <= 12
                    or (
                        key[0] == "me"
                        and line_ts_ms
                        and prior_ts
                        and 0 <= line_ts_ms - prior_ts <= 20_000
                    )
                )
                for kind, text, prior_index, prior_ts in recent
            ):
                continue
            recent.append((key[0], key[1], index, line_ts_ms))
            if len(recent) > 60:
                del recent[:-60]
        stamp = line[11:16] if len(line) >= 16 else ""
        body_out = body.replace("（手机）", "", 1).strip() or body
        raw_text = ""
        conv = stream_conv
        if tag in ("念", "复"):
            for row in raw_all:
                full_text = str(row.get("text") or "")
                if (
                    full_text
                    and body_out[:40]
                    and (
                        body_out[:40] in full_text
                        or full_text[:40] in body_out
                    )
                ):
                    conv = str(row.get("name") or "").strip()
                    if tag == "念":
                        raw_text = full_text[:30000]
                    break
        if not conv and tag == "念":
            conv = deps.phone_window_title().strip()
        out.append({
            "n": index,
            "kind": kinds[tag],
            "text": body_out[:6000],
            "at": stamp,
            "raw": raw_text,
            "conv": conv[:60],
            "stream": tag == "流",
            "_ts": line_ts_ms,
        })

    try:
        deps.chat_history.ingest(out)
    except Exception as exc:
        deps.print_line(f"   （历史库写入失败：{exc}）", flush=True)
    recent_out = out[-200:]
    if codex_replies is not None:
        stamps = [
            int(item.get("_ts") or 0)
            for item in recent_out
            if item.get("_ts")
        ]
        user_map: dict[str, str] = {}
        answer_map: dict[str, str] = {}
        if stamps:
            try:
                user_map, answer_map = codex_replies.recent_item_threads(
                    min(stamps) - 10 * 60 * 1000,
                    max(stamps) + 60 * 1000,
                    limit=1500,
                )
            except Exception:
                pass
        user_prefix = {
            str(key)[:16]: value
            for key, value in user_map.items()
            if key
        }
        for item in recent_out:
            kind = str(item.get("kind") or "")
            conv_key = codex_replies._norm(
                item.get("conv") or ""
            )[:32]
            conv_tid = (
                user_map.get(conv_key)
                or user_prefix.get(conv_key[:16])
                if conv_key else ""
            )
            if not conv_tid:
                old_conv = str(item.get("conv") or "").strip()
                if old_conv:
                    if old_conv not in alias_cache:
                        alias_cache[old_conv] = (
                            codex_replies.thread_for_title_alias(old_conv) or ""
                        )
                    conv_tid = alias_cache[old_conv]
            if conv_tid and title_by_id.get(str(conv_tid)):
                item["conv"] = str(title_by_id[str(conv_tid)])[:60]
            key = codex_replies._norm(item.get("text") or "")[:32]
            tid = user_map.get(key) if kind == "me" else (
                answer_map.get(key) if kind == "ai" else ""
            )
            if tid:
                item["conv"] = str(title_by_id.get(str(tid)) or "")[:60]
            if kind == "me" and not item.get("conv"):
                conv = deps.phone_window_title().strip()
                if not conv:
                    try:
                        conv = deps.current_thread_name().strip()
                    except Exception:
                        conv = ""
                if not conv or conv == "自动":
                    conv = "对话"
                item["conv"] = conv[:60]
            elif kind == "ai":
                conv = str(item.get("conv") or "")
                if (
                    not conv
                    or conv in ("ChatGPT", "Codex", "前台窗口", "自动")
                    or len(conv) > 36
                    or conv.startswith("-")
                    or "`" in conv
                    or "\n" in conv
                ):
                    item["conv"] = "对话"
    try:
        recent_out = deps.chat_history.visible_records(recent_out)
    except Exception:
        pass
    for item in recent_out:
        item.pop("_ts", None)
    return recent_out
