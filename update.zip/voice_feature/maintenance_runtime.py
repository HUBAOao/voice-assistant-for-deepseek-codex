# -*- coding: utf-8 -*-
"""Self-check, backup, update, undo and dictation actions without STT import."""
from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class MaintenanceRuntimeDependencies:
    status: Any
    speak: Callable[[str], Any]
    syslog: Callable[[str, str], Any]
    config: Mapping
    private: dict
    last_sent: dict
    transcriber: Any
    target: str | None
    overlay_running: bool
    overlay_disabled: bool
    current_target_hwnd: Callable[[], int]
    query_device: Callable[[Any], dict]
    device: Any
    find_window: Callable[[str], tuple[int, str]]
    clipboard_text: Callable[[], str]
    copy_to_clipboard: Callable[[str], bool]
    paste_clipboard: Callable[..., bool]
    paste_into: Callable[..., bool]
    focus_window: Callable[[int], Any]
    send_ctrl_z: Callable[[], Any]
    export_data: Callable[[], Path | None]
    import_data: Callable[[], tuple[int, str]]
    diag_pack: Callable[[], Path | None]
    newer_package: Callable[[], tuple[Path, str] | None]
    apply_update: Callable[[Path], int]
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], Any] = time.sleep
    emit: Callable[[str], Any] = print


class MaintenanceRuntime:
    """Keep the original action names and user-facing behavior."""

    def __init__(self, deps: MaintenanceRuntimeDependencies) -> None:
        self.deps = deps

    def self_check(self, speak_it: bool = True) -> list[str]:
        """Check microphone, model, target window, clipboard and overlay."""
        deps = self.deps
        problems: list[str] = []
        try:
            device = deps.query_device(deps.device)
            if int(device.get("max_input_channels") or 0) < 1:
                problems.append("那个麦克风现在没有输入通道")
        except Exception as exc:  # noqa: BLE001
            problems.append(f"找不到麦克风（{type(exc).__name__}）")
        if getattr(deps.transcriber, "model", None) is None:
            problems.append("识别模型没加载上")
        if deps.target:
            hwnd, _title = deps.find_window(deps.target)
            if not hwnd:
                problems.append(
                    f"没找到「{deps.target}」窗口，发出去的东西会先放剪贴板"
                )
        previous = deps.clipboard_text()
        if not deps.copy_to_clipboard("语音助手自检"):
            problems.append("剪贴板写不进去")
        elif previous:
            deps.copy_to_clipboard(previous)
        if (
            not deps.overlay_running
            and not deps.overlay_disabled
            and deps.config.get("overlay_enabled", True)
        ):
            problems.append("悬浮窗没起来")
        for problem in problems:
            deps.syslog("检", problem)
        if not problems:
            deps.syslog("检", "自检通过：麦克风/模型/窗口/剪贴板都正常")
        if speak_it and problems:
            deps.speak("自检发现：" + "；".join(problems))
        return problems

    def do_export(self) -> None:
        output = self.deps.export_data()
        if output:
            self.deps.speak(f"数据打包好了，藏在导出文件夹里：{output.name}")
            self.deps.syslog("备", f"导出数据 → {output.name}")
        else:
            self.deps.speak("导出失败了")

    def do_import(self) -> None:
        count, message = self.deps.import_data()
        self.deps.speak(("数据导入完成，" + message) if count else message)
        self.deps.syslog("备", f"导入数据：{message}")

    def do_diagnose(self) -> None:
        output = self.deps.diag_pack()
        if output:
            self.deps.speak(f"诊断包好了，藏在导出文件夹里：{output.name}")
            self.deps.syslog("备", f"打包诊断 → {output.name}")
        else:
            self.deps.speak("诊断包没打出来")

    def do_update(self) -> None:
        found = self.deps.newer_package()
        if not found:
            self.deps.speak("现在就是最新版本")
            return
        package, version = found
        self.deps.private["update_pkg"] = str(package)
        self.deps.speak(f"发现新版本 {version}，说「开始更新」我就套用")
        self.deps.syslog("更", f"发现新版本 {version}（{package.name}）")

    def apply_update_now(self) -> None:
        package = self.deps.private.get("update_pkg")
        if not package or not Path(str(package)).is_dir():
            self.deps.speak("先让我检查一下更新")
            return
        count = self.deps.apply_update(Path(str(package)))
        self.deps.speak(f"更新完成，套用了 {count} 个文件，重启一下就生效")
        self.deps.syslog("更", f"套用更新：{count} 个文件")

    def undo_last(self) -> None:
        """Undo the last send and put its text back into the input box."""
        deps = self.deps
        if (
            not deps.last_sent.get("text")
            or deps.clock() - float(deps.last_sent.get("at") or 0) > 180
        ):
            deps.speak("没有可以撤回的内容")
            return
        hwnd = (
            deps.find_window(deps.target)[0]
            if deps.target
            else deps.current_target_hwnd()
        )
        if hwnd:
            deps.focus_window(hwnd)
            deps.sleep(0.15)
            deps.send_ctrl_z()
            deps.sleep(0.25)
        text = str(deps.last_sent.get("text") or "")
        deps.copy_to_clipboard(text)
        deps.paste_clipboard(hwnd, press_enter=False, clear_first=True)
        deps.speak("试着撤回了，也把它放回输入框了，你改完自己发")
        deps.syslog("撤", f"撤回上一条：{text[:40]}")
        deps.emit("   ↳ ↩️ 已撤回并放回输入框")

    def type_into_focused(self, added: str) -> None:
        """Type dictation into the current caret without sending it."""
        deps = self.deps
        hwnd = deps.current_target_hwnd() or 0
        if not hwnd:
            deps.copy_to_clipboard(added)
            deps.speak("没找到光标在哪个窗口，先放剪贴板了")
            deps.status.set("sent", text=f"📝 {added}")
            return
        ok = deps.paste_into(
            added,
            hwnd,
            press_enter=False,
            clear_first=False,
        )
        deps.emit(
            f"   ↳ ⌨️ 听写：{added}（{'已输入' if ok else '没输进去'}）"
        )
        deps.status.set(
            "sent" if ok else "offline",
            text=f"⌨️ {added}",
        )


__all__ = [
    "MaintenanceRuntime",
    "MaintenanceRuntimeDependencies",
]
