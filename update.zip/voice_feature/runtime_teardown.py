# -*- coding: utf-8 -*-
"""Failure reporting and best-effort shutdown at the process boundary."""
from __future__ import annotations

import time
import traceback
from collections.abc import Callable
from datetime import datetime
from pathlib import Path

from voice_feature.runtime_lifecycle import RuntimeLifecycle


def handle_runtime_failure(
    exc: BaseException,
    *,
    crash_file: Path,
    syslog: Callable[[str, str], object],
    speak: Callable[[str], object],
    emit: Callable[[str], object],
    now: Callable[[], datetime] = datetime.now,
    sleep: Callable[[float], object] = time.sleep,
) -> None:
    """Persist the crash, notify the user, then raise the historical exit code."""
    detail = "".join(traceback.format_exception(exc))
    try:
        emit("\n出错了：\n" + detail)
    except Exception:
        pass
    try:
        syslog("错", f"程序异常退出：{type(exc).__name__}: {str(exc)[:120]}")
    except Exception:
        pass
    try:
        Path(crash_file).write_text(
            f"{now().strftime('%Y-%m-%d %H:%M:%S')}\n{detail}",
            encoding="utf-8",
        )
    except Exception:
        pass
    try:
        speak("我出了点问题，正在重启")
    except Exception:
        pass
    sleep(2)
    raise SystemExit(3)


def shutdown_runtime(
    lifecycle: RuntimeLifecycle,
    instance_guard,
    *,
    status,
    syslog: Callable[[str, str], object],
    emit: Callable[[str], object],
) -> list[tuple[str, Exception]]:
    """Run every shutdown step even when an earlier step fails."""
    errors: list[tuple[str, Exception]] = []

    def report(resource: str, error: Exception) -> None:
        errors.append((resource, error))
        try:
            emit(f"   （退出时清理 {resource} 失败：{error}）")
        except Exception:
            pass
        try:
            syslog("检", f"退出清理 {resource} 失败：{type(error).__name__}")
        except Exception:
            pass

    try:
        status.set("offline", hint="语音程序已退出")
    except Exception as exc:  # noqa: BLE001
        report("status", exc)

    try:
        close_errors = lifecycle.close()
    except Exception as exc:  # noqa: BLE001
        report("runtime", exc)
    else:
        for resource, error in close_errors:
            report(resource, error)

    try:
        instance_guard.release()
    except Exception as exc:  # noqa: BLE001
        report("instance-guard", exc)
    return errors
