"""Testable startup assembly for the STT process.

The main voice loop should receive a fully prepared runtime, not own the
ordering of instance locking, persisted state, machine profile, plugins,
command-line parsing and the heartbeat thread.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.runtime_lifecycle import RuntimeLifecycle


@dataclass(frozen=True)
class RuntimeBootstrapDependencies:
    """Bound app services needed before the voice loop can start."""

    setup_console: Callable[[], object]
    make_instance_guard: Callable[[], object]
    load_config: Callable[[], dict]
    start_plugins: Callable[[], object]
    restore_saved_state: Callable[[dict], object]
    detect_profile: Callable[[], tuple[str, Mapping]]
    apply_low_profile: Callable[[dict, str, Mapping], object]
    build_parser: Callable[[dict, str | None, str], object]
    start_heartbeat: Callable[[RuntimeLifecycle], object]
    register_atexit: Callable[[Callable[[], object]], object]
    default_input: Callable[[dict], str | None]
    default_out: str
    manual_exit: Path
    emit: Callable[[str], object] = print


@dataclass(frozen=True)
class RuntimeBootstrapResult:
    """The exact state consumed by the rest of ``main()``."""

    instance_guard: object
    cfg: dict
    profile: str
    hardware: Mapping
    args: Any


def prepare_runtime(
    raw_args: Sequence[str],
    dependencies: RuntimeBootstrapDependencies,
    lifecycle: RuntimeLifecycle,
) -> RuntimeBootstrapResult | None:
    """Prepare one process start, returning ``None`` if one is already live.

    ``--allow-multiple`` is checked against the original argument sequence, so
    the explicit multi-process escape remains effective before argparse runs.
    Startup is deliberately ordered: state and policy are ready before CLI
    defaults are parsed, and the heartbeat exists before the manual-exit mark
    is cleared for a self-started process.
    """
    deps = dependencies
    deps.setup_console()

    allow_multiple = "--allow-multiple" in raw_args
    guard = deps.make_instance_guard()
    if not allow_multiple and not guard.acquire():
        deps.emit("已经有一份在跑了，这份退出。")
        return None
    if guard.owned:
        deps.register_atexit(guard.release)

    cfg = deps.load_config()
    if not isinstance(cfg, dict):
        cfg = {}
    deps.start_plugins()
    deps.restore_saved_state(cfg)

    profile, hardware = deps.detect_profile()
    deps.apply_low_profile(cfg, profile, hardware)

    parser = deps.build_parser(
        cfg,
        deps.default_input(cfg),
        deps.default_out,
    )
    args = parser.parse_args(list(raw_args))

    deps.start_heartbeat(lifecycle)
    try:
        deps.manual_exit.unlink()
    except OSError:
        pass

    return RuntimeBootstrapResult(guard, cfg, profile, hardware, args)
