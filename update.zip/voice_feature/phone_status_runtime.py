# -*- coding: utf-8 -*-
"""Phone-facing status and product metadata without importing STT."""
from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PhoneStateDependencies:
    status: Any
    busy: dict
    mute: dict
    pause: dict
    reply_busy: Callable[[], bool]
    clock: Callable[[], float] = time.time
    busy_guard_seconds: float = 720.0


class PhoneStateRuntime:
    """Build the phone status payload and apply the stale-busy guard."""

    def __init__(self, deps: PhoneStateDependencies) -> None:
        self.deps = deps

    def snapshot(self) -> dict:
        deps = self.deps
        detail = str(
            (getattr(deps.status, "_last", {}) or {}).get("text")
            or deps.status.hint
            or ""
        )
        try:
            busy = bool(deps.busy.get("on")) or bool(deps.reply_busy())
        except Exception:
            busy = False
        started = deps.busy.get("at")
        if (
            busy
            and started
            and deps.clock() - float(started) > deps.busy_guard_seconds
        ):
            deps.busy["on"] = False
            try:
                if not deps.reply_busy():
                    busy = False
            except Exception:
                busy = False
        return {
            "state_text": (
                f"{deps.status.state} · {detail}"
                if detail
                else str(deps.status.state)
            ),
            "busy": busy,
            "mute": bool(deps.mute["on"]),
            "paused": bool(deps.pause["paused"]),
        }


@dataclass(frozen=True)
class PhoneInfoDependencies:
    config: Mapping
    pc_version: Callable[[], str]
    phone_version: Callable[[], str]
    version_module: Any
    public_update_url: Callable[[], str]
    remote_access: Any


class PhoneInfoRuntime:
    """Return the single metadata payload consumed by phone settings."""

    def __init__(self, deps: PhoneInfoDependencies) -> None:
        self.deps = deps

    def _update_source(self) -> str:
        try:
            custom = str(self.deps.config.get("update_url") or "").strip()
            if custom:
                return custom.rstrip("/")
            return str(self.deps.public_update_url() or "").rstrip("/")
        except Exception:
            return ""

    def snapshot(self) -> dict:
        deps = self.deps
        remote = deps.remote_access
        detail = remote.detail()
        version = deps.version_module
        return {
            "name": str(deps.config.get("name") or "语音助手"),
            "pc": deps.pc_version(),
            "phone": deps.phone_version(),
            "author": version.AUTHOR,
            "contact": version.CONTACT,
            "copyright": version.COPYRIGHT,
            "free": version.FREE_LINE,
            "notice": version.NOTICE,
            "update_url": self._update_source(),
            "fixed_url": remote.fixed_url(),
            "fixed_url_alt": remote.alt_url(),
            "remote_hint": remote.hint(),
            "remote_tip": remote.phone_hint(),
            "funnel_on": bool(detail.get("funnel_on")),
            "public_url": remote.public_url(),
            "tailscale_apk": remote.apk_url(),
            "remote_account": detail.get("account", ""),
        }
