# -*- coding: utf-8 -*-
"""Assemble phone and post-capture runtimes outside the STT entrypoint."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.phone_adapter_assembly import (
    RuntimePhoneAdapterDependencies,
    assemble_phone_adapter,
)
from voice_feature.phone_runtime_assembly import (
    PhoneRuntimeDependencies,
    assemble_phone_runtime,
)
from voice_feature.runtime_control_assembly import (
    ControlRuntime,
    ControlRuntimeDependencies,
)
from voice_feature.runtime_delivery_assembly import (
    RuntimeDeliveryAssembly,
    RuntimeDeliveryDependencies,
)
from voice_feature.runtime_interaction_assembly import (
    RuntimeInteractionAssembly,
    RuntimeInteractionDependencies,
)
from voice_feature.runtime_periodic_assembly import (
    OverlayLivenessDependencies,
    RuntimeOverlayLiveness,
    RuntimePeriodicAssembly,
    RuntimePeriodicDependencies,
)
from voice_feature.runtime_reply_assembly import (
    RuntimeReplyAssembly,
    RuntimeReplyDependencies,
)
from voice_feature.runtime_send_gate_assembly import (
    RuntimeSendGateAssembly,
    RuntimeSendGateDependencies,
)


@dataclass(frozen=True)
class RuntimeServiceDependencies:
    """Live callbacks and state needed by the middle runtime stack."""

    args: Any
    config: dict
    config_file: Path
    app_dir: Path
    syslog_file: Path
    voiceprint_file: Path
    said_file: Path
    manual_exit: Path
    status: Any
    busy: dict
    mute: dict
    editing: dict
    hotkey: dict
    level_state: Callable[[float], str]
    phone_window_state: dict
    voiceprint: dict
    wake_words: list[str]
    rate: int
    transcriber: Any
    cancel_reference_echo: Callable[[Any, int], Any]
    handle_lock: Any
    handle_command: Callable[[str], Any]
    speech_context: Any
    phone_window: Callable[[], tuple[int, str]]
    pick_send_target: Callable[[], tuple[int, str]]
    focus_window: Callable[[int], bool]
    press_enter: Callable[[], Any]
    paste_into: Callable[..., bool]
    paste_clipboard: Callable[..., Any]
    image_to_clipboard: Callable[[Path], bool]
    set_phone_window: Callable[[str, str], tuple[bool, str]]
    phone_thread_action: Callable[[str, str, dict], tuple[bool, str]]
    phone_new_thread: Callable[[str], tuple[bool, str]]
    on_stop: Callable[[], Any]
    calibrate: Callable[[], float]
    record: Callable[..., Any]
    has_utterance: Callable[[Any, int], bool]
    voice_features: Callable[[Any, int], list[float] | None]
    copy_to_clipboard: Callable[[str], bool]
    type_text_hwnd: Callable[..., bool]
    is_paused: Callable[[], bool]
    python_executable: str
    load_config: Callable[[], dict]
    syslog: Callable[[str, str], None]
    speak: Callable[..., Any]
    shut_up: Callable[[], Any]
    beep: Callable[[int, int], Any]
    read_selected: Callable[[], Any]
    do_export: Callable[[], Any]
    do_import: Callable[[], Any]
    do_diagnose: Callable[[], Any]
    start_wake_test: Callable[[str], Any]
    runtime_lifecycle: Any
    get_reply_reader: Callable[[], Any]
    reply_reader_module: Any
    reload_phone_link: Callable[[], Any]
    phone_link_module: Any
    version_module: Any
    remote_access_module: Any
    chat_history_module: Any
    remote_factory: Callable[[Callable[[str], Any]], Any]
    self_who: Callable[[dict], str]
    ack_phrases: tuple[str, ...]
    list_chat_windows: Callable[[], list]
    last_sent: dict
    fatigue: dict
    last_unsent: dict
    chars_per_second: Callable[[Any, int, str], float]
    privacy_clean: Callable[[str], str]
    verify_delivery: Callable[..., Any]
    datetime_factory: Callable[[], Any]
    background_noise: Callable[..., bool]
    reload_wake_settings: Callable[[], Any]
    focus_tick: Callable[[], Any]
    night_diary: Callable[[], Any]
    reminders: Callable[[], Any]
    overlay_process: Any
    ticker: dict
    start_overlay: Callable[[], Any]
    no_overlay: bool
    feed: bool
    test_paste: bool
    mic_capture: dict
    clock: Callable[[], float]
    emit: Callable[..., Any] = print


@dataclass
class RuntimeServiceAssembly:
    """Expose the established service objects and their historical aliases."""

    phone_adapter: Any
    phone: Any
    phone_server: Any
    interaction: Any
    control_runtime: Any
    remote: Any
    reply_runtime: Any
    delivery_tracking: Any
    send_gate: Any
    overlay_liveness: Any
    periodic_runtime: Any


def assemble_runtime_services(
    deps: RuntimeServiceDependencies,
) -> RuntimeServiceAssembly:
    """Create the runtime stack in the same order as the legacy ``main()``."""
    handle_lock = deps.handle_lock
    phone_adapter = assemble_phone_adapter(
        RuntimePhoneAdapterDependencies(
            execute_command=lambda text: deps.handle_command(text),
            speech_context=deps.speech_context,
            thread_module="codex_threads",
            fallback_module="site_publish",
            reply_reader=deps.get_reply_reader,
            raw_replies_file=deps.app_dir / "phone-replies.jsonl",
            last_reply_file=deps.app_dir / "last-reply.json",
        )
    )

    phone = assemble_phone_runtime(
        PhoneRuntimeDependencies(
            config=deps.config,
            status=deps.status,
            busy=deps.busy,
            mute=deps.mute,
            reply_busy=phone_adapter.reply_busy,
            load_config=deps.load_config,
            syslog=deps.syslog,
            handle_lock=handle_lock,
            process_command=phone_adapter.process_command,
            pick_target=deps.pick_send_target,
            phone_window=deps.phone_window,
            focus_window=deps.focus_window,
            press_enter=deps.press_enter,
            paste_into=deps.paste_into,
            paste_clipboard=deps.paste_clipboard,
            image_to_clipboard=deps.image_to_clipboard,
            get_reply_reader=deps.get_reply_reader,
            current_thread_id=phone_adapter.current_thread_id,
            current_thread_name=phone_adapter.current_thread_name,
            transcriber=deps.transcriber,
            cancel_reference_echo=deps.cancel_reference_echo,
            rate=deps.rate,
            config_file=deps.config_file,
            suppressed=bool(deps.feed or deps.test_paste),
            phone_port=int(
                deps.config.get("phone_port")
                or deps.phone_link_module.DEFAULT_PORT
            ),
            syslog_file=deps.syslog_file,
            raw_replies_file=phone_adapter.raw_replies_file,
            last_reply_file=phone_adapter.last_reply_file,
            self_who=deps.self_who,
            ack_phrases=deps.ack_phrases,
            phone_window_title=lambda: str(
                deps.phone_window_state.get("title") or ""
            ),
            chat_history=deps.chat_history_module,
            phone_link_module=deps.phone_link_module,
            runtime_lifecycle=deps.runtime_lifecycle,
            on_stop=deps.on_stop,
            fallback_get_windows=deps.list_chat_windows,
            public_update_url=phone_adapter.public_update_url,
            pc_version=deps.phone_link_module.pc_version,
            phone_version=deps.phone_link_module.phone_app_version,
            version_module=deps.version_module,
            remote_access=deps.remote_access_module,
            get_target=lambda: str(
                deps.phone_window_state.get("title") or ""
            ),
            get_target_id=lambda: str(
                deps.phone_window_state.get("id") or ""
            ),
            on_target=deps.set_phone_window,
            on_thread_action=deps.phone_thread_action,
            on_new_thread=deps.phone_new_thread,
            log=deps.emit,
        )
    )
    phone_server = phone.start()
    pause = phone.pause

    interaction = RuntimeInteractionAssembly(
        RuntimeInteractionDependencies(
            args=deps.args,
            config=deps.config,
            config_file=deps.config_file,
            voiceprint_file=deps.voiceprint_file,
            wake_words=deps.wake_words,
            rate=deps.rate,
            transcriber=deps.transcriber,
            calibrate=deps.calibrate,
            record=deps.record,
            has_utterance=deps.has_utterance,
            voice_features=deps.voice_features,
            voiceprint=deps.voiceprint,
            speak=deps.speak,
            status=deps.status,
            syslog=deps.syslog,
            emit=deps.emit,
            load_config=deps.load_config,
            copy_to_clipboard=deps.copy_to_clipboard,
            paste_clipboard=deps.paste_clipboard,
            paste_into=deps.paste_into,
            type_text_hwnd=deps.type_text_hwnd,
            is_paused=deps.is_paused,
            level_state=deps.level_state,
            app_dir=deps.app_dir,
            python_executable=deps.python_executable,
        )
    )

    control_runtime = ControlRuntime(
        ControlRuntimeDependencies(
            args=deps.args,
            config=deps.config,
            config_file=deps.config_file,
            load_config=deps.load_config,
            wake_words=deps.wake_words,
            pause=pause,
            mute=deps.mute,
            status=deps.status,
            editing=deps.editing,
            hotkey=deps.hotkey,
            syslog=deps.syslog,
            beep=deps.beep,
            shut_up=deps.shut_up,
            runtime_lifecycle=deps.runtime_lifecycle,
            do_export=deps.do_export,
            do_import=deps.do_import,
            do_diagnose=deps.do_diagnose,
            restart_program=interaction.restart_program,
            start_wake_test=deps.start_wake_test,
            read_selected=deps.read_selected,
            manual_exit=deps.manual_exit,
            emit=deps.emit,
        )
    )
    remote = deps.remote_factory(control_runtime.remote_action)

    reply_runtime = RuntimeReplyAssembly(
        RuntimeReplyDependencies(
            reply_reader_module=deps.reply_reader_module,
            speak=deps.speak,
            syslog=deps.syslog,
            on_raw_reply=phone.raw_reply,
            busy=deps.busy,
            page_path=lambda: Path(
                deps.phone_link_module.__file__
            ).resolve(),
            reload_module=deps.reload_phone_link,
            emit=deps.emit,
            clock=deps.clock,
        )
    )
    delivery_tracking = RuntimeDeliveryAssembly(
        RuntimeDeliveryDependencies(
            config=deps.config,
            last_sent=deps.last_sent,
            fatigue=deps.fatigue,
            busy=deps.busy,
            last_unsent=deps.last_unsent,
            said_file=deps.said_file,
            thread_name=phone_adapter.current_thread_name,
            get_reply_reader=deps.get_reply_reader,
            chars_per_second=deps.chars_per_second,
            privacy_clean=deps.privacy_clean,
            verify_delivery=deps.verify_delivery,
            datetime_factory=deps.datetime_factory,
            clock=deps.clock,
            syslog=deps.syslog,
            status=deps.status,
            speak=deps.speak,
            emit=deps.emit,
        )
    )
    send_gate = RuntimeSendGateAssembly(
        RuntimeSendGateDependencies(
            pick_send_target=deps.pick_send_target,
            phone_window=deps.phone_window,
            phone_target=deps.phone_window_state,
            current_thread_name=phone_adapter.current_thread_name,
            switch_thread=phone_adapter.switch_thread,
            config=deps.config,
            voiceprint=deps.voiceprint,
            background_noise=deps.background_noise,
            status=deps.status,
            syslog=deps.syslog,
            emit=deps.emit,
        )
    )
    overlay_liveness = RuntimeOverlayLiveness(
        OverlayLivenessDependencies(
            config=deps.config,
            no_overlay=deps.no_overlay,
            feed=deps.feed,
            test_paste=deps.test_paste,
            overlay_process=deps.overlay_process,
            ticker=deps.ticker,
            start_overlay=deps.start_overlay,
            syslog=deps.syslog,
            emit=deps.emit,
            clock=deps.clock,
        )
    )
    periodic_runtime = RuntimePeriodicAssembly(
        RuntimePeriodicDependencies(
            remote_poll=remote.poll,
            reload_config=deps.reload_wake_settings,
            hot_reload_page=reply_runtime.hot_reload_page,
            focus_tick=deps.focus_tick,
            night_diary=deps.night_diary,
            check_hotkey=control_runtime.check_hotkey,
            reminders=deps.reminders,
            overlay_liveness=overlay_liveness.keep_alive,
            paused=lambda: bool(pause["paused"]),
            syslog=deps.syslog,
            emit=deps.emit,
        )
    )
    return RuntimeServiceAssembly(
        phone_adapter=phone_adapter,
        phone=phone,
        phone_server=phone_server,
        interaction=interaction,
        control_runtime=control_runtime,
        remote=remote,
        reply_runtime=reply_runtime,
        delivery_tracking=delivery_tracking,
        send_gate=send_gate,
        overlay_liveness=overlay_liveness,
        periodic_runtime=periodic_runtime,
    )


__all__ = [
    "RuntimeServiceAssembly",
    "RuntimeServiceDependencies",
    "assemble_runtime_services",
]
