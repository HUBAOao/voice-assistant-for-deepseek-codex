# -*- coding: utf-8 -*-
"""Morning briefing and theme rotation built on companion-feature state."""
from __future__ import annotations


THEMES = (
    {"name": "默认", "overlay_accent": "#3ddc84", "overlay_button": "#2f7f5a",
     "overlay_talk_color": "#4aa3ff", "overlay_wave_style": "siri"},
    {"name": "深海", "overlay_accent": "#38bdf8", "overlay_button": "#1d6f9c",
     "overlay_talk_color": "#a78bfa", "overlay_wave_style": "siri"},
    {"name": "蜜桃", "overlay_accent": "#fb7185", "overlay_button": "#9f4257",
     "overlay_talk_color": "#fbbf24", "overlay_wave_style": "siri"},
    {"name": "柠檬", "overlay_accent": "#facc15", "overlay_button": "#8a6d1a",
     "overlay_talk_color": "#22d3ee", "overlay_wave_style": "bars"},
)


class DailyFeatureMixin:
    """Routines that read the surrounding ambient runtime dependencies."""

    d: object
    read_ledger: object

    def brief_now(self) -> None:
        now = self.d.date_now()
        week = "一二三四五六日"[now.weekday()]
        head = f"现在是 {now.hour} 点 {now.minute:02d} 分，星期{week}。"
        items = []
        try:
            import sched as schedule

            entries = self.d.config.get("schedules") or []
            due = (
                schedule.due_today(entries, now)
                if hasattr(schedule, "due_today")
                else entries
            )
            for item in due:
                if item.get("time"):
                    items.append(
                        f"{item['time']} {item.get('text', '')}".strip()
                    )
        except Exception:
            items = []
        plan = (
            "今天的日程有：" + "；".join(items[:5]) + "。"
            if items
            else "今天没有安排日程。"
        )
        today = now.strftime("%Y-%m-%d")
        spent = sum(
            row["amount"]
            for row in self.read_ledger()
            if row.get("date") == today
        )
        money = f"今天已经花了 {spent:g} 块。" if spent else ""
        weather = ""
        if self.d.weather_line is not None:
            weather = self.d.weather_line(
                str(self.d.config.get("weather_city") or "").strip()
            )
        self.d.speak(head + plan + money + weather)
        print(
            f"   ↳ 🌅 早间播报：{head}{plan}{money}",
            flush=True,
        )
        self.d.status.set("sent", text="🌅 播报完成")

    def transform(self) -> None:
        fresh = self.d.load_config()
        names = [theme["name"] for theme in THEMES]
        current = str(fresh.get("theme") or names[0])
        next_theme = (
            THEMES[(names.index(current) + 1) % len(THEMES)]
            if current in names
            else THEMES[0]
        )
        fresh.update({
            key: value
            for key, value in next_theme.items()
            if key != "name"
        })
        fresh["theme"] = next_theme["name"]
        try:
            self.d.save_config(fresh)
        except Exception:
            pass
        self.d.speak(f"变身完成，现在是{next_theme['name']}")
        print(f"   ↳ ✨ 主题 → {next_theme['name']}", flush=True)
        self.d.status.set("sent", text=f"✨ {next_theme['name']}")
        self.d.beep(1180, 70)


__all__ = ["DailyFeatureMixin", "THEMES"]
