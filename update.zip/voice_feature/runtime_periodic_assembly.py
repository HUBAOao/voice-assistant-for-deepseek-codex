"""Assemble foreground periodic checks and overlay liveness outside ``main``."""
from __future__ import annotations

import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from voice_feature.runtime_ticker import RuntimeTicker


@dataclass(frozen=True)
class OverlayLivenessDependencies:
    """Bind the overlay supervisor to its launch flags and process factory."""

    config: Mapping
    no_overlay: bool
    feed: bool
    test_paste: bool
    overlay_process: Any
    ticker: dict
    start_overlay: Callable[[], Any]
    syslog: Callable[[str, str], None]
    emit: Callable[[str], None]
    clock: Callable[[], float] = time.time


class RuntimeOverlayLiveness:
    """Restart a vanished overlay at most once per thirty-second check."""

    def __init__(self, deps: OverlayLivenessDependencies) -> None:
        self.deps = deps
        self.process = deps.overlay_process

    def keep_alive(self) -> None:
        deps = self.deps
        if not deps.config.get("overlay_enabled", True):
            return
        if deps.no_overlay or deps.feed or deps.test_paste:
            return
        now = deps.clock()
        if now < deps.ticker.get("overlay_check", 0.0):
            return
        deps.ticker["overlay_check"] = now + 30
        if self.process is None:
            self.process = deps.start_overlay()
            return
        if self.process.poll() is None:
            return
        deps.emit("\n🪟 悬浮窗不在了，重新拉一个")
        deps.syslog("检", "悬浮窗退出过，已重新启动")
        self.process = deps.start_overlay()


@dataclass(frozen=True)
class RuntimePeriodicDependencies:
    """Callbacks consumed by one ordered foreground tick."""

    remote_poll: Callable[[], object]
    reload_config: Callable[[], object]
    hot_reload_page: Callable[[], object]
    focus_tick: Callable[[], object]
    night_diary: Callable[[], object]
    check_hotkey: Callable[[], object]
    reminders: Callable[[], object]
    overlay_liveness: Callable[[], object]
    paused: Callable[[], bool]
    syslog: Callable[[str, str], None]
    emit: Callable[[str], None]


class RuntimePeriodicAssembly:
    """Keep stage order and failure isolation while exposing one tick entry."""

    def __init__(self, deps: RuntimePeriodicDependencies) -> None:
        self.deps = deps
        self.ticker = RuntimeTicker(
            (
                ("remote", deps.remote_poll),
                ("config-reload", deps.reload_config),
                ("phone-page-reload", deps.hot_reload_page),
                ("focus", deps.focus_tick),
                ("night-diary", deps.night_diary),
                ("read-hotkey", deps.check_hotkey),
                ("reminders", deps.reminders),
                ("overlay-liveness", deps.overlay_liveness),
            ),
            on_error=self._report_failure,
        )

    def _report_failure(self, failure) -> None:
        detail = (
            f"{failure.stage}: "
            f"{type(failure.error).__name__}: {failure.error}"
        )
        self.deps.emit(f"   （周期任务失败，其他检查继续：{detail}）")
        self.deps.syslog(
            "检",
            f"周期任务失败（第 {failure.count} 次）：{detail[:180]}",
        )

    def tick(self) -> bool:
        """Run every foreground check and return the current pause state."""
        self.ticker.run()
        return self.deps.paused()


__all__ = [
    "OverlayLivenessDependencies",
    "RuntimeOverlayLiveness",
    "RuntimePeriodicAssembly",
    "RuntimePeriodicDependencies",
]
