# -*- coding: utf-8 -*-
"""Track a delivered message without keeping business state in ``main()``."""
from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeDeliveryDependencies:
    """State and callbacks used after the target window accepts a message."""

    config: dict
    last_sent: dict
    fatigue: dict
    busy: dict
    last_unsent: dict
    said_file: Path
    thread_name: Callable[[], str]
    get_reply_reader: Callable[[], Any]
    chars_per_second: Callable[[Any, int, str], float]
    privacy_clean: Callable[[str], str]
    verify_delivery: Callable[..., Any]
    datetime_factory: Callable[[], Any]
    clock: Callable[[], float]
    syslog: Callable[[str, str], Any]
    status: Any
    speak: Callable[..., Any]
    emit: Callable[..., Any]
    thread_factory: Callable[..., Any] = threading.Thread


class RuntimeDeliveryAssembly:
    """Keep post-send bookkeeping deterministic and independently testable."""

    def __init__(self, deps: RuntimeDeliveryDependencies) -> None:
        self.deps = deps

    def after_sent(
        self,
        *,
        text: str,
        hwnd: int,
        title: str,
        audio: Any,
        sr: int,
        from_phone: bool,
        mood: str,
    ) -> bool:
        deps = self.deps
        now = deps.clock()
        deps.last_sent["text"] = text
        deps.last_sent["at"] = now

        watched = False
        reader = deps.get_reply_reader()
        if reader is not None and deps.config.get("read_reply", True) and (
            hwnd or from_phone
        ):
            try:
                conversation_name = str(deps.thread_name() or "")
            except Exception:
                conversation_name = ""
            reader.watch(
                hwnd,
                text,
                seconds=900,
                max_chars=20000,
                title=conversation_name or title,
                speak=not from_phone,
            )
            deps.emit(
                "   ↳ 🔊 开始念回答（说「停」就不念了；"
                "不想要可在设置里关掉）",
                flush=True,
            )
            watched = True

        if mood:
            deps.fatigue["speeds"].append(
                deps.chars_per_second(audio, sr, text)
            )
            deps.fatigue["speeds"][:] = deps.fatigue["speeds"][-40:]

        try:
            with deps.said_file.open("a", encoding="utf-8") as handle:
                stamp = deps.datetime_factory().strftime("%Y-%m-%d %H:%M:%S")
                handle.write(f"- {stamp} {deps.privacy_clean(text)}\n")
        except Exception:
            pass

        deps.busy["on"] = True
        deps.busy["at"] = now
        deps.thread_factory(
            target=lambda: deps.verify_delivery(
                text,
                hwnd,
                silent=from_phone,
                syslog=deps.syslog,
                status=deps.status,
                speak=deps.speak,
                last_unsent=deps.last_unsent,
            ),
            daemon=True,
        ).start()
        return watched


__all__ = [
    "RuntimeDeliveryAssembly",
    "RuntimeDeliveryDependencies",
]
