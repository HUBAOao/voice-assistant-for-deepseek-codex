"""Wire command and wake gates without rebuilding their order in ``main()``."""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.runtime_command_gate_assembly import (
    RuntimeCommandGateDependencies,
)
from voice_feature.runtime_gate_assembly import (
    RuntimeGateAssemblyDependencies,
    RuntimeGateRuntime,
    assemble_runtime_gates,
)
from voice_feature.runtime_wake_gate_assembly import (
    RuntimeWakeGateDependencies,
)


@dataclass(frozen=True)
class RuntimeGateWiringDependencies:
    """Runtime callbacks shared by command and wake admission."""

    speaking_now: Callable[[], bool]
    shut_up: Callable[[], Any]
    stop_words: Iterable[str]
    is_stop_word: Callable[[str, Iterable[str]], bool]
    last_unsent: dict
    pick_send_target: Callable[[], tuple[int, str]]
    send: Callable[[str, int], bool]
    busy: dict
    status: Any
    speak: Callable[[str], Any]
    syslog: Callable[[str, str], Any]
    emit: Callable[[str], Any]
    mute: dict
    mute_command: Callable[..., str]
    dispatch_mute: Callable[..., bool]
    self_speech: dict
    self_voice_miss: dict
    self_spoken_text: Callable[[], str]
    recent_spoken: Callable[[], Iterable[str]]
    sounds_like: Callable[[str, str], bool]
    repeated_after_miss: Callable[[str, dict], bool]
    extract_word: Callable[..., tuple[str, str]]
    wake_words: list[str]
    wake_level: Mapping[str, Any]
    dictation: Any
    is_standalone_command: Callable[[str], bool]
    dispatch_dictation: Callable[..., bool]
    beep: Callable[[int, int], Any]
    type_text: Callable[[str], Any]
    syslog_file: Path
    cancel_words: list[str]
    listen_timeout: float
    talk_state: Any
    looks_like_wake: Callable[[str, list[str]], bool]
    cancel_hit: Callable[[str, list[str]], bool]
    wake_voice_ok: Callable[[Any], bool]
    award: Callable[[str], Any]
    arm_followup: Callable[[], Any]
    once: bool
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], Any] = time.sleep


def assemble_runtime_gate_wiring(
    deps: RuntimeGateWiringDependencies,
) -> RuntimeGateRuntime:
    """Translate the runtime callback set into the two ordered gates.

    The callback wiring is intentionally kept in one place so ``main()`` only
    hands over concrete runtime services. The lower-level assembly still owns
    the command order, wake order and structured-action completion semantics.
    """
    command = RuntimeCommandGateDependencies(
        speaking_now=deps.speaking_now,
        shut_up=deps.shut_up,
        stop_words=deps.stop_words,
        is_stop_word=deps.is_stop_word,
        last_unsent=deps.last_unsent,
        pick_send_target=deps.pick_send_target,
        send=deps.send,
        busy=deps.busy,
        status=deps.status,
        speak=deps.speak,
        syslog=deps.syslog,
        emit=deps.emit,
        mute=deps.mute,
        mute_command=deps.mute_command,
        dispatch_mute=deps.dispatch_mute,
        self_speech=deps.self_speech,
        self_voice_miss=deps.self_voice_miss,
        self_spoken_text=deps.self_spoken_text,
        recent_spoken=deps.recent_spoken,
        sounds_like=deps.sounds_like,
        repeated_after_miss=deps.repeated_after_miss,
        extract_word=deps.extract_word,
        wake_words=deps.wake_words,
        wake_level=deps.wake_level,
        dictation=deps.dictation,
        is_standalone_command=deps.is_standalone_command,
        dispatch_dictation=deps.dispatch_dictation,
        beep=deps.beep,
        type_text=deps.type_text,
        syslog_file=deps.syslog_file,
        clock=deps.clock,
        sleep=deps.sleep,
    )
    wake = RuntimeWakeGateDependencies(
        wake_words=deps.wake_words,
        wake_level=deps.wake_level,
        cancel_words=deps.cancel_words,
        listen_timeout=deps.listen_timeout,
        talk_state=deps.talk_state,
        extract_word=deps.extract_word,
        looks_like_wake=deps.looks_like_wake,
        cancel_hit=deps.cancel_hit,
        wake_voice_ok=deps.wake_voice_ok,
        beep=deps.beep,
        award=deps.award,
        status=deps.status,
        syslog=deps.syslog,
        emit=deps.emit,
        sleep=deps.sleep,
    )
    return assemble_runtime_gates(
        RuntimeGateAssemblyDependencies(
            command=command,
            wake=wake,
            arm_followup=deps.arm_followup,
            once=deps.once,
            sleep=deps.sleep,
        )
    )


__all__ = [
    "RuntimeGateWiringDependencies",
    "assemble_runtime_gate_wiring",
]
