"""Prepare one process entry without keeping its ordering inside ``main``.

The foreground ``main`` should receive a fully prepared audio session and
session-state object.  Startup, utility modes, audio discovery and state
creation stay ordered here so their exit paths can be tested independently.
"""
from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

from voice_feature.runtime_audio_setup import (
    AudioRuntimeDependencies,
    AudioRuntimeSession,
    prepare_audio_runtime,
)
from voice_feature.runtime_bootstrap import (
    RuntimeBootstrapDependencies,
    RuntimeBootstrapResult,
    prepare_runtime,
)
from voice_feature.runtime_cli_modes import (
    RuntimeCliModeDependencies,
    run_cli_mode,
)
from voice_feature.runtime_lifecycle import RuntimeLifecycle


@dataclass(frozen=True)
class RuntimeEntryDependencies:
    """Bound services and exact values needed before the voice loop starts."""

    raw_args: Sequence[str]
    lifecycle: RuntimeLifecycle
    bootstrap: RuntimeBootstrapDependencies
    cli: RuntimeCliModeDependencies
    audio: AudioRuntimeDependencies
    make_tracker: Callable[[], Any]
    create_session_state: Callable[..., Any]
    stop_words: Sequence[str]
    emit: Callable[[str], object] = print


@dataclass(frozen=True)
class RuntimeEntryResult:
    """Prepared entry state, or the historical early-exit return code."""

    startup: RuntimeBootstrapResult | None
    audio: AudioRuntimeSession | None
    tracker: Any
    session_state: Any
    exit_code: int | None


def prepare_runtime_entry(
    dependencies: RuntimeEntryDependencies,
) -> RuntimeEntryResult:
    """Prepare startup, utility modes and the voice input session in order."""
    deps = dependencies
    startup = prepare_runtime(
        deps.raw_args,
        deps.bootstrap,
        deps.lifecycle,
    )
    if startup is None:
        return RuntimeEntryResult(None, None, None, None, 0)

    cfg = startup.cfg
    if cfg:
        deps.emit(
            f"（已读 config.json：唤醒词「{cfg.get('wake_word', '大肥鱼')}」"
            f"，模型 {cfg.get('model', 'small')}）"
        )

    cli_result = run_cli_mode(startup.args, deps.cli)
    if cli_result is not None:
        return RuntimeEntryResult(startup, None, None, None, cli_result)

    try:
        audio = prepare_audio_runtime(
            startup.args,
            cfg,
            startup.profile,
            startup.hardware,
            deps.audio,
        )
    except SystemExit as exc:
        deps.emit(str(exc))
        deps.cli.list_devices()
        return RuntimeEntryResult(startup, None, None, None, 2)

    tracker = deps.make_tracker() if audio.mode == "talk" else None
    session_state = deps.create_session_state(
        cfg,
        audio.mode,
        audio.wake_words,
        startup.args.wake_timeout,
        deps.stop_words,
    )
    return RuntimeEntryResult(
        startup,
        audio,
        tracker,
        session_state,
        None,
    )


__all__ = [
    "RuntimeEntryDependencies",
    "RuntimeEntryResult",
    "prepare_runtime_entry",
]
