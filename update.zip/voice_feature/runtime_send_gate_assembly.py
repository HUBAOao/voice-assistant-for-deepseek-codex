# -*- coding: utf-8 -*-
"""Select a delivery target and apply the final background-voice gate."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping


@dataclass(frozen=True)
class RuntimeSendGateDependencies:
    pick_send_target: Callable[[], tuple[int, str]]
    phone_window: Callable[[], tuple[int, str]]
    phone_target: Mapping[str, str]
    current_thread_name: Callable[[], str]
    switch_thread: Callable[[str, str], Any]
    config: Mapping[str, Any]
    voiceprint: Mapping[str, Any]
    background_noise: Callable[
        [str, float | None, float | None, bool, Any], bool
    ]
    status: Any
    syslog: Callable[[str, str], None]
    emit: Callable[..., None]
    sleep: Callable[[float], None] = time.sleep


@dataclass(frozen=True)
class RuntimeSendGateResult:
    allowed: bool
    hwnd: int = 0
    title: str = ""


class RuntimeSendGateAssembly:
    """Keep target selection and the final voice gate outside ``main()``."""

    def __init__(self, dependencies: RuntimeSendGateDependencies) -> None:
        self.dependencies = dependencies

    def _resolve_target(self, from_phone: bool) -> tuple[int, str]:
        deps = self.dependencies
        hwnd, title = deps.pick_send_target()
        if not from_phone:
            return hwnd, title

        phone_hwnd, phone_title = deps.phone_window()
        if not phone_hwnd:
            return hwnd, title
        hwnd, title = phone_hwnd, phone_title
        wanted = str(deps.phone_target.get("title") or "").strip()
        if not wanted or wanted == title:
            return hwnd, title
        try:
            if deps.current_thread_name() != wanted:
                deps.switch_thread(
                    wanted,
                    str(deps.phone_target.get("id") or ""),
                )
                deps.sleep(0.35)
                deps.emit(
                    f"   ↳ 手机选的是「{wanted}」，已经切过去了",
                    flush=True,
                )
        except Exception:
            pass
        return hwnd, title

    def prepare(self, text: str, *, from_phone: bool) -> RuntimeSendGateResult:
        deps = self.dependencies
        hwnd, title = self._resolve_target(from_phone)
        last_score = deps.voiceprint.get("last_score")
        wake_score = deps.voiceprint.get("wake_score")
        if deps.background_noise(
            text,
            last_score,
            wake_score,
            bool(deps.config.get("voiceprint_gate", False)),
            deps.config.get("background_min_score"),
        ):
            deps.emit(
                f"   ↳ 🔇 不像你的声音（{last_score:.2f}）又很短，当背景音丢了",
                flush=True,
            )
            deps.syslog(
                "噪",
                f"（背景音，声纹 {last_score:.2f}）{text[:30]}",
            )
            deps.status.set("idle", text="")
            return RuntimeSendGateResult(False)
        return RuntimeSendGateResult(True, hwnd, title)


__all__ = [
    "RuntimeSendGateAssembly",
    "RuntimeSendGateDependencies",
    "RuntimeSendGateResult",
]
