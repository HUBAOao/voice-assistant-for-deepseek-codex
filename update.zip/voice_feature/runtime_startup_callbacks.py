"""Own startup state restoration and small desktop entrypoint callbacks."""
from __future__ import annotations

from collections.abc import Callable, Iterable, MutableMapping
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SavedRuntimeTargets:
    """Mutable process targets restored from the persisted configuration."""

    phone_window: MutableMapping[str, Any]
    mute: MutableMapping[str, Any]

    def restore(self, saved: MutableMapping[str, Any]) -> None:
        self.phone_window["title"] = str(saved.get("phone_target") or "")
        self.phone_window["id"] = str(
            saved.get("phone_target_id") or ""
        )
        self.mute["on"] = bool(saved.get("muted", False))


@dataclass(frozen=True)
class DesktopCallbackDependencies:
    """Late-bound state and existing services used by entrypoint callbacks."""

    wake_words: Iterable[str]
    talk_state: Any
    followup_seconds: float
    status_provider: Callable[[], Any]
    bump_achievements: Callable[[str], Iterable[str]]
    speak: Callable[[str], Any]
    beep: Callable[[int, int], Any]
    selected_text: Callable[[], str]
    syslog: Callable[[str, str], Any]
    emit: Callable[[str], Any]
    spoken_flag: MutableMapping[str, Any]


class DesktopRuntimeCallbacks:
    """Keep historical callback order while leaving ``main()`` declarative."""

    def __init__(self, deps: DesktopCallbackDependencies) -> None:
        self.deps = deps

    def arm_followup(self) -> None:
        deps = self.deps
        if not deps.wake_words or not deps.talk_state.arm_followup():
            return
        deps.emit(
            f"   ↳ 接着说要问的就行（{deps.followup_seconds:g} 秒内免唤醒）"
        )
        deps.status_provider().set(
            "listening",
            text="",
            hint=(
                "接着说就行"
                f"（{deps.followup_seconds:g} 秒内免唤醒）"
            ),
        )

    def award(self, kind: str) -> None:
        deps = self.deps
        for name in deps.bump_achievements(kind):
            deps.speak(f"解锁成就：{name}")
            deps.status_provider().set("sent", text=f"🏆 {name}")
            deps.emit(f"   ↳ 🏆 解锁成就：{name}")
            deps.beep(1320, 90)

    def say_selected(self) -> None:
        deps = self.deps
        text = deps.selected_text()
        if not text:
            deps.speak("没选中文字哦")
            return
        deps.speak(text)
        deps.syslog("读", f"朗读选中 {len(text)} 字")
        deps.emit(f"   ↳ 🔊 朗读选中：{text[:30]}")
        deps.status_provider().set(
            "sent", text=f"🔊 朗读选中 {len(text)} 字"
        )

    def on_speech(self) -> None:
        deps = self.deps
        if deps.spoken_flag["first"]:
            deps.spoken_flag["first"] = False
            deps.emit("\r🎙 听到声音，正在识别…" + " " * 10)
        else:
            deps.emit("\r🎙 正在识别…" + " " * 20)


__all__ = [
    "DesktopCallbackDependencies",
    "DesktopRuntimeCallbacks",
    "SavedRuntimeTargets",
]
