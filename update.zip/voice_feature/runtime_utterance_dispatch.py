# -*- coding: utf-8 -*-
"""Own the late-bound single-utterance dispatch used by the foreground loop."""
from __future__ import annotations

import threading
from collections.abc import Callable
from typing import Any


class UtteranceDispatch:
    """Wait for the runtime assembly, then forward one utterance unchanged."""

    def __init__(
        self,
        *,
        timeout: float = 30.0,
        emit: Callable[[str], Any] = print,
    ) -> None:
        self.timeout = timeout
        self.emit = emit
        self._runtime: Any = None
        self._ready = threading.Event()

    def bind(self, runtime: Any) -> None:
        """Publish the fully wired runtime before any audio reaches it."""
        self._runtime = runtime
        self._ready.set()

    def handle(
        self,
        audio: Any,
        sr: int | None = None,
        pre_text: str | None = None,
        from_phone: bool = False,
    ) -> bool:
        """Preserve the historical readiness timeout and process signature."""
        if not self._ready.wait(self.timeout):
            self.emit("（语音处理装配还没准备好，这句先跳过）")
            return False
        return self._runtime.process(
            audio,
            sr=sr,
            pre_text=pre_text,
            from_phone=from_phone,
        )


__all__ = ["UtteranceDispatch"]
