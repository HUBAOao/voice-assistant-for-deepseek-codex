# -*- coding: utf-8 -*-
"""Tutorial narration and nightly diary business with injected dependencies."""
from __future__ import annotations

import json
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


TUTORIAL = [
    ("唤醒", "先说唤醒词，听到两声提示音，再讲你要问的。也可以一口气说完："
             "「{wake}，帮我查一下明天的天气」。没喊唤醒词的话，你说的话会被忽略，不会乱发。"),
    ("停下就发", "说完停一下，它自己就识别、自己发出去，不用按任何键。"
                 "说快了没听清，它会说一句「没听清，再说一遍」。"),
    ("接着说", "喊一次唤醒词之后，八秒内接着说就不用再喊了。想改这个时间：设置 → 智能 → 连续对话。"),
    ("暂停和继续", "按键盘上的减号「-」暂停；或者点悬浮窗右边那个开关。"
                   "暂停时它照样在录音，只是不发出去，随时能恢复。"),
    ("悬浮窗", "平时只有名字、状态、开关和底部一条声音波浪。有声音时波浪铺满底部、上下抖；"
               "没声音就缩成中间一个小圆球。我说话的时候它会换成蓝色，说完慢慢变回来。"),
    ("设置在这里", "点悬浮窗右下角的小箭头，它会平滑长大，下半部分就是设置，不用另开窗口。"
                   "一开始是「基本」页，上面有名字、唤醒词、问候语、你的称呼。"),
    ("六个标签页", "基本管称呼和唤醒；声音管音量、语速、八种音色；外观管颜色、背景、特效；"
                   "布局能把每个元素拖到你想要的位置；智能放性能和各种开关；日程是日历和时间表。"),
    ("喊不醒怎么办", "设置 → 基本 → 唤醒档位，有严格、标准、宽松、极宽松四档，越往右越灵敏。"
                     "还能点「＋自定」自己加一档。改完唤醒词它会自动跑一次自检，把结果念给你听。"),
    ("声音条特效", "外观页里有五个开关：视觉暂留会拖一条慢慢淡掉的残影，呼吸光晕、星尘、倒影、流光。"
                   "节能模式下它们会自动关掉。"),
    ("番茄钟", "说「专注二十五分钟」或「番茄钟」，声音条会变成一根越来越短的倒计时条，"
               "到点它念你去休息。问「还有多久」它告诉你，说「结束专注」就停。"),
    ("便签和记账", "说「记一下 明天买牛奶」存便签，说「念一下笔记」它念给你听；"
                   "说「记一笔 买菜三十」记账，问「今天花了多少」它报今天和这个月的合计。"),
    ("日程表", "设置 → 日程，日历上点某一天，那天会放大成时间表；"
               "把右边抽屉里的模块拖进去就能定时：提醒模块只念给你听，指令模块会替你发出去。"),
    ("让它闭嘴", "它念到一半你喊「停」「别念了」它立刻停；也可以直接喊唤醒词抢话，"
                 "它会先闭嘴再听你说。它朗读的时候麦克风是闭着的，不会把自己的声音当指令。"),
    ("隐私", "说到密码、身份证、银行卡这类词，那一行不会被记下来；"
             "说「别记这段」它会静默五分钟；说「清空所有记录」再「确定清空」能把便签、记账、记忆和日志全清掉。"),
    ("让它当打字员", "说「开始听写」，之后你说的话会直接打进光标位置，不发到聊天窗口；说「停止听写」结束。"
                     "选中一段文字按 Ctrl+Alt+R，它会念给你听。"),
    ("出问题了怎么办", "说「自检」查麦克风、模型、窗口、剪贴板；说「打包诊断」会把日志打成一个包，"
                       "藏在程序目录那个隐藏的「导出」文件夹里，设置里点「打开文件夹」就能看到；"
                       "右下角托盘图标里能打开设置、暂停、重启、退出。主程序要是挂了，看门狗会自动把它拉起来。"),
    ("教程结束", "这些记不住也没关系，随时说「教程」我再讲一遍。"
                 "想直接跳到哪一步，说「讲第几课」就行。"),
]


@dataclass(frozen=True)
class DiaryTutorialDependencies:
    status: Any
    speak: Callable[[str], Any]
    syslog: Callable[[str, str], Any]
    config: Mapping[str, Any]
    wake_words: Sequence[str]
    diary_summary: Callable[[str], str]
    read_achievements: Callable[[], dict]
    write_achievements: Callable[[dict], Any]
    diary_file: Path
    now: Callable[[], datetime] = datetime.now
    emit: Callable[[str], Any] = print


class DiaryTutorialRuntime:
    """Own tutorial state and diary writes without depending on ``main()``."""

    def __init__(self, dependencies: DiaryTutorialDependencies) -> None:
        self.d = dependencies
        self.state = {"on": False, "step": 0}

    def tutorial_say(self, index: int) -> None:
        if not (0 <= index < len(TUTORIAL)):
            self.state["on"] = False
            self.d.speak("教程讲完了")
            self.d.status.set("idle")
            return
        self.state.update(on=True, step=index)
        title, body = TUTORIAL[index]
        wake = self.d.wake_words[0] if self.d.wake_words else "大肥鱼"
        text = body.replace("{wake}", wake)
        self.d.speak(f"第 {index + 1} 课，{title}。{text}")
        self.d.emit(
            f"   ↳ 📘 教程 {index + 1}/{len(TUTORIAL)}：{title}"
        )
        self.d.syslog("教", f"第 {index + 1} 课：{title}")
        self.d.status.set(
            "sent",
            text=f"📘 {index + 1}/{len(TUTORIAL)} {title}",
        )

    def say_diary(self) -> str:
        day = self.d.now().strftime("%Y-%m-%d")
        text = self.d.diary_summary(day)
        self.d.speak(text)
        try:
            with self.d.diary_file.open("a", encoding="utf-8") as handle:
                handle.write(f"## {day}\n\n{text}\n\n")
        except Exception:
            pass
        self.d.emit(f"   ↳ 📔 日记：{text[:50]}")
        self.d.status.set("sent", text="📔 日记已生成")
        return text

    def maybe_night_diary(self) -> None:
        """Read tonight's diary once after the configured hour."""
        if not self.d.config.get("diary_enabled", True):
            return
        hour = int(self.d.config.get("diary_hour") or 22)
        now = self.d.now()
        today = now.strftime("%Y-%m-%d")
        data = self.d.read_achievements()
        if now.hour < hour or data.get("diary_day") == today:
            return
        data["diary_day"] = today
        try:
            self.d.write_achievements(data)
        except Exception:
            pass
        self.d.emit("   ↳ 📔 晚间日记时间")
        self.say_diary()

    @staticmethod
    def encode_achievements(data: dict) -> str:
        """JSON encoding kept here so the host can provide atomic writes."""
        return json.dumps(data, ensure_ascii=False)


__all__ = [
    "DiaryTutorialDependencies",
    "DiaryTutorialRuntime",
    "TUTORIAL",
]
