# -*- coding: utf-8 -*-
"""Assemble desktop runtimes without crowding the STT lifecycle entrypoint."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.ambient_features import (
    AmbientFeatureDependencies,
    AmbientFeatureRuntime,
)
from voice_feature.diary_tutorial_runtime import (
    DiaryTutorialDependencies,
    DiaryTutorialRuntime,
)
from voice_feature.maintenance_runtime import (
    MaintenanceRuntime,
    MaintenanceRuntimeDependencies,
)


@dataclass(frozen=True)
class DesktopRuntimeDependencies:
    status_factory: Callable[[str], Any]
    hint: str
    config: Mapping[str, Any]
    wake_words: list[str]
    speak: Callable[..., Any]
    syslog: Callable[[str, str], None]
    beep: Callable[[int, int], Any]
    arm_followup: Callable[[], Any]
    award: Callable[[str], Any]
    load_config: Callable[[], dict]
    save_config: Callable[[dict], Any]
    diary_summary: Callable[..., str]
    read_achievements: Callable[[], dict]
    write_achievements: Callable[[dict], Any]
    diary_file: Path
    now: Callable[[], Any]
    notes_file: Path
    ledger_file: Path
    weather_line: Callable[[str], str]
    private: dict
    last_sent: dict
    transcriber: Any
    target: str | None
    current_target_hwnd: Callable[[], int]
    query_device: Callable[[Any], dict]
    device: Any
    find_window: Callable[[str], tuple[int, str]]
    clipboard_text: Callable[[], str]
    copy_to_clipboard: Callable[[str], bool]
    paste_clipboard: Callable[..., Any]
    paste_into: Callable[..., bool]
    focus_window: Callable[[int], bool]
    send_ctrl_z: Callable[[], Any]
    export_data: Callable[..., Any]
    import_data: Callable[..., Any]
    diag_pack: Callable[..., Any]
    newer_package: Callable[..., Any]
    apply_update: Callable[..., Any]
    lifecycle: Any
    crash_file: Path
    no_overlay: bool
    feed: Any
    test_paste: bool
    start_overlay: Callable[[], Any]
    start_pet: Callable[[], Any]
    start_watchdog: Callable[[], Any]
    start_tray: Callable[[], Any]
    emit: Callable[..., Any]
    self_check_delay: float = 7


@dataclass
class DesktopRuntimeAssembly:
    status: Any
    diary: Any
    ambient: Any
    maintenance: Any
    overlay: Any
    pet_proc: dict[str, Any]
    interactive: bool

    @property
    def tutorial(self) -> Any:
        return self.diary.state

    @property
    def tutorial_say(self) -> Callable[..., Any]:
        return self.diary.tutorial_say

    @property
    def say_diary(self) -> Callable[..., Any]:
        return self.diary.say_diary

    @property
    def maybe_night_diary(self) -> Callable[..., Any]:
        return self.diary.maybe_night_diary

    @property
    def focus_active(self) -> Callable[..., Any]:
        return self.ambient.focus_active

    @property
    def focus_left(self) -> Callable[..., Any]:
        return self.ambient.focus_left

    @property
    def focus_start(self) -> Callable[..., Any]:
        return self.ambient.focus_start

    @property
    def focus_stop(self) -> Callable[..., Any]:
        return self.ambient.focus_stop

    @property
    def focus_tick(self) -> Callable[..., Any]:
        return self.ambient.focus_tick

    @property
    def read_ledger(self) -> Callable[..., Any]:
        return self.ambient.read_ledger

    @property
    def add_note(self) -> Callable[..., Any]:
        return self.ambient.add_note

    @property
    def add_ledger(self) -> Callable[..., Any]:
        return self.ambient.add_ledger

    @property
    def say_ledger(self) -> Callable[..., Any]:
        return self.ambient.say_ledger

    @property
    def say_notes(self) -> Callable[..., Any]:
        return self.ambient.say_notes

    @property
    def game_start(self) -> Callable[..., Any]:
        return self.ambient.game_start

    @property
    def do_pick(self) -> Callable[..., Any]:
        return self.ambient.do_pick

    @property
    def game_feed(self) -> Callable[..., Any]:
        return self.ambient.game_feed

    @property
    def brief_now(self) -> Callable[..., Any]:
        return self.ambient.brief_now

    @property
    def transform(self) -> Callable[..., Any]:
        return self.ambient.transform

    @property
    def self_check(self) -> Callable[..., Any]:
        return self.maintenance.self_check

    @property
    def do_export(self) -> Callable[..., Any]:
        return self.maintenance.do_export

    @property
    def do_import(self) -> Callable[..., Any]:
        return self.maintenance.do_import

    @property
    def do_diagnose(self) -> Callable[..., Any]:
        return self.maintenance.do_diagnose

    @property
    def do_update(self) -> Callable[..., Any]:
        return self.maintenance.do_update

    @property
    def apply_update_now(self) -> Callable[..., Any]:
        return self.maintenance.apply_update_now

    @property
    def undo_last(self) -> Callable[..., Any]:
        return self.maintenance.undo_last

    @property
    def type_into_focused(self) -> Callable[..., Any]:
        return self.maintenance.type_into_focused


def assemble_desktop_runtime(
    deps: DesktopRuntimeDependencies,
) -> DesktopRuntimeAssembly:
    """Create desktop services in the legacy order and start optional helpers."""
    status = deps.status_factory(deps.hint)
    status.set("starting")

    diary = DiaryTutorialRuntime(
        DiaryTutorialDependencies(
            status=status,
            speak=deps.speak,
            syslog=deps.syslog,
            config=deps.config,
            wake_words=deps.wake_words,
            diary_summary=deps.diary_summary,
            read_achievements=deps.read_achievements,
            write_achievements=deps.write_achievements,
            diary_file=deps.diary_file,
            now=deps.now,
            emit=deps.emit,
        )
    )
    ambient = AmbientFeatureRuntime(
        AmbientFeatureDependencies(
            status=status,
            speak=deps.speak,
            beep=deps.beep,
            arm_followup=deps.arm_followup,
            award=deps.award,
            config=deps.config,
            load_config=deps.load_config,
            save_config=deps.save_config,
            notes_file=deps.notes_file,
            ledger_file=deps.ledger_file,
            weather_line=deps.weather_line,
        )
    )
    interactive = not (deps.no_overlay or deps.feed or deps.test_paste)
    overlay = (
        deps.start_overlay()
        if interactive and deps.config.get("overlay_enabled", True)
        else None
    )
    maintenance = MaintenanceRuntime(
        MaintenanceRuntimeDependencies(
            status=status,
            speak=deps.speak,
            syslog=deps.syslog,
            config=deps.config,
            private=deps.private,
            last_sent=deps.last_sent,
            transcriber=deps.transcriber,
            target=deps.target,
            overlay_running=overlay is not None,
            overlay_disabled=deps.no_overlay,
            current_target_hwnd=deps.current_target_hwnd,
            query_device=deps.query_device,
            device=deps.device,
            find_window=deps.find_window,
            clipboard_text=deps.clipboard_text,
            copy_to_clipboard=deps.copy_to_clipboard,
            paste_clipboard=deps.paste_clipboard,
            paste_into=deps.paste_into,
            focus_window=deps.focus_window,
            send_ctrl_z=deps.send_ctrl_z,
            export_data=deps.export_data,
            import_data=deps.import_data,
            diag_pack=deps.diag_pack,
            newer_package=deps.newer_package,
            apply_update=deps.apply_update,
            emit=deps.emit,
        )
    )

    pet_proc: dict[str, Any] = {"p": None}
    if interactive and deps.config.get("pet_enabled", True):
        pet_proc["p"] = deps.start_pet()

    if deps.crash_file.exists():
        try:
            deps.crash_file.unlink()
        except Exception:
            pass
        deps.syslog("检", "上次异常退出，本次已恢复")
        deps.speak("上次我出了点问题，现在恢复了")

    if interactive:
        deps.lifecycle.start_daemon(
            "startup-self-check",
            lambda: maintenance.self_check(True),
            delay=deps.self_check_delay,
        )
        deps.start_watchdog()
        if deps.config.get("tray_enabled", True):
            deps.start_tray()

    return DesktopRuntimeAssembly(
        status=status,
        diary=diary,
        ambient=ambient,
        maintenance=maintenance,
        overlay=overlay,
        pet_proc=pet_proc,
        interactive=interactive,
    )
