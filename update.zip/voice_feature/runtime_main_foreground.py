"""Start the prepared foreground runtime without leaving its wiring in ``main``."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.runtime_entry_pipeline import RuntimeEntryResult
from voice_feature.runtime_foreground_assembly import (
    ForegroundRuntimeDependencies,
    assemble_foreground_runtime,
)


@dataclass(frozen=True)
class ForegroundPlatformDependencies:
    """Process-level callbacks shared by feed and live microphone modes."""

    find_window: Callable[[str], tuple[int, str]]
    paste_text: Callable[..., None]
    record_ptt: Callable[[Any], Any]
    has_utterance: Callable[[Any, int], bool]
    level_state: Callable[[float], str]
    resolve_device: Callable[[Any], Any]
    open_stream: Callable[[Any], tuple[Any, int]]
    make_recorder: Callable[..., Any]
    syslog: Callable[[str, str], object]
    shut_up: Callable[[], object]
    speaking_now: Callable[[], bool]
    duplex: Mapping
    cancel_reference_echo: Callable[[Any, int], Any]
    spectrum_bands: Callable[..., list[float]]
    transcriber: Any
    key_watcher_factory: Callable[[str], Any]
    tracker_worker_factory: Callable[[Any], Any]
    start_scheduler: Callable[
        [Callable[[], int], Callable[[str, int], None]],
        object,
    ]
    build_greeting: Callable[[dict, str], str]
    speak_greeting: Callable[[str, float], object]
    speak: Callable[[str], object]
    beep: Callable[[int, int], object]
    crash_file: Path
    emit: Callable[..., object]
    decode_audio_file: Callable[[str], Any]
    target_rate: int


@dataclass(frozen=True)
class PreparedForegroundDependencies:
    """Prepared entry objects plus the final foreground callbacks."""

    entry: RuntimeEntryResult
    handle: Callable[..., Any]
    handle_lock: Any
    services: Any
    status: Any
    lifecycle: Any
    on_speech: Callable[[], object]
    platform: ForegroundPlatformDependencies


def run_prepared_foreground(dependencies: PreparedForegroundDependencies) -> int:
    """Run feed mode or the live foreground loop in the historical order."""
    deps = dependencies
    entry = deps.entry
    startup = entry.startup
    audio = entry.audio
    session_state = entry.session_state
    assert startup is not None and audio is not None
    assert session_state is not None
    (
        spoken_flag,
        _stop_words,
        self_speech,
        _self_voice_miss,
        _dictation,
        music,
        _last_sent,
        _hotkey,
        _sit,
        _hourly,
        _fatigue,
        _ticker,
        _voiceprint,
        _editing,
        _pet_proc,
        _not_heard,
        hint,
        _followup,
        _talk_state,
        mic_capture,
    ) = session_state.as_tuple()
    services = deps.services
    platform = deps.platform
    args = startup.args
    pause = services.phone.pause

    if args.feed:
        for path in args.feed:
            print(f"\n▶ 测试音频：{Path(path).name}")
            deps.handle(
                platform.decode_audio_file(path),
                platform.target_rate,
            )
        return 0

    return assemble_foreground_runtime(
        ForegroundRuntimeDependencies(
            mode=audio.mode,
            args=args,
            tracker=entry.tracker,
            wake_words=audio.wake_words,
            cancel_words=audio.cancel_words,
            silence=audio.silence,
            runtime_lifecycle=deps.lifecycle,
            instance_guard=startup.instance_guard,
            pause=pause,
            set_paused=services.control_runtime.set_paused,
            runtime_tick=services.periodic_runtime.tick,
            remote=services.remote,
            handle_lock=deps.handle_lock,
            handle_audio=deps.handle,
            status=deps.status,
            cfg=startup.cfg,
            self_speech=self_speech,
            music=music,
            spoken_flag=spoken_flag,
            stream=audio.stream,
            recorder=audio.recorder,
            device=audio.device,
            rate=audio.rate,
            level=audio.level,
            resolve_device=platform.resolve_device,
            open_stream=platform.open_stream,
            make_recorder=platform.make_recorder,
            find_window=platform.find_window,
            paste_text=platform.paste_text,
            record_ptt=platform.record_ptt,
            has_utterance=platform.has_utterance,
            level_state=platform.level_state,
            on_hold_start=lambda: (
                platform.beep(880, 60),
                print("\r🎙 录音中…", end="", flush=True),
            ),
            on_hold_stop=lambda: platform.beep(520, 60),
            on_speech=deps.on_speech,
            before_fallback_capture=lambda: spoken_flag.__setitem__(
                "first",
                True,
            ),
            syslog=platform.syslog,
            shut_up=platform.shut_up,
            speaking_now=platform.speaking_now,
            duplex=platform.duplex,
            cancel_reference_echo=platform.cancel_reference_echo,
            spectrum_bands=platform.spectrum_bands,
            transcriber=platform.transcriber,
            hint=hint,
            key_watcher_factory=platform.key_watcher_factory,
            tracker_worker_factory=platform.tracker_worker_factory,
            start_scheduler=platform.start_scheduler,
            build_greeting=platform.build_greeting,
            speak_greeting=platform.speak_greeting,
            speak=platform.speak,
            emit=platform.emit,
            crash_file=platform.crash_file,
            overlay_process=services.overlay_liveness.process,
            phone_server=services.phone_server,
            on_microphone_ready=lambda recovery: mic_capture.__setitem__(
                "recovery",
                recovery,
            ),
        )
    )


__all__ = [
    "ForegroundPlatformDependencies",
    "PreparedForegroundDependencies",
    "run_prepared_foreground",
]
