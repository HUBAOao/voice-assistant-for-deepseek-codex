# -*- coding: utf-8 -*-
"""Run phone ingress, task tracking and desktop handoff outside ``main()``."""
from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PhoneCommandDependencies:
    ingress: Any
    task_store: Any | None
    phone_thread_id: Callable[[], str]
    phone_window: Callable[[], tuple[Any, str]]
    pick_target: Callable[[], tuple[Any, str]]
    focus_window: Callable[[Any], bool]
    press_enter: Callable[[], Any]
    paste_into: Callable[..., bool]
    paste_clipboard: Callable[..., Any]
    image_to_clipboard: Callable[[Path], bool]
    watch_media_reply: Callable[[str, Any, str], None]
    current_thread_id: Callable[[], str]
    busy: dict
    syslog: Callable[[str, str], None]
    handle_lock: Any
    process_command: Callable[[str], Any]
    clock: Callable[[], float] = time.time
    sleep: Callable[[float], None] = time.sleep
    print_line: Callable[..., object] = print


class PhoneCommandRuntime:
    """Own the phone queues while keeping the old ``main()`` entry names."""

    def __init__(self, deps: PhoneCommandDependencies) -> None:
        self.deps = deps

    def _print(self, text: str) -> None:
        self.deps.print_line(text, flush=True)

    def _create_task(self, text: str) -> str:
        store = self.deps.task_store
        if store is None:
            return ""
        try:
            task = store.create(
                text,
                thread_id=str(self.deps.phone_thread_id() or ""),
                detail="手机发来的命令",
            )
            return str(task["id"])
        except Exception:
            return ""

    def push(self, text: str) -> None:
        self.deps.ingress.push_command(
            text, self._create_task(text)
        )

    def got_image(self, path: Any) -> None:
        self.deps.ingress.push_image(path)

    def _mark_running(self, task_id: str, text: str) -> None:
        store = self.deps.task_store
        if store is None or not task_id:
            return
        try:
            store.update(task_id, status="running")
            store.add_tool_call(
                task_id, "phone_command", detail=text[:300]
            )
        except Exception:
            pass

    def _mark_done(self, task_id: str) -> None:
        store = self.deps.task_store
        if store is None or not task_id:
            return
        try:
            store.update(
                task_id,
                status="succeeded",
                thread_id=str(self.deps.current_thread_id() or ""),
                error="",
            )
        except Exception:
            pass

    def _mark_failed(self, task_id: str, error: Exception) -> None:
        store = self.deps.task_store
        if store is None or not task_id:
            return
        try:
            store.update(
                task_id, status="failed", error=str(error)[:500]
            )
        except Exception:
            pass

    def _target(self) -> tuple[Any, str]:
        hwnd, title = self.deps.phone_window()
        if not hwnd:
            hwnd, title = self.deps.pick_target()
        return hwnd, title

    def _submit_pending(self) -> bool:
        if not self.deps.ingress.consume_submit():
            return False
        try:
            hwnd, _title = self._target()
            if hwnd and self.deps.focus_window(hwnd):
                self.deps.sleep(0.12)
                self.deps.press_enter()
                self.deps.busy["on"] = True
                self.deps.busy["at"] = self.deps.clock()
                self.deps.syslog("发", "手机提交图片附件")
        except Exception as exc:  # noqa: BLE001
            self._print(f"   （手机提交图片失败：{exc}）")
        return True

    def _send_media(self) -> bool:
        text = self.deps.ingress.take_media()
        if not text:
            return False
        try:
            hwnd, title = self._target()
            if hwnd and self.deps.paste_into(
                text, hwnd, press_enter=True, clear_first=False
            ):
                self.deps.busy["on"] = True
                self.deps.busy["at"] = self.deps.clock()
                self.deps.syslog("听", text)
                self.deps.syslog(
                    "发", f"{title or '手机图片'}：{text[:60]}"
                )
                self.deps.watch_media_reply(text, hwnd, title)
        except Exception as exc:  # noqa: BLE001
            self._print(f"   （手机图片附言发送失败：{exc}）")
        return True

    def paste_images(self) -> bool:
        """Paste every queued image without pressing Enter."""
        while True:
            path = self.deps.ingress.take_image()
            if path is None:
                return False
            try:
                hwnd, _title = self._target()
                if self.deps.image_to_clipboard(path):
                    self.deps.paste_clipboard(
                        hwnd, press_enter=False, clear_first=False
                    )
                    self.deps.syslog(
                        "动", f"手机发来图片，已贴进聊天窗口：{Path(path).name}"
                    )
                    self._print(
                        f"   ↳ 📷 手机发来的图片已贴进对话窗口：{Path(path).name}"
                    )
                else:
                    self._print(f"   （手机发来的图片贴不进去：{Path(path).name}）")
            except Exception as exc:  # noqa: BLE001
                self._print(f"   （手机发来的图片处理失败：{exc}）")

    def _run_command(self, task_id: str, text: str) -> None:
        self._print(f"\n📱 手机发来：{text}")
        self._mark_running(task_id, text)
        try:
            with self.deps.handle_lock:
                self.deps.process_command(text)
            self._mark_done(task_id)
        except Exception as exc:  # noqa: BLE001
            self._print(f"   （手机这条没办成：{exc}）")
            self._mark_failed(task_id, exc)

    def drain(self) -> None:
        """Drain one image, media line or command batch in legacy order."""
        if self.paste_images():
            return
        if self._submit_pending():
            return
        if self._send_media():
            return
        while True:
            command = self.deps.ingress.take_command()
            if command is None:
                return
            task_id, text = command
            self._run_command(task_id, text)

    def worker(self) -> None:
        while True:
            self.deps.sleep(0.4)
            try:
                with self.deps.handle_lock:
                    self.drain()
            except Exception:
                pass
