# -*- coding: utf-8 -*-
"""Own the final foreground loop, failure path and resource teardown."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from voice_feature.runtime_teardown import (
    handle_runtime_failure,
    shutdown_runtime,
)


@dataclass(frozen=True)
class RuntimeRunDependencies:
    audio_loop: Any
    runtime_lifecycle: Any
    instance_guard: Any
    status: Any
    syslog: Callable[[str, str], object]
    speak: Callable[[str], object]
    crash_file: Path
    microphone_stream: Callable[[], Any]
    tracker_worker: Any
    overlay_process: Any
    phone_server: Any
    emit: Callable[[str], object] = print


def run_voice_runtime(deps: RuntimeRunDependencies) -> int:
    """Run until interruption while keeping the historical exit semantics."""
    try:
        deps.audio_loop.run()
        return 0
    except KeyboardInterrupt:
        deps.emit("\n已退出。")
        return 0
    except Exception as exc:  # noqa: BLE001
        handle_runtime_failure(
            exc,
            crash_file=deps.crash_file,
            syslog=deps.syslog,
            speak=deps.speak,
            emit=deps.emit,
        )
    finally:
        shutdown_runtime(
            deps.runtime_lifecycle,
            deps.instance_guard,
            status=deps.status,
            syslog=deps.syslog,
            emit=deps.emit,
        )
    return 3
