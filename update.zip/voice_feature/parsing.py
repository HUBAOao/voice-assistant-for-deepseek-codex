# -*- coding: utf-8 -*-
"""Pure parsers for voice commands; no audio or process side effects."""
from __future__ import annotations

import ast
import difflib
import re
import time


_UNITS = {"秒": 1, "分钟": 60, "分": 60, "小时": 3600, "个小时": 3600, "钟头": 3600}
_CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6,
           "七": 7, "八": 8, "九": 9, "十": 10}


def cn_number(raw: str) -> float | None:
    """把"十""半""二十五"这类中文数字换成数字；认不出来返回 None。"""
    raw = (raw or "").strip()
    if not raw:
        return None
    if raw.isdigit():
        return float(raw)
    if raw == "半":
        return 0.5
    if raw in _CN_NUM:
        return float(_CN_NUM[raw])
    if "十" in raw:
        head, _, tail = raw.partition("十")
        return float(_CN_NUM.get(head, 1) * 10 + (_CN_NUM.get(tail, 0) if tail else 0))
    return None


_REMIND_PATTERNS = [
    re.compile(r"([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:之后|以后|后)?\s*(?:提醒我|提醒|叫我|喊我|告诉)\s*[,，:：]?\s*(.*)"),
    re.compile(r"(?:提醒我|提醒|叫我|喊我|告诉我)\s*[,，:：]?\s*([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:之后|以后|后)?\s*(.*)"),
    re.compile(r"(?:定|设)?\s*(?:个)?\s*([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|秒|钟头)\s*(?:的)?\s*(?:闹钟|定时|提醒)\s*(.*)"),
]


def parse_reminder(text: str):
    """识别"10 分钟后提醒我喝水"这类说法，返回 (秒数, 提醒内容)。"""
    for pattern in _REMIND_PATTERNS:
        m = pattern.search(text)
        if not m:
            continue
        count = cn_number(m.group(1))
        if not count:
            continue
        unit = m.group(2)
        what = (m.group(3) or "").strip("。，,.！! ")
        seconds = count * _UNITS.get(unit, 60)
        if 0 < seconds <= 12 * 3600:
            return max(1, int(seconds)), (what or "时间到了")
    return None


# ---------------------------------------------------------------- 番茄钟

_FOCUS_TIME = re.compile(r"([0-9]+|[一二两三四五六七八九十半]+)\s*(个?小时|分钟|分|钟头)")


def parse_focus(text: str) -> int | None:
    """识别番茄钟/专注：返回分钟数；-1 表示"结束"；不是这类话返回 None。

    故意收得紧一点：光说"专注"不算，得带"番茄钟""专注模式""开始专注"或者时长，
    不然"我要专注工作"这种聊天会被当成下令。
    """
    if not text:
        return None
    plain = text.replace(" ", "")
    if any(w in plain for w in ("结束专注", "结束番茄", "停止专注", "停止番茄", "退出专注")):
        return -1
    hit = ("番茄钟" in plain or "番茄" in plain
           or "专注模式" in plain or "开始专注" in plain or "专注计时" in plain)
    m = _FOCUS_TIME.search(plain)
    if not hit and not (m and "专注" in plain):
        return None
    if "还剩" in plain or "还有多久" in plain or "剩多久" in plain:
        return 0                        # 0 = 只问还剩多久
    if m:
        count = cn_number(m.group(1)) or 25
        minutes = count * 60 if m.group(2) in ("小时", "个小时", "钟头") else count
    else:
        minutes = 25                    # 经典的番茄钟时长
    return max(1, min(180, int(minutes)))


# ---------------------------------------------------------------- 便签 / 记账

_NOTE_HEADS = ("记一下", "记一笔笔记", "记个笔记", "记笔记", "记下", "备忘", "帮我记")
_LEDGER_HEADS = ("记一笔", "记账", "花了", "花销", "支出", "买了")
_QUERY_NOTE = ("念一下笔记", "我记了什么", "念笔记", "看看笔记", "我的笔记")
_QUERY_LEDGER = ("花了多少", "花了多少钱", "今天花了", "这个月花了", "账本", "记的账")


def parse_note(text: str) -> str | None:
    """识别"记一下 XXX"。返回要记的内容。"""
    plain = (text or "").strip()
    for head in _NOTE_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1].strip("。，,.！!：: ")
            body = re.sub(r"^[一下个点把]+", "", body).strip("。，,.！!：: ")
            return body or None
    return None


def parse_ledger(text: str) -> tuple[str, float] | None:
    """识别"记一笔 买菜 30""买咖啡花了32块"。返回 (名目, 金额)。"""
    plain = (text or "").replace(" ", "")
    if not plain or not any(h in plain for h in _LEDGER_HEADS):
        return None
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:块|元|块钱|毛|角)?", plain)
    if not m:
        return None
    amount = float(m.group(1))
    if "毛" in plain or "角" in plain:
        amount = amount / 10
    name = plain
    for head in _LEDGER_HEADS:
        name = name.replace(head, "")
    name = re.sub(r"(\d+(?:\.\d+)?)\s*(?:块|元|块钱|毛|角)?", "", name)
    # 只去掉"我/今天/花了"这类纯前缀；"买""打"开头可能是名目本身（买菜、打车），别乱砍
    name = re.sub(r"^(?:我|你|刚刚|刚才|今天|今早|昨晚)", "", name)
    name = re.sub(r"^(?:买了|花了|付了|打了|花了钱)", "", name)
    name = name.strip("。，,.！!：:的了 ")
    return (name or "没写名目", amount)


# ---------------------------------------------------------------- 小游戏

_GAME_START = {
    "guess": ("猜数字", "猜个数", "玩猜数字"),
    "pick": ("帮我决定", "帮我选", "做个选择", "帮我挑"),
}
_GAME_STOP = ("不玩了", "结束游戏", "退出游戏", "别玩了")


def parse_game(text: str) -> tuple[str, str] | None:
    """识别小游戏指令，返回 (游戏, 附带内容)。"""
    plain = (text or "").replace(" ", "")
    if not plain:
        return None
    if any(w in plain for w in _GAME_STOP):
        return ("stop", "")
    for game, words in _GAME_START.items():
        for w in words:
            if w in plain:
                return (game, plain.split(w, 1)[1].strip("。，,.！!：: "))
    return None


# ---------------------------------------------------------------- 早间播报 / 变身

_BRIEF_WORDS = ("早间播报", "今天什么安排", "今天有什么安排", "今天的安排", "播报一下",
                "今天怎么样", "早上好")
_TRANSFORM_WORDS = ("变身", "换个样子", "换个造型", "换个主题", "换皮肤")


def parse_brief(text: str) -> bool:
    return any(w in (text or "").replace(" ", "") for w in _BRIEF_WORDS)


def parse_transform(text: str) -> bool:
    return any(w in (text or "").replace(" ", "") for w in _TRANSFORM_WORDS)


DEFAULT_STOP_WORDS = ["停", "停下", "别念了", "别说了", "闭嘴", "安静", "不用念了"]


def is_stop_word(text: str, words: list[str] | None = None) -> bool:
    """一喊就让它闭嘴。只认很短的句子，免得正常说话里带个"停"就误伤。"""
    plain = (text or "").strip("。，,.！!？? ")
    if not plain or len(plain) > 8:
        return False
    for w in (words or DEFAULT_STOP_WORDS):
        if not w:
            continue
        # 两个词以上：出现在短句里就算（"你安静点"）；单字口令要更严格，不然"停车位"会误伤
        if len(w) >= 2 and w in plain and len(plain) <= len(w) + 3:
            return True
        if plain == w or (plain.startswith(w) and len(plain) <= len(w) + 2):
            return True
    return False


_SEARCH_HEADS = ("搜一下", "搜索", "找一下我说过", "我说过关于", "翻一下日志", "查一下日志",
                 "日志里", "我说过什么关于")


def repeated_after_miss(text: str, miss: dict, now: float | None = None,
                        window: float = 120.0) -> bool:
    """这句是不是"刚刚被当成我自己的声音丢掉"的同一句？

    是 → 那就**一定是你说的**：它自己不会把同一句连念两遍。所以第二遍照常当你的话处理。
    （真机出过：它刚念完回答，你接着说话被误判丢掉；你再说一遍，还是被丢掉 —— 用户提的这招。）
    """
    last = str((miss or {}).get("text") or "")
    if not last:
        return False
    now = time.time() if now is None else now
    if now - float((miss or {}).get("at") or 0.0) >= window:
        return False
    return sounds_like(text, last)


def sounds_like(a: str, b: str) -> bool:
    """Return whether two utterances are almost certainly the same sentence.

    This deliberately uses a strict comparison: TTS playback round-trips almost
    the whole sentence, while ordinary user speech may repeat only a few words.
    """
    aa = re.sub(r"[\s，,。.！!？?]", "", a or "")
    bb = re.sub(r"[\s，,。.！!？?]", "", b or "")
    if len(aa) < 3 or len(bb) < 3:
        return False
    short, long_ = (aa, bb) if len(aa) <= len(bb) else (bb, aa)
    if len(short) >= 8 and short in long_:
        return True
    best, prev = 0, [0] * (len(bb) + 1)
    for i in range(1, len(aa) + 1):
        cur = [0] * (len(bb) + 1)
        for j in range(1, len(bb) + 1):
            if aa[i - 1] == bb[j - 1]:
                cur[j] = prev[j - 1] + 1
                best = max(best, cur[j])
        prev = cur
    if best >= 8 and best >= len(short) * 0.75:
        return True
    return difflib.SequenceMatcher(None, aa, bb).ratio() >= 0.7


def parse_search(text: str) -> str | None:
    """「搜一下我说过关于奶粉的话」→ 关键词「奶粉」。"""
    plain = (text or "").strip("。，,.！! ")
    for head in _SEARCH_HEADS:
        if head in plain:
            body = plain.split(head, 1)[1]
            body = re.sub(r"^(关于|有关|我说的|我说过|的话|吗|呢|？|\?)+", "", body).strip()
            body = re.sub(r"(的话|吗|呢|？|\?)$", "", body).strip()
            return body or None
    return None


# ---------------------------------------------------------------- 自学习纠错

def parse_correction(text: str) -> tuple[str, str] | None:
    """**已停用**（用户 2026-10-09 要求去掉：「全是误判」）。

    原来是「以后把胡包改成胡宝」「不是胡包是胡宝」→ (错, 对)，会往 config.json 里存一条
    替换规则，以后所有话里都替换掉。用户反馈：他随口说的一句话经常被当成"教它改错字"，
    然后就念一句"记住了，以后××写成××"、那句话还被改掉 —— 全是误判。所以直接停掉：
    不再学新规则（这里恒返回 None），旧的规则也不再应用（见 apply_corrections）。
    """
    return None


def apply_corrections(text: str, table: dict | None) -> str:
    """**已停用**：一律原样返回（连旧的替换表也不用了）。"""
    return text


# ---------------------------------------------------------------- 口算 / 换算

_MATH_WORDS = [("乘以", "*"), ("乘上", "*"), ("乘", "*"), ("×", "*"), ("x", "*"), ("X", "*"),
               ("加上", "+"), ("加", "+"), ("减去", "-"), ("减", "-"),
               ("除以", "/"), ("除", "/"), ("÷", "/"),
               ("的平方", "**2"), ("平方", "**2"), ("的立方", "**3"), ("立方", "**3"),
               ("点", "."), ("等于几", ""), ("等于多少", ""), ("是多少", ""), ("得多少", ""),
               ("等于", ""), ("帮我算", ""), ("算一下", ""), ("算算", ""), ("计算", ""),
               ("请问", ""), ("多少", ""), ("几", ""), ("？", ""), ("?", "")]


def _safe_eval(expr: str) -> float | None:
    """只允许数字和 + - * / ** ( ) 的算式求值。"""
    import ast

    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        return None

    def walk(node) -> float:
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return float(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            val = walk(node.operand)
            return val if isinstance(node.op, ast.UAdd) else -val
        if isinstance(node, ast.BinOp):
            a, b = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Add):
                return a + b
            if isinstance(node.op, ast.Sub):
                return a - b
            if isinstance(node.op, ast.Mult):
                return a * b
            if isinstance(node.op, ast.Div):
                return a / b
            if isinstance(node.op, ast.Pow):
                return a ** b
        raise ValueError("不支持的算式")

    try:
        return walk(tree)
    except Exception:
        return None


def parse_calc(text: str) -> tuple[str, float] | None:
    """本地算数：「127乘34」「200的百分之15」「9的平方」→ (算式, 结果)。"""
    plain = apply_corrections((text or "").strip(), None)
    if not plain or not re.search(r"[0-9０-９]", plain):
        return None
    for src, dst in zip("０１２３４５６７８９", "0123456789"):
        plain = plain.replace(src, dst)
    m = re.search(r"(\d+(?:\.\d+)?)\s*的\s*百分之\s*(\d+(?:\.\d+)?)", plain)
    if m:
        a, b = float(m.group(1)), float(m.group(2))
        return (f"{a:g} 的百分之 {b:g}", a * b / 100)
    expr = plain
    for src, dst in _MATH_WORDS:
        expr = expr.replace(src, dst)
    expr = expr.replace(" ", "").replace("，", "").replace(",", "").replace("。", "")
    if not re.fullmatch(r"[0-9+\-*/().]+", expr) or not re.search(r"[+\-*/]", expr):
        return None
    value = _safe_eval(expr)
    if value is None:
        return None
    show = expr.replace("**2", " 的平方").replace("**3", " 的立方")
    show = show.replace("*", " × ").replace("/", " ÷ ")
    return (show, value)


_UNIT_SCALE = {
    "毫米": 0.001, "厘米": 0.01, "分米": 0.1, "米": 1.0, "千米": 1000.0, "公里": 1000.0,
    "英寸": 0.0254, "英尺": 0.3048, "英里": 1609.344, "海里": 1852.0,
    "克": 1.0, "千克": 1000.0, "公斤": 1000.0, "斤": 500.0, "两": 50.0,
    "吨": 1000000.0, "磅": 453.59237, "盎司": 28.349523125,
    "毫升": 0.001, "升": 1.0, "立方米": 1000.0,
    "秒": 1.0, "分钟": 60.0, "小时": 3600.0, "天": 86400.0, "周": 604800.0,
}
_UNIT_FAMILY = {
    "毫米": "长度", "厘米": "长度", "分米": "长度", "米": "长度", "千米": "长度",
    "公里": "长度", "英寸": "长度", "英尺": "长度", "英里": "长度", "海里": "长度",
    "克": "重量", "千克": "重量", "公斤": "重量", "斤": "重量", "两": "重量",
    "吨": "重量", "磅": "重量", "盎司": "重量",
    "毫升": "体积", "升": "体积", "立方米": "体积",
    "秒": "时间", "分钟": "时间", "小时": "时间", "天": "时间", "周": "时间",
}


def parse_convert(text: str) -> str | None:
    """单位换算：「3斤是多少克」「5公里多少米」。温度单独处理。"""
    plain = (text or "").replace(" ", "").replace("？", "").replace("?", "")
    if not plain:
        return None
    if "摄氏" in plain or "华氏" in plain:
        m = re.search(r"(-?\d+(?:\.\d+)?)\s*(摄氏|华氏)?\s*度?", plain)
        if m:
            value = float(m.group(1))
            src = m.group(2) or ("华氏" if "华氏" in plain else "摄氏")
            if src == "华氏":
                return f"{value:g} 华氏度等于 {(value - 32) * 5 / 9:.1f} 摄氏度"
            return f"{value:g} 摄氏度等于 {value * 9 / 5 + 32:.1f} 华氏度"
    units = sorted(_UNIT_SCALE, key=len, reverse=True)
    found = [u for u in units if u in plain]
    if len(found) < 2:
        return None
    num = re.search(r"(\d+(?:\.\d+)?)", plain)
    if num:
        value = float(num.group(1))
    else:                                    # 支持"一公斤多少克"这种中文数字
        cn = re.search(r"([一二两三四五六七八九十半]+)", plain)
        value = cn_number(cn.group(1)) if cn else None
        if not value:
            return None
    src = found[0] if plain.find(found[0]) < plain.find(found[1]) else found[1]
    dst = found[1] if src == found[0] else found[0]
    if _UNIT_FAMILY.get(src) != _UNIT_FAMILY.get(dst):
        return None
    result = value * _UNIT_SCALE[src] / _UNIT_SCALE[dst]
    return f"{value:g} {src} 等于 {result:.4g} {dst}"


# ---------------------------------------------------------------- 媒体键 / 找东西

_VK_MEDIA = {"下一首": 0xB0, "下一曲": 0xB0, "切歌": 0xB0, "换首歌": 0xB0,
             "上一首": 0xB1, "上一曲": 0xB1, "回到上一首": 0xB1,
             "播放暂停": 0xB3, "暂停播放": 0xB3, "继续播放": 0xB3}
_VK_VOLUME = {"声音大点": 0xAF, "音量大点": 0xAF, "大声点": 0xAF, "声音大一点": 0xAF,
              "声音小点": 0xAE, "音量小点": 0xAE, "小声点": 0xAE, "声音小一点": 0xAE,
              "静音": 0xAD, "取消静音": 0xAD}


def parse_media(text: str) -> tuple[str, int] | None:
    """媒体控制。带"音乐/歌/播放器"的句子才当媒体指令，免得和暂停键打架。"""
    plain = (text or "").replace(" ", "")
    if not plain:
        return None
    for word, vk in _VK_VOLUME.items():
        if word in plain:
            return (word, vk)
    music_ctx = any(w in plain for w in ("音乐", "歌", "播放器", "声音", "视频"))
    for word, vk in _VK_MEDIA.items():
        if word in plain:
            return (word, vk)
    if music_ctx:
        if "暂停" in plain or "停一下" in plain:
            return ("暂停音乐", 0xB3)
        if "播放" in plain or "继续" in plain:
            return ("播放音乐", 0xB3)
    return None


_VOICE_OPEN_ENABLED = True
_OPEN_VERBS = ("帮我打开", "给我打开", "打开", "开一下", "启动", "运行", "打开一下")


def is_standalone_command(text: str) -> bool:
    """本地特殊命令只接受独立短句，避免长段落里的关键词被截走。"""
    raw = str(text or "").strip()
    plain = raw.replace(" ", "")
    if not plain or "\n" in raw or "\r" in raw:
        return False
    if len(plain) > 56:
        return False
    core = plain.strip("。！？!?；; ")
    if re.search(r"[。！？!?；;].*[。！？!?；;]", core):
        return False
    return True


def parse_open(text: str) -> str | None:
    plain = (text or "").strip("。，,.！! ")
    for verb in _OPEN_VERBS:
        if plain.startswith(verb):
            target = plain[len(verb):].strip("。，,.！! 一下 ")
            return target or None
    return None
