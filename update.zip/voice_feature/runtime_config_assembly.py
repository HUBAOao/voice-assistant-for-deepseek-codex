# -*- coding: utf-8 -*-
"""Own mutable configuration reloads and wake-word self-test scheduling."""
from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ConfigRuntimeDependencies:
    args: Any
    config: dict
    config_file: Path
    load_config: Callable[[], dict]
    mode: str
    wake_words: list[str]
    cancel_words: list[str]
    wake_levels: Any
    level: dict
    recorder: Any
    music: dict
    pet_proc: dict
    start_pet: Callable[[], Any]
    transcriber: Any
    status: Any
    wake_test_file: Path
    wake_selftest: Callable[[Any, dict], dict]
    speak: Callable[[str], object]
    runtime_lifecycle: Any
    emit: Callable[[str], object] = print


class ConfigRuntime:
    """Apply live settings without rebuilding the audio process."""

    def __init__(self, deps: ConfigRuntimeDependencies) -> None:
        self.deps = deps
        self._watch = {"next": 0.0, "mtime": 0.0}
        self._test_state = {"running": False}

    @property
    def reload_state(self) -> dict:
        return self._watch

    @property
    def test_state(self) -> dict:
        return self._test_state

    def reload_wake_settings(self) -> None:
        deps = self.deps
        now = time.time()
        if now < self._watch["next"]:
            return
        self._watch["next"] = now + 1.0
        try:
            mtime = deps.config_file.stat().st_mtime
        except OSError:
            return
        if mtime == self._watch["mtime"]:
            return
        self._watch["mtime"] = mtime
        fresh = deps.load_config()
        deps.config.clear()
        deps.config.update(fresh)
        if not (deps.mode == "talk" and deps.args.immediate):
            words = [
                word.strip()
                for word in str(fresh.get("wake_word") or "").split(",")
                if word.strip()
            ]
            if words and words != deps.wake_words:
                deps.wake_words[:] = words
                deps.emit(f"\n   ↳ 唤醒词已换成：{'、'.join(words)}")
            deps.cancel_words[:] = [
                word.strip()
                for word in str(fresh.get("cancel_word") or "").split(",")
                if word.strip()
            ]
        new_name, new_level = deps.wake_levels.params(fresh)
        if new_level != deps.level:
            deps.level.update(new_level)
            deps.emit(
                f"\n   ↳ 唤醒档位已换成：{new_name}"
                f"（{deps.wake_levels.describe(new_level)}）"
            )
        if deps.mode == "talk" and not deps.wake_words:
            deps.recorder.min_voiced_blocks = max(
                1, int(0.62 * deps.recorder.sr / deps.recorder.blocksize)
            )
        else:
            deps.recorder.min_voiced_blocks = max(
                1,
                int(
                    deps.level["min_voiced"]
                    * deps.recorder.sr
                    / deps.recorder.blocksize
                ),
            )
        deps.recorder.noise_mult = max(1.0, float(deps.level["noise_mult"]))
        deps.recorder.confirm = max(1, int(deps.level["confirm"]))
        deps.music["on"] = bool(fresh.get("wave_spectrum", False))
        if (
            fresh.get("pet_enabled", True)
            and not (deps.args.no_overlay or deps.args.feed or deps.args.test_paste)
        ):
            if (
                deps.pet_proc["p"] is None
                or deps.pet_proc["p"].poll() is not None
            ):
                deps.pet_proc["p"] = deps.start_pet()
        deps.transcriber.hotwords = (
            " ".join(deps.wake_words + deps.cancel_words)
            if deps.level.get("hotwords")
            else ""
        )

    def start_wake_test(self, why: str = "") -> None:
        deps = self.deps
        if self._test_state["running"] or not deps.wake_words:
            return
        self._test_state["running"] = True
        deps.emit(f"\n   ↳ 🧪 开始唤醒词自检{why}")
        deps.status.set("thinking", text="正在自检唤醒词…")

        def job() -> None:
            try:
                result = deps.wake_selftest(
                    deps.transcriber,
                    deps.load_config(),
                )
                deps.wake_test_file.write_text(
                    json.dumps(result, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                summary = result.get("summary") or "自检结束"
                deps.emit(f"   ↳ 🧪 {summary}")
                for case in result.get("cases") or []:
                    deps.emit(
                        f"      · {case['wake']} 噪声{case['noise']:g}"
                        f" 音量{case['gain']:g} → {case['text']!r}"
                        f" {'✓' if case['hit'] else '✗'}"
                    )
                deps.speak(summary)
            except Exception as exc:  # noqa: BLE001
                deps.emit(
                    f"   ↳ 🧪 自检出错：{type(exc).__name__}: {exc}"
                )
            finally:
                self._test_state["running"] = False
                deps.status.set("idle" if deps.wake_words else "listening")

        deps.runtime_lifecycle.start_daemon("wake-self-test", job)
