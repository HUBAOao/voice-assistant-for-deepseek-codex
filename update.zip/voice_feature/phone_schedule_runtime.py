# -*- coding: utf-8 -*-
"""Phone schedule read/write business kept outside the STT entrypoint."""
from __future__ import annotations

import json
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any


def _schedule_module(value=None):
    if value is not None:
        return value
    import sched as schedule_module

    return schedule_module


def list_phone_schedules(
    load_config: Callable[[], dict],
    *,
    schedule_module=None,
) -> list[dict]:
    """Return normalized schedule rows in the shape used by the phone page."""
    schedule_module = _schedule_module(schedule_module)
    rows: list[dict] = []
    try:
        data = load_config()
        for index, raw in enumerate(data.get("schedules") or []):
            if not isinstance(raw, dict):
                continue
            item = schedule_module.normalize(raw)
            rows.append({
                "i": index,
                "time": str(item.get("time") or ""),
                "text": str(item.get("text") or ""),
                "kind": str(item.get("kind") or "daily"),
                "when": schedule_module.describe(item),
                "weekdays": [int(value) for value in (
                    item.get("weekdays") or []
                )],
                "monthday": int(item.get("monthday") or 1),
                "date": str(item.get("date") or ""),
                "enabled": item.get("enabled", True) is not False,
                "module": str(item.get("kind_module") or ""),
            })
    except Exception as exc:  # noqa: BLE001
        print(f"（读日程失败：{exc}）")
    return rows


def _write_schedule_config(
    path: Path,
    data: dict[str, Any],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


def update_phone_schedule(
    action: str,
    payload: dict,
    *,
    config_file: Path,
    load_config: Callable[[], dict],
    log: Callable[[str, str], None],
    schedule_module=None,
) -> tuple[bool, str]:
    """Apply one phone schedule write and atomically replace config.json."""
    schedule_module = _schedule_module(schedule_module)
    act = str(action or "")
    item = payload.get("item") if isinstance(payload.get("item"), dict) else {}
    try:
        index = int(payload.get("i", -1))
    except (TypeError, ValueError):
        index = -1
    try:
        data = load_config()
    except Exception:  # noqa: BLE001
        data = {}
    items = [
        value for value in (data.get("schedules") or [])
        if isinstance(value, dict)
    ]

    if act == "add":
        new_item = schedule_module.normalize({
            "time": item.get("time") or "09:00",
            "text": str(item.get("text") or "").strip(),
            "kind": item.get("kind") or "daily",
            "weekdays": item.get("weekdays") or [],
            "monthday": item.get("monthday") or 1,
            "date": item.get("date") or "",
            "enabled": True,
        })
        if not new_item.get("text"):
            return False, "内容不能是空的"
        items.append(new_item)
    elif act in ("save", "update"):
        if index < 0 or index >= len(items):
            return False, "找不到这条日程"
        old = items[index]
        old["time"] = item.get("time") or old.get("time") or "09:00"
        old["text"] = str(
            item.get("text") or old.get("text") or ""
        ).strip()
        if not old["text"]:
            return False, "内容不能是空的"
        if item.get("kind"):
            old["kind"] = item["kind"]
        if "weekdays" in item:
            old["weekdays"] = item.get("weekdays") or []
        if item.get("monthday"):
            old["monthday"] = item.get("monthday")
        if item.get("date") is not None:
            old["date"] = item.get("date") or old.get("date") or ""
        items[index] = schedule_module.normalize(old)
    elif act == "del":
        if index < 0 or index >= len(items):
            return False, "找不到这条日程"
        items.pop(index)
    elif act == "toggle":
        if index < 0 or index >= len(items):
            return False, "找不到这条日程"
        items[index]["enabled"] = not (
            items[index].get("enabled", True) is not False
        )
    else:
        return False, "不认识这个操作"

    data["schedules"] = items
    try:
        _write_schedule_config(Path(config_file), data)
    except Exception as exc:  # noqa: BLE001
        return False, "存不上：%s" % exc
    try:
        log("日程", f"手机上改了日程（{act}）")
    except Exception:  # noqa: BLE001
        pass
    return True, "好了"
