# -*- coding: utf-8 -*-
"""Assemble microphone recovery without owning it in ``main()``."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

from voice_feature.microphone_recovery import MicrophoneRecovery


@dataclass(frozen=True)
class MicrophoneRuntimeDependencies:
    """Actions needed to reopen the configured input and report the result."""

    resolve_device: Callable[[Any], Any]
    open_stream: Callable[[Any], tuple[Any, int]]
    make_recorder: Callable[..., Any]
    default_input: bool
    input_value: Any
    silence: float
    max_seconds: float
    mode: str
    wake_enabled: bool
    level: Mapping
    on_reconnecting: Callable[[], None] | None = None
    on_reconnected: Callable[[int], None] | None = None
    on_failed: Callable[[], None] | None = None
    on_interrupted: Callable[[], None] | None = None


@dataclass(frozen=True)
class MicrophoneRuntimeSession:
    """The active stream, recorder and recovery controller for the voice loop."""

    recovery: MicrophoneRecovery


def prepare_microphone_runtime(
    *,
    stream: Any,
    rate: int,
    recorder: Any,
    device: Any,
    dependencies: MicrophoneRuntimeDependencies,
) -> MicrophoneRuntimeSession:
    """Build one recovery controller that also handles later reconnects."""
    deps = dependencies

    def reopen() -> tuple[Any, int, Any, Any]:
        new_device = None if deps.default_input else deps.resolve_device(
            deps.input_value
        )
        new_stream, new_rate = deps.open_stream(new_device)
        new_recorder = deps.make_recorder(
            new_stream,
            new_rate,
            deps.silence,
            deps.max_seconds,
            min_voiced=0.62
            if (deps.mode == "talk" and not deps.wake_enabled)
            else deps.level["min_voiced"],
            noise_mult=deps.level["noise_mult"],
            confirm=deps.level["confirm"],
            device=new_device,
        )
        return new_stream, new_rate, new_recorder, new_device

    recovery = MicrophoneRecovery(
        stream=stream,
        rate=rate,
        recorder=recorder,
        device=device,
        reopen=reopen,
        on_reconnecting=deps.on_reconnecting,
        on_reconnected=deps.on_reconnected,
        on_failed=deps.on_failed,
        on_interrupted=deps.on_interrupted,
    )
    return MicrophoneRuntimeSession(recovery=recovery)
