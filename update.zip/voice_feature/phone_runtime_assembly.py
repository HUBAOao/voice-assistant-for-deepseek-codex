# -*- coding: utf-8 -*-
"""Assemble phone-facing business services outside the STT entrypoint."""
from __future__ import annotations

import io
import time
import wave
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from phone_feature.phone_ingress import PhoneIngressQueue
from voice_feature.phone_bridge_runtime import (
    PhoneBridgeDependencies,
    start_phone_bridge,
)
from voice_feature.phone_command_runtime import (
    PhoneCommandDependencies,
    PhoneCommandRuntime,
)
from voice_feature.phone_history_runtime import (
    PhoneHistoryDependencies,
    append_reply,
    build_phone_history,
    recent_replies,
)
from voice_feature.phone_schedule_runtime import (
    list_phone_schedules,
    update_phone_schedule,
)
from voice_feature.phone_status_runtime import (
    PhoneInfoDependencies,
    PhoneInfoRuntime,
    PhoneStateDependencies,
    PhoneStateRuntime,
)


@dataclass(frozen=True)
class PhoneRuntimeDependencies:
    """Bind mature phone runtimes to one launch without importing ``stt``."""

    config: Mapping
    status: Any
    busy: dict
    mute: dict
    reply_busy: Callable[[], bool]
    load_config: Callable[[], dict]
    syslog: Callable[[str, str], None]
    handle_lock: Any
    process_command: Callable[[str], Any]
    pick_target: Callable[[], tuple[Any, str]]
    phone_window: Callable[[], tuple[Any, str]]
    focus_window: Callable[[Any], bool]
    press_enter: Callable[[], Any]
    paste_into: Callable[..., bool]
    paste_clipboard: Callable[..., Any]
    image_to_clipboard: Callable[[Path], bool]
    get_reply_reader: Callable[[], Any]
    current_thread_id: Callable[[], str]
    current_thread_name: Callable[[], str]
    transcriber: Any
    cancel_reference_echo: Callable[[Any, int], Any]
    rate: int
    config_file: Path
    suppressed: bool
    phone_port: int
    syslog_file: Path
    raw_replies_file: Path
    last_reply_file: Path
    self_who: Callable[[dict], str]
    ack_phrases: tuple[str, ...]
    phone_window_title: Callable[[], str]
    chat_history: Any
    phone_link_module: Any
    runtime_lifecycle: Any
    on_stop: Callable[[], Any]
    fallback_get_windows: Callable[[], list]
    public_update_url: Callable[[], str]
    pc_version: Callable[[], str]
    phone_version: Callable[[], str]
    version_module: Any
    remote_access: Any
    get_target: Callable[[], str]
    get_target_id: Callable[[], str]
    on_target: Callable[[str, str], tuple[bool, str]]
    on_thread_action: Callable[[str, str, dict], tuple[bool, str]]
    on_new_thread: Callable[[str], tuple[bool, str]]
    task_store_factory: Callable[[], Any] | None = None
    codex_control_factory: Callable[[Any], Any] | None = None
    threads_module: Any | None = None
    phone_stream_module: Any | None = None
    log: Callable[..., object] = print


class PhoneRuntimeAssembly:
    """Own the queue, history, metadata and bridge aliases for one process."""

    def __init__(self, deps: PhoneRuntimeDependencies) -> None:
        self.deps = deps
        self.ingress = PhoneIngressQueue()
        self.pause = {"prev": False, "paused": False}
        self.server = None
        try:
            if deps.task_store_factory is None:
                from features.tasks import TaskStore as StoreFactory
            else:
                StoreFactory = deps.task_store_factory
            self.task_store = StoreFactory()
            if deps.codex_control_factory is None:
                from features.codex_control import control as ControlFactory
            else:
                ControlFactory = deps.codex_control_factory
            self.live_codex = ControlFactory(self.task_store)
        except Exception:
            self.task_store = None
            self.live_codex = None

        self.state_runtime = PhoneStateRuntime(
            PhoneStateDependencies(
                status=deps.status,
                busy=deps.busy,
                mute=deps.mute,
                pause=self.pause,
                reply_busy=deps.reply_busy,
            )
        )
        self.info_runtime = PhoneInfoRuntime(
            PhoneInfoDependencies(
                config=deps.config,
                pc_version=deps.pc_version,
                phone_version=deps.phone_version,
                version_module=deps.version_module,
                public_update_url=deps.public_update_url,
                remote_access=deps.remote_access,
            )
        )
        self.commands = PhoneCommandRuntime(
            PhoneCommandDependencies(
                ingress=self.ingress,
                task_store=self.task_store,
                phone_thread_id=self.deps.get_target_id,
                phone_window=deps.phone_window,
                pick_target=deps.pick_target,
                focus_window=deps.focus_window,
                press_enter=deps.press_enter,
                paste_into=deps.paste_into,
                paste_clipboard=deps.paste_clipboard,
                image_to_clipboard=deps.image_to_clipboard,
                watch_media_reply=self.watch_media_reply,
                current_thread_id=deps.current_thread_id,
                busy=deps.busy,
                syslog=deps.syslog,
                handle_lock=deps.handle_lock,
                process_command=deps.process_command,
                print_line=deps.log,
            )
        )
        self.history_deps = PhoneHistoryDependencies(
            syslog_file=deps.syslog_file,
            raw_replies_file=deps.raw_replies_file,
            last_reply_file=deps.last_reply_file,
            load_config=deps.load_config,
            self_who=deps.self_who,
            ack_phrases=deps.ack_phrases,
            phone_window_title=deps.phone_window_title,
            current_thread_name=deps.current_thread_name,
            chat_history=deps.chat_history,
            print_line=deps.log,
        )

    def state(self) -> dict:
        """Return the compact state consumed by the HTTP bridge."""
        return self.state_runtime.snapshot()

    def update_source(self) -> str:
        """Keep the historical phone update-source probe."""
        return self.info_runtime._update_source()

    def info(self) -> dict:
        """Return product metadata consumed by phone settings."""
        return self.info_runtime.snapshot()

    def schedule_list(self) -> list:
        return list_phone_schedules(self.deps.load_config)

    def schedule_do(self, action: str, payload: dict) -> tuple:
        return update_phone_schedule(
            action,
            payload,
            config_file=self.deps.config_file,
            load_config=self.deps.load_config,
            log=self.deps.syslog,
        )

    def raw_reply(self, name: str, text: str) -> None:
        append_reply(
            name,
            text,
            deps=self.history_deps,
            log=self.deps.syslog,
        )

    def replies(self) -> list:
        return recent_replies(self.deps.raw_replies_file)

    def history(self, since: int, keyword: str = "") -> list[dict]:
        return build_phone_history(
            since,
            keyword,
            deps=self.history_deps,
        )

    def watch_media_reply(self, text: str, hwnd: int, title: str) -> None:
        reader = self.deps.get_reply_reader()
        if reader is None or not self.deps.config.get("read_reply", True):
            return
        reader.watch(
            hwnd,
            text,
            seconds=900,
            max_chars=20000,
            title=self.deps.current_thread_name() or title,
            speak=False,
        )

    def voice(self, wav_bytes: bytes) -> str:
        """Transcribe native phone audio and enqueue it like typed input."""
        try:
            with wave.open(io.BytesIO(wav_bytes), "rb") as source:
                channels = source.getnchannels()
                width = source.getsampwidth()
                sample_rate = source.getframerate()
                count = source.getnframes()
                raw = source.readframes(count)
            if width == 2:
                data = np.frombuffer(
                    raw, dtype=np.int16
                ).astype(np.float32) / 32768.0
            else:
                data = np.frombuffer(
                    raw, dtype=np.uint8
                ).astype(np.float32) / 128.0 - 1.0
            if channels > 1:
                data = data.reshape(-1, channels).mean(axis=1)
            if sample_rate != self.deps.rate and len(data) > 1:
                indexes = np.linspace(
                    0,
                    len(data) - 1,
                    max(1, int(len(data) * self.deps.rate / sample_rate)),
                )
                data = np.interp(
                    indexes, np.arange(len(data)), data
                ).astype(np.float32)
            if data.size < self.deps.rate // 4:
                return ""
            try:
                data = self.deps.cancel_reference_echo(
                    data, self.deps.rate
                )
            except Exception:
                pass
            got = self.deps.transcriber.transcribe(data)
        except Exception as exc:  # noqa: BLE001
            self.deps.log(f"   （手机录音读不了：{exc}）", flush=True)
            return ""
        got = (got or "").strip()
        self.deps.log(f"\n📱 手机说：{got}", flush=True)
        if not got:
            return ""
        self.commands.push(got)
        return got

    def start(self):
        """Start the HTTP bridge and return the historical server object."""
        self.server = start_phone_bridge(
            PhoneBridgeDependencies(
                enabled=bool(self.deps.config.get("phone_enabled", True)),
                suppressed=self.deps.suppressed,
                port=self.deps.phone_port,
                phone_link_module=self.deps.phone_link_module,
                runtime_lifecycle=self.deps.runtime_lifecycle,
                ingress=self.ingress,
                on_command=self.commands.push,
                get_state=self.state,
                get_log=self.history,
                on_stop=self.deps.on_stop,
                on_voice=self.voice,
                get_info=self.info,
                on_image=self.commands.got_image,
                get_schedule=self.schedule_list,
                on_schedule=self.schedule_do,
                get_replies=self.replies,
                get_codex_control=lambda: self.live_codex,
                get_target=self.deps.get_target,
                get_target_id=self.deps.get_target_id,
                on_target=self.deps.on_target,
                on_thread_action=self.deps.on_thread_action,
                on_new_thread=self.deps.on_new_thread,
                fallback_get_windows=self.deps.fallback_get_windows,
                worker=self.commands.worker,
                log=self.deps.log,
                syslog=self.deps.syslog,
                threads_module=self.deps.threads_module,
                phone_stream_module=self.deps.phone_stream_module,
            )
        )
        return self.server


def assemble_phone_runtime(
    deps: PhoneRuntimeDependencies,
) -> PhoneRuntimeAssembly:
    """Preserve one assembly entry while allowing independent verification."""
    return PhoneRuntimeAssembly(deps)
