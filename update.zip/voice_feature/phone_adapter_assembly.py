"""Phone-facing adapters around the desktop voice runtime."""
from __future__ import annotations

import importlib
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimePhoneAdapterDependencies:
    """Narrow dependencies keep desktop and phone entry points independently testable."""

    execute_command: Callable[[str], Any]
    speech_context: Any
    thread_module: str
    fallback_module: str
    reply_reader: Callable[[], Any]
    raw_replies_file: Path
    last_reply_file: Path
    import_module: Callable[[str], Any] = importlib.import_module


class RuntimePhoneAdapter:
    """Preserve the legacy phone bridge callbacks without local ``main()`` closures."""

    def __init__(self, deps: RuntimePhoneAdapterDependencies) -> None:
        self.deps = deps
        self.raw_replies_file = deps.raw_replies_file
        self.last_reply_file = deps.last_reply_file

    def process_command(self, text: str) -> None:
        """Phone text stays silent while it enters the shared utterance pipeline."""
        self.deps.speech_context.silent = True
        try:
            self.deps.execute_command(text)
        finally:
            self.deps.speech_context.silent = False

    def current_thread_id(self) -> str:
        try:
            module = self.deps.import_module(self.deps.thread_module)
            return str(module.current_thread_id() or "")
        except Exception:
            return ""

    def current_thread_name(self) -> str:
        try:
            module = self.deps.import_module(self.deps.thread_module)
            return str(module.current_name() or "")
        except Exception:
            return ""

    def switch_thread(self, title: str, thread_id: str) -> Any:
        module = self.deps.import_module(self.deps.thread_module)
        return module.open_thread(title, thread_id)

    def reply_busy(self) -> bool:
        try:
            reader = self.deps.reply_reader()
            return bool(reader is not None and reader.busy())
        except Exception:
            return False

    def public_update_url(self) -> str:
        try:
            module = self.deps.import_module(self.deps.fallback_module)
            return str(module.public_url() or "")
        except Exception:
            return ""


def assemble_phone_adapter(
    deps: RuntimePhoneAdapterDependencies,
) -> RuntimePhoneAdapter:
    return RuntimePhoneAdapter(deps)


__all__ = [
    "RuntimePhoneAdapter",
    "RuntimePhoneAdapterDependencies",
    "assemble_phone_adapter",
]
