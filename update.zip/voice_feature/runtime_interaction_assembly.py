# -*- coding: utf-8 -*-
"""Own short voice interactions that sit outside the foreground capture loop."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


_CANCEL_PUNCT = re.compile(r"[\s，,、。.!！?？~～…\-—_*·]+")


@dataclass(frozen=True)
class RuntimeInteractionDependencies:
    """Live settings, microphone callbacks, and delivery mechanisms."""

    args: Any
    config: dict
    config_file: Path
    voiceprint_file: Path
    wake_words: list[str]
    rate: int
    transcriber: Any
    calibrate: Callable[[], float]
    record: Callable[..., Any]
    has_utterance: Callable[[Any, int], bool]
    voice_features: Callable[[Any, int], list[float] | None]
    voiceprint: dict
    speak: Callable[..., Any]
    status: Any
    syslog: Callable[[str, str], Any]
    emit: Callable[..., Any]
    load_config: Callable[[], dict]
    copy_to_clipboard: Callable[[str], bool]
    paste_clipboard: Callable[..., bool]
    paste_into: Callable[..., bool]
    type_text_hwnd: Callable[..., bool]
    is_paused: Callable[[], bool]
    level_state: Callable[[float], str]
    app_dir: Path
    python_executable: str
    sleep: Callable[[float], Any] = time.sleep
    spawn: Callable[..., Any] | None = None


class RuntimeInteractionAssembly:
    """Keep microphone-dependent commands deterministic and independently tested."""

    def __init__(self, deps: RuntimeInteractionDependencies) -> None:
        self.deps = deps

    def set_config(self, key: str, value: Any) -> None:
        deps = self.deps
        fresh = deps.load_config()
        fresh[key] = value
        try:
            deps.config_file.write_text(
                json.dumps(fresh, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass
        deps.config[key] = value
        deps.syslog("设", f"{key} = {value}")

    def restart_program(self) -> None:
        deps = self.deps
        runner = Path(deps.python_executable).with_name("pythonw.exe")
        if not runner.exists():
            runner = Path(deps.python_executable)
        flags = 0x08000000 if os.name == "nt" else 0
        entrypoint = deps.app_dir / "stt.py"
        code = (
            "import subprocess, time; time.sleep(3); "
            f"subprocess.Popen([{str(runner)!r}, {str(entrypoint)!r}, "
            f"'--mode', 'talk'], cwd={str(deps.app_dir)!r}, "
            f"creationflags={flags})"
        )
        spawn = deps.spawn or subprocess.Popen
        try:
            spawn(
                [str(runner), "-c", code],
                cwd=str(deps.app_dir),
                creationflags=flags,
            )
            deps.emit("\n   ↳ 🔄 三秒后自动重启")
        except Exception as exc:  # noqa: BLE001
            deps.emit(f"   （重启进程没起来：{exc}）")
        deps.status.set("offline", hint="正在重启…")
        raise SystemExit(0)

    def _record_short(self) -> Any:
        deps = self.deps
        return deps.record(deps.calibrate(), None, tick=deps.is_paused)

    def train_wake_voice(self) -> None:
        deps = self.deps
        word = deps.wake_words[0] if deps.wake_words else "大肥鱼"
        deps.speak(f"好，念三遍「{word}」，每遍我都会说一句提示")
        feats: list[list[float]] = []
        for index in range(3):
            deps.speak(f"第 {index + 1} 遍")
            deps.sleep(0.4)
            audio = self._record_short()
            if audio is None or not deps.has_utterance(audio, deps.rate):
                deps.speak("这遍没听清，训练先停下，等下再来")
                return
            feature = deps.voice_features(audio, deps.rate)
            if feature:
                feats.append(feature)
        if len(feats) < 2:
            deps.speak("没录到足够的声音，重试一次吧")
            return
        similarities: list[float] = []
        for left in range(len(feats)):
            for right in range(left + 1, len(feats)):
                similarities.append(
                    float(
                        np.dot(
                            np.array(feats[left]),
                            np.array(feats[right]),
                        )
                    )
                )
        average = np.mean(np.array(feats), axis=0)
        average = average / (float(np.linalg.norm(average)) or 1.0)
        try:
            data = (
                json.loads(deps.voiceprint_file.read_text(encoding="utf-8"))
                if deps.voiceprint_file.exists()
                else {}
            )
        except Exception:
            data = {}
        data["wake_feat"] = [float(value) for value in average]
        data["wake_ts"] = time.time()
        try:
            deps.voiceprint_file.write_text(
                json.dumps(data, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass
        lowest = min(similarities) if similarities else 0.0
        judgement = "挺稳的" if lowest > 0.6 else "三次差别有点大"
        deps.speak(
            f"记录好了，三次相似度最低 {lowest:.2f}，{judgement}"
        )
        deps.syslog("声", f"唤醒词训练完成，最低相似度 {lowest:.2f}")
        deps.status.set("sent", text=f"🎙 唤醒词已训练（{lowest:.2f}）")

    def wake_voice_ok(self, audio: Any) -> bool:
        deps = self.deps
        if not deps.config.get("voiceprint_gate", False):
            return True
        try:
            reference = json.loads(
                deps.voiceprint_file.read_text(encoding="utf-8")
            ).get("wake_feat")
        except Exception:
            return True
        if not reference:
            return True
        feature = deps.voice_features(audio, deps.rate)
        if not feature:
            return True
        score = float(np.dot(np.array(reference), np.array(feature)))
        deps.syslog("声", f"唤醒声纹 {score:.2f}")
        deps.voiceprint["wake_score"] = score
        if score < 0.45:
            deps.emit(
                f"   ↳ 🎙 这次唤醒不像本人（{score:.2f}），忽略"
            )
            return False
        return True

    def send_it(self, text: str, hwnd: int) -> bool:
        deps = self.deps
        how = str(deps.config.get("send_mode") or "paste_enter")
        if how == "type":
            return deps.type_text_hwnd(
                text,
                hwnd,
                press_enter=not deps.args.no_send,
            )
        if how == "paste":
            deps.copy_to_clipboard(text)
            return deps.paste_clipboard(
                hwnd,
                press_enter=False,
                clear_first=not deps.args.keep_draft,
            )
        return deps.paste_into(
            text,
            hwnd,
            press_enter=not deps.args.no_send,
            clear_first=not deps.args.keep_draft,
        )

    def confirm_ok(self, text: str) -> bool:
        deps = self.deps
        if not deps.config.get("confirm_send", False):
            return True
        deps.speak(f"要发的是：{text[:40]}。发吗？")
        deps.emit("   ↳ ❓ 等你确认（说「发」或「取消」）")
        deps.status.set(
            "listening",
            text=f"❓ {text[:20]}… 发吗？",
        )
        answer = deps.record(
            deps.calibrate(),
            None,
            tick=deps.is_paused,
            on_level=lambda value, _block=None: deps.status.level(
                value,
                deps.level_state(value),
            ),
        )
        if answer is None or answer.size < deps.rate // 4:
            deps.speak("没听清，先不发了")
            return False
        heard = deps.transcriber.transcribe(answer)
        deps.emit(f"   ↳ 你的回答：{heard}")
        plain_answer = _CANCEL_PUNCT.sub("", heard or "")
        no_words = (
            "取消",
            "不",
            "别",
            "算了",
            "等等",
            "等一下",
            "先不",
            "不用",
            "不建议",
        )
        yes_words = (
            "发",
            "发送",
            "发吧",
            "好",
            "好嘞",
            "行",
            "可以",
            "确认",
            "对",
            "是的",
            "嗯",
        )
        if any(word in plain_answer for word in no_words):
            deps.speak("好，不发了")
            deps.syslog("撤", f"确认时取消：{text[:30]}")
            return False
        if any(word in plain_answer for word in yes_words):
            return True
        deps.speak("没听清，先不发了")
        deps.syslog("撤", f"确认时没听清：{text[:30]}")
        return False


__all__ = [
    "RuntimeInteractionAssembly",
    "RuntimeInteractionDependencies",
]
