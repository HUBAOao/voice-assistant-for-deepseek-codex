# -*- coding: utf-8 -*-
"""Small desktop companion features for the voice runtime.

The speech loop owns microphones, target windows and process lifetime.  This
module owns the in-memory focus timer, tiny games, notes, ledger, morning
briefing and theme rotation so ``main()`` only assembles those dependencies.
All user-facing wording and data paths stay unchanged.
"""
from __future__ import annotations

import json
import random
import re
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from voice_feature.daily_features import DailyFeatureMixin


IDIOMS = (
    "一心一意", "意气风发", "发扬光大", "大显身手", "手到擒来", "来日方长", "长驱直入",
    "入木三分", "分秒必争", "争先恐后", "后来居上", "上下一心", "心花怒放", "放虎归山",
    "山明水秀", "秀色可餐", "餐风露宿", "宿雨餐风", "风平浪静", "静观其变", "变本加厉",
    "厉兵秣马", "马到成功", "功成名就", "就地取材", "材大难用", "用武之地", "地久天长",
    "长话短说", "说一不二", "二话不说", "说三道四", "四面八方", "方兴未艾", "艾发衰容",
    "容光焕发", "发号施令", "令行禁止", "止戈为武", "武艺超群", "群策群力", "力争上游",
    "游刃有余", "余音绕梁", "梁上君子", "子虚乌有", "有备无患", "患得患失", "失之东隅",
    "海阔天空", "空前绝后", "后继有人", "人山人海", "海纳百川", "川流不息", "息息相关",
    "相亲相爱", "爱不释手", "手忙脚乱", "乱七八糟", "糟糠之妻", "妻离子散", "散兵游勇",
    "勇往直前", "前程万里", "里应外合", "合情合理", "理所当然", "然荻读书", "书声琅琅",
    "明日黄花", "花好月圆", "圆木警枕", "枕戈待旦", "旦夕之间", "间不容发",
)


@dataclass(frozen=True)
class AmbientFeatureDependencies:
    status: Any
    speak: Callable[[str], Any]
    beep: Callable[[int, int], Any]
    arm_followup: Callable[[], Any]
    award: Callable[[str], Any]
    config: dict
    load_config: Callable[[], dict]
    save_config: Callable[[dict], Any]
    notes_file: Path
    ledger_file: Path
    weather_line: Callable[[str], str] | None = None
    now: Callable[[], float] = time.time
    date_now: Callable[[], datetime] = datetime.now
    choose: Callable[[Any], Any] = random.choice


class AmbientFeatureRuntime(DailyFeatureMixin):
    """Stateful companion features assembled from injectable callbacks."""

    def __init__(self, dependencies: AmbientFeatureDependencies) -> None:
        self.d = dependencies
        self.focus = {
            "end": 0.0,
            "minutes": 0,
            "total": 0.0,
            "shown": 0.0,
        }
        self.game = {"kind": "", "data": {}, "until": 0.0}

    def focus_active(self) -> bool:
        return self.focus["end"] > self.d.now()

    def focus_left(self) -> float:
        return max(0.0, self.focus["end"] - self.d.now())

    def focus_start(self, minutes: int) -> None:
        self.focus.update(
            minutes=minutes,
            total=float(minutes) * 60,
            end=self.d.now() + minutes * 60,
            shown=0.0,
        )
        self.d.speak(f"好，专注 {minutes} 分钟，开始")
        print(f"   ↳ 🍅 番茄钟 {minutes} 分钟", flush=True)
        self.d.award("focus")
        self.focus_tick(force=True)
        self.d.arm_followup()

    def focus_stop(self, finished: bool = False) -> None:
        if not self.focus["end"]:
            return
        self.focus["end"] = 0.0
        self.d.status.focus = 0.0
        if finished:
            self.d.speak("时间到，起来动一动吧")
            self.d.beep(980, 120)
            time.sleep(0.12)
            self.d.beep(1320, 160)
            print("   ↳ 🍅 番茄钟到点", flush=True)
        else:
            self.d.speak("好，专注结束")
            print("   ↳ 🍅 番茄钟提前结束", flush=True)
        self.d.status.set("idle")

    def focus_tick(self, force: bool = False) -> None:
        """Write the countdown to the overlay at most once per second."""
        if not self.focus["end"]:
            return
        left = self.focus_left()
        if left <= 0:
            self.focus_stop(finished=True)
            return
        now = self.d.now()
        if not force and now - self.focus["shown"] < 1.0:
            return
        self.focus["shown"] = now
        self.d.status.patch(focus=left)

    def read_ledger(self) -> list[dict]:
        try:
            data = json.loads(self.d.ledger_file.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def add_note(self, body: str) -> None:
        stamp = self.d.date_now().strftime("%Y-%m-%d %H:%M")
        try:
            with self.d.notes_file.open("a", encoding="utf-8") as handle:
                handle.write(f"- {stamp}　{body}\n")
        except Exception:
            pass
        self.d.speak(f"记下了：{body}")
        print(f"   ↳ 📝 便签：{body}", flush=True)
        self.d.status.set("sent", text=f"📝 {body}")
        self.d.award("note")

    def add_ledger(self, name: str, amount: float) -> None:
        rows = self.read_ledger()
        today = self.d.date_now().strftime("%Y-%m-%d")
        rows.append({
            "ts": self.d.now(),
            "date": today,
            "name": name,
            "amount": round(amount, 2),
        })
        try:
            self.d.ledger_file.write_text(
                json.dumps(rows, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception:
            pass
        total = sum(
            row["amount"] for row in rows if row.get("date") == today
        )
        self.d.speak(f"记下了，{name} {amount:g} 块，今天一共 {total:g} 块")
        print(f"   ↳ 💰 {name} {amount:g}，今日合计 {total:g}", flush=True)
        self.d.status.set("sent", text=f"💰 {name} {amount:g}")
        self.d.award("ledger")

    def say_ledger(self) -> None:
        rows = self.read_ledger()
        today = self.d.date_now().strftime("%Y-%m-%d")
        month = today[:7]
        day_sum = sum(row["amount"] for row in rows if row.get("date") == today)
        month_sum = sum(
            row["amount"]
            for row in rows
            if str(row.get("date", "")).startswith(month)
        )
        tail = (
            "、".join(
                f"{row['name']} {row['amount']:g}"
                for row in rows
                if row.get("date") == today
            )[:60]
            or "还没记过"
        )
        self.d.speak(
            f"今天花了 {day_sum:g} 块，这个月一共 {month_sum:g} 块。"
            f"今天有：{tail}"
        )
        self.d.status.set(
            "sent",
            text=f"💰 今日 {day_sum:g} / 本月 {month_sum:g}",
        )

    def say_notes(self) -> None:
        try:
            lines = [
                line.strip()
                for line in self.d.notes_file.read_text(
                    encoding="utf-8"
                ).splitlines()
                if line.strip().startswith("-")
            ]
        except Exception:
            lines = []
        if not lines:
            self.d.speak("还没有记过东西")
            return
        recent = lines[-5:]
        self.d.speak(
            f"最近记了 {len(lines)} 条。最后几条是："
            + "；".join(
                line.lstrip("- ").split("　")[-1] for line in recent
            )
        )
        self.d.status.set("sent", text=f"📝 {len(lines)} 条便签")

    def game_start(self, kind: str, extra: str = "") -> None:
        if kind == "stop":
            self.game.update(kind="", data={}, until=0.0)
            self.d.speak("好，不玩了")
            self.d.status.set("idle")
            return
        if kind == "guess":
            self.game.update(
                kind="guess",
                data={
                    "answer": random.randint(1, 100),
                    "tries": 0,
                    "low": 1,
                    "high": 100,
                },
                until=self.d.now() + 600,
            )
            self.d.speak("我想好了一个 1 到 100 之间的数，你猜")
            self.d.status.set("listening", text="猜数字 1-100")
        elif kind == "pick":
            if not extra:
                self.d.speak("把选项说给我，比如：帮我决定 吃面还是吃饭")
                self.game.update(
                    kind="pick",
                    data={},
                    until=self.d.now() + 60,
                )
                return
            self.do_pick(extra)
        elif kind == "idiom":
            first = self.d.choose(IDIOMS)
            self.game.update(
                kind="idiom",
                data={"last": first[-1], "rounds": 0},
                until=self.d.now() + 600,
            )
            self.d.speak(f"我先来：{first}。你说一个以「{first[-1]}」开头的")
            self.d.status.set("listening", text=f"成语接龙：{first}")
        print(f"   ↳ 🎮 开始游戏：{kind}", flush=True)
        self.d.award("game")

    def do_pick(self, extra: str) -> None:
        parts = [
            part.strip("。，,.！!？? ")
            for part in re.split(r"还是|或者|,|，|、|/|\s+", extra)
            if part.strip("。，,.！!？? ")
        ]
        if len(parts) < 2:
            self.d.speak("至少给我两个选项吧")
            return
        chosen = self.d.choose(parts)
        self.d.speak(f"我选：{chosen}")
        print(f"   ↳ 🎲 选项 {parts} → {chosen}", flush=True)
        self.d.status.set("sent", text=f"🎲 我选 {chosen}")
        self.d.beep(880, 60)

    def game_feed(self, text: str) -> bool:
        """Consume one utterance while a game is active."""
        if not self.game["kind"] or self.d.now() > self.game["until"]:
            self.game.update(kind="", data={})
            return False
        if self.game["kind"] == "pick":
            self.do_pick(text)
            self.game.update(kind="")
            return True
        if self.game["kind"] == "guess":
            data = self.game["data"]
            match = re.search(r"(\d+)", text)
            if not match:
                self.d.speak("说个数字给我")
                return True
            number = int(match.group(1))
            data["tries"] += 1
            if number == data["answer"]:
                self.d.speak(
                    f"猜对了，就是 {number}，一共猜了 {data['tries']} 次"
                )
                self.d.status.set("sent", text=f"🎉 猜对了：{number}")
                self.d.beep(1320, 120)
                self.game.update(kind="")
            elif number < data["answer"]:
                self.d.speak("小了")
                self.d.status.set("listening", text=f"{number} → 小了")
            else:
                self.d.speak("大了")
                self.d.status.set("listening", text=f"{number} → 大了")
            return True
        if self.game["kind"] == "idiom":
            data = self.game["data"]
            word = re.sub(r"[^\u4e00-\u9fff]", "", text)
            if len(word) < 2:
                self.d.speak("说个成语给我")
                return True
            if word[0] != data["last"]:
                self.d.speak(f"要从「{data['last']}」开头哦")
                return True
            data["rounds"] += 1
            choices = [
                item
                for item in IDIOMS
                if item.startswith(word[-1]) and item != word
            ]
            if not choices:
                self.d.speak(f"「{word}」好，我接不上来了，你赢了")
                self.d.status.set("sent", text=f"🏆 你赢了（{word}）")
                self.game.update(kind="")
                return True
            reply = self.d.choose(choices)
            data["last"] = reply[-1]
            self.d.speak(reply)
            self.d.status.set("listening", text=f"我：{reply}")
            return True
        return False

__all__ = [
    "AmbientFeatureDependencies",
    "AmbientFeatureRuntime",
    "IDIOMS",
]
