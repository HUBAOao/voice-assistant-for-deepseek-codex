#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""手机入口：手机浏览器直接连到这台电脑上的语音助手。

为什么这么做：语音助手本来就会"把文字发到聊天窗口 / 执行本地动作"，
那就给它开一个 HTTP 小门（只用 Python 标准库，不装任何东西、不连任何第三方服务）：

    手机浏览器 → http://<电脑IP>:8765/?k=<令牌>
        ├─ POST /api/cmd   把一句话交给主程序（跟你在电脑上说话走同一条管线）
        ├─ GET  /api/log   把最近的对话（[听]/[发]/[答]…）拉回去显示
        ├─ POST /api/stop  让它闭嘴（等于喊「停」）
        └─ GET  /          手机网页界面（加到主屏幕就是个 APP）

安全：所有请求都要带令牌（?k= 或 X-Token 头），令牌存在 phone-token.txt，
第一次自动生成。默认只监听内网；要在外面也能用，就用 Tailscale 之类的内网穿透，
不要把 8765 直接映射到公网。
"""

from __future__ import annotations

import json
import hashlib
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HERE = Path(__file__).resolve().parent
TOKEN_FILE = HERE / "phone-token.txt"
APK_FILE = HERE / "语音助手-手机端.apk"      # 手机页面上那个"下载安装包"给的就是它

# 手机网页还有一个"外挂文件"版本：手机页.html。
# 有它就用它（每次请求现读、带 mtime 缓存）—— 这样我改完网页存个盘，
# 正在跑的服务下一刷就是新页面，**不用重启程序**（用户嫌重启二十多秒太慢）。
PAGE_FILE = HERE / "phone_page.html"
_page_cache = {"mtime": 0.0, "html": ""}


def current_page() -> str:
    """当前该发出去的那张网页：优先读 phone_page.html，其次用源码里的 PAGE。"""
    try:
        if PAGE_FILE.exists():
            mt = PAGE_FILE.stat().st_mtime
            if mt != _page_cache["mtime"] or not _page_cache["html"]:
                _page_cache["html"] = PAGE_FILE.read_text(encoding="utf-8")
                _page_cache["mtime"] = mt
            if _page_cache["html"]:
                return _page_cache["html"]
    except Exception:
        pass
    return PAGE
PHONE_VER_FILE = HERE / "phone-version.txt"  # 打包时写下的"手机端自己是哪个版本"
DEFAULT_PORT = 8765


def load_token() -> str:
    """令牌：存在 phone-token.txt，第一次跑自动生成，之后一直用这条。

    为什么有长度门槛：外面发出去的**旧安装包**里带过早期写死的短令牌
    （等于把口令跟着包一起发了），所以 32 位以下的一律作废重发。
    重发之后手机上要重新扫一次码。
    """
    try:
        tok = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if len(tok) >= TOKEN_MIN_CHARS:
            return tok
    except Exception:
        pass
    return rotate_token()


def rotate_token() -> str:
    """换一条新令牌（40 位）。换完手机上要重新扫一次码。"""
    tok = secrets.token_urlsafe(30)
    try:
        TOKEN_FILE.write_text(tok, encoding="utf-8")
    except Exception:
        pass
    return tok


_tok_cache = {"mtime": -1.0, "value": ""}


def current_token() -> str:
    """当前令牌（每次看一眼文件变没变）。

    为什么要这样：设置里点「换一条令牌」之后，**不用重启程序**就生效 ——
    不然换令牌得重启 28 秒，用户嫌慢。
    """
    try:
        m = TOKEN_FILE.stat().st_mtime
    except OSError:
        m = -1.0
    if m != _tok_cache["mtime"]:
        _tok_cache["mtime"] = m
        _tok_cache["value"] = load_token()
    return _tok_cache["value"]


# ------------------------------------------------- 新设备要"配对"（防令牌泄漏）
# 公网地址一开，只要那串令牌漏出去（截图、转发、浏览器记录），谁拿到都能指挥这台电脑。
# 所以再加一道门：**每台设备第一次来，电脑上会弹一句"要不要让它连"**，你点了允许它才进得来。
# 允许过之后它带一个 cookie（va_dev），以后就不用再确认。你自己手机第一次扫完码也会弹一次，
# 点一下就行。
DEV_FILE = HERE / "phone-devices.json"
DEV_COOKIE = "va_dev"
DEV_CODE_TTL = 900.0            # 等你确认的设备，15 分钟没人理就作废
DEV_DENY_TTL = 1800.0           # 你拒绝过的设备，半小时内不再为它弹窗（也别再登记新条目）
_dev_lock = threading.Lock()


def _dev_load() -> dict:
    try:
        data = json.loads(DEV_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _dev_save(data: dict) -> None:
    """写进去（先写临时文件再替换，别让两边同时读写写坏）。"""
    try:
        tmp = DEV_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(DEV_FILE)
    except Exception:
        pass


def devices() -> dict:
    """登记过的设备：等你确认的 + 已经允许的（顺手清掉等太久的）。"""
    with _dev_lock:
        data = _dev_load()
        now = time.time()
        changed = False
        for k in list(data.keys()):
            rec = data.get(k) or {}
            if not rec.get("ok") and now - float(rec.get("first") or 0) > DEV_CODE_TTL:
                if now - float(rec.get("denied") or 0) < DEV_DENY_TTL:
                    rec["first"] = now            # 拒绝过的先留着（免得它换个马甲又来刷屏）
                    data[k] = rec
                else:
                    data.pop(k, None)
                    changed = True
        if changed:
            _dev_save(data)
        return data


def pending_devices() -> list:
    """还在等你点"允许"的设备（刚被你拒绝的那批先不问，免得一直弹）。"""
    now = time.time()
    out = []
    for k, v in devices().items():
        if v.get("ok"):
            continue
        if now - float(v.get("denied") or 0) < DEV_DENY_TTL:
            continue
        out.append(dict(v, id=k))
    return out


def known_devices() -> list:
    """已经允许过的设备。"""
    return [dict(v, id=k) for k, v in devices().items() if v.get("ok")]


def _dev_id_new() -> str:
    return secrets.token_urlsafe(12)


def _dev_fp(ua: str, ip: str) -> str:
    """没有 cookie 的设备怎么"认脸"：UA + 来源地址。

    为什么必须有这一手：手机 APP 里那个后台轮询用的是 Java 的 HTTP 客户端，
    **它不带 cookie** —— 只认 cookie 的话，它每轮询一次就算一台新设备，
    几分钟就能攒出几十个"待确认"，还会一直弹窗。
    """
    raw = ("%s|%s" % (ua or "", ip or "")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]


def _dev_find(ua: str, ip: str) -> str:
    """按"认脸"找已经登记过的设备（找到就复用它的 id，别新建）。"""
    fp = _dev_fp(ua, ip)
    for k, v in devices().items():
        if str((v or {}).get("fp") or "") == fp:
            return k
    return ""


def _dev_touch(dev_id: str, ua: str = "", ip: str = "", fp: str = "") -> dict:
    """登记/更新一台设备，返回它的记录（里面有配对码和 ok）。"""
    with _dev_lock:
        data = _dev_load()
        now = time.time()
        rec = data.get(dev_id) or {}
        if not rec:
            rec = {"code": "%06d" % secrets.randbelow(1000000),
                   "ok": False, "first": now}
        rec["last"] = now
        if ua:
            rec["ua"] = str(ua)[:120]
        if ip:
            rec["ip"] = str(ip)[:60]
        if fp:
            rec["fp"] = str(fp)[:40]
        data[dev_id] = rec
        _dev_save(data)
        return dict(rec, id=dev_id)


def device_trusted(dev_id: str) -> bool:
    rec = devices().get(dev_id) or {}
    return bool(rec.get("ok"))


def device_allow(dev_id: str) -> tuple[bool, str]:
    """电脑上点"允许"：这台设备以后就能直接进了。"""
    with _dev_lock:
        data = _dev_load()
        rec = data.get(dev_id)
        if not rec:
            return False, "没这台设备（可能已经过期了）"
        rec["ok"] = True
        rec["allowed"] = time.time()
        data[dev_id] = rec
        _dev_save(data)
        return True, "已允许"


def device_deny(dev_id: str) -> tuple[bool, str]:
    """电脑上点"拒绝"：这台设备进不来；半小时内不再为它弹窗（免得被一直骚扰）。"""
    with _dev_lock:
        data = _dev_load()
        rec = data.get(dev_id)
        if not rec:
            return False, "没这台设备"
        rec["ok"] = False
        rec["denied"] = time.time()
        data[dev_id] = rec
        _dev_save(data)
        return True, "已拒绝"


def device_allow_by_code(code: str) -> tuple[bool, str]:
    want = str(code or "").strip()
    for rec in pending_devices():
        if str(rec.get("code")) == want:
            return device_allow(rec["id"])
    return False, "没找到这个配对码"


def device_forget_all() -> int:
    """把设备名单清空（下次谁来都得重新确认）。"""
    with _dev_lock:
        data = _dev_load()
        n = len(data)
        _dev_save({})
        return n


# ------------------------------------------------------- 令牌错了就限速、拉黑
# 公网地址（Funnel）一开，全世界都能敲这个端口 —— 而且 ts.net 的域名会进
# 证书透明度日志，扫描机器人天天来。以前令牌错了只是回一个 401，不痛不痒；
# 现在同一个人连错几次就关门外一段时间。自家手机令牌是对的，不受影响。
TOKEN_MIN_CHARS = 32          # 短于这个的旧令牌直接作废
GUARD_FAILS = 8               # 同一个来源错这么多次 → 拉黑
GUARD_WINDOW = 600.0          # 只数最近 10 分钟里的错
GUARD_BLOCK = 1800.0          # 拉黑 30 分钟
_guard = {"by": {}, "blocked": {}, "fails": 0, "blocks": 0, "last": 0.0}
_guard_lock = threading.Lock()


def guard_blocked(ip: str) -> float:
    """这个来源现在被封着吗？被封就返回还剩几秒。"""
    now = time.time()
    with _guard_lock:
        until = _guard["blocked"].get(ip, 0.0)
        if until and until <= now:
            _guard["blocked"].pop(ip, None)
            return 0.0
        return max(0.0, until - now)


def guard_note(ip: str, ok: bool) -> None:
    """记一次访问结果。令牌对了就把这人的失败记录清干净（别误封自家人）。"""
    now = time.time()
    with _guard_lock:
        _guard["last"] = now
        if ok:
            _guard["by"].pop(ip, None)
            return
        _guard["fails"] += 1
        hits = [t for t in _guard["by"].get(ip, []) if now - t < GUARD_WINDOW]
        hits.append(now)
        if len(hits) >= GUARD_FAILS:
            _guard["blocked"][ip] = now + GUARD_BLOCK
            _guard["by"].pop(ip, None)
            _guard["blocks"] += 1
        else:
            _guard["by"][ip] = hits


def guard_stats() -> dict:
    """给设置面板看：总共错了几次、封了几个、现在还封着谁。"""
    now = time.time()
    with _guard_lock:
        alive = {k: int(v - now) for k, v in _guard["blocked"].items() if v > now}
        return {"fails": _guard["fails"], "blocks": _guard["blocks"],
                "blocked": alive, "last": _guard["last"]}


def guard_reset() -> None:
    """把限速记录清空（自己把自己关门外时用，比如测试之后）。"""
    with _guard_lock:
        _guard["by"].clear()
        _guard["blocked"].clear()


def lan_ip() -> str:
    """本机在局域网里的地址（连不上外网也能拿到，用 UDP 探一下路由）。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.2)
        s.connect(("192.168.1.1", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def phone_url(port: int = DEFAULT_PORT) -> str:
    """手机上要打开的那条网址（设置页也用它）。"""
    return f"http://{lan_ip()}:{int(port)}/?k={load_token()}"


def pc_version() -> str:
    """电脑端现在这个版本号（手机 APP 靠它判断要不要更新）。"""
    try:
        import version as ver_mod

        return str(ver_mod.APP_VERSION)
    except Exception:
        return ""


def phone_app_version() -> str:
    """电脑上这份手机端 APP 的版本（不是电脑端版本）。

    只有这个变了才提示手机更新 —— 电脑端做美化、调小功能的时候它不动。
    优先读打包时写的纸条，读不到就退回 version.py 里的 PHONE_VERSION。
    """
    try:
        got = PHONE_VER_FILE.read_text(encoding="utf-8").strip()
        if got:
            return got
    except Exception:
        pass
    try:
        import version as ver_mod

        return str(getattr(ver_mod, "PHONE_VERSION", ""))
    except Exception:
        return ""


PAGE = """<!doctype html>
<html lang="zh-CN"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="语音助手">
<meta name="theme-color" content="#1b1b1f">
<link rel="manifest" href="manifest.webmanifest?k=__TOKEN__">
<link rel="apple-touch-icon" href="icon-192.png?k=__TOKEN__">
<title>语音助手 · 手机入口</title>
<style>
  :root { color-scheme: dark;
          --accent:#3ddc84; --accent-ink:#10261a; --bg:#1b1b1f; --panel:#26262d;
          --line:#33333c; --fg:#f2f2f5; --dim:#9a9aa5; --font:15px; }
  * { box-sizing: border-box; }
  body { margin:0; background:var(--bg); color:var(--fg);
         background-size:cover; background-position:center;
         font-family:-apple-system,"Microsoft YaHei UI","PingFang SC",sans-serif;
         display:flex; flex-direction:column; height:100vh; }
  header { padding:10px 14px; background:var(--panel); display:flex; align-items:center;
           gap:10px; border-bottom:1px solid var(--line); }
  header .dot { width:9px; height:9px; border-radius:50%; background:var(--accent);
                transition:background .3s ease; }
  header .name { font-weight:600; }
  header .state { margin-left:auto; color:var(--dim); font-size:12px; }
  header .gear { margin-left:8px; color:var(--fg); background:var(--line); font-size:12px;
                 padding:5px 10px; border-radius:9px; cursor:pointer; white-space:nowrap; }
  /* 微信聊天框右下角那个「＋」：点一下从底下滑出一格一格的功能菜单 */
  /* 左边那个"会话抽屉"（像推特那样：在聊天区滑一下，从左边滑出来挑会话） */
  #convbg { position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:20;
            display:none; }
  #convbg.on { display:block; }
  #convdrawer { position:fixed; top:0; bottom:0; left:0; width:84%; max-width:380px;
                background:var(--panel); z-index:21; transform:translateX(-102%);
                transition:transform .26s cubic-bezier(.2,.8,.3,1);
                display:flex; flex-direction:column;
                border-right:1px solid var(--line); }
  #convdrawer.open { transform:none; }
  #convdrawer .dhead { display:flex; align-items:center; gap:8px; padding:14px;
                       border-bottom:1px solid var(--line); }
  #convdrawer .dbody { flex:1; overflow-y:auto; padding:10px 12px 24px; }
  #convdrawer .drow { display:flex; align-items:center; gap:8px; padding:12px 10px;
                      margin:6px 0; border:1px solid var(--line); border-radius:11px;
                      font-size:14px; cursor:pointer; background:var(--bg); }
  #convdrawer .drow.now { background:#2a4a3a; border-color:#3ddc84; }
  #convdrawer .drow .nm { flex:1; overflow:hidden; text-overflow:ellipsis;
                          white-space:nowrap; }
  #convdrawer .drow .tag { color:var(--dim); font-size:11px; flex:0 0 auto; }
  #plus { width:38px; height:38px; border-radius:50%; background:var(--line); color:var(--fg);
          font-size:22px; line-height:38px; text-align:center; flex:0 0 38px; cursor:pointer;
          transition:transform .18s ease; }
  #plus.on { transform:rotate(45deg); background:var(--accent); color:var(--accent-ink); }
  #pluspanel { position:fixed; left:0; right:0; bottom:0; background:var(--panel);
               border-top:1px solid var(--line); border-radius:14px 14px 0 0;
               padding:14px 8px calc(16px + env(safe-area-inset-bottom));
               transform:translateY(110%); transition:transform .26s cubic-bezier(.2,.8,.3,1);
               z-index:19; box-shadow:0 -8px 30px rgba(0,0,0,.45); }
  #pluspanel.open { transform:none; }
  #pluspanel .grid { display:grid; grid-template-columns:repeat(4, 1fr); gap:12px 4px; }
  #pluspanel .tile { display:flex; flex-direction:column; align-items:center; gap:6px;
                     cursor:pointer; }
  #pluspanel .tile .box { width:52px; height:52px; border-radius:14px; background:var(--bg);
                          border:1px solid var(--line); display:flex; align-items:center;
                          justify-content:center; font-size:24px; }
  #pluspanel .tile span { font-size:11px; color:var(--dim); }
  #pluspanel .tile:active .box { transform:scale(.94); }
  #pluspanel .tile .box { transition:transform .12s ease; }
  /* 子页：从右边推进来，顶上一条带返回 */
  .page { position:fixed; inset:0; background:var(--bg); z-index:15;
          transform:translateX(102%); transition:transform .26s cubic-bezier(.2,.8,.3,1);
          display:flex; flex-direction:column; }
  .page.open { transform:none; }
  .phead { display:flex; align-items:center; gap:10px; padding:12px 14px;
           background:var(--panel); border-bottom:1px solid var(--line);
           position:sticky; top:0; cursor:pointer; }
  .phead b { font-size:15px; }
  .phead .back { margin-left:auto; color:var(--accent); font-size:14px; cursor:pointer;
                 padding:4px 8px; }
  .phead .x { color:var(--fg); background:var(--line); border-radius:8px; font-size:14px;
              padding:4px 10px; margin-left:8px; }
  .pbody { flex:1; overflow-y:auto; padding:10px 12px 20px; }
  #app { display:none; margin:0 12px 8px; padding:10px 12px; background:#2a4a3a;
         border:1px solid #3ddc84; border-radius:12px; color:#f2f2f5; font-size:14px; }
  #app a { color:#3ddc84; font-weight:600; text-decoration:none; }
  #upd { display:none; margin:0 12px 8px; padding:10px 12px; background:#4a3a2a;
         border:1px solid #f0a13c; border-radius:12px; color:#f2f2f5; font-size:14px; }
  #upd a { color:#f0a13c; font-weight:600; text-decoration:none; }
  .closex { float:right; margin-left:8px; color:#9a9aa5; cursor:pointer; font-size:16px;
            line-height:1; padding:0 4px; }
  header .ver { color:var(--dim); font-size:11px; margin-left:6px; }
  #log { flex:1; overflow-y:auto; padding:12px; }
  .row { margin:6px 0; display:flex; }
  .row.right { justify-content:flex-end; }
  .row .av { width:28px; height:28px; border-radius:50%; object-fit:cover; flex:0 0 28px;
             background:var(--panel); display:flex; align-items:center; justify-content:center;
             font-size:16px; line-height:28px; text-align:center; overflow:hidden; }
  .row .av.left { margin-right:6px; }
  .row .av.right { margin-left:6px; }
  header .av { width:30px; height:30px; border-radius:50%; object-fit:cover; background:var(--line);
               display:flex; align-items:center; justify-content:center; font-size:17px;
               overflow:hidden; flex:0 0 30px; }
  #wallpaper { position:fixed; inset:0; z-index:0; background-size:cover;
               background-position:center; pointer-events:none; }
  header, #log, footer, #quick { position:relative; z-index:1; }
  .bubble { max-width:86%; padding:8px 11px; border-radius:12px; font-size:var(--font);
            line-height:1.45; white-space:pre-wrap; word-break:break-word;
            animation:pop .22s cubic-bezier(.2,.8,.3,1) both; }
  .me  { margin-left:auto; background:var(--accent); color:var(--accent-ink);
         animation:send .28s cubic-bezier(.2,.9,.25,1) both; }
  .ai  { background:var(--panel); color:var(--fg); }
  .sys { background:transparent; color:var(--dim); font-size:12px; }
  .done { background:transparent; color:var(--accent); font-size:12px; }
  .row.center { justify-content:center; }
  @keyframes send { from { opacity:0; transform:translateX(18px) scale(.96); }
                    to   { opacity:1; transform:none; } }
  .bubble .t { display:block; font-size:11px; opacity:.55; margin-top:3px; }
  .bubble.syswrap { background:transparent; }
  /* 输入栏上面那个「正在思考 ···」的浮动小气泡已经拿掉了（用户要求弄干净点）：
     以前是三个跳动的点，现在整块都不显示，输入栏上面清清爽爽。 */
  footer { padding:10px 12px calc(10px + env(safe-area-inset-bottom)); background:var(--panel);
           border-top:1px solid var(--line); display:flex; gap:8px; }
  textarea { flex:1; resize:none; height:44px; padding:11px 12px; border-radius:10px;
             border:1px solid var(--line); background:var(--bg); color:var(--fg);
             font-size:var(--font); }
  button { border:0; border-radius:10px; padding:0 16px; font-size:15px; font-weight:600;
           background:var(--accent); color:var(--accent-ink); height:44px;
           transition:transform .12s ease, filter .12s ease; }
  button:active { transform:scale(.94); filter:brightness(1.1); }
  button.ghost { background:var(--line); color:var(--fg); font-weight:500; }
  @keyframes pop { from { opacity:0; transform:translateY(8px) scale(.98); }
                   to   { opacity:1; transform:none; } }
  @keyframes slidein { from { opacity:0; transform:translateY(-10px); }
                       to   { opacity:1; transform:none; } }
  /* 新气泡的出生动画：从一个小点慢慢长到**它本来那么大**（不铺满屏幕、不超过边框；
     终点就是正常大小，过冲只留 2%，长句子也不会撑出界） */
  @keyframes born {
    0%   { transform:scale(.06); opacity:0; }
    60%  { transform:scale(1.02); opacity:1; }
    100% { transform:scale(1); opacity:1; }
  }
  .row.born .bubble { animation:born .52s cubic-bezier(.22,.9,.25,1) both;
                      transform-origin:left bottom; }
  .row.right.born .bubble { transform-origin:right bottom; }
  .row.center.born .bubble { transform-origin:center bottom; }
  .row.born .av { animation:born .52s cubic-bezier(.22,.9,.25,1) both; }
  body.noanim .row.born .bubble, body.noanim .row.born .av { animation:none; }
  @keyframes breathe { 0%,100% { opacity:1; } 50% { opacity:.35; } }
  #app, #upd { animation:slidein .28s ease both; }
  header .dot.live { animation:breathe 1.6s ease-in-out infinite; }
  #shots { margin:0 12px 8px; border:1px solid #33333c; border-radius:12px; overflow:hidden; }
  #shots .head { display:flex; align-items:center; gap:8px; padding:8px 10px; background:#26262d; }
  #shots .head b { font-weight:600; }
  #shots .head .sp { margin-left:auto; }
  #shots .body { display:none; padding:8px 10px 10px; background:#1f1f24; }
  #shots.open .body { display:block; animation:slidein .22s ease both; }
  #shots img { width:100%; border-radius:8px; cursor:pointer; display:block; }
  #shots .meta { color:#7f7f8a; font-size:12px; margin:6px 0 0; }
  #shots .row2 { display:flex; gap:8px; margin-top:8px; flex-wrap:wrap; }
  #shots .chip { background:#33333c; color:#f2f2f5; border-radius:8px; padding:5px 9px;
                 font-size:12px; cursor:pointer; }
  #files { margin:0 12px 8px; border:1px solid var(--line); border-radius:12px; overflow:hidden; }
  #files .head { display:flex; align-items:center; gap:8px; padding:8px 10px; background:var(--panel); }
  #files .body { display:none; padding:8px 10px 10px; background:#1f1f24; }
  #files.open .body { display:block; animation:slidein .22s ease both; }
  #files .f { display:flex; align-items:center; gap:8px; padding:7px 0; font-size:13px;
              border-bottom:1px solid var(--line); }
  #files .f:last-child { border-bottom:0; }
  #files .f a { color:var(--accent); text-decoration:none; flex:1; overflow:hidden;
                text-overflow:ellipsis; white-space:nowrap; }
  #files .f span { color:var(--dim); font-size:11px; }
  #files input[type=text] { flex:1; padding:8px 10px; border-radius:9px; border:1px solid var(--line);
       background:var(--bg); color:var(--fg); font-size:13px; }
  #files .line { display:flex; gap:6px; margin-top:8px; }
  #quick { display:flex; gap:6px; padding:6px 12px 0; overflow-x:auto; background:var(--panel);
           border-top:1px solid var(--line); }
  #quick b { background:var(--line); color:var(--fg); border-radius:9px; padding:6px 10px;
             font-size:12px; font-weight:500; white-space:nowrap; cursor:pointer;
             transition:transform .12s ease; }
  #quick b:active { transform:scale(.94); }
  #mic { background:var(--accent); color:var(--accent-ink); }
  #searchline { display:none; padding:6px 12px 0; background:var(--panel); gap:6px; }
  #searchline.on { display:flex; }
  #searchline input { flex:1; padding:8px 10px; border-radius:9px; border:1px solid var(--line);
                      background:var(--bg); color:var(--fg); font-size:13px; }
  /* 外观设置：从底部滑上来的一张面板 */
  #sheet { position:fixed; left:0; right:0; bottom:0; background:var(--panel);
           border-top:1px solid var(--line); border-radius:14px 14px 0 0; padding:14px 14px 20px;
           transform:translateY(110%); transition:transform .28s cubic-bezier(.2,.8,.3,1);
           z-index:9; box-shadow:0 -8px 30px rgba(0,0,0,.45);
           max-height:88vh; overflow-y:auto; }      /* 内容变多了，得能滚、关得掉 */
  #sheet.open { transform:none; }
  #sheethead { display:flex; align-items:center; margin-bottom:6px; }
  #sheethead .cl { margin-left:auto; background:var(--line); color:var(--fg); border-radius:8px;
                   font-size:14px; padding:4px 12px; cursor:pointer; }
  /* 点空白处关掉：面板/菜单背后垫一层看不见的挡板，点一下就收 */
  #sheetbg { position:fixed; inset:0; z-index:8; display:none; }
  #sheetbg.on { display:block; }
  #plusbg { position:fixed; inset:0; z-index:18; display:none; }
  #plusbg.on { display:block; }
  #sheet h4 { margin:0 0 8px; font-size:14px; font-weight:600; }
  #sheet .lab { color:var(--dim); font-size:12px; margin:12px 0 6px; }
  #sheet .sw { display:flex; gap:8px; flex-wrap:wrap; }
  #sheet .sw span { width:30px; height:30px; border-radius:50%; cursor:pointer;
                    border:2px solid transparent; }
  #sheet .sw span.on { border-color:var(--fg); }
  #sheet .chips { display:flex; gap:8px; flex-wrap:wrap; }
  #sheet .chips b { background:var(--line); color:var(--fg); border-radius:9px;
                    padding:7px 11px; font-size:13px; font-weight:500; cursor:pointer; }
  #sheet .chips b.on { background:var(--accent); color:var(--accent-ink); font-weight:600; }
  #sheet input[type=text] { width:100%; padding:9px 11px; border-radius:9px;
       border:1px solid var(--line); background:var(--bg); color:var(--fg); font-size:13px; }
  #sheet .chips b { white-space:nowrap; }
  #sheet .done { margin-top:14px; width:100%; }
</style></head>
<body>
<div id="wallpaper"></div>
<header><span class="av" id="avhead"><img src="icon-192.png?k=__TOKEN__"
    style="width:100%;height:100%;object-fit:cover"></span>
  <span class="dot" id="dot"></span><span class="name" id="appname">语音助手</span>
  <span class="state" id="state"></span>
  <span class="gear" id="gear">⚙ 设置</span></header>
<div id="app"><span class="closex" id="appx">✕</span>📱 想在手机上装个 APP？
  <a id="apklink" href="#">点这里下载安装包</a>
  （安卓：下载后点开、允许安装即可；iPhone 用浏览器「分享 → 添加到主屏幕」）</div>
<div id="upd">⬆️ 手机端有新版了：电脑上是 <b id="updver"></b>，你装的还是 <b id="myver"></b>：
  <span class="closex" id="updx">✕</span>
  <a id="updlink" href="#">点这里更新（覆盖安装，地址不用重填）</a>
  <span style="color:#9a9aa5">（点右边 ✕ 可以关掉，下次有新版本再提醒）</span></div>
<div id="shots">
  <div class="head">
    <b>📺 电脑屏幕</b>
    <span class="sp"></span>
    <button class="ghost" id="shotbtn" style="height:32px;font-size:13px">📷 截图</button>
    <button class="ghost" id="recbtn" style="height:32px;font-size:13px">⏺ 录 8 秒</button>
    <button class="ghost" id="shottoggle" style="height:32px;font-size:13px">展开</button>
  </div>
  <div class="body">
    <img id="shotimg" alt="电脑屏幕" style="display:none">
    <div class="meta" id="shotmeta">还没有截图 —— 点上面「截图」或「录 8 秒」</div>
    <div class="row2" id="shotlist"></div>
  </div>
</div>
<div id="files">
  <div class="head">
    <b>📁 文件</b>
    <span class="sp" style="margin-left:auto"></span>
    <button class="ghost" id="upbtn" style="height:32px;font-size:13px">📤 传到电脑</button>
    <button class="ghost" id="filetoggle" style="height:32px;font-size:13px">展开</button>
  </div>
  <div class="body">
    <div id="filelist"></div>
    <div class="line">
      <input type="text" id="askfile" placeholder="跟电脑要文件：输入文件名，如 报表.xlsx">
      <button class="ghost" id="askbtn" style="height:36px;font-size:13px">要</button>
    </div>
    <input type="file" id="upfile" style="display:none">
    <input type="file" id="imgfile" accept="image/*" multiple style="display:none">
    <div class="meta" id="filemeta" style="color:var(--dim);font-size:12px;margin-top:6px"></div>
  </div>
</div>
<div id="log"></div>
<div id="pluspanel">
  <div class="grid">
    <div class="tile" data-page="shots"><div class="box">📺</div><span>电脑屏幕</span></div>
    <div class="tile" data-page="files"><div class="box">📁</div><span>文件</span></div>
    <div class="tile" data-page="wins"><div class="box">💬</div><span>对话会话</span></div>
    <div class="tile" data-page="search"><div class="box">🔍</div><span>搜历史</span></div>
    <div class="tile" id="tiimg"><div class="box">🖼</div><span>发图片</span></div>
    <div class="tile" id="tilook"><div class="box">🎨</div><span>外观</span></div>
    <div class="tile" id="ticonn"><div class="box">🔗</div><span>连接</span></div>
    <div class="tile" data-cmd="截图发手机"><div class="box">📷</div><span>截图</span></div>
    <div class="tile" data-cmd="录 8 秒发手机"><div class="box">⏺</div><span>录 8 秒</span></div>
    <div class="tile" data-cmd="状态"><div class="box">📊</div><span>状态</span></div>
    <div class="tile" data-cmd="停"><div class="box">✋</div><span>停</span></div>
    <div class="tile" id="tiavatar"><div class="box">🙂</div><span>头像</span></div>
  </div>
</div>
<div id="plusbg"></div>
<div id="sheetbg"></div>
<!-- 左边这个会话抽屉：在聊天区往左滑（或从左边缘往右拖）就出来，挑一个会话 -->
<div id="convbg"></div>
<div id="convdrawer">
  <div class="dhead">
    <b style="font-size:15px">💬 对话会话</b>
    <span id="convwho" style="color:var(--dim);font-size:11px"></span>
    <span id="convclose" style="margin-left:auto;color:var(--fg);background:var(--line);
          border-radius:8px;padding:4px 10px;font-size:13px;cursor:pointer">✕</span>
  </div>
  <div class="dbody" id="convlist"></div>
</div>
<div class="page" id="page-shots">
  <div class="phead"><b>📺 电脑屏幕</b>
    <span class="back" data-back>← 返回</span><span class="x" data-back>✕</span></div>
  <div class="pbody" id="body-shots"></div>
</div>
<div class="page" id="page-files">
  <div class="phead"><b>📁 文件收发</b>
    <span class="back" data-back>← 返回</span><span class="x" data-back>✕</span></div>
  <div class="pbody" id="body-files"></div>
</div>
<div class="page" id="page-wins">
  <div class="phead"><b>💬 发到哪个对话会话</b>
    <span class="back" data-back>← 返回</span><span class="x" data-back>✕</span></div>
  <div class="pbody">
    <div style="color:var(--dim);font-size:12px;margin-bottom:8px">
      这是**我和你的会话**（电脑上 Codex 侧栏里那些），自动读出来、实时同步：
      点一个手机就帮你切过去，以后手机发的话都进那一个。最上面「自动」＝电脑上开着哪个就发哪个。
    </div>
    <div id="body-wins"></div>
  </div>
</div>
<div class="page" id="page-search">
  <div class="phead"><b>🔍 搜历史</b>
    <span class="back" data-back>← 返回</span><span class="x" data-back>✕</span></div>
  <div class="pbody">
    <div class="line" style="display:flex;gap:6px">
      <input type="text" id="searchbox" placeholder="搜聊天记录里的关键词">
      <button class="ghost" id="searchgo" style="height:36px;font-size:13px">搜</button>
    </div>
    <div id="searchout" style="margin-top:10px"></div>
  </div>
</div>
<div id="sheet">
  <div id="sheethead"><h4 style="margin:0">设置</h4><span class="cl" id="sheetclose">✕ 关闭</span></div>
  <div class="lab">名字（手机上显示的名字，默认跟电脑上那个一样）</div>
  <input type="text" id="nameline" placeholder="比如 大肥鱼">
  <div class="lab">版本</div>
  <div style="color:var(--dim);font-size:12px" id="verline">手机端 — · 电脑端 —</div>
  <div class="lab">更新</div>
  <div class="line" style="display:flex;gap:8px;align-items:center">
    <span id="updnow" style="color:var(--dim);font-size:12px;flex:1">进 APP 里点一下就能更新</span>
    <button class="ghost" id="updbtn" style="height:34px;font-size:13px">检查更新</button>
  </div>
  <div class="lab" id="remotelab">外网访问（在外地 / 用流量也能连）</div>
  <div class="line" style="display:flex;gap:8px;align-items:center">
    <span id="fixedurl" style="color:var(--dim);font-size:11px;flex:1;
          word-break:break-all">正在读…</span>
    <button class="ghost" id="fixedcopy" style="height:34px;font-size:13px">复制</button>
  </div>
  <div class="chips" style="margin-top:8px">
    <b id="tssetup">📶 装 / 开 Tailscale</b>
    <b id="fixeduse">✅ 用这条地址连</b>
    <b id="tsalways">🔁 后台自动连（设一次）</b>
  </div>
  <div id="tstip" style="color:var(--dim);font-size:11.5px;margin-top:6px;line-height:1.7">
    在外面（流量 / 别的 Wi-Fi）也想用：点「装 / 开 Tailscale」——
    APP 里会自动把官方 APK 下下来装上（不用去应用商店找），装好用它登录电脑上那个账号，
    回来点「用这条地址连」就切过去了。地址固定，以后不用再改。<br>
    想更省事：点一下「后台自动连」——APP 会带你去安卓的 VPN 设置，把 Tailscale 设成
    「始终开启的 VPN」。设完这一次，<b>以后只开语音助手这一个 APP 就行</b>：
    在家自动走局域网，在外面自动走 Tailscale，Tailscale 的界面你再也不用打开。
  </div>
  <div class="lab">关于 / 署名</div>
  <div id="aboutbox" style="background:var(--line);border-radius:11px;padding:10px 12px;
       font-size:12px;line-height:1.75">
    <div id="aboutauthor" style="color:var(--fg)">作者：—</div>
    <div id="aboutcontact" style="color:var(--fg)">邮箱：—</div>
    <div id="aboutcopy" style="color:var(--dim)">©</div>
    <div id="aboutfree" style="color:#3ddc84;margin-top:2px"></div>
    <div id="aboutnotice" style="color:var(--dim);font-size:11px;margin-top:6px"></div>
  </div>
  <div id="connsec" style="display:none">
    <div class="lab">电脑地址（换 Wi-Fi / 换电脑 / Tailscale 就改这里）</div>
    <div class="line" style="display:flex;gap:6px;align-items:center">
      <input type="text" id="cururl" readonly style="flex:1">
      <button class="ghost" id="editurl" style="height:34px;font-size:13px">修改</button>
    </div>
    <div class="chips" style="margin-top:8px">
      <b id="scanbtn">🔍 扫码连接</b>
      <b id="reloadbtn">🔄 刷新页面</b>
      <b id="reseturl">恢复出厂地址</b>
    </div>
    <div class="lab">电脑忙完提醒我（手机上弹通知）</div>
    <div class="chips">
      <b id="notifyon">开</b>
      <b id="notifyoff">关</b>
    </div>
  </div>
  <div class="lab">主题色</div>
  <div class="lab">主题色</div>
  <div class="sw" id="sw-accent"></div>
  <div class="lab">背景</div>
  <div class="chips" id="sw-bg"></div>
  <div class="lab">壁纸</div>
  <div class="chips" id="sw-wall">
    <b id="pickself">📷 从手机选</b>
    <b id="clearwall">不用壁纸</b>
  </div>
  <div class="lab">壁纸透明度 <span id="wallval">100%</span></div>
  <input type="range" id="wallalpha" min="5" max="100" value="100"
         style="width:100%;accent-color:var(--accent)">
  <img id="wallprev" style="display:none;margin-top:8px;max-height:90px;border-radius:8px">
  <input type="file" id="wallfile" accept="image/*" style="display:none">
  <div class="lab">或者填图片网址</div>
  <input type="text" id="bgurl" placeholder="https://… 或留空">
  <div class="lab">头像（默认就是程序那个图标）</div>
  <div id="avsec"></div>
  <div class="chips">
    <b id="pickavme">📷 我的头像</b>
    <b id="pickavai">📷 它的头像</b>
    <b id="avicon">用图标</b>
    <b id="avee">🫥 不用头像</b>
  </div>
  <div class="chips" style="margin-top:6px" id="avquick"></div>
  <input type="file" id="avfile" accept="image/*" style="display:none">
  <div class="lab">字号</div>
  <div class="chips" id="sw-font"></div>
  <div class="lab">气泡动画</div>
  <div class="chips" id="sw-anim"></div>
  <button class="done" id="sheetdone">好了</button>
</div>
<footer>
  <textarea id="box" placeholder="打句话发过去…" rows="1"></textarea>
  <button id="send">发送</button>
  <button class="ghost" id="stop">停</button>
  <span id="plus">＋</span>
</footer>
<script>
const KEY = new URLSearchParams(location.search).get("k") || "";
const Q = "?k=" + encodeURIComponent(KEY);
// 公网下载页的网址（电脑设置里填过才有）。有了它，更新就以**网站上的文件**为准。
let siteBase = "";
// 外网那条固定地址（电脑上 Tailscale 开着才有）和它的官方 APK 地址。
// 手机不在同一个 Wi-Fi 时，就是靠这两样切过去。
let remoteUrl = "";
let tsApk = "";
const mine = [];                 // 我刚发出去的几句（防止日志回读时显示两条）
const ACCENTS = ["#3ddc84", "#4aa8ff", "#b06bff", "#f0a13c", "#ff6b9d", "#22d3ee"];
// 头像：默认就是程序那个图标（服务端已经在发 /icon-192.png），也能从手机相册选。
const ICON_AV = "icon-192.png?k=" + encodeURIComponent(
  new URLSearchParams(location.search).get("k") || "");
const AV_EMOJI = ["🐟", "🐰", "🐱", "🤖", "🧑", "😎", "🌙", "🍀"];
const BGS = [["深色", "#1b1b1f", "#26262d", "#33333c", "#f2f2f5"],
             ["纯黑", "#000000", "#141418", "#26262d", "#f2f2f5"],
             ["浅色", "#f4f4f7", "#ffffff", "#e6e6ec", "#1b1b1f"],
             ["藏青", "#101828", "#1c2740", "#2a3a5c", "#eef2ff"]];
let look = JSON.parse(localStorage.getItem("look") || "{}");
let lastSentAt = 0;

/** 应用外观：主题色 / 背景 / 字号 / 动画开关（存在手机上，换页面也记得）。 */
function applyLook() {
  const a = look.accent || ACCENTS[0];
  const bg = look.bg || BGS[0];
  const r = document.documentElement.style;
  r.setProperty("--accent", a);
  r.setProperty("--accent-ink", (look.accentInk || "#10261a"));
  r.setProperty("--bg", bg[1]);
  r.setProperty("--panel", bg[2]);
  r.setProperty("--line", bg[3]);
  r.setProperty("--fg", bg[4]);
  r.setProperty("--dim", bg[4] === "#1b1b1f" ? "#6b6b75" : "#7f7f8a");
  r.setProperty("--font", (look.font || "15px"));
  const wall = look.bgimg || look.bgurl || "";
  const layer = document.getElementById("wallpaper");
  if (layer) {
    layer.style.backgroundImage = wall ? "url('" + wall + "')" : "";
    layer.style.opacity = String(look.wallAlpha === undefined ? 1 : look.wallAlpha);
  }
  const wa = document.getElementById("wallalpha");
  if (wa) {
    const pct = Math.round((look.wallAlpha === undefined ? 1 : look.wallAlpha) * 100);
    wa.value = String(pct);
    const wv = document.getElementById("wallval");
    if (wv) wv.textContent = pct + "%";
  }
  const anim = look.anim !== false;
  document.body.classList.toggle("noanim", !anim);   // 关掉动画时，新气泡也别做出生的动画
  document.querySelectorAll(".bubble").forEach(b => {
    b.style.animation = anim ? "" : "none";
  });
}

function buildSheet() {
  const sw = document.getElementById("sw-accent");
  ACCENTS.forEach(c => {
    const s = document.createElement("span");
    s.style.background = c;
    if ((look.accent || ACCENTS[0]) === c) s.className = "on";
    s.onclick = () => { look.accent = c; look.accentInk = pickInk(c); save(); };
    sw.appendChild(s);
  });
  const bg = document.getElementById("sw-bg");
  BGS.forEach(b => {
    const s = document.createElement("b");
    s.textContent = b[0];
    if ((look.bgName || "深色") === b[0]) s.className = "on";
    s.onclick = () => { look.bg = b; look.bgName = b[0]; save(); };
    bg.appendChild(s);
  });
  const fo = document.getElementById("sw-font");
  [["小", "14px"], ["中", "15px"], ["大", "17px"]].forEach(([n, v]) => {
    const s = document.createElement("b");
    s.textContent = n;
    if ((look.font || "15px") === v) s.className = "on";
    s.onclick = () => { look.font = v; save(); };
    fo.appendChild(s);
  });
  const an = document.getElementById("sw-anim");
  [["开", true], ["关", false]].forEach(([n, v]) => {
    const s = document.createElement("b");
    s.textContent = n;
    if ((look.anim !== false) === v) s.className = "on";
    s.onclick = () => { look.anim = v; save(); };
    an.appendChild(s);
  });
  document.getElementById("bgurl").value = look.bgurl || "";
  const prev = document.getElementById("wallprev");
  if (look.bgimg) {
    prev.src = look.bgimg; prev.style.display = "block";
  } else {
    prev.style.display = "none";
  }
}

// 壁纸：直接从手机的相册里选。手机上拍的图动辄好几兆，localStorage 放不下，
// 所以先在手机里缩到 1600 宽、压成 jpeg 再存（一般 100~400KB）。
document.getElementById("pickself").onclick = () => document.getElementById("wallfile").click();
// 壁纸透明度：拖动就实时预览，松手存下来（存手机上）
document.getElementById("wallalpha").oninput = (e) => {
  look.wallAlpha = Math.max(0.05, Math.min(1, Number(e.target.value) / 100));
  document.getElementById("wallval").textContent = e.target.value + "%";
  document.getElementById("wallpaper").style.opacity = String(look.wallAlpha);
};
document.getElementById("wallalpha").onchange = () => {
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
};
document.getElementById("clearwall").onclick = () => {
  look.bgimg = ""; look.bgurl = "";
  localStorage.setItem("look", JSON.stringify(look));
  applyLook();
  document.getElementById("bgurl").value = "";
  document.getElementById("wallprev").style.display = "none";
};
document.getElementById("wallfile").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  // 先给个反馈，免得看着像"点了没反应"
  const ding = document.getElementById("sheetdone");
  const old = ding.textContent;
  ding.textContent = "正在处理这张图…";
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      let data = "";
      try {                                  // 正常路：缩到 1600 宽再压（省地方）
        const maxw = 1600;
        const scale = Math.min(1, maxw / img.width);
        const c = document.createElement("canvas");
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        let q = 0.82;
        data = c.toDataURL("image/jpeg", q);
        while (data.length > 3_500_000 && q > 0.4) {     // 太大了就再压一点
          q -= 0.15;
          data = c.toDataURL("image/jpeg", q);
        }
      } catch (err) {                        // 万一 canvas 不给用，就用原图
        data = fr.result;
      }
      look.bgimg = data;
      try {
        localStorage.setItem("look", JSON.stringify(look));
      } catch (err) {
        document.getElementById("sheetdone").textContent = "图太大，换张小点的";
        return;
      }
      ding.textContent = old;
      applyLook();
      document.getElementById("wallprev").src = data;
      document.getElementById("wallprev").style.display = "block";
    };
    img.onerror = () => { ding.textContent = old; };
    img.src = fr.result;
  };
  fr.onerror = () => { ding.textContent = old; };
  fr.readAsDataURL(f);
  e.target.value = "";
};

// ---- 头像 ----
let avWho = "me";                       // 这一次点的是换谁的头像
function buildAvQuick() {
  const box = document.getElementById("avquick");
  box.innerHTML = "";
  AV_EMOJI.forEach((em) => {
    const b = document.createElement("b");
    b.textContent = em;
    b.onclick = () => { setAvatar(avWho, "emoji:" + em); };
    box.appendChild(b);
  });
}
function setAvatar(who, value) {
  if (who === "me") { look.avMe = value; } else { look.avAi = value; }
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (e) {}
  refreshAvatars();
}
document.getElementById("pickavme").onclick = () => { avWho = "me"; document.getElementById("avfile").click(); };
document.getElementById("pickavai").onclick = () => { avWho = "ai"; document.getElementById("avfile").click(); };
document.getElementById("avicon").onclick = () => setAvatar(avWho, "icon");
document.getElementById("avee").onclick = () => setAvatar(avWho, "");
document.getElementById("avfile").onchange = (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const ding = document.getElementById("sheetdone");
  const old = ding.textContent;
  ding.textContent = "正在处理这张头像…";
  const fr = new FileReader();
  fr.onload = () => {
    const img = new Image();
    img.onload = () => {
      let data = "";
      try {                                    // 正常路：正方形裁一下、缩到 128
        const side = Math.min(img.width, img.height);
        const c = document.createElement("canvas");
        c.width = c.height = 128;
        c.getContext("2d").drawImage(
          img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 128, 128);
        data = c.toDataURL("image/jpeg", 0.85);
      } catch (err) {                          // canvas 不给用就用原图
        data = fr.result;
      }
      ding.textContent = old;
      setAvatar(avWho, data);
    };
    img.onerror = () => { ding.textContent = old; };
    img.src = fr.result;
  };
  fr.onerror = () => { ding.textContent = old; };
  fr.readAsDataURL(f);
  e.target.value = "";
};
buildAvQuick();

function pickInk(hex) {                       // 深色主题配绿/蓝用深字，浅色配浅字
  const n = parseInt(hex.slice(1), 16);
  const lum = 0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
  return lum > 150 ? "#10261a" : "#ffffff";
}

function save() {
  localStorage.setItem("look", JSON.stringify(look));
  applyLook();
  document.querySelectorAll("#sheet .sw span, #sheet .chips b").forEach(e => e.classList.remove("on"));
  document.getElementById("sw-accent").innerHTML = "";
  document.getElementById("sw-bg").innerHTML = "";
  document.getElementById("sw-font").innerHTML = "";
  document.getElementById("sw-anim").innerHTML = "";
  buildSheet();
}

document.getElementById("gear").onclick = () => {
  const s = document.getElementById("sheet");
  if (s.classList.contains("open")) {
    s.classList.remove("open");
    document.getElementById("sheetbg").classList.remove("on");
  } else {
    openSheet();
  }
};
/** 打开设置面板；带 conn=true 时滚到"连接"那一节（抽屉里点「连接」走这条）。 */
function openSheet(conn) {
  const s = document.getElementById("sheet");
  s.classList.add("open");
  document.getElementById("sheetbg").classList.add("on");
  if (conn) {
    const sec = document.getElementById("connsec");
    if (sec) setTimeout(() => sec.scrollIntoView({block: "center", behavior: "smooth"}), 240);
  }
}
document.getElementById("bgurl").onchange = e => {
  look.bgurl = e.target.value.trim();
  if (look.bgurl) look.bgimg = "";
  save();
};

// ---- 在 APP 里才有的：扫码 / 刷新 / 改地址（以前是底下那三个丑按钮，现在都进设置） ----
if (window.VoiceApp) {
  document.getElementById("connsec").style.display = "block";
  const cur = document.getElementById("cururl");
  try { cur.value = window.VoiceApp.url(); } catch (e) { cur.value = ""; }
  document.getElementById("editurl").onclick = () => window.VoiceApp.editUrl();
  document.getElementById("scanbtn").onclick = () => window.VoiceApp.scan();
  document.getElementById("reloadbtn").onclick = () => window.VoiceApp.reload();
  document.getElementById("reseturl").onclick = () => {
    // 恢复出厂地址：跟"修改"那条路走同一个原生弹窗（里面也有恢复按钮）
    window.VoiceApp.editUrl();
  };
  // 电脑忙完的提醒开关（APP 里才有的前台服务）
  const mark = () => {
    let on = true;
    try { on = window.VoiceApp.notifyOn(); } catch (e) {}
    document.getElementById("notifyon").classList.toggle("on", on);
    document.getElementById("notifyoff").classList.toggle("on", !on);
  };
  document.getElementById("notifyon").onclick = () => {
    try { window.VoiceApp.setNotify(true); } catch (e) {}
    mark();
  };
  document.getElementById("notifyoff").onclick = () => {
    try { window.VoiceApp.setNotify(false); } catch (e) {}
    mark();
  };
  mark();
}
document.getElementById("sheetdone").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
document.getElementById("sheetclose").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
if (/Android/i.test(navigator.userAgent)) {
  // 已经装在 APP 里（有 VoiceApp 这个桥）就不用再劝装 APP 了；关过一次也不再冒出来
  if (!window.VoiceApp && localStorage.getItem("hideInstall") !== "1") {
    document.getElementById("app").style.display = "block";
  }
  document.getElementById("apklink").href = "app.apk?k=" + encodeURIComponent(KEY);
}
document.getElementById("appx").onclick = () => {
  localStorage.setItem("hideInstall", "1");
  document.getElementById("app").style.display = "none";
};
document.getElementById("updx").onclick = () => {
  // 记住"这个版本我看见了"——同一个版本不再烦你，等手机端再出新版才提醒
  localStorage.setItem("updSeen", document.getElementById("updver").textContent || "");
  document.getElementById("upd").style.display = "none";
};
// 更新：只看**手机端自己的版本**（电脑端美化之类的不打扰手机）
// 一是一进页面自动查（有新版就在上面弹条横幅），二是设置里那个常驻的按钮
// （用户要求：设置里要有个随时能点的入口，不能只靠横幅）。
let updLatest = "";
function apkUrl() {
  // 必须给绝对地址：安卓那边 Uri.parse 认不了相对地址（这就是以前"一键更新用不了"的原因之一）
  return location.origin + "/app.apk?k=" + encodeURIComponent(KEY);
}
function doUpdate() {
  const now = document.getElementById("updnow");
  if (window.VoiceApp && window.VoiceApp.openUpdate) {
    if (now) now.textContent = "正在下载新版…（装的时候跟着系统提示点「更新」）";
    window.VoiceApp.openUpdate(apkUrl());
  } else {                       // 浏览器里打开的：只能去下，浏览器不会自动装
    if (now) now.textContent = "浏览器里装不了，用 APP 打开这条网址再点一次";
    window.open(apkUrl(), "_blank");
  }
}
async function refreshUpdRow() {
  const now = document.getElementById("updnow");
  const btn = document.getElementById("updbtn");
  if (!now || !btn) return;
  const appv = (window.VoiceApp && window.VoiceApp.version) ? window.VoiceApp.version() : "";
  if (!appv) {
    now.textContent = "浏览器打开的：装个 APP 就能一键更新";
    btn.textContent = "下载 APP";
    btn.onclick = doUpdate;
    return;
  }
  now.textContent = "正在检查…";
  try {
    // 版本信息以**网站上那份数据**为准（GitHub 上的 version.json）：网站一刷新，这边就提示更新。
    // 万一那一页还没起来，退回老接口读，保证"能提示"这件事不会因为一个接口没了就哑掉。
    let d = {};
    try {
      const mf = await updateManifest();
      if (!mf) throw new Error("清单读不到");
      d = {phone: (mf.phone || {}).version || "", pc: (mf.pc || {}).version || ""};
    } catch (e0) {
      const r = await fetch("/api/version?k=" + encodeURIComponent(KEY));
      d = await r.json();
    }
    const num = v => parseInt(String(v).split(".").pop(), 10) || 0;
    updLatest = String(d.phone || "");
    if (updLatest && num(updLatest) > num(appv)) {
      now.textContent = "有新版 v" + updLatest + "（你现在 v" + appv + "）";
      btn.textContent = "一键更新";
    } else {
      now.textContent = "已经是最新（v" + appv + "）";
      btn.textContent = "再看一眼";
    }
    btn.onclick = () => (updLatest && num(updLatest) > num(appv)) ? doUpdate()
                                                                  : refreshUpdRow();
  } catch (e) {
    now.textContent = "检查更新失败：连不上电脑？";
    btn.textContent = "重试";
    btn.onclick = refreshUpdRow;
  }
}
async function checkUpdate() {
  const appv = (window.VoiceApp && window.VoiceApp.version) ? window.VoiceApp.version() : "";
  if (appv) {
    // 版本号挪进设置了，页面上不显示（用户要求）
    const vl = document.getElementById("verline");
    if (vl) vl.dataset.phone = "v" + appv;
  }
  try {
    const r = await fetch("/api/version?k=" + encodeURIComponent(KEY));
    const d = await r.json();
    const num = v => parseInt(String(v).split(".").pop(), 10) || 0;
    if (appv && d.phone && num(d.phone) > num(appv)
        && localStorage.getItem("updSeen") !== ("v" + d.phone)) {
      document.getElementById("updver").textContent = "v" + d.phone;
      document.getElementById("myver").textContent = "v" + appv;
      document.getElementById("upd").style.display = "block";
      document.getElementById("updlink").onclick = function (e) {
        e.preventDefault();
        doUpdate();
      };
    }
  } catch (e) {}
  refreshUpdRow();
}
const logEl = document.getElementById("log");
const box = document.getElementById("box");
let since = 0, first = true;
function add(cls, text) {
  const row = document.createElement("div"); row.className = "row";
  if (cls === "me") row.className = "row right";
  if (cls === "done") row.className = "row center";
  row.dataset.kind = cls;
  if (cls === "me" || cls === "ai") {
    const av = document.createElement("span");
    av.className = "av " + (cls === "me" ? "right" : "left");
    fillAvatar(av, cls);
    if (cls === "me") row.appendChild(av);   // 自己的：气泡在左、头像在最右
  }
  const b = document.createElement("div"); b.className = "bubble " + cls;
  b.textContent = text;
  const t = document.createElement("span");
  t.className = "t";
  t.textContent = new Date().toLocaleTimeString("zh-CN", {hour: "2-digit", minute: "2-digit"});
  b.appendChild(t);
  // 长按复制（手机上很有用：AI 回答里常要挑一段拿走）
  b.addEventListener("contextmenu", e => { e.preventDefault();
    navigator.clipboard && navigator.clipboard.writeText(text);
    b.style.filter = "brightness(1.3)"; setTimeout(() => b.style.filter = "", 160);
  });
  row.appendChild(b);
  logEl.appendChild(row);
  // 一条新消息：从一个小点慢慢长大（设置里「气泡动画」关掉就不做）
  if (look.anim !== false) {
    row.classList.add("born");
    setTimeout(() => row.classList.remove("born"), 760);
  }
  logEl.scrollTop = logEl.scrollHeight;
}

/** 往一个头像位里填东西：图标 / 手机选的图 / emoji / 不显示。 */
function fillAvatar(el, who) {
  const v = who === "me" ? (look.avMe ?? "icon") : (look.avAi ?? "icon");
  el.innerHTML = "";
  if (v === "" ) { el.style.display = "none"; return; }
  el.style.display = "flex";
  if (v === "icon") {
    const img = document.createElement("img");
    img.src = ICON_AV;
    img.style.width = "100%"; img.style.height = "100%"; img.style.objectFit = "cover";
    el.appendChild(img);
  } else if (v.startsWith("emoji:")) {
    el.textContent = v.slice(6);
  } else {
    const img = document.createElement("img");
    img.src = v;
    img.style.width = "100%"; img.style.height = "100%"; img.style.objectFit = "cover";
    el.appendChild(img);
  }
}

/** 换头像之后，把已经显示出来的那些也一起换掉。 */
function refreshAvatars() {
  document.querySelectorAll("#log .row").forEach(row => {
    const who = row.dataset.kind;
    const av = row.querySelector(".av");
    if (av && (who === "me" || who === "ai")) fillAvatar(av, who);
  });
  const head = document.getElementById("avhead");
  if (head) fillAvatar(head, "ai");
}
let pulling = false;                 // 上一次还没回来就不再发请求（防并发）
let lastN = 0;                       // 已经显示过的最大日志行号
async function pull() {
  if (pulling) return;
  pulling = true;
  try {
    const r = await fetch("/api/log?since=" + since + "&k=" + encodeURIComponent(KEY));
    if (!r.ok) throw new Error(r.status);
    const d = await r.json();
    // 右边那行"说唤醒词"之类的小字去掉了：只在连不上时提示一句
    const stEl = document.getElementById("state");
    stEl.textContent = d.online ? "" : "连不上";
    const dot = document.getElementById("dot");
    dot.style.background = d.online ? "#3ddc84" : "#7f7f8a";
    dot.classList.toggle("live", !!d.online);
    // （输入栏上面那个「正在思考 ···」的浮动小气泡整个去掉了 —— 用户说"上面弄干净点"。
    //   它忙不忙看顶上的状态就行，不用在输入栏上面挂三个跳动的点。）
    for (const it of d.lines) {
      // 按"日志行号"去重：并发请求、重连、页面重绘都不会把同一行塞两遍
      if (it.n <= lastN) { since = Math.max(since, it.n); continue; }
      lastN = it.n;
      since = it.n;
      if (it.kind === "ai") { lastSentAt = 0; }        // 它回话了 → 收掉思考提示
      // 本地已经显示过的那句别再显示一遍（真机反馈"手机发出去会重复"就是这个）
      const i = mine.findIndex(m => m.text === it.text && (Date.now() - m.at) < 20000);
      if (it.kind === "me" && i >= 0) { mine.splice(i, 1); continue; }
      add(it.kind, it.text);
    }
  } catch (e) {
    document.getElementById("state").textContent = "连不上";
    document.getElementById("dot").style.background = "#e05252";
    document.getElementById("dot").classList.remove("live");
  } finally {
    pulling = false;
  }
}
async function post(path, body) {
  try {
    await fetch(path + "?k=" + encodeURIComponent(KEY), {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify(body || {})});
  } catch (e) {}
}
document.getElementById("send").onclick = async () => {
  const t = box.value.trim(); if (!t) return;
  add("me", t); box.value = "";
  mine.push({text: t, at: Date.now()});
  lastSentAt = Date.now();
  if (navigator.vibrate) navigator.vibrate(12);      // 发出去了，给一下手感
  await post("/api/cmd", {text: t}); pull();
};
document.getElementById("stop").onclick = () => post("/api/stop", {});
// ---- 电脑屏幕：截图 / 录屏 ----
let shotName = "";
document.getElementById("shottoggle").onclick = () => {
  const box = document.getElementById("shots");
  box.classList.toggle("open");
  document.getElementById("shottoggle").textContent = box.classList.contains("open") ? "收起" : "展开";
  if (box.classList.contains("open")) pullShots(true);
};
document.getElementById("shotbtn").onclick = async () => {
  document.getElementById("shotmeta").textContent = "正在截…";
  await post("/api/cmd", {text: "截图发手机"}); pullShots(true);
};
document.getElementById("recbtn").onclick = async () => {
  document.getElementById("shotmeta").textContent = "正在录 8 秒…（期间电脑屏幕上会动）";
  await post("/api/cmd", {text: "录 8 秒发手机"});
};
async function pullShots(force) {
  if (!document.getElementById("shots").classList.contains("open")) return;
  try {
    const r = await fetch("/api/shots" + Q);
    const d = await r.json();
    const items = d.items || [];
    if (!items.length) return;
    const top = items[0];
    if (top.name === shotName && !force) return;
    shotName = top.name;
    const img = document.getElementById("shotimg");
    img.src = "shot/" + encodeURIComponent(top.name) + Q + "&t=" + Date.now();
    img.style.display = "block";
    img.onclick = () => window.open(img.src, "_blank");
    document.getElementById("shotmeta").textContent =
      (top.kind === "video" ? "录像 " : "截图 ") + top.name + " · " + top.kb + " KB";
    const list = document.getElementById("shotlist");
    list.innerHTML = "";
    for (const it of items.slice(1, 9)) {
      const c = document.createElement("span");
      c.className = "chip";
      c.textContent = (it.kind === "video" ? "⏺ " : "🖼 ") + it.name.slice(-11, -4);
      c.onclick = () => { img.src = "shot/" + encodeURIComponent(it.name) + Q;
                          document.getElementById("shotmeta").textContent = it.name; };
      list.appendChild(c);
    }
  } catch (e) {}
}
// ---- 文件：电脑发来的 / 跟电脑要 / 传到电脑 ----
document.getElementById("filetoggle").onclick = () => {
  const box = document.getElementById("files");
  box.classList.toggle("open");
  document.getElementById("filetoggle").textContent = box.classList.contains("open") ? "收起" : "展开";
  if (box.classList.contains("open")) pullFiles();
};
// 优先用"公网那个下载页"当更新来源（电脑上设置里填过就用它）；
// 没填就退回电脑上的 /api/version（保证断网时也能提示）。
async function updateManifest() {
  const sites = [];
  // 结尾多一个斜杠也能认（不用正则，免得 Python 那边把反斜杠当转义）
  let base = siteBase;
  while (base.endsWith("/")) base = base.slice(0, -1);
  if (base) sites.push(base + "/version.json");
  for (const u of sites) {
    try {
      const r = await fetch(u, {cache: "no-store"});
      const mf = await r.json();
      if (mf && mf.ok) return mf;
    } catch (e) { /* 换下一个来源 */ }
  }
  return null;
}
// 手机切"发到哪个对话窗口"：列电脑上现有的窗口，点一下切过去
function winRow(title, sub, current) {
  const row = document.createElement("div");
  row.style.cssText = "display:flex;gap:8px;align-items:center;padding:11px 10px;margin:6px 0;" +
    "border:1px solid var(--line);border-radius:11px;font-size:14px;cursor:pointer;" +
    (current ? "background:#2a4a3a;border-color:#3ddc84;" : "background:var(--panel);");
  const t = document.createElement("div");
  t.style.cssText = "flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap";
  t.innerHTML = "<b>" + title + "</b>" +
    (sub ? "<div style='color:var(--dim);font-size:11px;margin-top:2px'>" + sub + "</div>" : "");
  row.appendChild(t);
  if (current) {
    const c = document.createElement("span");
    c.textContent = "当前";
    c.style.cssText = "color:#3ddc84;font-size:12px;flex:0 0 auto";
    row.appendChild(c);
  }
  return row;
}
async function pullWins() {
  const box = document.getElementById("body-wins");
  box.innerHTML = "<div style='color:var(--dim);font-size:13px'>正在读电脑上的会话…</div>";
  try {
    const r = await fetch("/api/windows" + Q);
    const d = await r.json();
    box.innerHTML = "";
    const opened = String(d.current || "");     // 电脑上此刻开着的是哪个
    const chosen = String(d.chosen || "");      // 手机选的是哪个
    const autoRow = winRow("自动", "电脑上开着哪个会话，就发到哪个", chosen === "");
    autoRow.onclick = () => setWin("");
    box.appendChild(autoRow);
    (d.windows || []).forEach(w => {
      const bits = [];
      if (w.title === opened) bits.push("电脑上正开着");
      if (w.title === chosen) bits.push("手机发的话去这儿");
      const row = winRow(w.title, bits.join(" · "), w.title === chosen);
      row.onclick = () => setWin(w.title);
      box.appendChild(row);
    });
    if (!(d.windows || []).length) {
      const e = document.createElement("div");
      e.style.cssText = "color:var(--dim);font-size:12px;margin-top:10px";
      e.textContent = "没读到会话 —— 先把电脑上的 Codex 打开（侧栏里有对话才行）。";
      box.appendChild(e);
    }
    const re = document.createElement("button");
    re.className = "ghost";
    re.textContent = "刷新";
    re.style.cssText = "margin-top:12px;height:36px;font-size:13px";
    re.onclick = pullWins;
    box.appendChild(re);
  } catch (e) {
    box.innerHTML = "<div style='color:var(--dim);font-size:13px'>拉不到窗口列表：" + e + "</div>";
  }
}
async function setWin(title) {
  try {
    const r = await fetch("/api/target" + Q, {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({title: title})});
    const d = await r.json();
    if (!d.ok) { alert("没切成：" + (d.msg || "")); }
    await pullWins();
  } catch (e) {
    alert("没切成：" + e);
  }
}
async function pullFiles() {
  if (!document.getElementById("files").classList.contains("open")) return;
  try {
    const r = await fetch("/api/files" + Q);
    const d = await r.json();
    const box = document.getElementById("filelist");
    box.innerHTML = "";
    if (!(d.items || []).length) {
      box.innerHTML = '<div class="f" style="color:var(--dim)">还没有文件 —— 在电脑上说' +
                      '「把 xxx 发到手机」，或者在下面输入文件名要一个</div>';
    }
    for (const it of (d.items || [])) {
      const row = document.createElement("div");
      row.className = "f";
      const a = document.createElement("a");
      a.href = "file/" + encodeURIComponent(it.name) + Q;
      a.textContent = "📄 " + it.name;
      const s = document.createElement("span");
      s.textContent = it.kb > 1024 ? (it.kb / 1024).toFixed(1) + " MB" : it.kb + " KB";
      row.appendChild(a); row.appendChild(s);
      box.appendChild(row);
    }
    if (d.uploads && d.uploads.length) {
      document.getElementById("filemeta").textContent =
        "手机传给电脑的最近一个：" + d.uploads[0].name + "（在电脑的 手机上传\\ 里）";
    }
  } catch (e) {}
}
document.getElementById("askbtn").onclick = async () => {
  const v = document.getElementById("askfile").value.trim();
  if (!v) return;
  document.getElementById("filemeta").textContent = "跟电脑要 " + v + " …";
  await post("/api/cmd", {text: "把" + v + "发到手机"});
  setTimeout(pullFiles, 1500);
};
document.getElementById("upbtn").onclick = () => document.getElementById("upfile").click();
// ---- 手机发图片：选相册里的图（可多选）→ 传到电脑 → 直接贴进对话窗口让 AI 看图 ----
document.getElementById("tiimg").onclick = () => {
  togglePlus(false);
  document.getElementById("imgfile").click();
};
document.getElementById("imgfile").onchange = async (e) => {
  const files = Array.from(e.target.files || []);
  if (!files.length) return;
  add("me", "📷 发图片：" + files.length + " 张（正在传…）");
  let ok = 0;
  for (const f of files) {
    try {
      const r = await fetch("/api/upload?name=" + encodeURIComponent(f.name)
                            + "&paste=1&k=" + encodeURIComponent(KEY),
                            {method: "POST", body: f});
      const d = await r.json();
      if (d.ok) ok++;
    } catch (err) {}
  }
  add("sys", ok === files.length
      ? ("📷 已发到电脑并贴进对话窗口（" + ok + " 张），接着打字问它就行")
      : ("📷 传上去 " + ok + "/" + files.length + " 张"));
  e.target.value = "";
  setTimeout(pull, 1500);
};
document.getElementById("upfile").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  document.getElementById("filemeta").textContent =
    "正在传到电脑：" + f.name + "（" + (f.size / 1024).toFixed(0) + " KB）";
  try {
    const r = await fetch("/api/upload?name=" + encodeURIComponent(f.name) + "&k=" + encodeURIComponent(KEY),
                          {method: "POST", body: f});
    const d = await r.json();
    document.getElementById("filemeta").textContent = d.ok
      ? "传好了：" + f.name + "（电脑上的「手机上传」文件夹里）"
      : ("传失败：" + (d.err || ""));
  } catch (err) {
    document.getElementById("filemeta").textContent = "传失败：连不上电脑";
  }
  e.target.value = "";
  pullFiles();
};

// ---- 微信聊天框右下角那个「＋」：点一下从底下滑出功能菜单 ----
/** 手机返回键：有开着的东西就关掉，返回 1；什么都没有就返回 0（交给 APP 去退）。 */
window.onAndroidBack = () => {
  const pageOpen = document.querySelector(".page.open");
  if (pageOpen) { closePages(); return 1; }
  if (document.getElementById("sheet").classList.contains("open")) {
    document.getElementById("sheet").classList.remove("open");
    document.getElementById("sheetbg").classList.remove("on");
    return 1;
  }
  if (document.getElementById("pluspanel").classList.contains("open")) {
    togglePlus(false);
    return 1;
  }
  return 0;
};
function togglePlus(on) {
  const p = document.getElementById("pluspanel");
  const b = document.getElementById("plus");
  const open = (on === undefined) ? !p.classList.contains("open") : !!on;
  p.classList.toggle("open", open);
  b.classList.toggle("on", open);
  b.textContent = open ? "×" : "＋";
  document.getElementById("plusbg").classList.toggle("on", open);
}
function openPage(id) {
  togglePlus(false);
  document.getElementById(id).classList.add("open");
  if (id === "page-shots") pullShots(true);
  if (id === "page-files") pullFiles(true);
  if (id === "page-wins") pullWins(true);
  if (id === "page-search") setTimeout(() => document.getElementById("searchbox").focus(), 180);
}
function closePages() {
  document.querySelectorAll(".page.open").forEach(p => p.classList.remove("open"));
}
document.getElementById("plus").onclick = () => togglePlus();
document.getElementById("plusbg").onclick = () => togglePlus(false);   // 点空白处收起来
document.getElementById("sheetbg").onclick = () => {
  document.getElementById("sheet").classList.remove("open");
  document.getElementById("sheetbg").classList.remove("on");
};
document.querySelectorAll(".page [data-back]").forEach(b => { b.onclick = closePages; });
// 子页里点空白处（或者点顶上那条标题）也能关掉
document.querySelectorAll(".page").forEach(pg => {
  pg.addEventListener("click", (e) => {
    if (e.target.closest("button,a,input,.tile,.f,.listrow,img,.chip,b")) {
      return;                       // 点到能操作的东西就别关
    }
    closePages();
  });
});
document.querySelectorAll("#pluspanel .tile[data-page]").forEach(row => {
  row.onclick = () => {
    // 「对话会话」直接开左边那个抽屉（跟滑一下出来的是同一个）
    if (row.dataset.page === "wins") { togglePlus(false); openDrawer(); return; }
    openPage("page-" + row.dataset.page);
  };
});
document.getElementById("tilook").onclick = () => { togglePlus(false); openSheet(); };
document.getElementById("ticonn").onclick = () => { togglePlus(false); openSheet(true); };
document.getElementById("tiavatar").onclick = () => {
  togglePlus(false); openSheet();
  const sec = document.getElementById("avsec");
  if (sec) setTimeout(() => sec.scrollIntoView({block: "center", behavior: "smooth"}), 240);
};
// 「＋」菜单里那几个快捷指令：一点就走
document.querySelectorAll("#pluspanel .tile[data-cmd]").forEach(t => {
  t.onclick = async () => {
    const cmd = t.dataset.cmd;
    togglePlus(false);
    add("me", cmd);
    mine.push({text: cmd, at: Date.now()});
    lastSentAt = Date.now();
    if (navigator.vibrate) navigator.vibrate(12);
    await post("/api/cmd", {text: cmd});
    pull();
  };
});
// 把已经做好的两块面板（屏幕 / 文件）搬进各自的子页里
(function moveIntoPages() {
  const shots = document.getElementById("shots");
  const files = document.getElementById("files");
  if (shots) {
    const t = shots.querySelector("#shottoggle");
    if (t) t.style.display = "none";
    document.getElementById("body-shots").appendChild(shots);
    shots.classList.add("open");
    shots.style.margin = "0";
  }
  if (files) {
    const t = files.querySelector("#filetoggle");
    if (t) t.style.display = "none";
    document.getElementById("body-files").appendChild(files);
    files.classList.add("open");
    files.style.margin = "0";
  }
})();

// ---- 搜历史：让电脑把带关键词的那几行挑出来 ----
document.getElementById("searchgo").onclick = doSearch;
document.getElementById("searchbox").addEventListener("keydown", e => {
  if (e.key === "Enter") { e.preventDefault(); doSearch(); }
});
async function doSearch() {
  const kw = document.getElementById("searchbox").value.trim();
  if (!kw) return;
  const out = document.getElementById("searchout");
  out.innerHTML = "搜…";
  try {
    const r = await fetch("/api/log?since=0&q=" + encodeURIComponent(kw) + "&k=" + encodeURIComponent(KEY));
    const d = await r.json();
    out.innerHTML = "";
    const head = document.createElement("div");
    head.style.color = "var(--dim)";
    head.style.fontSize = "12px";
    head.textContent = "找到 " + (d.lines || []).length + " 条带「" + kw + "」的";
    out.appendChild(head);
    for (const it of (d.lines || [])) {
      const row = document.createElement("div");
      row.className = "row" + (it.kind === "me" ? " right" : "");
      const b = document.createElement("div");
      b.className = "bubble " + it.kind;
      b.textContent = it.text;
      row.appendChild(b);
      out.appendChild(row);
    }
  } catch (e) {
    out.textContent = "搜不了，连不上电脑";
  }
}

// 手机端的"语音说话"按钮已经去掉了（按用户要求）——录音和识别还是电脑那边的事，
// 手机上直接打字或者点 ＋ 里的快捷指令。
// 电脑识别完会把文字回来（APP 通过 evaluateJavascript 调这个）
window.onVoiceResult = (text) => {
  if (text) { add("me", text); }
  setTimeout(pull, 900);
};

// 页面里要是哪里报错了，别静悄悄地"点了没反应" —— 直接在顶上红条写出来，
// 这样你截个图发我，我一眼就知道卡在哪。
window.onerror = (msg, src, line) => {
  try {
    let bar = document.getElementById("errbar");
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "errbar";
      bar.style.cssText = "position:fixed;left:0;right:0;top:0;z-index:99;background:#7a1f1f;"
        + "color:#fff;font-size:12px;padding:6px 10px;";
      document.body.appendChild(bar);
    }
    bar.textContent = "页面出错了：" + msg + "（第 " + line + " 行）";
  } catch (e) {}
  return false;
};
box.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); document.getElementById("send").click(); }
});
applyLook();
buildSheet();
refreshAvatars();          // 头像默认用程序图标，换过的话这里会跟着换
setInterval(pull, 2000); pull();
setInterval(() => pullShots(false), 3000);
checkUpdate();

// ---- 名字（默认跟电脑上那个一样） + 版本显示 ----
async function loadInfo() {
  try {
    const r = await fetch("/api/info" + Q);
    const d = await r.json();
    const nm = look.name || d.name || "语音助手";
    document.getElementById("appname").textContent = nm;
    document.title = nm;
    const nl = document.getElementById("nameline");
    if (nl && !nl.value) nl.placeholder = d.name || "语音助手";
    const vl = document.getElementById("verline");
    if (vl) {
      const pv = vl.dataset.phone || "";
      vl.textContent = "手机端 " + (pv || "—") + " · 电脑端 " + ("v" + (d.pc || "?"));
    }
    siteBase = String(d.update_url || "").trim();     // 公网下载页网址（有就用它）
    // 外网固定地址（Tailscale）：不在同一个 Wi-Fi 时用这条
    remoteUrl = String(d.fixed_url || "").trim();
    tsApk = String(d.tailscale_apk || "").trim();
    const fu = document.getElementById("fixedurl");
    if (fu) {
      fu.textContent = remoteUrl || (d.remote_hint || "外网访问不可用");
      fu.style.color = remoteUrl ? "var(--fg)" : "var(--dim)";
    }
    const tst = document.getElementById("tstip");
    if (tst && d.remote_tip) tst.textContent = d.remote_tip;
    // 公网地址开着的时候，手机什么都不用装 —— 那两个「装 / 开 Tailscale」「后台自动连」
    // 就是多余的了，藏起来，免得让人以为还得开 VPN（用户明确问过这个）。
    if (d.funnel_on) {
      const lab = document.getElementById("remotelab");
      if (lab) lab.textContent = "外网访问（公网地址 · 手机什么都不用装）";
      ["tssetup", "tsalways"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = "none";
      });
      if (tst) tst.textContent = "手机不用装任何东西：把上面这条地址发到手机上打开就行；" +
        "用 APP 的话点「用这条地址连」，或者扫电脑上的二维码。家里同一个 Wi-Fi 时，" +
        "用局域网那条（设置里的「手机网址」）最快。";
    }
    // 记住它：APP 里万一局域网连不上，能拿这条外网地址兜底
    try { if (remoteUrl) localStorage.setItem("remote", remoteUrl); } catch (e) {}
    try {
      if (remoteUrl && window.VoiceApp && VoiceApp.rememberRemote) VoiceApp.rememberRemote(remoteUrl);
      if (tsApk && window.VoiceApp && VoiceApp.rememberApk) VoiceApp.rememberApk(tsApk);
    } catch (e) {}
    // 署名 / 版权（跟电脑端「关于」一个来源：都读电脑上那个 version.py，改一处两边都变）
    const set = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text || "";
    };
    set("aboutauthor", d.author ? ("作者：" + d.author) : "作者：—");
    set("aboutcontact", d.contact ? ("邮箱：" + d.contact) : "邮箱：—");
    set("aboutcopy", d.copyright || "");
    set("aboutfree", d.free || "");
    set("aboutnotice", d.notice || "");
  } catch (e) {}
}
// ---- 外网那一栏：复制 / 装-开 Tailscale / 用这条地址连 ----
// （以前这三样被误塞进了下面 nameline.onchange 里面，结果"点了没反应" —— 搬出来。）
function wireRemote() {
  const fc = document.getElementById("fixedcopy");
  if (fc) {
    fc.onclick = () => {
      if (!remoteUrl) {
        alert("电脑那边外网访问还没开。请在电脑上打开 设置 → 智能 → 外网访问 → 一键开启");
        return;
      }
      if (navigator.clipboard) {
        navigator.clipboard.writeText(remoteUrl).then(
          () => { fc.textContent = "已复制"; setTimeout(() => fc.textContent = "复制", 1500); },
          () => alert("复制不了，手动抄一下吧：" + remoteUrl));
      } else {
        alert(remoteUrl);
      }
    };
  }
  const setup = document.getElementById("tssetup");
  if (setup) {
    setup.onclick = () => {
      if (window.VoiceApp && VoiceApp.tailscale) {
        VoiceApp.tailscale(tsApk);      // APP 里：帮它下 APK，装好直接打开
      } else if (tsApk) {
        location.href = tsApk;          // 浏览器里：下载官方 APK
      } else {
        alert("电脑上还没填下载站网址，没法自动下 APK。可以自己在应用商店搜 Tailscale");
      }
    };
  }
  const use = document.getElementById("fixeduse");
  if (use) {
    use.onclick = () => {
      if (!remoteUrl) { alert("还没有外网地址：先在电脑上点「一键开启」"); return; }
      if (window.VoiceApp && VoiceApp.useUrl) VoiceApp.useUrl(remoteUrl);
      else location.href = remoteUrl;
    };
  }
  // 「后台自动连」：去安卓的 VPN 设置，把 Tailscale 设成"始终开启" —— 设一次，
  // 以后只要开语音助手这一个 APP，在家走局域网、在外走 Tailscale，全自动。
  const always = document.getElementById("tsalways");
  if (always) {
    always.onclick = () => {
      if (window.VoiceApp && VoiceApp.alwaysOn) {
        VoiceApp.alwaysOn();
      } else {
        alert("这一步要在 APP 里做：打开语音助手 APP → 设置 → 外网访问 → 「后台自动连」。"
              + "（浏览器里没法改手机的 VPN 设置）");
      }
    };
  }
}
wireRemote();
document.getElementById("nameline").onchange = (e) => {
  look.name = e.target.value.trim();
  try { localStorage.setItem("look", JSON.stringify(look)); } catch (err) {}
  const nm = look.name || "语音助手";
  document.getElementById("appname").textContent = nm;
  document.title = nm;
};
loadInfo();
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js?k=__TOKEN__").catch(() => {});
}
// ---- 左边那个会话抽屉：滑一下出来挑会话（像推特那样） ----
const drawer = document.getElementById("convdrawer");
const convbg = document.getElementById("convbg");
let drawerOpen = false;
let drawerTimer = null;              // 抽屉开着的时候自动刷新用

function drawerRender(d, note) {
  const box = document.getElementById("convlist");
  const opened = String(d.current || "");
  const chosen = String(d.chosen || "");
  document.getElementById("convwho").textContent =
    chosen ? ("手机发的话去：" + chosen) : "跟着电脑走（自动）";
  box.innerHTML = "";
  const rows = [{ title: "自动（电脑上开着哪个就发哪个）", auto: true }]
    .concat(d.windows || []);
  rows.forEach(w => {
    const row = document.createElement("div");
    row.className = "drow" + ((w.auto && !chosen) || (!w.auto && w.title === chosen)
                              ? " now" : "");
    const nm = document.createElement("div");
    nm.className = "nm";
    nm.textContent = w.auto ? w.title : w.title;
    row.appendChild(nm);
    const tag = document.createElement("span");
    tag.className = "tag";
    const bits = [];
    if (w.auto && !chosen) bits.push("已选");
    if (!w.auto && w.title === opened) bits.push("电脑上正开着");
    if (!w.auto && w.title === chosen) bits.push("已选");
    tag.textContent = bits.join(" · ");
    row.appendChild(tag);
    row.onclick = () => { setConv(w.auto ? "" : w.title); };
    box.appendChild(row);
  });
  if (!(d.windows || []).length) {
    const e = document.createElement("div");
    e.style.cssText = "color:var(--dim);font-size:12px;margin-top:8px";
    e.textContent = "没读到会话 —— 电脑上把 Codex 打开（侧栏里有对话才行）。";
    box.appendChild(e);
  }
  // 刷新按钮：点了要有明确回执（"刚更新 07:20:31 · 4 个会话"），
  // 不然列表内容一样，看着就像按钮没反应（用户反馈"刷新按钮没有用"）。
  const bar = document.createElement("div");
  bar.style.cssText = "display:flex;align-items:center;gap:8px;margin-top:12px";
  const re = document.createElement("button");
  re.textContent = "刷新";
  re.style.cssText = "flex:0 0 auto;height:38px;padding:0 18px;border:0;border-radius:11px;" +
                     "background:#2a2a34;color:#f2f2f2;font-size:14px";
  re.onclick = () => pullConvs(true);
  const tip = document.createElement("span");
  tip.style.cssText = "color:var(--dim);font-size:12px";
  tip.textContent = note || "";
  bar.appendChild(re);
  bar.appendChild(tip);
  box.appendChild(bar);
}

let convBusy = false;
async function pullConvs(manual) {
  if (convBusy) return;                 // 上一轮还没回来就别叠着发
  convBusy = true;
  const box = document.getElementById("convlist");
  if (box) box.innerHTML = "<div style='color:var(--dim);font-size:13px'>正在读电脑上的会话…</div>";
  try {
    const r = await fetch("/api/windows" + Q + (manual ? "&t=" + Date.now() : ""));
    const d = await r.json();
    const now = new Date().toLocaleTimeString("zh-CN",
      {hour: "2-digit", minute: "2-digit", second: "2-digit"});
    drawerRender(d, "刚更新 " + now + " · " + ((d.windows || []).length) + " 个会话");
  } catch (e) {
    if (box) {
      box.innerHTML = "<div style='color:#ff9a9a;font-size:13px'>拉不到会话：" + e +
        "<br><span style='color:var(--dim)'>（电脑上的助手还开着吗？）</span></div>";
    }
  } finally {
    convBusy = false;
  }
}

async function setConv(title) {
  try {
    const r = await fetch("/api/target" + Q, {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({title: title})});
    const d = await r.json();
    if (!d.ok) { alert("没切成：" + (d.msg || "")); }
    closeDrawer();
    add("done", d.ok ? ("已经切到：" + (title || "自动")) : ("切换失败：" + (d.msg || "")));
  } catch (e) {
    alert("没切成：" + e);
  }
}

function openDrawer() {
  drawerOpen = true;
  drawer.style.transition = "";
  drawer.style.transform = "";
  drawer.classList.add("open");
  convbg.classList.add("on");
  pullConvs();
  // 开着的时候就别让列表过时：每 8 秒自己刷一次（你在电脑上切了会话，手机上也就跟着变）
  if (drawerTimer) clearInterval(drawerTimer);
  drawerTimer = setInterval(() => { if (drawerOpen) pullConvs(); }, 8000);
}

function closeDrawer() {
  drawerOpen = false;
  if (drawerTimer) { clearInterval(drawerTimer); drawerTimer = null; }
  drawer.style.transition = "";
  drawer.style.transform = "";
  drawer.classList.remove("open");
  convbg.classList.remove("on");
}

convbg.onclick = closeDrawer;
document.getElementById("convclose").onclick = closeDrawer;

// 手势：聊天区往左滑一下 → 抽屉出来（用户要的）；
// 从左边缘往右拖 → 抽屉跟手出来（推特那种）。
let _tx = 0, _ty = 0, _tt = 0, _drag = false, _touched = false;

function gestureStart(e) {
  const t = e.touches[0];
  if (!t) return;
  _tx = t.clientX; _ty = t.clientY; _tt = Date.now();
  _drag = false;
  _touched = true;
}

function gestureMove(e) {
  if (!_touched) return;
  const t = e.touches[0];
  if (!t) return;
  const dx = t.clientX - _tx, dy = t.clientY - _ty;
  if (Math.abs(dx) < Math.abs(dy)) return;        // 竖着划就给页面滚动
  if (!drawerOpen && _tx < 40 && dx > 0) {        // 从左边缘往右拖
    _drag = true;
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = Math.min(1, dx / w);
    drawer.style.transition = "none";
    drawer.style.transform = "translateX(" + (-102 + 102 * pct) + "%)";
    if (pct > 0.12) convbg.classList.add("on");
  } else if (drawerOpen && dx < 0) {              // 打开着往回拖
    _drag = true;
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = Math.max(0, 1 + dx / w);
    drawer.style.transition = "none";
    drawer.style.transform = "translateX(" + (-102 + 102 * pct) + "%)";
  }
}

function gestureEnd(e) {
  if (!_touched) return;
  _touched = false;
  const t = (e.changedTouches && e.changedTouches[0]) || null;
  const dx = t ? t.clientX - _tx : 0;
  const dy = t ? t.clientY - _ty : 0;
  const dt = Date.now() - _tt;
  if (_drag) {                                    // 拖拽收尾
    const w = Math.min(380, window.innerWidth * 0.84);
    const pct = drawerOpen ? 1 + dx / w : dx / w;
    drawer.style.transition = "";
    drawer.style.transform = "";
    if (pct > 0.35) { openDrawer(); } else { closeDrawer(); }
    return;
  }
  // 快速横滑：往左滑一下也把抽屉叫出来（用户要的手势）；往右滑则关掉
  if (dt < 500 && Math.abs(dx) > 60 && Math.abs(dy) < 45) {
    if (dx < 0 && !drawerOpen) { openDrawer(); }
    else if (dx > 0 && drawerOpen) { closeDrawer(); }
  }
}

const gesArea = document.getElementById("log");
if (gesArea) {
  gesArea.addEventListener("touchstart", gestureStart, {passive: true});
  gesArea.addEventListener("touchmove", gestureMove, {passive: true});
  gesArea.addEventListener("touchend", gestureEnd, {passive: true});
  gesArea.addEventListener("touchcancel", gestureEnd, {passive: true});
}

</script>
</body></html>

"""


class PhoneLink:
    """那个小 HTTP 门。回调都是外面（stt.py）传进来的。"""

    def __init__(self, on_command, get_state, get_log, on_stop=None,
                 port: int = DEFAULT_PORT, log=print, pairing: bool = True,
                 token: str | None = None) -> None:
        self.on_command = on_command
        self.get_state = get_state
        self.get_log = get_log
        self.on_stop = on_stop
        self.on_voice = None                 # 手机录的一段语音 → 交给主程序识别
        self.on_image = None                 # 手机发来的图片 → 交给主程序贴进对话窗口
        self.get_info = None                 # 电脑上这个助手叫什么、什么版本
        self.get_windows = None              # 电脑上现在有哪些聊天窗口（手机上来挑）
        self.get_target = None               # 手机上次挑的是哪个窗口
        self.on_target = None                # 手机切窗口 → 交给主程序
        self.port = int(port)
        self.log = log
        # pairing=False 只给自动化测试用（免掉"新设备要在电脑上点允许"这一道）
        self.pairing = bool(pairing)
        # token 也是给测试指定用的；不传就跟着 phone-token.txt 走（换令牌不用重启）
        self.token_forced = token is not None
        self.token = token or load_token()
        self._httpd: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._icons: dict[int, bytes] = {}
        self._seen_clients: dict[str, float] = {}   # 见过的手机/浏览器，用来报"连上了"
        self.on_client = None                       # 外面可以挂一个"有设备连上"的回调

    def _hello(self, ip: str) -> None:
        """第一次见到这个设备就说一声（电脑上立刻能看出手机连上没有）。"""
        now = time.time()
        last = self._seen_clients.get(ip, 0.0)
        self._seen_clients[ip] = now
        if now - last < 60:                          # 同一台设备一分钟内只报一次
            return
        self.log(f"📱 有设备连上了：{ip}")
        if self.on_client:
            try:
                self.on_client(ip)
            except Exception:
                pass

    # ---------------------------------------------------------------- 图标/清单
    def icon_png(self, size: int) -> bytes:
        """把程序自己的 voice.ico 缩成手机图标（有缓存，只生成一次）。"""
        size = 192 if size not in (192, 512) else size
        if size in self._icons:
            return self._icons[size]
        try:
            import io

            from PIL import Image

            ico = HERE / "voice.ico"
            if ico.exists():
                im = Image.open(ico).convert("RGBA")
            else:
                im = Image.new("RGBA", (size, size), (61, 220, 132, 255))
            im = im.resize((size, size), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, "PNG")
            data = buf.getvalue()
        except Exception:
            data = b""
        self._icons[size] = data
        return data

    def manifest(self) -> bytes:
        """PWA 清单：安卓 Chrome 靠它把网页"安装"成应用（图标、全屏、名字）。"""
        data = {
            "name": "语音助手",
            "short_name": "语音助手",
            "start_url": f"/?k={self.token}",
            "scope": "/",
            "display": "standalone",
            "background_color": "#1b1b1f",
            "theme_color": "#1b1b1f",
            "icons": [
                {"src": f"icon-192.png?k={self.token}", "sizes": "192x192", "type": "image/png"},
                {"src": f"icon-512.png?k={self.token}", "sizes": "512x512", "type": "image/png"},
            ],
        }
        return json.dumps(data, ensure_ascii=False).encode("utf-8")

    # ---------------------------------------------------------------- 启停
    def start(self) -> bool:
        outer = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "VoiceAssistantPhone/1.0"

            def log_message(self, *_a) -> None:      # 别往控制台刷日志
                pass

            # ---- 小工具 ----
            def _auth(self, q: dict) -> bool:
                got = (q.get("k") or [""])[0] or self.headers.get("X-Token") or ""
                want = outer.token if getattr(outer, "token_forced", False) else current_token()
                return bool(got) and secrets.compare_digest(str(got), str(want))

            def _who(self) -> tuple[str, bool]:
                """这个请求是谁发的；第二个值表示"是不是从公网转发进来的"。

                Funnel 转发进来的时候，连接其实是本机 127.0.0.1 发起的，
                真实来源在 X-Forwarded-For 里（Tailscale 会填上）。所以本机来的
                就看那个头，取最后一段（那是代理亲手加的，前面的可能是伪造的）。
                """
                peer = self.client_address[0] if self.client_address else "?"
                if peer in ("127.0.0.1", "::1"):
                    fwd = [x.strip() for x in
                           (self.headers.get("X-Forwarded-For") or "").split(",") if x.strip()]
                    if fwd:
                        return fwd[-1], True
                return peer, False

            def _gate(self, q: dict) -> bool:
                """三道门，过了才返回 True；没过会自己把响应写掉。

                ① 限速：**只管**从公网转发进来的那批（连接的来源是本机、真实来源在
                   X-Forwarded-For 里）—— 扫描机器人就是从那儿来的。自己手机走
                   Tailscale / 局域网直连的，令牌本来就不会错；万一哪天错了，也不能把
                   人锁在自己家门外（这坑真踩过：手机页面在轮询，令牌一换，几十次 401
                   就把手机自己封了 30 分钟）。
                ② 令牌：对不对。
                ③ 设备：这台设备你点头了吗（见上面的"新设备要配对"）。
                """
                who, public = self._who()
                if public:
                    left = guard_blocked(who)
                    if left > 0:
                        self._json({"ok": False, "err": "blocked",
                                    "retry_after": int(left)}, 429)
                        return False
                if not self._auth(q):
                    if public:
                        guard_note(who, False)
                    self._json({"ok": False, "err": "token"}, 401)
                    return False
                guard_note(who, True)
                return self._gate_device(who)

            def _cookie_dev(self) -> tuple[str, bool]:
                """这台设备是谁；第二个值表示"这次是刚发的新 cookie"。

                有 cookie 就按 cookie 认；没有（APP 里那个后台轮询就不带 cookie）
                就按 UA + 来源认脸 —— 认到老面孔就复用它的记录，**不能每次当新设备**，
                不然一会儿就攒一堆"待确认"、还一直弹窗（真踩过）。
                """
                raw = self.headers.get("Cookie") or ""
                for part in raw.split(";"):
                    k, _, v = part.strip().partition("=")
                    if k == DEV_COOKIE and v.strip():
                        return v.strip(), False
                ua = self.headers.get("User-Agent") or ""
                ip = self._who()[0]
                got = _dev_find(ua, ip)
                if got:
                    return got, False
                return _dev_id_new(), True

            def _gate_device(self, who: str) -> bool:
                """设备这道门：没确认过的设备只给它"等电脑上点允许"那一页。"""
                if not getattr(outer, "pairing", True):
                    return True                     # 自动化测试专用
                dev_id, fresh = self._cookie_dev()
                if fresh:
                    self._extra_headers = [
                        ("Set-Cookie",
                         "%s=%s; Path=/; Max-Age=31536000; SameSite=Lax; HttpOnly"
                         % (DEV_COOKIE, dev_id))]
                if device_trusted(dev_id):
                    return True
                rec = _dev_touch(dev_id, self.headers.get("User-Agent") or "", who,
                                 _dev_fp(self.headers.get("User-Agent") or "", who))
                code = str(rec.get("code") or "")
                if self.path.startswith("/api/"):
                    self._send(json.dumps({"ok": False, "err": "pairing", "code": code},
                                          ensure_ascii=False).encode("utf-8"),
                               "application/json; charset=utf-8", 403)
                    return False
                self._pending_page(code)
                return False

            def _pending_page(self, code: str) -> None:
                """还没确认的设备看到的就是这一页（每 5 秒自己看一眼好了没有）。"""
                html = (
                    "<!doctype html><meta charset=utf-8>"
                    "<meta name=viewport content='width=device-width,initial-scale=1'>"
                    "<meta http-equiv=refresh content=5>"
                    "<style>body{margin:0;background:#1b1b1f;color:#f2f2f5;padding:26px;"
                    "font-family:-apple-system,'Microsoft YaHei UI',sans-serif;text-align:center}"
                    "h3{font-size:18px;margin:22px 0 6px}"
                    ".c{font-size:46px;letter-spacing:10px;font-weight:700;color:#3ddc84;"
                    "margin:16px 0 10px}"
                    ".m{color:#9a9aa5;font-size:13.5px;line-height:1.85}</style>"
                    "<h3>等你在电脑上点一下「允许」</h3>"
                    "<div class=c>%s</div>"
                    "<div class=m>电脑上会弹出「有台新设备想连进来」，把这个号码对一下再点允许。<br>"
                    "点过之后这台设备就不用再确认了。<br>这页每 5 秒自己看一眼。</div>"
                    % code)
                self._send(html.encode("utf-8"), "text/html; charset=utf-8", 200)

            def _json(self, obj: dict, code: int = 200) -> None:
                self._send(json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                           "application/json; charset=utf-8", code)

            def _html(self, page: str) -> None:
                self._send(page.encode("utf-8"), "text/html; charset=utf-8", 200)

            def _send(self, body: bytes, ctype: str, code: int = 200) -> None:
                """发一段文本；能压就压。

                手机在外面那条路带宽很窄（实测 1~3 Mbps）：这一页原始 76KB，
                gzip 之后只有 22KB —— 手机上少等一大截。
                """
                enc = ""
                try:
                    want = "gzip" in (self.headers.get("Accept-Encoding") or "").lower()
                    if want and len(body) > 600:
                        import gzip
                        body = gzip.compress(body, 6)
                        enc = "gzip"
                except Exception:                                # noqa: BLE001
                    enc = ""
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                extra = getattr(self, "_extra_headers", None)
                if extra:                       # 给新设备发 cookie 那一手
                    for _k, _v in extra:
                        self.send_header(_k, _v)
                    self._extra_headers = []
                if enc:
                    self.send_header("Content-Encoding", enc)
                    self.send_header("Vary", "Accept-Encoding")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            # ---- 路由 ----
            def do_GET(self) -> None:                # noqa: N802
                u = urlparse(self.path)
                q = parse_qs(u.query)
                # ---- 下载页：故意不要令牌 ----
                # 这一页是给"别人"看的（发给朋友、同一个 Wi-Fi 里想装的同事），
                # 上面只有两个安装包和更新信息，没有对话内容、也没有控制入口。
                # （这里以前挂着一整套"局域网下载页"：/dl 页面、/dl/app.apk、/dl/pc.zip、
                #   二维码、更新清单、下载量统计）。用户要求"只留 GitHub 网址这一种下载方式"，
                #   所以整套都拆掉了 —— 下载和更新都走那个公网网址。
                if not self._gate(q):
                    return
                outer._hello(self.client_address[0] if self.client_address else "?")
                if u.path in ("/", "/index.html"):
                    self._html(current_page().replace("__TOKEN__", outer.token))
                    return
                if u.path == "/manifest.webmanifest":
                    body = outer.manifest()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/manifest+json; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if u.path in ("/icon-192.png", "/icon.png", "/icon-512.png"):
                    size = 512 if "512" in u.path else 192
                    body = outer.icon_png(size)
                    if not body:
                        self._json({"ok": False, "err": "no icon"}, 404)
                        return
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Cache-Control", "max-age=86400")
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if u.path == "/sw.js":
                    body = (
                        # 极简 service worker：安卓 Chrome 要求有它才允许"安装到主屏幕"
                        "self.addEventListener('install', e => self.skipWaiting());\n"
                        "self.addEventListener('activate', e => self.clients.claim());\n"
                        "self.addEventListener('fetch', e => {});\n"
                    ).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "application/javascript; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if u.path in ("/app.apk", "/语音助手-手机端.apk"):
                    # 手机扫完码直接在页面上点一下就能下载安装（不用微信、不用数据线）
                    apk = APK_FILE
                    if not apk.exists():
                        self._json({"ok": False, "err": "这台电脑上还没有手机端安装包"}, 404)
                        return
                    data = apk.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/vnd.android.package-archive")
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Content-Disposition",
                                     'attachment; filename="voice-assistant.apk"')
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if u.path == "/api/log":
                    try:
                        since = int((q.get("since") or ["0"])[0])
                    except Exception:
                        since = 0
                    st = outer.get_state() or {}
                    kw = (q.get("q") or [""])[0].strip()
                    try:
                        lines = outer.get_log(since, kw) or []
                    except TypeError:
                        lines = outer.get_log(since) or []      # 老的回调只有一个参数
                    self._json({"ok": True, "online": True,
                                "state": st.get("state_text", ""), "lines": lines})
                    return
                if u.path == "/api/version":
                    # 手机上的 APP 拿 phone 跟自己的版本比：**只有手机端自己升级了**才提示更新；
                    # pc 只是给它看个热闹（知道电脑端现在是哪个版本）。
                    self._json({"ok": True, "pc": pc_version(), "phone": phone_app_version(),
                                "apk": APK_FILE.name,
                                "apk_kb": round(APK_FILE.stat().st_size / 1024, 1)
                                if APK_FILE.exists() else 0})
                    return
                if u.path == "/api/info":
                    info = {}
                    if outer.get_info:
                        try:
                            info = outer.get_info() or {}
                        except Exception:
                            info = {}
                    info["ok"] = True
                    self._json(info)
                    return
                if u.path == "/api/windows":
                    # 手机上要的是"我和你的会话"（Codex 里的那些对话），实时读出来
                    items: list = []
                    if outer.get_windows:
                        try:
                            items = list(outer.get_windows() or [])
                        except Exception:
                            items = []
                    windows = []
                    opened = ""
                    for it in items:
                        if isinstance(it, dict):
                            name = str(it.get("title") or it.get("name") or "")
                            is_cur = bool(it.get("current"))
                        else:
                            name, is_cur = str(it), False
                        if not name:
                            continue
                        if is_cur:
                            opened = name
                        windows.append({"title": name, "current": is_cur})
                    cur = ""
                    if outer.get_target:
                        try:
                            cur = str(outer.get_target() or "")
                        except Exception:
                            cur = ""
                    self._json({"ok": True, "current": opened, "chosen": cur,
                                "windows": windows})
                    return
                if u.path == "/api/shots":
                    try:
                        import screen_share

                        items = screen_share.list_shots()
                    except Exception:
                        items = []
                    self._json({"ok": True, "items": items})
                    return
                if u.path.startswith("/shot/"):
                    name = u.path[len("/shot/"):]
                    try:
                        import urllib.parse

                        import screen_share

                        p = screen_share.shot_path(urllib.parse.unquote(name))
                    except Exception:
                        p = None
                    if p is None:
                        self._json({"ok": False, "err": "no such shot"}, 404)
                        return
                    data = p.read_bytes()
                    ctype = {".png": "image/png", ".webp": "image/webp",
                             ".gif": "image/gif"}.get(p.suffix.lower(), "application/octet-stream")
                    self.send_response(200)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if u.path == "/api/files":
                    try:
                        import file_share

                        items = file_share.list_files()
                        ups = file_share.list_uploads(5)
                    except Exception:
                        items, ups = [], []
                    self._json({"ok": True, "items": items, "uploads": ups})
                    return
                if u.path.startswith("/file/"):
                    try:
                        import urllib.parse

                        import file_share

                        p = file_share.file_path(urllib.parse.unquote(u.path[len("/file/"):]))
                    except Exception:
                        p = None
                    if p is None:
                        self._json({"ok": False, "err": "no such file"}, 404)
                        return
                    data = p.read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Length", str(len(data)))
                    # 手机上点了就是下载，文件名保持原样
                    quoted = urllib.parse.quote(p.name)
                    self.send_header("Content-Disposition",
                                     f"attachment; filename*=UTF-8''{quoted}")
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self._json({"ok": False, "err": "not found"}, 404)

            def do_POST(self) -> None:               # noqa: N802
                u = urlparse(self.path)
                q = parse_qs(u.query)
                if not self._gate(q):
                    return
                outer._hello(self.client_address[0] if self.client_address else "?")
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except Exception:
                    n = 0
                # 先把 body **原样**读出来：上传文件时它是二进制，不能被 JSON 解析吃掉
                # （以前这里先 json.loads，body 就被消费了，再读就卡住 → 一直等到超时）
                raw = self.rfile.read(n) if 0 < n <= 200 * 1024 * 1024 else b""
                try:
                    data = json.loads(raw or b"{}")
                except Exception:
                    data = {}
                if u.path == "/api/cmd":
                    text = str(data.get("text") or "").strip()
                    if not text:
                        self._json({"ok": False, "err": "empty"}, 400)
                        return
                    try:
                        outer.on_command(text)
                    except Exception as exc:          # noqa: BLE001
                        self._json({"ok": False, "err": str(exc)[:80]}, 500)
                        return
                    self._json({"ok": True})
                    return
                if u.path == "/api/stop":
                    try:
                        if outer.on_stop:
                            outer.on_stop()
                    except Exception:
                        pass
                    self._json({"ok": True})
                    return
                if u.path == "/api/target":
                    # 手机切"这句话发到哪个对话窗口"：{"title": "..."}，空 = 自动
                    title = str(data.get("title") or "")
                    ok, msg = True, "自动"
                    if outer.on_target:
                        try:
                            ok, msg = outer.on_target(title)
                        except Exception as exc:      # noqa: BLE001
                            ok, msg = False, str(exc)[:80]
                    else:
                        ok, msg = False, "电脑那边没准备好"
                    cur = msg if ok else ""
                    if outer.get_target and ok:
                        try:
                            cur = str(outer.get_target() or "") or msg
                        except Exception:
                            cur = msg
                    self._json({"ok": bool(ok), "msg": msg, "current": cur})
                    return
                if u.path == "/api/upload":
                    # 手机传上来的文件：原始字节直接当 body，名字走 ?name=
                    if not raw or len(raw) > 200 * 1024 * 1024:
                        self._json({"ok": False, "err": "大小不对"}, 400)
                        return
                    try:
                        import urllib.parse

                        import file_share

                        name = (q.get("name") or [f"手机文件-{int(time.time())}.bin"])[0]
                        p = file_share.save_upload(urllib.parse.unquote(name), raw)
                    except Exception:
                        p = None
                    if p is None:
                        self._json({"ok": False, "err": "存不下"}, 500)
                        return
                    if (q.get("paste") or ["0"])[0] in ("1", "true", "yes"):
                        # 手机发来的图片：顺手交给主程序贴进聊天窗口，让 AI 直接看图
                        try:
                            if outer.on_image:
                                outer.on_image(p)
                        except Exception:
                            pass
                    self._json({"ok": True, "name": p.name, "kb": round(len(raw) / 1024, 1)})
                    return
                if u.path == "/api/voice":
                    # 手机录好的一段 wav：让主程序用本机模型识别成文字，再当命令办掉
                    if not raw or len(raw) > 40 * 1024 * 1024:
                        self._json({"ok": False, "err": "录音大小不对"}, 400)
                        return
                    if not outer.on_voice:
                        self._json({"ok": False, "err": "这台电脑上的语音助手没接这个口"}, 503)
                        return
                    try:
                        text = outer.on_voice(raw) or ""
                    except Exception as exc:      # noqa: BLE001
                        self._json({"ok": False, "err": str(exc)[:120]}, 500)
                        return
                    self._json({"ok": True, "text": text})
                    return
                self._json({"ok": False, "err": "not found"}, 404)

        for attempt in range(2):
            try:
                self._httpd = ThreadingHTTPServer(("0.0.0.0", self.port), Handler)
                break
            except OSError as exc:
                if attempt == 0 and self.port != 0:
                    self.log(f"   （手机入口：{self.port} 端口被占，换一个试试）")
                    self.port += 1
                    continue
                self.log(f"   （手机入口没起来：{exc}）")
                return False
        self._httpd.daemon_threads = True
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        try:
            if self._httpd is not None:
                self._httpd.shutdown()
                self._httpd.server_close()
        except Exception:
            pass
        self._httpd = None

    def url(self) -> str:
        return f"http://{lan_ip()}:{self.port}/?k={self.token}"

    def alive(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

