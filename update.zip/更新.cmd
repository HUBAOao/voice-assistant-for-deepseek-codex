@echo off
rem ASCII ONLY content: cmd.exe parses .cmd files in the ANSI code page, so UTF-8
rem Chinese here would break the batch. All Chinese text comes from apply_update.py.
rem
rem 用法：双击 = 自己找程序装在哪然后更新；
rem       把程序文件夹拖到这个文件上 = 更新那个文件夹。
setlocal EnableExtensions
title Voice Assistant Updater
chcp 65001 >nul
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

echo.
echo    Voice Assistant - Update package
echo    ------------------------------------------------
echo.

set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo   [!] No Python found. This update package only replaces program files,
  echo       so it needs the Python that the original installer set up.
  echo       Please run 1-Install... (or setup.cmd) first.
  echo.
  pause
  exit /b 1
)

if not "%~1"=="" (
  %PYEXE% "%APP%\apply_update.py" --dir "%~1"
) else (
  %PYEXE% "%APP%\apply_update.py" %*
)
echo.
pause
