#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手统一入口：点桌面快捷方式会弹出它，选一种方式启动。

  · 对话模式   —— 说唤醒词，说完自动发送给 AI
  · 转录模式   —— 按住 * 说话，松开识别成文字
  · 只开悬浮窗 —— 不启动识别，只把浮窗叫出来

如果语音程序已经在后台跑，这里就只把悬浮窗提到前面，不会再开一个。
"""

from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONFIG = HERE / "config.json"
STATUS = HERE / "status.json"
VOICE_MUTEX = "VoiceAssistantVoice_v1"

MODES = [
    ("talk", "对话模式", "说唤醒词，说完自动发送给 AI"),
    ("hold", "转录模式", "按住 * 说话，松开识别成文字"),
    ("overlay", "只开悬浮窗", "不启动识别，只把浮窗叫出来"),
]
DEFAULT_MODE = "talk"

BG = "#1b1b1f"
CARD = "#26262d"
CARD_HOVER = "#32323b"
CARD_SEL = "#2a4a3a"
FG = "#f2f2f5"
DIM = "#9a9aa5"
ACCENT = "#3ddc84"


def no_console_io() -> None:
    """pythonw 下没有控制台，print 会报错，先兜住。"""
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            try:
                setattr(sys, name, open(HERE / "voice.log", "a", encoding="utf-8", buffering=1))
            except Exception:
                setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))


def pythonw() -> Path:
    candidate = Path(sys.executable).with_name("pythonw.exe")
    return candidate if candidate.exists() else Path(sys.executable)


def load_mode() -> str:
    try:
        mode = str(json.loads(CONFIG.read_text(encoding="utf-8")).get("last_mode") or "")
    except Exception:
        mode = ""
    return mode if mode in {m for m, _, _ in MODES} else DEFAULT_MODE


def save_mode(mode: str) -> None:
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8")) if CONFIG.exists() else {}
        if not isinstance(data, dict):
            data = {}
        data["last_mode"] = mode
        CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def named_mutex_exists(name: str) -> bool:
    SYNCHRONIZE = 0x00100000
    k = ctypes.windll.kernel32
    handle = k.OpenMutexW(SYNCHRONIZE, False, name)
    if handle:
        k.CloseHandle(handle)
        return True
    return False


def program_running() -> bool:
    if named_mutex_exists(VOICE_MUTEX):
        return True
    try:
        pid = int(json.loads(STATUS.read_text(encoding="utf-8")).get("pid") or 0)
    except Exception:
        return False
    if not pid:
        return False
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    h = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if h:
        ctypes.windll.kernel32.CloseHandle(h)
        return True
    return False


def start(mode: str) -> None:
    """启动语音程序；已经在跑就只把浮窗叫出来。"""
    if program_running():
        subprocess.Popen([str(pythonw()), str(HERE / "show_overlay.py")], cwd=str(HERE))
        return
    if mode == "overlay":
        subprocess.Popen([str(pythonw()), str(HERE / "show_overlay.py")], cwd=str(HERE))
        return
    subprocess.Popen([str(pythonw()), str(HERE / "stt.py"), "--mode", mode], cwd=str(HERE))
    time.sleep(0.4)


class Chooser:
    def __init__(self) -> None:
        import tkinter as tk

        self.tk = tk
        self.mode = load_mode()
        self.running = program_running()

        self.root = tk.Tk()
        self.root.title("语音助手 · 选择模式")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)
        self.root.attributes("-topmost", True)
        w, h = 372, 342
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        self.root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 3}")

        head = tk.Label(self.root, text="语音助手", bg=BG, fg=FG,
                        font=("Microsoft YaHei UI", 13, "bold"))
        head.pack(anchor="w", padx=18, pady=(16, 2))
        state = "已在后台运行 · 选一个就切过去" if self.running else "选一种方式启动"
        tk.Label(self.root, text=state, bg=BG, fg=DIM,
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(0, 2))
        # 署名 / 版权只在设置里的「关于」按钮里显示，这里不放
        tk.Label(self.root, text="", bg=BG, font=("Microsoft YaHei UI", 8)).pack(pady=(0, 6))

        self.cards = {}
        for value, name, desc in MODES:
            card = tk.Frame(self.root, bg=CARD, highlightthickness=1,
                            highlightbackground="#33333c")
            card.pack(fill="x", padx=16, pady=3)
            dot = tk.Canvas(card, width=16, height=16, bg=CARD, highlightthickness=0)
            dot.pack(side="left", padx=(10, 8), pady=9)
            ring = dot.create_oval(3, 3, 13, 13, outline=DIM, width=1)
            inner = dot.create_oval(6, 6, 10, 10, outline="", fill=CARD)
            title = tk.Label(card, text=name, bg=CARD, fg=FG,
                             font=("Microsoft YaHei UI", 10, "bold"))
            title.pack(anchor="w", pady=(8, 0))
            sub = tk.Label(card, text=desc, bg=CARD, fg=DIM,
                           font=("Microsoft YaHei UI", 8))
            sub.pack(anchor="w", pady=(0, 8))
            self.cards[value] = (card, dot, ring, inner, title, sub)
            for widget in (card, dot, title, sub):
                widget.bind("<Button-1>", lambda _e, v=value: self.select(v))
                widget.bind("<Double-Button-1>", lambda _e, v=value: self.launch(v))
                widget.bind("<Enter>", lambda _e, v=value: self.hover(v, True))
                widget.bind("<Leave>", lambda _e, v=value: self.hover(v, False))

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=16, pady=(12, 14))
        self.go = tk.Label(bar, text="启 动", bg=ACCENT, fg="#10261a",
                           font=("Microsoft YaHei UI", 10, "bold"), padx=26, pady=6,
                           cursor="hand2")
        self.go.pack(side="right")
        self.go.bind("<Button-1>", lambda _e: self.launch(self.mode))
        quit_btn = tk.Label(bar, text="退出语音程序" if self.running else "取消",
                            bg=CARD, fg=FG, font=("Microsoft YaHei UI", 9),
                            padx=14, pady=6, cursor="hand2")
        quit_btn.pack(side="right", padx=(0, 10))
        quit_btn.bind("<Button-1>", lambda _e: self.quit_program())
        settings_btn = tk.Label(bar, text="设置…", bg=CARD, fg=FG,
                                font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        settings_btn.pack(side="left")
        settings_btn.bind("<Button-1>", lambda _e: self.open_settings())

        self.root.bind("<Return>", lambda _e: self.launch(self.mode))
        self.root.bind("<Escape>", lambda _e: self.root.destroy())
        self.refresh()

    def refresh(self) -> None:
        for value, (card, dot, ring, inner, title, sub) in self.cards.items():
            chosen = value == self.mode
            bg = CARD_SEL if chosen else CARD
            card.config(bg=bg, highlightbackground=ACCENT if chosen else "#33333c")
            for widget in (dot, title, sub):
                widget.config(bg=bg)
            dot.itemconfig(ring, outline=ACCENT if chosen else DIM)
            dot.itemconfig(inner, fill=ACCENT if chosen else bg)
            title.config(fg=FG)
            sub.config(fg=DIM)

    def hover(self, value: str, entering: bool) -> None:
        card = self.cards[value][0]
        if value == self.mode:
            return
        bg = CARD_HOVER if entering else CARD
        card.config(bg=bg)
        # 注意：cards 里第 2、3 项是画布上的图形 id（整数），不是控件，别对它调 config
        _card, dot, _ring, _inner, title, sub = self.cards[value]
        for widget in (dot, title, sub):
            widget.config(bg=bg)

    def select(self, value: str) -> None:
        self.mode = value
        save_mode(value)
        self.refresh()

    def launch(self, value: str) -> None:
        self.select(value)
        start(value)
        self.root.after(500, self.root.destroy)   # 起来之后再关掉这个选择框

    def quit_program(self) -> None:
        if self.running:
            try:
                (HERE / "control.json").write_text(
                    json.dumps({"action": "quit", "ts": time.time()}), encoding="utf-8")
            except Exception:
                pass
        self.root.after(300, self.root.destroy)

    def open_settings(self) -> None:
        """让浮窗展开到设置（没在跑就先启动程序）。"""
        if not program_running():
            start(load_mode())
            time.sleep(2.0)
        try:
            (HERE / "control.json").write_text(
                json.dumps({"action": "expand", "ts": time.time()}), encoding="utf-8")
        except Exception:
            pass
        self.root.after(300, self.root.destroy)


def main() -> int:
    no_console_io()
    Chooser().root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
