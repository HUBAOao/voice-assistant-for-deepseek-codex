@echo off
rem ASCII ONLY content (cmd.exe reads .cmd in the ANSI code page).
rem Brings the floating window back:
rem   already showing -> raise it to front
rem   voice running but window closed -> start just the window
rem   nothing running -> start the voice program (which brings the window)
setlocal EnableExtensions
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

set "PYW=%APP%\.venv\Scripts\pythonw.exe"
if not exist "%PYW%" set "PYW="
if not defined PYW (
  echo   [!] .venv not found - please run the installer first.
  echo       ^(1-Install... cmd / setup.cmd^)
  pause
  exit /b 1
)

"%PYW%" "%APP%\show_overlay.py"
echo.
echo   Asked the floating window to come back.
echo   If you still cannot see it, open show-overlay.log next to this file.
timeout /t 3 /nobreak >nul
exit /b 0
