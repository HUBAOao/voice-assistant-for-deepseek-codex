@echo off
rem ASCII ONLY: cmd.exe parses .cmd in the ANSI code page, so UTF-8 Chinese in
rem this file would corrupt the batch (it did once - the file would not run).
rem The window with Chinese wording is opened by uninstall.py.
setlocal EnableExtensions
title Voice Assistant Uninstaller
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

echo.
echo    Voice Assistant - Uninstaller
echo    ------------------------------------------------
echo.

rem Prefer a real system Python (never the .venv one: we are about to delete it)
set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)
if defined PYEXE (
  %PYEXE% "%~dp0uninstall.py" %*
  echo.
  pause
  exit /b 0
)

echo    [i] No system Python found - doing a simple uninstall instead.
echo        Removing .venv, models and the shortcuts.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d='%APP%';$n=@('python.exe','pythonw.exe');Get-CimInstance Win32_Process | Where-Object { $n -contains $_.Name -and $_.CommandLine -and $_.CommandLine -like ('*'+$d+'*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
timeout /t 2 /nobreak >nul
if exist ".venv" rd /s /q ".venv"
if exist "models" rd /s /q "models"
if exist "__pycache__" rd /s /q "__pycache__"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d='%APP%';$sh=New-Object -ComObject WScript.Shell;foreach($p in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('Programs'))){Get-ChildItem -LiteralPath $p -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object { try { $s=$sh.CreateShortcut($_.FullName); if ($s.TargetPath -like ('*'+$d+'*') -or $s.Arguments -like ('*'+$d+'*')) { Remove-Item -LiteralPath $_.FullName -Force } } catch {} }}"
echo.
echo    Done. You can delete this whole folder now.
pause
