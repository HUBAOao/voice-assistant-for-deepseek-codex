@echo off
chcp 65001 >nul
setlocal
set HF_ENDPOINT=https://hf-mirror.com
if not defined STT_INPUT set "STT_INPUT=USB Microphone"
set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo [ERROR] venv not found - please run install.cmd first.
  pause
  exit /b 1
)
REM Target window / wake word / mic all come from config.json
"%PY%" "%~dp0stt.py" --mode talk %*
pause
