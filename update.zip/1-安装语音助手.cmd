@echo off
rem ---------------------------------------------------------------------------
rem  ASCII ONLY on purpose: cmd.exe reads .cmd files in the ANSI code page, so
rem  UTF-8 Chinese here would break the whole batch file (that bug shipped once).
rem  All the Chinese wording comes from setup.py, which handles UTF-8 properly.
rem ---------------------------------------------------------------------------
setlocal EnableExtensions
title Voice Assistant Installer
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

echo.
echo   ==========================================================
echo    Voice Assistant - Installer
echo   ==========================================================
echo.

rem --- 1) running from inside the zip preview? ---------------------------------
echo %APP% | findstr /i /c:"AppData\Local\Temp" >nul
if not errorlevel 1 (
  echo   [!] This is running from a temporary folder inside the .zip.
  echo       Please close this, right-click the .zip - Extract All,
  echo       then run this file from the extracted folder.
  echo.
  echo   [!] Please read README-FIRST.txt
  echo.
  pause
  exit /b 1
)

rem --- 2) unblock everything downloaded from the internet (Mark of the Web) ----
echo   [1/3] Unblocking files downloaded from the internet ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%APP%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>nul

rem --- 3) hand over to setup.cmd (it does the real work) ----------------------
echo   [2/3] Starting setup (this can take 10-30 minutes the first time:
echo         it downloads ~300MB of libraries and a ~500MB speech model) ...
echo   [3/3] Full log will be written to: %APP%\install.log
echo.
call "%~dp0setup.cmd" %*
set "RC=%ERRORLEVEL%"

echo.
echo   ==========================================================
if "%RC%"=="0" (
  echo    FINISHED. A shortcut named "YuYinZhuShou" should be on your
  echo    desktop now - double-click it.
) else (
  echo    SETUP FAILED, exit code %RC% .
  echo    Please send these two files to the developer:
  echo      %APP%\install.log
  echo      %APP%\voice.log
)
echo   ==========================================================
echo.
pause
exit /b %RC%
