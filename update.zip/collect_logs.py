#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把排查用的东西打成一个 zip 放桌面 —— 那边双击「收日志.cmd」就会跑这个。

为什么要有它：悬浮窗要是出不来，用户看不到界面、也不知道去哪找日志。
点一下这个，桌面就出一个 zip，直接拖进微信发过来就行。
"""

from __future__ import annotations

import json
import os
import platform
import subprocess
import sys
import time
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NO_WINDOW = 0x08000000 if os.name == "nt" else 0
# 只收尾巴，别把几 MB 的日志整个塞进去
TAIL_LINES = 300
TAIL_FILES = ["voice.log", "syslog.md", "overlay-exit.log", "input.log", "watchdog.log"]
FULL_FILES = ["overlay-error.log", "install.log", "更新日志.txt", "tray-error.log",
              "pet-error.log", "last-crash.txt", "status.json", "config.json"]
SECRET_KEYS = {"voice", "corrections", "target", "input"}


def say(text: str = "") -> None:
    print(text, flush=True)


def desktop() -> Path:
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "[Environment]::GetFolderPath('Desktop')"],
            capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW)
        p = Path(out.stdout.strip())
        if p.is_dir():
            return p
    except Exception:
        pass
    return Path.home() / "Desktop"


def app_shortcuts() -> list:
    script = (
        "$sh=New-Object -ComObject WScript.Shell;"
        "foreach($p in @([Environment]::GetFolderPath('Desktop'),"
        "[Environment]::GetFolderPath('Startup'))){"
        " Get-ChildItem -LiteralPath $p -Filter *.lnk -ErrorAction SilentlyContinue |"
        " ForEach-Object { try { $s=$sh.CreateShortcut($_.FullName);"
        " Write-Output ($_.Name + ' -> ' + $s.TargetPath + ' ' + $s.Arguments) } catch {} } }"
    )
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-Command", script], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=40,
                             creationflags=NO_WINDOW)
        # 只留跟本程序有关的（别把用户桌面上其它快捷方式一起收走）
        me = str(HERE).lower()
        keep = []
        for ln in out.stdout.splitlines():
            low = ln.lower()
            if me in low or "语音助手" in ln or "voice" in low:
                keep.append(ln.strip())
        return keep
    except Exception:
        return []


def running() -> list:
    script = ("Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' } |"
              " ForEach-Object { $_.ProcessId.ToString() + ' ' + $_.Name + ' ' +"
              " [string]$_.CommandLine }")
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-Command", script], capture_output=True, text=True,
                             encoding="utf-8", errors="replace", timeout=40,
                             creationflags=NO_WINDOW)
        me = str(HERE).lower()
        return [ln.strip() for ln in out.stdout.splitlines()
                if ln.strip() and me in ln.lower()]
    except Exception:
        return []


def tail(path: Path, lines: int = TAIL_LINES) -> str:
    try:
        data = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(data[-lines:]) + "\n"
    except Exception as exc:
        return f"（读不了：{exc}）\n"


def version_here() -> str:
    try:
        sys.path.insert(0, str(HERE))
        import importlib.util

        spec = importlib.util.spec_from_file_location("v_here", HERE / "version.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return str(getattr(mod, "APP_VERSION", "?"))
    except Exception as exc:
        return f"（读不到：{exc}）"


def env_text() -> str:
    lines = [
        f"时间：{time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"程序目录：{HERE}",
        f"程序版本：{version_here()}",
        f"系统：{platform.platform()}",
        f"Python：{sys.version.split()[0]}（{sys.executable}）",
        "",
        "【文件在不在】",
    ]
    for name in ("stt.py", "overlay.py", "version.py", "config.json", "voice.ico",
                 "使用教程.html", "说明书.html", "1-安装语音助手.cmd",
                 "卸载语音助手.cmd", "显示悬浮窗.cmd", "收日志.cmd",
                 "overlay_ready.json", "heartbeat.json"):
        p = HERE / name
        extra = ""
        if p.exists():
            try:
                extra = f"  {p.stat().st_size} 字节"
                if name == "overlay_ready.json":
                    extra += "  " + p.read_text(encoding="utf-8", errors="replace")[:200]
            except Exception:
                pass
        lines.append(f"  {'有' if p.exists() else '没有'}  {name}{extra}")
    lines += ["", "【运行环境】",
              f"  .venv：{'有' if (HERE / '.venv').exists() else '没有'}",
              f"  models：{'有' if (HERE / 'models').exists() else '没有'}"]
    # 依赖检查：少一个库就会"没悬浮窗、也没报错"，这里直接列出来
    venv_py = HERE / ".venv" / "Scripts" / "python.exe"
    if venv_py.exists():
        try:
            out = subprocess.run(
                [str(venv_py), "-c",
                 "import importlib.util;mods=['PIL','pystray','numpy','sounddevice',"
                 "'faster_whisper','av','edge_tts','pypinyin','tkinter'];"
                 "print(' '.join(m + ('=OK' if importlib.util.find_spec(m) else '=缺')"
                 " for m in mods))"],
                capture_output=True, text=True, timeout=60, creationflags=NO_WINDOW)
            lines.append("  依赖：" + (out.stdout.strip() or f"（查不动：{out.stderr[:80]}）"))
        except Exception as exc:
            lines.append(f"  依赖：查不动（{exc}）")
    else:
        lines.append("  依赖：没有 .venv，没得查")
    try:
        models = list((HERE / "models").glob("*")) if (HERE / "models").exists() else []
        lines.append("  模型文件：" + (", ".join(p.name for p in models) or "（空）"))
    except Exception:
        pass
    lines += ["", "【本程序的快捷方式（只列跟它有关的）】",
              "  （只收跟本程序相关的，你桌面上其它的不收集）"]
    links = app_shortcuts()
    lines += [f"  {s}" for s in links] or ["  （没找到指向它的快捷方式）"]
    lines += ["", "【本程序的进程（只列跟它有关的）】"]
    procs = running()
    lines += [f"  {s}" for s in procs] or ["  （它现在没在跑）"]
    return "\n".join(lines) + "\n"


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleTitleW("语音助手 - 收日志")
        except Exception:
            pass

    out = desktop() / f"语音助手日志-{time.strftime('%Y%m%d-%H%M')}.zip"
    say("")
    say("  正在把排查用的东西打包…")
    say(f"  程序目录：{HERE}")
    got = 0
    try:
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("环境.txt", env_text())
            got += 1
            for name in FULL_FILES:
                p = HERE / name
                if not p.is_file():
                    continue
                if name == "config.json":
                    try:                       # 配置里去掉可能敏感的那几项
                        data = json.loads(p.read_text(encoding="utf-8"))
                        for k in SECRET_KEYS:
                            data.pop(k, None)
                        zf.writestr(name, json.dumps(data, ensure_ascii=False, indent=2))
                        got += 1
                        continue
                    except Exception:
                        pass
                try:
                    zf.write(p, name)
                    got += 1
                except Exception:
                    pass
            for name in TAIL_FILES:
                p = HERE / name
                if p.is_file():
                    zf.writestr(name + "（尾巴 300 行）", tail(p))
                    got += 1
    except Exception as exc:  # noqa: BLE001
        say(f"  ✗ 打包失败：{exc}")
        return 1

    say(f"  ✓ 收好了 {got} 份材料")
    say("")
    say(f"  就在这儿：{out}")
    say("  把这个 zip 直接拖进微信发给开发者就行。")
    try:
        subprocess.Popen(f'explorer /select,"{out}"', shell=True)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
