# -*- coding: utf-8 -*-
"""读 / 切换 **Codex 里的对话会话**（不是电脑上的窗口）。

用户澄清过："对话窗口"指的是他和我（Codex）的会话 —— 比如「语音助手相关」「学习 UV5
蓝图知识」「能否同时处理多个项目」各是一个会话。所以这里：

  · `list_threads()`  用 UI Automation 读桌面 App 侧栏里现在有哪些会话，
                      并且把"当前打开的那个"标出来（实时，你那边切了它就知道）
  · `open_thread(name)` 点一下侧栏里那个会话，让 App 切过去

实现放在 codex_threads.ps1 里（纯 PowerShell + .NET 的 UI Automation，不用装任何东西）。
"""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "codex_threads.ps1"


def _run(args: list[str], timeout: float = 25.0) -> tuple[bool, str]:
    """跑 PowerShell。**中文名字一律走文件**（走参数会被按 GBK 解成乱码）。"""
    if not SCRIPT.exists():
        return False, "NO_SCRIPT"
    out_file = Path(tempfile.gettempdir()) / "va-thread-out.txt"
    try:
        out_file.unlink()
    except Exception:
        pass
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
           "-File", str(SCRIPT), "-OutFile", str(out_file)] + args
    flags = 0x08000000 if sys.platform == "win32" else 0
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           encoding="utf-8", errors="replace",
                           timeout=timeout, creationflags=flags)
        # 优先读脚本写出来的那个 UTF-8 文件（stdout 里的中文不可靠）
        if out_file.exists():
            text_out = out_file.read_text(encoding="utf-8-sig", errors="replace")
        else:
            text_out = (p.stdout or "") + (p.stderr or "")
        return p.returncode == 0, text_out.strip()
    except Exception as exc:
        return False, "%s: %s" % (type(exc).__name__, exc)


def _run_with_name(name: str, extra: list[str], timeout: float = 30.0):
    """把会话名写进一个 UTF-8 临时文件再交给 PowerShell（避免中文变乱码）。"""
    tmp = Path(tempfile.gettempdir()) / "va-thread-name.txt"
    try:
        tmp.write_text(str(name), encoding="utf-8")
    except Exception as exc:
        return False, "临时文件写不了：%s" % exc
    return _run(extra + ["-NameFile", str(tmp)], timeout=timeout)


def available() -> bool:
    ok, out = _run(["-Action", "list"])
    return ok and "NO_WINDOW" not in out


def list_threads() -> list[dict]:
    """现在有哪些会话：[{name, current}]，顺序就是侧栏里的顺序。"""
    ok, out = _run(["-Action", "list"])
    if not ok or "NO_WINDOW" in out:
        return []
    rows: list[dict] = []
    seen: set[str] = set()
    for line in out.splitlines():
        line = line.strip()
        if not line or "\t" not in line:
            continue
        name, _, mark = line.rpartition("\t")
        name = name.strip()
        if not name or name in seen:
            continue
        seen.add(name)
        rows.append({"name": name, "current": mark.strip() == "1"})
    return rows


def current_name() -> str:
    for row in list_threads():
        if row["current"]:
            return row["name"]
    return ""


def open_thread(name: str, dry_run: bool = False) -> tuple[bool, str]:
    """切到某个会话（点侧栏那一行）。"""
    name = str(name or "").strip()
    if not name:
        return False, "没给会话名"
    args = ["-Action", "open"]
    if dry_run:
        args.append("-DryRun")
    ok, out = _run_with_name(name, args, timeout=30.0)
    if not ok:
        return False, out[:120]
    if "CLICKED" in out or "WOULD_CLICK" in out:
        return True, name
    if "NOT_FOUND" in out:
        return False, "侧栏里没找到这个会话（可能被折叠/滚出可视区了）"
    if "NO_WINDOW" in out:
        return False, "没找到 Codex 窗口（先把它打开）"
    return False, out[:120]


if __name__ == "__main__":                      # 自己跑一下看看
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    rows = list_threads()
    print("Codex 里的会话一共 %d 个：" % len(rows))
    for r in rows:
        print("   %s%s" % (r["name"], "   ← 当前打开的就是它" if r["current"] else ""))
