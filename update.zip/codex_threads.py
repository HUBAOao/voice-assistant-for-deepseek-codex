# -*- coding: utf-8 -*-
"""Read and manage Codex threads for the phone conversation picker.

The list and mutations use Codex's local app-server protocol.  Opening a
thread uses its stable ``codex://threads/<id>`` deep link, with UI Automation
as a compatibility fallback.  We never write ``state_5.sqlite`` directly.
"""
from __future__ import annotations

import atexit
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlencode

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "codex_threads.ps1"
DB = Path.home() / ".codex" / "state_5.sqlite"
INDEX = Path.home() / ".codex" / "session_index.jsonl"

_RPC_LOCK = threading.RLock()
_RPC: "_AppServerClient | None" = None


def _run(args: list[str], timeout: float = 25.0) -> tuple[bool, str]:
    """Run the small UI Automation helper used for focus/click fallback."""
    if not SCRIPT.exists():
        return False, "NO_SCRIPT"
    try:
        p = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-File", str(SCRIPT)] + args,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            creationflags=0x08000000 if sys.platform == "win32" else 0,
        )
        return p.returncode == 0, ((p.stdout or "") + (p.stderr or "")).strip()
    except Exception as exc:  # noqa: BLE001
        return False, "%s: %s" % (type(exc).__name__, exc)


def _run_with_name(name: str, extra: list[str], timeout: float = 30.0):
    """Pass Chinese names through a UTF-8 file for PowerShell 5.1."""
    import tempfile

    tmp = Path(tempfile.gettempdir()) / "va-thread-name.txt"
    try:
        tmp.write_text(str(name), encoding="utf-8")
    except Exception as exc:  # noqa: BLE001
        return False, "临时文件写不了：%s" % exc
    return _run(extra + ["-NameFile", str(tmp)], timeout=timeout)


def _find_codex_exe() -> str:
    env = os.environ.get("CODEX_EXE", "").strip()
    candidates: list[Path] = []
    if env:
        candidates.append(Path(env))
    found = shutil.which("codex")
    if found:
        candidates.append(Path(found))
    local = Path.home() / "AppData" / "Local" / "OpenAI" / "Codex" / "bin"
    try:
        candidates.extend(sorted(local.glob("*/codex.exe"),
                                  key=lambda p: p.stat().st_mtime, reverse=True))
    except Exception:
        pass
    for path in candidates:
        try:
            if path.is_file():
                return str(path)
        except Exception:
            pass
    return ""


# Public compatibility probe for health checks and adapters.  The old private
# spelling remains available for existing callers and saved diagnostics.
find_codex_exe = _find_codex_exe


class _AppServerClient:
    """Tiny JSON-lines app-server client with a persistent child process."""

    def __init__(self, exe: str) -> None:
        self.exe = exe
        self.proc: subprocess.Popen | None = None
        self.messages: queue.Queue[dict] = queue.Queue()
        self.reader: threading.Thread | None = None
        self.seq = 0
        self.user_agent = ""
        self.start()

    def start(self) -> None:
        self.stop()
        flags = 0x08000000 if sys.platform == "win32" else 0
        self.proc = subprocess.Popen(
            [self.exe, "app-server", "--stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            creationflags=flags,
        )
        self.messages = queue.Queue()

        def read_stdout() -> None:
            assert self.proc is not None and self.proc.stdout is not None
            try:
                for line in self.proc.stdout:
                    try:
                        obj = json.loads(line)
                    except Exception:
                        continue
                    if isinstance(obj, dict):
                        self.messages.put(obj)
            finally:
                self.messages.put({"__eof__": True})

        self.reader = threading.Thread(target=read_stdout, daemon=True)
        self.reader.start()
        self.seq += 1
        result = self._exchange("initialize", {
            "clientInfo": {
                "name": "voice-assistant",
                "title": "Voice Assistant",
                "version": "1.0",
            },
            "capabilities": {"experimentalApi": True},
        }, request_id=self.seq, timeout=12.0)
        if not isinstance(result, dict) or "userAgent" not in result:
            raise RuntimeError("Codex app-server initialize failed")
        self.user_agent = str(result.get("userAgent") or "")
        self._send({"method": "initialized"})

    def stop(self) -> None:
        proc = self.proc
        self.proc = None
        if proc is None:
            return
        try:
            if proc.stdin:
                proc.stdin.close()
        except Exception:
            pass
        try:
            proc.terminate()
            proc.wait(timeout=2.0)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def alive(self) -> bool:
        return bool(self.proc is not None and self.proc.poll() is None)

    def _send(self, obj: dict) -> None:
        if not self.proc or not self.proc.stdin or not self.alive():
            raise RuntimeError("Codex app-server is not running")
        self.proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()

    def _exchange(self, method: str, params: dict | None = None,
                  request_id: int | None = None, timeout: float = 15.0) -> Any:
        rid = self.seq if request_id is None else request_id
        self._send({"id": rid, "method": method, "params": params or {}})
        deadline = time.monotonic() + timeout
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                raise TimeoutError("%s timed out" % method)
            try:
                msg = self.messages.get(timeout=min(left, 0.5))
            except queue.Empty:
                if not self.alive():
                    raise RuntimeError("Codex app-server exited")
                continue
            if msg.get("__eof__"):
                raise RuntimeError("Codex app-server closed its output")
            if msg.get("id") == rid:
                if "error" in msg:
                    err = msg.get("error")
                    if isinstance(err, dict):
                        raise RuntimeError(str(err.get("message") or err))
                    raise RuntimeError(str(err))
                return msg.get("result")
            # Reply to unexpected server requests so they cannot wait forever.
            if msg.get("id") is not None and msg.get("method"):
                try:
                    self._send({
                        "id": msg["id"],
                        "error": {"code": -32601, "message": "unsupported"},
                    })
                except Exception:
                    pass

    def call(self, method: str, params: dict | None = None,
             timeout: float = 15.0) -> Any:
        self.seq += 1
        return self._exchange(method, params, request_id=self.seq, timeout=timeout)


def _client() -> _AppServerClient:
    global _RPC
    exe = _find_codex_exe()
    if not exe:
        raise RuntimeError("没找到 Codex 命令行程序")
    with _RPC_LOCK:
        if _RPC is None or not _RPC.alive():
            _RPC = _AppServerClient(exe)
        return _RPC


def _rpc(method: str, params: dict | None = None, timeout: float = 15.0) -> Any:
    global _RPC
    with _RPC_LOCK:
        for attempt in range(2):
            try:
                return _client().call(method, params, timeout=timeout)
            except Exception:
                if _RPC is not None:
                    _RPC.stop()
                _RPC = None
                if attempt:
                    raise
    raise RuntimeError("Codex app-server unavailable")


def _close_rpc() -> None:
    global _RPC
    with _RPC_LOCK:
        if _RPC is not None:
            _RPC.stop()
            _RPC = None


atexit.register(_close_rpc)


def probe_app_server() -> dict[str, str]:
    """Initialize a short-lived app-server and verify the basic thread API."""
    exe = _find_codex_exe()
    if not exe:
        raise RuntimeError("没找到 Codex 命令行程序")
    client = _AppServerClient(exe)
    try:
        result = client.call(
            "thread/list",
            {"limit": 1, "useStateDbOnly": True,
             "sortKey": "recency_at", "sortDirection": "desc"},
            timeout=8.0,
        )
        if not isinstance(result, dict) or "data" not in result:
            raise RuntimeError("Codex app-server thread/list 返回格式不兼容")
        return {"exe": exe, "userAgent": client.user_agent}
    finally:
        client.stop()


def _index_titles() -> dict[str, str]:
    names: dict[str, str] = {}
    try:
        for line in INDEX.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                obj = json.loads(line)
            except Exception:
                continue
            if isinstance(obj, dict) and obj.get("id") and obj.get("thread_name"):
                names[str(obj["id"])] = str(obj["thread_name"]).strip()
    except Exception:
        pass
    return names


def _ui_current_title() -> str:
    ok, out = _run(["-Action", "list"], timeout=8.0)
    if not ok or "NO_WINDOW" in out:
        return ""
    for line in out.splitlines():
        if "\t" in line and line.rstrip().endswith("\t1"):
            return line.rsplit("\t", 1)[0].strip()
    return ""


def _paged(method: str, params: dict, key: str = "data",
           page_limit: int = 200, max_pages: int = 8) -> tuple[list[dict], dict]:
    rows: list[dict] = []
    extra: dict = {}
    cursor = None
    for _ in range(max_pages):
        p = dict(params)
        p["limit"] = page_limit
        if cursor:
            p["cursor"] = cursor
        result = _rpc(method, p, timeout=25.0)
        if not isinstance(result, dict):
            break
        data = result.get(key)
        if isinstance(data, list):
            rows.extend(x for x in data if isinstance(x, dict))
        if isinstance(result.get("readStates"), dict):
            extra.setdefault("readStates", {}).update(result["readStates"])
        cursor = result.get("nextCursor")
        if not cursor:
            break
    return rows, extra


def list_projects() -> list[dict]:
    """Projects shown by Codex, including projects with no visible threads."""
    try:
        rows, _ = _paged("project/list", {
            "sortKey": "position",
            "sortDirection": "asc",
        })
        out = []
        for p in rows:
            pid = str(p.get("id") or "")
            name = str(p.get("name") or "").strip()
            if pid and name:
                out.append({
                    "id": pid,
                    "name": name,
                    "position": int(p.get("position") or 0),
                    "recency_at": int(p.get("recencyAt") or 0) * 1000,
                    "roots": p.get("roots") or [],
                })
        return out
    except Exception:
        return []


def _sections() -> list[dict]:
    try:
        rows, _ = _paged("threadSection/list", {}, page_limit=100)
        return [r for r in rows if r.get("id") and r.get("name")]
    except Exception:
        return []


def _fallback_threads() -> list[dict]:
    """Read-only fallback for a temporarily unavailable app-server."""
    try:
        import sqlite3

        if not DB.exists():
            return []
        con = sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True)
        try:
            projects = {str(i): str(n) for i, n in
                        con.execute("select id, name from projects")}
            nice = _index_titles()
            current = _ui_current_title()
            rows = []
            for r in con.execute(
                    "select id,title,name,first_user_message,project_id,archived,"
                    "updated_at_ms,recency_at_ms,preview from threads "
                    "where coalesce(archived,0)=0 "
                    "order by coalesce(recency_at_ms,updated_at_ms) desc"):
                tid, title, name, first, pid, archived, updated, recency, preview = r
                tid = str(tid)
                clean = nice.get(tid) or str(name or title or first or "").strip()[:80]
                if not clean:
                    continue
                rows.append({
                    "id": tid, "name": clean, "title": clean,
                    "current": bool(current and clean == current),
                    "pinned": False, "unread": False,
                    "project": projects.get(str(pid or ""), ""),
                    "project_id": str(pid or ""), "archived": False,
                    "updated_at": int(recency or updated or 0),
                    "created_at": 0, "preview": str(preview or "")[:160],
                    "section_id": "", "section": "", "status": "",
                    "read_revision": "", "from_db": True,
                })
            return rows
        finally:
            con.close()
    except Exception:
        return []


def list_threads() -> list[dict]:
    """Return the same information hierarchy used by the desktop chat picker."""
    projects = list_projects()
    project_names = {p["id"]: p["name"] for p in projects}
    project_roots: list[tuple[str, str, int]] = []
    for project in projects:
        for root in project.get("roots") or []:
            path = str((root or {}).get("path") or "").replace("/", "\\").lower()
            if path.startswith("\\\\?\\"):
                path = path[4:]
            if path:
                project_roots.append((path.rstrip("\\"), project["id"],
                                      int(project.get("position") or 0)))
    sections = _sections()
    section_names = {str(s["id"]): str(s["name"]) for s in sections}
    nice = _index_titles()
    current = _ui_current_title()

    try:
        visible, extra = _paged("thread/list", {
            "archived": False,
            "useStateDbOnly": True,
            "sortKey": "recency_at",
            "sortDirection": "desc",
        })
        archived, _ = _paged("thread/list", {
            "archived": True,
            "useStateDbOnly": True,
            "sortKey": "updated_at",
            "sortDirection": "desc",
        })
    except Exception:
        return _fallback_threads()

    read_states = extra.get("readStates") if isinstance(extra.get("readStates"), dict) else {}
    out: list[dict] = []
    for source, is_archived in ((visible, False), (archived, True)):
        for t in source:
            tid = str(t.get("id") or "")
            if not tid:
                continue
            title = (nice.get(tid) or str(t.get("name") or "").strip()
                     or str(t.get("preview") or "").strip()[:80])
            if not title:
                continue
            pid = str(t.get("projectId") or "")
            cwd = str(t.get("cwd") or "").replace("/", "\\").lower()
            if cwd.startswith("\\\\?\\"):
                cwd = cwd[4:]
            if not pid and cwd:
                leaf = cwd.rstrip("\\").rsplit("\\", 1)[-1]
                matches = []
                for root, candidate_id, position in project_roots:
                    if cwd == root or cwd.startswith(root + "\\"):
                        project_name = project_names.get(candidate_id, "").casefold()
                        matches.append((
                            project_name == leaf,
                            len(root),
                            -position,
                            candidate_id,
                        ))
                if matches:
                    pid = max(matches)[3]
            sec = t.get("section") if isinstance(t.get("section"), dict) else {}
            sid = str(sec.get("id") or "")
            sname = str(sec.get("name") or section_names.get(sid) or "")
            rs = read_states.get(tid) if isinstance(read_states.get(tid), dict) else {}
            unread = bool(rs.get("firstUnread"))
            updated = int(t.get("recencyAt") or t.get("updatedAt") or 0)
            created = int(t.get("createdAt") or 0)
            out.append({
                "id": tid,
                "name": title,
                "title": title,
                "current": bool(current and title == current),
                "pinned": bool(sname and sname.casefold() in
                               {"pinned", "置顶", "已置顶", "top"}),
                "unread": unread,
                "project": project_names.get(pid, ""),
                "project_id": pid,
                "archived": bool(is_archived),
                "updated_at": updated * 1000 if updated < 10_000_000_000 else updated,
                "created_at": created * 1000 if created < 10_000_000_000 else created,
                "preview": str(t.get("preview") or "")[:160],
                "section_id": sid,
                "section": sname,
                "status": ((t.get("status") or {}).get("type")
                           if isinstance(t.get("status"), dict) else ""),
                "read_revision": str(rs.get("revision") or ""),
                "from_db": False,
            })
    return out


def current_name() -> str:
    return _ui_current_title()


def current_thread_id() -> str:
    current = _ui_current_title()
    if not current:
        return ""
    # The UI exposes the active title, not the thread UUID.  Resolve it from
    # the read-only state database and prefer the most recent exact match.
    try:
        import sqlite3

        if DB.exists():
            con = sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True)
            try:
                row = con.execute(
                    "select id from threads where title=? or name=? "
                    "order by coalesce(recency_at_ms,updated_at_ms) desc limit 1",
                    (current, current),
                ).fetchone()
                if row:
                    return str(row[0])
            finally:
                con.close()
    except Exception:
        pass
    return ""


def _open_deeplink(route: str) -> bool:
    url = "codex://threads/" + route
    try:
        if sys.platform == "win32":
            os.startfile(url)  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def open_new_thread(project_id: str = "") -> tuple[bool, str]:
    project_id = str(project_id or "").strip()
    query = ("?" + urlencode({"projectId": project_id})) if project_id else ""
    if not _open_deeplink("new" + query):
        ok, out = _run(["-Action", "new"], timeout=15.0)
        if not ok:
            return False, out[:120] or "打不开新对话"
    return True, "新对话"


def open_thread(name: str, thread_id: str = "", dry_run: bool = False) -> tuple[bool, str]:
    """Open a thread by stable id, then verify its title when possible."""
    name = str(name or "").strip()
    thread_id = str(thread_id or "").strip()
    if not name and not thread_id:
        return False, "没给会话名"
    if dry_run:
        ok, out = _run_with_name(name, ["-Action", "open", "-DryRun"], timeout=30.0)
        if ok and ("WOULD_CLICK" in out or "CLICKED" in out):
            return True, out
        if "NOT_FOUND" in out:
            return False, "侧栏里没找到这个会话（可能被折叠/滚出可视区了）"
        return False, out[:120]

    if thread_id:
        if current_thread_id() == thread_id:
            return True, name or thread_id
        if _open_deeplink(quote(thread_id, safe="")):
            for _ in range(12):
                time.sleep(0.15)
                if not name or _ui_current_title() == name:
                    return True, name or thread_id

    ok, out = _run_with_name(name, ["-Action", "open"], timeout=30.0)
    if not ok:
        return False, out[:120]
    if "CLICKED" in out:
        return True, name
    if "NOT_FOUND" in out:
        return False, "侧栏里没找到这个会话（可能被折叠/滚出可视区了）"
    if "NO_WINDOW" in out:
        return False, "没找到 Codex 窗口（先把它打开）"
    return False, out[:120]


def rename_thread(thread_id: str, new_name: str) -> tuple[bool, str]:
    new_name = str(new_name or "").strip()
    if not thread_id or not new_name:
        return False, "新名字不能为空"
    try:
        _rpc("thread/name/set", {"threadId": thread_id, "name": new_name})
        return True, new_name
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:120]


def set_read_state(thread_id: str, read: bool, revision: str = "") -> tuple[bool, str]:
    try:
        rev = str(revision or "")
        if not rev:
            data = _rpc("thread/read", {"threadId": thread_id, "includeTurns": False})
            state = data.get("readState") if isinstance(data, dict) else {}
            rev = str((state or {}).get("revision") or "")
        if not rev:
            return False, "读不到会话的已读状态"
        _rpc("thread/readState/update", {
            "threadId": thread_id,
            "expectedRevision": rev,
            "operation": {"type": "read" if read else "unread"},
        })
        return True, "已标为已读" if read else "已标为未读"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:120]


def set_pinned(thread_id: str, pinned: bool) -> tuple[bool, str]:
    try:
        sections = _sections()
        pinned_section = next(
            (s for s in sections
             if str(s.get("name") or "").casefold() in
             {"pinned", "置顶", "已置顶", "top"}),
            None,
        )
        if pinned:
            if pinned_section is None:
                result = _rpc("threadSection/create", {"name": "Pinned"})
                pinned_section = result.get("section") if isinstance(result, dict) else None
            if not pinned_section:
                return False, "电脑上没有置顶分组"
            sid = str(pinned_section.get("id") or "")
        else:
            sid = None
        _rpc("thread/section/move", {"threadId": thread_id, "sectionId": sid})
        return True, "已置顶" if pinned else "已取消置顶"
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:120]


def move_to_project(thread_id: str, project_id: str) -> tuple[bool, str]:
    try:
        pid = str(project_id or "").strip()
        _rpc("thread/metadata/update", {"threadId": thread_id, "projectId": pid})
        if not pid:
            return True, "已移出项目"
        name = next((p["name"] for p in list_projects() if p["id"] == pid), pid)
        return True, "已移动到 " + name
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)[:120]


def _label_file(prefix: str, labels: list[str]) -> Path:
    import tempfile

    path = Path(tempfile.gettempdir()) / ("va-%s-%s.txt" % (prefix, os.getpid()))
    path.write_text("\n".join(labels), encoding="utf-8")
    return path


def _ui_manage(action: str, name: str, menu: list[str],
               confirm: list[str] | None = None) -> tuple[bool, str]:
    menu_file = _label_file("thread-menu", menu)
    args = ["-Action", action, "-MenuFile", str(menu_file)]
    if confirm:
        confirm_file = _label_file("thread-confirm", confirm)
        args += ["-ConfirmFile", str(confirm_file)]
    ok, out = _run_with_name(name, args, timeout=35.0)
    if not ok:
        return False, out[:120]
    if "CLICKED_MENU" in out or "ARCHIVE_SENT" in out or "CONFIRMED" in out:
        return True, out[-40:]
    if "CONFIRM_NOT_FOUND" in out:
        return False, "桌面对话框里没找到删除确认按钮"
    if "NOT_FOUND" in out:
        return False, "电脑端没有找到这条会话"
    return False, out[:120]


def _row_by_id(thread_id: str) -> dict | None:
    return next((r for r in list_threads() if r.get("id") == thread_id), None)


def _restore_thread(row: dict | None) -> None:
    if not row or row.get("archived"):
        return
    try:
        if current_thread_id() != str(row.get("id") or ""):
            open_thread(str(row.get("name") or ""), str(row.get("id") or ""))
    except Exception:
        pass


def archive_thread(thread_id: str, archived: bool = True,
                   name: str = "") -> tuple[bool, str]:
    row = _row_by_id(thread_id)
    name = str(name or (row or {}).get("name") or "").strip()
    if archived:
        if not name:
            return False, "没找到会话名"
        previous = next((r for r in list_threads() if r.get("current")), None)
        if current_thread_id() != thread_id:
            ok, msg = open_thread(name, thread_id)
            if not ok:
                return False, msg
        ok, msg = _ui_manage("archivecurrent", name, [])
        if not ok:
            _restore_thread(previous)
            return False, msg
        time.sleep(0.35)
        changed = _row_by_id(thread_id)
        _restore_thread(previous)
        if changed is None or not changed.get("archived"):
            return False, "电脑端没有确认归档成功"
        return True, "已归档"

    previous = next((r for r in list_threads() if r.get("current")), None)
    if not _open_deeplink(quote(thread_id, safe="")):
        return False, "打不开已归档会话"
    time.sleep(0.65)
    ok, msg = _ui_manage("unarchive", name, [
        "Unarchive and open", "Unarchive this chat", "Unarchive chat",
        "取消归档聊天", "取消归档",
    ])
    if not ok:
        return False, msg
    time.sleep(0.45)
    changed = _row_by_id(thread_id)
    if changed is None or changed.get("archived"):
        _restore_thread(previous)
        return False, "电脑端没有确认取消归档成功"
    _restore_thread(previous)
    return True, "已取消归档"


def delete_thread(thread_id: str, name: str = "") -> tuple[bool, str]:
    row = _row_by_id(thread_id)
    name = str(name or (row or {}).get("name") or "").strip()
    if not name:
        return False, "没找到会话名"
    previous = next((r for r in list_threads() if r.get("current")), None)
    try:
        _rpc("thread/delete", {"threadId": thread_id})
    except Exception:
        # A thread currently loaded by the desktop owns a writer. Archive it
        # first; that unloads the writer, then the official delete API works.
        ok, msg = archive_thread(thread_id, True, name)
        if not ok:
            _restore_thread(previous)
            return False, msg
        try:
            _rpc("thread/delete", {"threadId": thread_id})
        except Exception as exc:  # noqa: BLE001
            _restore_thread(previous)
            return False, "会话已归档，但永久删除失败：" + str(exc)[:90]
    time.sleep(0.45)
    if _row_by_id(thread_id) is not None:
        _restore_thread(previous)
        return False, "电脑端没有确认删除成功"
    _restore_thread(previous)
    return True, "会话已永久删除"


def thread_action(action: str, thread_id: str, **payload: Any) -> tuple[bool, str]:
    action = str(action or "").strip().lower()
    thread_id = str(thread_id or "").strip()
    if not thread_id:
        return False, "没给会话 ID"
    if action == "rename":
        return rename_thread(thread_id, str(payload.get("name") or ""))
    if action == "pin":
        return set_pinned(thread_id, bool(payload.get("pinned", True)))
    if action == "read":
        return set_read_state(thread_id, bool(payload.get("read", True)),
                              str(payload.get("revision") or ""))
    if action == "project":
        return move_to_project(thread_id, str(payload.get("project_id") or ""))
    if action == "archive":
        return archive_thread(thread_id, bool(payload.get("archived", True)),
                              str(payload.get("title") or payload.get("name") or ""))
    if action == "delete":
        return delete_thread(thread_id,
                             str(payload.get("title") or payload.get("name") or ""))
    return False, "不支持的会话操作"


def available() -> bool:
    ok, out = _run(["-Action", "list"])
    return ok and "NO_WINDOW" not in out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    rows = list_threads()
    print("Codex 里的会话一共 %d 个：" % len(rows))
    for row in rows:
        print("   %s%s%s" % (
            row["name"],
            "   [置顶]" if row.get("pinned") else "",
            "   ← 当前" if row.get("current") else "",
        ))
