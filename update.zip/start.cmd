@echo off
chcp 65001 >nul
setlocal
set HF_ENDPOINT=https://hf-mirror.com
set "PY=%~dp0.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo [ERROR] venv not found - please run install.cmd first.
  pause
  exit /b 1
)
"%PY%" "%~dp0stt.py" %*
pause
