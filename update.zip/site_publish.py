# -*- coding: utf-8 -*-
"""把下载页发布成一个公网网站（免费静态托管），以后每次更新自动同步。

为什么不能"全自动"：发布到公网必须有一个**你的账号**（GitHub / Gitee / Cloudflare…），
注册和登录只能你来（我不能替你注册账号）。所以这里做到的是：

  第一次：建一个空仓库（30 秒，说明见下）→ 把仓库地址填进设置里「发布到网站」
          → 点一下发布 → git 弹一次登录 → 完事（登录一次就被 Windows 记住了）。
  以后： 每次打包都会自动重新生成页面 + 自动 commit + 自动 push，
          网站上的版本号、更新日志、安装包就都是最新的。

仓库怎么建（免费）：
  · GitHub：github.com → 右上 + → New repository → 名字随便（例如 voice-assistant）
    → Public → Create → 复制 https 地址（形如
    https://github.com/你的用户名/voice-assistant.git）
    然后仓库 Settings → Pages → Source 选 Deploy from a branch →
    Branch 选 main + / (root) → Save。几十秒后网址是
    https://你的用户名.github.io/voice-assistant/
  · Gitee（国内快）：gitee.com 新建仓库 → 服务 → Gitee Pages → 部署
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONF = HERE / "site.json"
DEFAULT_DIR = Path(r"F:/语音助手/网站")

# 攒够多少个小版本才往 GitHub 发一次（用户要求：不要每个小版本都发）。
# 版本号本身就是"改过多少次"，所以"攒了几个"就是两个号相减。
PUBLISH_EVERY = 10


def load() -> dict:
    try:
        data = json.loads(CONF.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save(data: dict) -> None:
    try:
        CONF.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def site_dir() -> Path:
    return Path(load().get("dir") or str(DEFAULT_DIR))


def repo_url() -> str:
    return str(load().get("repo") or "").strip()


def public_url() -> str:
    return str(load().get("url") or "").strip().rstrip("/")


def _n(text: str) -> int:
    """版本号 1.139 → 139（只比最后一个点后面的数）。"""
    try:
        return int(str(text).split(".")[-1])
    except Exception:
        return 0


def every() -> int:
    try:
        return max(1, int(load().get("every") or PUBLISH_EVERY))
    except Exception:
        return PUBLISH_EVERY


def published_version() -> str:
    return str(load().get("last_published") or "").strip()


def pending() -> int:
    """从上次发布到现在攒了几个小版本。"""
    import version

    if not published_version():
        return _n(version.APP_VERSION)
    return max(0, _n(version.APP_VERSION) - _n(published_version()))


def mark_published(ver: str = "") -> None:
    import version
    import time as _t

    data = load()
    data["last_published"] = ver or version.APP_VERSION
    data["last_published_at"] = _t.strftime("%Y-%m-%d %H:%M")
    save(data)


def release_notes() -> str:
    """这一批攒下来的改动，给 Release 当说明用。"""
    import version

    names = [x for x in version.CHANGELOG]
    last = _n(published_version())
    start = last                      # 从"上次发布之后"那条开始
    picked = names[start:] or names[-3:]
    lines = []
    for i, text in enumerate(picked, start + 1):
        lines.append("- v1.%d  %s" % (i, text.replace("**", "")))
    head = ("这一版攒了 %d 个小改动（电脑端 v%s）\n\n" % (len(picked),
                                                     version.APP_VERSION))
    return head + "\n".join(lines) + "\n"


def configure(repo: str = "", url: str = "", directory: str = "") -> dict:
    data = load()
    if repo:
        data["repo"] = repo.strip()
    if url:
        data["url"] = url.strip().rstrip("/")
    if directory:
        data["dir"] = directory
    save(data)
    return data


def _git(*args: str, cwd: Path, timeout: float = 120.0):
    try:
        p = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           timeout=timeout)
        return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()
    except Exception as exc:
        return 1, "%s: %s" % (type(exc).__name__, exc)


def ensure_repo(directory: Path = None):
    d = Path(directory or site_dir())
    d.mkdir(parents=True, exist_ok=True)
    if not (d / ".git").exists():
        code, out = _git("init", "-q", "-b", "main", cwd=d)
        if code != 0:
            code, out = _git("init", "-q", cwd=d)
        if code != 0:
            return False, "建仓库失败：%s" % out[:120]
    _git("config", "user.name", "语音助手下载站", cwd=d)
    _git("config", "user.email", "site@local", cwd=d)
    return True, ""


def republish(directory: Path = None):
    d = Path(directory or site_dir())
    try:
        sys.path.insert(0, str(HERE))
        import download_page

        made = download_page.write_static(d)
        return True, "重新生成了 %d 个文件" % len(made)
    except Exception as exc:
        return False, "生成失败：%s: %s" % (type(exc).__name__, exc)


def publish(message: str = "", over: bool = False, force: bool = False):
    """往 GitHub 发一次。

    force=False（打包时走这个）：攒够 every() 个小版本才真发，没攒够就跳过，
    只在本机更新（用户要求：别每个小版本都往 GitHub 发）。
    force=True（设置里那个「发布到网站」按钮 / 手动发）：立刻就发。
    """
    d = site_dir()
    url = repo_url()
    if not over and not url:
        return False, ("还没填仓库地址 —— 先在 github.com 建一个空仓库（Public），"
                       "把它的 https 地址填到设置里「发布到网站」")
    need = every()
    gap = pending()
    if not force and gap < need:
        return False, ("这次先不发（攒着）：已经攒了 %d 个小版本，攒到 %d 个"
                       "就自动发一个大版本（还差 %d 个）。想现在就发，"
                       "点设置里的「发布到网站」" % (gap, need, need - gap)), False
    ok, why = ensure_repo(d)
    if not ok:
        return False, why, False
    ok, why = republish(d)
    if not ok:
        return False, why, False
    # 把这一批的改动写成 Release 说明（工作流会用它当正文）
    try:
        (d / "release-notes.txt").write_text(release_notes(), encoding="utf-8")
    except Exception:
        pass
    if url:
        code, out = _git("remote", "get-url", "origin", cwd=d)
        if code != 0:
            code, out = _git("remote", "add", "origin", url, cwd=d)
            if code != 0:
                return False, "记不住仓库地址：%s" % out[:120], False
        else:
            _git("remote", "set-url", "origin", url, cwd=d)
    _git("add", "-A", cwd=d)
    _git("commit", "-m", message or ("下载页更新 " + time.strftime("%Y-%m-%d %H:%M")), cwd=d)
    code, out = _git("push", "-u", "origin", "main", cwd=d, timeout=300)
    if code != 0:
        code, out = _git("push", "-u", "origin", "master", cwd=d, timeout=300)
    if code != 0:
        return False, ("推送失败（第一次会弹登录窗口，登一次就行）："
                       + out.replace("\n", " ")[:160]), False
    # 顺手打一个 vX.Y 标签推上去：仓库里那条 GitHub Actions 收到标签就会
    # 自己建一个 Release（仓库右边那一栏"Releases"就有东西了），还会把两个
    # 安装包挂上去 —— 不用你点，也不用 token。
    try:
        import version

        tag = "v" + version.APP_VERSION
        _git("tag", "-f", tag, cwd=d)
        _git("push", "-f", "origin", tag, cwd=d, timeout=120)
    except Exception:
        pass
    mark_published()
    return True, ("已经发上去了（这一个大版本含 %d 个小改动）" % max(gap, 1)), True
