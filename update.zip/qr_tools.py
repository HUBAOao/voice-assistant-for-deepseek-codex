# -*- coding: utf-8 -*-
"""把手机入口网址画成二维码（纯本地生成，不联网、不外发）。

手机端 APP 左上角有个「扫码」，照一下这个码就能自动连上电脑，不用手敲 IP 和令牌。
库用的是 `qrcode`（纯 Python，几十 KB）；万一这台机器上没装，这里会返回一句人话，
让界面改成"复制网址"，而不是把报错糊到用户脸上。
"""
from __future__ import annotations

import io
import subprocess
import sys

MIRROR = "https://pypi.tuna.tsinghua.edu.cn/simple"


def available() -> bool:
    """这台机器上能不能画二维码。"""
    try:
        import qrcode  # noqa: F401
        return True
    except Exception:
        return False


def qr_image(text: str, box: int = 8, border: int = 3,
             dark: str = "#101014", light: str = "#ffffff"):
    """画一张二维码（PIL 图）。box 是一个小方格的像素数，越大图越大。"""
    import qrcode

    q = qrcode.QRCode(border=border,
                      error_correction=qrcode.constants.ERROR_CORRECT_M,
                      box_size=max(1, int(box)))
    q.add_data(str(text))
    q.make(fit=True)
    img = q.make_image(fill_color=dark, back_color=light)
    # qrcode 包了一层 PilImage，底下才是真图；两种都兼容一下
    pil = getattr(img, "_img", None)
    if pil is None and hasattr(img, "get_image"):
        pil = img.get_image()
    return (pil or img).convert("RGB")


def qr_png(text: str, **kw) -> bytes:
    buf = io.BytesIO()
    qr_image(text, **kw).save(buf, format="PNG")
    return buf.getvalue()


def install(timeout: int = 180) -> tuple[bool, str]:
    """现装一下 qrcode（正规安装时 requirements.txt 里已经有了，这里只是兜底）。"""
    if available():
        return True, "本来就有"
    for args in (["-i", MIRROR], []):
        try:
            done = subprocess.run([sys.executable, "-m", "pip", "install", "qrcode",
                                   "--quiet", *args],
                                  capture_output=True, timeout=timeout)
        except Exception as exc:               # 断网 / 超时
            return False, f"装不上：{exc}"
        if done.returncode == 0:
            return True, "装好了"
    return False, "装不上（换镜像也没成功），先点「复制」把网址发到手机上也行"
