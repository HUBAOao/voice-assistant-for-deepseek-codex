# -*- coding: utf-8 -*-
"""电脑端"检查更新 / 一键更新"。

数据从**下载页那边**读：电脑上跑着助手时它自己会发一份
    http://127.0.0.1:<端口>/dl/version.json
（跟下载页上写的版本号、包大小、更新日志是同一份东西）。也就是说：
网站那边刷新了，电脑端和手机端的"该更新了"提示就跟着变 —— 不用两边各记一套。

要是你把下载页传到了公网（或者网盘给了直链），在设置里把"更新源"填成那个网址，
电脑就会去那儿读，不在同一个网也能收到更新提示。
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _num(text: str) -> int:
    """版本号只比最后那一段（1.128 → 128），跟页面、手机那边一个规矩。"""
    try:
        return int(str(text).split(".")[-1])
    except Exception:
        return 0


def source_url(cfg: dict | None = None) -> str:
    """更新源。空着就用本机这份下载页（也就是这台电脑上的数据）。"""
    cfg = cfg or {}
    custom = str(cfg.get("update_url") or "").strip()
    if not custom:
        # 也可以只填一个"下载页网址"（公网那个），一样认
        try:
            import site_publish

            custom = site_publish.public_url()
        except Exception:
            custom = ""
    if custom:
        if custom.endswith(".json"):
            return custom
        return custom.rstrip("/") + "/version.json"
    # 万一网站没配/连不上，退回本机这个接口（它报的是同一套版本号），
    # 保证"至少能提示更新"这件事不会因为网络断掉就哑了。
    port = int(cfg.get("phone_port") or 8765)
    return f"http://127.0.0.1:{port}/api/version"


def fetch(url: str, timeout: float = 8.0) -> dict:
    """把更新清单拉回来（拉不到就抛异常，调用方自己兜）。"""
    req = urllib.request.Request(url, headers={"User-Agent": "voice-assistant"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def check(cfg: dict | None = None) -> dict:
    """看看有没有新版。

    返回 {"ok":bool, "src":..., "pc_new":bool, "phone_new":bool,
          "pc":{...}, "phone":{...}, "err":...}
    """
    import version

    url = source_url(cfg)
    out = {"ok": False, "src": url, "pc_new": False, "phone_new": False,
           "pc": {}, "phone": {}, "err": ""}
    try:
        mf = fetch(url)
    except Exception as exc:  # noqa: BLE001
        out["err"] = f"读不到更新信息（{type(exc).__name__}）"
        return out
    pc = mf.get("pc") or {}
    phone = mf.get("phone") or {}
    if isinstance(pc, str):              # 老接口 /api/version 是直接给版本号字符串
        pc = {"version": pc}
    if isinstance(phone, str):
        phone = {"version": phone}
    out["ok"] = bool(mf.get("ok"))
    out["pc"], out["phone"] = pc, phone
    out["updated"] = mf.get("updated", "")
    out["pc_new"] = _num(pc.get("version")) > _num(version.APP_VERSION)
    out["phone_new"] = _num(phone.get("version")) > _num(version.PHONE_VERSION)
    return out


def notes_text(info: dict, count: int = 3) -> str:
    rows = (info or {}).get("notes") or []
    return "\n".join(f"· v{n.get('version')}：{n.get('text')}" for n in rows[:count])


def resolve(src: str, rel: str) -> str:
    """清单里的地址可能是相对的（update.zip），拿更新源拼成完整地址。"""
    rel = str(rel or "")
    if rel.startswith("http://") or rel.startswith("https://"):
        return rel
    base = str(src or "")
    if base.endswith("version.json"):
        base = base[: -len("version.json")]
    if not base.endswith("/"):
        base += "/"
    return base + rel.lstrip("/")


def download(url: str, dest: Path, timeout: float = 120.0) -> tuple[bool, str]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "voice-assistant"})
        with urllib.request.urlopen(req, timeout=timeout) as r, dest.open("wb") as fh:
            shutil.copyfileobj(r, fh, 1 << 16)
        return True, ""
    except Exception as exc:  # noqa: BLE001
        return False, f"{type(exc).__name__}: {exc}"


def apply_update(zip_url: str, install_dir: Path | None = None) -> tuple[bool, str]:
    """一键更新：把更新包下下来、解开，然后跑里面的更新器（它会关掉程序再装回去）。

    这个函数是"发射后不管"：更新器会把当前程序杀掉，所以下载和启动都得在
    独立进程里干，不然我们自己也被杀在半路。
    """
    install_dir = Path(install_dir or HERE)
    tmp = Path(tempfile.mkdtemp(prefix="va-update-"))
    pack = tmp / "update.zip"
    ok, why = download(zip_url, pack)
    if not ok:
        return False, why
    try:
        with zipfile.ZipFile(pack) as z:
            z.extractall(tmp)
    except Exception as exc:  # noqa: BLE001
        return False, f"更新包解不开：{exc}"
    py = None
    for cand in (install_dir / ".venv" / "Scripts" / "pythonw.exe",
                 install_dir / ".venv" / "Scripts" / "python.exe",
                 Path(sys.executable)):
        if Path(cand).exists():
            py = str(cand)
            break
    script = None
    for cand in sorted(tmp.rglob("apply_update.py")):
        script = cand
        break
    if not py or not script:
        return False, "更新包里没找到更新器"
    flags = 0x00000008 | 0x08000000 if sys.platform == "win32" else 0   # DETACHED|NO_WINDOW
    subprocess.Popen([py, str(script), "--yes", "--dir", str(install_dir)],
                     cwd=str(script.parent), creationflags=flags,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     stdin=subprocess.DEVNULL)
    time.sleep(0.3)
    return True, ""
