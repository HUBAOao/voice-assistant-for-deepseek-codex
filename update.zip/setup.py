#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手安装器（用 Python 跑，中文界面更可靠）。

    python setup.py                  # 安装
    python setup.py --model small    # 指定模型
    python setup.py --no-cuda        # 不装显卡加速库
    python setup.py --uninstall      # 卸载
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PYPI = os.environ.get("STT_PIP_MIRROR") or "https://pypi.tuna.tsinghua.edu.cn/simple"
VENV = HERE / ".venv"
VENV_PY = VENV / "Scripts" / "python.exe"
MODELS = {
    "small": "约 480MB，快，日常够用",
    "large-v3-turbo": "约 1.6GB，更准，最好有 NVIDIA 显卡",
}


def setup_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleTitleW("语音助手 - 安装")
        except Exception:
            pass


def title(text: str) -> None:
    print()
    print("=" * 58)
    print(f"  {text}")
    print("=" * 58)


def step(num: int, total: int, text: str) -> None:
    print(f"\n[{num}/{total}] {text}")


def run(cmd: list[str], **kw) -> int:
    print("      > " + " ".join(str(c) for c in cmd[:4]) + (" ..." if len(cmd) > 4 else ""))
    return subprocess.call([str(c) for c in cmd], **kw)


def desktop_dir() -> Path:
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command", "[Environment]::GetFolderPath('Desktop')"],
            capture_output=True, text=True, timeout=30,
        )
        path = out.stdout.strip()
        if path:
            return Path(path)
    except Exception:  # noqa: BLE001
        pass
    return Path.home() / "Desktop"


def make_shortcuts() -> None:
    script = HERE / "make-shortcuts.ps1"
    if script.exists():
        run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script, "-AppDir", HERE])
        return
    print("      （没找到 make-shortcuts.ps1，跳过创建快捷方式）")


def set_autostart(action: str, mode: str = "talk") -> None:
    """开关开机自启（往"启动"文件夹里放一个最小化的快捷方式）。"""
    script = HERE / "autostart.ps1"
    if not script.exists():
        print("      （没找到 autostart.ps1，跳过开机自启）")
        return
    run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script,
         "-AppDir", HERE, "-Action", action, "-Mode", mode])


def has_nvidia() -> bool:
    return shutil.which("nvidia-smi") is not None


def remember_install_path() -> None:
    """记一张"装在这儿"的小纸条，将来更新包靠它自己找上门（不用问用户）。

    放在 %APPDATA%\\VoiceAssistant\\install_path.txt —— 卸载时不需要管它，
    路径不对了更新包会自己忽略。
    """
    try:
        folder = Path(os.environ.get("APPDATA", Path.home())) / "VoiceAssistant"
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "install_path.txt").write_text(str(HERE), encoding="utf-8")
        print(f"      更新包以后靠这个找上门：{folder / 'install_path.txt'}")
    except Exception as exc:  # noqa: BLE001
        print(f"      （位置纸条没写成：{exc}，不影响使用）")


def check_runtime_deps() -> None:
    """装完检查一遍关键库 —— 少了它们会「有语音、没悬浮窗、还没报错」，最难查。"""
    code = ("import importlib.util;mods=['PIL','pystray','numpy','sounddevice',"
            "'faster_whisper','av','edge_tts','pypinyin','tkinter'];"
            "print(' '.join(m + ('=OK' if importlib.util.find_spec(m) else '=缺')"
            " for m in mods))")
    try:
        out = subprocess.run([str(VENV_PY), "-c", code], capture_output=True, text=True,
                             timeout=120)
        got = (out.stdout or "").strip()
    except Exception as exc:  # noqa: BLE001
        print(f"      （依赖检查没跑起来：{exc}）")
        return
    missing = [w.split("=")[0] for w in got.split() if w.endswith("=缺")]
    print(f"      依赖检查：{got}")
    if missing:
        print(f"      [警告] 还缺：{'、'.join(missing)}")
        print("             双击程序目录里的「修复依赖.cmd」可以补装。")
    else:
        print("      依赖齐了，悬浮窗和托盘都能起来。")


def ensure_config(model: str | None) -> None:
    path = HERE / "config.json"
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            data = {}
    data.setdefault("input", "")
    data.setdefault("lang", "zh")
    data.setdefault("wake_word", "大肥鱼")
    data.setdefault("cancel_word", "取消")
    data.setdefault("target", "")
    data.setdefault("voice", "zh-CN-XiaoxiaoNeural")
    data.setdefault("rate", "+8%")
    if model:
        data["model"] = model
    data.setdefault("model", "small")
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"      config.json 的模型 = {data['model']}")


def install(args) -> int:
    title("语音助手 一键安装")
    print(f"  安装位置: {HERE}")
    print("  装完桌面会有两个快捷方式；第一次要下识别模型，")
    print("  中途断了再跑一次本文件就行，会自动续传。")

    step(1, 5, "检查运行环境")
    print(f"      正在用: {sys.executable}")
    if sys.version_info < (3, 10):
        print("      [错误] Python 版本太低，需要 3.10 以上。")
        return 1
    if not VENV_PY.exists():
        print("      创建 .venv ...")
        if run([sys.executable, "-m", "venv", VENV]) != 0:
            print("      [错误] 创建虚拟环境失败")
            return 1
    else:
        print("      已有 .venv，跳过")

    step(2, 5, "安装依赖（第一次约 300MB）")
    run([VENV_PY, "-m", "pip", "install", "--upgrade", "pip", "--quiet", "-i", PYPI])
    req = HERE / "requirements.txt"
    code = run([VENV_PY, "-m", "pip", "install", "-r", req, "-i", PYPI])
    if code != 0:
        print("      镜像失败，换官方源再试一次 ...")
        code = run([VENV_PY, "-m", "pip", "install", "-r", req])
    if code != 0:
        print("      [错误] 依赖安装失败，把上面的报错发给开发者看看。")
        return 1

    step(3, 5, "显卡加速（可选）")
    if args.no_cuda:
        print("      按你的要求跳过")
    elif not has_nvidia():
        print("      没检测到 NVIDIA 显卡，跳过；用 CPU 识别，慢一些但能用")
    else:
        print("      检测到 NVIDIA 显卡，安装加速库（约 1.2GB）")
        print("      不想装的话下次加 --no-cuda")
        if run([VENV_PY, "-m", "pip", "install",
                "nvidia-cublas-cu12", "nvidia-cudnn-cu12", "-i", PYPI]) != 0:
            print("      [提示] 加速库没装上，不影响使用，会自动用 CPU")

    step(4, 5, "下载识别模型")
    model = args.model
    if not model:
        if sys.stdin.isatty():
            print("      选一个（直接回车 = 1）:")
            for i, (name, desc) in enumerate(MODELS.items(), 1):
                print(f"        {i}) {name:<18} {desc}")
            choice = input("      输入序号后回车: ").strip()
            model = list(MODELS)[1] if choice == "2" else list(MODELS)[0]
        else:
            model = "small"
    print(f"      下载: {model}（可断点续传）")
    if run([VENV_PY, HERE / "fetch_model.py", model]) != 0:
        print("      [提示] 模型没下完，联网后重新运行本安装器会自动续传。")

    step(5, 5, "创建快捷方式、写入配置")
    make_shortcuts()
    ensure_config(model)
    remember_install_path()
    check_runtime_deps()
    if args.no_autostart:
        set_autostart("off")
    else:
        print("      设置开机自启（登录后自动在后台待命，最小化窗口）")
        set_autostart("on")

    title("装好了！")
    print("  桌面「语音助手」       双击 → 选「对话模式」：先说唤醒词，再说要问的")
    print("  桌面「卸载语音助手」   不想用了双击它")
    print()
    print("  改设置：记事本打开本目录的 config.json")
    print("          （麦克风 / 唤醒词 / 发音人 / 发到哪个窗口）")
    print("  详细说明：同目录的 说明书.html 和 使用说明.txt")
    # 署名信息只在程序设置里的「关于」按钮里显示，装完这里不再打印
    return 0


def uninstall(args) -> int:
    # 真正的卸载逻辑在 uninstall.py 里（会停掉后台进程、取消开机自启、清快捷方式）
    helper = HERE / "uninstall.py"
    if helper.exists():
        cmd = [sys.executable, str(helper), "--yes"]
        if getattr(args, "full", False):
            cmd.append("--full")
        return subprocess.call([str(c) for c in cmd], cwd=str(HERE))

    title("语音助手 卸载")
    print("  会删掉: .venv（运行环境）、models（模型）、桌面快捷方式")
    print("  会保留: 程序文件、你的识别记录 transcripts.md")
    if not args.yes:
        ans = input("\n  确定卸载吗? 输入 y 回车: ").strip().lower()
        if ans != "y":
            print("  已取消。")
            return 0

    subprocess.run(["taskkill", "/f", "/im", "python.exe"], capture_output=True)
    for folder in (VENV, HERE / "models", HERE / "__pycache__"):
        if folder.exists():
            print(f"      删除 {folder.name} ...")
            shutil.rmtree(folder, ignore_errors=True)
    for name in ("last.txt", "install.log"):
        target = HERE / name
        if target.exists():
            target.unlink()
    desktop = desktop_dir()
    for name in ("语音助手", "语音助手-对话模式"):
        lnk = desktop / f"{name}.lnk"
        if lnk.exists():
            print(f"      删除快捷方式 {lnk.name}")
            lnk.unlink()
    print("\n  卸载完成。识别记录 transcripts.md 保留着，要删自己删。")
    return 0


def main() -> int:
    setup_console()
    ap = argparse.ArgumentParser(description="语音助手安装器")
    ap.add_argument("--model", choices=list(MODELS), help="要下载的识别模型")
    ap.add_argument("--no-cuda", action="store_true", help="不安装显卡加速库")
    ap.add_argument("--no-autostart", action="store_true", help="不设置开机自启")
    ap.add_argument("--uninstall", action="store_true", help="卸载")
    ap.add_argument("--yes", action="store_true", help="卸载时不再确认")
    ap.add_argument("--full", action="store_true", help="卸载时连程序文件和记录一起删")
    args = ap.parse_args()
    if os.environ.get("STT_SETUP_SKIP_CUDA"):
        args.no_cuda = True
    if os.environ.get("STT_SETUP_MODEL") in MODELS:
        args.model = os.environ["STT_SETUP_MODEL"]
    return uninstall(args) if args.uninstall else install(args)


if __name__ == "__main__":
    raise SystemExit(main())
