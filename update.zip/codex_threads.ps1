# Read / switch the Codex desktop app's conversation list through UI Automation.
# ASCII only: PowerShell 5.1 reads .ps1 files as ANSI.
#
#   -Action list                 -> print "NAME<TAB>1|0" lines (1 = currently open)
#   -Action open -Name "xxx"     -> click that conversation in the sidebar
#   -Action open -Name "xxx" -DryRun  -> only report the rect we would click
param(
    [string]$Action = "list",
    [string]$Name = "",
    [string]$NameFile = "",
    [string]$OutFile = "",
    [switch]$DryRun
)

# 中文进出都走 UTF-8：PowerShell 默认按控制台代码页（GBK）读写，
# 会话名一过参数/输出就变乱码。名字从文件读，输出强制 UTF-8。
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
$OutputEncoding = [Console]::OutputEncoding
if ($NameFile -and (Test-Path $NameFile)) {
    $Name = (Get-Content -Raw -Encoding UTF8 $NameFile).Trim()
}

# 结果统一收集起来，最后用 UTF-8 写文件 —— 中文经 stdout 会被按 GBK 弄成乱码，
# 而"写 UTF-8 文件再读"是稳的。
$script:lines = New-Object System.Collections.ArrayList
function Say([string]$text) {
    [void]$script:lines.Add($text)
    Write-Output $text
    if ($OutFile) {
        $script:lines | Out-File -FilePath $OutFile -Encoding UTF8
    }
}

Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
$auto = [System.Windows.Automation.AutomationElement]
$scopeKids = [System.Windows.Automation.TreeScope]::Children
$scopeAll = [System.Windows.Automation.TreeScope]::Descendants
$true2 = [System.Windows.Automation.Condition]::TrueCondition

$root = $auto::RootElement
$cond = New-Object System.Windows.Automation.PropertyCondition($auto::NameProperty, "ChatGPT")
$win = $root.FindFirst($scopeKids, $cond)
if ($null -eq $win) { Say "NO_WINDOW"; exit 1 }
$wr = $win.Current.BoundingRectangle

# the currently open conversation shows up as the window's Document element
$docCond = New-Object System.Windows.Automation.PropertyCondition(
    $auto::ControlTypeProperty, [System.Windows.Automation.ControlType]::Document)
$doc = $win.FindFirst($scopeAll, $docCond)
$current = ""
if ($doc) { $current = $doc.Current.Name }

$listCond = New-Object System.Windows.Automation.PropertyCondition(
    $auto::ControlTypeProperty, [System.Windows.Automation.ControlType]::ListItem)
$items = $win.FindAll($scopeAll, $listCond)

foreach ($e in $items) {
    $n = $e.Current.Name
    if (-not $n) { continue }
    $r = $e.Current.BoundingRectangle
    # sidebar rows: inside the window, in the left quarter, row height like a list item
    if ($r.Width -lt 120 -or $r.Width -gt 600) { continue }
    if ($r.Height -lt 24 -or $r.Height -gt 90) { continue }
    if ($r.X -lt ($wr.X - 2) -or $r.X -gt ($wr.X + $wr.Width * 0.30)) { continue }
    if ($r.Y -lt ($wr.Y - 2) -or ($r.Y + $r.Height) -gt ($wr.Y + $wr.Height)) { continue }
    if ($Action -eq "list") {
        $mark = "0"
        if ($current -and $n.Trim() -eq $current.Trim()) { $mark = "1" }
        Say ($n + "`t" + $mark)
    } elseif ($Action -eq "open") {
        if ($n.Trim() -eq $Name.Trim()) {
            $cx = [int]($r.X + $r.Width / 2)
            $cy = [int]($r.Y + $r.Height / 2)
            if ($DryRun) { Say ("WOULD_CLICK " + $cx + "," + $cy); exit 0 }
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($cx, $cy)
            Start-Sleep -Milliseconds 120
            Add-Type @"
using System;
using System.Runtime.InteropServices;
public class M {
  [DllImport("user32.dll")] public static extern void mouse_event(int f, int dx, int dy, int d, int e);
}
"@
            [M]::mouse_event(0x0002, 0, 0, 0, 0)     # left down
            Start-Sleep -Milliseconds 60
            [M]::mouse_event(0x0004, 0, 0, 0, 0)     # left up
            Say ("CLICKED " + $cx + "," + $cy)
            exit 0
        }
    }
}
if ($Action -eq "open") { Say "NOT_FOUND" }
