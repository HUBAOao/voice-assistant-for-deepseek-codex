#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""悬浮窗里的日程面板（课程表式交互，全部在悬浮窗内完成）。

交互：
  · 月历上**点某一天** → 那块日历就地放大成**当天的时间表**（按小时排的时间轴）
  · 时间表里**点空白处** → 缩回月历
  · 底部是**模块抽屉**：点标题展开，抽屉里的模块**只能用拖动**放到时间表的某个时段
  · 模块分两类：🔔 提醒（到点只语音提醒）和 ➤ 指令（到点把内容发给 Codex）
"""

from __future__ import annotations

import calendar
from datetime import date, datetime

import sched

BG = "#1d1d23"
CARD = "#24242c"
CARD_SEL = "#2a4a3a"
FG = "#ffffff"
DIM = "#9a9aa5"
ROW = "#20202a"
ROW_HOVER = "#2b3a44"
REMIND = "#c79a3a"      # 提醒模块的底色
COMMAND = "#2f7f5a"     # 指令模块的底色
HOUR_H = 27
ANIM_STEPS = 10          # 抽屉/切页动画的帧数（按性能模式调整）


class SchedulePanel:
    def __init__(self, tk, parent, cfg: dict, on_change, button_color="#2f7f5a",
                 accent="#3ddc84") -> None:
        self.tk = tk
        self.parent = parent
        self.on_change = on_change
        self.button_color = button_color
        self.accent = accent
        self.entries = [sched.normalize(e) for e in (cfg.get("schedules") or [])
                        if isinstance(e, dict)]
        self.modules = self._load_modules(cfg)
        self.modules_open = False
        today = date.today()
        self.year, self.month = today.year, today.month
        self.selected = today
        self.view = "calendar"      # calendar | day | table
        self.kind = "command"       # 新建模块的类型
        self.dragging = None
        self._drag_label = None
        # 性能模式：eco 关掉所有界面动画，quality 帧率拉满
        self.perf = str(cfg.get("perf_mode") or "standard")
        self.fps = max(15, min(60, int(cfg.get("anim_fps") or 60)))
        self._build()

    @staticmethod
    def _load_modules(cfg: dict) -> list[dict]:
        raw = cfg.get("schedule_modules") or []
        out = []
        for item in raw:
            if isinstance(item, dict) and str(item.get("text") or "").strip():
                out.append({"text": str(item["text"]).strip(),
                            "kind": "remind" if item.get("kind") == "remind" else "command"})
            elif isinstance(item, str) and item.strip():      # 兼容老格式
                out.append({"text": item.strip(), "kind": "command"})
        return out

    def module_texts(self) -> list[str]:
        return [m["text"] for m in self.modules]

    # ------------------------------------------------------------------ 骨架
    def _build(self) -> None:
        tk = self.tk
        bar = tk.Frame(self.parent, bg=BG)
        bar.pack(fill="x", padx=10, pady=(4, 2))
        self.view_chips = {}
        for value, label in (("calendar", "日历"), ("table", "表格")):
            chip = tk.Label(bar, text=label, bg=CARD, fg=FG, padx=12, pady=3, cursor="hand2",
                            font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=3)
            chip.bind("<Button-1>", lambda _e, v=value: self.set_view(v))
            self.view_chips[value] = chip
        tk.Label(bar, text="点某天放大成时间表 · 点空白缩回", bg=BG, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="right", padx=6)

        self.calendar_frame = tk.Frame(self.parent, bg=BG)
        self.day_frame = tk.Frame(self.parent, bg=BG)
        self.table_frame = tk.Frame(self.parent, bg=BG)
        self._build_calendar(self.calendar_frame)
        self._build_day(self.day_frame)
        self._build_table(self.table_frame)
        self._build_drawer(self.parent)
        self.set_view("calendar")

    # ------------------------------------------------------------------ 月历
    def _build_calendar(self, parent) -> None:
        tk = self.tk
        head = tk.Frame(parent, bg=BG)
        head.pack(fill="x", padx=10, pady=(2, 0))
        self.month_label = tk.Label(head, text="", bg=BG, fg=FG,
                                    font=("Microsoft YaHei UI", 11, "bold"))
        self.month_label.pack(side="left")
        for text, step in (("›", 1), ("‹", -1)):
            chip = tk.Label(head, text=text, bg=CARD, fg=FG, padx=12, pady=2, cursor="hand2",
                            font=("Microsoft YaHei UI", 11))
            chip.pack(side="right", padx=2)
            chip.bind("<Button-1>", lambda _e, s=step: self.shift_month(s))
        grid = tk.Frame(parent, bg=BG)
        grid.pack(fill="both", expand=True, padx=10, pady=(4, 2))
        for i, name in enumerate("一二三四五六日"):
            tk.Label(grid, text=name, bg=BG, fg=DIM, font=("Microsoft YaHei UI", 9)).grid(
                row=0, column=i, padx=2, pady=(0, 2), sticky="nsew")
        for i in range(7):
            grid.grid_columnconfigure(i, weight=1, uniform="day")
        for r in range(1, 7):
            grid.grid_rowconfigure(r, weight=1, uniform="week")
        self.grid = grid
        for r in range(1, 7):
            for c in range(7):
                cell = tk.Label(grid, text="", bg=CARD, fg=FG, cursor="hand2",
                                font=("Microsoft YaHei UI", 11), height=2)
                cell.grid(row=r, column=c, padx=2, pady=2, sticky="nsew")
                cell.bind("<Button-1>", lambda _e, w=cell: self.open_day(w))
                cell.bind("<ButtonRelease-1>", lambda _e, w=cell: self.drop_on_day(w))

    def refresh_calendar(self) -> None:
        self.month_label.config(text=f"{self.year} 年 {self.month} 月")
        first = date(self.year, self.month, 1)
        total = calendar.monthrange(self.year, self.month)[1]
        start = first.weekday()
        today = date.today()
        for r in range(1, 7):
            for c in range(7):
                cell = self.grid.grid_slaves(row=r, column=c)[0]
                cell.config(text="", bg=CARD, fg=FG, highlightthickness=0)
                if hasattr(cell, "_date"):
                    del cell._date
        for day in range(1, total + 1):
            idx = start + day - 1
            r, c = idx // 7 + 1, idx % 7
            if r > 6:
                break
            cell = self.grid.grid_slaves(row=r, column=c)[0]
            current = date(self.year, self.month, day)
            cell.config(text=str(day),
                        bg=CARD_SEL if current == self.selected else CARD)
            if current == today:
                cell.config(highlightthickness=2, highlightbackground=self.accent,
                            highlightcolor=self.accent)
            cell._date = current

    def shift_month(self, step: int) -> None:
        month = self.month + step
        self.year += (month - 1) // 12
        self.month = (month - 1) % 12 + 1
        self.refresh_calendar()

    def open_day(self, cell) -> None:
        current = getattr(cell, "_date", None)
        if current is None:
            return
        self.selected = current
        self.set_view("day")

    def drop_on_day(self, cell) -> None:
        """把模块拖到日历某一天：加一条「单次」条目。"""
        module = self.dragging
        self._clear_drag()
        if not module:
            return
        current = getattr(cell, "_date", None)
        if current is None:
            return
        self.selected = current
        self.add_entry(module, "09:00", kind="once", day=current)

    # ------------------------------------------------------------------ 当天时间表
    def _build_day(self, parent) -> None:
        tk = self.tk
        head = tk.Frame(parent, bg=BG)
        head.pack(fill="x", padx=10, pady=(2, 2))
        back = tk.Label(head, text="‹ 返回日历", bg=CARD, fg=FG, padx=10, pady=3, cursor="hand2",
                        font=("Microsoft YaHei UI", 9))
        back.pack(side="left")
        back.bind("<Button-1>", lambda _e: self.set_view("calendar"))
        self.day_label = tk.Label(head, text="", bg=BG, fg=FG,
                                  font=("Microsoft YaHei UI", 11, "bold"))
        self.day_label.pack(side="left", padx=10)
        tk.Label(head, text="把下面的模块拖到某个时段", bg=BG, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="right", padx=6)
        # 点这块空白 = 缩回月历
        for widget in (parent, head):
            widget.bind("<Button-1>", lambda _e: self.set_view("calendar"))

        body = tk.Frame(parent, bg=BG)
        body.pack(fill="both", expand=True, padx=10, pady=(2, 4))
        self.hour_canvas = tk.Canvas(body, bg=BG, highlightthickness=0)
        self.hour_scroll = tk.Scrollbar(body, orient="vertical", command=self.hour_canvas.yview)
        self.hour_list = tk.Frame(self.hour_canvas, bg=BG)
        self.hour_canvas.create_window((0, 0), window=self.hour_list, anchor="nw", width=396)
        self.hour_canvas.configure(yscrollcommand=self.hour_scroll.set)
        self.hour_canvas.pack(side="left", fill="both", expand=True)
        self.hour_scroll.pack(side="right", fill="y")
        self.hour_list.bind("<Configure>",
                            lambda _e: self.hour_canvas.configure(
                                scrollregion=self.hour_canvas.bbox("all")))

    def refresh_day(self) -> None:
        tk = self.tk
        for child in self.hour_list.winfo_children():
            child.destroy()
        weekday = "一二三四五六日"[self.selected.weekday()]
        self.day_label.config(text=f"{self.selected.month} 月 {self.selected.day} 日 · 周{weekday}")
        items = sched.entries_for_day(self.entries, self.selected)
        hours = sorted({int(str(i.get("time") or "09:00").split(":")[0]) for _n, i in items})
        start_hour = min([6] + hours)
        end_hour = max([22] + hours)
        by_hour: dict[int, list[tuple[int, dict]]] = {}
        for index, item in items:
            try:
                hour = int(str(item.get("time") or "09:00").split(":")[0])
            except Exception:
                hour = 9
            by_hour.setdefault(hour, []).append((index, item))

        for hour in range(start_hour, end_hour + 1):
            row = tk.Frame(self.hour_list, bg=ROW, height=HOUR_H)
            row.pack(fill="x", pady=1)
            row.pack_propagate(False)
            row._hour = hour                                   # 拖动落点
            tk.Label(row, text=f"{hour:02d}:00", bg=ROW, fg=DIM, width=6,
                     font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(6, 4))
            lane = tk.Frame(row, bg=ROW)
            lane.pack(side="left", fill="both", expand=True)
            lane._hour = hour
            row.bind("<Button-1>", lambda _e: None)
            for _index, item in by_hour.get(hour, []):
                self._draw_entry(lane, item)
            for widget in (row, lane):
                widget.bind("<Enter>", lambda _e, w=row: w.config(bg=ROW_HOVER))
                widget.bind("<Leave>", lambda _e, w=row: w.config(bg=ROW))

    def _draw_entry(self, lane, item: dict) -> None:
        tk = self.tk
        is_remind = item.get("kind_module") == "remind"
        color = REMIND if is_remind else COMMAND
        block = tk.Frame(lane, bg=color)
        block.pack(side="left", padx=3, pady=3)
        tk.Label(block, text=("🔔 " if is_remind else "➤ ") + str(item.get("time") or ""),
                 bg=color, fg="#ffffff", font=("Microsoft YaHei UI", 9, "bold")).pack(
            side="left", padx=(6, 2), pady=2)
        tk.Label(block, text=str(item.get("text") or ""), bg=color, fg="#ffffff",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=2, pady=2)
        close = tk.Label(block, text="✕", bg=color, fg="#ffffff", padx=6, cursor="hand2",
                         font=("Microsoft YaHei UI", 9))
        close.pack(side="left")
        # 按"同一条"删除：时间+内容+类型都对得上就删（副本也能正确匹配）
        close.bind("<Button-1>", lambda _e, it=item: self.remove_entry(it))

    def add_entry(self, module: dict, time_text: str, kind: str = "once",
                  day: date | None = None) -> None:
        day = day or self.selected
        entry = {"time": time_text, "text": module["text"], "enabled": True,
                 "kind_module": module.get("kind", "command")}
        if kind == "daily":
            entry["kind"] = "daily"
        elif kind == "weekly":
            entry["kind"] = "weekly"
            entry["weekdays"] = [day.weekday()]
        elif kind == "monthly":
            entry["kind"] = "monthly"
            entry["monthday"] = day.day
        else:
            entry["kind"] = "once"
            entry["date"] = day.strftime("%Y-%m-%d")
        self.entries.append(entry)
        self.refresh_calendar()
        self.refresh_day()
        self.on_change()

    def remove_entry(self, item: dict) -> None:
        for i, entry in enumerate(self.entries):
            if (entry is item
                    or (str(entry.get("text")) == str(item.get("text"))
                        and str(entry.get("time")) == str(item.get("time"))
                        and str(entry.get("kind")) == str(item.get("kind")))):
                self.entries.pop(i)
                break
        self.refresh_calendar()
        self.refresh_day()
        self.on_change()

    # ------------------------------------------------------------------ 模块抽屉
    def _build_drawer(self, parent) -> None:
        tk = self.tk
        wrap = tk.Frame(parent, bg=BG)
        wrap.pack(fill="x", side="bottom", padx=10, pady=(0, 6))
        self.drawer_wrap = wrap
        self.drawer_head = tk.Frame(wrap, bg=BG)
        self.drawer_head.pack(fill="x")
        self.drawer_title = tk.Label(self.drawer_head, text="", bg=CARD, fg=FG, padx=12, pady=4,
                                     cursor="hand2", font=("Microsoft YaHei UI", 9, "bold"))
        self.drawer_title.pack(side="left")
        self.drawer_title.bind("<Button-1>", lambda _e: self.toggle_drawer())
        tk.Label(self.drawer_head, text="按住模块拖到时间表", bg=BG, fg=DIM,
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=(10, 3))
        new = tk.Label(self.drawer_head, text="＋ 新建模块", bg=CARD, fg=FG, padx=10, pady=3,
                       cursor="hand2", font=("Microsoft YaHei UI", 8))
        new.pack(side="right", padx=2)
        new.bind("<Button-1>", lambda _e: self.toggle_editor())

        # 新建模块的就地编辑区（不另开窗口）
        self.editor = tk.Frame(wrap, bg=BG)
        tk.Label(self.editor, text="模块内容（可多写几句要求）", bg=BG, fg=DIM,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(4, 1))
        self.editor_text = tk.Text(self.editor, height=2, bg=CARD, fg=FG, relief="flat",
                                   insertbackground=FG, wrap="word",
                                   font=("Microsoft YaHei UI", 9))
        self.editor_text.pack(fill="x")
        bar = tk.Frame(self.editor, bg=BG)
        bar.pack(fill="x", pady=(3, 0))
        self.editor_kind = "command"
        self.kind_chips = {}
        for value, label in (("command", "➤ 指令"), ("remind", "🔔 提醒")):
            chip = tk.Label(bar, text=label, bg=CARD, fg=FG, padx=10, pady=3, cursor="hand2",
                            font=("Microsoft YaHei UI", 8))
            chip.pack(side="left", padx=2)
            chip.bind("<Button-1>", lambda _e, v=value: self.set_module_kind(v))
            self.kind_chips[value] = chip
        self.set_module_kind("command")
        save = tk.Label(bar, text="保存模块", bg=self.button_color, fg="#ffffff", padx=12, pady=4,
                        cursor="hand2", font=("Microsoft YaHei UI", 8, "bold"))
        save.pack(side="right", padx=2)
        save.bind("<Button-1>", lambda _e: self.save_editor())
        cancel = tk.Label(bar, text="收起", bg=CARD, fg=FG, padx=10, pady=4, cursor="hand2",
                          font=("Microsoft YaHei UI", 8))
        cancel.pack(side="right", padx=4)
        cancel.bind("<Button-1>", lambda _e: self.toggle_editor(open_it=False))
        self.editor_open = False

        self.drawer_body = tk.Frame(wrap, bg=BG)
        self.toggle_drawer(open_it=True)

    def toggle_editor(self, open_it: bool | None = None) -> None:
        """就地展开/收起模块编辑区（带高度动画）。"""
        self.editor_open = (not self.editor_open) if open_it is None else bool(open_it)
        if self.editor_open:
            self.editor.pack(fill="x")
            self.editor.pack_propagate(True)
            natural = max(70, self.editor.winfo_reqheight())
            self.editor.pack_propagate(False)
            start = max(0, self.editor.winfo_height())
            self._tween(lambda t: self.editor.configure(
                height=max(1, int(start + (natural - start) * t))))
            self.editor_text.focus_set()
        else:
            current = max(1, self.editor.winfo_height())
            self._tween(lambda t: self.editor.configure(height=max(1, int(current * (1 - t)))),
                        done=self.editor.pack_forget)

    def save_editor(self) -> None:
        text = self.editor_text.get("1.0", "end").strip()
        if text and not any(m["text"] == text and m["kind"] == self.editor_kind
                            for m in self.modules):
            self.modules.append({"text": text, "kind": self.editor_kind})
            self.editor_text.delete("1.0", "end")
            self.toggle_drawer(open_it=True)
            self.on_change()
        self.toggle_editor(open_it=False)

    def new_module_dialog(self) -> None:
        """新建模块：单独一个窗口，写名称、选类型。"""
        tk = self.tk
        win = tk.Toplevel(self.parent)
        win.title("新建模块")
        win.configure(bg=BG)
        win.geometry("470x270")
        win.attributes("-topmost", True)
        tk.Label(win, text="新建模块", bg=BG, fg=FG,
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(win, text="内容（拖到时间表后就显示这句，也可以直接写要求）", bg=BG, fg=DIM,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=14)
        box = tk.Text(win, height=4, bg=CARD, fg=FG, insertbackground=FG, relief="flat",
                      wrap="word", font=("Microsoft YaHei UI", 10))
        box.pack(fill="both", expand=True, padx=14, pady=(2, 6))
        bar = tk.Frame(win, bg=BG)
        bar.pack(fill="x", padx=14, pady=(0, 12))
        state = {"kind": self.kind}
        chips = {}

        def set_kind(value: str) -> None:
            state["kind"] = value
            for key, chip in chips.items():
                chip.config(bg=COMMAND if key == "command" else REMIND,
                            fg="#ffffff" if key == value else "#cfcfd8")

        tk.Label(bar, text="类型", bg=BG, fg=DIM,
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(0, 4))
        for value, label in (("command", "➤ 指令"), ("remind", "🔔 提醒")):
            chip = tk.Label(bar, text=label, bg=CARD, fg=FG, padx=12, pady=5, cursor="hand2",
                            font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=3)
            chip.bind("<Button-1>", lambda _e, v=value: set_kind(v))
            chips[value] = chip
        set_kind(self.kind)
        tk.Label(bar, text="指令＝到点发给 Codex，提醒＝只语音提醒", bg=BG, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="left", padx=6)

        def confirm() -> None:
            text = box.get("1.0", "end").strip()
            if text:
                if not any(m["text"] == text and m["kind"] == state["kind"]
                           for m in self.modules):
                    self.modules.append({"text": text, "kind": state["kind"]})
                self.set_module_kind(state["kind"])
                self.toggle_drawer(open_it=True)
                self.on_change()
            win.destroy()

        ok = tk.Label(bar, text="保存", bg=self.button_color, fg="#ffffff", padx=20, pady=6,
                      cursor="hand2", font=("Microsoft YaHei UI", 10, "bold"))
        ok.pack(side="right")
        ok.bind("<Button-1>", lambda _e: confirm())
        cancel = tk.Label(bar, text="取消", bg=CARD, fg=FG, padx=16, pady=6, cursor="hand2",
                          font=("Microsoft YaHei UI", 10))
        cancel.pack(side="right", padx=8)
        cancel.bind("<Button-1>", lambda _e: win.destroy())
        try:
            win.lift()
            win.focus_force()
            box.focus_set()
        except Exception:
            pass

    def toggle_drawer(self, open_it: bool | None = None) -> None:
        self.modules_open = (not self.modules_open) if open_it is None else bool(open_it)
        if self.modules_open:
            self.refresh_modules()
        self.drawer_body.pack(fill="x", pady=(4, 0))
        self.drawer_body.pack_propagate(True)
        natural = max(24, self.drawer_body.winfo_reqheight())
        self.drawer_body.pack_propagate(False)
        start = max(0, self.drawer_body.winfo_height())
        end = natural if self.modules_open else 0
        self._animate_height(start, end)
        self.update_drawer_title()

    def _animate_height(self, start: int, end: int) -> None:
        """抽屉高度动画：用 after 驱动，不阻塞界面（阻塞会看起来一顿一顿）。"""
        self._tween(lambda t: self.drawer_body.configure(
            height=max(1, int(start + (end - start) * t))))

    def _tween(self, apply, steps: int | None = None, done=None) -> None:
        """通用缓动：每帧只做一次轻量设置，交给 Tk 事件循环调度。"""
        if self.perf == "eco":
            apply(1.0)
            if done:
                done()
            return
        total = steps or max(6, int(ANIM_STEPS * self.fps / 60))
        delay = max(8, int(1000 / max(15, self.fps)))
        state = {"i": 0}

        def step() -> None:
            state["i"] += 1
            t = 1 - (1 - state["i"] / total) ** 3
            try:
                apply(t)
            except Exception:
                return
            if state["i"] < total:
                self.parent.after(delay, step)
            elif done:
                done()

        step()

    def update_drawer_title(self) -> None:
        arrow = "▾" if self.modules_open else "▸"
        self.drawer_title.config(text=f"{arrow} 模块（{len(self.modules)}）")

    def set_module_kind(self, value: str) -> None:
        self.kind = value
        self.editor_kind = value
        for key, chip in getattr(self, "kind_chips", {}).items():
            chip.config(bg=COMMAND if key == "command" else REMIND,
                        fg="#ffffff" if key == value else "#d0d0d8")

    def remove_module(self, module: dict) -> None:
        self.modules = [m for m in self.modules if m is not module]
        self.refresh_modules()
        self.on_change()

    def refresh_modules(self) -> None:
        for child in self.drawer_body.winfo_children():
            child.destroy()
        self.update_drawer_title()
        if not self.modules:
            self.tk.Label(self.drawer_body, text="还没有模块：点右边「＋ 新建模块」加一个",
                          bg=BG, fg="#6f6f7a", font=("Microsoft YaHei UI", 8)).pack(anchor="w")
            return
        # 每行两个模块，名字不截断（放不下就换行）
        line = None
        for i, module in enumerate(self.modules):
            if i % 2 == 0:
                line = self.tk.Frame(self.drawer_body, bg=BG)
                line.pack(fill="x")
            color = COMMAND if module["kind"] == "command" else REMIND
            cell = self.tk.Frame(line, bg=color)
            cell.pack(side="left", padx=3, pady=2, fill="x", expand=True)
            chip = self.tk.Label(cell, text=module["text"], bg=color, fg="#ffffff",
                                 padx=8, pady=4, cursor="hand2", anchor="w", justify="left",
                                 wraplength=170, font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", fill="x", expand=True)
            chip.bind("<ButtonPress-1>", lambda _e, m=module: self.pick_module(m))
            chip.bind("<B1-Motion>", lambda e, m=module: self.drag_module(e, m))
            chip.bind("<ButtonRelease-1>", lambda _e: self.release_module())
            close = self.tk.Label(cell, text="✕", bg=color, fg="#ffffff", padx=6, cursor="hand2",
                                  font=("Microsoft YaHei UI", 9))
            close.pack(side="right")
            close.bind("<Button-1>", lambda _e, m=module: self.remove_module(m))

    def pick_module(self, module: dict) -> None:
        self.dragging = module

    def drag_module(self, event, module: dict) -> None:
        self.dragging = module
        if self._drag_label is None:
            self._drag_label = self.tk.Toplevel(self.parent)
            self._drag_label.overrideredirect(True)
            self._drag_label.attributes("-topmost", True)
            color = COMMAND if module["kind"] == "command" else REMIND
            self.tk.Label(self._drag_label, text=module["text"][:18], bg=color, fg="#ffffff",
                          padx=10, pady=4, font=("Microsoft YaHei UI", 9)).pack()
        self._drag_label.geometry(f"+{event.x_root + 14}+{event.y_root + 12}")

    def release_module(self) -> None:
        """松手：落在哪个小时行就排到那个时段（只能这样加入）。"""
        module = self.dragging
        self._clear_drag()
        if not module:
            return
        widget = self.parent.winfo_containing(*self.parent.winfo_pointerxy())
        hour = None
        while widget is not None:
            hour = getattr(widget, "_hour", None)
            if hour is not None:
                break
            widget = getattr(widget, "master", None)
        if hour is None:
            return
        self.add_entry(module, f"{int(hour):02d}:00")

    def _clear_drag(self) -> None:
        self.dragging = None
        if self._drag_label is not None:
            self._drag_label.destroy()
            self._drag_label = None

    # ------------------------------------------------------------------ 表格视图
    def _build_table(self, parent) -> None:
        tk = self.tk
        head = tk.Frame(parent, bg=BG)
        head.pack(fill="x", padx=10, pady=(2, 1))
        for text, width in (("时间", 7), ("循环", 10), ("类型", 6), ("内容", 22)):
            tk.Label(head, text=text, bg=BG, fg=DIM, width=width, anchor="w",
                     font=("Microsoft YaHei UI", 8)).pack(side="left", padx=2)
        self.table_rows = tk.Frame(parent, bg=BG)
        self.table_rows.pack(fill="both", expand=True, padx=10)

    def refresh_table(self) -> None:
        for child in self.table_rows.winfo_children():
            child.destroy()
        self.table_vars = []
        for entry in self.entries:
            self.add_table_row(entry)

    def add_table_row(self, entry: dict | None = None) -> None:
        tk = self.tk
        item = sched.normalize(entry or {"time": "09:00", "kind": "daily", "text": ""})
        row = tk.Frame(self.table_rows, bg=BG)
        row.pack(fill="x", pady=1)
        kw = dict(bg=CARD, fg=FG, relief="flat", insertbackground=FG,
                  font=("Microsoft YaHei UI", 9))
        var_t = tk.StringVar(value=str(item.get("time") or "09:00"))
        var_d = tk.StringVar(value=sched.describe(item))
        var_k = tk.StringVar(value="提醒" if item.get("kind_module") == "remind" else "指令")
        var_b = tk.StringVar(value=str(item.get("text") or ""))
        tk.Entry(row, textvariable=var_t, width=7, **kw).pack(side="left", padx=1, ipady=2)
        tk.Entry(row, textvariable=var_d, width=10, **kw).pack(side="left", padx=1, ipady=2)
        tk.Entry(row, textvariable=var_k, width=6, **kw).pack(side="left", padx=1, ipady=2)
        tk.Entry(row, textvariable=var_b, **kw).pack(side="left", fill="x", expand=True,
                                                     padx=1, ipady=2)
        record = {"row": row, "t": var_t, "d": var_d, "k": var_k, "b": var_b}
        self.table_vars.append(record)
        delete = tk.Label(row, text="✕", bg=BG, fg="#ff8080", padx=5, cursor="hand2",
                          font=("Microsoft YaHei UI", 8))
        delete.pack(side="left")
        delete.bind("<Button-1>", lambda _e, r=record: self.remove_table_row(r))
        for var in (var_t, var_d, var_k, var_b):
            var.trace_add("write", lambda *_a: self.sync_table())

    def remove_table_row(self, record: dict) -> None:
        record["row"].destroy()
        self.table_vars = [r for r in self.table_vars if r is not record]
        self.sync_table()

    def sync_table(self) -> None:
        data = []
        for record in getattr(self, "table_vars", []):
            text = record["b"].get().strip()
            if not text:
                continue
            item = {"time": record["t"].get().strip() or "09:00",
                    "days": record["d"].get().strip() or "每天", "text": text, "enabled": True,
                    "kind_module": "remind" if "提醒" in record["k"].get() else "command"}
            data.append(sched.normalize(item))
        self.entries = data
        self.refresh_calendar()
        self.on_change()

    # ------------------------------------------------------------------ 视图切换
    def set_view(self, value: str) -> None:
        self.view = value
        for key, chip in self.view_chips.items():
            chip.config(bg=self.button_color if key == value else CARD)
        if value == "day":
            self.refresh_day()
            self._slide_in(self.day_frame)
            return
        for frame in (self.calendar_frame, self.table_frame):
            frame.pack_forget()
        if value == "table":
            self.table_frame.pack(fill="both", expand=True)
            self.refresh_table()
        else:
            self.calendar_frame.pack(fill="both", expand=True)
            self.refresh_calendar()
        self._slide_out(self.day_frame)

    def _slide_in(self, frame) -> None:
        """当天时间表从右边滑进来（节能模式直接出现）。"""
        width = max(320, self.parent.winfo_width() or 420)
        frame.place(x=width, y=0, relwidth=1, relheight=1)
        frame.lift()

        def apply(t: float) -> None:
            frame.place_configure(x=int(width * (1 - t)))
            if getattr(self, "drawer_wrap", None) is not None:
                self.drawer_wrap.lift()      # 抽屉要一直在最上层

        self._tween(apply)

    def _slide_out(self, frame) -> None:
        if not frame.winfo_ismapped():
            return
        width = max(320, self.parent.winfo_width() or 420)
        self._tween(lambda t: frame.place_configure(x=int(width * t)), done=frame.place_forget)
