#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手 卸载程序。

双击「卸载语音助手.cmd」进来就会弹一个小窗口问你要卸到哪一步；
也可以命令行直接跑：

    python uninstall.py                    # 弹窗口
    python uninstall.py --yes              # 不弹窗：只卸运行环境，保留程序和记录
    python uninstall.py --yes --full       # 不弹窗：连程序文件带记录全删
    python uninstall.py --yes --dry-run    # 只列出来要删什么，不动手
    python uninstall.py --appdir D:\\xxx    # 指定目录（测试用）
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent

# 一定要删的：运行环境、模型、缓存（这些都是装的时候能重下的）
RUNTIME_DIRS = (".venv", "models", "__pycache__")
# 顺手清掉的运行时状态文件
RUNTIME_FILES = (
    "last.txt", "install.log", "status.json", "control.json", "speak.json",
    "speak_stop.json", "heartbeat.json", "manual-exit.json", "wake_test.json",
    "first-run.done", "pet_pos.json", "overlay_pos.json",
    "config.backup-before-levels.json", "show-overlay.log",
)
# 「保留记录」模式下一定要留下的
KEEP = (
    "config.json", "transcripts.md", "said.md", "syslog.md", "diary.md",
    "notes.md", "ledger.json", "achievements.json", "memory.json",
    "voiceprint.json",
)
NO_WINDOW = 0x08000000 if os.name == "nt" else 0
DETACHED = 0x00000008 | NO_WINDOW if os.name == "nt" else 0


def _log(text: str = "") -> None:
    print(text, flush=True)


def powershell(script: str, timeout: int = 90) -> str:
    """跑一段 PowerShell（不闪窗口），返回 stdout。"""
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, creationflags=NO_WINDOW,
        )
        return out.stdout or ""
    except Exception as exc:  # noqa: BLE001
        _log(f"      （powershell 没跑起来：{exc}）")
        return ""


def shell_quote(path: Path) -> str:
    return str(path).replace("'", "''")


# ------------------------------------------------------------------ 进程

def running_processes(app_dir: Path) -> list[int]:
    """找出正在跑的、属于这个目录的 python 进程。

    两个"别误伤"：别人写的 python 不碰；我自己（这个卸载程序）也不能停，
    不然刚开个头就把自己杀了，什么都删不掉。
    """
    d = shell_quote(app_dir)
    me = os.getpid()
    script = (
        f"$d='{d}'; $me={me};"
        "Get-CimInstance Win32_Process | Where-Object { "
        "($_.Name -eq 'python.exe' -or $_.Name -eq 'pythonw.exe') -and "
        "$_.ProcessId -ne $me -and "
        "$_.CommandLine -and $_.CommandLine -like ('*' + $d + '*') -and "
        "$_.CommandLine -notlike '*uninstall.py*' } | "
        "ForEach-Object { $_.ProcessId }"
    )
    return [int(x) for x in powershell(script).split() if x.strip().isdigit()]


def stop_running(app_dir: Path, dry: bool = False) -> int:
    pids = running_processes(app_dir)
    if not pids:
        _log("   没有正在运行的语音助手进程")
        return 0
    _log(f"   停掉 {len(pids)} 个进程：{', '.join(str(p) for p in pids)}")
    if dry:
        return len(pids)
    for pid in pids:
        subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                        f"Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue"],
                       capture_output=True, creationflags=NO_WINDOW)
    time.sleep(1.2)
    return len(pids)


# ------------------------------------------------------------------ 快捷方式

def shortcut_folders() -> list[Path]:
    script = ("[Environment]::GetFolderPath('Desktop');"
              "[Environment]::GetFolderPath('Startup');"
              "[Environment]::GetFolderPath('Programs')")
    out = [line.strip() for line in powershell(script).splitlines() if line.strip()]
    return [Path(p) for p in out if Path(p).is_dir()]


def app_shortcuts(app_dir: Path) -> list[Path]:
    """只找"指向这个目录"的 .lnk，别人的快捷方式一根毛都不碰。"""
    d = shell_quote(app_dir)
    roots = ",".join(f"'{shell_quote(p)}'" for p in shortcut_folders())
    if not roots:
        return []
    script = (
        f"$d='{d}'; $sh=New-Object -ComObject WScript.Shell;"
        f"foreach($p in @({roots})) {{"
        " Get-ChildItem -LiteralPath $p -Filter *.lnk -ErrorAction SilentlyContinue |"
        " ForEach-Object { try { $s=$sh.CreateShortcut($_.FullName);"
        " if ($s.TargetPath -like ('*'+$d+'*') -or $s.Arguments -like ('*'+$d+'*'))"
        " { $_.FullName } } catch {} } }"
    )
    return [Path(line.strip()) for line in powershell(script).splitlines() if line.strip()]


def remove_shortcuts(app_dir: Path, dry: bool = False) -> int:
    links = app_shortcuts(app_dir)
    if not links:
        _log("   没有找到指向本程序的快捷方式")
        return 0
    for lnk in links:
        _log(f"   删快捷方式：{lnk}")
        if not dry:
            try:
                lnk.unlink()
            except Exception as exc:  # noqa: BLE001
                _log(f"      （没删掉：{exc}）")
    return len(links)


# ------------------------------------------------------------------ 删文件

def runtime_targets(app_dir: Path) -> list[Path]:
    """「保留记录」模式要删的东西。"""
    targets = [app_dir / name for name in RUNTIME_DIRS]
    targets += [app_dir / name for name in RUNTIME_FILES]
    targets += sorted(app_dir.glob("*.log"))
    return [p for p in targets if p.exists()]


def size_of(path: Path) -> int:
    if path.is_file():
        try:
            return path.stat().st_size
        except OSError:
            return 0
    total = 0
    for p in path.rglob("*"):
        try:
            if p.is_file():
                total += p.stat().st_size
        except OSError:
            pass
    return total


def human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024.0
    return f"{n:.1f} GB"


def remove_runtime(app_dir: Path, dry: bool = False) -> int:
    removed = 0
    for p in runtime_targets(app_dir):
        if p.name in KEEP:
            continue
        _log(f"   删 {p.relative_to(app_dir)}（{human(size_of(p))}）")
        removed += 1
        if dry:
            continue
        try:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink()
        except Exception as exc:  # noqa: BLE001
            _log(f"      （没删掉：{exc}）")
    return removed


def schedule_full_removal(app_dir: Path) -> Path:
    """把"等我们退出后再把整个目录删掉"写成一个小 cmd，丢到临时目录去跑。

    不能当场删：我们自己的 python.exe 就在这个目录里，Windows 不让删正在跑的文件。
    删之前多试几轮——万一还有个 cmd 窗口开着，等它关掉就能删掉了。
    """
    script = Path(tempfile.gettempdir()) / f"voice-uninstall-{int(time.time())}.cmd"
    script.write_text(
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "set /a tries=0\r\n"
        ":again\r\n"
        "ping -n 3 127.0.0.1 >nul\r\n"
        f'rd /s /q "{app_dir}"\r\n'
        f'if exist "{app_dir}" (\r\n'
        "  set /a tries+=1\r\n"
        "  if %tries% lss 20 goto again\r\n"
        ")\r\n"
        'del /f /q "%~f0" 2>nul\r\n',
        encoding="utf-8")
    subprocess.Popen(["cmd", "/c", str(script)], cwd=str(Path(tempfile.gettempdir())),
                     creationflags=DETACHED, close_fds=True)
    return script


# ------------------------------------------------------------------ 界面

BG, CARD, FG, DIM, ACCENT = "#151519", "#24242c", "#ffffff", "#9a9aa5", "#3ddc84"


def ask(app_dir: Path) -> str:
    """弹个小窗口：返回 keep / full / cancel。"""
    import tkinter as tk

    result = {"mode": "cancel"}
    root = tk.Tk()
    root.title("卸载语音助手")
    root.configure(bg=BG)
    root.resizable(False, False)
    root.geometry("500x480")
    try:
        root.attributes("-topmost", True)
    except Exception:
        pass

    tk.Label(root, text="卸载语音助手", bg=BG, fg=FG,
             font=("Microsoft YaHei UI", 14, "bold")).pack(anchor="w", padx=20, pady=(18, 4))
    tk.Label(root, text=f"程序装在这里：\n{app_dir}", bg=BG, fg=DIM,
             font=("Microsoft YaHei UI", 9), justify="left", wraplength=450).pack(
                 anchor="w", padx=20)

    box = tk.Frame(root, bg=CARD)
    box.pack(fill="x", padx=20, pady=14)
    tk.Label(box, text="不管选哪个，都会顺手做这几件事：", bg=CARD, fg=ACCENT,
             font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", padx=14, pady=(10, 2))
    tk.Label(box, justify="left", anchor="w", bg=CARD, fg=FG,
             font=("Microsoft YaHei UI", 9),
             text="· 关掉正在后台跑的语音助手\n"
                  "· 取消开机自启\n"
                  "· 删掉桌面 / 开始菜单里的快捷方式").pack(anchor="w", padx=14, pady=(0, 10))

    def choose(mode: str) -> None:
        result["mode"] = mode
        root.destroy()

    b1 = tk.Label(root, text="① 卸载（保留我的记录）", bg=ACCENT, fg="#0b2a18",
                  font=("Microsoft YaHei UI", 11, "bold"), pady=10, cursor="hand2")
    b1.pack(fill="x", padx=20)
    b1.bind("<Button-1>", lambda _e: choose("keep"))
    tk.Label(root, text="删掉运行环境、识别模型和日志（省下几个 G）；"
                        "程序文件、设置和聊天记录都留着，以后想用重跑一次 setup.cmd 就行",
             bg=BG, fg=DIM, font=("Microsoft YaHei UI", 8), justify="left",
             wraplength=430).pack(anchor="w", padx=20, pady=(3, 10))

    b2 = tk.Label(root, text="② 彻底删除（连程序和记录一起清掉）", bg=CARD, fg="#ff8080",
                  font=("Microsoft YaHei UI", 11, "bold"), pady=10, cursor="hand2")
    b2.pack(fill="x", padx=20)
    b2.bind("<Button-1>", lambda _e: choose("full"))
    tk.Label(root, text="整个文件夹连里面的聊天记录、日记、记账一起删干净，删完就找不回来了",
             bg=BG, fg=DIM, font=("Microsoft YaHei UI", 8), justify="left",
             wraplength=430).pack(anchor="w", padx=20, pady=(3, 10))

    cancel = tk.Label(root, text="先不卸了", bg=BG, fg=DIM, cursor="hand2",
                      font=("Microsoft YaHei UI", 10))
    cancel.pack(pady=(0, 14))
    cancel.bind("<Button-1>", lambda _e: choose("cancel"))
    root.mainloop()
    return result["mode"]


# ------------------------------------------------------------------ 主流程

def sanity_check(app_dir: Path) -> bool:
    """保险绳：确认这真的是语音助手的目录，别把别的文件夹删了。"""
    marks = ("stt.py", "overlay.py", "version.py")
    found = [m for m in marks if (app_dir / m).exists()]
    if len(found) < 2:
        _log(f"✗ {app_dir} 看着不像语音助手的目录（只有 {found}），为安全起见不动它。")
        return False
    return True


def uninstall(app_dir: Path, full: bool, dry: bool, quiet: bool = False) -> int:
    if not sanity_check(app_dir):
        return 2
    mode = "彻底删除（连记录）" if full else "卸载（保留记录）"
    _log("")
    _log("=" * 54)
    _log(f"  语音助手 卸载 · {mode}" + ("（演练，不动手）" if dry else ""))
    _log("=" * 54)

    _log("\n[1/4] 停掉正在跑的语音助手")
    stop_running(app_dir, dry)

    _log("\n[2/4] 取消开机自启、删快捷方式")
    remove_shortcuts(app_dir, dry)

    _log("\n[3/4] 清掉运行环境")
    if full:
        _log(f"   待会儿整个目录一起删：{app_dir}（{human(size_of(app_dir))}）")
    else:
        remove_runtime(app_dir, dry)

    _log("\n[4/4] 收尾")
    if full:
        if dry:
            _log("   （演练）会在退出后删掉整个目录")
        else:
            script = schedule_full_removal(app_dir)
            _log(f"   已安排：本窗口关掉后自动把整个目录删干净")
            _log(f"   （帮手脚本：{script}）")
    else:
        kept = [name for name in KEEP if (app_dir / name).exists()]
        _log(f"   保留：{', '.join(kept) if kept else '（没有记录文件）'}")
        _log("   想彻底删掉，把整个文件夹拖进回收站就行")

    if not quiet:
        _log("\n" + ("（这只是演练，什么都没删）" if dry else "卸载完成，谢谢用过。"))
    return 0


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description="语音助手卸载程序")
    ap.add_argument("--yes", action="store_true", help="不弹窗、不再确认")
    ap.add_argument("--full", action="store_true", help="连程序文件和记录一起删")
    ap.add_argument("--keep", action="store_true", help="只卸运行环境，保留程序和记录")
    ap.add_argument("--dry-run", action="store_true", help="只列出来要删什么")
    ap.add_argument("--no-gui", action="store_true", help="命令行模式，不弹窗口")
    ap.add_argument("--appdir", default=None, help="要卸载的目录（默认是本文件所在目录）")
    args = ap.parse_args(argv)

    app_dir = Path(args.appdir).resolve() if args.appdir else HERE
    if not args.yes and not args.no_gui:
        try:
            choice = ask(app_dir)
        except Exception as exc:  # noqa: BLE001
            # 图形窗口起不来（比如那台机器的 Python 没带 tkinter）也**不能默默退出**，
            # 那用户就看到"双击了没反应"。改成在命令行里问一句。
            _log(f"（图形界面没起来：{exc}）")
            _log("")
            _log("  改在命令行里问你：")
            _log("    1 = 卸载（保留我的记录）")
            _log("    2 = 彻底删除（连程序和记录一起清掉）")
            _log("    直接回车 = 先不卸")
            try:
                ans = input("  输入 1 或 2 再回车：").strip()
            except Exception:
                ans = ""
            if ans == "1":
                choice = "keep"
            elif ans == "2":
                choice = "full"
            else:
                choice = "cancel"
        if choice == "cancel":
            _log("已取消，什么都没动。")
            return 0
        return uninstall(app_dir, full=(choice == "full"), dry=args.dry_run)
    return uninstall(app_dir, full=args.full and not args.keep, dry=args.dry_run)


if __name__ == "__main__":
    raise SystemExit(main())
