#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""设置界面用的小控件：动画开关、滑杆、颜色块（都做了抗锯齿）。"""

from __future__ import annotations

from PIL import Image, ImageDraw, ImageTk

BG = "#151519"
PANEL = "#1d1d23"
CARD = "#24242c"
FG = "#ffffff"
DIM = "#9a9aa5"
ACCENT = "#3ddc84"
SW_ON = "#2f7f5a"
SW_OFF = "#3a3a44"
SW_KNOB = "#f2f2f6"


def rgb_tuple(color: str) -> tuple[int, int, int]:
    color = color.lstrip("#")
    if len(color) == 3:
        color = "".join(c * 2 for c in color)
    return int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)


class Switch:
    """自绘动画开关：滑块缓动，圆形用 4 倍超采样抗锯齿。"""

    W, H = 46, 24

    def __init__(self, parent, value: bool, on_change=None, bg=CARD):
        import tkinter as tk

        self.tk = tk
        self.on_change = on_change
        self.value = bool(value)
        self.pos = 1.0 if value else 0.0
        self.target = self.pos
        self._cache: dict = {}
        self.canvas = tk.Canvas(parent, width=self.W, height=self.H, bg=bg,
                                highlightthickness=0, cursor="hand2")
        self.item = self.canvas.create_image(self.W / 2, self.H / 2, image=self.sprite(self.pos))
        self.canvas.bind("<Button-1>", lambda _e: self.toggle())
        self._tick()

    def sprite(self, pos: float):
        key = round(pos * 40) / 40
        im = self._cache.get(key)
        if im is None:
            scale = 4
            big = (self.W * scale, self.H * scale)
            pic = Image.new("RGBA", big, (0, 0, 0, 0))
            d = ImageDraw.Draw(pic)
            a, b = rgb_tuple(SW_OFF), rgb_tuple(SW_ON)
            fill = "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * key) for i in range(3))
            d.rounded_rectangle([0, 0, big[0] - 1, big[1] - 1], radius=big[1] // 2, fill=fill)
            pad, r = 3 * scale, (self.H - 6) / 2 * scale
            x0 = pad + (big[0] - 2 * pad - 2 * r) * key
            cy = big[1] / 2
            d.ellipse([x0, cy - r, x0 + 2 * r, cy + r], fill=SW_KNOB)
            im = ImageTk.PhotoImage(pic.resize((self.W, self.H), Image.LANCZOS))
            self._cache[key] = im
        return im

    def _tick(self) -> None:
        if abs(self.target - self.pos) > 0.002:
            self.pos += (self.target - self.pos) * 0.25
            self.canvas.itemconfig(self.item, image=self.sprite(self.pos))
            self._job = self.canvas.after(25, self._tick)
        else:
            # 动画停了就别再挂定时器：一个开关 25ms 醒一次、几十个开关就是几百次
            # 纯属白转的唤醒，还会把 update() 这种"跑到没事干才返回"的调用卡住。
            self.pos = self.target
            self._job = None

    def _wake(self) -> None:
        """要动了才把定时器点起来（toggle / set 都走这儿）。"""
        if getattr(self, "_job", None) is None:
            self._job = self.canvas.after(25, self._tick)

    def toggle(self) -> None:
        self.value = not self.value
        self.target = 1.0 if self.value else 0.0
        self._wake()
        if self.on_change:
            self.on_change(self.value)

    def get(self) -> bool:
        return self.value

    def set(self, value: bool) -> None:
        self.value = bool(value)
        self.target = 1.0 if value else 0.0
        self._wake()


class Slider:
    """一行：标题 + 滑杆 + 数值。"""

    def __init__(self, parent, label, minimum, maximum, value,
                 fmt="{:.0f}", on_change=None, width=10, bg=CARD):
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.on_change = on_change
        self.fmt = fmt
        row = tk.Frame(parent, bg=bg)
        row.pack(fill="x", pady=3)
        tk.Label(row, text=label, bg=bg, fg=FG, width=width, anchor="w",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(10, 4))
        self.value_label = tk.Label(row, text=fmt.format(value), bg=bg, fg=ACCENT, width=5,
                                    font=("Microsoft YaHei UI", 9, "bold"))
        self.value_label.pack(side="right", padx=(4, 10))
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Dark.Horizontal.TScale", background=bg, troughcolor="#33333d",
                        bordercolor=bg, lightcolor=ACCENT, darkcolor=ACCENT)
        self.var = tk.DoubleVar(value=value)
        self.scale = ttk.Scale(row, from_=minimum, to=maximum, variable=self.var,
                               orient="horizontal", style="Dark.Horizontal.TScale",
                               command=self.changed)
        self.scale.pack(side="left", fill="x", expand=True, padx=4)

    def changed(self, _value=None) -> None:
        v = self.var.get()
        self.value_label.config(text=self.fmt.format(v))
        if self.on_change:
            self.on_change(v)

    def get(self) -> float:
        return self.var.get()

    def set(self, value: float) -> None:
        self.var.set(value)
        self.changed()


class SpinRow:
    """一行里放几个"－ 数值 ＋"的小调节器，用来调元素的位置和大小。"""

    def __init__(self, parent, label, items, on_change=None, bg=CARD, label_width=8):
        import tkinter as tk

        self.tk = tk
        self.on_change = on_change
        row = tk.Frame(parent, bg=bg)
        row.pack(fill="x", pady=3)
        tk.Label(row, text=label, bg=bg, fg=FG, width=label_width, anchor="w",
                 font=("Microsoft YaHei UI", 9)).pack(side="left", padx=(10, 4))
        self.vars: dict[str, float] = {}
        self.labels: dict[str, object] = {}
        for key, title, value, step, lo, hi in items:
            cell = tk.Frame(row, bg=bg)
            cell.pack(side="left", padx=(0, 8))
            tk.Label(cell, text=title, bg=bg, fg=DIM, font=("Microsoft YaHei UI", 8)).pack(side="left")
            plus = tk.Label(cell, text="＋", bg=PANEL, fg=FG, font=("Microsoft YaHei UI", 8),
                            padx=4, cursor="hand2")
            plus.pack(side="right")
            minus = tk.Label(cell, text="－", bg=PANEL, fg=FG, font=("Microsoft YaHei UI", 8),
                             padx=4, cursor="hand2")
            minus.pack(side="right", padx=(2, 2))
            show = tk.Label(cell, text=str(int(value)), bg=bg, fg=ACCENT, width=3,
                            font=("Microsoft YaHei UI", 9, "bold"))
            show.pack(side="right", padx=2)
            self.vars[key] = float(value)
            self.labels[key] = show
            plus.bind("<Button-1>", lambda _e, k=key, s=step, a=hi: self.bump(k, s, a))
            minus.bind("<Button-1>", lambda _e, k=key, s=step, a=lo: self.bump(k, -s, a))

    def bump(self, key: str, delta: float, limit: float) -> None:
        self.vars[key] = self.vars[key] + delta
        if delta > 0:
            self.vars[key] = min(self.vars[key], limit)
        else:
            self.vars[key] = max(self.vars[key], limit)
        self.labels[key].config(text=str(int(self.vars[key])))
        if self.on_change:
            self.on_change()

    def get(self) -> dict:
        return dict(self.vars)
