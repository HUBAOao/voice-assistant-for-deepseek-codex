#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把你给的一张图做成语音助手的图标（多尺寸 .ico）。

    python icon_from_image.py 图片路径
    python icon_from_image.py 图片路径 --crop 110,110,470,470     # 左,上,右,下
    python icon_from_image.py 图片路径 --no-round                 # 不做圆角

生成的 voice.ico 会直接替换掉原来的图标（桌面快捷方式本来就指向它）。
同时会在同目录留下 voice-icon-preview.png 方便预览。
"""

from __future__ import annotations

import argparse
import ctypes
import sys
from pathlib import Path

from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent


def build(src: Path, crop: tuple[int, int, int, int] | None, radius_ratio: float,
          out: Path, preview: Path) -> None:
    img = Image.open(src).convert("RGBA")
    w, h = img.size
    if crop:
        x0, y0, x1, y1 = crop
        img = img.crop((max(0, x0), max(0, y0), min(w, x1), min(h, y1)))
    # 裁成正方形（居中）
    w, h = img.size
    side = min(w, h)
    img = img.crop(((w - side) // 2, (h - side) // 2,
                    (w - side) // 2 + side, (h - side) // 2 + side))
    img = img.resize((1024, 1024), Image.LANCZOS)

    if radius_ratio > 0:                      # 圆角
        mask = Image.new("L", (1024, 1024), 0)
        ImageDraw.Draw(mask).rounded_rectangle(
            [0, 0, 1023, 1023], radius=int(1024 * radius_ratio), fill=255)
        img.putalpha(mask)

    img.save(out, sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    img.resize((256, 256), Image.LANCZOS).save(preview)
    img.resize((64, 64), Image.LANCZOS).save(preview.with_name(preview.stem + "-64.png"))


def main() -> int:
    ap = argparse.ArgumentParser(description="把图片做成语音助手图标")
    ap.add_argument("image")
    ap.add_argument("--crop", help="裁剪区域 左,上,右,下（像素）")
    ap.add_argument("--no-round", action="store_true", help="不做圆角")
    ap.add_argument("--out", default=str(HERE / "voice.ico"))
    args = ap.parse_args()

    crop = None
    if args.crop:
        crop = tuple(int(v) for v in args.crop.split(","))  # type: ignore[assignment]
        if len(crop) != 4:
            print("--crop 要写 4 个数字：左,上,右,下")
            return 2
    build(Path(args.image), crop, 0.0 if args.no_round else 0.10,
          Path(args.out), HERE / "voice-icon-preview.png")
    refresh_shell_icons()
    print("图标已更新:", args.out)
    return 0


def refresh_shell_icons() -> None:
    """让资源管理器立刻用上新图标（不然可能还显示缓存的旧图）。"""
    if sys.platform != "win32":
        return
    try:
        SHCNE_ASSOCCHANGED = 0x08000000
        SHCNF_IDLIST = 0x0000
        ctypes.windll.shell32.SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, None, None)
    except Exception:
        pass


if __name__ == "__main__":
    raise SystemExit(main())
