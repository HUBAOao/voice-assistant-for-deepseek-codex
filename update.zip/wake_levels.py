#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""唤醒档位（灵敏度预设）。

主程序（stt.py）和悬浮窗（overlay.py）都读这里，保证两边对同一档位的理解一致。
每档就是一组参数：

  noise_mult  环境噪声的倍数门槛：越大越"耳背"，越不容易被空调/风扇之类的底噪吵醒
  min_voiced  一次开口至少要持续多久（秒）才算一句话：越小越能接住说得快的人
  confirm     连续几块音频够响才认定"开口了"：越大越抗"啪"一声的杂音
  fuzzy       同音字容错：大飞鱼 / 打肥鱼 也算喊的是 大肥鱼
  leading     开头吞字容错：录音头一个字被吞（"飞鱼…"）也算
  hotwords    把唤醒词当热词喂给识别引擎，更容易被按原样写出来
"""

from __future__ import annotations

DEFAULT_LEVEL = "宽松"

LEVELS: dict[str, dict] = {
    # 实测：念一遍"大肥鱼"只有约 0.45～0.5 秒是"够响"的，
    # 所以"最小发声"这一项千万别超过 0.45，否则正常说话会被当噪音丢掉。
    # 实测：拿"环境噪声中位数×6"算门槛会到 0.05 上下（房间有电视），
    # 正常说话的轻声音节够不着，所以倍数整体压下来，改成跟"滚动噪声底"比。
    "严格": {"noise_mult": 4.0, "min_voiced": 0.42, "confirm": 4,
             "fuzzy": True, "leading": False, "hotwords": True},
    "标准": {"noise_mult": 3.2, "min_voiced": 0.36, "confirm": 3,
             "fuzzy": True, "leading": False, "hotwords": True},
    "宽松": {"noise_mult": 2.6, "min_voiced": 0.30, "confirm": 3,
             "fuzzy": True, "leading": True, "hotwords": True},
    "极宽松": {"noise_mult": 2.0, "min_voiced": 0.20, "confirm": 2,
               "fuzzy": True, "leading": True, "hotwords": True},
}

FIELDS = ("noise_mult", "min_voiced", "confirm", "fuzzy", "leading", "hotwords")

# 用户自定义档位的文字格式（在悬浮窗里用一个小编辑框改）
_KEYS = {
    "最小发声": ("min_voiced", float),
    "噪声倍数": ("noise_mult", float),
    "连续块": ("confirm", int),
    "同音字": ("fuzzy", bool),
    "开头吞字": ("leading", bool),
    "热词": ("hotwords", bool),
}


def merged(custom: dict | None) -> dict[str, dict]:
    """内置档位 + 用户自定义档位（自定义的可以覆盖内置同名档位）。"""
    out = {name: dict(p) for name, p in LEVELS.items()}
    if isinstance(custom, dict):
        for name, params in custom.items():
            name = str(name).strip()
            if not name or not isinstance(params, dict):
                continue
            base = dict(LEVELS[DEFAULT_LEVEL])
            for key in FIELDS:
                if key in params:
                    base[key] = params[key]
            out[name] = base
    return out


def params(cfg: dict) -> tuple[str, dict]:
    """返回 (档位名, 该档位的参数)；配置里没写或写错就用默认档。"""
    levels = merged((cfg or {}).get("wake_levels"))
    name = str((cfg or {}).get("wake_level") or DEFAULT_LEVEL)
    if name not in levels:
        name = DEFAULT_LEVEL
    return name, levels[name]


def describe(p: dict) -> str:
    """一行中文说明，给设置界面看。"""
    on = lambda v: "开" if v else "关"          # noqa: E731
    return (f"开口≥{p['min_voiced']:g}秒 · 底噪×{p['noise_mult']:g} · "
            f"连响{p['confirm']}块 · 同音字{on(p['fuzzy'])} · "
            f"吞字{on(p['leading'])} · 热词{on(p['hotwords'])}")


def to_text(name: str, p: dict) -> str:
    """转成编辑框里的文字（方便用户复制着改）。"""
    on = lambda v: "开" if v else "关"          # noqa: E731
    return "\n".join([
        f"名称={name}",
        f"最小发声={p['min_voiced']:g}",
        f"噪声倍数={p['noise_mult']:g}",
        f"连续块={p['confirm']:g}",
        f"同音字={on(p['fuzzy'])}",
        f"开头吞字={on(p['leading'])}",
        f"热词={on(p['hotwords'])}",
    ])


def from_text(text: str) -> tuple[str, dict] | None:
    """解析编辑框里的文字；名称留空或格式不对返回 None。"""
    name = ""
    out: dict = {}
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or "=" not in line and "：" not in line:
            continue
        key, _, value = line.replace("：", "=").partition("=")
        key, value = key.strip(), value.strip()
        if key in ("名称", "名字", "档位名"):
            name = value
            continue
        if key not in _KEYS:
            continue
        field, cast = _KEYS[key]
        try:
            if cast is bool:
                out[field] = value.lower() in ("开", "1", "true", "yes", "是", "on", "y")
            else:
                out[field] = cast(float(value))
        except ValueError:
            continue
    if not name:
        return None
    base = dict(LEVELS[DEFAULT_LEVEL])
    base.update(out)
    return name, base
