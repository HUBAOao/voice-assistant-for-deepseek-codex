﻿param([string]$AppDir)

# 桌面上只放一个入口：点它弹选择框（对话模式 / 转录模式 / 只开悬浮窗）。
# 同时会清掉指向本目录的历史快捷方式（老的三个分开的入口），别人的快捷方式不碰。
$sh = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$pythonw = Join-Path $AppDir '.venv\Scripts\pythonw.exe'
$launcher = Join-Path $AppDir 'launcher.py'

$icon = Join-Path $AppDir 'voice.ico'
if (-not (Test-Path -LiteralPath $icon)) { $icon = "$env:SystemRoot\System32\mmres.dll,5" }

$name = '语音助手'
$lnk = Join-Path $desktop ($name + '.lnk')

# 清理旧的（只删指向本程序目录的）
Get-ChildItem -LiteralPath $desktop -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.FullName -ne $lnk) {
        try {
            $old = $sh.CreateShortcut($_.FullName)
            if ($old.TargetPath -like "$AppDir*" -or $old.Arguments -like "*$AppDir*") {
                Remove-Item -LiteralPath $_.FullName -Force
                Write-Host ('   清理旧快捷方式: ' + $_.Name)
            }
        }
        catch { }
    }
}

$sc = $sh.CreateShortcut($lnk)
$sc.TargetPath = $pythonw
$sc.Arguments = '"' + $launcher + '"'
$sc.WorkingDirectory = $AppDir
$sc.IconLocation = $icon
$sc.Description = '语音助手：点一下选择启动方式（对话 / 转录 / 悬浮窗）'
$sc.WindowStyle = 1
$sc.Save()
Write-Host ('   已创建: ' + $lnk)
Write-Host ('   图标:   ' + $icon)

# 卸载程序也放一个快捷方式（双击就能卸），旧的英文名 uninstall.cmd 也照样能用
$uninstallName = '卸载语音助手'
$uninstallLnk = Join-Path $desktop ($uninstallName + '.lnk')
$uninstallCmd = Join-Path $AppDir '卸载语音助手.cmd'
if (-not (Test-Path -LiteralPath $uninstallCmd)) {
    $uninstallCmd = Join-Path $AppDir 'uninstall.cmd'
}
if (Test-Path -LiteralPath $uninstallCmd) {
    $uc = $sh.CreateShortcut($uninstallLnk)
    $uc.TargetPath = "$env:SystemRoot\System32\cmd.exe"
    $uc.Arguments = '/c "' + $uninstallCmd + '"'
    $uc.WorkingDirectory = $AppDir
    $uc.IconLocation = "$env:SystemRoot\System32\imageres.dll,54"
    $uc.Description = '卸载语音助手（会让你选：保留记录 / 彻底删除）'
    $uc.WindowStyle = 1
    $uc.Save()
    Write-Host ('   已创建: ' + $uninstallLnk)
}
