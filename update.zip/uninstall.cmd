@echo off
rem Alias for the uninstaller. ASCII only (see the note in the other .cmd file).
setlocal EnableExtensions
title Voice Assistant Uninstaller
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

if defined PYTHONIOENCODING goto :skipset
set "PYTHONIOENCODING=utf-8"
:skipset

set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)
if defined PYEXE (
  %PYEXE% "%~dp0uninstall.py" %*
  pause
  exit /b 0
)

echo   [Uninstall] Python not found. Removing .venv and models ...
if exist ".venv" rd /s /q ".venv"
if exist "models" rd /s /q "models"
echo   [Uninstall] Please delete the desktop shortcuts manually.
pause
