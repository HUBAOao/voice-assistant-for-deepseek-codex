# -*- coding: utf-8 -*-
"""Read-only startup health checks for FinDeck."""
from __future__ import annotations

import json
import re
import socket
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))


@dataclass(frozen=True)
class CheckResult:
    name: str
    ok: bool
    detail: str
    severity: str = "error"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def check_path(name: str, path: Path, *, severity: str = "error") -> CheckResult:
    try:
        exists = path.exists()
    except OSError as exc:
        return CheckResult(name, False, f"{path}: {exc}", severity)
    return CheckResult(name, exists, str(path), severity)


def check_tcp(name: str, host: str, port: int, timeout: float = 0.35,
              *, severity: str = "warning") -> CheckResult:
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            pass
    except OSError as exc:
        return CheckResult(name, False, f"{host}:{port} 不可连接：{exc}", severity)
    return CheckResult(name, True, f"{host}:{port}", severity)


def check_codex_cli() -> CheckResult:
    try:
        import codex_threads

        exe = codex_threads.find_codex_exe()
    except Exception as exc:  # noqa: BLE001
        return CheckResult("codex_cli", False, f"无法定位 Codex：{exc}")
    if not exe:
        return CheckResult("codex_cli", False, "未找到 Codex CLI")
    try:
        proc = subprocess.run(
            [exe, "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=8,
            creationflags=0x08000000 if sys.platform == "win32" else 0,
        )
    except Exception as exc:  # noqa: BLE001
        return CheckResult("codex_cli", False, f"{exe}: {exc}")
    text = ((proc.stdout or "") + (proc.stderr or "")).strip()
    if proc.returncode != 0:
        return CheckResult("codex_cli", False, f"{exe}: {text or proc.returncode}")
    return CheckResult("codex_cli", True, text or exe)


def check_codex_compat() -> CheckResult:
    """Verify the installed Codex exposes the app-server API FinDeck uses."""
    try:
        import codex_threads

        probe = codex_threads.probe_app_server()
    except Exception as exc:  # noqa: BLE001
        return CheckResult("codex_compat", False, f"app-server 不可用：{exc}")
    agent = str(probe.get("userAgent") or "").strip()
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", agent)
    if not match:
        return CheckResult(
            "codex_compat",
            False,
            f"app-server 可启动，但读不出兼容版本：{agent or 'unknown'}",
            "warning",
        )
    version = tuple(int(part) for part in match.groups())
    if version < (0, 100, 0):
        return CheckResult(
            "codex_compat",
            False,
            f"Codex {agent} 过旧，需要 0.100.0 或更新版本",
        )
    return CheckResult("codex_compat", True, f"app-server {agent}")


def check_storage() -> CheckResult:
    try:
        import storage_paths

        roots = (storage_paths.DATA_ROOT, storage_paths.F_DATA_ROOT)
        parts = [f"{root}={'ok' if root.exists() else 'missing'}" for root in roots]
    except Exception as exc:  # noqa: BLE001
        return CheckResult("storage", False, str(exc), "warning")
    ok = all((root.exists() for root in roots))
    return CheckResult("storage", ok, "; ".join(parts), "warning")


def check_phone_port(port: int | None = None) -> CheckResult:
    if port is None:
        try:
            config = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
            port = int(config.get("phone_port") or 8765)
        except Exception:
            port = 8765
    return check_tcp("phone_port", "127.0.0.1", int(port))


def check_app_security() -> CheckResult:
    try:
        from features.app_security import SECURITY

        summary = SECURITY.summary()
        detail = (f"{summary.get('algorithm')} · 密钥 {summary.get('key_age_days')} 天"
                  + (" · 建议轮换" if summary.get("rotation_due") else ""))
        return CheckResult("app_security", True, detail,
                           "warning" if summary.get("rotation_due") else "error")
    except Exception as exc:  # noqa: BLE001
        return CheckResult("app_security", False, str(exc))


def collect(base: Path | None = None, *, include_phone: bool = True) -> dict[str, Any]:
    root = Path(base) if base is not None else HERE
    checks = [
        check_path("main_entry", root / "stt.py"),
        check_path("phone_entry", root / "phone_link.py"),
        check_path("phone_page", root / "phone_page.html"),
        check_path("codex_threads", root / "codex_threads.py"),
        check_path("overlay_entry", root / "overlay.py"),
        check_path("phone_security", root / "phone_feature" / "security.py"),
        check_path("security_console", root / "phone_feature" / "security_console.py"),
        check_path("legacy_phone_page", root / "phone_feature" / "legacy_page.html"),
        check_path("overlay_runtime", root / "overlay_feature" / "runtime.py"),
        check_path("overlay_defaults", root / "overlay_feature" / "defaults.py"),
        check_path("overlay_visuals", root / "overlay_feature" / "visuals.py"),
        check_path("overlay_dialogs", root / "overlay_feature" / "dialogs.py"),
        check_path("overlay_presets", root / "overlay_feature" / "presets_mixin.py"),
        check_path("overlay_schedule", root / "overlay_feature" / "schedule_mixin.py"),
        check_path("overlay_settings", root / "overlay_feature" / "settings_mixin.py"),
        check_path("overlay_settings_content",
                   root / "overlay_feature" / "settings_content_mixin.py"),
        check_path("overlay_settings_pages",
                   root / "overlay_feature" / "settings_pages_mixin.py"),
        check_path("voice_parsers", root / "voice_feature" / "parsing.py"),
        check_path("voice_action_dispatch",
                   root / "voice_feature" / "action_dispatch.py"),
        check_path("voice_local_commands",
                   root / "voice_feature" / "local_commands.py"),
        check_path("voice_feature_commands",
                   root / "voice_feature" / "feature_commands.py"),
        check_path("voice_maintenance_commands",
                   root / "voice_feature" / "maintenance_commands.py"),
        check_path("voice_tutorial_commands",
                   root / "voice_feature" / "tutorial_commands.py"),
        check_path("voice_capture", root / "voice_feature" / "capture.py"),
        check_path("voice_transcriber", root / "voice_feature" / "transcriber.py"),
        check_path("audio_io", root / "voice_feature" / "audio_io.py"),
        check_path("task_center", root / "features" / "tasks.py"),
        check_path("duplex_voice", root / "features" / "duplex.py"),
        check_path("codex_control", root / "features" / "codex_control.py"),
        check_path("app_security_entry", root / "features" / "app_security.py"),
        check_path("reference_audio_echo", root / "features" / "voice_echo.py"),
        check_path("agent_operations", root / "features" / "agent_workers.py"),
        check_path("plugin_registry", root / "features" / "plugin_registry.py"),
        check_path("plugin_signing", root / "features" / "plugin_signing.py"),
        check_path("plugin_market", root / "features" / "plugin_market.py"),
        check_path("plugin_publisher_tool", root / "plugin_publisher.py"),
        check_path("device_acceptance", root / "phone_feature" / "device_acceptance.py"),
        check_path("phone_media_routes", root / "phone_feature" / "media_routes.py"),
        check_path("phone_basic_routes",
                   root / "phone_feature" / "basic_routes.py"),
        check_path("phone_session_schedule_routes",
                   root / "phone_feature" / "session_schedule_routes.py"),
        check_path("phone_history_routes",
                   root / "phone_feature" / "history_routes.py"),
        check_path("phone_ui_core", root / "phone_feature" / "ui" / "page_core.js"),
        check_path("phone_ui_runtime",
                   root / "phone_feature" / "ui" / "page_runtime.js"),
        check_path("phone_ui_tools", root / "phone_feature" / "ui" / "page_tools.js"),
        check_path("phone_ui_bootstrap",
                   root / "phone_feature" / "ui" / "bootstrap.js"),
        check_path("phone_ui_chat", root / "phone_feature" / "ui" / "chat.js"),
        check_path("phone_ui_conversations",
                   root / "phone_feature" / "ui" / "conversations.js"),
        check_path("phone_ui_media", root / "phone_feature" / "ui" / "media.js"),
        check_path("phone_ui_settings", root / "phone_feature" / "ui" / "settings.js"),
        check_path("phone_ui_history", root / "phone_feature" / "ui" / "history.js"),
        check_path("phone_ui_tasks", root / "phone_feature" / "ui" / "tasks.js"),
        check_path("phone_ui_management",
                   root / "phone_feature" / "ui" / "management.js"),
        check_path("platform_adapter", root / "core" / "platform_adapter.py"),
        check_path("settings", root / "config.json", severity="warning"),
        check_codex_cli(),
        check_codex_compat(),
        check_app_security(),
        check_storage(),
    ]
    if include_phone:
        checks.append(check_phone_port())
    failed = [item for item in checks if not item.ok and item.severity == "error"]
    warnings = [item for item in checks if not item.ok and item.severity != "error"]
    return {
        "ok": not failed,
        "error_count": len(failed),
        "warning_count": len(warnings),
        "checks": [item.as_dict() for item in checks],
    }


def format_text(report: dict[str, Any]) -> str:
    lines = [
        "鳍舱启动自检：%s" % ("通过" if report.get("ok") else "发现错误"),
        "错误 %s 项，警告 %s 项" % (
            report.get("error_count", 0),
            report.get("warning_count", 0),
        ),
    ]
    for item in report.get("checks", []):
        state = "OK" if item.get("ok") else str(item.get("severity", "error")).upper()
        lines.append("[%s] %s: %s" % (state, item.get("name"), item.get("detail")))
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    report = collect(include_phone="--no-phone" not in args)
    if "--json" in args:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(format_text(report))
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
