# Read the text inside a window (Windows UI Automation).
# ASCII ONLY: Windows PowerShell 5.1 reads .ps1 files in the ANSI code page,
# so UTF-8 Chinese comments here would break the parser (that bug shipped once).
#
# ChatGPT / Codex / Claude desktop apps keep the conversation in a Document
# element inside the window, so we look for that element and use TextPattern.
param(
    [Parameter(Mandatory = $true)][int]$Hwnd,
    [int]$Limit = 4000
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$el = [System.Windows.Automation.AutomationElement]::FromHandle([IntPtr]::new($Hwnd))
if ($null -eq $el) { exit 1 }

$cond = New-Object System.Windows.Automation.PropertyCondition(
    [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
    [System.Windows.Automation.ControlType]::Document)
$doc = $el.FindFirst([System.Windows.Automation.TreeScope]::Descendants, $cond)
if ($null -eq $doc) { $doc = $el }

$tp = $null
if ($doc.TryGetCurrentPattern([System.Windows.Automation.TextPattern]::Pattern, [ref]$tp)) {
    $tp.DocumentRange.GetText($Limit)
    exit 0
}
exit 2
