﻿param(
    [Parameter(Mandatory = $true)][string]$AppDir,
    [ValidateSet('on', 'off', 'status')][string]$Action = 'status',
    [ValidateSet('talk', 'hold')][string]$Mode = 'talk'
)

$startup = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $startup '语音助手（开机自启）.lnk'
$pythonw = Join-Path $AppDir '.venv\Scripts\pythonw.exe'
$stt = Join-Path $AppDir 'stt.py'
$icon = Join-Path $AppDir 'voice.ico'
if (-not (Test-Path -LiteralPath $icon)) { $icon = "$env:SystemRoot\System32\mmres.dll,5" }

switch ($Action) {
    'on' {
        # 无窗口启动：开机后台待命，桌面上只有一个悬浮窗
        $modeArg = if ($Mode -eq 'hold') { '--mode hold' } else { '--mode talk' }
        $sh = New-Object -ComObject WScript.Shell

        # 先清掉历史遗留的同名快捷方式（只删"指向本程序目录"的那些，别人的不碰）
        Get-ChildItem -LiteralPath $startup -Filter '*.lnk' -ErrorAction SilentlyContinue | ForEach-Object {
            if ($_.FullName -ne $lnk) {
                try {
                    $old = $sh.CreateShortcut($_.FullName)
                    if ($old.TargetPath -like "$AppDir*" -or $old.Arguments -like "*$AppDir*") {
                        Remove-Item -LiteralPath $_.FullName -Force
                        Write-Output ("   清理旧快捷方式: " + $_.Name)
                    }
                }
                catch { }
            }
        }

        $sc = $sh.CreateShortcut($lnk)
        $sc.TargetPath = $pythonw
        $sc.Arguments = '"' + $stt + '" ' + $modeArg
        $sc.WorkingDirectory = $AppDir
        $sc.IconLocation = $icon
        $sc.Description = '登录后自动启动语音助手（后台无窗口）'
        $sc.WindowStyle = 7
        $sc.Save()
        Write-Output "autostart ON  ->  $pythonw $modeArg"
        Write-Output "shortcut      :  $lnk"
    }
    'off' {
        if (Test-Path -LiteralPath $lnk) {
            Remove-Item -LiteralPath $lnk -Force
            Write-Output "autostart OFF (已删除 $lnk)"
        }
        else {
            Write-Output "autostart OFF (本来就没开)"
        }
    }
    'status' {
        if (Test-Path -LiteralPath $lnk) {
            $sc = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
            Write-Output "autostart ON  ->  $($sc.TargetPath) $($sc.Arguments)"
        }
        else {
            Write-Output "autostart OFF"
        }
    }
}
