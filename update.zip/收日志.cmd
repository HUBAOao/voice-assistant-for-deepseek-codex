@echo off
rem ASCII ONLY content (cmd.exe parses .cmd in the ANSI code page).
rem Collects logs into a zip on the Desktop so they can be sent for diagnosis.
setlocal EnableExtensions
title Voice Assistant - Collect logs
chcp 65001 >nul
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

echo.
echo    Voice Assistant - collect logs
echo    ------------------------------------------------
echo.

set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  py -3 -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo   [!] No Python found, so logs cannot be collected.
  echo       Just zip this whole folder by hand and send it.
  echo.
  pause
  exit /b 1
)

%PYEXE% "%APP%\collect_logs.py"
echo.
pause
