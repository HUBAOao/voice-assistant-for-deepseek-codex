#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手设置页。

左边是分类，右边是内容，切页时带滑动动画；开关是自绘的，滑动也是动画。
改完点「保存并应用」—— 悬浮窗会立刻跟着变（它每秒看一次配置文件）。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

from PIL import Image, ImageDraw, ImageTk

HERE = Path(__file__).resolve().parent
CONFIG = HERE / "config.json"

BG = "#151519"
PANEL = "#1d1d23"
CARD = "#24242c"
CARD_HOVER = "#2c2c36"
CARD_SEL = "#2a4a3a"
FG = "#ffffff"
DIM = "#9a9aa5"
ACCENT = "#3ddc84"
SW_ON = "#2f7f5a"
SW_OFF = "#3a3a44"
SW_KNOB = "#f2f2f6"

VOICES = [
    ("zh-CN-XiaoxiaoNeural", "晓晓 · 女声温柔"),
    ("zh-CN-XiaoyiNeural", "晓伊 · 女声活泼"),
    ("zh-CN-YunxiNeural", "云希 · 男声年轻"),
    ("zh-CN-YunjianNeural", "云健 · 男声浑厚"),
    ("zh-CN-YunyangNeural", "云扬 · 男声播音"),
    ("zh-CN-YunxiaNeural", "云夏 · 男声少年"),
    ("zh-CN-liaoning-XiaobeiNeural", "小北 · 东北女声"),
    ("zh-CN-shaanxi-XiaoniNeural", "小妮 · 陕西女声"),
]

STARTUP_LNK = "语音助手（开机自启）.lnk"


def load_config() -> dict:
    try:
        data = json.loads(CONFIG.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_config(data: dict) -> None:
    CONFIG.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def startup_path() -> Path:
    return Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup" / STARTUP_LNK


class Slider:
    """带数值显示的滑杆。"""

    def __init__(self, parent, label, minimum, maximum, value, fmt="{:.0f}", on_change=None):
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.on_change = on_change
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill="x", pady=6)
        tk.Label(row, text=label, bg=CARD, fg=FG, width=12, anchor="w",
                 font=("Microsoft YaHei UI", 10)).pack(side="left", padx=(12, 6))
        self.value_label = tk.Label(row, text=fmt.format(value), bg=CARD, fg=ACCENT, width=6,
                                    font=("Microsoft YaHei UI", 10, "bold"))
        self.value_label.pack(side="right", padx=(6, 12))
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Dark.Horizontal.TScale", background=CARD, troughcolor="#33333d",
                        bordercolor=CARD, lightcolor=ACCENT, darkcolor=ACCENT)
        self.var = tk.DoubleVar(value=value)
        self.scale = ttk.Scale(row, from_=minimum, to=maximum, variable=self.var,
                               orient="horizontal", style="Dark.Horizontal.TScale",
                               command=self.changed)
        self.scale.pack(side="left", fill="x", expand=True, padx=6)
        self.fmt = fmt

    def changed(self, _value=None) -> None:
        v = self.var.get()
        self.value_label.config(text=self.fmt.format(v))
        if self.on_change:
            self.on_change(v)

    def get(self) -> float:
        return self.var.get()

    def set(self, value: float) -> None:
        self.var.set(value)
        self.changed()


class Switch:
    """自绘的动画开关（抗锯齿贴图 + 缓动滑动）。"""

    W, H = 46, 24

    def __init__(self, parent, value: bool, on_change=None, bg=CARD):
        import tkinter as tk

        self.tk = tk
        self.on_change = on_change
        self.value = bool(value)
        self.pos = 1.0 if value else 0.0
        self.target = self.pos
        self._cache = {}
        self.canvas = tk.Canvas(parent, width=self.W, height=self.H, bg=bg,
                                highlightthickness=0, cursor="hand2")
        self.item = self.canvas.create_image(self.W / 2, self.H / 2, image=self.sprite(self.pos))
        self.canvas.bind("<Button-1>", lambda _e: self.toggle())
        self._tick()

    def sprite(self, pos: float):
        key = round(pos * 40) / 40
        im = self._cache.get(key)
        if im is None:
            scale = 4
            big = (self.W * scale, self.H * scale)
            pic = Image.new("RGBA", big, (0, 0, 0, 0))
            d = ImageDraw.Draw(pic)
            a, b = rgb_tuple(SW_OFF), rgb_tuple(SW_ON)
            fill = "#%02x%02x%02x" % tuple(round(a[i] + (b[i] - a[i]) * key) for i in range(3))
            d.rounded_rectangle([0, 0, big[0] - 1, big[1] - 1], radius=big[1] // 2, fill=fill)
            pad, r = 3 * scale, (self.H - 6) / 2 * scale
            x0 = pad + (big[0] - 2 * pad - 2 * r) * key
            cy = big[1] / 2
            d.ellipse([x0, cy - r, x0 + 2 * r, cy + r], fill=SW_KNOB)
            im = ImageTk.PhotoImage(pic.resize((self.W, self.H), Image.LANCZOS))
            self._cache[key] = im
        return im

    def _tick(self) -> None:
        if abs(self.target - self.pos) > 0.002:
            self.pos += (self.target - self.pos) * 0.25
            self.canvas.itemconfig(self.item, image=self.sprite(self.pos))
            self._job = self.canvas.after(25, self._tick)
        else:
            # 跟悬浮窗里那个开关一样：动画停了就不挂定时器，别白醒
            self.pos = self.target
            self._job = None

    def _wake(self) -> None:
        if getattr(self, "_job", None) is None:
            self._job = self.canvas.after(25, self._tick)

    def toggle(self) -> None:
        self.value = not self.value
        self.target = 1.0 if self.value else 0.0
        self._wake()
        if self.on_change:
            self.on_change(self.value)

    def get(self) -> bool:
        return self.value

    def set(self, value: bool) -> None:
        self.value = bool(value)
        self.target = 1.0 if value else 0.0
        self._wake()


def rgb_tuple(color: str) -> tuple[int, int, int]:
    color = color.lstrip("#")
    return int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)


class Settings:
    def __init__(self, start_tab: int = 0) -> None:
        import tkinter as tk
        from tkinter import colorchooser, filedialog

        self.tk = tk
        self.colorchooser = colorchooser
        self.filedialog = filedialog
        self.cfg = load_config()
        self.dirty = False

        self.root = tk.Tk()
        self.root.title("语音助手 · 设置")
        self.root.configure(bg=BG)
        self.root.geometry("640x660")
        self.root.resizable(False, False)

        head = tk.Frame(self.root, bg=BG)
        head.pack(fill="x", padx=18, pady=(16, 8))
        tk.Label(head, text="语音助手设置", bg=BG, fg=FG,
                 font=("Microsoft YaHei UI", 15, "bold")).pack(side="left")
        self.hint = tk.Label(head, text="", bg=BG, fg=ACCENT,
                             font=("Microsoft YaHei UI", 9))
        self.hint.pack(side="right")

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=18, pady=(0, 10))

        # 左边分类
        nav = tk.Frame(body, bg=PANEL, width=140)
        nav.pack(side="left", fill="y")
        nav.pack_propagate(False)
        self.nav_canvas = tk.Canvas(body, width=4, bg=PANEL, highlightthickness=0)
        self.nav_items = []
        self.tabs = {}
        self.tab_names = ["基本", "声音", "外观", "布局", "其他"]
        for i, name in enumerate(self.tab_names):
            label = tk.Label(nav, text=name, bg=PANEL, fg=DIM, anchor="w",
                             font=("Microsoft YaHei UI", 11), padx=14, pady=10, cursor="hand2")
            label.pack(fill="x")
            label.bind("<Button-1>", lambda _e, idx=i: self.show_tab(idx))
            label.bind("<Enter>", lambda _e, l=label: l.config(bg=CARD) if l["fg"] == DIM else None)
            label.bind("<Leave>", lambda _e, l=label: l.config(bg=PANEL) if l["fg"] == DIM else None)
            self.nav_items.append(label)

        self.stage = tk.Frame(body, bg=BG)
        self.stage.pack(side="left", fill="both", expand=True)
        self.stage.pack_propagate(False)
        for name in self.tab_names:
            frame = tk.Frame(self.stage, bg=BG)
            self.tabs[name] = frame
        self.build_basic(self.tabs["基本"])
        self.build_sound(self.tabs["声音"])
        self.build_look(self.tabs["外观"])
        self.build_layout(self.tabs["布局"])
        self.build_misc(self.tabs["其他"])

        bar = tk.Frame(self.root, bg=BG)
        bar.pack(fill="x", padx=18, pady=(0, 16))
        self.save_btn = tk.Label(bar, text="保存并应用", bg=ACCENT, fg="#10261a",
                                 font=("Microsoft YaHei UI", 11, "bold"), padx=26, pady=8,
                                 cursor="hand2")
        self.save_btn.pack(side="right")
        self.save_btn.bind("<Button-1>", lambda _e: self.save())
        restart = tk.Label(bar, text="重启语音程序", bg=CARD, fg=FG,
                           font=("Microsoft YaHei UI", 10), padx=16, pady=8, cursor="hand2")
        restart.pack(side="right", padx=(0, 10))
        restart.bind("<Button-1>", lambda _e: self.restart_program())
        self.current = 0
        self.show_tab(max(0, min(len(self.tab_names) - 1, start_tab)), animate=False)

    # ---------------------------------------------------------------- 分页
    def show_tab(self, index: int, animate: bool = True) -> None:
        name = self.tab_names[index]
        if index == self.current and animate:
            return
        for i, label in enumerate(self.nav_items):
            label.config(bg=PANEL if i != index else CARD,
                         fg=FG if i == index else DIM)
        old = self.tabs[self.tab_names[self.current]]
        new = self.tabs[name]
        self.current = index
        width = self.stage.winfo_width() or 460
        if not animate:
            old.place_forget()
            new.place(x=0, y=0, relwidth=1, relheight=1)
            return
        # 横向滑入
        new.place(x=width, y=0, relwidth=1, relheight=1)
        for step in range(1, 13):
            t = 1 - (1 - step / 12) ** 3
            new.place_configure(x=int(width * (1 - t)))
            old.place_configure(x=int(-width * 0.35 * t))
            self.root.update_idletasks()
            time.sleep(0.012)
        old.place_forget()
        new.place(x=0, y=0, relwidth=1, relheight=1)

    # ---------------------------------------------------------------- 基本
    def build_basic(self, parent) -> None:
        tk = self.tk
        self.entry_name = self.entry(parent, "悬浮窗上显示的名字", self.cfg.get("name") or "语音助手")
        self.entry_wake = self.entry(parent, "唤醒词", self.cfg.get("wake_word") or "大肥鱼")
        self.entry_cancel = self.entry(parent, "取消词", self.cfg.get("cancel_word") or "取消")

        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text="启动模式", bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=10)
        self.mode_var = tk.StringVar(value=self.cfg.get("last_mode") or "talk")
        for value, text in (("talk", "对话模式"), ("hold", "转录模式")):
            tk.Radiobutton(card, text=text, value=value, variable=self.mode_var,
                           bg=CARD, fg=FG, selectcolor=PANEL, activebackground=CARD,
                           activeforeground=FG, font=("Microsoft YaHei UI", 10),
                           command=self.mark_dirty).pack(side="left", padx=6)

        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text="开机自启", bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=10)
        self.sw_autostart = Switch(card, startup_path().exists(), self.on_autostart)
        self.sw_autostart.canvas.pack(side="right", padx=12, pady=8)

        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text="开机问候", bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=10)
        self.sw_greeting = Switch(card, bool(self.cfg.get("greeting_enabled", True)),
                                  lambda _v: self.mark_dirty())
        self.sw_greeting.canvas.pack(side="right", padx=12, pady=8)
        self.entry_greeting = self.entry(
            parent, "问候语（可用 {time} {name} {wake} 占位）",
            self.cfg.get("greeting_text") or "{time}好，{name}已经就绪，说「{wake}」就能叫我。")

    def on_autostart(self, value: bool) -> None:
        script = HERE / "autostart.ps1"
        if script.exists():
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-File", str(script), "-AppDir", str(HERE),
                              "-Action", "on" if value else "off"],
                             creationflags=0x08000000)
        self.flash("开机自启：" + ("已打开" if value else "已关闭"))

    # ---------------------------------------------------------------- 声音
    def build_sound(self, parent) -> None:
        tk = self.tk
        self.sl_volume = Slider(parent, "朗读音量", 0, 100, float(self.cfg.get("volume") or 80),
                                fmt="{:.0f}%", on_change=lambda _v: self.mark_dirty())

        def rate_to_slider(rate: str) -> float:
            try:
                return float(str(rate).replace("%", "").replace("+", ""))
            except Exception:
                return 8.0

        self.sl_rate = Slider(parent, "语速", -40, 60, rate_to_slider(self.cfg.get("rate") or "+8%"),
                              fmt="{:+.0f}%", on_change=lambda _v: self.mark_dirty())

        tk.Label(parent, text="音色", bg=BG, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            anchor="w", pady=(12, 4))
        wrap = tk.Frame(parent, bg=BG)
        wrap.pack(fill="x")
        self.voice_labels = {}
        current = self.cfg.get("voice") or VOICES[0][0]
        for value, label in VOICES:
            row = tk.Label(wrap, text=label, bg=CARD if value != current else CARD_SEL,
                           fg=FG, anchor="w", font=("Microsoft YaHei UI", 10), padx=12, pady=6,
                           cursor="hand2")
            row.pack(fill="x", pady=2)
            row.bind("<Button-1>", lambda _e, v=value: self.pick_voice(v))
            self.voice_labels[value] = row
        self.voice = current
        prev = tk.Label(parent, text="试听当前音色", bg=CARD, fg=FG,
                        font=("Microsoft YaHei UI", 10), padx=14, pady=7, cursor="hand2")
        prev.pack(anchor="w", pady=(10, 0))
        prev.bind("<Button-1>", lambda _e: self.preview())

    def pick_voice(self, value: str) -> None:
        self.voice = value
        for v, row in self.voice_labels.items():
            row.config(bg=CARD_SEL if v == value else CARD)
        self.mark_dirty()

    def preview(self) -> None:
        voice, volume = self.voice, int(self.sl_volume.get())

        def run() -> None:
            try:
                sys.path.insert(0, str(HERE))
                import say

                label = dict(VOICES).get(voice, voice).split(" · ")[0]
                mp3 = say.edge_mp3(f"你好，我是{label}。音量现在是百分之{volume}。",
                                   voice, f"{int(self.sl_rate.get()):+d}%")
                audio, sr = say.decode_audio(mp3)
                if volume < 100:
                    audio = audio * (volume / 100)
                say.play(audio, sr)
            except Exception as exc:  # noqa: BLE001
                self.root.after(0, lambda: self.flash(f"试听失败：{str(exc)[:32]}"))

        threading.Thread(target=run, daemon=True).start()

    # ---------------------------------------------------------------- 外观
    def build_look(self, parent) -> None:
        tk = self.tk
        self.sw_color = self.color_row(parent, "面板颜色", self.cfg.get("overlay_color") or "#1b1b1f")
        self.sw_accent = self.color_row(parent, "强调色", self.cfg.get("overlay_accent") or "#3ddc84")
        self.sw_line_follow = self.toggle_row(parent, "线条跟着状态变色", self.cfg.get(
            "overlay_line_follow_state", False))

        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text="背景图片", bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=10)
        self.image_label = tk.Label(card, text=self.short_path(self.cfg.get("overlay_bg_image") or ""),
                                    bg=CARD, fg=DIM, font=("Microsoft YaHei UI", 9))
        self.image_label.pack(side="left", padx=6)
        clear = tk.Label(card, text="清除", bg=PANEL, fg=FG, font=("Microsoft YaHei UI", 9),
                         padx=10, pady=4, cursor="hand2")
        clear.pack(side="right", padx=10)
        clear.bind("<Button-1>", lambda _e: self.pick_image(""))
        choose = tk.Label(card, text="选择…", bg=PANEL, fg=FG, font=("Microsoft YaHei UI", 9),
                          padx=10, pady=4, cursor="hand2")
        choose.pack(side="right")
        choose.bind("<Button-1>", lambda _e: self.pick_image(None))

        self.sl_dim = Slider(parent, "背景变暗", 0, 90,
                             float(self.cfg.get("overlay_bg_dim") or 45), fmt="{:.0f}%",
                             on_change=lambda _v: self.mark_dirty())
        self.sl_alpha = Slider(parent, "整体透明度", 35, 100,
                               float(self.cfg.get("overlay_alpha") or 0.98) * 100, fmt="{:.0f}%",
                               on_change=lambda _v: self.mark_dirty())

    def short_path(self, path: str) -> str:
        return Path(path).name if path else "（没有，用纯色）"

    def pick_image(self, path) -> None:
        if path is None:
            chosen = self.filedialog.askopenfilename(
                title="选一张背景图",
                filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp"), ("全部", "*.*")])
            if not chosen:
                return
            path = chosen
        self.bg_image = path
        self.image_label.config(text=self.short_path(path))
        self.mark_dirty()

    def color_row(self, parent, label, value):
        tk = self.tk
        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text=label, bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=10)
        swatch = tk.Canvas(card, width=42, height=22, bg=CARD, highlightthickness=0, cursor="hand2")
        swatch.pack(side="right", padx=12)
        rect = swatch.create_rectangle(1, 1, 41, 21, fill=value, outline="#55555f")

        def choose(_event=None):
            _rgb, hex_color = self.colorchooser.askcolor(color=swatch.itemcget(rect, "fill"),
                                                         title=label)
            if hex_color:
                swatch.itemconfig(rect, fill=hex_color)
                self.mark_dirty()

        swatch.bind("<Button-1>", choose)
        return swatch, rect

    # ---------------------------------------------------------------- 布局
    def build_layout(self, parent) -> None:
        tk = self.tk
        self.sw_show_name = self.toggle_row(parent, "显示名字", self.cfg.get("overlay_show_name", True))
        self.sw_show_status = self.toggle_row(parent, "显示状态", self.cfg.get("overlay_show_status", True))
        self.sw_show_line = self.toggle_row(parent, "显示声音线条", self.cfg.get("overlay_show_line", True))
        self.sw_show_switch = self.toggle_row(parent, "显示开关", self.cfg.get("overlay_show_switch", True))
        self.sl_width = Slider(parent, "面板宽度", 260, 520, float(self.cfg.get("overlay_width") or 344),
                               on_change=lambda _v: self.mark_dirty())
        self.sl_height = Slider(parent, "面板高度", 90, 200, float(self.cfg.get("overlay_height") or 104),
                                on_change=lambda _v: self.mark_dirty())
        self.sl_line = Slider(parent, "线条最长", 80, 420, float(self.cfg.get("overlay_line_max") or 190),
                              fmt="{:.0f}px", on_change=lambda _v: self.mark_dirty())

    def toggle_row(self, parent, label, value):
        tk = self.tk
        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=5)
        tk.Label(card, text=label, bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            side="left", padx=12, pady=8)
        sw = Switch(card, bool(value), lambda _v: self.mark_dirty())
        sw.canvas.pack(side="right", padx=12, pady=6)
        return sw

    # ---------------------------------------------------------------- 其他
    def build_misc(self, parent) -> None:
        tk = self.tk
        info = tk.Label(parent, text=("· 悬浮窗右键可以打开这个设置页\n"
                                      "· 改完记得点「保存并应用」\n"
                                      "· 改唤醒词、麦克风这类要在「重启语音程序」后生效\n"
                                      "· 控制台日志在 voice.log，识别记录在 transcripts.md"),
                        bg=BG, fg=DIM, justify="left", font=("Microsoft YaHei UI", 10))
        info.pack(anchor="w", pady=(6, 14))
        for text, command in (("打开程序目录", self.open_folder),
                              ("查看识别记录", lambda: self.open_file("transcripts.md")),
                              ("查看运行日志", lambda: self.open_file("voice.log")),
                               ("卸载语音助手", self.uninstall)):
            btn = tk.Label(parent, text=text, bg=CARD, fg=FG, anchor="w",
                           font=("Microsoft YaHei UI", 10), padx=12, pady=8, cursor="hand2")
            btn.pack(fill="x", pady=3)
            btn.bind("<Button-1>", lambda _e, c=command: c())

    def open_folder(self) -> None:
        subprocess.Popen(["explorer", str(HERE)])

    def open_file(self, name: str) -> None:
        path = HERE / name
        if path.exists():
            os.startfile(path)  # noqa: S606
        else:
            self.flash(f"还没有 {name}")

    def uninstall(self) -> None:
        # 弹图形卸载程序（会问你要"保留记录"还是"彻底删除"）
        script = HERE / "uninstall.py"
        if script.exists():
            subprocess.Popen([sys.executable, str(script)], cwd=str(HERE))
            return
        legacy = HERE / "setup.py"
        if legacy.exists():
            subprocess.Popen([sys.executable, str(legacy), "--uninstall"], cwd=str(HERE))

    # ---------------------------------------------------------------- 保存
    def entry(self, parent, label, value):
        tk = self.tk
        card = tk.Frame(parent, bg=CARD)
        card.pack(fill="x", pady=6)
        tk.Label(card, text=label, bg=CARD, fg=FG, font=("Microsoft YaHei UI", 10)).pack(
            anchor="w", padx=12, pady=(8, 2))
        var = tk.StringVar(value=str(value))
        entry = tk.Entry(card, textvariable=var, bg=PANEL, fg=FG, insertbackground=FG,
                         font=("Microsoft YaHei UI", 11), relief="flat")
        entry.pack(fill="x", padx=12, pady=(0, 10))
        var.trace_add("write", lambda *_a: self.mark_dirty())
        return var

    def mark_dirty(self, *_a) -> None:
        self.dirty = True
        self.hint.config(text="有改动未保存")

    def flash(self, text: str) -> None:
        self.hint.config(text=text)
        self.root.after(2500, lambda: self.hint.config(text="有改动未保存" if self.dirty else ""))

    def save(self) -> None:
        data = load_config()
        data.update({
            "name": self.entry_name.get().strip() or "语音助手",
            "wake_word": self.entry_wake.get().strip() or "大肥鱼",
            "cancel_word": self.entry_cancel.get().strip() or "取消",
            "last_mode": self.mode_var.get(),
            "greeting_enabled": self.sw_greeting.get(),
            "greeting_text": self.entry_greeting.get().strip(),
            "volume": int(self.sl_volume.get()),
            "rate": f"{int(self.sl_rate.get()):+d}%",
            "voice": self.voice,
            "overlay_color": self.sw_color[0].itemcget(self.sw_color[1], "fill"),
            "overlay_accent": self.sw_accent[0].itemcget(self.sw_accent[1], "fill"),
            "overlay_bg_image": getattr(self, "bg_image", None) or data.get("overlay_bg_image") or "",
            "overlay_bg_dim": int(self.sl_dim.get()),
            "overlay_alpha": round(self.sl_alpha.get() / 100, 2),
            "overlay_show_name": self.sw_show_name.get(),
            "overlay_show_status": self.sw_show_status.get(),
            "overlay_show_line": self.sw_show_line.get(),
            "overlay_show_switch": self.sw_show_switch.get(),
            "overlay_width": int(self.sl_width.get()),
            "overlay_height": int(self.sl_height.get()),
            "overlay_line_max": int(self.sl_line.get()),
            "overlay_line_follow_state": self.sw_line_follow.get(),
        })
        save_config(data)
        self.dirty = False
        self.hint.config(text="已保存，悬浮窗会立刻变")
        self.root.after(2200, lambda: self.hint.config(text=""))

    def restart_program(self) -> None:
        self.save()
        try:
            (HERE / "control.json").write_text(
                json.dumps({"action": "quit", "ts": time.time()}), encoding="utf-8")
        except Exception:
            pass
        time.sleep(1.2)
        runner = Path(sys.executable).with_name("pythonw.exe")
        if not runner.exists():
            runner = Path(sys.executable)
        mode = "hold" if self.mode_var.get() == "hold" else "talk"
        subprocess.Popen([str(runner), str(HERE / "stt.py"), "--mode", mode], cwd=str(HERE))
        self.flash("语音程序已重启")

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description="语音助手设置")
    ap.add_argument("--tab", type=int, default=0, help="直接打开第几页（0基本 1声音 2外观 3布局 4其他）")
    args = ap.parse_args()
    Settings(args.tab).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
