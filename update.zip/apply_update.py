#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""更新包里的更新器：不用原始安装包，双击就能把已装的程序更新到这一版。

它会：
  1. 自己找"程序装在哪"（安装时留下的位置纸条 → 桌面/开机自启快捷方式 → 你手动指定）
  2. 把现在这版的文件备份一份（可回退）
  3. 停掉正在跑的语音助手
  4. 覆盖程序文件（**不动** 你的 config.json、聊天记录、便签、记账、模型和虚拟环境）
  5. 重新启动

命令行：
    python apply_update.py                 # 弹窗问答（正常双击走这条）
    python apply_update.py --yes           # 不问，直接更新
    python apply_update.py --dir D:\\路径    # 指定装在哪
    python apply_update.py --dry-run       # 只列出来要改什么
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
MARKER = Path(os.environ.get("APPDATA", Path.home())) / "VoiceAssistant" / "install_path.txt"

# 覆盖程序文件时**必须保住**的东西（你的数据 + 运行环境）
KEEP = {
    "config.json", "transcripts.md", "syslog.md", "said.md", "diary.md", "notes.md",
    "ledger.json", "memory.json", "achievements.json", "voiceprint.json", "presets.json",
    "install.log", "更新日志.txt", "导出",
}
KEEP_DIRS = {".venv", "models", "导出", "__pycache__"}
# 更新包自己的东西，不该往安装目录里搬
NOT_PAYLOAD = {"apply_update.py", "更新.cmd", "更新说明.txt", "更新日志.txt"}

NO_WINDOW = 0x08000000 if os.name == "nt" else 0
NEW_CONSOLE = 0x00000010 if os.name == "nt" else 0


def say(text: str = "") -> None:
    print(text, flush=True)


def powershell(script: str, timeout: int = 60) -> str:
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=timeout, creationflags=NO_WINDOW)
        return out.stdout or ""
    except Exception:
        return ""


def looks_like_install(path: Path) -> bool:
    return (path / "stt.py").exists() and (path / "overlay.py").exists() and \
        (path / "version.py").exists()


def from_marker() -> Path | None:
    try:
        p = Path(MARKER.read_text(encoding="utf-8").strip())
        return p if looks_like_install(p) else None
    except Exception:
        return None


def from_shortcuts() -> Path | None:
    """看桌面 / 开机自启 / 开始菜单里那几个快捷方式指向哪儿。"""
    script = (
        "$sh=New-Object -ComObject WScript.Shell;"
        "foreach($p in @([Environment]::GetFolderPath('Desktop'),"
        "[Environment]::GetFolderPath('Startup'),"
        "[Environment]::GetFolderPath('Programs'))){"
        " Get-ChildItem -LiteralPath $p -Filter *.lnk -ErrorAction SilentlyContinue |"
        " ForEach-Object { try { $s=$sh.CreateShortcut($_.FullName);"
        " if($s.Arguments -match 'launcher.py|show_overlay.py|stt.py'){"
        " Write-Output ($_.FullName); Write-Output $s.Arguments } } catch {} } }"
    )
    for line in powershell(script).splitlines():
        line = line.strip()
        if ":\\" in line and line.lower().endswith((".py", ".py\"")):
            cand = Path(line.strip('"').strip("'"))
            if looks_like_install(cand.parent):
                return cand.parent
    return None


def from_self() -> Path | None:
    """有人把更新包解压到安装目录里了 / 就是在安装目录里跑的本脚本。"""
    return HERE if looks_like_install(HERE) else None


def find_install() -> Path | None:
    for fn in (from_marker, from_shortcuts, from_self):
        try:
            got = fn()
        except Exception:
            got = None
        if got:
            return got
    return None


def version_of(folder: Path) -> str:
    try:
        sys.path.insert(0, str(folder))
        import importlib.util

        spec = importlib.util.spec_from_file_location("v_" + folder.name, folder / "version.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return str(getattr(mod, "APP_VERSION", "?"))
    except Exception:
        return "?"
    finally:
        try:
            sys.path.remove(str(folder))
        except ValueError:
            pass


def payload_files() -> list:
    """更新包里要覆盖过去的文件（排除数据、运行环境和更新器自己）。"""
    out = []
    for p in sorted(HERE.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(HERE)
        if rel.parts[0] in KEEP_DIRS or rel.name in KEEP or rel.name in NOT_PAYLOAD:
            continue
        if p.suffix.lower() in {".log", ".pyc"}:
            continue
        out.append(rel)
    return out


def app_processes(app_dir: Path) -> list:
    d = str(app_dir).replace("'", "''")
    me = os.getpid()
    script = (
        f"$d='{d}'; $me={me};"
        "Get-CimInstance Win32_Process | Where-Object { "
        "($_.Name -eq 'python.exe' -or $_.Name -eq 'pythonw.exe') -and "
        "$_.ProcessId -ne $me -and $_.CommandLine -and "
        "$_.CommandLine -like ('*' + $d + '*') -and "
        "$_.CommandLine -notlike '*apply_update.py*' } | ForEach-Object { $_.ProcessId }"
    )
    return [int(x) for x in powershell(script).split() if x.strip().isdigit()]


def stop_app(app_dir: Path) -> int:
    pids = app_processes(app_dir)
    for pid in pids:
        powershell(f"Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue")
    if pids:
        time.sleep(1.2)
    return len(pids)


def backup(app_dir: Path, old_ver: str) -> Path | None:
    """把要被覆盖的那几个文件先备份一份，出问题能退回去。"""
    folder = app_dir / f"更新备份-v{old_ver}"
    try:
        folder.mkdir(parents=True, exist_ok=True)
        for rel in payload_files():
            src = app_dir / rel
            if src.is_file():
                dst = folder / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        return folder
    except Exception as exc:  # noqa: BLE001
        say(f"  （备份没做成：{exc}，继续更新）")
        return None


def apply(app_dir: Path, dry: bool = False) -> tuple:
    new_ver = version_of(HERE)
    old_ver = version_of(app_dir)
    files = payload_files()
    say("")
    say("=" * 58)
    say(f"  语音助手 更新　v{old_ver}  →  v{new_ver}")
    say("=" * 58)
    say(f"  装在这儿：{app_dir}")
    say(f"  要更新 {len(files)} 个程序文件；你的设置、聊天记录、便签、记账、"
        f"模型都不会动。")
    if dry:
        say("  （这是演练，什么都没改）")
        for rel in files[:20]:
            say(f"    · {rel}")
        if len(files) > 20:
            say(f"    … 还有 {len(files) - 20} 个")
        return 0, old_ver, new_ver

    n = stop_app(app_dir)
    if n:
        say(f"  停掉了 {n} 个正在跑的进程")
    bak = backup(app_dir, old_ver)
    if bak:
        say(f"  备份好了：{bak.name}")
    done = 0
    for rel in files:
        src, dst = HERE / rel, app_dir / rel
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            done += 1
        except Exception as exc:  # noqa: BLE001
            say(f"    ✗ {rel}：{exc}")
    say(f"  更新完成：{done}/{len(files)} 个文件")
    try:
        (app_dir / "更新日志.txt").write_text(
            f"{time.strftime('%Y-%m-%d %H:%M:%S')}  v{old_ver} → v{new_ver}\n"
            f"更新了 {done} 个文件，备份在 {bak.name if bak else '（没备份）'}\n",
            encoding="utf-8")
    except Exception:
        pass
    return done, old_ver, new_ver


def restart(app_dir: Path) -> None:
    runner = app_dir / ".venv" / "Scripts" / "pythonw.exe"
    if not runner.exists():
        runner = Path(sys.executable).with_name("pythonw.exe")
    script = app_dir / "stt.py"
    if not script.exists():
        return
    try:
        subprocess.Popen([str(runner), str(script), "--mode", "talk"], cwd=str(app_dir),
                         creationflags=NO_WINDOW)
        say("  已经重新启动了（看右下角的悬浮窗）")
    except Exception as exc:  # noqa: BLE001
        say(f"  （没自动起来：{exc}，双击桌面「语音助手」就行）")


def ask(app_dir: Path | None) -> str:
    """弹个小窗口问一句。返回 ok / cancel。"""
    import tkinter as tk

    result = {"ok": False}
    win = tk.Tk()
    win.title("更新语音助手")
    win.configure(bg="#151519")
    win.geometry("480x300")
    win.resizable(False, False)
    tk.Label(win, text="更新语音助手", bg="#151519", fg="#ffffff",
             font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w", padx=18,
                                                            pady=(16, 4))
    tk.Label(win, text=f"这一版：v{version_of(HERE)}", bg="#151519", fg="#9a9aa5",
             font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18)
    box = tk.Frame(win, bg="#24242c")
    box.pack(fill="x", padx=18, pady=12)
    tk.Label(box, text="要更新的程序：", bg="#24242c", fg="#ffffff",
             font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=12, pady=(10, 0))
    tk.Label(box, text=str(app_dir or "没找到它装在哪（请把程序文件夹拖进来）"),
             bg="#24242c", fg="#3ddc84", font=("Microsoft YaHei UI", 9),
             wraplength=420, justify="left").pack(anchor="w", padx=12)
    tk.Label(box, text="你的设置、聊天记录、便签、记账和模型都不会动；"
                       "更新前会自动备份一份，能退回去。",
             bg="#24242c", fg="#9a9aa5", font=("Microsoft YaHei UI", 8),
             wraplength=420, justify="left").pack(anchor="w", padx=12, pady=(6, 10))

    def ok(_e=None):
        result["ok"] = True
        win.destroy()

    go = tk.Label(win, text="开始更新", bg="#2f7f5a", fg="#ffffff",
                  font=("Microsoft YaHei UI", 11, "bold"), padx=24, pady=8,
                  cursor="hand2")
    go.pack(pady=(0, 6))
    go.bind("<Button-1>", ok)
    cancel = tk.Label(win, text="先不更新", bg="#151519", fg="#9a9aa5",
                      font=("Microsoft YaHei UI", 9), cursor="hand2")
    cancel.pack()
    cancel.bind("<Button-1>", lambda _e: win.destroy())
    win.bind("<Return>", ok)
    win.bind("<Escape>", lambda _e: win.destroy())
    try:
        win.attributes("-topmost", True)
        win.focus_force()
    except Exception:
        pass
    win.mainloop()
    return "ok" if result["ok"] else "cancel"


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleTitleW("语音助手 - 更新")
        except Exception:
            pass

    ap = argparse.ArgumentParser(description="语音助手 更新器")
    ap.add_argument("--yes", action="store_true", help="不问，直接更新")
    ap.add_argument("--dry-run", action="store_true", help="只列出来要改什么")
    ap.add_argument("--dir", default=None, help="程序装在哪（不填就自己找）")
    ap.add_argument("--no-restart", action="store_true", help="更新完不自动启动")
    args = ap.parse_args()

    app_dir = Path(args.dir).resolve() if args.dir else find_install()
    if app_dir is not None and not looks_like_install(app_dir):
        say(f"✗ {app_dir} 看着不像装语音助手的目录（里面没有 stt.py / overlay.py）")
        return 2

    if not args.yes and not args.dry_run:
        if app_dir is None:
            say("找不到程序装在哪儿。请这样：把更新包解压，然后")
            say("  把程序文件夹拖到「更新.cmd」上，或者")
            say("  在命令行里运行：python apply_update.py --dir \"D:\\程序目录\"")
            ask(app_dir)
            return 1
        if ask(app_dir) != "ok":
            say("已取消，什么都没动。")
            return 0

    if app_dir is None:
        say("找不到程序装在哪儿；用 --dir 指定一下。")
        return 1

    done, old_ver, new_ver = apply(app_dir, dry=args.dry_run)
    if args.dry_run:
        say("\n（演练结束，什么都没改）")
        return 0
    if not args.no_restart:
        restart(app_dir)
    say("")
    say(f"  更新完毕：v{old_ver} → v{new_ver}")
    say("  （要退回上一版：进程序目录，把「更新备份-v"
        f"{old_ver}」里的文件拷回去就行）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
