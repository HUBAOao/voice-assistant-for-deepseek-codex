#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""日程的规则解析与判定（界面和调度器共用）。

一条日程长这样：
    {"time": "09:00", "kind": "daily",   "text": "早上好"}
    {"time": "18:30", "kind": "weekly",  "weekdays": [0, 2, 4], "text": "该收拾桌面了"}
    {"time": "10:00", "kind": "monthly", "monthday": 1, "text": "交房租"}
    {"time": "15:00", "kind": "once",    "date": "2026-10-08", "text": "面试"}
也兼容老写法：只写 "days": "每天 / 工作日 / 周一,周三"。
"""

from __future__ import annotations

from datetime import date, datetime

WEEK_CN = ["一", "二", "三", "四", "五", "六", "日"]
KINDS = [("daily", "每天"), ("weekly", "每周"), ("monthly", "每月"), ("once", "单次")]
_WEEK = {"一": 0, "二": 1, "三": 2, "四": 3, "五": 4, "六": 5, "日": 6, "天": 6}


def legacy_weekdays(text: str) -> list[int] | None:
    """把老的 days 文本转成星期列表；返回 None 表示"每天"。"""
    text = (text or "").strip()
    if not text or text in ("每天", "每日", "天天", "all"):
        return None
    if text in ("工作日", "周一至周五", "周一到周五"):
        return [0, 1, 2, 3, 4]
    if text in ("周末", "周六周日"):
        return [5, 6]
    picked = sorted({_WEEK[ch] for ch in text if ch in _WEEK})
    return picked or None


def normalize(entry: dict) -> dict:
    """补全成统一结构（兼容老数据）。"""
    item = dict(entry or {})
    kind = item.get("kind")
    if kind not in {k for k, _ in KINDS}:
        weekdays = legacy_weekdays(str(item.get("days") or ""))
        if weekdays is None:
            kind = "daily"
        else:
            kind = "weekly"
            item["weekdays"] = weekdays
        item["kind"] = kind
    if kind == "weekly" and not item.get("weekdays"):
        item["weekdays"] = [0]
    if kind == "monthly":
        try:
            item["monthday"] = max(1, min(31, int(item.get("monthday") or 1)))
        except Exception:
            item["monthday"] = 1
    if kind == "once" and not item.get("date"):
        item["date"] = datetime.now().strftime("%Y-%m-%d")
    return item


def matches(entry: dict, day: date) -> bool:
    item = normalize(entry)
    kind = item["kind"]
    if kind == "daily":
        return True
    if kind == "weekly":
        return day.weekday() in (item.get("weekdays") or [])
    if kind == "monthly":
        return day.day == int(item.get("monthday") or 1)
    if kind == "once":
        return str(item.get("date")) == day.strftime("%Y-%m-%d")
    return False


def describe(entry: dict) -> str:
    item = normalize(entry)
    kind = item["kind"]
    if kind == "daily":
        return "每天"
    if kind == "weekly":
        days = item.get("weekdays") or []
        if sorted(days) == [0, 1, 2, 3, 4]:
            return "工作日"
        if sorted(days) == [5, 6]:
            return "周末"
        return "周" + "、".join(WEEK_CN[i] for i in days if 0 <= i <= 6)
    if kind == "monthly":
        return f"每月{item.get('monthday')}日"
    if kind == "once":
        return str(item.get("date"))
    return "每天"


def entries_for_day(entries: list, day: date) -> list[tuple[int, dict]]:
    out = []
    for i, entry in enumerate(entries or []):
        if not isinstance(entry, dict):
            continue
        if entry.get("enabled", True) is False:
            continue
        if matches(entry, day):
            out.append((i, normalize(entry)))
    out.sort(key=lambda pair: str(pair[1].get("time") or ""))
    return out
