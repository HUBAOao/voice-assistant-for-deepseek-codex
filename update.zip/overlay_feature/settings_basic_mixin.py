# -*- coding: utf-8 -*-
"""Stable composition entry for the basic settings page."""
from __future__ import annotations

from overlay_feature.settings_identity_mixin import (
    OverlaySettingsIdentityMixin,
)
from overlay_feature.settings_response_mixin import (
    OverlaySettingsResponseMixin,
)


class OverlaySettingsBasicMixin(
    OverlaySettingsIdentityMixin,
    OverlaySettingsResponseMixin,
):
    """Compose the basic settings page without owning config persistence."""

    def build_basic(self, parent) -> None:
        self.build_identity(parent)
        self.build_response(parent)
