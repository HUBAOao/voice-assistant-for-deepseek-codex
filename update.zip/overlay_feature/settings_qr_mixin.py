# -*- coding: utf-8 -*-
"""Local phone-link QR presentation for the settings panel."""
from __future__ import annotations

import threading

from PIL import ImageTk

from overlay_feature.defaults import BG_PANEL
from overlay_feature.qr_presentation import (
    display_qr_image,
)
from overlay_feature.qr_save_dialog import save_qr_with_dialog
from overlay_feature.runtime import inputlog


class OverlaySettingsQrMixin:
    def show_qr(self) -> None:
        """Draw the local phone URL as a QR code without network access."""
        tk = self.tk
        import qr_tools

        url = self.phone_url_now()
        self.qr_url = url
        old = getattr(self, "qr_win", None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        self.qr_win = win
        win.title("手机扫码连接")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        size = "380x560"
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 380) // 2
            y = self.root.winfo_y() + 40
            win.geometry(f"{size}+{max(0, x)}+{max(0, y)}")
        except Exception:
            win.geometry(size)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        tk.Label(
            win,
            text="手机扫码连接",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(16, 2))
        tk.Label(
            win,
            text="手机 APP 左上角点「扫码」，照一下这个码就自动连上；"
            "没装 APP 直接用相机扫也行，扫出来是个网页",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=330,
            justify="center",
        ).pack(padx=16)

        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=26, pady=12)
        keep = {"photo": None}

        def paint() -> None:
            if not qr_tools.available():
                keep["photo"] = None
                holder.config(
                    image="",
                    width=30,
                    height=10,
                    compound="center",
                    fg="#333333",
                    font=("Microsoft YaHei UI", 10),
                    text="这台机器少一个画二维码的小库\n"
                    "点下面「装一下二维码库」就行",
                )
                return
            try:
                image = display_qr_image(url)
                keep["photo"] = ImageTk.PhotoImage(image)
                self.qr_photo = keep["photo"]
                holder.config(
                    image=keep["photo"],
                    text="",
                    width=0,
                    height=0,
                )
            except Exception as exc:  # noqa: BLE001
                holder.config(
                    image="",
                    text=f"画不出来：{exc}",
                    fg="#333333",
                    width=30,
                    height=10,
                    compound="center",
                )

        def install_library() -> None:
            self.flash("正在装二维码库，几秒钟…", 3)

            def work() -> None:
                _ok, message = qr_tools.install()
                self.root.after(
                    0,
                    lambda: (paint(), self.flash(message, 3.5)),
                )

            threading.Thread(target=work, daemon=True).start()

        def save_png() -> None:
            if not qr_tools.available():
                self.flash("先装上二维码库再存图", 3)
                return
            save_qr_with_dialog(win, url, self.flash)

        paint()
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(2, 6))
        self._chip(
            buttons,
            "复制网址",
            lambda: self.copy_phone_url(),
        ).pack(side="left", padx=4)
        self._chip(
            buttons,
            "另存为图片",
            lambda: save_png(),
        ).pack(side="left", padx=4)
        if not qr_tools.available():
            self._chip(
                buttons,
                "装一下二维码库",
                lambda: install_library(),
            ).pack(side="left", padx=4)

        tk.Label(
            win,
            text=url or "（读不到地址，重启一下程序）",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Consolas", 9),
            wraplength=330,
            justify="center",
        ).pack(padx=16, pady=(4, 2))
        tk.Label(
            win,
            text="换 Wi-Fi / 换电脑之后 IP 会变，到时候重新点一次这个按钮就行",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            wraplength=330,
            justify="center",
        ).pack(padx=16, pady=(0, 10))
        inputlog("点了「二维码」按钮")


__all__ = ["OverlaySettingsQrMixin"]
