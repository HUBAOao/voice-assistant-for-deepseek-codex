# -*- coding: utf-8 -*-
"""Background image and immediate overlay resizing actions."""
from __future__ import annotations

from pathlib import Path


class OverlaySettingsBackgroundSizeMixin:
    def pick_bg(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="选一张背景图",
            filetypes=[
                ("图片", "*.png *.jpg *.jpeg *.webp *.bmp"),
                ("全部", "*.*"),
            ],
        )
        if path:
            self.set_bg(path)

    def set_bg(self, path: str) -> None:
        self.bg_path = path
        self.bg_label.config(text=Path(path).name if path else "无")
        self.on_change()

    def _rate_value(self, rate) -> float:
        try:
            return float(str(rate or "+8%").replace("%", "").replace("+", ""))
        except Exception:
            return 8.0

    def apply_size(self, *_args) -> None:
        """Resize immediately while keeping panel geometry consistent."""
        try:
            self.W = int(self.sl_width.get())
            self.H = int(self.sl_height.get())
        except Exception:
            return
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + self.PANEL_H
        self._base = None
        self._base_key = None
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        try:
            self.root.geometry(
                f"{int(self.compact_w)}x{int(self.header_h)}+"
                f"{int(self.base_x)}+{int(self.base_y)}"
            )
        except Exception:
            pass
        self.on_change()


__all__ = ["OverlaySettingsBackgroundSizeMixin"]
