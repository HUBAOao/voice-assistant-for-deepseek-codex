# -*- coding: utf-8 -*-
"""Compatibility surface for the split appearance controls."""
from __future__ import annotations

from overlay_feature.settings_layout_mixin import OverlaySettingsLayoutMixin
from overlay_feature.settings_visual_geometry_mixin import (
    OverlaySettingsVisualGeometryMixin,
)
from overlay_feature.settings_visual_palette_mixin import (
    OverlaySettingsVisualPaletteMixin,
)


class OverlaySettingsVisualsMixin(
    OverlaySettingsLayoutMixin,
    OverlaySettingsVisualPaletteMixin,
    OverlaySettingsVisualGeometryMixin,
):
    def build_look(self, parent) -> None:
        self.build_visual_palette(parent)
        self.build_visual_geometry(parent)

    def on_fx_change(self, key: str) -> None:
        switch = getattr(self, "fx_switches", {}).get(key)
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None) or {}
            self.fx.update({name: bool(value) for name, value in before.items()})
            self._auto_low = False
            self._fx_before_low = None
            self._auto_low_off = True
        self.fx[key] = (
            bool(switch.get()) if switch is not None
            else bool(self.fx.get(key))
        )
        if key == "fx_sparkles" and not self.fx[key]:
            self._sparks.clear()
        if key == "fx_trail" and not self.fx[key]:
            self._trail_img = None
        self.on_change()
