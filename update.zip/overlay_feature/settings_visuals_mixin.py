# -*- coding: utf-8 -*-
"""Appearance controls for the overlay settings panel."""
from __future__ import annotations

from pathlib import Path

from overlay_feature.defaults import BG_PANEL
from overlay_feature.settings_layout_mixin import OverlaySettingsLayoutMixin


class OverlaySettingsVisualsMixin(OverlaySettingsLayoutMixin):
    def build_look(self, parent) -> None:
        row = self._row(parent, "样式")
        self.wave_style_value = self.wave_style
        self.style_chips = {}
        for value, label in (("siri", "波形带"), ("bars", "声波条")):
            chip = self._chip(
                row, label, lambda current=value: self.set_wave_style(current)
            )
            chip.pack(side="left", padx=3)
            self.style_chips[value] = chip
        self.refresh_style_chips()

        row = self._row(parent, "颜色")
        self.sw_color = self._swatch(row, "面板", self.panel_color)
        self.sw_accent = self._swatch(row, "线条", self.accent)
        self.sw_button = self._swatch(row, "按钮", self.button_color)
        self.sw_text = self._swatch(row, "文字", self.text_color)
        row = self._row(parent, "说话色")
        self.sw_talk = self._swatch(row, "我说话时", self.talk_color)
        self.tk.Label(
            row,
            text="朗读时声音条换成这个颜色，形状跟着语音变化",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left", padx=6)

        row = self._row(parent, "背景图")
        self.bg_path = self.cfg.get("overlay_bg_image") or ""
        self.bg_label = self.tk.Label(
            row,
            text=Path(self.bg_path).name if self.bg_path else "无",
            bg=BG_PANEL,
            fg="#9a9aa5",
            width=12,
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.bg_label.pack(side="left", padx=4)
        self._chip(row, "清除", lambda: self.set_bg("")).pack(
            side="right", padx=4
        )
        self._chip(row, "选择", self.pick_bg).pack(side="right")

        self.sl_alpha = self._slider(
            parent,
            "整体透明度",
            35,
            100,
            self.alpha * 100,
            "{:.0f}%",
        )
        self.sl_dim = self._slider(
            parent,
            "背景变暗",
            0,
            90,
            float(self.cfg.get("overlay_bg_dim") or 45),
            "{:.0f}%",
        )
        self.sw_wheel = self._switch_row(
            parent, "滚轮调透明度", bool(self.cfg.get("wheel_alpha", True))
        )
        self.sw_snap = self._switch_row(
            parent, "贴边吸附", bool(self.cfg.get("snap_edges", True))
        )
        self.sl_width = self._slider(
            parent,
            "悬浮窗宽度",
            240,
            760,
            self.W,
            "{:.0f}",
            self.apply_size,
        )
        self.sl_height = self._slider(
            parent,
            "悬浮窗高度",
            76,
            220,
            self.H,
            "{:.0f}",
            self.apply_size,
        )

        self.build_effects_and_layout(parent)

    def on_fx_change(self, key: str) -> None:
        switch = getattr(self, "fx_switches", {}).get(key)
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None) or {}
            self.fx.update({name: bool(value) for name, value in before.items()})
            self._auto_low = False
            self._fx_before_low = None
            self._auto_low_off = True
        self.fx[key] = (
            bool(switch.get()) if switch is not None
            else bool(self.fx.get(key))
        )
        if key == "fx_sparkles" and not self.fx[key]:
            self._sparks.clear()
        if key == "fx_trail" and not self.fx[key]:
            self._trail_img = None
        self.on_change()

    def _slider(
        self,
        parent,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        fmt: str,
        command=None,
    ):
        from ui_widgets import Slider

        return Slider(
            parent,
            label,
            minimum,
            maximum,
            value,
            fmt=fmt,
            on_change=command or self.on_change,
            bg=BG_PANEL,
        )
