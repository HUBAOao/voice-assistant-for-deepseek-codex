# -*- coding: utf-8 -*-
"""Recognition model, language and recorder controls for settings."""
from __future__ import annotations


class OverlaySettingsRecognitionMixin:
    """Own recognition widgets without coupling them to phone connectivity."""

    def build_recognition_controls(self, parent) -> None:
        self._group(parent, "识别")
        row = self._row(parent, "唤醒词训练")
        self.tk.Label(
            row,
            text="念三遍让它记住你的口音",
            bg=self._panel_bg(),
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(
            row,
            "开始训练",
            lambda: (
                self.send_settings_command("expand"),
                self.flash("对着麦克风说「训练唤醒词」", 3),
            ),
        ).pack(side="right", padx=(4, 10))

        row = self._row(parent, "识别模型")
        self.model_value = str(
            self.cfg.get("model") or "large-v3-turbo"
        )
        self.model_chips = {}
        for value, label in (
            ("small", "小(快)"),
            ("medium", "中"),
            ("large-v3-turbo", "大(准)"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_model(current),
            )
            chip.pack(side="left", padx=3)
            self.model_chips[value] = chip
        self.refresh_model_chips()

        row = self._row(parent, "识别语言")
        self.lang_value = str(self.cfg.get("lang") or "zh")
        self.lang_chips = {}
        for value, label in (
            ("zh", "中文"),
            ("zh,en", "中英混说"),
            ("en", "英文"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_lang(current),
            )
            chip.pack(side="left", padx=3)
            self.lang_chips[value] = chip
        self.refresh_lang_chips()

        row = self._row(parent, "改完生效")
        self.tk.Label(
            row,
            text="改模型或语言后要点重启",
            bg=self._panel_bg(),
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(row, "重启程序", self.restart_program).pack(
            side="right", padx=(4, 10)
        )
        self.sw_rec = self._switch_row(
            parent,
            "录音提示灯",
            bool(self.cfg.get("rec_indicator", True)),
        )

    def _panel_bg(self) -> str:
        """Keep the historical panel color while allowing mixin probes."""
        from overlay_feature.defaults import BG_PANEL

        return BG_PANEL

    def send_settings_command(self, action: str) -> None:
        """Preserve the old module-level helper for this compatibility mixin."""
        from overlay_feature.settings_connection_mixin import send_command

        send_command(action)
