# -*- coding: utf-8 -*-
"""Compatibility composition for sending, connection and recognition settings."""
from __future__ import annotations

from overlay_feature.settings_connection_mixin import (
    OverlaySettingsConnectionMixin,
    send_command,
)
from overlay_feature.settings_send_mixin import OverlaySettingsSendMixin


class OverlaySettingsDeliveryMixin(
    OverlaySettingsSendMixin,
    OverlaySettingsConnectionMixin,
):
    """Keep the historical entry while each business slice stays isolated."""

    def build_delivery_section(self, parent) -> None:
        self.build_send_controls(parent)
        self.build_connection_controls(parent)


__all__ = ["OverlaySettingsDeliveryMixin", "send_command"]
