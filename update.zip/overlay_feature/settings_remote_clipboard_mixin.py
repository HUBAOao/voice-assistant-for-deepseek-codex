"""Clipboard actions for the remote-access settings panel."""
from __future__ import annotations


class OverlaySettingsRemoteClipboardMixin:
    """Copy current LAN, private and public addresses without reconnecting."""

    def copy_phone_url(self) -> None:
        """Put the current phone URL on the clipboard."""
        try:
            url = self.phone_url_now()
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("网址已复制，发到手机上打开就行")
        except Exception:
            self.flash("复制失败，手动抄一下这条网址")

    def phone_url_now(self) -> str:
        """Read the current local phone URL, including network changes."""
        try:
            import phone_link

            return phone_link.phone_url(
                int(self.cfg.get("phone_port") or 8765)
            )
        except Exception:
            pass
        try:
            return str(self.phone_url_label.cget("text"))
        except Exception:
            return ""

    def copy_remote_url(self) -> None:
        """Copy the fixed private remote URL."""
        try:
            import remote_access

            url = (
                getattr(self, "remote_fixed_url", "")
                or remote_access.fixed_url()
            )
            if not url:
                self.flash("还没有外网地址 —— 先点「一键开启」", 4)
                return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("外网固定地址已复制，发到手机上就行", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)

    def copy_public_url(self) -> None:
        """Copy the public Funnel address, falling back to the private URL."""
        try:
            import remote_access

            url = remote_access.public_url() or ""
            if not url:
                fallback = getattr(self, "remote_fixed_url", "")
                if fallback:
                    url = fallback
                else:
                    self.flash(
                        "公网地址还没开 —— 先点「开（手机免装）」",
                        4,
                    )
                    return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("公网地址已复制，发到手机上就能用", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)


__all__ = ["OverlaySettingsRemoteClipboardMixin"]
