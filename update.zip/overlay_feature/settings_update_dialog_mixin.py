"""Release notes and explicit update actions in a separate dialog boundary."""
from __future__ import annotations

import threading
from pathlib import Path

import version
from overlay_feature.defaults import BG_PANEL, CARD


HERE = Path(__file__).resolve().parent.parent


class OverlaySettingsUpdateDialogMixin:
    def _update_dialog(self, ver: str, pc: dict, src: str) -> None:
        """Show release notes and keep both update routes available."""
        import self_update

        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("有新版")
        win.configure(bg=BG_PANEL)
        win.geometry("470x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(
            win,
            text=f"有新版本 v{ver}",
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 13, "bold"),
        ).pack(anchor="w", padx=18, pady=(16, 2))
        tk.Label(
            win,
            text=f"你现在是 v{version.APP_VERSION} · 新版 {pc.get('size') or ''}",
            bg=BG_PANEL,
            fg="#8a8a95",
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=18)
        box = tk.Frame(win, bg=CARD)
        box.pack(fill="both", expand=True, padx=18, pady=(10, 8))
        txt = tk.Text(
            box,
            bg=CARD,
            fg="#e6e6ec",
            relief="flat",
            wrap="word",
            font=("Microsoft YaHei UI", 9),
            insertbackground="#ffffff",
        )
        txt.pack(fill="both", expand=True, padx=10, pady=10)
        txt.insert(
            "1.0",
            "这一版改了什么：\n\n"
            + (self_update.notes_text(pc, 4) or "（更新说明见下载页）"),
        )
        txt.config(state="disabled")
        tk.Label(
            win,
            text="「一键更新」会下载更新包、自动关掉程序再装好（装完自己开回来）",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            wraplength=430,
            justify="left",
        ).pack(anchor="w", padx=18)
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(8, 14))

        def open_page() -> None:
            try:
                import webbrowser

                page = (
                    src[: -len("version.json")]
                    if src.endswith("version.json")
                    else src
                )
                webbrowser.open(page)
                self.flash("下载页已经用浏览器打开了", 3)
            except Exception as exc:  # noqa: BLE001
                self.flash(f"打不开浏览器：{exc}", 3)

        def one_click() -> None:
            for child in bar.winfo_children():
                child.destroy()
            tk.Label(
                bar,
                text="正在下载更新包…（下完程序会自己关掉重开）",
                bg=BG_PANEL,
                fg=self.accent,
                font=("Microsoft YaHei UI", 9),
            ).pack(side="left")

            def run() -> None:
                url = self_update.resolve(
                    src,
                    str(pc.get("update_url") or ""),
                )
                ok, why = self_update.apply_update(url, HERE)
                self.root.after(
                    0,
                    lambda: self.flash(
                        "更新包开始装了，程序会自己重开"
                        if ok
                        else f"更新失败：{why}",
                        4,
                    ),
                )

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(
            bar,
            text="一键更新",
            bg=self.button_color,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 10, "bold"),
            padx=18,
            pady=6,
            cursor="hand2",
        )
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _event: one_click())
        later = tk.Label(
            bar,
            text="以后再说",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=14,
            pady=6,
            cursor="hand2",
        )
        later.pack(side="right", padx=8)
        later.bind("<Button-1>", lambda _event: win.destroy())
        page = tk.Label(
            bar,
            text="打开下载页",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=14,
            pady=6,
            cursor="hand2",
        )
        page.pack(side="right", padx=8)
        page.bind("<Button-1>", lambda _event: open_page())


__all__ = ["OverlaySettingsUpdateDialogMixin"]
