# -*- coding: utf-8 -*-
"""Shortcut editing composed with independently owned settings dialogs."""
from __future__ import annotations

from overlay_feature.settings_qr_mixin import OverlaySettingsQrMixin
from overlay_feature.settings_site_publish_mixin import (
    OverlaySettingsSitePublishMixin,
)


class OverlaySettingsProductActionsMixin(
    OverlaySettingsSitePublishMixin,
    OverlaySettingsQrMixin,
):
    """Keep user-triggered product utilities outside the overlay shell."""

    def shortcuts_summary(self) -> str:
        if not self.shortcuts:
            return "（还没设置）"
        return (
            f"{len(self.shortcuts)} 条："
            + "、".join(list(self.shortcuts)[:3])
        )

    def edit_shortcuts(self) -> None:
        text = "\n".join(f"{key}={value}" for key, value in self.shortcuts.items())

        def apply(value: str) -> None:
            data = {}
            for line in value.splitlines():
                line = line.strip()
                if not line or "=" not in line:
                    continue
                key, _, action = line.partition("=")
                key, action = key.strip(), action.strip()
                if key and action:
                    data[key] = action
            self.shortcuts = data
            self.shortcuts_label.config(text=self.shortcuts_summary())
            self.on_change()

        self.edit_text("快捷指令", text, apply, multiline=True)

__all__ = ["OverlaySettingsProductActionsMixin"]
