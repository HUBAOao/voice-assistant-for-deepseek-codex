# -*- coding: utf-8 -*-
"""Compatibility composition for wake-level and self-test settings."""
from __future__ import annotations

from overlay_feature.settings_wake_levels_mixin import (
    OverlaySettingsWakeLevelsMixin,
)
from overlay_feature.settings_wake_test_mixin import (
    OverlaySettingsWakeTestMixin,
    send_command,
)


class OverlaySettingsWakeMixin(
    OverlaySettingsWakeLevelsMixin,
    OverlaySettingsWakeTestMixin,
):
    """Keep the historical class and method entrypoints."""


__all__ = ["OverlaySettingsWakeMixin", "send_command"]
