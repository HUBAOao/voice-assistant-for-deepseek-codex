"""Compatibility composition for read-only device evidence views."""
from __future__ import annotations

from overlay_feature.settings_access_log_mixin import (
    OverlaySettingsAccessLogMixin,
)
from overlay_feature.settings_device_list_mixin import (
    OverlaySettingsDeviceListMixin,
)
from overlay_feature.settings_remote_qr_mixin import (
    OverlaySettingsRemoteQrMixin,
)


class OverlaySettingsDeviceViewsMixin(
    OverlaySettingsDeviceListMixin,
    OverlaySettingsAccessLogMixin,
    OverlaySettingsRemoteQrMixin,
):
    """Keep the historical class while each evidence window evolves alone."""


__all__ = ["OverlaySettingsDeviceViewsMixin"]
