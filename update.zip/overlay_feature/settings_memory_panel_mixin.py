# -*- coding: utf-8 -*-
"""Memory archive presentation for the maintenance settings page."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsMemoryPanelMixin:
    """Render the memory summary and its two historical actions."""

    def build_memory_panel(self, parent) -> None:
        self._group(parent, "集中记忆")
        row = self._row(parent, "记忆归档")
        self.memory_label = self.tk.Label(
            row,
            text=self.memory_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.memory_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "查看", self.open_memory_archive).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "归档", self.do_memory_archive).pack(
            side="right", padx=2
        )
        self.tk.Label(
            parent,
            text="只有你说「集中记忆归档」或点「归档」才会生成；"
                 "说「查看记忆归档」只打开上一次的，不会自动重建",
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        ).pack(fill="x", padx=(14, 10), pady=(0, 4))


__all__ = ["OverlaySettingsMemoryPanelMixin"]
