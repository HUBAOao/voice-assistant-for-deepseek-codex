"""Effects and per-element layout controls for the appearance settings page."""
from __future__ import annotations

from ui_widgets import SpinRow
from overlay_feature.defaults import BG_PANEL, DEFAULTS


class OverlaySettingsLayoutMixin:
    def build_effects_and_layout(self, parent) -> None:
        self.tk.Label(
            parent,
            text="声音条特效（各自独立开关；节能模式下会自动关掉）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        self.fx_switches = {}
        for key, label, hint in (
            ("fx_trail", "视觉暂留", "声音条拖一条慢慢淡掉的残影"),
            ("fx_glow", "呼吸光晕", "顺着条的形状往外铺的柔光，跟着声音一明一暗"),
            ("fx_sparkles", "星尘", "说话时溅出去的小亮点"),
            ("fx_reflection", "倒影", "条下面一层淡淡的反光"),
            ("fx_sweep", "流光", "一道高光沿着条扫过去"),
            ("fx_ripple", "波纹", "没声音时，那颗小圆点一圈圈荡开"),
            ("fx_aurora", "极光柔光", "小圆点外面那层光会慢慢换色"),
            ("fx_rotor", "旋转光环", "一圈虚线光环绕着圆点慢慢转"),
            ("fx_orbit", "卫星环绕", "两颗小卫星绕着圆点飞，拖着光尾"),
            ("fx_starflare", "星芒", "十字形的亮光，一明一暗地闪"),
            ("fx_heartbeat", "心跳脉动", "圆点像心跳那样「咚—咚」"),
            ("fx_burst", "唤醒爆闪", "被叫醒的一瞬间炸出一圈小火星"),
        ):
            row = self._row(parent, label)
            self.tk.Label(
                row,
                text=hint,
                bg=BG_PANEL,
                fg="#6f6f7a",
                font=("Microsoft YaHei UI", 8),
            ).pack(side="left", padx=(0, 6))
            switch = self._effect_switch(
                row,
                bool(self.cfg.get(key, DEFAULTS[key])),
                lambda _value, current=key: self.on_fx_change(current),
            )
            self.fx_switches[key] = switch

        self.tk.Label(
            parent,
            text="各元素的位置和大小（负数的 X 表示离右边多远）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=14, pady=(8, 0))
        layout = self.layout
        self.sp_name = self._spin_row(
            parent,
            "名字",
            [
                ("x", "X", layout["name"][0], 4, -200, 800),
                ("y", "Y", layout["name"][1], 2, -80, 400),
                ("s", "字号", layout["name"][2], 1, 8, 48),
            ],
        )
        self.sp_status = self._spin_row(
            parent,
            "状态",
            [
                ("x", "X", layout["status"][0], 4, -800, 800),
                ("y", "Y", layout["status"][1], 2, -80, 400),
                ("s", "字号", layout["status"][2], 1, 8, 40),
            ],
        )
        self.sp_switch = self._spin_row(
            parent,
            "开关",
            [
                ("x", "X", layout["switch"][0], 4, -800, 800),
                ("y", "Y", layout["switch"][1], 2, -80, 400),
            ],
        )
        self.sp_wave = self._spin_row(
            parent,
            "波浪",
            [
                ("y", "距底", layout["wave"][0], 2, 0, 120),
                ("h", "高度", layout["wave"][1], 2, 10, 80),
            ],
        )
        self.sw_show = {}
        for key, label in (
            ("name", "名字"), ("status", "状态"),
            ("line", "波浪"), ("switch", "开关"),
        ):
            self.sw_show[key] = self._switch_row(
                parent,
                "显示" + label,
                bool(self.cfg.get(f"overlay_show_{key}", True)),
            )

    def _effect_switch(self, parent, value: bool, command):
        from ui_widgets import Switch

        switch = Switch(parent, value, on_change=command, bg=BG_PANEL)
        switch.canvas.pack(side="right", padx=(0, 10))
        return switch

    def _spin_row(self, parent, label: str, fields):
        return SpinRow(
            parent,
            label,
            fields,
            on_change=self.on_change,
            bg=BG_PANEL,
        )
