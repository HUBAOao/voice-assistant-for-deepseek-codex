"""Render and save the local phone-link QR without Tk window wiring."""
from __future__ import annotations

from pathlib import Path

from PIL import Image

import qr_tools


def display_qr_image(url: str, max_pixels: int = 264) -> Image.Image:
    """Return a crisp, display-sized QR image for the settings popup."""
    image = qr_tools.qr_image(
        url,
        box=1,
        border=3,
        dark="#101014",
        light="#ffffff",
    )
    scale = max(3, int(max_pixels) // max(1, image.width))
    return image.resize(
        (image.width * scale, image.height * scale),
        Image.NEAREST,
    )


def save_qr_image(url: str, path: str | Path) -> Path:
    """Write the higher-resolution QR used by the explicit save action."""
    target = Path(path)
    qr_tools.qr_image(
        url,
        box=10,
        border=4,
    ).save(target)
    return target


__all__ = ["display_qr_image", "save_qr_image"]
