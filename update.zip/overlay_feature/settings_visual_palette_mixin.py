# -*- coding: utf-8 -*-
"""Style, palette, and background controls for the appearance page."""
from __future__ import annotations

from pathlib import Path

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsVisualPaletteMixin:
    def build_visual_palette(self, parent) -> None:
        row = self._row(parent, "样式")
        self.wave_style_value = self.wave_style
        self.style_chips = {}
        for value, label in (("siri", "波形带"), ("bars", "声波条")):
            chip = self._chip(
                row, label, lambda current=value: self.set_wave_style(current)
            )
            chip.pack(side="left", padx=3)
            self.style_chips[value] = chip
        self.refresh_style_chips()

        row = self._row(parent, "颜色")
        self.sw_color = self._swatch(row, "面板", self.panel_color)
        self.sw_accent = self._swatch(row, "线条", self.accent)
        self.sw_button = self._swatch(row, "按钮", self.button_color)
        self.sw_text = self._swatch(row, "文字", self.text_color)
        row = self._row(parent, "说话色")
        self.sw_talk = self._swatch(row, "我说话时", self.talk_color)
        self.tk.Label(
            row,
            text="朗读时声音条换成这个颜色，形状跟着语音变化",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left", padx=6)

        row = self._row(parent, "背景图")
        self.bg_path = self.cfg.get("overlay_bg_image") or ""
        self.bg_label = self.tk.Label(
            row,
            text=Path(self.bg_path).name if self.bg_path else "无",
            bg=BG_PANEL,
            fg="#9a9aa5",
            width=12,
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.bg_label.pack(side="left", padx=4)
        self._chip(row, "清除", lambda: self.set_bg("")).pack(
            side="right", padx=4
        )
        self._chip(row, "选择", self.pick_bg).pack(side="right")


__all__ = ["OverlaySettingsVisualPaletteMixin"]
