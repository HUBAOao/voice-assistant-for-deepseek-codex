# -*- coding: utf-8 -*-
"""Save, apply and remove persisted settings presets."""
from __future__ import annotations


class OverlayPresetsActionsMixin:
    """Keep preset mutations separate from portable-file transfer."""

    def save_preset(self) -> None:
        def done(name: str) -> None:
            if not name:
                return
            data = self.collect()
            presets = dict(data.get("presets") or {})
            presets[name] = {
                key: value for key, value in data.items() if key != "presets"
            }
            data["presets"] = presets
            self._preset_write(data)
            self.refresh_presets()
            self.flash(f"已存为预设「{name}」", 2.4)

        self.edit_text("预设名称", "", done)

    def apply_preset(self, name: str) -> None:
        data = self._preset_load()
        preset = (data.get("presets") or {}).get(name) or {}
        data.update(preset)
        self._preset_write(data)
        self.cfg = data
        owner = self._preset_owner()
        config = getattr(owner, "CONFIG", None)
        if config is not None:
            try:
                self.cfg_mtime = config.stat().st_mtime
            except OSError:
                pass
        self.apply_saved()
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None
            self.build_panel()
            self._place_panel(self._expanded_h())
        self.flash(f"已套用预设「{name}」", 2.4)

    def remove_preset(self, name: str) -> None:
        data = self._preset_load()
        presets = dict(data.get("presets") or {})
        presets.pop(name, None)
        data["presets"] = presets
        self._preset_write(data)
        self.refresh_presets()
        self.flash(f"已删除预设「{name}」", 2)


__all__ = ["OverlayPresetsActionsMixin"]
