# -*- coding: utf-8 -*-
"""Compatibility entrypoint for the overlay settings composition."""
from __future__ import annotations

from overlay_feature.settings_navigation_mixin import (
    OverlaySettingsNavigationMixin,
)
from overlay_feature.settings_shell_mixin import (
    OverlaySettingsShellMixin,
    send_command,
)


class OverlaySettingsMixin(
    OverlaySettingsShellMixin,
    OverlaySettingsNavigationMixin,
):
    """Keep the historical import while the shell lives in its own boundary."""


__all__ = ["OverlaySettingsMixin", "send_command"]

