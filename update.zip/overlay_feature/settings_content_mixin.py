# -*- coding: utf-8 -*-
"""Audio, appearance and shared row controls for the overlay settings panel."""
from __future__ import annotations

from ui_widgets import Switch
from overlay_feature import panel_controls as _controls
from overlay_feature.settings_audio_mixin import OverlaySettingsAudioMixin
from overlay_feature.settings_voice_mixin import OverlaySettingsVoiceMixin


class OverlaySettingsContentMixin(
    OverlaySettingsAudioMixin,
    OverlaySettingsVoiceMixin,
):
    """Historical composition entry; sound and voice stay independently testable."""

    def _group(self, parent, title: str) -> None:
        _controls.group(self.tk, parent, title, self.accent)

    def _row(self, parent, label):
        return _controls.row(self.tk, parent, label)

    def _chip(self, parent, text, command):
        return _controls.chip(self.tk, parent, text, command)

    def _switch_row(self, parent, label, value, on_change=None):
        return _controls.switch_row(
            self.tk,
            parent,
            label,
            value,
            on_change or (lambda _value: self.on_change()),
            Switch,
        )

    def _swatch(self, parent, label, color):
        return _controls.swatch(
            self.tk,
            parent,
            label,
            color,
            self.on_change,
        )
