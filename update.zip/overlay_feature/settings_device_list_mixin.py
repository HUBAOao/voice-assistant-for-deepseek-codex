"""Allowed and pending phone devices shown by the settings panel."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import inputlog
from overlay_feature.settings_device_groups_mixin import (
    OverlaySettingsDeviceGroupsMixin,
)


class OverlaySettingsDeviceListMixin(OverlaySettingsDeviceGroupsMixin):
    """Render trusted-device evidence without making admission decisions."""

    def show_device_list(self) -> None:
        """能连这台电脑的设备名单：谁允许过、谁在等你确认。"""
        tk = self.tk
        try:
            import phone_link
        except Exception as exc:  # noqa: BLE001
            self.flash("读设备名单失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("能连这台电脑的设备")
        win.configure(bg=BG_PANEL)
        win.geometry("440x540")
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 440) // 2
            y = self.root.winfo_y() + 40
            win.geometry("440x540+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            pass
        tk.Label(
            win,
            text="能连这台电脑的设备",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(12, 2))
        tk.Label(
            win,
            text="每台设备第一次连都得你在这儿点一次「允许」。\n"
            "不是你自己的设备（或者号码对不上手机屏幕）就点「拒绝」。\n"
            "同一台手机可能占好几条（页面 / APP 后台 / 换个网就是新的一条），"
            "都点允许就行。",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=390,
            justify="center",
        ).pack(padx=12)
        info = tk.Label(
            win,
            text="",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 9),
        )
        info.pack(pady=(8, 2))
        holder = tk.Frame(win, bg=BG_PANEL)
        holder.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        def redraw() -> None:
            for widget in holder.winfo_children():
                widget.destroy()
            self._draw_device_groups(holder, info, redraw)

        redraw()
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(0, 10))
        self._chip(
            buttons,
            "全部清除",
            lambda: (self.forget_devices(), redraw()),
        ).pack(side="left", padx=4)
        self._chip(
            buttons,
            "连接记录",
            lambda: self.show_access_log(),
        ).pack(side="left", padx=4)
        self._chip(
            buttons,
            "关掉",
            lambda: win.destroy(),
        ).pack(side="left", padx=4)
        inputlog("点了「设备名单」")


__all__ = ["OverlaySettingsDeviceListMixin"]
