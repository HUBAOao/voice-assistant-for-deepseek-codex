# -*- coding: utf-8 -*-
"""Non-blocking voice cycling and audio preview."""
from __future__ import annotations

import threading

from overlay_feature.defaults import VOICES


class OverlaySettingsVoicePreviewMixin:
    def cycle_voice(self, step: int) -> None:
        self.voice_index = (self.voice_index + step) % len(VOICES)
        self.voice_label.config(text=self._voice_text())
        self.on_change()

    def preview_voice(self, idx: int | None = None) -> None:
        """Preview a voice without blocking the overlay event loop."""
        if idx is not None:
            self.select_voice(int(idx))
        voice, label, pitch, fx = VOICES[self.voice_index]
        label = label.split(" · ")[0]
        volume, rate = int(self.sl_volume.get()), int(self.sl_rate.get())

        def run() -> None:
            try:
                import say

                text = f"你好，我是{label}。以后就用这个声音跟你说话。"
                if say.is_clone(voice):
                    got = say.clone_audio(text, voice, f"{rate:+d}%")
                    if got is None:
                        self.root.after(
                            0,
                            lambda: self.flash("克隆音色这会儿用不了，看日志"),
                        )
                        return
                    audio, sr = got
                    if volume < 100:
                        audio = audio * max(0.0, min(1.0, volume / 100))
                    say.play(audio, sr)
                    return
                say.PITCH[0] = pitch
                mp3 = say.edge_mp3(text, voice, f"{rate:+d}%")
                audio, sr = say.decode_audio(mp3)
                audio = say.apply_fx(audio, sr, fx)
                if volume < 100:
                    audio = audio * max(0.0, min(1.0, volume / 100))
                say.play(audio, sr)
            except Exception as exc:  # noqa: BLE001
                why = str(exc)[:24]
                self.root.after(
                    0,
                    lambda w=why: self.flash(f"试听失败：{w}"),
                )

        threading.Thread(target=run, daemon=True).start()
