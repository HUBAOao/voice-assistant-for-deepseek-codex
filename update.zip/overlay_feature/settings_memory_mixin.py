# -*- coding: utf-8 -*-
"""Explicit memory archive actions; the read-only viewer stays separate."""
from __future__ import annotations

import threading

import memory_archive
from overlay_feature.settings_memory_viewer_mixin import (
    OverlaySettingsMemoryViewerMixin,
)


class OverlaySettingsMemoryMixin(OverlaySettingsMemoryViewerMixin):
    def memory_summary(self) -> str:
        try:
            info = memory_archive.summary()
        except Exception:
            info = None
        if not info:
            return "还没有归档 · 说「集中记忆归档」或点「归档」"
        stats = info.get("stats") or {}
        return (
            f"上次 {info.get('generated_at', '')} · "
            f"{stats.get('threads', 0)} 个会话 / "
            f"{stats.get('user_messages', 0)} 条你的话"
        )

    def do_memory_archive(self) -> None:
        """Archive only after an explicit button press."""
        self.flash("正在把所有对话的记忆归档…", 3)

        def job() -> None:
            try:
                info = memory_archive.build_archive()
                message = memory_archive.describe(info)
            except Exception as exc:  # noqa: BLE001
                message = f"归档没成功：{exc}"

            def done() -> None:
                self.flash(message, 4)
                try:
                    self.memory_label.config(text=self.memory_summary())
                except Exception:
                    pass
                if getattr(self, "memory_win", None) is not None:
                    try:
                        if self.memory_win.winfo_exists():
                            self.load_memory_text()
                    except Exception:
                        pass

            try:
                self.root.after(0, done)
            except Exception:
                pass

        threading.Thread(target=job, daemon=True).start()
