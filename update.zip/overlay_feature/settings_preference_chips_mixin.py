# -*- coding: utf-8 -*-
"""Autostart and preference-chip interactions for the settings panel."""
from __future__ import annotations

import subprocess
from pathlib import Path

from overlay_feature.defaults import CARD


HERE = Path(__file__).resolve().parent.parent


class OverlaySettingsPreferenceChipsMixin:
    def set_autostart(self, value: bool) -> None:
        script = HERE / "autostart.ps1"
        if script.exists():
            subprocess.Popen(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                    "-AppDir",
                    str(HERE),
                    "-Action",
                    "on" if value else "off",
                ],
                creationflags=0x08000000,
            )
        self.flash("开机自启：" + ("开" if value else "关"))

    def set_wave_style(self, value: str) -> None:
        self.wave_style_value = value
        self.wave_style = value
        self.refresh_style_chips()
        self.on_change()

    def set_perf(self, value: str) -> None:
        self.perf_value = value
        self.perf = value
        self.refresh_perf_chips()
        if value == "eco":
            self.sl_anim.set(20)
        elif value == "quality":
            self.sl_anim.set(60)
        self.on_change()

    def refresh_perf_chips(self) -> None:
        for value, chip in getattr(self, "perf_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.perf_value else CARD,
                fg="#ffffff",
            )

    def set_name_freq(self, value: str) -> None:
        self.name_freq_value = value
        self.refresh_name_freq()
        self.on_change()

    def refresh_name_freq(self) -> None:
        for value, chip in getattr(self, "name_freq_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.name_freq_value else CARD,
                fg="#ffffff",
            )

    def set_self_freq(self, value: str) -> None:
        self.self_freq_value = value
        self.refresh_self_freq()
        self.on_change()

    def refresh_self_freq(self) -> None:
        for value, chip in getattr(self, "self_freq_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.self_freq_value else CARD,
                fg="#ffffff",
            )

    def refresh_style_chips(self) -> None:
        for value, chip in getattr(self, "style_chips", {}).items():
            chip.config(
                bg=self.button_color if value == self.wave_style_value else CARD,
                fg="#ffffff",
            )


__all__ = ["OverlaySettingsPreferenceChipsMixin"]
