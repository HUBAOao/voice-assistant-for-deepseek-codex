"""Render grouped device trust evidence inside the device-list window."""
from __future__ import annotations

import time

from overlay_feature.defaults import BG_PANEL, CARD


class OverlaySettingsDeviceGroupsMixin:
    """Keep group cards and their explicit actions separate from window setup."""

    def _draw_device_groups(self, holder, info, redraw) -> None:
        tk = self.tk
        try:
            import phone_link

            groups = phone_link.device_groups()
        except Exception:  # noqa: BLE001
            groups = []
        pend_n = sum(1 for group in groups if group.get("pending"))
        info.config(
            text="%d 台设备 · 等你确认 %d 台"
            % (len(groups), pend_n)
        )
        if not groups:
            tk.Label(
                holder,
                text="现在一台都没有。\n"
                "手机上扫码连一次，名单里就会冒出来。",
                bg=BG_PANEL,
                fg="#9a9aa5",
                font=("Microsoft YaHei UI", 9),
            ).pack(pady=16)
            return

        def card(group: dict) -> None:
            pending = bool(group.get("pending"))
            ids = group.get("ids") or []
            frame = tk.Frame(holder, bg=CARD)
            frame.pack(fill="x", pady=3)
            codes = " / ".join(
                code for code in (group.get("codes") or []) if code
            )
            head = (
                "⏳ 等你确认 · 号码 %s" % codes
                if pending
                else "✅ 已允许"
            )
            if len(ids) > 1:
                head += "  ·  %d 个入口" % len(ids)
            tk.Label(
                frame,
                text=head,
                bg=CARD,
                fg="#ffd166" if pending else "#3ddc84",
                font=("Microsoft YaHei UI", 9, "bold"),
            ).pack(anchor="w", padx=10, pady=(7, 0))
            last = float(group.get("last") or 0)
            tk.Label(
                frame,
                text="%s\n来源 %s · 最后 %s"
                % (
                    group.get("name") or "（认不出）",
                    group.get("ip") or "—",
                    time.strftime(
                        "%m-%d %H:%M",
                        time.localtime(last),
                    )
                    if last
                    else "—",
                ),
                bg=CARD,
                fg="#c9cdd3",
                font=("Microsoft YaHei UI", 9),
                justify="left",
                wraplength=385,
            ).pack(anchor="w", padx=10)
            for item in group.get("items") or []:
                try:
                    item_name = phone_link.device_name(
                        item.get("ua"),
                        item.get("ip"),
                    )
                except Exception:  # noqa: BLE001
                    item_name = "?"
                tk.Label(
                    frame,
                    text="· %s   %s"
                    % (item_name, str(item.get("ua") or "")[:52]),
                    bg=CARD,
                    fg="#6f6f7a",
                    font=("Microsoft YaHei UI", 7),
                    justify="left",
                    wraplength=385,
                ).pack(anchor="w", padx=10)
            buttons = tk.Frame(frame, bg=CARD)
            buttons.pack(anchor="e", padx=8, pady=(2, 7))

            def do(action) -> None:
                try:
                    action()
                except Exception as exc:  # noqa: BLE001
                    self.flash("操作失败：%s" % exc, 4)
                redraw()
                self.refresh_devices_label()

            if pending:
                self._chip(
                    buttons,
                    "允许",
                    lambda group_ids=ids: do(
                        lambda: phone_link.group_allow(group_ids)
                    ),
                ).pack(side="left", padx=3)
                self._chip(
                    buttons,
                    "拒绝",
                    lambda group_ids=ids: do(
                        lambda: phone_link.group_deny(group_ids)
                    ),
                ).pack(side="left", padx=3)
            else:
                self._chip(
                    buttons,
                    "移除（下次要重新确认）",
                    lambda group_ids=ids: do(
                        lambda: phone_link.group_revoke(group_ids)
                    ),
                ).pack(side="left", padx=3)

        for group in groups:
            card(group)


__all__ = ["OverlaySettingsDeviceGroupsMixin"]
