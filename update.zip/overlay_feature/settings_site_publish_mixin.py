"""User-confirmed website publishing dialog for the settings panel."""

from __future__ import annotations

import threading

from overlay_feature.defaults import BG_PANEL, CARD


class OverlaySettingsSitePublishMixin:
    """Keep the publish dialog out of shortcut editing and QR presentation."""

    def publish_site(self) -> None:
        """Publish the download page after an explicit user confirmation."""
        import site_publish

        tk = self.tk
        cur_repo = site_publish.repo_url()
        win = tk.Toplevel(self.root)
        win.title("发布下载页到网站")
        win.configure(bg=BG_PANEL)
        win.geometry("560x330")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(
            win,
            text="发布到网站（免费静态托管）",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(anchor="w", padx=18, pady=(14, 2))
        tk.Label(
            win,
            text="第一次：先在 github.com 建一个空仓库（Public），"
            "把它的 https 地址\n贴到下面；点「发布」会弹一次登录，登完就记住了。\n"
            "以后每次更新，打包时会**自动**重新生成并推上去。",
            bg=BG_PANEL,
            fg="#8a8a95",
            font=("Microsoft YaHei UI", 9),
            justify="left",
        ).pack(anchor="w", padx=18)
        tk.Label(
            win,
            text="仓库地址（https://github.com/用户名/仓库名.git）",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=18, pady=(12, 2))
        repo_var = tk.StringVar(value=cur_repo)
        tk.Entry(
            win,
            textvariable=repo_var,
            bg=CARD,
            fg="#ffffff",
            relief="flat",
            insertbackground="#ffffff",
            font=("Consolas", 10),
        ).pack(fill="x", padx=18, ipady=6)
        tk.Label(
            win,
            text="网站网址（发布成功后填，形如 https://用户名.github.io/仓库名/）",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=18, pady=(10, 2))
        url_var = tk.StringVar(value=site_publish.public_url())
        tk.Entry(
            win,
            textvariable=url_var,
            bg=CARD,
            fg="#ffffff",
            relief="flat",
            insertbackground="#ffffff",
            font=("Consolas", 10),
        ).pack(fill="x", padx=18, ipady=6)
        message = tk.Label(
            win,
            text="",
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9),
            wraplength=520,
            justify="left",
        )
        message.pack(anchor="w", padx=18, pady=(10, 0))
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(10, 14))

        def do_publish() -> None:
            repo = repo_var.get().strip()
            url = url_var.get().strip()
            site_publish.configure(repo=repo, url=url)
            message.config(
                text="正在发布…（第一次会弹一个登录窗口，登一次就行）"
            )

            def run() -> None:
                ok, why, _did = site_publish.publish(force=True)
                self.root.after(
                    0,
                    lambda: message.config(
                        text=(
                            "发布成功："
                            + (
                                url
                                or site_publish.public_url()
                                or "（记得填网站网址）"
                            )
                            if ok
                            else "没发上去：" + why
                        ),
                        fg=self.accent if ok else "#ff9a9a",
                    ),
                )
                if ok:
                    self.root.after(
                        0,
                        lambda: self.flash("网站上已经是新版了", 3),
                    )

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(
            bar,
            text="发布",
            bg=self.button_color,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 10, "bold"),
            padx=20,
            pady=6,
            cursor="hand2",
        )
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _event: do_publish())
        close = tk.Label(
            bar,
            text="关掉",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=14,
            pady=6,
            cursor="hand2",
        )
        close.pack(side="right", padx=8)
        close.bind("<Button-1>", lambda _event: win.destroy())


__all__ = ["OverlaySettingsSitePublishMixin"]
