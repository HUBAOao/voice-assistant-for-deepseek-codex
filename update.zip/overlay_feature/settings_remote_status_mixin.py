# -*- coding: utf-8 -*-
"""Read and display remote-access status without mutating the connection."""
from __future__ import annotations

import threading


class OverlaySettingsRemoteStatusMixin:
    """Keep the background status read and main-thread paint in one boundary."""

    def refresh_remote(self) -> None:
        """Refresh the remote status without blocking the settings UI."""
        threading.Thread(target=self._remote_report, daemon=True).start()
        self._remote_poll()

    def _remote_report(self, flash=None) -> None:
        """Read status in the worker and hand the result back to Tk."""
        try:
            import remote_access

            state = remote_access.detail(fresh=True)
            if state["logged_in"]:
                if state.get("funnel_on"):
                    text = (
                        "公网地址已开通 ✅  账号 %s · 设备 %s\n"
                        "手机那边什么都不用装：APP 里「扫码」照一下，"
                        "或直接用浏览器打开\n%s"
                        % (
                            state["account"] or "—",
                            state["device"] or "—",
                            self._masked_url(state["url"]),
                        )
                    )
                else:
                    text = (
                        "已经通了 ✅  账号 %s · 设备 %s\n"
                        "手机在外面：点「复制地址」发到手机上，"
                        "或用 APP 的「扫码」照二维码\n"
                        "%s（固定不变，重启电脑也一样）\n"
                        "想省掉手机上那个 Tailscale：点下面「公网地址 → 开」"
                        % (
                            state["account"] or "—",
                            state["device"] or "—",
                            self._masked_url(state["url"]),
                        )
                    )
                color = "#3ddc84"
            else:
                text = state["why"] or "外网访问现在用不了"
                color = "#e0b050"
            self.remote_fixed_url = state["url"]
            self.remote_fixed_alt = state.get("alt_url", "")
        except Exception as exc:  # noqa: BLE001
            text = "读不到外网状态：%s（点「刷新」再试）" % exc
            color = "#e0b050"
        self._remote_job = (text, color)
        if flash:
            self._remote_flash = flash

    @staticmethod
    def _masked_url(url: str) -> str:
        """Hide the token portion while leaving a recognizable base URL."""
        try:
            at = str(url or "").find("?k=")
            return (
                str(url)[: at + 3] + "…"
                if at > 0
                else str(url or "")
            )
        except Exception:  # noqa: BLE001
            return str(url or "")

    def _remote_poll(self, tries: int = 0) -> None:
        """Paint the worker result on Tk's thread, waiting at most 18 seconds."""
        job = getattr(self, "_remote_job", None)
        if job is not None:
            self._remote_job = None
            try:
                self.remote_label.config(text=job[0], fg=job[1])
            except Exception:  # noqa: BLE001
                pass
            toast = getattr(self, "_remote_flash", None)
            if toast:
                self._remote_flash = None
                self.flash(toast[0], toast[1])
            return
        if tries < 120:
            try:
                self.root.after(
                    150,
                    lambda count=tries + 1: self._remote_poll(count),
                )
            except Exception:  # noqa: BLE001
                pass


__all__ = ["OverlaySettingsRemoteStatusMixin"]
