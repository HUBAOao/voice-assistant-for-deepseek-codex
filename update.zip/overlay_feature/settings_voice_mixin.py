# -*- coding: utf-8 -*-
"""Historical voice-setting composition split into drawer and preview."""
from __future__ import annotations

from overlay_feature.settings_voice_drawer_mixin import (
    OverlaySettingsVoiceDrawerMixin,
)
from overlay_feature.settings_voice_preview_mixin import (
    OverlaySettingsVoicePreviewMixin,
)


class OverlaySettingsVoiceMixin(
    OverlaySettingsVoiceDrawerMixin,
    OverlaySettingsVoicePreviewMixin,
):
    """Keep the public class name while separating UI state from playback."""
