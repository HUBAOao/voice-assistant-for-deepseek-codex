# -*- coding: utf-8 -*-
"""Compatibility composition for the split uninstall settings boundary."""
from __future__ import annotations

from overlay_feature.settings_uninstall_actions_mixin import (
    OverlaySettingsUninstallActionsMixin,
)
from overlay_feature.settings_uninstall_dialog_mixin import (
    OverlaySettingsUninstallDialogMixin,
)


class OverlaySettingsUninstallMixin(
    OverlaySettingsUninstallActionsMixin,
    OverlaySettingsUninstallDialogMixin,
):
    """Keep the historical import while actions and dialog stay independent."""


__all__ = ["OverlaySettingsUninstallMixin"]
