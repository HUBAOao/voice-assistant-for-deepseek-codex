# -*- coding: utf-8 -*-
"""Maintenance settings view; backup and memory actions are separate."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsMaintenanceMixin:
    def build_maintenance(self, parent) -> None:
        """Build maintenance settings without owning their actions."""
        self._group(parent, "集中记忆")
        row = self._row(parent, "记忆归档")
        self.memory_label = self.tk.Label(
            row,
            text=self.memory_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.memory_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "查看", self.open_memory_archive).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "归档", self.do_memory_archive).pack(
            side="right", padx=2
        )
        self.tk.Label(
            parent,
            text="只有你说「集中记忆归档」或点「归档」才会生成；"
                 "说「查看记忆归档」只打开上一次的，不会自动重建",
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        ).pack(fill="x", padx=(14, 10), pady=(0, 4))

        self._group(parent, "数据与排查")
        self.entry_city = self._entry(
            parent, "天气城市", self.cfg.get("weather_city") or ""
        )
        row = self._row(parent, "数据")
        self._chip(row, "导出", self.do_export).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "导入", self.do_import).pack(side="right", padx=2)
        self._chip(row, "清空", self.ask_clear).pack(side="right", padx=2)
        row = self._row(parent, "备份与诊断")
        self._chip(row, "打包诊断", self.do_diagnose).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "打开文件夹", self.open_backup_dir).pack(
            side="right", padx=2
        )
        self.backup_label = self.tk.Label(
            parent,
            text=self.backup_summary(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            anchor="w",
            justify="left",
            wraplength=max(220, self.expand_w - 40),
            font=("Microsoft YaHei UI", 8),
        )
        self.backup_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(parent, "系统日志")
        self.log_label = self.tk.Label(
            row,
            text=self.log_summary(),
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            font=("Microsoft YaHei UI", 8),
        )
        self.log_label.pack(side="left", fill="x", expand=True)
        self._chip(row, "记事本", self.open_syslog).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "查看", self.open_log_window).pack(
            side="right", padx=2
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(
            row,
            text="你急它偏暖、你轻它偏灰；两分钟没人理就打哈欠、四分钟打盹；"
                 "音浪＝声音条变频谱柱；跟读＝它念到哪个字哪个字亮；"
                 "大字幕＝屏幕底部一条大字",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        self._group(parent, "卸载")
        row = self._row(parent, "卸载")
        self._chip(row, "卸载鳍舱…", self.ask_uninstall).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            parent,
            text="会先问你：只卸运行环境和模型（聊天记录留着），"
                 "还是连程序带记录一起删干净",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 6))
