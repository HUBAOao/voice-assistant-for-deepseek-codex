# -*- coding: utf-8 -*-
"""Compatibility composition for the maintenance settings panels."""
from __future__ import annotations

from overlay_feature.settings_data_panel_mixin import (
    OverlaySettingsDataPanelMixin,
)
from overlay_feature.settings_memory_panel_mixin import (
    OverlaySettingsMemoryPanelMixin,
)
from overlay_feature.settings_uninstall_panel_mixin import (
    OverlaySettingsUninstallPanelMixin,
)


class OverlaySettingsMaintenanceMixin(
    OverlaySettingsMemoryPanelMixin,
    OverlaySettingsDataPanelMixin,
    OverlaySettingsUninstallPanelMixin,
):
    """Keep the historical class and panel order as a small composition."""

    def build_maintenance(self, parent) -> None:
        self.build_memory_panel(parent)
        self.build_data_panel(parent)
        self.build_uninstall_panel(parent)


__all__ = ["OverlaySettingsMaintenanceMixin"]
