"""Uninstall confirmation dialog with the original two-tap full-delete guard."""
from __future__ import annotations

from pathlib import Path

from overlay_feature.defaults import BG_PANEL, CARD


HERE = Path(__file__).resolve().parents[1]


class OverlaySettingsUninstallDialogMixin:
    """Render uninstall choices while actions stay in their own boundary."""

    def ask_uninstall(self) -> None:
        """Offer keep-data and full-delete flows; full delete needs two taps."""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("卸载鳍舱")
        win.configure(bg=BG_PANEL)
        win.geometry("456x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(
            win,
            text="卸载鳍舱",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(
            win,
            justify="left",
            anchor="w",
            bg=BG_PANEL,
            fg="#9a9aa5",
            wraplength=400,
            font=("Microsoft YaHei UI", 8),
            text="不管选哪个，都会先关掉后台的鳍舱、取消开机自启、"
            "删掉桌面和开始菜单里指向本程序的快捷方式。\n"
            f"程序目录：{HERE}",
        ).pack(anchor="w", padx=16)

        card = tk.Frame(win, bg=CARD)
        card.pack(fill="x", padx=16, pady=10)
        tk.Label(
            card,
            text="删掉 .venv 运行环境、识别模型、日志（省几个 G）；"
            "程序文件、设置、聊天记录都留着，以后想用重跑一次 setup.cmd 就行",
            bg=CARD,
            fg="#c9c9d6",
            justify="left",
            anchor="w",
            wraplength=370,
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=12, pady=(8, 0))
        keep = tk.Label(
            card,
            text="① 卸载（保留我的记录）",
            bg=self.button_color,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 10, "bold"),
            pady=8,
            cursor="hand2",
        )
        keep.pack(fill="x", padx=12, pady=(6, 10))

        warning = tk.Label(
            win,
            text="整个文件夹连聊天记录、日记、记账一起删干净，删完找不回来",
            bg=BG_PANEL,
            fg="#9a9aa5",
            justify="left",
            anchor="w",
            wraplength=400,
            font=("Microsoft YaHei UI", 8),
        )
        warning.pack(anchor="w", padx=16)
        full = tk.Label(
            win,
            text="② 彻底删除（连程序和记录一起清掉）",
            bg=CARD,
            fg="#ff8080",
            font=("Microsoft YaHei UI", 10, "bold"),
            pady=8,
            cursor="hand2",
        )
        full.pack(fill="x", padx=16, pady=(6, 4))
        armed = {"on": False}

        def pick_keep(_event=None) -> None:
            win.destroy()
            self.do_uninstall(False)

        def pick_full(_event=None) -> None:
            if not armed["on"]:
                armed["on"] = True
                full.config(
                    text="真的要全删？再点一次就动手",
                    bg="#7a1f1f",
                )
                warning.config(
                    text="连聊天记录和设置一起删，没有回收站，删完就真没了",
                    fg="#ff8080",
                )
                return
            win.destroy()
            self.do_uninstall(True)

        def pick_cancel(_event=None) -> None:
            win.destroy()
            self.flash("没卸，什么都没动", 2)

        keep.bind("<Button-1>", pick_keep)
        full.bind("<Button-1>", pick_full)
        keep.bind(
            "<Enter>",
            lambda _event: keep.config(bg=self.accent),
        )
        keep.bind(
            "<Leave>",
            lambda _event: keep.config(bg=self.button_color),
        )
        full.bind(
            "<Enter>",
            lambda _event: full.config(
                bg="#5a1717" if armed["on"] else "#2c2c36"
            ),
        )
        full.bind(
            "<Leave>",
            lambda _event: full.config(
                bg="#7a1f1f" if armed["on"] else CARD
            ),
        )
        cancel = tk.Label(
            win,
            text="先不卸了",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 9),
            cursor="hand2",
        )
        cancel.pack(pady=(2, 10))
        cancel.bind("<Button-1>", pick_cancel)
        win.bind("<Escape>", pick_cancel)
        try:
            win.lift()
            win.focus_force()
        except Exception:
            pass


__all__ = ["OverlaySettingsUninstallDialogMixin"]
