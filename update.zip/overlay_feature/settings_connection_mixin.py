# -*- coding: utf-8 -*-
"""Phone, remote access and device controls for the settings panel."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import CONTROL
from overlay_feature import runtime as _runtime
from overlay_feature.settings_recognition_mixin import (
    OverlaySettingsRecognitionMixin,
)


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsConnectionMixin(OverlaySettingsRecognitionMixin):
    """Build connection controls while keeping the historical recognition entry."""

    def build_connection_controls(self, parent) -> None:
        self.build_phone_connection_controls(parent)
        self.build_recognition_controls(parent)

    def build_phone_connection_controls(self, parent) -> None:
        self.sw_phone = self._switch_row(
            parent,
            "手机入口",
            bool(self.cfg.get("phone_enabled", True)),
        )
        row = self._row(parent, "手机网址")
        try:
            import phone_link

            url_now = phone_link.phone_url(
                int(self.cfg.get("phone_port") or 8765)
            )
        except Exception:
            url_now = "（读不到网卡地址，重启后再看）"
        self.phone_url_label = self.tk.Label(
            row,
            text=url_now,
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        )
        self.phone_url_label.pack(side="left", padx=(0, 6))
        self._chip(row, "复制", lambda: self.copy_phone_url()).pack(side="right")
        self._chip(row, "二维码", lambda: self.show_qr()).pack(
            side="right", padx=(0, 6)
        )
        self.tk.Label(
            parent,
            text="手机连同一个 Wi-Fi，浏览器打开这条网址就行；"
                 "出门在外面要用，点下面「外网访问」的一键开启",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
            wraplength=360,
            justify="left",
        ).pack(anchor="w", padx=14, pady=(0, 4))

        self._group(parent, "外网访问（在外面也能连）")
        self.remote_label = self.tk.Label(
            parent,
            text="正在看…",
            bg=BG_PANEL,
            fg="#9a9aa5",
            anchor="w",
            justify="left",
            wraplength=350,
            font=("Microsoft YaHei UI", 8),
        )
        self.remote_label.pack(fill="x", padx=(14, 10), pady=(0, 4))
        row = self._row(parent, "外网访问")
        self._chip(row, "一键开启", self.remote_enable).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "二维码", self.show_remote_qr).pack(
            side="right", padx=2
        )
        self._chip(row, "复制地址", self.copy_remote_url).pack(
            side="right", padx=2
        )
        self._chip(row, "刷新", self.refresh_remote).pack(
            side="right", padx=2
        )
        row = self._row(parent, "公网地址")
        self._chip(row, "开（手机免装）", self.remote_funnel_on).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "复制", self.copy_public_url).pack(
            side="right", padx=2
        )
        self._chip(row, "关掉", self.remote_funnel_off).pack(
            side="right", padx=2
        )

        row = self._row(parent, "能连的设备")
        self.devices_label = self.tk.Label(
            row,
            text="…",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        )
        self.devices_label.pack(side="left")
        self._chip(row, "名单", self.show_device_list).pack(
            side="right", padx=(4, 10)
        )
        self._chip(row, "连接记录", self.show_access_log).pack(
            side="right", padx=2
        )
        row = self._row(parent, "手机令牌")
        self._chip(row, "换一条", self.rotate_phone_token).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            row,
            text="怕链接泄漏了就换",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self.refresh_devices_label()
