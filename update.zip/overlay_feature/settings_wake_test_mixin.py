# -*- coding: utf-8 -*-
"""Wake-word self-test command and result polling."""
from __future__ import annotations

import json
import time

from overlay_feature.runtime import CONTROL, WAKE_TEST_FILE
from overlay_feature import runtime as _runtime


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


class OverlaySettingsWakeTestMixin:
    """Request and display a self-test without owning level rendering."""

    def run_wake_test(self) -> None:
        send_command("wake-test")
        self.wake_test_at = time.time()
        self.wake_test_result = ""
        self.update_level_info(
            "正在自检唤醒词…（会合成几段语音试一遍，稍后念出结果）",
            "#c9c9d6",
        )
        self.flash("正在自检唤醒词…", 3)

    def poll_wake_test(self) -> None:
        try:
            data = json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_wake_test_ts", 0.0):
            return
        self._wake_test_ts = ts
        self.wake_test_result = str(data.get("summary") or "")
        if self.wake_test_result:
            self.flash(self.wake_test_result, 4.5)
            self.update_level_info()


__all__ = ["OverlaySettingsWakeTestMixin", "send_command"]
