"""Compatibility composition for device trust settings."""
from __future__ import annotations

from overlay_feature.settings_device_actions_mixin import (
    OverlaySettingsDeviceActionsMixin,
)
from overlay_feature.settings_device_views_mixin import (
    OverlaySettingsDeviceViewsMixin,
)


class OverlaySettingsDevicesMixin(
    OverlaySettingsDeviceActionsMixin,
    OverlaySettingsDeviceViewsMixin,
):
    """Keep the historical mixin while separating decisions from evidence views."""


__all__ = ["OverlaySettingsDevicesMixin"]
