"""Device admission, access history and remote QR settings."""
from __future__ import annotations

import os
import time

from PIL import Image, ImageTk

from overlay_feature.defaults import BG_PANEL, CARD
from overlay_feature.runtime import inputlog


class OverlaySettingsDevicesMixin:
    """Keep device trust decisions and their evidence views out of the shell."""

    def check_new_devices(self, force: bool = False) -> None:
        """（每 200ms 被 tick 调一次）有没有新设备在等确认？有就弹窗。"""
        now = time.time()
        if not force and now - getattr(self, "_dev_checked", 0.0) < 2.0:
            return
        self._dev_checked = now
        try:
            import phone_link

            pend = [g for g in phone_link.device_groups() if g.get("pending")]
        except Exception:  # noqa: BLE001
            return
        asked = getattr(self, "_dev_asked", None)
        if asked is None:
            asked = set()
            self._dev_asked = asked
        for grp in pend:
            did = str(grp.get("key") or "") or str(
                (grp.get("ids") or [""])[0]
            )
            if not did or did in asked:
                continue
            asked.add(did)
            self.ask_new_device(grp)

    def ask_new_device(self, rec: dict) -> None:
        """弹窗：有台新设备想连进来，对一下号码再决定。"""
        tk = self.tk
        from tkinter import messagebox

        code = " / ".join(
            [c for c in (rec.get("codes") or []) if c]
        ) or str(rec.get("code") or "")
        ua = str(rec.get("ua") or "")[:70]
        ip = str(rec.get("ip") or "")
        try:
            import phone_link

            nice = str(rec.get("name") or "") or phone_link.device_name(ua, ip)
        except Exception:  # noqa: BLE001
            nice = "（认不出）"
        n = len(rec.get("ids") or [])
        more = (
            "\n（这台手机一共 %d 个入口，一起处理）" % n
            if n > 1
            else ""
        )
        try:
            ok = messagebox.askyesno(
                "有台新设备想连进来",
                "配对号码：%s\n\n设备：%s\n来源：%s%s\n\n让它连吗？\n"
                "（手机屏幕上现在显示的就是这个号码；是你自己的手机才点「是」）"
                % (code, nice, ip or "—", more),
            )
        except Exception:  # noqa: BLE001
            ok = False
        try:
            import phone_link

            ids = rec.get("ids") or []
            if ok:
                phone_link.group_allow(ids)
                self._dev_asked = set()
                self.flash("已允许这台设备（%s）" % code, 4)
            else:
                phone_link.group_deny(ids)
                self.flash("已拒绝这台设备", 4)
        except Exception as exc:  # noqa: BLE001
            self.flash("处理设备确认失败：%s" % exc, 4)
        self.refresh_devices_label()

    def refresh_devices_label(self) -> None:
        """设置里那行“已配对设备”的小字。"""
        try:
            import phone_link

            groups = phone_link.device_groups()
            ok_n = sum(1 for g in groups if not g.get("pending"))
            pend = sum(1 for g in groups if g.get("pending"))
        except Exception:  # noqa: BLE001
            return
        txt = "%d 台设备" % len(groups)
        if ok_n:
            txt += "（已允许 %d 台）" % ok_n
        if pend:
            txt = "%d 台等你确认" % pend
        try:
            self.devices_label.config(text=txt)
        except Exception:  # noqa: BLE001
            pass

    def forget_devices(self) -> None:
        """把设备名单清空：下次谁来都得重新确认一遍。"""
        from tkinter import messagebox

        if not messagebox.askyesno(
            "清空设备名单",
            "清掉之后：所有手机都要重新确认一次。\n"
            "（你自己手机也一样）\n\n要清吗？",
        ):
            return
        try:
            import phone_link

            n = phone_link.device_forget_all()
            self.flash("已清空 %d 台设备" % n, 4)
        except Exception as exc:  # noqa: BLE001
            self.flash("清空失败：%s" % exc, 4)
        self.refresh_devices_label()

    def rotate_phone_token(self) -> None:
        """换一条手机令牌 —— 旧的立刻作废（手机上要重新扫一次码）。"""
        from tkinter import messagebox

        if not messagebox.askyesno(
            "换一条手机令牌",
            "什么时候用得着：你怀疑那条链接被泄漏了。\n\n"
            "换过之后：\n· 旧链接立刻失效（谁拿着都没用）\n"
            "· **你自己的手机也要重新扫一次码**\n"
            "· 已经配对的设备不受影响\n\n要换吗？",
        ):
            return
        try:
            import phone_link

            phone_link.rotate_token()
            phone_link.device_forget_all()
            self.flash("令牌换了 —— 手机上重新扫一次码", 6)
            self.refresh_remote()
            self.refresh_devices_label()
        except Exception as exc:  # noqa: BLE001
            self.flash("换令牌失败：%s" % exc, 5)

    def show_device_list(self) -> None:
        """能连这台电脑的设备名单：谁允许过、谁在等你确认。"""
        tk = self.tk
        try:
            import phone_link
        except Exception as exc:  # noqa: BLE001
            self.flash("读设备名单失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("能连这台电脑的设备")
        win.configure(bg=BG_PANEL)
        win.geometry("440x540")
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 440) // 2
            y = self.root.winfo_y() + 40
            win.geometry("440x540+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            pass
        tk.Label(
            win,
            text="能连这台电脑的设备",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(12, 2))
        tk.Label(
            win,
            text="每台设备第一次连都得你在这儿点一次「允许」。\n"
            "不是你自己的设备（或者号码对不上手机屏幕）就点「拒绝」。\n"
            "同一台手机可能占好几条（页面 / APP 后台 / 换个网就是新的一条），"
            "都点允许就行。",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=390,
            justify="center",
        ).pack(padx=12)
        info = tk.Label(
            win,
            text="",
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 9),
        )
        info.pack(pady=(8, 2))
        holder = tk.Frame(win, bg=BG_PANEL)
        holder.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        def redraw() -> None:
            for widget in holder.winfo_children():
                widget.destroy()
            try:
                groups = phone_link.device_groups()
            except Exception:  # noqa: BLE001
                groups = []
            pend_n = sum(1 for g in groups if g.get("pending"))
            info.config(
                text="%d 台设备 · 等你确认 %d 台" % (len(groups), pend_n)
            )
            if not groups:
                tk.Label(
                    holder,
                    text="现在一台都没有。\n"
                    "手机上扫码连一次，名单里就会冒出来。",
                    bg=BG_PANEL,
                    fg="#9a9aa5",
                    font=("Microsoft YaHei UI", 9),
                ).pack(pady=16)
                return

            def card(grp: dict) -> None:
                pending = bool(grp.get("pending"))
                ids = grp.get("ids") or []
                frame = tk.Frame(holder, bg=CARD)
                frame.pack(fill="x", pady=3)
                codes = " / ".join(
                    [c for c in (grp.get("codes") or []) if c]
                )
                head = (
                    "⏳ 等你确认 · 号码 %s" % codes
                    if pending
                    else "✅ 已允许"
                )
                if len(ids) > 1:
                    head += "  ·  %d 个入口" % len(ids)
                tk.Label(
                    frame,
                    text=head,
                    bg=CARD,
                    fg=("#ffd166" if pending else "#3ddc84"),
                    font=("Microsoft YaHei UI", 9, "bold"),
                ).pack(anchor="w", padx=10, pady=(7, 0))
                last = float(grp.get("last") or 0)
                tk.Label(
                    frame,
                    text="%s\n来源 %s · 最后 %s"
                    % (
                        grp.get("name") or "（认不出）",
                        grp.get("ip") or "—",
                        time.strftime(
                            "%m-%d %H:%M", time.localtime(last)
                        )
                        if last
                        else "—",
                    ),
                    bg=CARD,
                    fg="#c9cdd3",
                    font=("Microsoft YaHei UI", 9),
                    justify="left",
                    wraplength=385,
                ).pack(anchor="w", padx=10)
                for item in grp.get("items") or []:
                    try:
                        item_name = phone_link.device_name(
                            item.get("ua"), item.get("ip")
                        )
                    except Exception:  # noqa: BLE001
                        item_name = "?"
                    tk.Label(
                        frame,
                        text="· %s   %s"
                        % (item_name, str(item.get("ua") or "")[:52]),
                        bg=CARD,
                        fg="#6f6f7a",
                        font=("Microsoft YaHei UI", 7),
                        justify="left",
                        wraplength=385,
                    ).pack(anchor="w", padx=10)
                buttons = tk.Frame(frame, bg=CARD)
                buttons.pack(anchor="e", padx=8, pady=(2, 7))

                def do(fn) -> None:
                    try:
                        fn()
                    except Exception as exc:  # noqa: BLE001
                        self.flash("操作失败：%s" % exc, 4)
                    redraw()
                    self.refresh_devices_label()

                if pending:
                    self._chip(
                        buttons,
                        "允许",
                        lambda g=ids: do(lambda: phone_link.group_allow(g)),
                    ).pack(side="left", padx=3)
                    self._chip(
                        buttons,
                        "拒绝",
                        lambda g=ids: do(lambda: phone_link.group_deny(g)),
                    ).pack(side="left", padx=3)
                else:
                    self._chip(
                        buttons,
                        "移除（下次要重新确认）",
                        lambda g=ids: do(lambda: phone_link.group_revoke(g)),
                    ).pack(side="left", padx=3)

            for grp in groups:
                card(grp)

        redraw()
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(0, 10))
        self._chip(
            buttons,
            "全部清除",
            lambda: (self.forget_devices(), redraw()),
        ).pack(side="left", padx=4)
        self._chip(
            buttons,
            "连接记录",
            lambda: self.show_access_log(),
        ).pack(side="left", padx=4)
        self._chip(
            buttons,
            "关掉",
            lambda: win.destroy(),
        ).pack(side="left", padx=4)
        inputlog("点了「设备名单」")

    def show_access_log(self) -> None:
        """连接记录：谁、什么时候、连上来干了什么。"""
        tk = self.tk
        try:
            import phone_link

            rows = phone_link.access_recent(300)
        except Exception as exc:  # noqa: BLE001
            self.flash("读连接记录失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("连接记录")
        win.configure(bg=BG_PANEL)
        win.geometry("560x480")
        try:
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            pass
        tk.Label(
            win,
            text="连接记录（谁来过、干了什么）",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(10, 0))
        tk.Label(
            win,
            text="「连上」= 有设备连过来 · 「发命令 / 看屏幕 / 取文件」= "
            "它做了什么 · 「新设备」「允许」「拒绝」「封了」= 那道门的事",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=520,
            justify="center",
        ).pack(padx=10)
        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=10, pady=8)
        text = tk.Text(
            body,
            bg="#14141a",
            fg="#d8d8e0",
            insertbackground="#d8d8e0",
            font=("Consolas", 9),
            wrap="none",
            height=20,
            width=62,
            bd=0,
        )
        scroll = tk.Scrollbar(body, command=text.yview)
        text.config(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        lines = []
        for row in rows:
            stamp = time.strftime(
                "%m-%d %H:%M:%S",
                time.localtime(float(row.get("ts") or 0)),
            )
            try:
                who = phone_link.device_name(
                    row.get("ua"), row.get("ip")
                )[:18]
            except Exception:  # noqa: BLE001
                who = (
                    str(row.get("ua") or "").split("(")[0].strip()[:16]
                    or "—"
                )
            lines.append(
                "%s  %-4s  %-16s %s"
                % (
                    stamp,
                    str(row.get("ev") or ""),
                    who,
                    str(row.get("detail") or ""),
                )
            )
        text.insert("1.0", "\n".join(lines) or "（还没有记录）")
        text.config(state="disabled")
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(0, 10))
        self._chip(
            buttons,
            "刷新",
            lambda: (win.destroy(), self.show_access_log()),
        ).pack(side="left", padx=4)

        def open_file() -> None:
            try:
                os.startfile(str(phone_link.ACCESS_FILE))
            except Exception as exc:  # noqa: BLE001
                self.flash("打不开文件：%s" % exc, 4)

        self._chip(buttons, "打开文件", open_file).pack(side="left", padx=4)

        def wipe() -> None:
            from tkinter import messagebox

            if messagebox.askyesno(
                "清空连接记录", "把记录清掉？（设备名单不动）"
            ):
                phone_link.access_clear()
                win.destroy()
                self.show_access_log()

        self._chip(buttons, "清空", wipe).pack(side="left", padx=4)
        self._chip(
            buttons,
            "关掉",
            lambda: win.destroy(),
        ).pack(side="left", padx=4)
        inputlog("点了「连接记录」")

    def show_remote_qr(self) -> None:
        """把外网固定地址也画成二维码 —— 手机 APP 里「扫码」照一下就切过去。"""
        tk = self.tk
        try:
            import remote_access

            state = remote_access.detail(fresh=True)
        except Exception as exc:  # noqa: BLE001
            self.flash("读不到外网地址：%s" % exc, 4)
            return
        url = state.get("url") or ""
        if not url:
            self.flash(
                state.get("why") or "还没有外网地址 —— 先点「一键开启」",
                5,
            )
            return
        import qr_tools

        win = tk.Toplevel(self.root)
        win.title("外网地址二维码")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 340) // 2
            y = self.root.winfo_y() + 40
            win.geometry("340x470+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            win.geometry("340x470")
        tk.Label(
            win,
            text="在外面也能连",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(14, 2))
        tip = (
            "手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就切到公网那条；"
            "手机不用装 Tailscale，后台也不留东西"
            if state.get("funnel_on")
            else "手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就换成外网那条；"
            "前提是手机上装了 Tailscale 并登了电脑上这个账号"
        )
        tk.Label(
            win,
            text=tip,
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=290,
            justify="center",
        ).pack(padx=14)
        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=24, pady=10)
        keep = {"photo": None}
        if not qr_tools.available():
            holder.config(
                image="",
                width=28,
                height=10,
                compound="center",
                fg="#333333",
                font=("Microsoft YaHei UI", 10),
                text="这台机器少一个画二维码的小库",
            )
        else:
            try:
                image = qr_tools.qr_image(
                    url,
                    box=1,
                    border=3,
                    dark="#101014",
                    light="#ffffff",
                )
                factor = max(3, 250 // max(1, image.width))
                image = image.resize(
                    (image.width * factor, image.height * factor),
                    Image.NEAREST,
                )
                keep["photo"] = ImageTk.PhotoImage(image)
                holder.config(
                    image=keep["photo"],
                    text="",
                    width=0,
                    height=0,
                )
                win._va_qr = keep["photo"]
            except Exception as exc:  # noqa: BLE001
                holder.config(
                    image="",
                    text="画不出来：%s" % exc,
                    fg="#333333",
                    width=28,
                    height=10,
                    compound="center",
                )
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(2, 6))
        self._chip(
            buttons,
            "复制地址",
            lambda: self.copy_remote_url(),
        ).pack(side="left", padx=4)
        tk.Label(
            win,
            text=url,
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Consolas", 8),
            wraplength=296,
            justify="center",
        ).pack(padx=14, pady=(4, 2))
        if state.get("account"):
            tk.Label(
                win,
                text="账号：%s" % state["account"],
                bg=BG_PANEL,
                fg="#6f6f7a",
                font=("Microsoft YaHei UI", 8),
            ).pack(pady=(0, 10))
        inputlog("点了「外网地址二维码」")


__all__ = ["OverlaySettingsDevicesMixin"]
