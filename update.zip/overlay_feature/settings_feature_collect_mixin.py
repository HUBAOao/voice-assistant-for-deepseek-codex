# -*- coding: utf-8 -*-
"""Collect feature, reminder, schedule and performance settings."""
from __future__ import annotations

import wake_levels


class OverlaySettingsFeatureCollectMixin:
    """Keep feature-heavy widget collection separate from basic presentation."""

    def collect_feature_settings(self, data: dict) -> dict:
        data.update({
            "followup_seconds": int(self.sl_followup.get()),
            "caption_enabled": self.sw_caption.get(),
            "mood_enabled": self.sw_mood.get(),
            "mood_idle": self.sw_sleepy.get(),
            "wave_spectrum": self.sw_spectrum.get(),
            "karaoke": self.sw_karaoke.get(),
            "diary_enabled": self.sw_diary.get(),
            "big_caption": self.sw_big.get(),
            "screenshot_enabled": self.sw_shot.get(),
            "screen_share": self.sw_share.get(),
            "phone_enabled": self.sw_phone.get(),
            "hourly_chime": self.sw_chime.get(),
            "sit_reminder": self.sw_sit.get(),
            "meeting_mute": self.sw_meeting.get(),
            "read_hotkey": self.sw_hotkey.get(),
            "voiceprint_warn": self.sw_voiceprint.get(),
            "pet_enabled": self.sw_pet.get(),
            "follow_foreground": self.sw_follow.get(),
            "read_reply": self.sw_readreply.get(),
            "rec_indicator": self.sw_rec.get(),
            "weather_city": self.entry_city.get().strip(),
            "send_mode": self.send_mode_value,
            "confirm_send": self.sw_confirm.get(),
            "tray_enabled": self.sw_tray.get(),
            "auto_tune": self.sw_autotune.get(),
            "auto_restart": self.sw_restart.get(),
            "not_heard_reply": self.sw_notheard.get(),
            "voiceprint_gate": self.sw_gate.get(),
            "model": self.model_value,
            "lang": self.lang_value,
            "wake_level": str(
                self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL
            ),
            "wake_levels": self.custom_levels(),
            "reminders_enabled": self.sw_reminder.get(),
            "reminder_paste": self.sw_reminder_paste.get(),
            "shortcuts": self.shortcuts,
            "schedules": self.schedule_panel.entries,
            "schedule_modules": self.schedule_panel.modules,
            "perf_mode": self.perf_value,
            "anim_fps": int(self.sl_anim.get()),
            "wheel_alpha": self.sw_wheel.get(),
            "snap_edges": self.sw_snap.get(),
            **self._fx_to_save(),
        })
        return data

    def _fx_to_save(self) -> dict:
        """Persist effects without overriding a temporary low-power session."""
        fx = {
            key: bool(switch.get())
            for key, switch in getattr(self, "fx_switches", {}).items()
        }
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None)
            if before:
                fx.update(before)
        return fx
