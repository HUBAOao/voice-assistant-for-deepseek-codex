# -*- coding: utf-8 -*-
"""Remote-access controls kept separate from the settings panel layout."""
from __future__ import annotations

import threading

from overlay_feature import runtime as _runtime
from overlay_feature.runtime import INPUT_LOG
from overlay_feature.settings_remote_status_mixin import (
    OverlaySettingsRemoteStatusMixin,
)


class OverlaySettingsRemoteActionsMixin(OverlaySettingsRemoteStatusMixin):
    def copy_phone_url(self) -> None:
        """把手机入口网址塞进剪贴板（手机扫不出码，但可以直接发给自己）。"""
        try:
            url = self.phone_url_now()
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("网址已复制，发到手机上打开就行")
        except Exception:
            self.flash("复制失败，手动抄一下这条网址")

    def phone_url_now(self) -> str:
        """现读一遍手机入口网址（网卡换了、端口改了都会跟着变）。"""
        try:
            import phone_link

            return phone_link.phone_url(
                int(self.cfg.get("phone_port") or 8765)
            )
        except Exception:
            pass
        try:
            return str(self.phone_url_label.cget("text"))
        except Exception:
            return ""

    # ------------------------------------------------ 外网访问（Tailscale，内置的）
    # 状态读取和界面刷新由 status mixin 负责；这里只保留用户主动变更动作。

    def remote_enable(self) -> None:
        """一键开启外网访问：装 → 登 → 显示固定地址。"""
        self.flash(
            "正在弄外网访问，可能要你点一下「是」（装 Tailscale 那一步）…",
            5,
        )

        def work() -> None:
            try:
                import remote_access

                ok, message = remote_access.enable(progress=None)
            except Exception as exc:  # noqa: BLE001
                ok, message = False, "出错了：%s" % exc
            self._remote_report(
                flash=(
                    message if ok else "外网访问没弄成：%s" % message,
                    7,
                )
            )
            try:
                _runtime.inputlog(
                    "点了「一键开启外网访问」",
                    INPUT_LOG,
                )
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def copy_remote_url(self) -> None:
        """把外网那条固定地址塞进剪贴板（发给手机，或者手机扫码）。"""
        try:
            import remote_access

            url = getattr(self, "remote_fixed_url", "") or remote_access.fixed_url()
            if not url:
                self.flash("还没有外网地址 —— 先点「一键开启」", 4)
                return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("外网固定地址已复制，发到手机上就行", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)

    def remote_funnel_on(self) -> None:
        """开公网地址（Funnel）：手机那边连 Tailscale 都不用装。"""
        self.flash(
            "正在开公网地址…（第一次会让你在浏览器里点一次同意）",
            5,
        )

        def work() -> None:
            try:
                import remote_access

                ok, message = remote_access.funnel_enable()
            except Exception as exc:  # noqa: BLE001
                ok, message = False, "出错了：%s" % exc
            self._remote_report(
                flash=(
                    message if ok else "公网地址没开成：%s" % message,
                    8,
                )
            )
            try:
                _runtime.inputlog("点了「开公网地址」", INPUT_LOG)
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def remote_funnel_off(self) -> None:
        """关掉公网地址：回到只有自己登录过的设备能连。"""

        def work() -> None:
            try:
                import remote_access

                _ok, message = remote_access.funnel_disable()
            except Exception as exc:  # noqa: BLE001
                message = "出错了：%s" % exc
            self._remote_report(flash=(message, 5))
            try:
                _runtime.inputlog("点了「关掉公网地址」", INPUT_LOG)
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def copy_public_url(self) -> None:
        """复制公网地址 —— 手机在哪个网下都能打开的那条。"""
        try:
            import remote_access

            url = remote_access.public_url() or ""
            if not url:
                fallback = getattr(self, "remote_fixed_url", "")
                if fallback:
                    url = fallback
                else:
                    self.flash("公网地址还没开 —— 先点「开（手机免装）」", 4)
                    return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("公网地址已复制，发到手机上就能用", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)


__all__ = [
    "OverlaySettingsRemoteActionsMixin",
    "OverlaySettingsRemoteStatusMixin",
]
