"""Compatibility composition for split remote-access settings actions."""
from __future__ import annotations

from overlay_feature.settings_remote_clipboard_mixin import (
    OverlaySettingsRemoteClipboardMixin,
)
from overlay_feature.settings_remote_network_mixin import (
    OverlaySettingsRemoteNetworkMixin,
)
from overlay_feature.settings_remote_status_mixin import (
    OverlaySettingsRemoteStatusMixin,
)


class OverlaySettingsRemoteActionsMixin(
    OverlaySettingsRemoteNetworkMixin,
    OverlaySettingsRemoteClipboardMixin,
    OverlaySettingsRemoteStatusMixin,
):
    """Keep the historical class while clipboard and network stay separate."""


__all__ = [
    "OverlaySettingsRemoteActionsMixin",
    "OverlaySettingsRemoteStatusMixin",
]
