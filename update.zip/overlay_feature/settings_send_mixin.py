# -*- coding: utf-8 -*-
"""Sending and delivery-mode controls for the settings panel."""
from __future__ import annotations


class OverlaySettingsSendMixin:
    """Build the send mode and local delivery switches only."""

    def build_send_controls(self, parent) -> None:
        self._group(parent, "发送")
        row = self._row(parent, "发送方式")
        self.send_mode_value = str(self.cfg.get("send_mode") or "paste_enter")
        self.send_chips = {}
        for value, label in (
            ("paste_enter", "粘贴并回车"),
            ("paste", "只粘贴"),
            ("type", "当打字机"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_send_mode(current),
            )
            chip.pack(side="left", padx=3)
            self.send_chips[value] = chip
        self.refresh_send_chips()
        self.sw_confirm = self._switch_row(
            parent,
            "发之前先问我",
            bool(self.cfg.get("confirm_send", False)),
        )
        self.sw_follow = self._switch_row(
            parent,
            "跟着当前窗口发",
            bool(self.cfg.get("follow_foreground", False)),
        )
        self.sw_readreply = self._switch_row(
            parent,
            "自动念回答",
            bool(self.cfg.get("read_reply", True)),
        )
        self.sw_tray = self._switch_row(
            parent,
            "托盘图标",
            bool(self.cfg.get("tray_enabled", True)),
        )
        self.sw_gate = self._switch_row(
            parent,
            "只认我的声音",
            bool(self.cfg.get("voiceprint_gate", False)),
        )
