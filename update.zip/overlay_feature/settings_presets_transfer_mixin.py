# -*- coding: utf-8 -*-
"""Portable JSON import and export for settings presets."""
from __future__ import annotations

import json
import time
from pathlib import Path


class OverlayPresetsTransferMixin:
    """Keep preset files separate from mutation and chip rendering."""

    def export_presets(self) -> None:
        from tkinter import filedialog

        presets = self._preset_load().get("presets") or {}
        if not presets:
            self.flash("还没有预设可以导出，先点「存为预设」", 3)
            return
        desk = Path.home() / "Desktop"
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="导出预设",
            defaultextension=".json",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            initialfile=f"鳍舱预设-{len(presets)}套.json",
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")],
        )
        if not path:
            return
        payload = {
            "kind": "voice-assistant-presets",
            "version": 1,
            "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "presets": presets,
        }
        try:
            Path(path).write_text(
                json.dumps(payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:  # noqa: BLE001
            self.flash(f"导出失败：{exc}", 4)
            return
        self.flash(f"已导出 {len(presets)} 套预设 → {Path(path).name}", 3.5)
        self._preset_note(f"预设导出到 {path}")

    def import_presets(self) -> None:
        from tkinter import filedialog

        desk = Path.home() / "Desktop"
        path = filedialog.askopenfilename(
            parent=self.root,
            title="导入预设",
            initialdir=str(desk if desk.is_dir() else Path.home()),
            filetypes=[("预设文件", "*.json"), ("所有文件", "*.*")],
        )
        if not path:
            return
        try:
            raw = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            self.flash(f"这个文件读不了：{exc}", 4)
            return
        if isinstance(raw, dict) and isinstance(raw.get("presets"), dict):
            incoming = raw["presets"]
        elif (
            isinstance(raw, dict)
            and raw
            and all(isinstance(value, dict) for value in raw.values())
        ):
            incoming = raw
        else:
            self.flash("这文件里没有预设", 4)
            return
        incoming = {
            str(key)[:40]: value
            for key, value in incoming.items()
            if isinstance(value, dict)
        }
        if not incoming:
            self.flash("这文件里没有预设", 4)
            return
        data = self._preset_load()
        presets = dict(data.get("presets") or {})
        old = set(presets)
        presets.update(incoming)
        data["presets"] = presets
        self._preset_write(data)
        filled = [name for name in incoming if name not in old]
        overwritten = [name for name in incoming if name in old]
        self.refresh_presets()
        result = f"导入 {len(incoming)} 套预设"
        if overwritten:
            result += f"（覆盖了 {len(overwritten)} 套同名）"
        if filled:
            result += f"：{'、'.join(filled[:3])}"
            if len(filled) > 3:
                result += "…"
        self.flash(result, 3.5)
        self._preset_note(
            f"导入预设：新增 {len(filled)} 套、覆盖 {len(overwritten)} 套"
        )


__all__ = ["OverlayPresetsTransferMixin"]
