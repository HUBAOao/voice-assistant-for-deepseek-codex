"""Compatibility entrypoint for desktop update checking and installation."""
from __future__ import annotations

from overlay_feature.settings_update_check_mixin import (
    OverlaySettingsUpdateCheckMixin,
)
from overlay_feature.settings_update_dialog_mixin import (
    OverlaySettingsUpdateDialogMixin,
)


class OverlaySettingsUpdateMixin(
    OverlaySettingsUpdateCheckMixin,
    OverlaySettingsUpdateDialogMixin,
):
    """Keep the historical import while checking and applying stay separate."""


__all__ = ["OverlaySettingsUpdateMixin"]
