"""Uninstall command construction and process launch without dialog layout."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from overlay_feature.runtime import note


HERE = Path(__file__).resolve().parents[1]


class OverlaySettingsUninstallActionsMixin:
    """Build and launch the existing independent uninstaller."""

    def uninstall_command(self, full: bool) -> list[str]:
        """Build the independent uninstaller command used by the UI."""
        cmd_file = HERE / "卸载语音助手.cmd"
        if not cmd_file.exists():
            cmd_file = HERE / "uninstall.cmd"
        if cmd_file.exists():
            return (
                ["cmd", "/c", str(cmd_file), "--yes"]
                + (["--full"] if full else [])
            )
        return (
            [sys.executable, str(HERE / "uninstall.py"), "--yes"]
            + (["--full"] if full else [])
        )

    def do_uninstall(self, full: bool) -> None:
        """Run the uninstaller in its own visible console process."""
        command = self.uninstall_command(full)
        try:
            subprocess.Popen(
                command,
                cwd=str(HERE),
                creationflags=0x00000010,
            )
        except Exception as exc:  # noqa: BLE001
            self.flash(f"卸载程序没起来：{exc}", 5)
            return
        note(
            "从悬浮窗发起卸载："
            + ("彻底删除（连记录）" if full else "卸载（保留记录）")
        )
        self.flash(
            "卸载程序起来了，接下来交给它（后台的我会被它关掉）",
            5,
        )


__all__ = ["OverlaySettingsUninstallActionsMixin"]
