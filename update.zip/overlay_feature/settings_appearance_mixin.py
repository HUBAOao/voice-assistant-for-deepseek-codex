# -*- coding: utf-8 -*-
"""Compatibility composition for text, preferences and appearance actions."""
from __future__ import annotations

from overlay_feature.settings_background_size_mixin import (
    OverlaySettingsBackgroundSizeMixin,
)
from overlay_feature.settings_preference_chips_mixin import (
    OverlaySettingsPreferenceChipsMixin,
)
from overlay_feature.settings_text_input_mixin import (
    OverlaySettingsTextInputMixin,
)


class OverlaySettingsAppearanceMixin(
    OverlaySettingsTextInputMixin,
    OverlaySettingsPreferenceChipsMixin,
    OverlaySettingsBackgroundSizeMixin,
):
    """Keep the historical import while the actions live in three boundaries."""


__all__ = ["OverlaySettingsAppearanceMixin"]
