"""Explicit update actions kept separate from the release-note dialog view."""
from __future__ import annotations

import threading
import webbrowser
from pathlib import Path


HERE = Path(__file__).resolve().parent.parent


class OverlaySettingsUpdateDialogActionsMixin:
    """Open the download page or apply an update without owning the dialog UI."""

    def _open_update_page(self, src: str) -> None:
        try:
            page = src[: -len("version.json")] if src.endswith(
                "version.json"
            ) else src
            webbrowser.open(page)
            self.flash("下载页已经用浏览器打开了", 3)
        except Exception as exc:  # noqa: BLE001
            self.flash(f"打不开浏览器：{exc}", 3)

    def _install_update_from_dialog(
        self,
        pc: dict,
        src: str,
        bar,
        tk,
    ) -> None:
        import self_update

        for child in bar.winfo_children():
            child.destroy()
        tk.Label(
            bar,
            text="正在下载更新包…（下完程序会自己关掉重开）",
            bg=self.update_panel_bg,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9),
        ).pack(side="left")

        def run() -> None:
            url = self_update.resolve(
                src,
                str(pc.get("update_url") or ""),
            )
            ok, why = self_update.apply_update(url, HERE)
            self.root.after(
                0,
                lambda: self.flash(
                    "更新包开始装了，程序会自己重开"
                    if ok
                    else f"更新失败：{why}",
                    4,
                ),
            )

        threading.Thread(target=run, daemon=True).start()


__all__ = ["OverlaySettingsUpdateDialogActionsMixin"]
