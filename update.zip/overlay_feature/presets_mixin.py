# -*- coding: utf-8 -*-
"""Overlay configuration presets and portable preset files."""
from __future__ import annotations

import sys

from overlay_feature.defaults import BG_PANEL, CARD
from overlay_feature.settings_presets_store_mixin import (
    OverlayPresetsStoreMixin,
)


class OverlayPresetsMixin(OverlayPresetsStoreMixin):
    def _preset_owner(self):
        """Resolve callbacks from the owning overlay module.

        Tests replace ``overlay.CONFIG`` and ``overlay.load_config`` after this
        module is imported, so a copied import-time binding would target the
        wrong machine configuration.
        """
        return sys.modules.get(type(self).__module__)

    def _preset_load(self) -> dict:
        owner = self._preset_owner()
        return owner.load_config() if owner is not None else {}

    def _preset_write(self, data: dict) -> None:
        owner = self._preset_owner()
        if owner is not None:
            owner.write_config(data)

    def _preset_note(self, text: str) -> None:
        owner = self._preset_owner()
        if owner is not None:
            owner.note(text)

    def refresh_presets(self) -> None:
        if getattr(self, "preset_bar", None) is None:
            return
        for child in self.preset_bar.winfo_children():
            child.destroy()
        presets = self._preset_load().get("presets") or {}
        if not presets:
            self.tk.Label(self.preset_bar,
                          text="（可以把现在整套设置存成预设，随时切回来）",
                          bg=BG_PANEL, fg="#6f6f7a",
                          font=("Microsoft YaHei UI", 8)).pack(anchor="w")
            return
        for name in presets:
            chip = self.tk.Label(self.preset_bar, text=name[:12], bg=CARD, fg="#ffffff",
                                 padx=10, pady=3, cursor="hand2",
                                 font=("Microsoft YaHei UI", 9))
            chip.pack(side="left", padx=2, pady=1)
            chip.bind("<Button-1>", lambda _e, n=name: self.apply_preset(n))
            chip.bind("<Button-3>", lambda _e, n=name: self.remove_preset(n))
