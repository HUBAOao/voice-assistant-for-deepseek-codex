"""Non-blocking desktop update checks and result presentation."""
from __future__ import annotations

import threading

import version


class OverlaySettingsUpdateCheckMixin:
    def check_update(self) -> None:
        """Check the download-page manifest without blocking the panel."""
        if self.upd_label is not None:
            self.upd_label.config(text="正在检查…", fg="#7f7f8a")
        self.flash("正在检查更新…", 1.6)

        def work() -> None:
            try:
                import self_update

                got = self_update.check(self.cfg)
            except Exception as exc:  # noqa: BLE001
                got = {
                    "ok": False,
                    "err": f"{type(exc).__name__}: {exc}"[:80],
                }
            self.root.after(0, lambda: self._update_result(got))

        threading.Thread(target=work, daemon=True).start()

    def _update_result(self, got: dict) -> None:
        """Report no update, or offer installation when one is available."""
        if not got.get("ok"):
            why = str(got.get("err") or "读不到更新信息")
            if self.upd_label is not None:
                self.upd_label.config(text=why, fg="#ff9a9a")
            self.flash(why, 3)
            return
        pc = got.get("pc") or {}
        if not got.get("pc_new"):
            text = f"已是最新（v{version.APP_VERSION}）"
            if self.upd_label is not None:
                self.upd_label.config(text=text, fg="#7f8f86")
            self.flash(text, 2.4)
            return
        found = str(pc.get("version"))
        if self.upd_label is not None:
            self.upd_label.config(text=f"有新版 v{found}", fg=self.accent)
        self._update_dialog(
            found,
            pc,
            str(got.get("src") or ""),
        )


__all__ = ["OverlaySettingsUpdateCheckMixin"]
