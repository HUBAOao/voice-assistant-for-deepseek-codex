# -*- coding: utf-8 -*-
"""First-run onboarding and retired listening-indicator cleanup."""
from __future__ import annotations

from pathlib import Path

from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import make_no_activate, virtual_screen


HERE = Path(__file__).resolve().parent.parent


class OverlaySettingsOnboardingMixin:
    """Keep one-time onboarding outside the settings shell."""

    def maybe_first_run(self) -> None:
        """第一次用的时候弹一个小引导（三步），看过了就不再弹。"""
        mark = HERE / "first-run.done"
        if mark.exists():
            return
        try:
            mark.write_text("ok", encoding="utf-8")
        except Exception:
            return
        tk = self.tk
        try:
            win = tk.Toplevel(self.root)
        except Exception:
            return
        win.title("第一次用，三步就能上手")
        win.configure(bg=BG_PANEL)
        win.attributes("-topmost", True)
        win.geometry("460x300")
        tk.Label(win, text="三步就能用起来", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 14, "bold")).pack(
                     anchor="w", padx=18, pady=(16, 6)
                 )
        steps = [
            "1. 先确认麦克风：说「自检」，它会告诉你麦克风/模型/窗口/剪贴板有没有问题。",
            "2. 试一句：说「" + str(self.cfg.get("wake_word") or "大肥鱼") +
            "」，听到两声提示音再说话，说完自动发出去。",
            "3. 挑声音：设置 → 声音 → 音色，点「选择」把抽屉拉开，想用哪个直接点哪个"
            "（每行右边还有「听」，一边听一边挑）。",
            "",
            "其它常用的：说「专注25分钟」开番茄钟；「记一下 明天买牛奶」存便签；",
            "「别记这段」让它几分钟不记录；「自检」随时查身体。",
        ]
        for text in steps:
            tk.Label(
                win, text=text, bg=BG_PANEL, fg="#c9c9d6", justify="left",
                font=("Microsoft YaHei UI", 9),
            ).pack(anchor="w", padx=20, pady=1)
        tk.Label(
            win, text="知道了", bg=self.button_color, fg="#ffffff",
            padx=22, pady=6, cursor="hand2",
            font=("Microsoft YaHei UI", 10, "bold"),
        ).pack(pady=14)
        win.winfo_children()[-1].bind(
            "<Button-1>", lambda _event: win.destroy()
        )

    def sync_rec_dot(self) -> None:
        """Retire the old recording dot while retaining the compatibility call."""
        if self.rec_win is not None:
            try:
                self.rec_win.destroy()
            except Exception:
                pass
            self.rec_win = None
        return

        # 保留旧实现所需依赖的导入路径；恢复提示灯时可直接从这里重建。
        live = False
        if live and self.rec_win is None:
            try:
                win = self.tk.Toplevel(self.root)
                win.overrideredirect(True)
                win.title("在听")
                win.attributes("-topmost", True)
                win.configure(bg="#141418")
                label = self.tk.Label(
                    win, text="● 在听", bg="#141418", fg="#ff5c5c",
                    font=("Microsoft YaHei UI", 12, "bold"),
                    padx=12, pady=4,
                )
                label.pack()
                make_no_activate(win.winfo_id())
                vx, vy, vw, vh = virtual_screen()
                win.geometry(f"+{vx + vw - 150}+{vy + vh - 120}")
                self.rec_win = win
            except Exception:
                self.rec_win = None
        elif not live and self.rec_win is not None:
            try:
                self.rec_win.destroy()
            except Exception:
                pass
            self.rec_win = None
