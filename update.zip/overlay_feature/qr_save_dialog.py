"""Explicit save-as action for the local phone-link QR."""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from overlay_feature.qr_presentation import save_qr_image
from overlay_feature.runtime import note


def save_qr_with_dialog(
    parent,
    url: str,
    flash: Callable[[str, float], object],
) -> Path | None:
    """Ask for a PNG path, save there, and preserve the prior user feedback."""
    from tkinter import filedialog

    desktop = Path.home() / "Desktop"
    path = filedialog.asksaveasfilename(
        parent=parent,
        title="保存二维码",
        defaultextension=".png",
        initialdir=str(desktop if desktop.is_dir() else Path.home()),
        initialfile="手机入口二维码.png",
        filetypes=[
            ("PNG 图片", "*.png"),
            ("所有文件", "*.*"),
        ],
    )
    if not path:
        return None
    try:
        target = save_qr_image(url, path)
    except Exception as exc:  # noqa: BLE001
        flash(f"存不了：{exc}", 4)
        return None
    flash(f"二维码存到 {target.name} 了", 3)
    note(f"手机二维码另存到 {target}")
    return target


__all__ = ["save_qr_with_dialog"]
