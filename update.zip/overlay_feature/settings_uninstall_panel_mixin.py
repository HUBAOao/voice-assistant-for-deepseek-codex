# -*- coding: utf-8 -*-
"""Uninstall presentation inside the maintenance settings page."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsUninstallPanelMixin:
    """Render the historical confirmation entry without owning its action."""

    def build_uninstall_panel(self, parent) -> None:
        self._group(parent, "卸载")
        row = self._row(parent, "卸载")
        self._chip(row, "卸载鳍舱…", self.ask_uninstall).pack(
            side="right", padx=(4, 10)
        )
        self.tk.Label(
            parent,
            text="会先问你：只卸运行环境和模型（聊天记录留着），"
                 "还是连程序带记录一起删干净",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 6))


__all__ = ["OverlaySettingsUninstallPanelMixin"]
