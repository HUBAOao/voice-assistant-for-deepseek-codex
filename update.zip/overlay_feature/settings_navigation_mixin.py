# -*- coding: utf-8 -*-
"""Settings tab switching, responsive canvas and wheel navigation."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL, CARD


class OverlaySettingsNavigationMixin:
    """Keep page navigation independent from panel construction."""

    def _on_stage_resize(self, event) -> None:
        """Keep the scrolling content as wide as its viewport."""
        try:
            self.stage.itemconfig(
                self._stage_win, width=max(1, int(event.width))
            )
        except Exception:
            pass
        self._update_scroll_hint()

    def _on_stage_inner(self, _event=None) -> None:
        try:
            self.stage.configure(scrollregion=self.stage.bbox("all"))
        except Exception:
            pass
        self._update_scroll_hint()

    def _update_scroll_hint(self) -> None:
        """Show the narrow indicator only when content exceeds the viewport."""
        bar = getattr(self, "scroll_hint", None)
        stage = getattr(self, "stage_canvas", None)
        if bar is None or stage is None:
            return
        try:
            region = stage.bbox("all")
            view = stage.winfo_height()
            if (
                not region
                or view <= 1
                or region[3] - region[1] <= view + 1
            ):
                bar.place_forget()
                return
            top, bottom = stage.yview()
            height = max(26, int(view * (bottom - top)))
            y = int(stage.winfo_y() + view * top)
            bar.delete("all")
            bar.create_rectangle(
                0, 0, 4, height, fill=self.button_color, outline=""
            )
            bar.place(relx=1.0, x=-6, y=y, width=4, height=height)
        except Exception:
            pass

    def _bind_wheel_tree(self, widget) -> None:
        widget.bind("<MouseWheel>", self.on_panel_wheel, add="+")
        for child in widget.winfo_children():
            self._bind_wheel_tree(child)

    def on_panel_wheel(self, event):
        """Scroll only overflowing content; preserve overlay alpha scrolling."""
        stage = getattr(self, "stage_canvas", None)
        if stage is None:
            return None
        region = stage.bbox("all")
        if (
            not region
            or region[3] - region[1] <= stage.winfo_height() + 1
        ):
            self._update_scroll_hint()
            return None
        stage.yview_scroll(
            -1 if getattr(event, "delta", 0) > 0 else 1, "units"
        )
        self._update_scroll_hint()
        return "break"

    def show_tab(self, name: str) -> None:
        self.current_tab = name
        for key, frame in self.tab_frames.items():
            if key == name:
                frame.pack(fill="both", expand=True)
            else:
                frame.pack_forget()
        stage = getattr(self, "stage_canvas", None)
        if stage is not None:
            try:
                stage.yview_moveto(0.0)
                self._on_stage_inner()
            except Exception:
                pass
        for key, lab in self.tab_labels.items():
            lab.config(
                bg=CARD if key == name else BG_PANEL,
                fg="#ffffff" if key == name else "#9a9aa5",
            )
        if self.expanded:
            self._place_panel(self._expanded_h())
        self.root.after(30, self._update_scroll_hint)
        if (
            name == "智能"
            and getattr(self, "remote_label", None) is not None
        ):
            self.root.after(60, self.refresh_remote)
