"""User-initiated remote-access changes for the settings panel."""
from __future__ import annotations

import threading

from overlay_feature import runtime as _runtime
from overlay_feature.runtime import INPUT_LOG


class OverlaySettingsRemoteNetworkMixin:
    """Run Tailscale and Funnel changes away from the Tk event thread."""

    def remote_enable(self) -> None:
        """Install or sign in and reveal the fixed remote address."""
        self.flash(
            "正在弄外网访问，可能要你点一下「是」（装 Tailscale 那一步）…",
            5,
        )

        def work() -> None:
            try:
                import remote_access

                ok, message = remote_access.enable(progress=None)
            except Exception as exc:  # noqa: BLE001
                ok, message = False, "出错了：%s" % exc
            self._remote_report(
                flash=(
                    message if ok else "外网访问没弄成：%s" % message,
                    7,
                )
            )
            try:
                _runtime.inputlog(
                    "点了「一键开启外网访问」",
                    INPUT_LOG,
                )
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def remote_funnel_on(self) -> None:
        """Enable the public Funnel address after explicit user action."""
        self.flash(
            "正在开公网地址…（第一次会让你在浏览器里点一次同意）",
            5,
        )

        def work() -> None:
            try:
                import remote_access

                ok, message = remote_access.funnel_enable()
            except Exception as exc:  # noqa: BLE001
                ok, message = False, "出错了：%s" % exc
            self._remote_report(
                flash=(
                    message if ok else "公网地址没开成：%s" % message,
                    8,
                )
            )
            try:
                _runtime.inputlog("点了「开公网地址」", INPUT_LOG)
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def remote_funnel_off(self) -> None:
        """Disable Funnel while leaving the private route untouched."""

        def work() -> None:
            try:
                import remote_access

                _ok, message = remote_access.funnel_disable()
            except Exception as exc:  # noqa: BLE001
                message = "出错了：%s" % exc
            self._remote_report(flash=(message, 5))
            try:
                _runtime.inputlog("点了「关掉公网地址」", INPUT_LOG)
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()


__all__ = ["OverlaySettingsRemoteNetworkMixin"]
