"""Remote-address QR presentation for the settings panel."""
from __future__ import annotations

from PIL import Image, ImageTk

from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import inputlog


class OverlaySettingsRemoteQrMixin:
    def show_remote_qr(self) -> None:
        """把外网固定地址也画成二维码，手机 APP 扫码后切到公网入口。"""
        tk = self.tk
        try:
            import remote_access

            state = remote_access.detail(fresh=True)
        except Exception as exc:  # noqa: BLE001
            self.flash("读不到外网地址：%s" % exc, 4)
            return
        url = state.get("url") or ""
        if not url:
            self.flash(
                state.get("why") or "还没有外网地址 —— 先点「一键开启」",
                5,
            )
            return
        import qr_tools

        win = tk.Toplevel(self.root)
        win.title("外网地址二维码")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 340) // 2
            y = self.root.winfo_y() + 40
            win.geometry("340x470+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            win.geometry("340x470")
        tk.Label(
            win,
            text="在外面也能连",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(14, 2))
        tip = (
            "手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就切到公网那条；"
            "手机不用装 Tailscale，后台也不留东西"
            if state.get("funnel_on")
            else "手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就换成外网那条；"
            "前提是手机上装了 Tailscale 并登了电脑上这个账号"
        )
        tk.Label(
            win,
            text=tip,
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=290,
            justify="center",
        ).pack(padx=14)
        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=24, pady=10)
        keep = {"photo": None}
        if not qr_tools.available():
            holder.config(
                image="",
                width=28,
                height=10,
                compound="center",
                fg="#333333",
                font=("Microsoft YaHei UI", 10),
                text="这台机器少一个画二维码的小库",
            )
        else:
            try:
                image = qr_tools.qr_image(
                    url,
                    box=1,
                    border=3,
                    dark="#101014",
                    light="#ffffff",
                )
                factor = max(3, 250 // max(1, image.width))
                image = image.resize(
                    (image.width * factor, image.height * factor),
                    Image.NEAREST,
                )
                keep["photo"] = ImageTk.PhotoImage(image)
                holder.config(
                    image=keep["photo"],
                    text="",
                    width=0,
                    height=0,
                )
                win._va_qr = keep["photo"]
            except Exception as exc:  # noqa: BLE001
                holder.config(
                    image="",
                    text="画不出来：%s" % exc,
                    fg="#333333",
                    width=28,
                    height=10,
                    compound="center",
                )
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(2, 6))
        self._chip(
            buttons,
            "复制地址",
            lambda: self.copy_remote_url(),
        ).pack(side="left", padx=4)
        tk.Label(
            win,
            text=url,
            bg=BG_PANEL,
            fg="#9a9aa5",
            font=("Consolas", 8),
            wraplength=296,
            justify="center",
        ).pack(padx=14, pady=(4, 2))
        if state.get("account"):
            tk.Label(
                win,
                text="账号：%s" % state["account"],
                bg=BG_PANEL,
                fg="#6f6f7a",
                font=("Microsoft YaHei UI", 8),
            ).pack(pady=(0, 10))
        inputlog("点了「外网地址二维码」")


__all__ = ["OverlaySettingsRemoteQrMixin"]
