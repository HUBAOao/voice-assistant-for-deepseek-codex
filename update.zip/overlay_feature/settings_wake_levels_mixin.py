# -*- coding: utf-8 -*-
"""Wake-level chips, descriptions and custom-level editing."""
from __future__ import annotations

import wake_levels
from overlay_feature.defaults import BG_PANEL


class OverlaySettingsWakeLevelsMixin:
    """Render and persist wake levels without owning the self-test workflow."""

    def build_wake_level(self, parent) -> None:
        row = self._row(parent, "唤醒档位")
        self._chip(row, "自检", self.run_wake_test).pack(
            side="right",
            padx=(4, 10),
        )
        self._chip(row, "＋自定", self.add_wake_level).pack(
            side="right",
            padx=2,
        )
        self.level_holder = self.tk.Frame(parent, bg=BG_PANEL)
        self.level_holder.pack(fill="x", padx=(12, 10), pady=(0, 2))
        self.level_info = self.tk.Label(
            parent,
            text="",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            anchor="w",
            justify="left",
            wraplength=386,
        )
        self.level_info.pack(fill="x", padx=(14, 10), pady=(0, 3))
        self.level_chips = {}
        self.refresh_level_chips()

    def custom_levels(self) -> dict:
        return dict(self.cfg.get("wake_levels") or {})

    def refresh_level_chips(self) -> None:
        if not hasattr(self, "level_holder"):
            return
        for child in self.level_holder.winfo_children():
            child.destroy()
        self.level_chips = {}
        room = max(220, self.expand_w - 34)
        try:
            import tkinter.font as tkfont

            metre = tkfont.Font(font=("Microsoft YaHei UI", 9))
        except Exception:
            metre = None
        line, used = None, 0
        for name in wake_levels.merged(self.custom_levels()):
            width = (
                metre.measure(name) + 26
                if metre is not None
                else 9 * len(name) + 30
            )
            if line is None or used + width > room:
                line = self.tk.Frame(self.level_holder, bg=BG_PANEL)
                line.pack(anchor="w", fill="x")
                used = 0
            chip = self._chip(
                line,
                name,
                lambda current=name: self.set_wake_level(current),
            )
            chip.pack(side="left", padx=2, pady=1)
            used += width
            self.level_chips[name] = chip
        self.refresh_level_colors()
        self.update_level_info()

    def refresh_level_colors(self) -> None:
        current = str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL)
        for name, chip in getattr(self, "level_chips", {}).items():
            chip.config(
                bg=self.button_color if name == current else "#24242a",
                fg="#ffffff",
            )

    def update_level_info(
        self,
        text: str | None = None,
        color: str = "#7f7f8a",
    ) -> None:
        if not hasattr(self, "level_info"):
            return
        if text is None:
            name, params = wake_levels.params(self.cfg)
            text = f"「{name}」{wake_levels.describe(params)}"
            if getattr(self, "wake_test_result", ""):
                text = f"{self.wake_test_result}   ·   {text}"
        self.level_info.config(text=text, fg=color)

    def set_wake_level(self, name: str) -> None:
        self.cfg["wake_level"] = name
        self.refresh_level_colors()
        self.update_level_info()
        self.on_change()
        self.flash(f"唤醒档位：{name}", 1.6)

    def add_wake_level(self) -> None:
        name, params = wake_levels.params(self.cfg)

        def done(text: str) -> None:
            got = wake_levels.from_text(text)
            if not got:
                self.flash("没读懂，名称那一行不能空", 2.4)
                return
            new_name, new_params = got
            custom = dict(self.cfg.get("wake_levels") or {})
            custom[new_name] = new_params
            self.cfg["wake_levels"] = custom
            self.cfg["wake_level"] = new_name
            self.refresh_level_chips()
            self.on_change()
            self.flash(f"已新增档位「{new_name}」", 2.4)

        self.edit_text(
            "唤醒档位（照抄着改数值就行）",
            wake_levels.to_text(name, params),
            done,
            multiline=True,
        )


__all__ = ["OverlaySettingsWakeLevelsMixin"]
