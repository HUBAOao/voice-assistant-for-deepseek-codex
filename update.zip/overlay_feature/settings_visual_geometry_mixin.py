# -*- coding: utf-8 -*-
"""Opacity and window geometry controls for the appearance page."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL


class OverlaySettingsVisualGeometryMixin:
    def build_visual_geometry(self, parent) -> None:
        self.sl_alpha = self._slider(
            parent,
            "整体透明度",
            35,
            100,
            self.alpha * 100,
            "{:.0f}%",
        )
        self.sl_dim = self._slider(
            parent,
            "背景变暗",
            0,
            90,
            float(self.cfg.get("overlay_bg_dim") or 45),
            "{:.0f}%",
        )
        self.sw_wheel = self._switch_row(
            parent, "滚轮调透明度", bool(self.cfg.get("wheel_alpha", True))
        )
        self.sw_snap = self._switch_row(
            parent, "贴边吸附", bool(self.cfg.get("snap_edges", True))
        )
        self.sl_width = self._slider(
            parent,
            "悬浮窗宽度",
            240,
            760,
            self.W,
            "{:.0f}",
            self.apply_size,
        )
        self.sl_height = self._slider(
            parent,
            "悬浮窗高度",
            76,
            220,
            self.H,
            "{:.0f}",
            self.apply_size,
        )
        self.build_effects_and_layout(parent)

    def _slider(
        self,
        parent,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        fmt: str,
        command=None,
    ):
        from ui_widgets import Slider

        return Slider(
            parent,
            label,
            minimum,
            maximum,
            value,
            fmt=fmt,
            on_change=command or self.on_change,
            bg=BG_PANEL,
        )


__all__ = ["OverlaySettingsVisualGeometryMixin"]
