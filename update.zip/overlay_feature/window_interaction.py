# -*- coding: utf-8 -*-
"""Pointer, drag, snap, and menu interaction for the overlay window."""
from __future__ import annotations

import json
import time

from overlay_feature import window_geometry as _geometry
from overlay_feature.window_support import (
    ARROW,
    MAX_ALPHA,
    MIN_ALPHA,
    SIMPLE_LONG,
    SIMPLE_THICK,
    SNAP_PX,
    SW_H,
    SW_W,
    virtual_screen,
)


class WindowInteractionMixin:
    def load_pos(self) -> tuple[int, int]:
        try:
            data = json.loads(
                self._path("POS").read_text(encoding="utf-8")
            )
            self.snap_edge = str(data.get("snap") or "")
            return int(data["x"]), int(data["y"])
        except Exception:
            pass
        return _geometry.default_position(
            virtual_screen(),
            self.W,
            right_gap=40,
            top=60,
        )

    def on_press(self, event) -> None:
        if self.hit_arrow(event.x, event.y):
            self.set_expanded(not self.expanded)
            return
        if self.hit_switch(event.x, event.y):
            self.toggle_switch()
            return
        self._drag = (
            event.x_root - self.root.winfo_x(),
            event.y_root - self.root.winfo_y(),
        )

    def on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.base_x = event.x_root - dx
        self.base_y = event.y_root - dy
        self.root.geometry(f"+{self.base_x}+{self.base_y}")

    def on_release(self, _event) -> None:
        self._drag = None
        self.try_snap()
        self.save_pos()

    def save_pos(self) -> None:
        try:
            self._path("POS").write_text(
                json.dumps(
                    {
                        "x": self.root.winfo_x(),
                        "y": self.root.winfo_y(),
                        "snap": self.snap_edge,
                    }
                ),
                encoding="utf-8",
            )
        except Exception:
            pass

    def simple_size(self) -> tuple:
        if self.snap_edge in ("left", "right"):
            return SIMPLE_THICK, SIMPLE_LONG
        if self.snap_edge in ("top", "bottom"):
            return SIMPLE_LONG, SIMPLE_THICK
        return self.compact_w, self.header_h

    def simple_on(self) -> bool:
        return (
            bool(self.snap_edge)
            and self.snap_on
            and not self.hovered
            and not self.expanded
            and not self._drag
        )

    def nearest_edge(self, x: int, y: int, w: int, h: int) -> str:
        return _geometry.nearest_edge(
            x,
            y,
            w,
            h,
            virtual_screen(),
            SNAP_PX,
        )

    def try_snap(self) -> None:
        if not self.snap_on or self.expanded:
            self.snap_edge = ""
            self.reset_target()
            return
        x, y = self.root.winfo_x(), self.root.winfo_y()
        self.snap_edge = self.nearest_edge(
            x,
            y,
            int(self.cur_w),
            int(self.cur_h),
        )
        if self.snap_edge:
            self.base_x, self.base_y = self.dock_pos(
                self.cur_w,
                self.cur_h,
            )
            self.root.geometry(
                f"{int(self.cur_w)}x{int(self.cur_h)}"
                f"+{self.base_x}+{self.base_y}"
            )
            names = {
                "left": "左边",
                "right": "右边",
                "top": "上边",
                "bottom": "下边",
            }
            self._note(f"吸到{names[self.snap_edge]}")
        else:
            self.reset_target()

    def reset_target(self) -> None:
        self.target_w = float(self.compact_w)
        self.target_h = float(self.header_h)
        if self.expanded:
            self._position_panel_window()

    def dock_pos(self, w: float, h: float) -> tuple:
        return _geometry.dock_position(
            self.snap_edge,
            int(self.base_x),
            int(self.base_y),
            int(w),
            int(h),
            virtual_screen(),
        )

    def clamp_on_screen(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
    ) -> tuple:
        return _geometry.clamp_position(x, y, w, h, virtual_screen())

    def watch_hover(self) -> None:
        try:
            px, py = self.root.winfo_pointerxy()
        except Exception:
            return
        wx, wy = self.root.winfo_x(), self.root.winfo_y()
        self.hovered = (
            wx - 2 <= px <= wx + self.cur_w + 2
            and wy - 2 <= py <= wy + self.cur_h + 2
        )

    def switch_rect(self) -> tuple[int, int]:
        x, y = self.layout["switch"]
        x0 = _geometry.switch_rect(int(self.cur_w), x, SW_W)[0]
        return x0, y

    def hit_switch(self, x: int, y: int) -> bool:
        if not self.show_switch:
            return False
        x0, y0 = self.switch_rect()
        return x0 <= x <= x0 + SW_W and y0 <= y <= y0 + SW_H

    def hit_arrow(self, x: int, y: int) -> bool:
        return _geometry.point_in_rect(
            x,
            y,
            _geometry.arrow_rect(
                int(self.cur_w),
                self.header_h,
                ARROW,
            ),
        )

    def on_wheel(self, event) -> None:
        if not bool(self.cfg.get("wheel_alpha", True)):
            return
        delta = 0.02 if getattr(event, "delta", 0) > 0 else -0.02
        self.alpha = min(
            MAX_ALPHA,
            max(MIN_ALPHA, self.alpha + delta),
        )
        data = self._load_config()
        data["overlay_alpha"] = round(self.alpha, 2)
        self._write_config(data)
        self.flash(f"透明度 {int(self.alpha * 100)}%")

    def toggle_switch(self) -> None:
        paused = self.status.get("state") == "paused"
        self._send_command("resume" if paused else "pause")
        self.flash("正在恢复…" if paused else "正在暂停…")

    def open_menu(self, event) -> None:
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def quit_program(self) -> None:
        self._send_command("quit")
        self.flash("已让语音程序退出")
        self.root.after(700, self.quit)

    def quit(self, reason: str = "用户关掉了浮窗") -> None:
        self._note(f"退出：{reason}")
        try:
            self.root.destroy()
        except Exception:
            pass

    def flash(self, text: str, seconds: float = 1.6) -> None:
        self.toast = text
        self.toast_until = time.time() + seconds
