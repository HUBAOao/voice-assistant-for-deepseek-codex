# -*- coding: utf-8 -*-
"""Identity, greeting and preset composition for the basic settings page."""
from __future__ import annotations

import version
from overlay_feature.defaults import BG_PANEL, DEFAULTS
from overlay_feature.runtime import startup_exists


class OverlaySettingsIdentityMixin:
    """Compose editable identity controls without owning config persistence."""

    def build_identity(self, parent) -> None:
        self.entry_name = self._entry(
            parent,
            "名字",
            self.cfg.get("name") or version.ASSISTANT_NAME,
        )
        self.entry_wake = self._entry(
            parent,
            "唤醒词",
            self.cfg.get("wake_word") or "大肥鱼",
        )
        self.build_wake_level(parent)
        self.entry_greeting = self._entry(
            parent,
            "问候语",
            self.cfg.get("greeting_text") or DEFAULTS["greeting_text"],
            multiline=True,
        )
        self.entry_user = self._entry(
            parent,
            "你的称呼",
            self.cfg.get("user_name") or "",
        )
        row = self._row(parent, "称呼频率")
        self.name_freq_value = str(self.cfg.get("name_freq") or "sometimes")
        self.name_freq_chips = {}
        for value, label in (
            ("off", "从不"),
            ("sometimes", "偶尔"),
            ("often", "经常"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_name_freq(current),
            )
            chip.pack(side="left", padx=3)
            self.name_freq_chips[value] = chip
        self.refresh_name_freq()
        self.sw_greeting = self._switch_row(
            parent,
            "开机问候",
            bool(self.cfg.get("greeting_enabled", True)),
        )
        self.sw_autostart = self._switch_row(
            parent,
            "开机自启",
            startup_exists(),
            on_change=self.set_autostart,
        )
        self.sw_restart = self._switch_row(
            parent,
            "崩溃自动重启",
            bool(self.cfg.get("auto_restart", True)),
        )
        row = self._row(parent, "预设")
        self._chip(row, "存为预设", self.save_preset).pack(
            side="right",
            padx=(4, 10),
        )
        self._chip(row, "导出预设", self.export_presets).pack(
            side="right",
            padx=2,
        )
        self._chip(row, "导入预设", self.import_presets).pack(
            side="right",
            padx=2,
        )
        self.preset_bar = self.tk.Frame(parent, bg=BG_PANEL)
        self.preset_bar.pack(fill="x", padx=12, pady=(0, 6))
        self.refresh_presets()
