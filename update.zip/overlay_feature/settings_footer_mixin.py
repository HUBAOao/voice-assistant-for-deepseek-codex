# -*- coding: utf-8 -*-
"""Persistent settings footer actions kept outside the window shell."""
from __future__ import annotations

import version
from overlay_feature.defaults import BG_PANEL, CARD


class OverlaySettingsFooterMixin:
    def build_footer(self, foot) -> None:
        """Build the historical version, update and save action row."""
        tk = self.tk
        tk.Label(
            foot,
            text=version.label(),
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left", padx=(2, 0))
        save = tk.Label(
            foot,
            text="保存",
            bg=self.button_color,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 10, "bold"),
            padx=18,
            pady=5,
            cursor="hand2",
        )
        save.pack(side="right")
        save.bind("<Button-1>", lambda _e: self.save_settings())
        reset = tk.Label(
            foot,
            text="恢复默认",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=12,
            pady=5,
            cursor="hand2",
        )
        reset.pack(side="right", padx=8)
        reset.bind("<Button-1>", lambda _e: self.reset_defaults())
        about_btn = tk.Label(
            foot,
            text="关于",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=12,
            pady=5,
            cursor="hand2",
        )
        about_btn.pack(side="right", padx=(0, 4))
        about_btn.bind("<Button-1>", lambda _e: self.show_about())
        self.upd_label = tk.Label(
            foot,
            text="",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        )
        self.upd_label.pack(side="left", padx=(8, 0))
        upd_btn = tk.Label(
            foot,
            text="检查更新",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=12,
            pady=5,
            cursor="hand2",
        )
        upd_btn.pack(side="right", padx=(0, 4))
        upd_btn.bind("<Button-1>", lambda _e: self.check_update())
        pub_btn = tk.Label(
            foot,
            text="发布到网站",
            bg=CARD,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 9),
            padx=12,
            pady=5,
            cursor="hand2",
        )
        pub_btn.pack(side="right", padx=(0, 4))
        pub_btn.bind("<Button-1>", lambda _e: self.publish_site())
