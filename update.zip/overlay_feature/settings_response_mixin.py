# -*- coding: utf-8 -*-
"""Acknowledgement and self-reference composition for basic settings."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL, DEFAULTS


class OverlaySettingsResponseMixin:
    """Compose response phrases without owning collection or persistence."""

    def build_response(self, parent) -> None:
        # 应答语可以写多条，一行一条（或 | 隔开），每次随机挑一条。
        self.entry_ack = self._entry(
            parent,
            "应答语",
            self.cfg.get("ack_text") or DEFAULTS["ack_text"],
            multiline=True,
        )
        self.tk.Label(
            parent,
            text="可以写好几条，一行一条；每次随机挑一条说",
            bg=BG_PANEL,
            fg="#6f6f7a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w", padx=(14, 10), pady=(0, 3))
        self.sw_ack = self._switch_row(
            parent,
            "应答语开关",
            bool(self.cfg.get("ack_enabled", True)),
        )
        self.entry_self = self._entry(
            parent,
            "自称",
            self.cfg.get("self_name") or "大肥鱼",
        )
        self.sw_self = self._switch_row(
            parent,
            "自称开关",
            bool(self.cfg.get("self_talk", True)),
        )
        row = self._row(parent, "自称频率")
        self.self_freq_value = str(self.cfg.get("self_freq") or "sometimes")
        self.self_freq_chips = {}
        for value, label in (
            ("off", "从不说"),
            ("sometimes", "有时"),
            ("often", "经常"),
        ):
            chip = self._chip(
                row,
                label,
                lambda current=value: self.set_self_freq(current),
            )
            chip.pack(side="left", padx=3)
            self.self_freq_chips[value] = chip
        self.refresh_self_freq()
