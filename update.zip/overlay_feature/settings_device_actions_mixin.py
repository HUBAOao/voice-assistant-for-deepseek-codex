"""Device admission decisions and trust-list mutations."""
from __future__ import annotations

import time


class OverlaySettingsDeviceActionsMixin:
    """Keep confirmation and destructive device actions in one narrow boundary."""

    def check_new_devices(self, force: bool = False) -> None:
        """（每 200ms 被 tick 调一次）有没有新设备在等确认？有就弹窗。"""
        now = time.time()
        if not force and now - getattr(self, "_dev_checked", 0.0) < 2.0:
            return
        self._dev_checked = now
        try:
            import phone_link

            pend = [g for g in phone_link.device_groups() if g.get("pending")]
        except Exception:  # noqa: BLE001
            return
        asked = getattr(self, "_dev_asked", None)
        if asked is None:
            asked = set()
            self._dev_asked = asked
        for grp in pend:
            did = str(grp.get("key") or "") or str(
                (grp.get("ids") or [""])[0]
            )
            if not did or did in asked:
                continue
            asked.add(did)
            self.ask_new_device(grp)

    def ask_new_device(self, rec: dict) -> None:
        """弹窗：有台新设备想连进来，对一下号码再决定。"""
        from tkinter import messagebox

        code = " / ".join(
            [c for c in (rec.get("codes") or []) if c]
        ) or str(rec.get("code") or "")
        ua = str(rec.get("ua") or "")[:70]
        ip = str(rec.get("ip") or "")
        try:
            import phone_link

            nice = str(rec.get("name") or "") or phone_link.device_name(ua, ip)
        except Exception:  # noqa: BLE001
            nice = "（认不出）"
        n = len(rec.get("ids") or [])
        more = (
            "\n（这台手机一共 %d 个入口，一起处理）" % n
            if n > 1
            else ""
        )
        try:
            ok = messagebox.askyesno(
                "有台新设备想连进来",
                "配对号码：%s\n\n设备：%s\n来源：%s%s\n\n让它连吗？\n"
                "（手机屏幕上现在显示的就是这个号码；是你自己的手机才点「是」）"
                % (code, nice, ip or "—", more),
            )
        except Exception:  # noqa: BLE001
            ok = False
        try:
            import phone_link

            ids = rec.get("ids") or []
            if ok:
                phone_link.group_allow(ids)
                self._dev_asked = set()
                self.flash("已允许这台设备（%s）" % code, 4)
            else:
                phone_link.group_deny(ids)
                self.flash("已拒绝这台设备", 4)
        except Exception as exc:  # noqa: BLE001
            self.flash("处理设备确认失败：%s" % exc, 4)
        self.refresh_devices_label()

    def refresh_devices_label(self) -> None:
        """设置里那行“已配对设备”的小字。"""
        try:
            import phone_link

            groups = phone_link.device_groups()
            ok_n = sum(1 for g in groups if not g.get("pending"))
            pend = sum(1 for g in groups if g.get("pending"))
        except Exception:  # noqa: BLE001
            return
        txt = "%d 台设备" % len(groups)
        if ok_n:
            txt += "（已允许 %d 台）" % ok_n
        if pend:
            txt = "%d 台等你确认" % pend
        try:
            self.devices_label.config(text=txt)
        except Exception:  # noqa: BLE001
            pass

    def forget_devices(self) -> None:
        """把设备名单清空：下次谁来都得重新确认一遍。"""
        from tkinter import messagebox

        if not messagebox.askyesno(
            "清空设备名单",
            "清掉之后：所有手机都要重新确认一次。\n"
            "（你自己手机也一样）\n\n要清吗？",
        ):
            return
        try:
            import phone_link

            n = phone_link.device_forget_all()
            self.flash("已清空 %d 台设备" % n, 4)
        except Exception as exc:  # noqa: BLE001
            self.flash("清空失败：%s" % exc, 4)
        self.refresh_devices_label()

    def rotate_phone_token(self) -> None:
        """换一条手机令牌 —— 旧的立刻作废（手机上要重新扫一次码）。"""
        from tkinter import messagebox

        if not messagebox.askyesno(
            "换一条手机令牌",
            "什么时候用得着：你怀疑那条链接被泄漏了。\n\n"
            "换过之后：\n· 旧链接立刻失效（谁拿着都没用）\n"
            "· **你自己的手机也要重新扫一次码**\n"
            "· 已经配对的设备不受影响\n\n要换吗？",
        ):
            return
        try:
            import phone_link

            phone_link.rotate_token()
            phone_link.device_forget_all()
            self.flash("令牌换了 —— 手机上重新扫一次码", 6)
            self.refresh_remote()
            self.refresh_devices_label()
        except Exception as exc:  # noqa: BLE001
            self.flash("换令牌失败：%s" % exc, 5)
