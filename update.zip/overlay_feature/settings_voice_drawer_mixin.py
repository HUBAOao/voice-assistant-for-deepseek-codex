# -*- coding: utf-8 -*-
"""Voice preset row, drawer state and selected-item highlighting."""
from __future__ import annotations

from overlay_feature.defaults import BG_PANEL, CARD, VOICES


class OverlaySettingsVoiceDrawerMixin:
    def build_voice(self, parent) -> None:
        """Build the voice row while preserving the historical widget names."""
        row = self._row(parent, "音色")
        self.voice_index = self._voice_index()
        self.voice_label = self.tk.Label(
            row,
            text=self._voice_text(),
            bg=BG_PANEL,
            fg=self.accent,
            font=("Microsoft YaHei UI", 9),
        )
        self.voice_label.pack(side="left", padx=4)
        self._chip(row, "试听", lambda: self.preview_voice()).pack(
            side="right", padx=6
        )
        self.voice_drawer_open = False
        self.voice_more = self._chip(
            row, "选择 ▾", lambda: self.toggle_voice_drawer()
        )
        self.voice_more.pack(side="right", padx=(0, 6))
        self.voice_drawer = self.tk.Frame(parent, bg=CARD)
        self.voice_rows = {}
        self._build_voice_drawer()

    def _voice_index(self) -> int:
        # Prefer the preset index because one Edge voice may have variants.
        try:
            idx = int(self.cfg.get("voice_preset") or -1)
            if 0 <= idx < len(VOICES):
                return idx
        except Exception:
            pass
        current = self.cfg.get("voice") or VOICES[0][0]
        for i, entry in enumerate(VOICES):
            value = entry[0]
            if value == current:
                return i
        return 0

    def _voice_text(self) -> str:
        return VOICES[self.voice_index][1]

    def _build_voice_drawer(self) -> None:
        tk = self.tk
        head = tk.Frame(self.voice_drawer, bg=CARD)
        head.pack(fill="x", padx=8, pady=(6, 2))
        tk.Label(
            head,
            text=f"想要哪个直接点（一共 {len(VOICES)} 个）",
            bg=CARD,
            fg="#9a9aa5",
            font=("Microsoft YaHei UI", 8),
        ).pack(side="left")
        self._chip(head, "收起", lambda: self.toggle_voice_drawer()).pack(
            side="right"
        )
        for index, (_voice, label, _pitch, _fx) in enumerate(VOICES):
            line = tk.Frame(self.voice_drawer, bg=CARD)
            line.pack(fill="x", padx=8, pady=1)
            name = tk.Label(
                line,
                text=label,
                bg=CARD,
                fg="#ffffff",
                anchor="w",
                font=("Microsoft YaHei UI", 9),
                padx=6,
                pady=3,
                cursor="hand2",
            )
            name.pack(side="left", fill="x", expand=True)
            name.bind(
                "<Button-1>", lambda _event, i=index: self.select_voice(i)
            )
            self._chip(
                line, "听", lambda idx=index: self.preview_voice(idx)
            ).pack(side="right", padx=(4, 2))
            self.voice_rows[index] = name
        self.refresh_voice_rows()

    def toggle_voice_drawer(self) -> None:
        self.voice_drawer_open = not bool(
            getattr(self, "voice_drawer_open", False)
        )
        if self.voice_drawer_open:
            self.voice_drawer.pack(fill="x", padx=12, pady=(2, 8))
            self.voice_more.config(text="选择 ▴")
        else:
            self.voice_drawer.pack_forget()
            self.voice_more.config(text="选择 ▾")
        self.root.after(10, self._on_stage_inner)

    def select_voice(self, index: int) -> None:
        self.voice_index = max(0, min(len(VOICES) - 1, int(index)))
        self.voice_label.config(text=self._voice_text())
        self.refresh_voice_rows()
        self.on_change()

    def refresh_voice_rows(self) -> None:
        for index, label in getattr(self, "voice_rows", {}).items():
            label.config(
                bg=self.button_color if index == self.voice_index else CARD,
                fg="#ffffff",
            )
