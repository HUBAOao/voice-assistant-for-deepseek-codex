# -*- coding: utf-8 -*-
"""Reliable titled editors for text settings."""
from __future__ import annotations

from overlay_feature import panel_controls as _controls


class OverlaySettingsTextInputMixin:
    def _entry(self, parent, label, value, multiline: bool = False):
        """One text setting that opens a normal editor dialog when clicked."""

        def open_editor():
            self._overlay_inputlog(f"点击「{label}」按钮")
            self.edit_text(
                label,
                variable.get(),
                lambda text: variable.set(text),
                multiline=multiline,
            )

        variable = _controls.text_field(
            self.tk,
            parent,
            label,
            value,
            open_editor,
            self.on_change,
        )
        return variable

    def edit_text(
        self,
        title: str,
        initial: str,
        on_ok=None,
        multiline: bool = False,
    ) -> None:
        """Open a normal titled editor so keyboard focus remains reliable."""
        _controls.text_dialog(
            self.tk,
            self.root,
            title,
            initial,
            multiline=multiline,
            button_color=self.button_color,
            on_ok=on_ok,
            on_editing=self.set_editing,
            on_touch=lambda value: setattr(self, "edit_touch", value),
        )


__all__ = ["OverlaySettingsTextInputMixin"]
