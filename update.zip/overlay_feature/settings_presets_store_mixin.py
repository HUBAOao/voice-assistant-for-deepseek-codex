# -*- coding: utf-8 -*-
"""Compatibility composition for preset mutation and file transfer."""
from __future__ import annotations

from overlay_feature.settings_presets_actions_mixin import (
    OverlayPresetsActionsMixin,
)
from overlay_feature.settings_presets_transfer_mixin import (
    OverlayPresetsTransferMixin,
)


class OverlayPresetsStoreMixin(
    OverlayPresetsActionsMixin,
    OverlayPresetsTransferMixin,
):
    """Keep every historical preset entry while actions stay testable."""


__all__ = ["OverlayPresetsStoreMixin"]
