# -*- coding: utf-8 -*-
"""Overlay "smart" and "features" settings pages."""
from __future__ import annotations

from ui_widgets import Slider
from overlay_feature.defaults import BG_PANEL


class OverlaySettingsPagesMixin:
    def build_smart(self, parent, more) -> None:
        """智能＝听和发；more 是「功能」页，好玩的和维护的都写在那。"""
        self._group(parent, "性能")
        row = self._row(parent, "性能模式")
        self.perf_value = str(self.cfg.get("perf_mode") or "quality")
        self.perf_chips = {}
        for value, label in (("eco", "节能"), ("standard", "标准"), ("quality", "质量")):
            chip = self._chip(row, label, lambda v=value: self.set_perf(v))
            chip.pack(side="left", padx=3)
            self.perf_chips[value] = chip
        self.refresh_perf_chips()
        note = self.tk.Frame(parent, bg=BG_PANEL)
        note.pack(fill="x", padx=12, pady=(0, 6))
        self.tk.Label(note, text="节能＝关掉设置里的界面动画；质量＝动画全开、帧率拉满",
                      bg=BG_PANEL, fg="#7f7f8a",
                      font=("Microsoft YaHei UI", 8)).pack(anchor="w")
        self.sl_anim = Slider(
            parent, "动画帧率", 15, 60,
            float(self.cfg.get("anim_fps") or 60),
            fmt="{:.0f} fps", on_change=self.on_change, bg=BG_PANEL,
        )
        self.sw_autotune = self._switch_row(
            parent, "低配自动降级", bool(self.cfg.get("auto_tune", True))
        )
        self.sl_followup = Slider(
            parent, "连续对话", 0, 30,
            float(self.cfg.get("followup_seconds") or 0),
            fmt="{:.0f} 秒", on_change=self.on_change, bg=BG_PANEL,
        )
        row = self.tk.Frame(parent, bg=BG_PANEL)
        row.pack(fill="x", padx=12, pady=(2, 6))
        self.tk.Label(
            row,
            text="说一次唤醒词后，这段时间内接着说就不用再喊它（0＝关闭）",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
        ).pack(anchor="w")

        self.build_features(more)

        self.build_delivery_section(parent)
        self.build_maintenance(more)
