"""Read-only phone access history for the settings panel."""
from __future__ import annotations

import os
import time

from overlay_feature.defaults import BG_PANEL
from overlay_feature.runtime import inputlog


class OverlaySettingsAccessLogMixin:
    def show_access_log(self) -> None:
        """连接记录：谁、什么时候、连上来干了什么。"""
        tk = self.tk
        try:
            import phone_link

            rows = phone_link.access_recent(300)
        except Exception as exc:  # noqa: BLE001
            self.flash("读连接记录失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("连接记录")
        win.configure(bg=BG_PANEL)
        win.geometry("560x480")
        try:
            win.attributes("-topmost", True)
        except Exception:  # noqa: BLE001
            pass
        tk.Label(
            win,
            text="连接记录（谁来过、干了什么）",
            bg=BG_PANEL,
            fg="#ffffff",
            font=("Microsoft YaHei UI", 12, "bold"),
        ).pack(pady=(10, 0))
        tk.Label(
            win,
            text="「连上」= 有设备连过来 · 「发命令 / 看屏幕 / 取文件」= "
            "它做了什么 · 「新设备」「允许」「拒绝」「封了」= 那道门的事",
            bg=BG_PANEL,
            fg="#7f7f8a",
            font=("Microsoft YaHei UI", 8),
            wraplength=520,
            justify="center",
        ).pack(padx=10)
        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=10, pady=8)
        text = tk.Text(
            body,
            bg="#14141a",
            fg="#d8d8e0",
            insertbackground="#d8d8e0",
            font=("Consolas", 9),
            wrap="none",
            height=20,
            width=62,
            bd=0,
        )
        scroll = tk.Scrollbar(body, command=text.yview)
        text.config(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        lines = []
        for row in rows:
            stamp = time.strftime(
                "%m-%d %H:%M:%S",
                time.localtime(float(row.get("ts") or 0)),
            )
            try:
                who = phone_link.device_name(
                    row.get("ua"), row.get("ip")
                )[:18]
            except Exception:  # noqa: BLE001
                who = (
                    str(row.get("ua") or "").split("(")[0].strip()[:16]
                    or "—"
                )
            lines.append(
                "%s  %-4s  %-16s %s"
                % (
                    stamp,
                    str(row.get("ev") or ""),
                    who,
                    str(row.get("detail") or ""),
                )
            )
        text.insert("1.0", "\n".join(lines) or "（还没有记录）")
        text.config(state="disabled")
        buttons = tk.Frame(win, bg=BG_PANEL)
        buttons.pack(pady=(0, 10))
        self._chip(
            buttons,
            "刷新",
            lambda: (win.destroy(), self.show_access_log()),
        ).pack(side="left", padx=4)

        def open_file() -> None:
            try:
                os.startfile(str(phone_link.ACCESS_FILE))
            except Exception as exc:  # noqa: BLE001
                self.flash("打不开文件：%s" % exc, 4)

        self._chip(buttons, "打开文件", open_file).pack(side="left", padx=4)

        def wipe() -> None:
            from tkinter import messagebox

            if messagebox.askyesno(
                "清空连接记录", "把记录清掉？（设备名单不动）"
            ):
                phone_link.access_clear()
                win.destroy()
                self.show_access_log()

        self._chip(buttons, "清空", wipe).pack(side="left", padx=4)
        self._chip(
            buttons,
            "关掉",
            lambda: win.destroy(),
        ).pack(side="left", padx=4)
        inputlog("点了「连接记录」")


__all__ = ["OverlaySettingsAccessLogMixin"]
