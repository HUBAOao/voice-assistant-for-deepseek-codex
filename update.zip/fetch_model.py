#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""下载 faster-whisper 模型到 models/ 目录（支持断点续传，默认走国内镜像）。

    python fetch_model.py small
    python fetch_model.py medium
    python fetch_model.py large-v3
"""

from __future__ import annotations

import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILES = ["config.json", "tokenizer.json", "vocabulary.txt", "vocabulary.json",
         "preprocessor_config.json", "model.bin"]

REPOS = {
    "tiny": "Systran/faster-whisper-tiny",
    "base": "Systran/faster-whisper-base",
    "small": "Systran/faster-whisper-small",
    "medium": "Systran/faster-whisper-medium",
    "large-v3": "Systran/faster-whisper-large-v3",
    "large-v3-turbo": "deepdml/faster-whisper-large-v3-turbo-ct2",
}


def expected_size(url: str) -> int:
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "curl/8"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return int(resp.headers.get("Content-Length", 0))


def download(url: str, dest: Path, stall_timeout: float = 45.0, tries: int = 40) -> None:
    """带断点续传的下载：卡住超过 stall_timeout 秒就断开重连，从断点继续。"""
    want = 0
    try:
        want = expected_size(url)
    except Exception:  # noqa: BLE001
        want = 0

    for attempt in range(1, tries + 1):
        done = dest.stat().st_size if dest.exists() else 0
        if want and done >= want:
            print(f"\r  {dest.name}: 100.0%  {done/1e6:.1f} MB（完成）")
            return
        req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
        if done:
            req.add_header("Range", f"bytes={done}-")
        try:
            with urllib.request.urlopen(req, timeout=stall_timeout) as resp:
                total = int(resp.headers.get("Content-Length", 0)) + done
                mode = "ab" if done and resp.status == 206 else "wb"
                if mode == "wb":
                    done = 0
                with dest.open(mode) as fh:
                    while True:
                        chunk = resp.read(1 << 20)
                        if not chunk:
                            break
                        fh.write(chunk)
                        done += len(chunk)
                        shown = total or want
                        pct = done * 100 / shown if shown else 0
                        sys.stdout.write(f"\r  {dest.name}: {pct:5.1f}%  {done/1e6:7.1f}/{(shown or 0)/1e6:.1f} MB")
                        sys.stdout.flush()
        except Exception as exc:  # noqa: BLE001
            if isinstance(exc, urllib.error.HTTPError) and exc.code == 404:
                raise FileNotFoundError(dest.name) from None
            if isinstance(exc, urllib.error.HTTPError) and exc.code == 416:
                # Range 超出文件长度，说明本地这个文件已经完整了
                print(f"\r  {dest.name}: 已完整（{done/1e6:.1f} MB）")
                return
            print(f"\n  第 {attempt} 次连接中断（{type(exc).__name__}），从 {done/1e6:.1f} MB 继续")
            time.sleep(1.5)
            continue
    raise SystemExit(f"{dest.name} 下载失败：试了 {tries} 次还是没下完")


def main() -> int:
    name = sys.argv[1] if len(sys.argv) > 1 else "small"
    if name not in REPOS:
        print(f"未知模型 {name}，可选：{', '.join(REPOS)}")
        return 2
    base = (os.environ.get("HF_ENDPOINT") or "https://hf-mirror.com").rstrip("/")
    url_base = f"{base}/{REPOS[name]}/resolve/main"
    out = HERE / "models" / f"faster-whisper-{name}"
    out.mkdir(parents=True, exist_ok=True)
    print(f"下载 {name} -> {out}")
    for f in FILES:
        try:
            download(f"{url_base}/{f}?download=true", out / f)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:  # 不同仓库的配置文件不完全一样，缺的跳过
                print(f"  {f}: 这个仓库里没有，跳过")
                continue
            print(f"  {f} 下载失败：{exc}")
            return 1
        except FileNotFoundError:  # 同上：仓库里没有这个文件
            print(f"  {f}: 这个仓库里没有，跳过")
            continue
        except Exception as exc:  # noqa: BLE001
            print(f"  {f} 下载失败：{exc}")
            return 1
    size = sum(p.stat().st_size for p in out.iterdir()) / 1e6
    print(f"完成，共 {size:.1f} MB。现在可以直接 python stt.py --model {name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
