# -*- coding: utf-8 -*-
"""双击就能发布：把下载页重新生成一遍，推到网站上去。

（平时不用管它 —— 每次更新程序、打包的时候会自动发布；这个是万一你想手动发一次。）
做完会弹一个小窗告诉你成功没有。
"""
from __future__ import annotations

import sys
import traceback


def main() -> int:
    try:
        import site_publish
    except Exception:
        print(traceback.format_exc())
        return 1
    cfg = site_publish.load()
    print("仓库：", cfg.get("repo") or "（没填）")
    print("网站：", cfg.get("url") or "（没填）")
    # 双击这个 = 手动发布，那就别攒着了，直接发（force=True）
    ok, why, did = site_publish.publish(force=True)
    print("\n" + ("发布成功：" if ok else "没发上去：") + why)
    if ok:
        print("网站：", cfg.get("url") or "（记得填网站网址）")
    try:                       # 双击运行的时候，别让窗口一闪就没
        if sys.stdout and sys.stdout.isatty():
            input("\n按回车关掉…")
        else:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                None, ("发布成功！\n" + str(cfg.get("url") or "")) if ok else ("没发上去：\n" + why),
                "语音助手 · 发布下载页", 0x40 if ok else 0x10)
    except Exception:
        pass
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
