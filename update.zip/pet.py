#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""桌宠：DeepSeek 娘在桌面上走来走去。

素材是从你给的那几张图里提出来的（assets/pet/*.png）：
  · 8 个表情（普通/笑/兴奋/困/担心/生气/欢呼/认真）
  · 一张像素立绘
它会照着语音助手的状态换表情：在听你说话就兴奋，识别中就认真，发出去了就欢呼，
暂停了就打瞌睡，主程序不在就担心。鼠标可以拖，双击会跳一下，右键有菜单。
"""

from __future__ import annotations

import ctypes
import json
import math
import random
import time
import tkinter as tk
from pathlib import Path

from PIL import Image, ImageTk

HERE = Path(__file__).resolve().parent
ASSETS = HERE / "assets" / "pet"
STATUS = HERE / "status.json"
POS = HERE / "pet_pos.json"
CONFIG = HERE / "config.json"

MAGIC = "#ff00fe"            # 透明色（这个颜色精灵里不会出现）
FRAME_MS = 33                # ~30fps，桌宠不需要 60

STATE_FACE = {
    "idle": "normal", "starting": "normal",
    "listening": "excited", "hearing": "excited",
    "thinking": "ready", "sent": "cheer", "copied": "smile",
    "paused": "sleepy", "offline": "worried", "focus": "ready",
}


def load_config() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


class Pet:
    def __init__(self) -> None:
        self.cfg = load_config()
        self.scale = max(1, min(6, int(self.cfg.get("pet_scale") or 3)))
        self.speed = max(1, min(10, int(self.cfg.get("pet_speed") or 3)))
        self.w = self.h = 96 * self.scale // 3
        self.sprites = self.load_sprites()
        self.face = "normal"
        self.images: dict[str, ImageTk.PhotoImage] = {}

        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=MAGIC)
        try:
            self.root.attributes("-transparentcolor", MAGIC)
        except Exception:
            pass
        self.screen_w = self.root.winfo_screenwidth()
        self.screen_h = self.root.winfo_screenheight()
        x, y = self.load_pos()
        self.x, self.y = float(x), float(y)
        self.dir = 1
        self.phase = random.random() * 6.28
        self.hop = 0.0
        self.state = "idle"
        self.status = {}
        self.miss = 0
        self._next_status = 0.0
        self._drag = None

        self.canvas = tk.Canvas(self.root, width=self.w, height=self.h, bg=MAGIC,
                                highlightthickness=0)
        self.canvas.pack()
        self.item = self.canvas.create_image(0, 0, anchor="nw")
        self.canvas.bind("<Button-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Double-Button-1>", lambda _e: self.jump())
        self.canvas.bind("<Button-3>", self.menu)
        self.menu_widget = tk.Menu(self.root, tearoff=0, bg="#26262d", fg="#ffffff",
                                   activebackground="#2f7f5a", activeforeground="#ffffff",
                                   font=("Microsoft YaHei UI", 9))
        self.menu_widget.add_command(label="跳一下", command=self.jump)
        self.menu_widget.add_command(label="走两步", command=self.walk_about)
        self.menu_widget.add_command(label="藏起来", command=self.quit)

        self.root.geometry(f"{self.w}x{self.h}+{int(self.x)}+{int(self.y)}")
        self.root.report_callback_exception = self.on_error
        try:                                   # 桌宠不抢键盘焦点
            u = ctypes.windll.user32
            inner = self.root.winfo_id()
            outer = u.GetParent(inner) or inner
            for hwnd in {inner, outer}:
                style = u.GetWindowLongW(hwnd, -20)
                u.SetWindowLongW(hwnd, -20, style | 0x08000000)
        except Exception:
            pass
        self.tick()
        self.anim()

    # ------------------------------------------------------------ 素材 / 位置
    def on_error(self, exc_type, exc_value, exc_tb) -> None:
        """Tk 回调里的异常默认只打到控制台，pythonw 下等于消失——记到文件里。"""
        import traceback

        try:
            with (HERE / "pet-error.log").open("a", encoding="utf-8") as fh:
                fh.write("".join(traceback.format_exception(exc_type, exc_value, exc_tb)))
        except Exception:
            pass

    def load_sprites(self) -> dict[str, Image.Image]:
        out: dict[str, Image.Image] = {}
        for path in sorted(ASSETS.glob("*.png")):
            try:
                im = Image.open(path).convert("RGBA")
            except Exception:
                continue
            size = max(24, int(self.w))
            im = im.resize((size, size), Image.NEAREST)      # 像素风：放大也别糊
            out[path.stem] = im
        if not out:
            im = Image.new("RGBA", (self.w, self.h), (70, 110, 200, 255))
            out["normal"] = im
        return out

    def load_pos(self) -> tuple[int, int]:
        try:
            data = json.loads(POS.read_text(encoding="utf-8"))
            x, y = int(data["x"]), int(data["y"])
        except Exception:
            x, y = self.screen_w - 320, self.screen_h - 300
        # 别让它停在屏幕外（拖到边上、或者分辨率变了都可能出界）
        x = max(0, min(self.screen_w - self.w - 4, x))
        y = max(0, min(self.screen_h - self.h - 48, y))
        return x, y

    # ------------------------------------------------------------ 交互
    def on_press(self, event) -> None:
        self._drag = (event.x_root - self.x, event.y_root - self.y)

    def on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.x = max(-self.w // 3, min(self.screen_w - self.w + self.w // 3, event.x_root - dx))
        self.y = max(0, min(self.screen_h - self.h // 2, event.y_root - dy))
        self.root.geometry(f"+{int(self.x)}+{int(self.y)}")

    def on_release(self, _event) -> None:
        self._drag = None
        try:
            POS.write_text(json.dumps({"x": int(self.x), "y": int(self.y)}), encoding="utf-8")
        except Exception:
            pass

    def menu(self, event) -> None:
        try:
            self.menu_widget.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu_widget.grab_release()

    def jump(self) -> None:
        self.hop = 1.0

    def walk_about(self) -> None:
        self.dir = random.choice((-1, 1))
        self.x += self.dir * random.randint(60, 200)

    def quit(self) -> None:
        try:
            self.root.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------ 状态 / 动作
    def read_status(self) -> None:
        now = time.time()
        if now < self._next_status:
            return
        self._next_status = now + 0.25
        try:
            self.status = json.loads(STATUS.read_text(encoding="utf-8"))
            self.miss = 0
        except Exception:
            self.miss += 1
            if self.miss > 400:            # 主程序好久不在了，自己退
                self.quit()
            return
        state = str(self.status.get("state") or "idle")
        if state != self.state:
            if state in ("listening", "hearing") and self.state == "idle":
                self.hop = 1.0             # 被叫醒，蹦一下
            self.state = state
        want = STATE_FACE.get(state, "normal")
        if self.status.get("mood") == "急" and state in ("hearing", "thinking"):
            want = "angry"
        self.face = want if want in self.sprites else "normal"

    def anim(self) -> None:
        self.read_status()
        moving = self.state in ("idle", "listening", "hearing")
        if self._drag is None and moving:
            self.phase += 0.16
            self.x += self.dir * (0.6 + 0.25 * self.speed)
            if self.x < 8:
                self.x, self.dir = 8, 1
            elif self.x > self.screen_w - self.w - 8:
                self.x, self.dir = self.screen_w - self.w - 8, -1
        else:
            self.phase += 0.07
        bob = math.sin(self.phase) * 3
        if self.hop > 0:
            bob -= math.sin((1 - self.hop) * math.pi) * 26
            self.hop = max(0.0, self.hop - 0.06)
        self.root.geometry(f"+{int(self.x)}+{int(self.y + bob)}")

        sprite = self.sprites.get(self.face) or next(iter(self.sprites.values()))
        if self.dir < 0:
            sprite = sprite.transpose(Image.FLIP_LEFT_RIGHT)
        frame = Image.new("RGBA", (self.w, self.h), (0, 0, 0, 0))
        frame.alpha_composite(sprite.convert("RGBA"), (0, 0))
        # 透明色抠图要求边缘是"硬"的，所以先把半透明像素二值化，否则边上会有一圈洋红
        frame.putalpha(frame.getchannel("A").point(lambda v: 255 if v >= 128 else 0))
        flat = Image.new("RGB", (self.w, self.h), MAGIC)
        flat.paste(frame, (0, 0), frame)
        self.photo = ImageTk.PhotoImage(flat)
        self.canvas.itemconfig(self.item, image=self.photo)
        self.root.after(FRAME_MS, self.anim)

    def tick(self) -> None:
        self.cfg = load_config()
        if not self.cfg.get("pet_enabled", True):    # 设置里关掉了就自己退
            self.quit()
            return
        self.root.after(2000, self.tick)

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    try:
        Pet().run()
    except Exception as exc:  # noqa: BLE001
        # 窗口已经被关掉（用户点了退出/程序收尾）时再来一帧动画会抛 TclError，
        # 这是正常收场，不是故障 —— 别写进错误日志吓人。
        if "application has been destroyed" in str(exc) or "TclError" in type(exc).__name__:
            return 0
        import traceback
        try:
            (HERE / "pet-error.log").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
