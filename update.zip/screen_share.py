#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把电脑屏幕发给手机：截图 / 录屏，都存到 手机屏幕\\ 这个文件夹里，
手机入口（phone_link.py）再把它们端给手机看。

为什么不用 ffmpeg：用户那边的电脑不一定装，而这个功能得"装上就能用"。
录屏用 PIL 直接写成**动图**（优先 webp，退而求其次 gif）——
手机浏览器都认，不用装任何东西。

顺带处理一个坑：Windows 的 GDI 截屏**看不见分层窗口**（悬浮窗是带透明度的），
所以截完会把悬浮窗单独 PrintWindow 抓一份按 α 合进去，画面才跟肉眼看到的一致。
"""

from __future__ import annotations

import ctypes
import time
from pathlib import Path
from typing import Optional

HERE = Path(__file__).resolve().parent
SHOT_DIR = HERE / "手机屏幕"
OVERLAY_TITLE = "大肥鱼"          # 要合进去的悬浮窗（跟设置的"名字"一致）


class _BIH(ctypes.Structure):
    _fields_ = [("biSize", ctypes.c_uint32), ("biWidth", ctypes.c_int32),
                ("biHeight", ctypes.c_int32), ("biPlanes", ctypes.c_uint16),
                ("biBitCount", ctypes.c_uint16), ("biCompression", ctypes.c_uint32),
                ("biSizeImage", ctypes.c_uint32), ("biXPelsPerMeter", ctypes.c_int32),
                ("biYPelsPerMeter", ctypes.c_int32), ("biClrUsed", ctypes.c_uint32),
                ("biClrImportant", ctypes.c_uint32)]


def _screen_bounds() -> tuple[int, int, int, int]:
    u = ctypes.windll.user32
    return (u.GetSystemMetrics(76), u.GetSystemMetrics(77),
            u.GetSystemMetrics(78), u.GetSystemMetrics(79))


def _bbox_to_image(bbox: tuple, use_printwindow: bool = False):
    """把屏幕（或某个窗口）抓成 PIL 图片。"""
    from PIL import Image

    u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
    u32.GetDC.restype = ctypes.c_void_p
    g32.CreateCompatibleDC.restype = ctypes.c_void_p
    g32.CreateCompatibleBitmap.restype = ctypes.c_void_p
    hwnd, x, y, w, h = bbox
    src = u32.GetWindowDC(ctypes.c_void_p(hwnd)) if use_printwindow else u32.GetDC(0)
    mem = g32.CreateCompatibleDC(ctypes.c_void_p(src))
    bmp = g32.CreateCompatibleBitmap(ctypes.c_void_p(src), w, h)
    g32.SelectObject(ctypes.c_void_p(mem), ctypes.c_void_p(bmp))
    if use_printwindow:
        u32.PrintWindow(ctypes.c_void_p(hwnd), ctypes.c_void_p(mem), 2)
    else:
        g32.BitBlt(ctypes.c_void_p(mem), 0, 0, w, h, ctypes.c_void_p(src), x, y, 0x00CC0020)
    info = _BIH()
    info.biSize = ctypes.sizeof(_BIH)
    info.biWidth, info.biHeight = w, -h
    info.biPlanes, info.biBitCount, info.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(ctypes.c_void_p(mem), ctypes.c_void_p(bmp), 0, h, buf, ctypes.byref(info), 0)
    im = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1)
    g32.DeleteObject(ctypes.c_void_p(bmp))
    g32.DeleteDC(ctypes.c_void_p(mem))
    if use_printwindow:
        u32.ReleaseDC(ctypes.c_void_p(hwnd), ctypes.c_void_p(src))
    else:
        u32.ReleaseDC(0, ctypes.c_void_p(src))
    return im


def _overlay_bbox(title: str = OVERLAY_TITLE):
    """找悬浮窗的位置（要把它合进截图里）。"""
    u32 = ctypes.windll.user32
    found: list = []
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def cb(hwnd, _l):
        if u32.IsWindowVisible(hwnd):
            buf = ctypes.create_unicode_buffer(128)
            u32.GetWindowTextW(hwnd, buf, 128)
            if buf.value == title:
                found.append(hwnd)
        return True

    u32.EnumWindows(CB(cb), 0)
    if not found:
        return None
    hwnd = found[0]
    rect = (ctypes.c_int32 * 4)()
    u32.GetWindowRect(ctypes.c_void_p(hwnd), ctypes.byref(rect))
    l, t, r, b = rect
    return (hwnd, l, t, r - l, b - t)


def grab_screen_image(with_overlay: bool = True):
    """抓一张整屏（默认把悬浮窗按 α 合进去，跟肉眼看到的一致）。"""
    from PIL import Image

    vx, vy, vw, vh = _screen_bounds()
    im = _bbox_to_image((0, vx, vy, vw, vh)).convert("RGB")
    if not with_overlay:
        return im
    box = _overlay_bbox()
    if not box:
        return im
    try:
        hwnd, x, y, w, h = box
        ov = _bbox_to_image((hwnd, 0, 0, w, h), use_printwindow=True)
        alpha = ov.getchannel("A").point(lambda v: int(v * 0.95))   # 悬浮窗 95% 不透明
        ov.putalpha(alpha)
        im.paste(ov.convert("RGB"), (x - vx, y - vy), alpha)
    except Exception:
        pass
    return im


def _ensure_dir() -> Path:
    SHOT_DIR.mkdir(parents=True, exist_ok=True)
    return SHOT_DIR


def take_shot(prefix: str = "屏幕", max_width: int = 2560) -> Optional[Path]:
    """截一张屏，返回文件路径。"""
    try:
        _ensure_dir()
        im = grab_screen_image()
        if im.width > max_width:                    # 5120 宽的屏直接存要 5MB，缩一半够看了
            im = im.resize((max_width, max(1, int(im.height * max_width / im.width))))
        p = SHOT_DIR / f"{prefix}-{time.strftime('%m%d-%H%M%S')}.png"
        im.save(p, optimize=True)
        prune()
        return p
    except Exception:
        return None


def record_screen(seconds: float = 8.0, fps: int = 8, width: int = 960) -> Optional[Path]:
    """录一小段屏幕，写成动图（webp 优先，gif 兜底）——手机浏览器都能播。"""
    try:
        _ensure_dir()
        vx, vy, vw, vh = _screen_bounds()
        frames = []
        delay = 1.0 / max(3, min(15, fps))
        end_at = time.time() + max(1.0, min(60.0, seconds))
        while time.time() < end_at:
            t0 = time.time()
            im = _bbox_to_image((0, vx, vy, vw, vh)).convert("RGB")
            if im.width > width:
                im = im.resize((width, max(1, int(im.height * width / im.width))))
            frames.append(im)
            spent = time.time() - t0
            if spent < delay:
                time.sleep(delay - spent)
        if not frames:
            return None
        out_webp = SHOT_DIR / f"录像-{time.strftime('%m%d-%H%M%S')}.webp"
        try:
            frames[0].save(out_webp, "WEBP", save_all=True, append_images=frames[1:],
                           duration=int(1000 * delay), loop=0, quality=70, method=4)
            prune()
            return out_webp
        except Exception:
            out_gif = out_webp.with_suffix(".gif")
            frames[0].save(out_gif, save_all=True, append_images=frames[1:],
                           duration=int(1000 * delay), loop=0, optimize=True)
            prune()
            return out_gif
    except Exception:
        return None


def list_shots(limit: int = 24) -> list[dict]:
    """最近发过来的屏幕（新的在前）。"""
    if not SHOT_DIR.exists():
        return []
    out = []
    for p in sorted(SHOT_DIR.glob("*"), key=lambda f: f.stat().st_mtime, reverse=True)[:limit]:
        if p.suffix.lower() not in (".png", ".webp", ".gif", ".jpg", ".jpeg"):
            continue
        st = p.stat()
        out.append({"name": p.name, "kind": "video" if p.suffix.lower() in (".webp", ".gif")
                    else "image", "ts": st.st_mtime, "kb": round(st.st_size / 1024, 1)})
    return out


def prune(keep: int = 24) -> None:
    """只留最近这些，别把硬盘塞满。"""
    if not SHOT_DIR.exists():
        return
    files = sorted(SHOT_DIR.glob("*"), key=lambda f: f.stat().st_mtime, reverse=True)
    for old in files[keep:]:
        try:
            old.unlink()
        except Exception:
            pass


def shot_path(name: str) -> Optional[Path]:
    """按名字取文件（只认这个目录里的、名字里没有路径分隔符的，防穿越）。"""
    if not name or "/" in name or "\\" in name or ".." in name:
        return None
    p = SHOT_DIR / name
    return p if p.is_file() else None
