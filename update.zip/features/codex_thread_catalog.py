# -*- coding: utf-8 -*-
"""Read Codex projects and threads without writing its state database."""
from __future__ import annotations

import json
from pathlib import Path

from features import codex_app_server
from features.codex_ui_bridge import current_title


HERE = Path(__file__).resolve().parents[1]
DB = Path.home() / ".codex" / "state_5.sqlite"
INDEX = Path.home() / ".codex" / "session_index.jsonl"
GLOBAL_STATE = Path.home() / ".codex" / ".codex-global-state.json"


def ui_current_title() -> str:
    return current_title()


def _index_titles() -> dict[str, str]:
    names: dict[str, str] = {}
    try:
        for line in INDEX.read_text(
            encoding="utf-8",
            errors="replace",
        ).splitlines():
            try:
                item = json.loads(line)
            except Exception:
                continue
            if isinstance(item, dict) and item.get("id") and item.get("thread_name"):
                names[str(item["id"])] = str(item["thread_name"]).strip()
    except Exception:
        pass
    return names


def _paged(
    method: str,
    params: dict,
    key: str = "data",
    page_limit: int = 200,
    max_pages: int = 8,
) -> tuple[list[dict], dict]:
    rows: list[dict] = []
    extra: dict = {}
    cursor = None
    for _ in range(max_pages):
        query = dict(params)
        query["limit"] = page_limit
        if cursor:
            query["cursor"] = cursor
        result = codex_app_server._rpc(method, query, timeout=25.0)
        if not isinstance(result, dict):
            break
        data = result.get(key)
        if isinstance(data, list):
            rows.extend(item for item in data if isinstance(item, dict))
        if isinstance(result.get("readStates"), dict):
            extra.setdefault("readStates", {}).update(result["readStates"])
        cursor = result.get("nextCursor")
        if not cursor:
            break
    return rows, extra


def _desktop_project_state() -> tuple[list[dict], dict[str, str], dict[str, str]]:
    """Read the project hierarchy currently shown by the desktop app.

    ``project/list`` still returns legacy projects after Codex migrates the
    sidebar to its newer project records.  Those stale rows are why the phone
    can show projects the desktop no longer displays.  The desktop's global
    state contains the visible order, names, roots, current project IDs and
    thread assignments; use that as the source of truth and translate legacy
    IDs to the app-server IDs used by project actions.
    """
    try:
        state = json.loads(GLOBAL_STATE.read_text(encoding="utf-8"))
        if not isinstance(state, dict):
            return [], {}, {}
        local_projects = state.get("local-projects")
        if not isinstance(local_projects, dict) or not local_projects:
            return [], {}, {}

        id_map_by_host = state.get(
            "app-server-project-id-by-legacy-project-id-by-host"
        )
        app_server_ids: dict[str, str] = {}
        if isinstance(id_map_by_host, dict):
            for mapping in id_map_by_host.values():
                if not isinstance(mapping, dict):
                    continue
                for legacy_id, app_server_id in mapping.items():
                    legacy_id = str(legacy_id or "")
                    app_server_id = str(app_server_id or "")
                    if legacy_id and app_server_id:
                        app_server_ids[legacy_id] = app_server_id

        order = state.get("project-order")
        ordered_ids = [str(item) for item in order] if isinstance(order, list) else []
        for legacy_id in local_projects:
            if str(legacy_id) not in ordered_ids:
                ordered_ids.append(str(legacy_id))

        projects: list[dict] = []
        aliases: dict[str, str] = {}
        for position, legacy_id in enumerate(ordered_ids):
            project = local_projects.get(legacy_id)
            if not isinstance(project, dict):
                continue
            name = str(project.get("name") or "").strip()
            app_server_id = app_server_ids.get(legacy_id, legacy_id)
            if not name or not app_server_id:
                continue
            roots = [
                {"path": str(path)}
                for path in (project.get("rootPaths") or [])
                if str(path or "").strip()
            ]
            projects.append(
                {
                    "id": app_server_id,
                    "name": name,
                    "position": position,
                    "recency_at": 0,
                    "roots": roots,
                }
            )
            aliases[legacy_id] = app_server_id

        assignments: dict[str, str] = {}
        raw_assignments = state.get("thread-project-assignments")
        if isinstance(raw_assignments, dict):
            for thread_id, item in raw_assignments.items():
                if not isinstance(item, dict):
                    continue
                legacy_id = str(item.get("projectId") or "")
                if thread_id and legacy_id in aliases:
                    assignments[str(thread_id)] = aliases[legacy_id]
        return projects, aliases, assignments
    except Exception:
        return [], {}, {}


def list_projects() -> list[dict]:
    desktop_projects, _, _ = _desktop_project_state()
    if desktop_projects:
        return desktop_projects
    try:
        rows, _ = _paged(
            "project/list",
            {"sortKey": "position", "sortDirection": "asc"},
        )
        result = []
        for project in rows:
            pid = str(project.get("id") or "")
            name = str(project.get("name") or "").strip()
            if pid and name:
                result.append(
                    {
                        "id": pid,
                        "name": name,
                        "position": int(project.get("position") or 0),
                        "recency_at": int(project.get("recencyAt") or 0) * 1000,
                        "roots": project.get("roots") or [],
                    }
                )
        return result
    except Exception:
        return []


def _sections() -> list[dict]:
    try:
        rows, _ = _paged("threadSection/list", {}, page_limit=100)
        return [row for row in rows if row.get("id") and row.get("name")]
    except Exception:
        return []


def _fallback_threads() -> list[dict]:
    try:
        import sqlite3

        if not DB.exists():
            return []
        connection = sqlite3.connect(f"file:{DB.as_posix()}?mode=ro", uri=True)
        try:
            projects = {
                str(pid): str(name)
                for pid, name in connection.execute("select id, name from projects")
            }
            names = _index_titles()
            current = ui_current_title()
            rows = []
            for record in connection.execute(
                "select id,title,name,first_user_message,project_id,archived,"
                "updated_at_ms,recency_at_ms,preview from threads "
                "where coalesce(archived,0)=0 "
                "order by coalesce(recency_at_ms,updated_at_ms) desc"
            ):
                tid, title, name, first, pid, _archived, updated, recency, preview = record
                tid = str(tid)
                clean_name = names.get(tid) or str(
                    name or title or first or ""
                ).strip()[:80]
                if not clean_name:
                    continue
                rows.append(
                    {
                        "id": tid,
                        "name": clean_name,
                        "title": clean_name,
                        "current": bool(current and clean_name == current),
                        "pinned": False,
                        "unread": False,
                        "project": projects.get(str(pid or ""), ""),
                        "project_id": str(pid or ""),
                        "archived": False,
                        "updated_at": int(recency or updated or 0),
                        "created_at": 0,
                        "preview": str(preview or "")[:160],
                        "section_id": "",
                        "section": "",
                        "status": "",
                        "read_revision": "",
                        "from_db": True,
                    }
                )
            return rows
        finally:
            connection.close()
    except Exception:
        return []


def list_threads() -> list[dict]:
    """Return the same hierarchy used by the desktop conversation picker."""
    projects, project_aliases, thread_assignments = _desktop_project_state()
    if not projects:
        projects = list_projects()
    project_names = {project["id"]: project["name"] for project in projects}
    project_roots: list[tuple[str, str, int]] = []
    for project in projects:
        for root in project.get("roots") or []:
            path = str((root or {}).get("path") or "").replace("/", "\\").lower()
            if path.startswith("\\\\?\\"):
                path = path[4:]
            if path:
                project_roots.append(
                    (
                        path.rstrip("\\"),
                        project["id"],
                        int(project.get("position") or 0),
                    )
                )
    sections = _sections()
    section_names = {str(section["id"]): str(section["name"]) for section in sections}
    names = _index_titles()
    current = ui_current_title()
    try:
        visible, extra = _paged(
            "thread/list",
            {
                "archived": False,
                "useStateDbOnly": True,
                "sortKey": "recency_at",
                "sortDirection": "desc",
            },
        )
        archived, _ = _paged(
            "thread/list",
            {
                "archived": True,
                "useStateDbOnly": True,
                "sortKey": "updated_at",
                "sortDirection": "desc",
            },
        )
    except Exception:
        return _fallback_threads()

    read_states = extra.get("readStates")
    if not isinstance(read_states, dict):
        read_states = {}
    result: list[dict] = []
    for source, is_archived in ((visible, False), (archived, True)):
        for thread in source:
            tid = str(thread.get("id") or "")
            if not tid:
                continue
            title = (
                names.get(tid)
                or str(thread.get("name") or "").strip()
                or str(thread.get("preview") or "").strip()[:80]
            )
            if not title:
                continue
            pid = (
                thread_assignments.get(tid)
                or project_aliases.get(str(thread.get("projectId") or ""))
                or str(thread.get("projectId") or "")
            )
            if pid not in project_names:
                pid = ""
            cwd = str(thread.get("cwd") or "").replace("/", "\\").lower()
            if cwd.startswith("\\\\?\\"):
                cwd = cwd[4:]
            if not pid and cwd:
                leaf = cwd.rstrip("\\").rsplit("\\", 1)[-1]
                matches = []
                for root, candidate_id, position in project_roots:
                    if cwd == root or cwd.startswith(root + "\\"):
                        project_name = project_names.get(candidate_id, "").casefold()
                        matches.append(
                            (
                                project_name == leaf,
                                len(root),
                                -position,
                                candidate_id,
                            )
                        )
                if matches:
                    pid = max(matches)[3]
            section = thread.get("section")
            if not isinstance(section, dict):
                section = {}
            sid = str(section.get("id") or "")
            section_name = str(section.get("name") or section_names.get(sid) or "")
            read_state = read_states.get(tid)
            if not isinstance(read_state, dict):
                read_state = {}
            updated = int(thread.get("recencyAt") or thread.get("updatedAt") or 0)
            created = int(thread.get("createdAt") or 0)
            result.append(
                {
                    "id": tid,
                    "name": title,
                    "title": title,
                    "current": bool(current and title == current),
                    "pinned": bool(
                        section_name
                        and section_name.casefold()
                        in {"pinned", "置顶", "已置顶", "top"}
                    ),
                    "unread": bool(read_state.get("firstUnread")),
                    "project": project_names.get(pid, ""),
                    "project_id": pid,
                    "archived": bool(is_archived),
                    "updated_at": updated * 1000 if updated < 10_000_000_000 else updated,
                    "created_at": created * 1000 if created < 10_000_000_000 else created,
                    "preview": str(thread.get("preview") or "")[:160],
                    "section_id": sid,
                    "section": section_name,
                    "status": (
                        (thread.get("status") or {}).get("type")
                        if isinstance(thread.get("status"), dict)
                        else ""
                    ),
                    "read_revision": str(read_state.get("revision") or ""),
                    "from_db": False,
                }
            )

    result.sort(
        key=lambda row: (
            bool(row.get("pinned")),
            int(row.get("updated_at") or 0),
            int(row.get("created_at") or 0),
        ),
        reverse=True,
    )
    return result
