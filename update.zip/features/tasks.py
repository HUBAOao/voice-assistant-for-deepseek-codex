# -*- coding: utf-8 -*-
"""Persistent task state, approvals, tool activity, tests, and diffs."""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from pathlib import Path
from typing import Any

STATUSES = {
    "queued",
    "running",
    "waiting_approval",
    "succeeded",
    "failed",
    "cancelled",
}

RISK_KEYWORDS = {
    "high": (
        "删除", "永久", "格式化", "卸载", "发布", "推送", "付款", "转账",
        "rm -rf", "del ", "remove-item", "drop table", "reset --hard",
    ),
    "medium": (
        "安装", "更新", "移动", "改名", "重命名", "上传", "提交", "commit",
        "merge", "覆盖", "write", "write_text",
    ),
}


def classify_risk(command: str) -> str:
    text = str(command or "").lower()
    for risk in ("high", "medium"):
        if any(word in text for word in RISK_KEYWORDS[risk]):
            return risk
    return "low"


class TaskStore:
    """Small thread-safe JSON task store with atomic writes."""

    def __init__(self, path: Path | None = None) -> None:
        configured = os.environ.get("FIN_DECK_TASKS_FILE", "").strip()
        if path is None and configured:
            path = Path(configured)
        if path is None:
            try:
                import storage_paths

                path = storage_paths.DATA_ROOT / "任务" / "tasks.json"
            except Exception:
                path = Path(__file__).resolve().parent.parent / "任务" / "tasks.json"
        self.path = Path(path)
        self._lock = threading.RLock()

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("tasks"), dict):
                return data
        except Exception:
            pass
        return {"version": 1, "tasks": {}}

    def _save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self.path)

    @staticmethod
    def _event(task: dict[str, Any], kind: str, detail: str = "") -> None:
        events = task.setdefault("events", [])
        events.append({"at": time.time(), "kind": str(kind)[:40],
                       "detail": str(detail)[:300]})
        if len(events) > 200:
            del events[:-200]

    def create(self, title: str, *, thread_id: str = "", detail: str = "") -> dict[str, Any]:
        title = str(title or "").strip() or "未命名任务"
        now = time.time()
        task = {
            "id": "task_" + uuid.uuid4().hex[:16],
            "title": title[:160],
            "detail": str(detail or "")[:1000],
            "thread_id": str(thread_id or ""),
            "status": "queued",
            "created_at": now,
            "updated_at": now,
            "tool_calls": [],
            "tests": [],
            "changes": [],
            "messages": [],
            "approval": None,
            "error": "",
            "events": [],
        }
        self._event(task, "created")
        with self._lock:
            data = self._load()
            data["tasks"][task["id"]] = task
            self._save(data)
        return dict(task)

    def get(self, task_id: str) -> dict[str, Any] | None:
        with self._lock:
            task = self._load()["tasks"].get(str(task_id))
            return dict(task) if task else None

    def find_by_source(self, source: str, source_id: str) -> dict[str, Any] | None:
        with self._lock:
            for task in self._load()["tasks"].values():
                if (task.get("source") == str(source)
                        and task.get("source_id") == str(source_id)):
                    return dict(task)
        return None

    def list(self, *, status: str = "", limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            tasks = list(self._load()["tasks"].values())
        if status:
            tasks = [task for task in tasks if task.get("status") == status]
        tasks.sort(key=lambda task: float(task.get("updated_at") or 0), reverse=True)
        return [dict(task) for task in tasks[:max(1, int(limit))]]

    def update(self, task_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            data = self._load()
            task = data["tasks"].get(str(task_id))
            if not task:
                raise KeyError("任务不存在")
            status = fields.get("status")
            if status and status not in STATUSES:
                raise ValueError("未知任务状态：%s" % status)
            for key, value in fields.items():
                if key in {"id", "created_at", "events"}:
                    continue
                task[key] = value
            task["updated_at"] = time.time()
            self._event(task, "updated", ",".join(sorted(fields)))
            self._save(data)
            return dict(task)

    def request_approval(self, task_id: str, command: str, *,
                         target: str = "", risk: str = "") -> dict[str, Any]:
        risk = str(risk or classify_risk(command)).lower()
        if risk not in {"low", "medium", "high"}:
            risk = "high"
        approval = {
            "command": str(command or "")[:2000],
            "target": str(target or "")[:500],
            "risk": risk,
            "requested_at": time.time(),
            "decision": "pending",
        }
        return self.update(task_id, status="waiting_approval", approval=approval)

    def decide(self, task_id: str, approved: bool, note: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        approval = task.get("approval") or {}
        if approval.get("decision") != "pending":
            raise ValueError("没有待批准请求")
        approval.update({
            "decision": "approved" if approved else "rejected",
            "decided_at": time.time(),
            "note": str(note or "")[:500],
        })
        status = "running" if approved else "cancelled"
        return self.update(task_id, status=status, approval=approval)

    def add_tool_call(self, task_id: str, name: str, *, status: str = "running",
                      detail: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        calls = list(task.get("tool_calls") or [])
        calls.append({"name": str(name)[:120], "status": str(status)[:30],
                      "detail": str(detail)[:1000], "at": time.time()})
        return self.update(task_id, tool_calls=calls[-100:])

    def add_test(self, task_id: str, name: str, ok: bool, *,
                 detail: str = "") -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        tests = list(task.get("tests") or [])
        tests.append({"name": str(name)[:160], "ok": bool(ok),
                      "detail": str(detail)[:2000], "at": time.time()})
        return self.update(task_id, tests=tests[-100:])

    def set_changes(self, task_id: str, changes: list[dict[str, Any]]) -> dict[str, Any]:
        clean = []
        for item in list(changes or [])[:500]:
            if not isinstance(item, dict):
                continue
            clean.append({
                "path": str(item.get("path") or "")[:500],
                "status": str(item.get("status") or "modified")[:30],
                "added": int(item.get("added") or 0),
                "removed": int(item.get("removed") or 0),
            })
        return self.update(task_id, changes=clean)

    def queue_message(self, task_id: str, text: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        messages.append({"id": uuid.uuid4().hex[:12], "text": str(text or "")[:4000],
                         "status": "queued", "at": time.time()})
        return self.update(task_id, messages=messages[-100:])

    def edit_message(self, task_id: str, message_id: str, text: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["text"] = str(text or "")[:4000]
                item["status"] = "queued"
                item["edited_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def cancel_message(self, task_id: str, message_id: str) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        for item in messages:
            if item.get("id") == str(message_id):
                item["status"] = "cancelled"
                item["cancelled_at"] = time.time()
                return self.update(task_id, messages=messages)
        raise KeyError("消息不存在")

    def reorder_messages(self, task_id: str, message_ids: list[str]) -> dict[str, Any]:
        task = self.get(task_id)
        if not task:
            raise KeyError("任务不存在")
        messages = list(task.get("messages") or [])
        by_id = {str(item.get("id")): item for item in messages}
        ordered = [by_id.pop(str(mid)) for mid in message_ids if str(mid) in by_id]
        ordered.extend(item for item in messages if str(item.get("id")) in by_id)
        for idx, item in enumerate(ordered):
            item["position"] = idx
        return self.update(task_id, messages=ordered)


_SYNC_LOCK = threading.Lock()
_LAST_SYNC = 0.0


def _turn_status(status: str) -> str:
    return {
        "inProgress": "running",
        "completed": "succeeded",
        "failed": "failed",
        "interrupted": "cancelled",
    }.get(str(status or ""), "queued")


def _turn_changes(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for item in items:
        if not isinstance(item, dict) or item.get("type") != "fileChange":
            continue
        for change in item.get("changes") or []:
            if not isinstance(change, dict):
                continue
            out.append({
                "path": str(change.get("path") or change.get("file") or "")[:500],
                "status": str(change.get("kind") or change.get("status") or "modified")[:30],
            })
    return out


def _turn_tools(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("type") or "")
        if kind == "commandExecution":
            command = str(item.get("command") or "")[:500]
            out.append({
                "name": "shell",
                "status": str(item.get("status") or "")[:30],
                "detail": command,
                "exit_code": item.get("exitCode"),
                "at": time.time(),
            })
        elif kind in {"collabAgentToolCall", "subAgentActivity"}:
            out.append({
                "name": kind,
                "status": str(item.get("status") or item.get("kind") or "")[:30],
                "detail": str(item.get("tool") or item.get("agentPath") or "")[:500],
                "at": time.time(),
            })
    return out[-100:]


def sync_recent_threads(store: TaskStore | None = None, *,
                        max_threads: int = 10, max_turns: int = 6) -> int:
    """Merge recent Codex turns into the task store without writing Codex state."""
    global _LAST_SYNC
    now = time.time()
    if now - _LAST_SYNC < 12:
        return 0
    if not _SYNC_LOCK.acquire(blocking=False):
        return 0
    try:
        if time.time() - _LAST_SYNC < 12:
            return 0
        import codex_threads

        store = store or TaskStore()
        changed = 0
        for row in codex_threads.list_threads()[:max_threads]:
            thread_id = str(row.get("id") or "")
            if not thread_id or row.get("archived"):
                continue
            try:
                data = codex_threads._rpc("thread/read", {
                    "threadId": thread_id,
                    "includeTurns": True,
                }, timeout=10)
            except Exception:
                continue
            thread = data.get("thread") or {}
            turns = list(thread.get("turns") or [])[-max_turns:]
            for turn in turns:
                source_id = str(turn.get("id") or "")
                if not source_id:
                    continue
                existing = store.find_by_source("codex_turn", source_id)
                task = existing or store.create(
                    str(thread.get("name") or thread.get("preview") or thread_id),
                    thread_id=thread_id,
                    detail="Codex 实时任务",
                )
                items = [x for x in (turn.get("items") or []) if isinstance(x, dict)]
                error = turn.get("error") or ""
                status = _turn_status(str(turn.get("status") or ""))
                tests = []
                for tool in _turn_tools(items):
                    command = str(tool.get("detail") or "").lower()
                    if "test" in command or "pytest" in command:
                        tests.append({
                            "name": str(tool.get("detail") or "test")[:160],
                            "ok": tool.get("status") == "completed"
                                  and int(tool.get("exit_code") or 0) == 0,
                            "detail": "",
                            "at": tool.get("at") or time.time(),
                        })
                store.update(
                    task["id"],
                    source="codex_turn",
                    source_id=source_id,
                    title=str(thread.get("name") or task.get("title") or thread_id),
                    thread_id=thread_id,
                    detail="Codex 实时任务",
                    status=status,
                    error=str(error)[:1000],
                    tool_calls=_turn_tools(items),
                    changes=_turn_changes(items),
                    tests=tests[-30:],
                )
                changed += 1
        _LAST_SYNC = time.time()
        return changed
    finally:
        _SYNC_LOCK.release()

