#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""语音助手悬浮窗（精简版 + 就地设置）。

平时只有四样东西：名字、状态、开关、以及贴着底部的一条声音波浪。
  · 有声音 → 波浪铺满底部，上下抖动（不是左右伸缩）
  · 没声音 → 缩到中间，变成一个上下浮动的小圆球
右下角是个小箭头：点一下浮窗平滑长大，就地展开设置（基本/声音/外观/布局）。
设置里改什么都立刻预览，满意了再保存；也有「恢复默认」。
"""

from __future__ import annotations

import ctypes
import atexit
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageTk

from ui_widgets import Slider, SpinRow, Switch
import wake_levels
import version
import memory_archive

HERE = Path(__file__).resolve().parent
STATUS = HERE / "status.json"
SPEAK_STATUS = HERE / "speak.json"
CONTROL = HERE / "control.json"
POS = HERE / "overlay_pos.json"
CONFIG = HERE / "config.json"
WAKE_TEST_FILE = HERE / "wake_test.json"
READY_FILE = HERE / "overlay_ready.json"   # "窗口已经显示出来了"的回执，给主程序看
SYSLOG_FILE = HERE / "syslog.md"
EXIT_LOG = HERE / "overlay-exit.log"
INPUT_LOG = HERE / "input.log"

FRAME_MS = 16                 # 约 60fps
FADE_SECONDS = 0.24           # 声音条换色（说话/静默、改配色）的过渡时长
RESIZE_STEPS = 8              # 展开/收起走多少步（按步数走，机器慢也不会变成大跳）
RESIZE_STEP_MS = 8            # 展开/收起期间两帧之间至少要隔这么久，不然窗口尺寸会被合并
SIMPLE_STEPS = 6              # 缩成侧边条 / 从侧边条放大回来：距离短，走更少的步，更快
SNAP_PX = 26                  # 拖到离屏幕边缘多近就吸上去
SIMPLE_LONG = 132             # 贴边后那条"简化版"有多长
SIMPLE_THICK = 20             # 以及多粗
STATUS_MS = 200
CONFIG_MS = 300
PANEL_H = 452                 # 五个标签页，留够高度
PANEL_H_OPEN = 560            # 展开设置后的固定高度（不再跟着标签页内容变，装不下就用滚轮看）
DEFAULT_ALPHA = 0.98
MIN_ALPHA, MAX_ALPHA = 0.35, 1.0

from overlay_feature.defaults import (
    ARROW, BG_PANEL, BORDER, CARD, COLORS, DEFAULTS, FX_DOT_KEYS, FX_KEYS,
    KNOB, LABELS, SW_H, SW_W, VOICES,
)


def _clone_entries() -> list[tuple[str, str, str, str]]:
    """本机装了语音克隆环境的话，把那些"真音色"也挂进音色列表。

    没装的机器上一律是空的（clone_voice.py 也不会跟着安装包发出去），
    所以别人的界面上根本不会出现这一栏。
    """
    try:
        import clone_voice

        return [(value, name, "", "") for value, name in clone_voice.models()]
    except Exception:
        return []


# 原来的 RVC 克隆音色（曼波/高松灯…）也不再挂出来 —— 只留上面这一种。
# _clone_entries() 留着但不调用，以后想恢复只要把下一行的注释去掉。
# VOICES.extend(_clone_entries())
from overlay_feature.runtime import (
    CONFIG,
    CONTROL,
    EXIT_LOG,
    FONT_FILES,
    INPUT_LOG,
    POS,
    READY_FILE,
    SPEAK_STATUS,
    STARTUP_LNK,
    STATUS,
    SYSLOG_FILE,
    WAKE_TEST_FILE,
    _pid_alive,
    font,
    hexs,
    inputlog,
    make_no_activate,
    mix,
    process_alive,
    rgb,
    safe_color,
    set_no_activate,
    shade,
    startup_exists,
    virtual_screen,
)
from overlay_feature import runtime as _runtime
from overlay_feature.dialogs import OverlayDialogMixin
from overlay_feature.presets_mixin import OverlayPresetsMixin
from overlay_feature.schedule_mixin import OverlayScheduleMixin
from overlay_feature.settings_mixin import OverlaySettingsMixin
from overlay_feature.settings_content_mixin import OverlaySettingsContentMixin
from overlay_feature.settings_pages_mixin import OverlaySettingsPagesMixin
from overlay_feature.visuals import OverlayVisualMixin


def load_config() -> dict:
    return _runtime.load_config(CONFIG)


def write_config(data: dict) -> None:
    _runtime.write_config(data, CONFIG)


def send_command(action: str) -> None:
    _runtime.send_command(action, CONTROL)


def note(text: str) -> None:
    _runtime.note(text, EXIT_LOG)


def inputlog(text: str) -> None:
    _runtime.inputlog(text, INPUT_LOG)


def single_instance() -> bool:
    return _runtime.single_instance(READY_FILE)

class Overlay(OverlayVisualMixin, OverlayDialogMixin, OverlayScheduleMixin,
              OverlayPresetsMixin, OverlaySettingsContentMixin,
              OverlaySettingsPagesMixin, OverlaySettingsMixin):
    def __init__(self) -> None:
        import tkinter as tk

        self.tk = tk
        self.cfg = load_config()
        self.cfg_mtime = CONFIG.stat().st_mtime if CONFIG.exists() else 0.0
        self.started = time.time()
        self.status: dict = {}
        self.miss = self.dead_hits = 0
        self._next_status = self._next_cfg = 0.0
        self.level = self.level_shown = 0.0
        self.breath = 0.0
        self.wave_phase = 0.0
        self.bar_heights: list[float] = []
        self.switch_pos = self.switch_target = 1.0
        self.state = "starting"
        self.text_fade = 1.0
        self.toast = ""
        self.toast_until = 0.0
        self.intro = 0.0
        self._drag = None
        self._sprites: dict = {}
        self._base = None
        self._base_key = None
        self._photo = None
        self.expanded = False
        self.alpha_override = None
        self.panel_h_shown = 0
        self.panel_h_natural = 0
        self.resize_from = None
        self._resize_key = None
        self.panel = None
        self.panel_win = None
        self._panel_fade_token = 0
        self._panel_geom = ""
        self.hint_label = None
        self._push_job = None
        # 声音条特效的运行时状态
        self.dt = 0.016
        self._sparks: list[dict] = []
        self._trail_img = None
        self._trail_key = None
        self._sweep_pos = 0.0
        self._sweep_base = None
        self.last_active = time.time()   # 养成：多久没人理它
        self.sleep_stage = 0             # 0 正常 / 1 打哈欠 / 2 睡着了
        self._pop = 0.0                  # 被叫醒时"弹一下"的强度
        self._frames = 0                 # 画了多少帧（配合帧时间判断要不要降级）
        self._frame_cost = 0.0           # 每帧平均画了多久
        self._auto_low = False           # 已经因为机器慢自动降过级了吗
        self._fx_before_low: dict | None = None   # 降级前你自己选的那套特效开关
        self._auto_low_off = False       # 你亲手把特效开回来了，这一轮就别再自动关
        self._degrade_stage = 0          # 0 没降 / 1 关了特效 / 2 连帧率也降了
        self._period = 0.0               # 帧间隔（上一帧开始到这一帧开始）
        self._gaps: list[float] = []     # 最近 60 帧的间隔，取中位数用
        self._slow_checks = 0            # 连着几次判定为"跟不上"
        self._started = time.time()      # 启动时刻：开机那段 CPU 尖峰不算数
        self.snap_edge = ""              # "" / left / right / top / bottom：吸在哪条边上
        self.hovered = False             # 鼠标是不是在窗口上（贴边时用它决定放大还是缩成小条）
        self.snap_on = True              # 贴边吸附总开关（设置里能关）
        self._panel_closing = False
        self.current_tab = "基本"
        self.wake_test_result = ""      # 最近一次唤醒词自检的结论
        self.focus_left = 0.0           # 番茄钟剩余秒数（0 = 没在专注）
        self.focus_total = 0.0          # 这一轮专注一共多久
        self.caption_win = None         # 大字幕窗口
        self.caption_label = None
        self.caption_last = ""
        self.caption_at = 0.0
        self.rec_win = None             # 录音提示灯
        self.editing_on = False          # 正在改设置？（这期间让主程序别抢键盘）
        self.wake_test_at = 0.0
        try:                            # 上次运行留下的自检结果不当成新的
            self._wake_test_ts = float(
                json.loads(WAKE_TEST_FILE.read_text(encoding="utf-8")).get("ts") or 0)
        except Exception:
            self._wake_test_ts = 0.0
        self._wake_seen = str(self.cfg.get("wake_word") or "")   # 用来判断唤醒词有没有被改
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self.cur_w = float(self.compact_w)
        self.cur_h = float(self.header_h)
        self.target_w, self.target_h = self.cur_w, self.cur_h

        x, y = self.load_pos()
        self.base_x, self.base_y = x, y
        # Windows 的定时器默认只有 ~15.6ms 的精度：after(16) 经常被拖到 23ms 才醒，
        # 60 帧根本跑不起来。目标帧率够高（>=50 帧）时才把精度提到 1ms，
        # 退出时还回去；节能/30 帧模式就不折腾了，省电。
        if os.name == "nt" and self.frame_ms <= 20:
            try:
                ctypes.windll.winmm.timeBeginPeriod(1)
                atexit.register(lambda: ctypes.windll.winmm.timeEndPeriod(1))
            except Exception:
                pass
        self.root = tk.Tk()
        self.root.title(self.name)
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=self.panel_color)
        self.root.geometry(f"{self.compact_w}x{self.header_h}+{x}+{y - 16}")
        self.root.attributes("-alpha", 0.0)
        self.root.update_idletasks()
        try:
            u = ctypes.windll.user32
            inner = self.root.winfo_id()
            make_no_activate(u.GetParent(inner) or inner)
            make_no_activate(inner)
        except Exception:
            pass

        self.canvas = tk.Canvas(self.root, width=self.compact_w, height=self.header_h,
                                bg=self.panel_color, highlightthickness=0)
        self.canvas.pack(side="top", fill="x")      # 宽度跟着窗口走，不用每帧单独设
        self._photo = ImageTk.PhotoImage(
            Image.new("RGB", (self.compact_w, self.header_h), self.panel_color))
        self.img_item = self.canvas.create_image(0, 0, anchor="nw", image=self._photo)
        self.canvas.bind("<Button-1>", self.on_press)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.open_menu)
        for widget in (self.canvas, self.root):
            widget.bind("<MouseWheel>", self.on_wheel)

        self.menu = tk.Menu(self.root, tearoff=0, bg="#26262d", fg="#ffffff",
                            activebackground=self.button_color, activeforeground="#ffffff",
                            font=("Microsoft YaHei UI", 9))
        self.menu.add_command(label="只关浮窗（程序继续跑）", command=self.quit)
        self.menu.add_command(label="🔇 静音 / 🔊 恢复出声（切换）",
                              command=lambda: send_command("toggle-mute"))
        self.menu.add_command(label="退出语音程序", command=self.quit_program)

        self.root.report_callback_exception = self.on_tk_error
        note(f"启动 pid={os.getpid()} 位置=({x},{y})")
        self.root.after(120, self.tick)
        self.root.after(self.frame_ms, self.anim)
        self.root.after(1500, self.maybe_first_run)
        self.root.after(4000, self.warm_panel)     # 闲着的时候先把设置面板备好

    def _overlay_send_command(self, action: str) -> None:
        send_command(action)

    def _overlay_load_config(self) -> dict:
        return load_config()

    def _overlay_write_config(self, data: dict) -> None:
        write_config(data)

    def warm_panel(self) -> None:
        """开了一会儿之后，偷偷把设置面板建好、摆到窗口外面去（窗口小，看不见）。

        为了让你第一次点箭头就是顺的：建面板要 map 七百个控件，就地卡 0.6~1.1 秒，
        以前这 0.6 秒正好卡在展开动画中间，动画就"没了"。
        """
        if self.panel is not None:
            return
        try:
            self.build_panel()
            self._place_panel(self._expanded_h())
            # 先在屏幕外/全透明状态下 map 一次，把控件树建好；真正展开时
            # 只是 deiconify + 淡入，不再现场 map 七百个控件。
            if self.panel_win is not None and not self.expanded:
                try:
                    self.panel_win.attributes("-alpha", 0.0)
                    self.panel_win.deiconify()
                    self.panel_win.update_idletasks()
                    self.panel_win.withdraw()
                except Exception:
                    pass
        except Exception as exc:  # noqa: BLE001
            note(f"预热设置面板失败：{type(exc).__name__}")

    def on_tk_error(self, exc_type, exc_value, exc_tb) -> None:
        import traceback

        note("回调异常: " + "".join(traceback.format_exception_only(exc_type, exc_value)).strip())
        try:
            # 写在"当前配置所在的那个目录"：正常就是程序目录；脚本测试时会把 CONFIG
            # 指到临时目录，报错就落在那儿，不会把真程序这条日志冲掉。
            (CONFIG.parent / "overlay-error.log").write_text(
                "".join(traceback.format_exception(exc_type, exc_value, exc_tb)), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------ 配置
    def cfg_get(self, key: str):
        return self.cfg.get(key, DEFAULTS.get(key))

    def apply_config(self) -> None:
        c = self.cfg
        self.name = str(c.get("name") or DEFAULTS["name"])
        # 颜色一律先过校验：写错了不让它崩，退回默认值
        self.panel_color = safe_color(c.get("overlay_color"), DEFAULTS["overlay_color"])
        self.accent = safe_color(c.get("overlay_accent"), DEFAULTS["overlay_accent"])
        self.button_color = safe_color(c.get("overlay_button"), DEFAULTS["overlay_button"])
        self.text_color = safe_color(c.get("overlay_text"), DEFAULTS["overlay_text"])
        self.talk_color = safe_color(c.get("overlay_talk_color"), DEFAULTS["overlay_talk_color"])
        self.bg_image = str(c.get("overlay_bg_image") or "")
        self.bg_dim = int(c.get("overlay_bg_dim") or DEFAULTS["overlay_bg_dim"])
        self.alpha = min(MAX_ALPHA, max(MIN_ALPHA, float(c.get("overlay_alpha") or DEFAULT_ALPHA)))
        self.W = int(c.get("overlay_width") or DEFAULTS["overlay_width"])
        self.H = int(c.get("overlay_height") or DEFAULTS["overlay_height"])
        self.show_name = bool(c.get("overlay_show_name", True))
        self.show_status = bool(c.get("overlay_show_status", True))
        self.show_line = bool(c.get("overlay_show_line", True))
        self.show_switch = bool(c.get("overlay_show_switch", True))
        self.line_follow = bool(c.get("overlay_line_follow_state", False))
        self.wave_style = str(c.get("overlay_wave_style") or "siri")
        # 声音条特效开关；节能模式下统一不画（你要求节能＝界面动画全关）
        self.fx = {key: bool(c.get(key, DEFAULTS[key])) for key in FX_KEYS}
        self.show_caption = bool(c.get("overlay_show_caption", True))
        self.caption_on = bool(c.get("caption_enabled", True))
        self.mood_on = bool(c.get("mood_enabled", True))
        self.mood_idle = bool(c.get("mood_idle", True))
        self.spectrum_on = bool(c.get("wave_spectrum", False))
        self.karaoke_on = bool(c.get("karaoke", True))
        self.big_on = bool(c.get("big_caption", False))
        self.big_size = max(16, min(72, int(c.get("big_caption_size") or 34)))
        self.rec_on = bool(c.get("rec_indicator", True))
        self.snap_on = bool(c.get("snap_edges", True))   # 贴边吸附总开关
        # 性能模式：eco 关界面动画、质量模式帧率拉满
        self.perf = str(c.get("perf_mode") or "quality")
        self.fps = max(15, min(60, int(c.get("anim_fps") or 60)))
        if self.perf == "eco":
            self.fps = min(self.fps, 20)
        elif self.perf == "standard":
            self.fps = min(self.fps, 40)
        self.frame_ms = max(8, int(1000 / self.fps))
        self.auto_tune = bool(c.get("auto_tune", True))   # 机器慢时要不要自动降级
        self.layout = {
            "name": (int(self.cfg_get("ov_name_x")), int(self.cfg_get("ov_name_y")),
                     int(self.cfg_get("ov_name_size"))),
            "status": (int(self.cfg_get("ov_status_x")), int(self.cfg_get("ov_status_y")),
                       int(self.cfg_get("ov_status_size"))),
            "switch": (int(self.cfg_get("ov_switch_x")), int(self.cfg_get("ov_switch_y"))),
            "wave": (int(self.cfg_get("ov_wave_y")), int(self.cfg_get("ov_wave_h"))),
        }

    def reload_config_if_changed(self) -> None:
        now = time.time()
        if now < self._next_cfg:
            return
        self._next_cfg = now + CONFIG_MS / 1000
        try:
            mtime = CONFIG.stat().st_mtime
        except OSError:
            return
        if mtime == self.cfg_mtime:
            return
        self.cfg_mtime = mtime
        self.cfg = load_config()
        self.apply_saved()

    def apply_saved(self) -> None:
        self.apply_config()
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        # 主浮窗永远保持紧凑尺寸；设置面板是独立窗口
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        self._base_key = None
        self.root.title(self.name)
        self.root.configure(bg=self.panel_color)
        self.canvas.configure(bg=self.panel_color)
        self.menu.configure(activebackground=self.button_color)

    # ------------------------------------------------------------ 位置
    def load_pos(self) -> tuple[int, int]:
        try:
            data = json.loads(POS.read_text(encoding="utf-8"))
            self.snap_edge = str(data.get("snap") or "")
            return int(data["x"]), int(data["y"])
        except Exception:
            pass
        screen = 1920
        try:
            screen = ctypes.windll.user32.GetSystemMetrics(0)
        except Exception:
            pass
        return screen - 344 - 40, 60

    # ------------------------------------------------------------ 交互
    def on_press(self, event) -> None:
        if self.hit_arrow(event.x, event.y):
            self.set_expanded(not self.expanded)
            return
        if self.hit_switch(event.x, event.y):
            self.toggle_switch()
            return
        self._drag = (event.x_root - self.root.winfo_x(), event.y_root - self.root.winfo_y())

    def on_drag(self, event) -> None:
        if not self._drag:
            return
        dx, dy = self._drag
        self.base_x, self.base_y = event.x_root - dx, event.y_root - dy
        self.root.geometry(f"+{self.base_x}+{self.base_y}")

    def on_release(self, _event) -> None:
        self._drag = None
        self.try_snap()
        self.save_pos()

    def save_pos(self) -> None:
        try:
            POS.write_text(json.dumps({
                "x": self.root.winfo_x(), "y": self.root.winfo_y(),
                "snap": self.snap_edge,
            }), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------- 贴边吸附 / 简化版
    def simple_size(self) -> tuple:
        """贴边之后那条"简化版"的尺寸：竖边竖条、横边横条。"""
        if self.snap_edge in ("left", "right"):
            return SIMPLE_THICK, SIMPLE_LONG
        if self.snap_edge in ("top", "bottom"):
            return SIMPLE_LONG, SIMPLE_THICK
        return self.compact_w, self.header_h

    def simple_on(self) -> bool:
        """什么时候缩成小条：吸在边上 + 鼠标不在上面 + 没展开设置。"""
        return bool(self.snap_edge) and self.snap_on and not self.hovered \
            and not self.expanded and not self._drag

    def nearest_edge(self, x: int, y: int, w: int, h: int) -> str:
        vx, vy, vw, vh = virtual_screen()
        near = {"left": x - vx, "right": (vx + vw) - (x + w),
                "top": y - vy, "bottom": (vy + vh) - (y + h)}
        edge, dist = min(near.items(), key=lambda kv: kv[1])
        return edge if dist <= SNAP_PX else ""

    def try_snap(self) -> None:
        """松手之后看要不要吸到边上。"""
        if not self.snap_on or self.expanded:
            self.snap_edge = ""
            self.reset_target()
            return
        x, y = self.root.winfo_x(), self.root.winfo_y()
        self.snap_edge = self.nearest_edge(x, y, int(self.cur_w), int(self.cur_h))
        if self.snap_edge:
            self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            note(f"吸到{ {'left': '左边', 'right': '右边', 'top': '上边', 'bottom': '下边'}[self.snap_edge] }")
        else:
            self.reset_target()

    def reset_target(self) -> None:
        """不贴边了：把目标尺寸恢复成"平时的浮窗"（或者展开的面板）。

        不恢复的话，从边上拖走之后它还会一直按"小细条"的尺寸缩着。
        """
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._position_panel_window()

    def dock_pos(self, w: float, h: float) -> tuple:
        """吸在边上时，窗口该待在哪儿（跟着尺寸走，缩成小条也不会飘走）。"""
        vx, vy, vw, vh = virtual_screen()
        x, y = int(self.base_x), int(self.base_y)
        if self.snap_edge == "left":
            return vx, min(max(y, vy), vy + vh - int(h))
        if self.snap_edge == "right":
            return vx + vw - int(w), min(max(y, vy), vy + vh - int(h))
        if self.snap_edge == "top":
            return min(max(x, vx), vx + vw - int(w)), vy
        if self.snap_edge == "bottom":
            return min(max(x, vx), vx + vw - int(w)), vy + vh - int(h)
        return x, y

    def clamp_on_screen(self, x: int, y: int, w: int, h: int) -> tuple:
        """展开设置面板之后别跑到屏幕外面去。"""
        vx, vy, vw, vh = virtual_screen()
        x = min(max(x, vx), max(vx, vx + vw - w))
        y = min(max(y, vy), max(vy, vy + vh - h))
        return x, y

    def watch_hover(self) -> None:
        """用指针位置判断鼠标在不在窗口上 —— 比 Enter/Leave 稳（子控件不会误报离开）。"""
        try:
            px, py = self.root.winfo_pointerxy()
        except Exception:
            return
        wx, wy = self.root.winfo_x(), self.root.winfo_y()
        self.hovered = (wx - 2 <= px <= wx + self.cur_w + 2
                        and wy - 2 <= py <= wy + self.cur_h + 2)

    def switch_rect(self) -> tuple[int, int]:
        """返回开关左上角。X 为负表示"离右边多远"，所以要减掉开关自身宽度。"""
        x, y = self.layout["switch"]
        x0 = (int(self.cur_w) + x - SW_W) if x < 0 else x
        return x0, y

    def hit_switch(self, x: int, y: int) -> bool:
        if not self.show_switch:
            return False
        x0, y0 = self.switch_rect()
        return x0 <= x <= x0 + SW_W and y0 <= y <= y0 + SW_H

    def hit_arrow(self, x: int, y: int) -> bool:
        ax = int(self.cur_w) - ARROW - 10
        ay = self.header_h - ARROW - 8
        return ax <= x <= ax + ARROW and ay <= y <= ay + ARROW

    def on_wheel(self, event) -> None:
        if not bool(self.cfg.get("wheel_alpha", True)):
            return
        delta = 0.02 if getattr(event, "delta", 0) > 0 else -0.02
        self.alpha = min(MAX_ALPHA, max(MIN_ALPHA, self.alpha + delta))
        data = load_config()
        data["overlay_alpha"] = round(self.alpha, 2)
        write_config(data)
        self.flash(f"透明度 {int(self.alpha * 100)}%")

    def toggle_switch(self) -> None:
        paused = self.status.get("state") == "paused"
        send_command("resume" if paused else "pause")
        self.flash("正在恢复…" if paused else "正在暂停…")

    def open_menu(self, event) -> None:
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def quit_program(self) -> None:
        send_command("quit")
        self.flash("已让语音程序退出")
        self.root.after(700, self.quit)

    def quit(self, reason: str = "用户关掉了浮窗") -> None:
        note(f"退出：{reason}")
        try:
            self.root.destroy()
        except Exception:
            pass

    def flash(self, text: str, seconds: float = 1.6) -> None:
        self.toast = text
        self.toast_until = time.time() + seconds

    # ------------------------------------------------------------ 贴图
    # ------------------------------------------------------------ 状态
    def read_status(self) -> dict:
        try:
            return json.loads(STATUS.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def handle_remote(self) -> None:
        try:
            data = json.loads(CONTROL.read_text(encoding="utf-8"))
        except Exception:
            return
        ts = float(data.get("ts") or 0)
        if ts <= getattr(self, "_ctrl_ts", 0.0):
            return
        self._ctrl_ts = ts
        action = str(data.get("action") or "")
        if action == "expand":
            self.set_expanded(True)
        elif action == "collapse":
            self.set_expanded(False)
        elif action == "qr":
            # 别的窗口 / 托盘 / 手机入口也能叫它把连接二维码弹出来
            self.show_qr()
        elif action == "perf":
            # 把当前的真实帧率情况写出来（用来量"到底卡不卡"，不用瞎猜）
            gaps = list(self._gaps)
            gaps.sort()
            med = gaps[len(gaps) // 2] * 1000 if gaps else 0.0
            p90 = gaps[int(len(gaps) * 0.9)] * 1000 if gaps else 0.0
            try:
                (HERE / "perf.json").write_text(json.dumps({
                    "目标帧率": self.fps, "帧预算ms": round(self.frame_ms, 1),
                    "中位间隔ms": round(med, 1),
                    "p90间隔ms": round(p90, 1),
                    "最差间隔ms": round(gaps[-1] * 1000, 1) if gaps else 0.0,
                    "实际帧率": round(1000 / med, 1) if med else 0.0,
                    "画一帧ms": round(self._frame_cost * 1000, 1),
                    "已降级": self._degrade_stage,
                    "特效": {k: v for k, v in self.fx.items() if k.startswith("fx_")},
                    "窗口": f"{int(self.cur_w)}x{int(self.cur_h)}",
                    "ts": time.time(),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass

    def tick(self) -> None:
        self.reload_config_if_changed()
        self.handle_remote()
        self.poll_wake_test()
        self.check_new_devices()          # 有新设备想连进来就弹窗问一声（公网那道门）
        self.sync_big_caption()
        self.sync_rec_dot()
        # 编辑状态别一直挂着：90 秒没敲字就自动让位（免得它永远不粘了）
        if self.editing_on and time.time() - getattr(self, "edit_touch", 0) > 90:
            self.set_editing(False)
        data = self.read_status()
        if data:
            self.miss = 0
            self.status = data
        else:
            self.miss += 1
            if self.miss == 40:
                note(f"连续 {self.miss} 次读不到 status.json")
        state = (self.status or {}).get("state") or "offline"
        # 「听到声音」只在真出声时算：麦克风底噪也能把 state 写成 hearing，
        # 那样浮窗会一直显示"听到声音了"（用户反馈）。这里按电平再看一道。
        if state == "hearing" and float((self.status or {}).get("level") or 0.0) < 0.05:
            state = "listening"
        self.state = state
        self.level = float((self.status or {}).get("level") or 0.0)
        self.focus_left = float((self.status or {}).get("focus") or 0.0)
        if self.focus_left <= 0:
            self.focus_total = 0.0
        elif self.focus_total <= 0 or self.focus_left > self.focus_total + 0.5:
            self.focus_total = self.focus_left      # 新的一轮专注
        self.switch_target = 0.0 if state == "paused" else 1.0
        if self.status:
            pid = int(self.status.get("pid") or 0)
            if time.time() - self.started > 8 and not process_alive(pid):
                self.dead_hits += 1
                if self.dead_hits >= 4:
                    note(f"退出：主程序不在了（pid={pid}）")
                    self.quit()
                    return
            else:
                self.dead_hits = 0
        elif self.miss >= 80:
            note("退出：连续读不到状态文件")
            self.quit()
            return
        self.root.after(STATUS_MS, self.tick)

    # ------------------------------------------------------------ 画面
    def anim(self) -> None:
        frame_t0 = time.perf_counter()
        now_t = time.time()
        self.dt = min(0.1, max(0.0, now_t - getattr(self, "_frame_t", now_t)))
        self._frame_t = now_t
        self._sweep_pos = (self._sweep_pos + self.dt * 0.55) % 1.0

        if self.intro < 1.0:
            self.intro = min(1.0, self.intro + 0.09)
            ease = 1 - (1 - self.intro) ** 3
            self.root.geometry(f"+{self.base_x}+{int(self.base_y - 16 * (1 - ease))}")
            self.root.attributes("-alpha", self.alpha * ease)

        # 贴边吸附：吸在边上、鼠标又不在上面的时候，缩成一条小细条；
        # 鼠标移上去自己放大回来。只有"吸在边上"才会这样，随便放桌面中间不受影响。
        if self._frames % 4 == 0:
            self.watch_hover()
        if self.snap_on and self.snap_edge:
            if self.simple_on():
                w_s, h_s = self.simple_size()
                self.target_w, self.target_h = float(w_s), float(h_s)
            elif not self.expanded:
                self.target_w = float(self.compact_w)
                self.target_h = float(self.header_h)
            # 展开设置时的高度交给 set_expanded() 管，别每帧算一遍面板高度
            # 正在拖的时候**千万别**抢位置：不然每帧都被拉回边缘，等于拖不动
            if self._drag is None:
                self.base_x, self.base_y = self.dock_pos(self.cur_w, self.cur_h)

        # 展开/收起：固定"步数"的缓动。
        # 为什么不用时间驱动？改窗口尺寸这一下是要 Windows 重新合成这个半透明窗口的，
        # 一帧要 20~30ms，用 0.24 秒去卡只能挤出 6 个台阶，头一步就跳掉三分之一，
        # 肉眼就是"卡"。改成固定 14 步：机器快就 230ms 走完，机器慢就慢一点，
        # 但每一步都是均匀的，看着才顺。
        if abs(self.target_w - self.cur_w) > 0.6 or abs(self.target_h - self.cur_h) > 0.6:
            key = (round(self.target_w, 1), round(self.target_h, 1))
            if self.resize_from is None or self._resize_key != key:
                # 目标一变就重新从"当前尺寸"开始走：否则会拿着上一次的进度，
                # 一帧就跳到位（收起时看起来就像没有动画）
                self._resize_key = key
                self._rz_step = 0
                self.resize_from = (self.cur_w, self.cur_h)
            w0, h0 = self.resize_from
            self._rz_step = getattr(self, "_rz_step", 0) + 1
            # 贴边小条那一下距离短，少走几步就到位（更快）；展开/收起面板走 8 步
            steps = SIMPLE_STEPS if (self.snap_edge and not self.expanded) else RESIZE_STEPS
            t = min(1.0, self._rz_step / float(steps))
            e = t * t * (3 - 2 * t)          # smoothstep：两头慢、中间快
            self.cur_w = w0 + (self.target_w - w0) * e
            self.cur_h = h0 + (self.target_h - h0) * e
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            self._base_key = None
            # 面板跟着窗口一起长（而不是一开始就摆到最终高度）：
            # 面板每帧都"变了尺寸"，Tk 就会把它整块重画；不然新露出来的那条
            # 是没画过的像素 —— 分层窗口里看着就是一条黑带。
            if self.expanded:
                self._place_panel(self.cur_h)
            # 展开/收起时窗口一变大，新露出来的那块必须**马上重画**。
            # 不重画的话它是"未绘制"的 —— 浮窗是分层窗口，未绘制 = 透明，
            # 你会直接看到后面的聊天窗口透过来，看着就是一大块黑边（真机抓到过整片黑）。
            self._repaint_now()
            if t >= 1.0:
                self.cur_w, self.cur_h = self.target_w, self.target_h
                self.resize_from = self._resize_key = self._rz_step = None
                self.root.geometry(
                    f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
                if self._panel_closing:        # 收起动画走完了，这才把面板撤掉
                    self._finish_panel_close()
        elif self.resize_from is not None:
            # 尺寸已经到位（差得不足 1px）：把缓动状态清干净，
            # 不然下一次展开/收起会拿着过期进度瞬间跳完
            self.cur_w, self.cur_h = self.target_w, self.target_h
            self.resize_from = self._resize_key = self._rz_step = None
            self.root.geometry(f"{int(self.cur_w)}x{int(self.cur_h)}+{self.base_x}+{self.base_y}")
            if self._panel_closing:
                self._finish_panel_close()

        # 面板是独立窗口：浮窗被拖动/吸边/换位置时，它跟着走
        if self.expanded and self.panel_win is not None:
            self._position_panel_window()

        # 帧率提高后每帧步长相应减小，观感速度保持一致
        self.level_shown += (self.level - self.level_shown) * 0.16
        self.breath = (self.breath + 0.055) % (2 * math.pi)
        self.wave_phase += 0.13 + 0.3 * self.level_shown
        if self.text_fade < 1.0:
            self.text_fade = min(1.0, self.text_fade + 0.07)
        if abs(self.switch_target - self.switch_pos) > 0.002:
            self.switch_pos += (self.switch_target - self.switch_pos) * 0.14
        else:
            self.switch_pos = self.switch_target

        state_color = COLORS.get(self.state, self.accent)
        # 我正在说话时：换成说话色，并用朗读的实时音量驱动形状和大小
        speak_active, speak_level, speak_text, speak_prog = self.read_speaking()
        if speak_active:
            self.level = speak_level

        # 养成：长时间没人理它会打哈欠→打盹；被叫醒时弹一下
        active = (self.level > 0.06 or speak_active
                  or self.state in ("listening", "hearing", "thinking", "sent",
                                    "copied", "focus"))
        if active:
            if self.sleep_stage >= 2:
                self._pop = 1.0
            self.last_active = now_t
            self.sleep_stage = 0
        elif self.mood_idle:
            idle = now_t - self.last_active
            self.sleep_stage = 2 if idle >= 240 else (1 if idle >= 120 else 0)
        else:
            self.sleep_stage = 0
        if self._pop > 0:
            self._pop = max(0.0, self._pop - self.dt * 2.0)

        # 颜色过渡：目标色变了就从"当前显示色"补间过去，用固定时长 + smoothstep，
        # 所以起步慢、收尾也慢，中间不会抖；帧率从 30 调到 60 快慢也一样。
        # 说话↔不说话换色、在设置里改配色，都会是渐变而不是"啪"地跳。
        now_t = time.time()
        target_hex = self.talk_color if speak_active else (
            state_color if self.line_follow else self.accent)
        # 语气反应：你吼得急，线条就往暖色偏；你轻声说，就往冷灰偏
        mood = str((self.status or {}).get("mood") or "")
        # 语气只在 10 秒内有效：不然一句"急"会一直黄下去，看着像自己变色
        if mood and time.time() - float((self.status or {}).get("mood_ts") or 0) > 10:
            mood = ""
        if self.mood_on and mood and not speak_active:
            target_hex = mix(target_hex, "#ff6b35" if mood == "急" else "#455270", 0.60)
        target_rgb = rgb(target_hex)
        cur = getattr(self, "_wave_rgb", None)
        if cur is None:
            cur = target_rgb
        if self.perf == "eco":                 # 节能模式：不做过渡，直接跳到目标色
            cur = target_rgb
            self._fade_from = target_rgb
            self._fade_to = target_rgb
            self._fade_t0 = now_t
            self._fade_dur = FADE_SECONDS
        else:
            if target_rgb != getattr(self, "_fade_to", None):
                self._fade_from = cur          # 从肉眼看到的颜色接着往下走
                self._fade_to = target_rgb
                self._fade_t0 = now_t
                self._fade_dur = FADE_SECONDS
            p = min(1.0, max(0.0, (now_t - self._fade_t0) / max(0.01, self._fade_dur)))
            e = p * p * (3 - 2 * p)            # smoothstep 缓动
            a = self._fade_from
            cur = tuple(a[i] + (self._fade_to[i] - a[i]) * e for i in range(3))
        self._wave_rgb = cur
        # 量化到 4 的倍数：过渡够细腻，又不会让渲染出来的颜色无限细分
        wave_color = hexs(tuple(round(c / 4) * 4 for c in cur))
        im = self.base_image().copy()
        d = ImageDraw.Draw(im)
        if self.simple_on():
            # 贴边时的"简化版小窗口"：只有一条会跟着声音起伏的细条
            self.draw_simple(im, d, wave_color)
        else:
            self.draw_full(im, d, wave_color, state_color, speak_active,
                           speak_text, speak_prog)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)
        # 透明度只在"真的变了"的时候设：每帧设一次会让窗口合成器每帧重算一遍
        if self.intro >= 1.0:
            want = self.alpha_override if self.alpha_override else self.alpha
            if abs(want - getattr(self, "_alpha_set", -1.0)) > 0.004:
                self._alpha_set = want
                try:
                    self.root.attributes("-alpha", want)
                except Exception:
                    pass
            # 给主程序回执："窗口真的画出来了"（动画循环活着 + 窗口可见 + 不是透明的）
            if (not getattr(self, "_ready_done", False)
                    or now_t - getattr(self, "_ready_ts", 0.0) > 10.0):
                self._ready_done = True
                self._ready_ts = now_t
                self.write_ready()
        # 下一帧按"这一帧开始的时间"排。以前是排在画完之后：
        # 画一帧要 6ms，间隔就变成 16+6=22ms，60 帧永远跑不到（实测只有 44 帧）。
        spent_ms = (time.perf_counter() - frame_t0) * 1000
        # 展开/收起动画期间还要留个最小步进间隔：改窗口尺寸这一步本身要 20ms 上下，
        # 不加下限的话每一步都"已经超时"，12 步会在一次事件循环里挤成一坨，
        # Windows 只画最后一个尺寸 —— 看着就是内容"啪"地出现/消失，中间什么都没有。
        floor_ms = RESIZE_STEP_MS if self.resize_from is not None else 1
        self.root.after(max(floor_ms, int(round(self.frame_ms - spent_ms))), self.anim)
        # 机器忙的时候自动降级。注意两点：
        #   · 看的是"帧间隔"（上一帧开始 → 这一帧开始），不是 anim 里的耗时 ——
        #     机器忙的时候进程会被抢走 CPU，墙体时间里的等待不该算成我们的锅；
        #   · 先关特效、不降帧。以前一上来就掉到 30 帧，结果"为了省 CPU 把画面变得更卡"。
        cost = time.perf_counter() - frame_t0
        self._frame_cost = getattr(self, "_frame_cost", cost) * 0.9 + cost * 0.1
        prev = getattr(self, "_prev_t", None)
        if prev is not None:
            gap = max(0.0, now_t - prev)
            self._period = getattr(self, "_period", gap) * 0.9 + gap * 0.1
            self._gaps.append(gap)
            if len(self._gaps) > 60:
                del self._gaps[:-60]
        self._prev_t = now_t
        self._frames = getattr(self, "_frames", 0) + 1
        budget = self.frame_ms / 1000.0
        gaps = self._gaps
        median = sorted(gaps)[len(gaps) // 2] if gaps else 0.0
        if median > budget * 1.25 and len(gaps) >= 60:
            self._slow_checks = getattr(self, "_slow_checks", 0) + 1
        else:
            self._slow_checks = 0
        if (getattr(self, "auto_tune", True)
                and not getattr(self, "_auto_low_off", False)   # 你亲手开回来的，就别再自动关
                and self._frames > 150
                and (now_t - getattr(self, "_started", now_t)) > 20
                and getattr(self, "_slow_checks", 0) >= 5):
            self._slow_checks = 0
            stage = getattr(self, "_degrade_stage", 0)
            if stage == 0:
                fancy = [k for k in FX_KEYS if self.fx.get(k)]
                if fancy:
                    # 先把"你自己选的那套"记下来：降级只是这一次运行的事，
                    # 不许它顺着"保存设置"溜进 config.json 变成你的新设置
                    self._fx_before_low = {k: bool(self.fx.get(k)) for k in FX_KEYS}
                    for k in fancy:
                        self.fx[k] = False
                    self._auto_low = True
                    self._degrade_stage = 1
                    self._frames = 0
                    note(f"帧间隔中位数 {median * 1000:.0f}ms 偏长，先关掉声音条特效（保住帧率）")
                else:
                    self._degrade_stage = 2
            elif stage == 1:
                self._degrade_stage = 2
                self.frame_ms = max(self.frame_ms, 33)
                note("关了特效还是偏长，这才降到 30 帧")

    def draw_simple(self, im, d, wave_color: str) -> None:
        """贴边时那条"简化版"：一小段会跟着声音起伏的光条，没有字也没有开关。

        竖着贴左/右边就是竖条，贴上/下边就是横条。外观页那五个特效在这里同样生效：
        视觉暂留拖残影、呼吸光晕垫柔光、星尘溅亮点、倒影来一条对称的淡影、流光扫过。
        """
        w, h = im.size
        vertical = self.snap_edge in ("left", "right")
        d.rounded_rectangle([0, 0, w - 1, h - 1], radius=min(w, h) // 2,
                            fill=self.panel_color)

        level = max(0.0, min(1.0, self.level_shown))
        wob = 0.5 + 0.5 * math.sin(self.wave_phase * 1.2)
        frac = 0.22 + 0.70 * min(1.0, level * (0.55 + 0.45 * wob) + level * 0.35)
        thick = max(2.0, min(w, h) * 0.40)
        # 光条在长轴上跟着声音来回滑（像个 VU 表）—— 有了这个"动"，
        # 视觉暂留的拖影才看得出来；不然一直是同心放大，根本看不见。
        want_pos = 0.5 + (level - 0.35) * 0.40 * math.sin(self.wave_phase * 0.62)
        want_pos = min(0.86, max(0.14, want_pos))
        now_pos = getattr(self, "_strip_pos", 0.5)
        self._strip_pos = now_pos + (want_pos - now_pos) * 0.16
        # 节能模式 / 已经自动降过级：特效一律不画（跟主声音条一个规矩）
        fx = {k: bool(v) for k, v in self.fx.items()}
        if self.perf == "eco" or getattr(self, "_auto_low", False):
            fx = {k: False for k in fx}

        def box_for(f: float, extra: float = 0.0, pos: float | None = None) -> list:
            t = thick + extra
            c = self._strip_pos if pos is None else pos
            if vertical:
                span = max(6.0, (h - 14) * f)
                mid = 7 + (h - 14) * c
                y0 = min(max(4.0, mid - span / 2), h - 4 - span)
                return [w / 2 - t / 2, y0, w / 2 + t / 2, y0 + span]
            span = max(6.0, (w - 14) * f)
            mid = 7 + (w - 14) * c
            x0 = min(max(4.0, mid - span / 2), w - 4 - span)
            return [x0, h / 2 - t / 2, x0 + span, h / 2 + t / 2]

        # ① 视觉暂留：把最近几帧的长度留成一层层淡影
        if fx.get("fx_trail"):
            for i, (old_f, old_p) in enumerate(getattr(self, "_strip_hist", [])[-3:]):
                d.rounded_rectangle(box_for(old_f, 1.0, old_p),
                                    radius=int(thick // 2) + 1,
                                    fill=mix(self.panel_color, wave_color,
                                             0.16 + 0.12 * i))
        self._strip_hist = (getattr(self, "_strip_hist", [])
                            + [(frac, self._strip_pos)])[-4:]

        # ② 倒影：旁边并排来一条更细更淡的（竖条就左右并排、横条就上下并排）
        if fx.get("fx_reflection"):
            gap = thick * 0.95
            seg = box_for(frac, -thick * 0.62)
            if vertical:
                seg = [seg[0] + gap, seg[1], seg[2] + gap, seg[3]]
            else:
                seg = [seg[0], seg[1] + gap, seg[2], seg[3] + gap]
            d.rounded_rectangle(seg, radius=int(max(1, thick // 3)),
                                fill=mix(self.panel_color, wave_color, 0.34))

        # ③ 呼吸光晕：先垫一层毛茸茸的柔光
        if fx.get("fx_glow") and level > 0.06:
            halo = Image.new("RGBA", im.size, (0, 0, 0, 0))
            hd = ImageDraw.Draw(halo)
            hd.rounded_rectangle(box_for(frac, thick * 0.6), radius=int(thick),
                                 fill=rgb(wave_color) + (int(60 + 70 * level),))
            halo = halo.filter(ImageFilter.GaussianBlur(3.0))
            im.paste(Image.alpha_composite(im.convert("RGBA"), halo).convert("RGB"),
                     (0, 0))
            d = ImageDraw.Draw(im)

        # ④ 光条本体
        d.rounded_rectangle(box_for(frac), radius=int(max(1, thick // 2)), fill=wave_color)

        # ⑤ 流光：一条高光顺着光条扫过去
        if fx.get("fx_sweep"):
            seg = box_for(frac)
            t = (self._sweep_pos * 1.6) % 1.0
            length = max(4.0, (seg[3] - seg[1]) * 0.22) if vertical \
                else max(4.0, (seg[2] - seg[0]) * 0.22)
            if vertical:
                y0 = seg[1] + (seg[3] - seg[1] - length) * t
                box = [seg[0], y0, seg[2], y0 + length]
            else:
                x0 = seg[0] + (seg[2] - seg[0] - length) * t
                box = [x0, seg[1], x0 + length, seg[3]]
            d.rounded_rectangle(box, radius=int(max(1, thick // 3)),
                                fill=mix(wave_color, "#ffffff", 0.55))

        # ⑥ 星尘：说话时在光条两头溅几个小亮点
        if fx.get("fx_sparkles") and level > 0.15:
            import random as _random

            sparks = getattr(self, "_strip_sparks", [])
            if len(sparks) < 14 and _random.random() < 0.5:
                seg = box_for(frac)
                if vertical:
                    sparks.append([w / 2 + _random.uniform(-thick, thick),
                                   _random.choice([seg[1], seg[3]]),
                                   _random.uniform(-0.5, 0.5),
                                   _random.uniform(-1.4, 1.4), 1.0])
                else:
                    sparks.append([_random.choice([seg[0], seg[2]]),
                                   h / 2 + _random.uniform(-thick, thick),
                                   _random.uniform(-1.4, 1.4),
                                   _random.uniform(-0.5, 0.5), 1.0])
            alive = []
            for sx, sy, vx2, vy2, life in sparks:
                life -= 0.06
                if life <= 0:
                    continue
                sx, sy = sx + vx2, sy + vy2
                r = 1.4 * life
                d.ellipse([sx - r, sy - r, sx + r, sy + r],
                          fill=mix(wave_color, "#ffffff", 0.5 * life))
                alive.append([sx, sy, vx2, vy2, life])
            self._strip_sparks = alive[-14:]

        # ⑦ 贴的那一侧一条高光，暗示"我贴着屏幕边"
        edge_line = {"left": [(1, 4), (1, h - 4)], "right": [(w - 2, 4), (w - 2, h - 4)],
                     "top": [(4, 1), (w - 4, 1)], "bottom": [(4, h - 2), (w - 4, h - 2)]}
        if self.snap_edge in edge_line:
            a, b = edge_line[self.snap_edge]
            d.line([a, b], fill=wave_color, width=1)

    def draw_full(self, im, d, wave_color: str, state_color: str,
                  speak_active: bool, speak_text: str, speak_prog: float) -> None:
        """平时那套样子：名字 + 状态 + 声音条 + 开关 + 箭头。"""
        w_now = im.width
        if self.show_status:
            sx, sy, ssize = self.layout["status"]
            label = LABELS.get(self.state, self.state)
            if self.focus_left > 0:
                label = LABELS["focus"]          # 专注中优先显示
            if self.sleep_stage >= 2:
                label = LABELS["sleepy"]        # 睡着了就别再写"待唤醒"
            if time.time() < self.toast_until:
                label = self.toast
            f = font(ssize)
            box = d.textbbox((0, 0), label, font=f)
            x0 = (w_now + sx - (box[2] - box[0])) if sx < 0 else sx
            # 状态图标：文字左边一个小圆点，跟着状态变色（待命绿 / 在想蓝 / 已发青 / 静音黄 / 暂停橙 / 断线灰）
            d.text((x0, sy), label, font=f,
                   fill=mix(self.panel_color, state_color, min(1.0, 0.3 + self.text_fade)))
        bands = list((self.status or {}).get("bands") or [])
        if self.spectrum_on and bands and not speak_active and self.focus_left <= 0:
            self.draw_spectrum(im, d, wave_color, bands)
        elif self.focus_left > 0:
            self.draw_focus(im, d, wave_color,
                            1.0 - self.focus_left / max(1.0, self.focus_total))
        else:
            self.draw_voice(im, wave_color)
        gap, height = self.layout["wave"]
        self.draw_caption(d, w_now, im.height - gap - height,
                          speak_text if speak_active else "", speak_prog)
        if self.show_switch:
            sw = self.switch_sprite(self.switch_pos)
            x0, y0 = self.switch_rect()
            im.paste(sw, (x0, y0), sw)
        # 出声状态：左下角一个**半透明的小喇叭**（会出声=带两道声波；静音=一道斜杠）。
        # 做法：先按 8 倍画再缩回来 → 边缘平滑不糊（小图直接画会毛刺）；再压一层透明度。
        try:
            muted = bool(self.cfg.get("muted"))
            size = max(9, int(self.layout["status"][2] * 0.85))
            k = 8
            tile = Image.new("RGBA", (size * k, size * k), (0, 0, 0, 0))
            td = ImageDraw.Draw(tile)
            col = (255, 209, 102, 255) if muted else (61, 220, 132, 255)
            u = size * k / 24.0
            def P(x, y):
                return (x * u, y * u)
            td.rounded_rectangle([P(3, 9.5), P(7.5, 14.5)], radius=1.5 * u, fill=col)
            td.polygon([P(7.5, 9.5), P(11.5, 6), P(11.5, 18), P(7.5, 14.5)], fill=col)
            if muted:
                td.line([P(14, 7.5), P(20.5, 16.5)], fill=col, width=max(1, int(1.6 * u)))
            else:
                td.arc([P(8.5, 8), P(15.5, 16)], -70, 70, fill=col, width=max(1, int(1.5 * u)))
                td.arc([P(8.5, 4.5), P(19.5, 19.5)], -70, 70, fill=col, width=max(1, int(1.5 * u)))
            tile = tile.resize((size, size), Image.LANCZOS)
            a = tile.getchannel("A").point(lambda v: int(v * 0.55))   # 半透明（55%）
            tile.putalpha(a)
            pad = max(3, int(size * 0.35))
            im.paste(tile, (pad, max(0, im.height - size - pad)), tile)
        except Exception:
            pass
        self.draw_arrow(d, w_now)

        # 复用同一张 Tk 图片：每帧都 new 一个 ImageTk.PhotoImage 要重新分配、
        # 还要在 Tk 那边注册一份，白花好几毫秒。
        if (self._photo is None or self._photo.width() != im.width
                or self._photo.height() != im.height):
            self._photo = ImageTk.PhotoImage(im)
            self.canvas.itemconfig(self.img_item, image=self._photo)
        else:
            self._photo.paste(im)

    def read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        return self._read_speaking()

    def write_ready(self) -> None:
        """写一张"我已经把窗口显示出来了"的回执给主程序（每 10 秒续一次时间戳）。"""
        try:
            w = self.root.winfo_x(), self.root.winfo_y()
            READY_FILE.write_text(json.dumps({
                "pid": os.getpid(),
                "ts": time.time(),
                "size": [int(self.cur_w), int(self.cur_h)],
                "pos": [int(w[0]), int(w[1])],
                "alpha": round(float(getattr(self, "_alpha_set", 0.0)), 2),
                "visible": bool(self.root.winfo_viewable()),
            }, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def _read_speaking(self) -> tuple[bool, float]:
        """朗读进程每 50ms 更新一次；这里每 ~50ms 读一次，够做动画了。"""
        counter = getattr(self, "_speak_tick", 0) + 1
        self._speak_tick = counter
        if counter % 3 != 1 and getattr(self, "_speak_cache", None) is not None:
            return self._speak_cache
        try:
            data = json.loads(SPEAK_STATUS.read_text(encoding="utf-8"))
            fresh = time.time() - float(data.get("ts") or 0) < 1.5
            self._speak_cache = (bool(data.get("active")) and fresh,
                                 float(data.get("level") or 0.0),
                                 str(data.get("text") or ""),
                                 float(data.get("progress") or 0.0))
        except Exception:
            self._speak_cache = (False, 0.0, "", 0.0)
        return self._speak_cache

    # ------------------------------------------------------------ 展开 / 收起
    def set_expanded(self, value: bool) -> None:
        if value == self.expanded:
            return
        self.expanded = value
        self.allow_keyboard(value)      # 展开时要能打字，收起后继续不抢焦点
        # 注意：不在这里改透明度 —— 你要求展开前后保持一致。
        # （透明窗口里 Windows 会关掉 ClearType，想要最锐的文字可以把透明度拉到 100%）
        if value:
            if self.panel is None:
                self.build_panel()
            # 主浮窗不改尺寸，面板是独立窗口，淡入
            self._show_panel()
            # 面板刚变大，等布局稳定再量一次"内容够不够放"，该显示滚动条就显示
            self.root.after(120, self._update_scroll_hint)
        else:
            self.set_editing(False)
            self._hide_panel()

    def _expanded_h(self) -> float:
        """展开后的窗口高度 —— **固定值**，不再跟着标签页内容变。

        以前是按当前页内容算需要多高：切到"外观"就长高一点、切到"基本"又缩回去，
        日程页还要单独给 620，看着就是"窗口自己在上下抽动"。现在固定成一个高度，
        装不下的部分用滚轮看（面板本来就是画布 + 滚轮，右边还有一条细滚动条提示）。
        高度上限还是跟着屏幕走：1080P 这种矮屏幕不会把底部按钮顶出窗外。
        """
        cap = max(420, self.root.winfo_screenheight() - 200)
        return float(self.header_h + int(min(cap, PANEL_H_OPEN)))

    def _place_panel(self, total_h: float) -> None:
        if self.panel is None:
            return
        ph = max(1, int(round(self._expanded_h() - self.header_h)))
        self.panel.place(x=0, y=0, width=self.expand_w, height=ph)
        if self.panel_win is not None:
            self.panel_win.geometry(f"{self.expand_w}x{ph}")
            self._position_panel_window()
            try:
                self.panel.update_idletasks()
            except Exception:
                pass

    def _position_panel_window(self) -> None:
        """面板窗口贴在浮窗下方/上方；浮窗本身永远不改尺寸。"""
        win = getattr(self, "panel_win", None)
        if win is None or self.panel is None:
            return
        try:
            ph = max(1, int(round(self._expanded_h() - self.header_h)))
            pw = int(self.expand_w)
            rx, ry = self.root.winfo_x(), self.root.winfo_y()
            vx, vy, vw, vh = virtual_screen()
            x = rx - max(0, (pw - self.compact_w) // 2)
            if x + pw > vx + vw - 8:
                x = vx + vw - pw - 8
            if x < vx + 8:
                x = vx + 8
            y = ry + self.header_h - 1
            if y + ph > vy + vh - 8:
                y = ry - ph + 1
            if y < vy + 8:
                y = vy + 8
            geom = f"{pw}x{ph}+{int(x)}+{int(y)}"
            if geom != getattr(self, "_panel_geom", ""):
                self._panel_geom = geom
                win.geometry(geom)
        except Exception:
            pass

    def _show_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._place_panel(self._expanded_h())
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            win.attributes("-alpha", 0.0)
            win.deiconify()
            win.lift()
            win.attributes("-topmost", True)
        except Exception:
            pass
        target = float(self.alpha_override or self.alpha)
        for i in range(1, 9):
            self.root.after(int(12 * i),
                            lambda a=target * i / 8, t=token:
                            self._fade_panel_step(t, a, False))

    def _hide_panel(self) -> None:
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        self._panel_fade_token += 1
        token = self._panel_fade_token
        try:
            start = float(win.attributes("-alpha") or 0.0)
        except Exception:
            start = 0.0
        for i in range(1, 7):
            last = i == 6
            self.root.after(int(12 * i),
                            lambda a=start * (1 - i / 6), t=token, h=last:
                            self._fade_panel_step(t, a, h))

    def _fade_panel_step(self, token: int, alpha: float, hide: bool) -> None:
        if token != getattr(self, "_panel_fade_token", 0):
            return
        win = getattr(self, "panel_win", None)
        if win is None:
            return
        try:
            win.attributes("-alpha", max(0.0, min(1.0, float(alpha))))
            if hide and alpha <= 0.02:
                win.withdraw()
        except Exception:
            pass

    def _repaint_now(self) -> None:
        """让新露出来的那块立刻画上（Tk 平时要等到下一次空闲才画）。

        只在这几个时刻用：改窗口尺寸、面板换高度、换标签页 —— 一帧几毫秒，
        换来的是"展开过程里看不到没画的黑块"。
        """
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        panel = getattr(self, "panel", None)
        if panel is not None:
            try:
                panel.update_idletasks()
            except Exception:
                pass
        # Tk 的 update_idletasks 只管"有空就画"，窗口刚变大的那块它不一定画 ——
        # 于是那块是黑的/透明的。这里直接让 Windows 立刻把整棵控件树重画一遍。
        if os.name == "nt":
            try:
                RDW_INVALIDATE, RDW_ERASE, RDW_ALLCHILDREN, RDW_UPDATENOW = 0x1, 0x4, 0x80, 0x100
                ctypes.windll.user32.RedrawWindow(
                    ctypes.c_void_p(int(self.root.winfo_id())), None, None,
                    RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN | RDW_UPDATENOW)
            except Exception:
                pass
        # 分层窗口（-alpha）改尺寸之后，Windows 常常只重画"变小"的部分，
        # 新露出来的那条一直是黑的。重新设一遍 alpha 就会让它整块重新合成。
        try:
            cur = getattr(self, "_alpha_set", None)
            if cur is not None:
                self.root.attributes("-alpha", max(0.05, float(cur) - 0.001))
                self.root.attributes("-alpha", float(cur))
        except Exception:
            pass

    def _finish_panel_close(self) -> None:
        self._panel_closing = False
        # 独立窗口：收起就是淡出后 withdraw，下次展开只 deiconify
        self._hide_panel()

    # ------------------------------------------------------------ 键盘焦点
    def hwnds(self) -> list[int]:
        u = ctypes.windll.user32
        inner = self.root.winfo_id()
        outer = u.GetParent(inner) or inner
        return [h for h in {outer, inner} if h]

    def allow_keyboard(self, enabled: bool) -> None:
        """展开设置期间允许窗口被激活，这样输入框才能打字。"""
        try:
            for hwnd in self.hwnds():
                set_no_activate(hwnd, not enabled)
            if enabled:
                grab_foreground(self.hwnds()[0])
        except Exception:
            pass

    def focus_entry(self, widget) -> None:
        """点输入框时把焦点真的交给它（默认的浮窗是拿不到焦点的）。"""
        self.allow_keyboard(True)
        self.set_editing(True)
        try:
            grab_foreground(self.hwnds()[0])
            self.root.focus_force()
            widget.focus_set()
            widget.icursor("end")
            grab_foreground(widget.winfo_id())      # 再对着输入框自己抢一次
        except Exception:
            pass

    def set_editing(self, on: bool) -> None:
        """告诉主程序"我正在改设置"，这段时间别抢我的键盘（别往聊天窗口粘东西）。"""
        if on == self.editing_on:
            return
        self.editing_on = on
        self.edit_touch = time.time()
        send_command("editing-on" if on else "editing-off")
        inputlog(f"编辑状态 = {'开（主程序先别抢焦点）' if on else '关'}")

    def _pick_chip(self, chips: dict, value: str) -> None:
        for k, chip in chips.items():
            chip.config(bg=self.button_color if k == value else CARD, fg="#ffffff")

    def set_send_mode(self, value: str) -> None:
        self.send_mode_value = value
        self._pick_chip(self.send_chips, value)
        self.on_change()
        self.flash("发送方式：" + {"paste_enter": "粘贴并回车", "paste": "只粘贴",
                                   "type": "当打字机"}.get(value, value), 2)

    def set_model(self, value: str) -> None:
        self.model_value = value
        self._pick_chip(self.model_chips, value)
        self.on_change()
        self.flash("模型改好了，点「重启程序」生效", 3)

    def set_lang(self, value: str) -> None:
        self.lang_value = value
        self._pick_chip(self.lang_chips, value)
        self.on_change()
        self.flash("语言改好了，点「重启程序」生效", 3)

    def refresh_send_chips(self) -> None:
        self._pick_chip(getattr(self, "send_chips", {}), self.send_mode_value)

    def refresh_model_chips(self) -> None:
        self._pick_chip(getattr(self, "model_chips", {}), self.model_value)

    def refresh_lang_chips(self) -> None:
        self._pick_chip(getattr(self, "lang_chips", {}), self.lang_value)

    def restart_program(self) -> None:
        self.flash("正在重启语音程序…", 3)
        send_command("restart")

    def do_export(self) -> None:
        self.flash("正在打包数据…（会藏进「导出」文件夹）", 2.5)
        send_command("export")
        self.root.after(1600, self.refresh_backup_label)

    def do_import(self) -> None:
        self.flash("正在导入最新的导出包…", 2.5)
        send_command("import")

    # ------------------------------------------------- 备份与诊断（都藏进导出文件夹）
    def backup_dir(self) -> Path:
        """和主程序一个规矩：包裹都放这儿，不往桌面上扔。"""
        folder = HERE / "导出"
        try:
            folder.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                try:
                    ctypes.windll.kernel32.SetFileAttributesW(str(folder), 0x02)  # 隐藏
                except Exception:
                    pass
            return folder
        except Exception:
            return HERE

    def backup_summary(self) -> str:
        """最新几个包：时间 + 大小，一眼看出有没有打出来。"""
        folder = self.backup_dir()
        packs = sorted(list(folder.glob("语音助手数据-*.zip"))
                       + list(folder.glob("语音助手诊断-*.zip")))
        if not packs:
            return "还没有导出 / 诊断包 · 都藏在这个文件夹里，不往桌面上扔"
        bits = []
        for path in packs[-3:][::-1]:
            m = re.match(r"语音助手(数据|诊断)-(\d{8})-(\d{4})(?:-\d+)?\.zip$", path.name)
            try:
                kb = path.stat().st_size / 1024
            except OSError:
                kb = 0
            if m:
                kind = m.group(1)
                when = (f"{m.group(2)[4:6]}/{m.group(2)[6:8]} "
                        f"{m.group(3)[:2]}:{m.group(3)[2:]}")
                bits.append(f"{kind} {when}（{kb:.0f}KB）")
            else:
                bits.append(f"{path.name}（{kb:.0f}KB）")
        more = f" · 共 {len(packs)} 个" if len(packs) > 3 else ""
        return "最新：" + "、".join(bits) + more + " · 藏在程序目录的「导出」里"

    def do_diagnose(self) -> None:
        self.flash("正在打包诊断…（会藏进「导出」文件夹）", 2.5)
        send_command("diagnose")
        self.root.after(1600, self.refresh_backup_label)

    def refresh_backup_label(self) -> None:
        label = getattr(self, "backup_label", None)
        if label is None:
            return
        try:
            label.config(text=self.backup_summary())
        except Exception:
            pass

    def open_backup_dir(self) -> None:
        folder = self.backup_dir()
        try:
            os.startfile(str(folder))
        except Exception:
            self.flash(f"打不开：{folder}", 3)

    # ------------------------------------------------- 集中记忆归档
    def memory_summary(self) -> str:
        try:
            info = memory_archive.summary()
        except Exception:
            info = None
        if not info:
            return "还没有归档 · 说「集中记忆归档」或点「归档」"
        s = info.get("stats") or {}
        return (f"上次 {info.get('generated_at', '')} · "
                f"{s.get('threads', 0)} 个会话 / {s.get('user_messages', 0)} 条你的话")

    def do_memory_archive(self) -> None:
        """手动归档：用户点一下才跑，不自动、不定时。"""
        self.flash("正在把所有对话的记忆归档…", 3)

        def job() -> None:
            try:
                info = memory_archive.build_archive()
                msg = memory_archive.describe(info)
            except Exception as exc:                    # noqa: BLE001
                msg = f"归档没成功：{exc}"

            def done() -> None:
                self.flash(msg, 4)
                try:
                    self.memory_label.config(text=self.memory_summary())
                except Exception:
                    pass
                if getattr(self, "memory_win", None) is not None:
                    try:
                        if self.memory_win.winfo_exists():
                            self.load_memory_text()
                    except Exception:
                        pass

            try:
                self.root.after(0, done)
            except Exception:
                pass

        threading.Thread(target=job, daemon=True).start()

    def open_memory_archive(self) -> None:
        """在设置里查看上一次的归档；不会顺手重新生成。"""
        path = memory_archive.ARCHIVE_MD
        if not path.is_file():
            self.flash("还没有归档，先点「归档」或说「集中记忆归档」", 3)
            return
        tk = self.tk
        win = getattr(self, "memory_win", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.deiconify()
                    win.lift()
                    self.load_memory_text()
                    return
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        self.memory_win = win
        win.title("集中记忆归档")
        win.configure(bg=BG_PANEL)
        win.geometry("780x620")
        win.minsize(520, 360)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        head = tk.Frame(win, bg=BG_PANEL)
        head.pack(fill="x", padx=14, pady=(12, 2))
        tk.Label(head, text="集中记忆归档", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(side="left")
        tk.Label(head, text=self.memory_summary(), bg=BG_PANEL, fg="#6f6f7a",
                 font=("Microsoft YaHei UI", 8)).pack(side="right")
        tk.Label(win, text="所有 Codex 对话 + 事实记忆 / 便签 / 记账 / 日程 / 日记，"
                           "都收在这一份里。只有点「归档」才会更新。",
                 bg=BG_PANEL, fg="#6f6f7a", anchor="w",
                 font=("Microsoft YaHei UI", 8)).pack(fill="x", padx=14, pady=(0, 6))

        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=14)
        text = tk.Text(body, bg="#16161b", fg="#d8d8e0", relief="flat", wrap="word",
                       font=("Microsoft YaHei UI", 9), padx=10, pady=8,
                       spacing1=1, spacing3=2)
        bar = tk.Scrollbar(body, command=text.yview, bg=CARD, troughcolor=BG_PANEL,
                           relief="flat", width=12)
        text.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        self.memory_text = text

        foot = tk.Frame(win, bg=BG_PANEL)
        foot.pack(fill="x", padx=14, pady=(6, 12))
        self._chip(foot, "用记事本打开",
                   lambda: memory_archive.open_archive()).pack(side="left")
        self._chip(foot, "重新归档", self.do_memory_archive).pack(side="left", padx=6)
        self._chip(foot, "关闭", win.destroy).pack(side="right")
        self.load_memory_text()

    def load_memory_text(self) -> None:
        path = memory_archive.ARCHIVE_MD
        try:
            content = path.read_text(encoding="utf-8-sig", errors="replace")
        except Exception as exc:                        # noqa: BLE001
            content = f"读不了归档文件：{exc}"
        # Tk 的 Text 碰到 NUL 会截断，先把控制字符清掉
        content = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", content)
        limit = 1_500_000
        if len(content) > limit:
            content = (content[:limit]
                       + "\n\n…（文件太大，这里先显示前 1.5 MB；"
                         "完整内容点「用记事本打开」）")
        text = getattr(self, "memory_text", None)
        if text is None:
            return
        try:
            text.configure(state="normal")
            text.delete("1.0", "end")
            text.insert("1.0", content)
            text.configure(state="disabled")
        except Exception:
            pass

    # ------------------------------------------------- 卸载（悬浮窗里直接卸）
    def uninstall_command(self, full: bool) -> list[str]:
        """拼出"启动卸载程序"的命令行。单独拆出来，方便测。"""
        cmd_file = HERE / "卸载语音助手.cmd"
        if not cmd_file.exists():
            cmd_file = HERE / "uninstall.cmd"
        if cmd_file.exists():
            return ["cmd", "/c", str(cmd_file), "--yes"] + (["--full"] if full else [])
        # 连 .cmd 都没有就自己叫 uninstall.py
        return [sys.executable, str(HERE / "uninstall.py"), "--yes"] + \
               (["--full"] if full else [])

    def do_uninstall(self, full: bool) -> None:
        """真去卸：另开一个独立窗口跑卸载程序，进度你自己看得见。

        必须是"独立进程 + 独立窗口"：卸载程序干的第一件事就是把后台的我们全停掉，
        停完它还得接着干活，所以它不能挂在我们的进程树上。
        """
        cmd = self.uninstall_command(full)
        try:
            subprocess.Popen(cmd, cwd=str(HERE),
                             creationflags=0x00000010)   # CREATE_NEW_CONSOLE：看得见进度
        except Exception as exc:  # noqa: BLE001
            self.flash(f"卸载程序没起来：{exc}", 5)
            return
        note("从悬浮窗发起卸载：" + ("彻底删除（连记录）" if full else "卸载（保留记录）"))
        self.flash("卸载程序起来了，接下来交给它（后台的我会被它关掉）", 5)

    def ask_uninstall(self) -> None:
        """先问清楚要卸到哪一步。彻底删除要点两下，防手滑。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("卸载鳍舱")
        win.configure(bg=BG_PANEL)
        win.geometry("456x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text="卸载鳍舱", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w", padx=16,
                                                              pady=(14, 2))
        tk.Label(win, justify="left", anchor="w", bg=BG_PANEL, fg="#9a9aa5", wraplength=400,
                 font=("Microsoft YaHei UI", 8),
                 text="不管选哪个，都会先关掉后台的鳍舱、取消开机自启、"
                      "删掉桌面和开始菜单里指向本程序的快捷方式。\n"
                      f"程序目录：{HERE}").pack(anchor="w", padx=16)

        card = tk.Frame(win, bg=CARD)
        card.pack(fill="x", padx=16, pady=10)
        tk.Label(card, text="删掉 .venv 运行环境、识别模型、日志（省几个 G）；"
                            "程序文件、设置、聊天记录都留着，以后想用重跑一次 setup.cmd 就行",
                 bg=CARD, fg="#c9c9d6", justify="left", anchor="w", wraplength=370,
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", padx=12, pady=(8, 0))
        b1 = tk.Label(card, text="① 卸载（保留我的记录）", bg=self.button_color,
                      fg="#ffffff", font=("Microsoft YaHei UI", 10, "bold"),
                      pady=8, cursor="hand2")
        b1.pack(fill="x", padx=12, pady=(6, 10))

        warn = tk.Label(win, text="整个文件夹连聊天记录、日记、记账一起删干净，删完找不回来",
                        bg=BG_PANEL, fg="#9a9aa5", justify="left", anchor="w",
                        wraplength=400, font=("Microsoft YaHei UI", 8))
        warn.pack(anchor="w", padx=16)
        b2 = tk.Label(win, text="② 彻底删除（连程序和记录一起清掉）", bg=CARD,
                      fg="#ff8080", font=("Microsoft YaHei UI", 10, "bold"),
                      pady=8, cursor="hand2")
        b2.pack(fill="x", padx=16, pady=(6, 4))
        armed = {"on": False}

        def pick_keep(_e=None) -> None:
            win.destroy()
            self.do_uninstall(False)

        def pick_full(_e=None) -> None:
            if not armed["on"]:      # 第一下只是"解锁"，防手滑
                armed["on"] = True
                b2.config(text="真的要全删？再点一次就动手", bg="#7a1f1f")
                warn.config(text="连聊天记录和设置一起删，没有回收站，删完就真没了",
                            fg="#ff8080")
                return
            win.destroy()
            self.do_uninstall(True)

        def pick_cancel(_e=None) -> None:
            win.destroy()
            self.flash("没卸，什么都没动", 2)

        b1.bind("<Button-1>", pick_keep)
        b2.bind("<Button-1>", pick_full)
        b1.bind("<Enter>", lambda _e: b1.config(bg=self.accent))
        b1.bind("<Leave>", lambda _e: b1.config(bg=self.button_color))
        b2.bind("<Enter>", lambda _e: b2.config(bg="#5a1717" if armed["on"] else "#2c2c36"))
        b2.bind("<Leave>", lambda _e: b2.config(bg="#7a1f1f" if armed["on"] else CARD))
        cancel = tk.Label(win, text="先不卸了", bg=BG_PANEL, fg="#9a9aa5",
                          font=("Microsoft YaHei UI", 9), cursor="hand2")
        cancel.pack(pady=(2, 10))
        cancel.bind("<Button-1>", pick_cancel)
        win.bind("<Escape>", pick_cancel)
        try:
            win.lift()
            win.focus_force()
        except Exception:
            pass

    def ask_clear(self) -> None:
        self.flash("要清空就说「清空所有记录」再「确定清空」", 3)

    def publish_site(self) -> None:
        """把下载页发布到公网网站（第一次要填一次仓库地址、登录一次，以后自动）。

        发布之后：更新就以**网站上的文件**为准 —— 两边 APP 都去读那上面的
        version.json，网站一更新，提示就跟着变。
        """
        import site_publish

        tk = self.tk
        cur_repo = site_publish.repo_url()
        win = tk.Toplevel(self.root)
        win.title("发布下载页到网站")
        win.configure(bg=BG_PANEL)
        win.geometry("560x330")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text="发布到网站（免费静态托管）", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w", padx=18,
                                                               pady=(14, 2))
        tk.Label(win, text="第一次：先在 github.com 建一个空仓库（Public），把它的 https 地址\n"
                           "贴到下面；点「发布」会弹一次登录，登完就记住了。\n"
                           "以后每次更新，打包时会**自动**重新生成并推上去。",
                 bg=BG_PANEL, fg="#8a8a95", font=("Microsoft YaHei UI", 9),
                 justify="left").pack(anchor="w", padx=18)
        tk.Label(win, text="仓库地址（https://github.com/用户名/仓库名.git）",
                 bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(12, 2))
        repo_var = tk.StringVar(value=cur_repo)
        tk.Entry(win, textvariable=repo_var, bg=CARD, fg="#ffffff", relief="flat",
                 insertbackground="#ffffff",
                 font=("Consolas", 10)).pack(fill="x", padx=18, ipady=6)
        tk.Label(win, text="网站网址（发布成功后填，形如 https://用户名.github.io/仓库名/）",
                 bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(10, 2))
        url_var = tk.StringVar(value=site_publish.public_url())
        tk.Entry(win, textvariable=url_var, bg=CARD, fg="#ffffff", relief="flat",
                 insertbackground="#ffffff",
                 font=("Consolas", 10)).pack(fill="x", padx=18, ipady=6)
        msg = tk.Label(win, text="", bg=BG_PANEL, fg=self.accent,
                       font=("Microsoft YaHei UI", 9), wraplength=520, justify="left")
        msg.pack(anchor="w", padx=18, pady=(10, 0))
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(10, 14))

        def do_publish() -> None:
            repo = repo_var.get().strip()
            url = url_var.get().strip()
            site_publish.configure(repo=repo, url=url)
            msg.config(text="正在发布…（第一次会弹一个登录窗口，登一次就行）")

            def run() -> None:
                # 你自己点的这个按钮 = 现在就发（不管攒够没攒够）
                ok, why, did = site_publish.publish(force=True)
                self.root.after(0, lambda: msg.config(
                    text=("发布成功：" + (url or site_publish.public_url() or "（记得填网站网址）"))
                    if ok else ("没发上去：" + why),
                    fg=self.accent if ok else "#ff9a9a"))
                if ok:
                    self.root.after(0, lambda: self.flash("网站上已经是新版了", 3))

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(bar, text="发布", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=20, pady=6,
                        cursor="hand2")
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _e: do_publish())
        close = tk.Label(bar, text="关掉", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        close.pack(side="right", padx=8)
        close.bind("<Button-1>", lambda _e: win.destroy())

    def check_update(self) -> None:
        """检查更新：读的是**下载页那份数据**（网页刷新了，这边就提示）。

        来源默认是本机这一份（http://127.0.0.1:端口/dl/version.json）—— 跟别人看到的
        下载页是同一个东西。要是把下载页传到了公网，在设置里把「更新源」填成那个网址，
        跑到哪儿都能收到提示。
        """
        if self.upd_label is not None:
            self.upd_label.config(text="正在检查…", fg="#7f7f8a")
        self.flash("正在检查更新…", 1.6)

        def work() -> None:
            try:
                import self_update

                got = self_update.check(self.cfg)
            except Exception as exc:            # noqa: BLE001
                got = {"ok": False, "err": f"{type(exc).__name__}: {exc}"[:80]}
            self.root.after(0, lambda: self._update_result(got))

        threading.Thread(target=work, daemon=True).start()

    def _update_result(self, got: dict) -> None:
        """检查结果：没新版就说一声，有新版就弹个窗口问你要不要装。"""
        if not got.get("ok"):
            why = str(got.get("err") or "读不到更新信息")
            if self.upd_label is not None:
                self.upd_label.config(text=why, fg="#ff9a9a")
            self.flash(why, 3)
            return
        pc = got.get("pc") or {}
        if not got.get("pc_new"):
            text = f"已是最新（v{version.APP_VERSION}）"
            if self.upd_label is not None:
                self.upd_label.config(text=text, fg="#7f8f86")
            self.flash(text, 2.4)
            return
        ver = str(pc.get("version"))
        if self.upd_label is not None:
            self.upd_label.config(text=f"有新版 v{ver}", fg=self.accent)
        self._update_dialog(ver, pc, str(got.get("src") or ""))

    def _update_dialog(self, ver: str, pc: dict, src: str) -> None:
        """有新版本：把更新内容摆出来，问你是"一键更新"还是"自己去下载页下"。"""
        import self_update

        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title("有新版")
        win.configure(bg=BG_PANEL)
        win.geometry("470x400")
        win.resizable(False, False)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass
        tk.Label(win, text=f"有新版本 v{ver}", bg=BG_PANEL, fg=self.accent,
                 font=("Microsoft YaHei UI", 13, "bold")).pack(anchor="w", padx=18,
                                                               pady=(16, 2))
        tk.Label(win, text=f"你现在是 v{version.APP_VERSION} · "
                           f"新版 {pc.get('size') or ''}", bg=BG_PANEL, fg="#8a8a95",
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18)
        box = tk.Frame(win, bg=CARD)
        box.pack(fill="both", expand=True, padx=18, pady=(10, 8))
        txt = tk.Text(box, bg=CARD, fg="#e6e6ec", relief="flat", wrap="word",
                      font=("Microsoft YaHei UI", 9), insertbackground="#ffffff")
        txt.pack(fill="both", expand=True, padx=10, pady=10)
        txt.insert("1.0", "这一版改了什么：\n\n" + (self_update.notes_text(pc, 4)
                                                    or "（更新说明见下载页）"))
        txt.config(state="disabled")
        tk.Label(win, text="「一键更新」会下载更新包、自动关掉程序再装好（装完自己开回来）",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 wraplength=430, justify="left").pack(anchor="w", padx=18)
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=18, pady=(8, 14))

        def open_page() -> None:
            try:
                import webbrowser

                page = src[:-len("version.json")] if src.endswith("version.json") else src
                webbrowser.open(page)
                self.flash("下载页已经用浏览器打开了", 3)
            except Exception as exc:            # noqa: BLE001
                self.flash(f"打不开浏览器：{exc}", 3)

        def one_click() -> None:
            for child in bar.winfo_children():
                child.destroy()
            tk.Label(bar, text="正在下载更新包…（下完程序会自己关掉重开）",
                     bg=BG_PANEL, fg=self.accent,
                     font=("Microsoft YaHei UI", 9)).pack(side="left")

            def run() -> None:
                url = self_update.resolve(src, str(pc.get("update_url") or ""))
                ok, why = self_update.apply_update(url, HERE)
                self.root.after(0, lambda: self.flash(
                    "更新包开始装了，程序会自己重开" if ok else f"更新失败：{why}", 4))

            threading.Thread(target=run, daemon=True).start()

        chip = tk.Label(bar, text="一键更新", bg=self.button_color, fg="#ffffff",
                        font=("Microsoft YaHei UI", 10, "bold"), padx=18, pady=6,
                        cursor="hand2")
        chip.pack(side="right")
        chip.bind("<Button-1>", lambda _e: one_click())
        later = tk.Label(bar, text="以后再说", bg=CARD, fg="#ffffff",
                         font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        later.pack(side="right", padx=8)
        later.bind("<Button-1>", lambda _e: win.destroy())
        page = tk.Label(bar, text="打开下载页", bg=CARD, fg="#ffffff",
                        font=("Microsoft YaHei UI", 9), padx=14, pady=6, cursor="hand2")
        page.pack(side="right", padx=8)
        page.bind("<Button-1>", lambda _e: open_page())

    def shortcuts_summary(self) -> str:
        if not self.shortcuts:
            return "（还没设置）"
        return f"{len(self.shortcuts)} 条：" + "、".join(list(self.shortcuts)[:3])

    def edit_shortcuts(self) -> None:
        text = "\n".join(f"{k}={v}" for k, v in self.shortcuts.items())

        def apply(value: str) -> None:
            data = {}
            for line in value.splitlines():
                line = line.strip()
                if not line or "=" not in line:
                    continue
                key, _, action = line.partition("=")
                key, action = key.strip(), action.strip()
                if key and action:
                    data[key] = action
            self.shortcuts = data
            self.shortcuts_label.config(text=self.shortcuts_summary())
            self.on_change()

        self.edit_text("快捷指令", text, apply, multiline=True)

    def copy_phone_url(self) -> None:
        """把手机入口网址塞进剪贴板（手机扫不出码，但可以直接发给自己）。"""
        try:
            url = self.phone_url_now()
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("网址已复制，发到手机上打开就行")
        except Exception:
            self.flash("复制失败，手动抄一下这条网址")

    def phone_url_now(self) -> str:
        """现读一遍手机入口网址（网卡换了、端口改了都会跟着变）。"""
        try:
            import phone_link
            return phone_link.phone_url(int(self.cfg.get("phone_port") or 8765))
        except Exception:
            pass
        try:
            return str(self.phone_url_label.cget("text"))
        except Exception:
            return ""

    # ------------------------------------------------ 外网访问（Tailscale，内置的）
    # 用户要的是"别让我自己去装 Tailscale"：所以电脑端这块全自动 ——
    # 一键 = 没装就装（winget / 官方 msi）、没登录就登（自动开登录页）、完了给固定地址。
    def refresh_remote(self) -> None:
        """看一眼外网状态写进那一行小字。跑在后台线程里，别卡界面。"""
        threading.Thread(target=self._remote_report, daemon=True).start()
        self._remote_poll()

    def _remote_report(self, flash=None) -> None:
        """（后台线程里跑）读一次外网状态，结果放 _remote_job，等主线程来取。

        注意：Tk 的界面只能在主线程碰 —— 所以这里一个控件都不动，
        只往属性里塞结果，由主线程的 _remote_poll 去显示。
        """
        try:
            import remote_access
            st = remote_access.detail(fresh=True)
            if st["logged_in"]:
                # 只显前一半地址（令牌那串不摆出来，免得看着乱）：要完整的点「复制地址」
                if st.get("funnel_on"):
                    text = ("公网地址已开通 ✅  账号 %s · 设备 %s\n"
                            "手机那边什么都不用装：APP 里「扫码」照一下，或直接用浏览器打开\n"
                            "%s"
                            % (st["account"] or "—", st["device"] or "—",
                               self._masked_url(st["url"])))
                else:
                    text = ("已经通了 ✅  账号 %s · 设备 %s\n"
                            "手机在外面：点「复制地址」发到手机上，或用 APP 的「扫码」照二维码\n"
                            "%s（固定不变，重启电脑也一样）\n"
                            "想省掉手机上那个 Tailscale：点下面「公网地址 → 开」"
                            % (st["account"] or "—", st["device"] or "—",
                               self._masked_url(st["url"])))
                color = "#3ddc84"
            else:
                text = st["why"] or "外网访问现在用不了"
                color = "#e0b050"
            self.remote_fixed_url = st["url"]
            self.remote_fixed_alt = st.get("alt_url", "")
        except Exception as exc:                             # noqa: BLE001
            text = "读不到外网状态：%s（点「刷新」再试）" % exc
            color = "#e0b050"
        self._remote_job = (text, color)
        if flash:
            self._remote_flash = flash

    @staticmethod
    def _masked_url(url: str) -> str:
        """把地址里的令牌那截去掉，只留人看得懂的 http://ip:端口/?k=…。"""
        try:
            at = str(url or "").find("?k=")
            return (str(url)[:at + 3] + "…") if at > 0 else str(url or "")
        except Exception:                                    # noqa: BLE001
            return str(url or "")

    def _remote_poll(self, tries: int = 0) -> None:
        """（主线程）等后台那次读完了就显示出来；最多等 18 秒。"""
        job = getattr(self, "_remote_job", None)
        if job is not None:
            self._remote_job = None
            try:
                self.remote_label.config(text=job[0], fg=job[1])
            except Exception:                                # noqa: BLE001
                pass
            toast = getattr(self, "_remote_flash", None)
            if toast:
                self._remote_flash = None
                self.flash(toast[0], toast[1])
            return
        if tries < 120:
            try:
                self.root.after(150, lambda n=tries + 1: self._remote_poll(n))
            except Exception:                                # noqa: BLE001
                pass

    def remote_enable(self) -> None:
        """一键开启外网访问：装 → 登 → 显示固定地址。"""
        self.flash("正在弄外网访问，可能要你点一下「是」（装 Tailscale 那一步）…", 5)

        def work() -> None:
            try:
                import remote_access
                ok, msg = remote_access.enable(progress=None)
            except Exception as exc:                         # noqa: BLE001
                ok, msg = False, "出错了：%s" % exc
            # 成的时候 msg 本身就是一句完整的话；失败的时候补个前缀，免得看不出是哪儿出的问题
            self._remote_report(flash=(msg if ok else "外网访问没弄成：%s" % msg, 7))
            try:
                inputlog("点了「一键开启外网访问」")
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def copy_remote_url(self) -> None:
        """把外网那条固定地址塞进剪贴板（发给手机，或者手机扫码）。"""
        try:
            import remote_access
            url = getattr(self, "remote_fixed_url", "") or remote_access.fixed_url()
            if not url:
                self.flash("还没有外网地址 —— 先点「一键开启」", 4)
                return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("外网固定地址已复制，发到手机上就行", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)

    def remote_funnel_on(self) -> None:
        """开公网地址（Funnel）：手机那边连 Tailscale 都不用装、后台也不留东西。

        第一次会卡在"账号级开关"上 —— Tailscale 会给一条同意链接，remote_access
        会顺手把浏览器开出来，点完回来再点一次这个按钮就成。
        """
        self.flash("正在开公网地址…（第一次会让你在浏览器里点一次同意）", 5)

        def work() -> None:
            try:
                import remote_access
                ok, msg = remote_access.funnel_enable()
            except Exception as exc:                         # noqa: BLE001
                ok, msg = False, "出错了：%s" % exc
            self._remote_report(flash=(msg if ok else "公网地址没开成：%s" % msg, 8))
            try:
                inputlog("点了「开公网地址」")
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def remote_funnel_off(self) -> None:
        """关掉公网地址：回到"只有自己登录过的设备能连"。"""
        def work() -> None:
            try:
                import remote_access
                ok, msg = remote_access.funnel_disable()
            except Exception as exc:                         # noqa: BLE001
                ok, msg = False, "出错了：%s" % exc
            self._remote_report(flash=(msg, 5))
            try:
                inputlog("点了「关掉公网地址」")
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()
        self._remote_poll()

    def copy_public_url(self) -> None:
        """复制公网地址 —— 手机在哪个网下都能打开的那条。"""
        try:
            import remote_access
            url = remote_access.public_url() or ""
            if not url:
                fallback = getattr(self, "remote_fixed_url", "")
                if fallback:
                    url = fallback
                else:
                    self.flash("公网地址还没开 —— 先点「开（手机免装）」", 4)
                    return
            self.root.clipboard_clear()
            self.root.clipboard_append(url)
            self.flash("公网地址已复制，发到手机上就能用", 3.5)
        except Exception:
            self.flash("复制失败，手动抄一下吧", 3.5)

    # ------------------------------------------ 设备确认（防别人拿到令牌就操控电脑）
    # 公网地址是开着的，所以再加一道：**每台设备第一次来都要你在电脑上点一次允许**。
    # 令牌万一漏出去（截图、转发），别人拿到的也只是"等确认"那一页。
    def check_new_devices(self, force: bool = False) -> None:
        """（每 200ms 被 tick 调一次）有没有新设备在等确认？有就弹窗。"""
        now = time.time()
        if not force and now - getattr(self, "_dev_checked", 0.0) < 2.0:
            return
        self._dev_checked = now
        try:
            import phone_link
            pend = [g for g in phone_link.device_groups() if g.get("pending")]
        except Exception:                                    # noqa: BLE001
            return
        asked = getattr(self, "_dev_asked", None)
        if asked is None:
            asked = set()
            self._dev_asked = asked
        for grp in pend:
            did = str(grp.get("key") or "") or str((grp.get("ids") or [""])[0])
            if not did or did in asked:
                continue
            asked.add(did)
            self.ask_new_device(grp)

    def ask_new_device(self, rec: dict) -> None:
        """弹窗：有台新设备想连进来，对一下号码再决定。"""
        tk = self.tk
        from tkinter import messagebox
        code = " / ".join([c for c in (rec.get("codes") or []) if c]) or str(rec.get("code") or "")
        ua = str(rec.get("ua") or "")[:70]
        ip = str(rec.get("ip") or "")
        try:
            import phone_link
            nice = str(rec.get("name") or "") or phone_link.device_name(ua, ip)
        except Exception:                                    # noqa: BLE001
            nice = "（认不出）"
        n = len(rec.get("ids") or [])
        more = ("\n（这台手机一共 %d 个入口，一起处理）" % n) if n > 1 else ""
        try:
            ok = messagebox.askyesno(
                "有台新设备想连进来",
                "配对号码：%s\n\n设备：%s\n来源：%s%s\n\n让它连吗？\n"
                "（手机屏幕上现在显示的就是这个号码；是你自己的手机才点「是」）"
                % (code, nice, ip or "—", more))
        except Exception:                                    # noqa: BLE001
            ok = False
        try:
            import phone_link
            ids = rec.get("ids") or []
            if ok:
                phone_link.group_allow(ids)
                self._dev_asked = set()
                self.flash("已允许这台设备（%s）" % code, 4)
            else:
                phone_link.group_deny(ids)
                self.flash("已拒绝这台设备", 4)
        except Exception as exc:                             # noqa: BLE001
            self.flash("处理设备确认失败：%s" % exc, 4)
        self.refresh_devices_label()

    def refresh_devices_label(self) -> None:
        """设置里那行"已配对设备"的小字。"""
        try:
            import phone_link
            groups = phone_link.device_groups()
            ok_n = sum(1 for g in groups if not g.get("pending"))
            pend = sum(1 for g in groups if g.get("pending"))
        except Exception:                                    # noqa: BLE001
            return
        txt = "%d 台设备" % len(groups)
        if ok_n:
            txt += "（已允许 %d 台）" % ok_n
        if pend:
            txt = "%d 台等你确认" % pend
        try:
            self.devices_label.config(text=txt)
        except Exception:                                    # noqa: BLE001
            pass

    def forget_devices(self) -> None:
        """把设备名单清空：下次谁来都得重新确认一遍。"""
        tk = self.tk
        from tkinter import messagebox
        if not messagebox.askyesno("清空设备名单",
                                   "清掉之后：所有手机都要重新确认一次。\n（你自己手机也一样）\n\n要清吗？"):
            return
        try:
            import phone_link
            n = phone_link.device_forget_all()
            self.flash("已清空 %d 台设备" % n, 4)
        except Exception as exc:                             # noqa: BLE001
            self.flash("清空失败：%s" % exc, 4)
        self.refresh_devices_label()

    def rotate_phone_token(self) -> None:
        """换一条手机令牌 —— 旧的立刻作废（手机上要重新扫一次码）。"""
        tk = self.tk
        from tkinter import messagebox
        if not messagebox.askyesno(
                "换一条手机令牌",
                "什么时候用得着：你怀疑那条链接被泄漏了。\n\n"
                "换过之后：\n· 旧链接立刻失效（谁拿着都没用）\n"
                "· **你自己的手机也要重新扫一次码**\n"
                "· 已经配对的设备不受影响\n\n要换吗？"):
            return
        try:
            import phone_link
            phone_link.rotate_token()
            phone_link.device_forget_all()      # 顺手让所有设备重新确认一次
            self.flash("令牌换了 —— 手机上重新扫一次码", 6)
            self.refresh_remote()
            self.refresh_devices_label()
        except Exception as exc:                             # noqa: BLE001
            self.flash("换令牌失败：%s" % exc, 5)

    def show_device_list(self) -> None:
        """能连这台电脑的设备名单：谁允许过、谁在等你确认，都能在这儿改。"""
        tk = self.tk
        try:
            import phone_link
        except Exception as exc:                             # noqa: BLE001
            self.flash("读设备名单失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("能连这台电脑的设备")
        win.configure(bg=BG_PANEL)
        win.geometry("440x540")
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 440) // 2
            y = self.root.winfo_y() + 40
            win.geometry("440x540+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:                                    # noqa: BLE001
            pass
        tk.Label(win, text="能连这台电脑的设备", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(12, 2))
        tk.Label(win, text="每台设备第一次连都得你在这儿点一次「允许」。\n"
                           "不是你自己的设备（或者号码对不上手机屏幕）就点「拒绝」。\n"
                           "同一台手机可能占好几条（页面 / APP 后台 / 换个网就是新的一条），都点允许就行。",
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=390, justify="center").pack(padx=12)
        info = tk.Label(win, text="", bg=BG_PANEL, fg="#9a9aa5",
                        font=("Microsoft YaHei UI", 9))
        info.pack(pady=(8, 2))
        holder = tk.Frame(win, bg=BG_PANEL)
        holder.pack(fill="both", expand=True, padx=12, pady=(0, 6))

        def redraw() -> None:
            for w in holder.winfo_children():
                w.destroy()
            try:
                groups = phone_link.device_groups()
            except Exception:                                # noqa: BLE001
                groups = []
            pend_n = sum(1 for g in groups if g.get("pending"))
            info.config(text="%d 台设备 · 等你确认 %d 台" % (len(groups), pend_n))
            if not groups:
                tk.Label(holder, text="现在一台都没有。\n手机上扫码连一次，名单里就会冒出来。",
                         bg=BG_PANEL, fg="#9a9aa5",
                         font=("Microsoft YaHei UI", 9)).pack(pady=16)
                return

            def card(grp: dict) -> None:
                pending = bool(grp.get("pending"))
                ids = grp.get("ids") or []
                f = tk.Frame(holder, bg=CARD)
                f.pack(fill="x", pady=3)
                codes = " / ".join([c for c in (grp.get("codes") or []) if c])
                head = ("⏳ 等你确认 · 号码 %s" % codes) if pending else "✅ 已允许"
                if len(ids) > 1:
                    head += "  ·  %d 个入口" % len(ids)
                tk.Label(f, text=head, bg=CARD,
                         fg=("#ffd166" if pending else "#3ddc84"),
                         font=("Microsoft YaHei UI", 9, "bold")).pack(anchor="w", padx=10, pady=(7, 0))
                last = float(grp.get("last") or 0)
                tk.Label(f, text="%s\n来源 %s · 最后 %s" % (
                    grp.get("name") or "（认不出）", grp.get("ip") or "—",
                    time.strftime("%m-%d %H:%M", time.localtime(last)) if last else "—"),
                    bg=CARD, fg="#c9cdd3", font=("Microsoft YaHei UI", 9),
                    justify="left", wraplength=385).pack(anchor="w", padx=10)
                for it in (grp.get("items") or []):
                    try:
                        nm2 = phone_link.device_name(it.get("ua"), it.get("ip"))
                    except Exception:                            # noqa: BLE001
                        nm2 = "?"
                    tk.Label(f, text="· %s   %s" % (nm2, str(it.get("ua") or "")[:52]),
                             bg=CARD, fg="#6f6f7a", font=("Microsoft YaHei UI", 7),
                             justify="left", wraplength=385).pack(anchor="w", padx=10)
                br = tk.Frame(f, bg=CARD)
                br.pack(anchor="e", padx=8, pady=(2, 7))

                def do(fn) -> None:
                    try:
                        fn()
                    except Exception as exc:                 # noqa: BLE001
                        self.flash("操作失败：%s" % exc, 4)
                    redraw()
                    self.refresh_devices_label()

                if pending:
                    self._chip(br, "允许", lambda g=ids: do(
                        lambda: phone_link.group_allow(g))).pack(side="left", padx=3)
                    self._chip(br, "拒绝", lambda g=ids: do(
                        lambda: phone_link.group_deny(g))).pack(side="left", padx=3)
                else:
                    self._chip(br, "移除（下次要重新确认）", lambda g=ids: do(
                        lambda: phone_link.group_revoke(g))).pack(side="left", padx=3)

            for grp in groups:
                card(grp)

        redraw()
        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(0, 10))
        self._chip(btns, "全部清除", lambda: (self.forget_devices(), redraw())).pack(side="left", padx=4)
        self._chip(btns, "连接记录", lambda: self.show_access_log()).pack(side="left", padx=4)
        self._chip(btns, "关掉", lambda: win.destroy()).pack(side="left", padx=4)
        inputlog("点了「设备名单」")

    def show_access_log(self) -> None:
        """连接记录：谁、什么时候、连上来干了什么。"""
        tk = self.tk
        try:
            import phone_link
            rows = phone_link.access_recent(300)
        except Exception as exc:                             # noqa: BLE001
            self.flash("读连接记录失败：%s" % exc, 4)
            return
        win = tk.Toplevel(self.root)
        win.title("连接记录")
        win.configure(bg=BG_PANEL)
        win.geometry("560x480")
        try:
            win.attributes("-topmost", True)
        except Exception:                                    # noqa: BLE001
            pass
        tk.Label(win, text="连接记录（谁来过、干了什么）", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(10, 0))
        tk.Label(win, text="「连上」= 有设备连过来 · 「发命令 / 看屏幕 / 取文件」= 它做了什么 · "
                           "「新设备」「允许」「拒绝」「封了」= 那道门的事",
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=520, justify="center").pack(padx=10)
        body = tk.Frame(win, bg=BG_PANEL)
        body.pack(fill="both", expand=True, padx=10, pady=8)
        txt = tk.Text(body, bg="#14141a", fg="#d8d8e0", insertbackground="#d8d8e0",
                      font=("Consolas", 9), wrap="none", height=20, width=62, bd=0)
        sb = tk.Scrollbar(body, command=txt.yview)
        txt.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        lines = []
        for r in rows:
            ts = time.strftime("%m-%d %H:%M:%S", time.localtime(float(r.get("ts") or 0)))
            try:
                who = phone_link.device_name(r.get("ua"), r.get("ip"))[:18]
            except Exception:                                # noqa: BLE001
                who = str(r.get("ua") or "").split("(")[0].strip()[:16] or "—"
            lines.append("%s  %-4s  %-16s %s" % (
                ts, str(r.get("ev") or ""), who, str(r.get("detail") or "")))
        txt.insert("1.0", "\n".join(lines) or "（还没有记录）")
        txt.config(state="disabled")
        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(0, 10))
        self._chip(btns, "刷新", lambda: (win.destroy(), self.show_access_log())).pack(side="left", padx=4)
        def open_file() -> None:
            try:
                os.startfile(str(phone_link.ACCESS_FILE))
            except Exception as exc:                         # noqa: BLE001
                self.flash("打不开文件：%s" % exc, 4)

        self._chip(btns, "打开文件", open_file).pack(side="left", padx=4)

        def wipe() -> None:
            from tkinter import messagebox
            if messagebox.askyesno("清空连接记录", "把记录清掉？（设备名单不动）"):
                phone_link.access_clear()
                win.destroy()
                self.show_access_log()

        self._chip(btns, "清空", wipe).pack(side="left", padx=4)
        self._chip(btns, "关掉", lambda: win.destroy()).pack(side="left", padx=4)
        inputlog("点了「连接记录」")

    def show_remote_qr(self) -> None:
        """把外网固定地址也画成二维码 —— 手机 APP 里「扫码」照一下就切过去了。"""
        tk = self.tk
        try:
            import remote_access
            st = remote_access.detail(fresh=True)
        except Exception as exc:                             # noqa: BLE001
            self.flash("读不到外网地址：%s" % exc, 4)
            return
        url = st.get("url") or ""
        if not url:
            self.flash(st.get("why") or "还没有外网地址 —— 先点「一键开启」", 5)
            return
        import qr_tools

        win = tk.Toplevel(self.root)
        win.title("外网地址二维码")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        try:
            x = self.root.winfo_x() + (self.root.winfo_width() - 340) // 2
            y = self.root.winfo_y() + 40
            win.geometry("340x470+%d+%d" % (max(0, x), max(0, y)))
            win.attributes("-topmost", True)
        except Exception:
            win.geometry("340x470")
        tk.Label(win, text="在外面也能连", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(14, 2))
        tip = ("手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就切到公网那条；"
               "手机不用装 Tailscale，后台也不留东西"
               if st.get("funnel_on") else
               "手机 APP 里「＋ → 连接 → 扫码」照这个码，地址就换成外网那条；"
               "前提是手机上装了 Tailscale 并登了电脑上这个账号")
        tk.Label(win, text=tip,
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=290, justify="center").pack(padx=14)
        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=24, pady=10)
        keep = {"photo": None}
        if not qr_tools.available():
            holder.config(image="", width=28, height=10, compound="center",
                          fg="#333333", font=("Microsoft YaHei UI", 10),
                          text="这台机器少一个画二维码的小库")
        else:
            try:
                img = qr_tools.qr_image(url, box=1, border=3,
                                        dark="#101014", light="#ffffff")
                k = max(3, 250 // max(1, img.width))
                img = img.resize((img.width * k, img.height * k), Image.NEAREST)
                keep["photo"] = ImageTk.PhotoImage(img)
                holder.config(image=keep["photo"], text="", width=0, height=0)
                win._va_qr = keep["photo"]                   # 留着引用，不然白板
            except Exception as exc:                         # noqa: BLE001
                holder.config(image="", text="画不出来：%s" % exc, fg="#333333",
                              width=28, height=10, compound="center")
        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(2, 6))
        self._chip(btns, "复制地址", lambda: self.copy_remote_url()).pack(side="left", padx=4)
        tk.Label(win, text=url, bg=BG_PANEL, fg="#9a9aa5", font=("Consolas", 8),
                 wraplength=296, justify="center").pack(padx=14, pady=(4, 2))
        if st.get("account"):
            tk.Label(win, text="账号：%s" % st["account"], bg=BG_PANEL, fg="#6f6f7a",
                     font=("Microsoft YaHei UI", 8)).pack(pady=(0, 10))
        inputlog("点了「外网地址二维码」")

    def show_qr(self) -> None:
        """把手机入口网址画成二维码弹出来（本地画的，不联网）。

        手机端 APP 左上角有「扫码」，照一下这个码就自动连上电脑：
        不用手敲 IP，也不用抄那串令牌。
        """
        tk = self.tk
        import qr_tools

        url = self.phone_url_now()
        self.qr_url = url
        old = getattr(self, "qr_win", None)
        if old is not None:
            try:
                if old.winfo_exists():
                    old.destroy()
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        self.qr_win = win
        win.title("手机扫码连接")
        win.configure(bg=BG_PANEL)
        win.resizable(False, False)
        size = "380x560"
        try:                       # 贴着悬浮窗弹出来，别飞到屏幕另一头去
            x = self.root.winfo_x() + (self.root.winfo_width() - 380) // 2
            y = self.root.winfo_y() + 40
            win.geometry(f"{size}+{max(0, x)}+{max(0, y)}")
        except Exception:
            win.geometry(size)
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        tk.Label(win, text="手机扫码连接", bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(pady=(16, 2))
        tk.Label(win, text="手机 APP 左上角点「扫码」，照一下这个码就自动连上；"
                           "没装 APP 直接用相机扫也行，扫出来是个网页",
                 bg=BG_PANEL, fg="#7f7f8a", font=("Microsoft YaHei UI", 8),
                 wraplength=330, justify="center").pack(padx=16)

        holder = tk.Label(win, bg="#ffffff", bd=0)
        holder.pack(padx=26, pady=12)
        keep = {"photo": None}

        def paint() -> None:
            if not qr_tools.available():
                keep["photo"] = None
                holder.config(image="", width=30, height=10, compound="center",
                              fg="#333333", font=("Microsoft YaHei UI", 10),
                              text="这台机器少一个画二维码的小库\n"
                                   "点下面「装一下二维码库」就行")
                return
            try:
                # 一个格子 1 像素先画出来，再整倍数放大 —— 边角才是硬的，扫得准
                img = qr_tools.qr_image(url, box=1, border=3,
                                        dark="#101014", light="#ffffff")
                k = max(3, 264 // max(1, img.width))
                img = img.resize((img.width * k, img.height * k), Image.NEAREST)
                keep["photo"] = ImageTk.PhotoImage(img)   # 得留着引用，不然白板
                self.qr_photo = keep["photo"]             # 也给测试留个抓手
                holder.config(image=keep["photo"], text="", width=0, height=0)
            except Exception as exc:                      # noqa: BLE001
                holder.config(image="", text=f"画不出来：{exc}", fg="#333333",
                              width=30, height=10, compound="center")

        def install_lib() -> None:
            self.flash("正在装二维码库，几秒钟…", 3)

            def work() -> None:
                ok, msg = qr_tools.install()
                self.root.after(0, lambda: (paint(), self.flash(msg, 3.5)))

            threading.Thread(target=work, daemon=True).start()

        def save_png() -> None:
            from tkinter import filedialog

            if not qr_tools.available():
                self.flash("先装上二维码库再存图", 3)
                return
            desk = Path.home() / "Desktop"
            path = filedialog.asksaveasfilename(
                parent=win, title="保存二维码", defaultextension=".png",
                initialdir=str(desk if desk.is_dir() else Path.home()),
                initialfile="手机入口二维码.png",
                filetypes=[("PNG 图片", "*.png"), ("所有文件", "*.*")])
            if not path:
                return
            try:
                qr_tools.qr_image(url, box=10, border=4).save(path)
            except Exception as exc:                      # noqa: BLE001
                self.flash(f"存不了：{exc}", 4)
                return
            self.flash(f"二维码存到 {Path(path).name} 了", 3)
            note(f"手机二维码另存到 {path}")

        paint()

        btns = tk.Frame(win, bg=BG_PANEL)
        btns.pack(pady=(2, 6))
        self._chip(btns, "复制网址", lambda: self.copy_phone_url()).pack(side="left", padx=4)
        self._chip(btns, "另存为图片", lambda: save_png()).pack(side="left", padx=4)
        if not qr_tools.available():
            self._chip(btns, "装一下二维码库", lambda: install_lib()).pack(side="left", padx=4)

        tk.Label(win, text=url or "（读不到地址，重启一下程序）", bg=BG_PANEL,
                 fg="#9a9aa5", font=("Consolas", 9), wraplength=330,
                 justify="center").pack(padx=16, pady=(4, 2))
        tk.Label(win, text="换 Wi-Fi / 换电脑之后 IP 会变，到时候重新点一次这个按钮就行",
                 bg=BG_PANEL, fg="#6f6f7a", font=("Microsoft YaHei UI", 8),
                 wraplength=330, justify="center").pack(padx=16, pady=(0, 10))
        inputlog("点了「二维码」按钮")

    def _entry(self, parent, label, value, multiline: bool = False):
        """一行文字设置，做成一个按钮：点一下弹窗来改（不在小框里打字就不会丢焦点）。"""
        row = self._row(parent, label)
        var = self.tk.StringVar(value=str(value))

        def shown(text) -> str:
            one = " ".join(str(text or "").split())
            if not one:
                return "（点这里设置）"
            one = one.replace("|", " ／ ")      # 多条应答语的写法，显示得好看点
            return one if len(one) <= 26 else one[:25] + "…"

        btn = self.tk.Label(row, text=shown(var.get()), bg=CARD, fg="#ffffff",
                            font=("Microsoft YaHei UI", 9), padx=10, pady=4,
                            cursor="hand2", anchor="w", justify="left",
                            highlightthickness=1, highlightbackground=BORDER)
        btn.pack(side="left", fill="x", expand=True, padx=(0, 10))

        def open_editor(_event=None):
            inputlog(f"点击「{label}」按钮")
            self.edit_text(label, var.get(),
                           lambda t: (var.set(t), None)[1], multiline=multiline)

        btn.bind("<Button-1>", open_editor)
        btn.bind("<Enter>", lambda _e: btn.config(bg="#2c2c36"))
        btn.bind("<Leave>", lambda _e: btn.config(bg=CARD))

        def sync(*_args):
            btn.config(text=shown(var.get()))
            self.on_change()

        var.trace_add("write", sync)
        return var

    def edit_text(self, title: str, initial: str, on_ok=None, multiline: bool = False) -> None:
        """开一个普通窗口来编辑（带标题栏，能正常获得键盘焦点）。"""
        tk = self.tk
        win = tk.Toplevel(self.root)
        win.title(f"编辑 · {title}")
        win.configure(bg=BG_PANEL)
        win.attributes("-topmost", True)
        win.geometry("440x190" if multiline else "440x150")
        win.resizable(False, False)
        tk.Label(win, text=title, bg=BG_PANEL, fg="#ffffff",
                 font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        var = tk.StringVar(value=initial)
        if multiline:
            box = tk.Text(win, height=3, bg=CARD, fg="#ffffff", insertbackground="#ffffff",
                          relief="flat", wrap="word", font=("Microsoft YaHei UI", 10))
            box.insert("1.0", initial)
            box.pack(fill="both", expand=True, padx=14, pady=6)
        else:
            box = tk.Entry(win, textvariable=var, bg=CARD, fg="#ffffff",
                           insertbackground="#ffffff", relief="flat",
                           font=("Microsoft YaHei UI", 11))
            box.pack(fill="x", padx=14, pady=10, ipady=6)
        bar = tk.Frame(win, bg=BG_PANEL)
        bar.pack(fill="x", padx=14, pady=(2, 12))

        def confirm() -> None:
            text = (box.get("1.0", "end").strip() if multiline else var.get()).strip()
            if on_ok:
                on_ok(text)
            close()

        def close() -> None:
            # 关窗口时告诉主程序"改完了"，它可以接着抢键盘了
            self.set_editing(False)
            win.destroy()

        ok = tk.Label(bar, text="确定", bg=self.button_color, fg="#ffffff",
                      font=("Microsoft YaHei UI", 10, "bold"), padx=20, pady=6, cursor="hand2")
        ok.pack(side="right")
        ok.bind("<Button-1>", lambda _e: confirm())
        cancel = tk.Label(bar, text="取消", bg=CARD, fg="#ffffff",
                          font=("Microsoft YaHei UI", 10), padx=16, pady=6, cursor="hand2")
        cancel.pack(side="right", padx=8)
        cancel.bind("<Button-1>", lambda _e: close())
        win.bind("<Return>", lambda _e: confirm())
        win.bind("<Escape>", lambda _e: close())
        win.protocol("WM_DELETE_WINDOW", close)
        # 弹窗是独立窗口，焦点一定拿得到；这段时间让主程序先别往聊天框粘东西
        self.set_editing(True)
        self.edit_touch = time.time()
        try:
            win.lift()
            win.focus_force()
            box.focus_set()
        except Exception:
            pass

    def collect(self) -> dict:
        data = load_config()
        data.update({
            "name": self.entry_name.get().strip() or version.ASSISTANT_NAME,
            "wake_word": self.entry_wake.get().strip() or "大肥鱼",
            "greeting_text": self.entry_greeting.get().strip(),
            "greeting_enabled": self.sw_greeting.get(),
            "user_name": self.entry_user.get().strip(),
            "name_freq": self.name_freq_value,
            "ack_text": self.entry_ack.get().strip() or DEFAULTS["ack_text"],
            "ack_enabled": self.sw_ack.get(),
            "self_name": self.entry_self.get().strip() or "大肥鱼",
            "self_talk": self.sw_self.get(),
            "self_freq": self.self_freq_value,
            "volume": int(self.sl_volume.get()),
            "rate": f"{int(self.sl_rate.get()):+d}%",
            "voice": VOICES[self.voice_index][0],
            "voice_pitch": VOICES[self.voice_index][2],
            "voice_fx": VOICES[self.voice_index][3],
            "voice_preset": int(self.voice_index),
            "overlay_width": int(self.sl_width.get()),
            "overlay_height": int(self.sl_height.get()),
            "overlay_color": self.sw_color[0].itemcget(self.sw_color[1], "fill"),
            "overlay_accent": self.sw_accent[0].itemcget(self.sw_accent[1], "fill"),
            "overlay_button": self.sw_button[0].itemcget(self.sw_button[1], "fill"),
            "overlay_text": self.sw_text[0].itemcget(self.sw_text[1], "fill"),
            "overlay_talk_color": self.sw_talk[0].itemcget(self.sw_talk[1], "fill"),
            "overlay_bg_image": self.bg_path,
            "overlay_alpha": round(self.sl_alpha.get() / 100, 2),
            "overlay_bg_dim": int(self.sl_dim.get()),
            "overlay_wave_style": self.wave_style_value,
            "ov_name_x": int(self.sp_name.get()["x"]),
            "ov_name_y": int(self.sp_name.get()["y"]),
            "ov_name_size": int(self.sp_name.get()["s"]),
            "ov_status_x": int(self.sp_status.get()["x"]),
            "ov_status_y": int(self.sp_status.get()["y"]),
            "ov_status_size": int(self.sp_status.get()["s"]),
            "ov_switch_x": int(self.sp_switch.get()["x"]),
            "ov_switch_y": int(self.sp_switch.get()["y"]),
            "ov_wave_y": int(self.sp_wave.get()["y"]),
            "ov_wave_h": int(self.sp_wave.get()["h"]),
            "overlay_show_name": self.sw_show["name"].get(),
            "overlay_show_status": self.sw_show["status"].get(),
            "overlay_show_line": self.sw_show["line"].get(),
            "overlay_show_switch": self.sw_show["switch"].get(),
            "followup_seconds": int(self.sl_followup.get()),
            "caption_enabled": self.sw_caption.get(),
            "mood_enabled": self.sw_mood.get(),
            "mood_idle": self.sw_sleepy.get(),
            "wave_spectrum": self.sw_spectrum.get(),
            "karaoke": self.sw_karaoke.get(),
            "diary_enabled": self.sw_diary.get(),
            "big_caption": self.sw_big.get(),
            "screenshot_enabled": self.sw_shot.get(),
            "screen_share": self.sw_share.get(),
            "phone_enabled": self.sw_phone.get(),
            "hourly_chime": self.sw_chime.get(),
            "sit_reminder": self.sw_sit.get(),
            "meeting_mute": self.sw_meeting.get(),
            "read_hotkey": self.sw_hotkey.get(),
            "voiceprint_warn": self.sw_voiceprint.get(),
            "pet_enabled": self.sw_pet.get(),
            "follow_foreground": self.sw_follow.get(),
            "read_reply": self.sw_readreply.get(),
            "rec_indicator": self.sw_rec.get(),
            "weather_city": self.entry_city.get().strip(),
            "send_mode": self.send_mode_value,
            "confirm_send": self.sw_confirm.get(),
            "tray_enabled": self.sw_tray.get(),
            "auto_tune": self.sw_autotune.get(),
            "auto_restart": self.sw_restart.get(),
            "not_heard_reply": self.sw_notheard.get(),
            "voiceprint_gate": self.sw_gate.get(),
            "model": self.model_value,
            "lang": self.lang_value,
            "wake_level": str(self.cfg.get("wake_level") or wake_levels.DEFAULT_LEVEL),
            "wake_levels": self.custom_levels(),
            "reminders_enabled": self.sw_reminder.get(),
            "reminder_paste": self.sw_reminder_paste.get(),
            "shortcuts": self.shortcuts,
            "schedules": self.schedule_panel.entries,
            "schedule_modules": self.schedule_panel.modules,
            "perf_mode": self.perf_value,
            "anim_fps": int(self.sl_anim.get()),
            "wheel_alpha": self.sw_wheel.get(),
            "snap_edges": self.sw_snap.get(),
            **self._fx_to_save(),
        })
        return data

    def _fx_to_save(self) -> dict:
        """要存进 config.json 的特效开关。

        机器一时忙（开模型、跑大文件、几十个进程抢 CPU）的时候，悬浮窗会自动把特效
        关掉保住帧率 —— 那是"这一次运行"的临时措施。以前它会被"保存设置"顺手写进
        配置文件，结果一次卡顿就把你选的特效永久关掉了。现在这种自动降级不落盘。
        """
        fx = {key: bool(sw.get())
              for key, sw in getattr(self, "fx_switches", {}).items()}
        if getattr(self, "_auto_low", False):
            before = getattr(self, "_fx_before_low", None)
            if before:
                fx.update(before)
        return fx

    def on_change(self, *_a) -> None:
        if self._push_job is not None:
            try:
                self.root.after_cancel(self._push_job)
            except Exception:
                pass
        self._push_job = self.root.after(120, self.push_now)
        if self.hint_label is not None:
            self.hint_label.config(text="改动即时预览", fg="#7f7f8a")

    def push_now(self) -> None:
        self._push_job = None
        data = self.collect()
        write_config(data)
        self.cfg = data
        try:
            self.cfg_mtime = CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        self.after_wake_word_change(data)

    def after_wake_word_change(self, data: dict) -> None:
        """唤醒词一改就自动跑一次自检 —— 免得换了个词却没人告诉你好不好用。"""
        now_word = str(data.get("wake_word") or "")
        if now_word == getattr(self, "_wake_seen", None):
            return
        first_time = not getattr(self, "_wake_seen", None)
        self._wake_seen = now_word
        if first_time or not now_word.strip():
            return
        if time.time() - self.started < 20:      # 刚启动别抢开机问候的话筒
            return
        self.run_wake_test()

    def save_settings(self) -> None:
        self.push_now()
        self.flash("已保存", 2)
        if self.hint_label is not None:
            self.hint_label.config(text="已保存", fg=self.accent)

    def reset_defaults(self) -> None:
        data = load_config()
        for key, value in DEFAULTS.items():
            # 字典/列表要复制一份，不然改配置会顺手把 DEFAULTS 里那份也改了
            if isinstance(value, dict):
                data[key] = dict(value)
            elif isinstance(value, list):
                data[key] = list(value)
            else:
                data[key] = value
        data.pop("overlay_line_follow_state", None)
        write_config(data)
        self.cfg = data
        try:
            self.cfg_mtime = CONFIG.stat().st_mtime
        except OSError:
            pass
        self.apply_saved()
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None
            if self.panel_win is not None:
                try:
                    self.panel_win.destroy()
                except Exception:
                    pass
                self.panel_win = None
            self.build_panel()
            self._place_panel(self._expanded_h())
            if self.expanded:
                self._show_panel()
        self.flash("已恢复默认设置", 2.4)

    def set_autostart(self, value: bool) -> None:
        script = HERE / "autostart.ps1"
        if script.exists():
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                              "-File", str(script), "-AppDir", str(HERE),
                              "-Action", "on" if value else "off"],
                             creationflags=0x08000000)
        self.flash("开机自启：" + ("开" if value else "关"))

    def set_wave_style(self, value: str) -> None:
        self.wave_style_value = value
        self.wave_style = value
        self.refresh_style_chips()
        self.on_change()

    def set_perf(self, value: str) -> None:
        self.perf_value = value
        self.perf = value
        self.refresh_perf_chips()
        if value == "eco":
            self.sl_anim.set(20)
        elif value == "quality":
            self.sl_anim.set(60)
        self.on_change()

    def refresh_perf_chips(self) -> None:
        for value, chip in getattr(self, "perf_chips", {}).items():
            chip.config(bg=self.button_color if value == self.perf_value else CARD,
                        fg="#ffffff")

    def set_name_freq(self, value: str) -> None:
        self.name_freq_value = value
        self.refresh_name_freq()
        self.on_change()

    def refresh_name_freq(self) -> None:
        for value, chip in getattr(self, "name_freq_chips", {}).items():
            chip.config(bg=self.button_color if value == self.name_freq_value else CARD,
                        fg="#ffffff")

    def set_self_freq(self, value: str) -> None:
        self.self_freq_value = value
        self.refresh_self_freq()
        self.on_change()

    def refresh_self_freq(self) -> None:
        for value, chip in getattr(self, "self_freq_chips", {}).items():
            chip.config(bg=self.button_color if value == self.self_freq_value else CARD,
                        fg="#ffffff")

    def refresh_style_chips(self) -> None:
        for value, chip in getattr(self, "style_chips", {}).items():
            chip.config(bg=self.button_color if value == self.wave_style_value else CARD,
                        fg="#ffffff")

    def pick_bg(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="选一张背景图",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp"), ("全部", "*.*")])
        if path:
            self.set_bg(path)

    def set_bg(self, path: str) -> None:
        self.bg_path = path
        self.bg_label.config(text=Path(path).name if path else "无")
        self.on_change()

    def _rate_value(self, rate) -> float:
        try:
            return float(str(rate or "+8%").replace("%", "").replace("+", ""))
        except Exception:
            return 8.0

    def _voice_index(self) -> int:
        # 优先按"第几套预设"记（同一个 edge 音色会有好几套：普通/变声/特效）
        try:
            idx = int(self.cfg.get("voice_preset") or -1)
            if 0 <= idx < len(VOICES):
                return idx
        except Exception:
            pass
        current = self.cfg.get("voice") or VOICES[0][0]
        for i, entry in enumerate(VOICES):
            value = entry[0]
            if value == current:
                return i
        return 0

    def _voice_text(self) -> str:
        return VOICES[self.voice_index][1]

    def apply_size(self, *_a) -> None:
        """改悬浮窗本身的宽/高：立刻量一次，重摆面板（不用重启）。"""
        try:
            self.W = int(self.sl_width.get())
            self.H = int(self.sl_height.get())
        except Exception:
            return
        self.compact_w, self.header_h = self.W, self.H
        self.expand_w = max(432, self.W)
        self.expand_h = self.header_h + PANEL_H
        self._base = None            # 头部底图要按新宽度重画
        self._base_key = None
        self.target_w, self.target_h = float(self.compact_w), float(self.header_h)
        if self.expanded:
            self._place_panel(self._expanded_h())
            self._position_panel_window()
        try:
            self.root.geometry(f"{int(self.compact_w)}x{int(self.header_h)}+"
                               f"{int(self.base_x)}+{int(self.base_y)}")
        except Exception:
            pass
        self.on_change()

    def cycle_voice(self, step: int) -> None:
        self.voice_index = (self.voice_index + step) % len(VOICES)
        self.voice_label.config(text=self._voice_text())
        self.on_change()

    def preview_voice(self, idx: int | None = None) -> None:
        """试听。抽屉里那一列「听」会指定第几个，顺便就把它选上了。"""
        if idx is not None:
            self.select_voice(int(idx))
        voice, label, pitch, fx = VOICES[self.voice_index]
        label = label.split(" · ")[0]
        volume, rate = int(self.sl_volume.get()), int(self.sl_rate.get())

        def run() -> None:
            try:
                import say

                if say.is_clone(voice):        # 克隆音色：走本机的换嗓子那条路
                    got = say.clone_audio(f"你好，我是{label}。以后就用这个声音跟你说话。",
                                          voice, f"{rate:+d}%")
                    if got is None:
                        self.root.after(0, lambda: self.flash("克隆音色这会儿用不了，看日志"))
                        return
                    audio, sr = got
                    if volume < 100:
                        audio = audio * max(0.0, min(1.0, volume / 100))
                    say.play(audio, sr)
                    return
                say.PITCH[0] = pitch
                mp3 = say.edge_mp3(f"你好，我是{label}。以后就用这个声音跟你说话。",
                                   voice, f"{rate:+d}%")
                audio, sr = say.decode_audio(mp3)
                audio = say.apply_fx(audio, sr, fx)
                if volume < 100:
                    audio = audio * max(0.0, min(1.0, volume / 100))
                say.play(audio, sr)
            except Exception as exc:  # noqa: BLE001
                # 注意：except 里的 exc 出了这个块就被删了，得先取出来再用
                why = str(exc)[:24]
                self.root.after(0, lambda w=why: self.flash(f"试听失败：{w}"))

        threading.Thread(target=run, daemon=True).start()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    if not single_instance():
        return 0
    try:
        Overlay().run()
        note("mainloop 正常结束（窗口被销毁）")
    except Exception:
        import traceback

        try:
            (HERE / "overlay-error.log").write_text(traceback.format_exc(), encoding="utf-8")
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
