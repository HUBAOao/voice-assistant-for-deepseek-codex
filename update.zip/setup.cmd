@echo off
setlocal EnableExtensions
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"
title Voice Assistant Setup
chcp 65001 >nul

set "PYEXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE (
  py -3 -c "import sys;raise SystemExit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys;raise SystemExit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
  if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
  echo [Setup] Python 3.12 not found, downloading it now ...
  call :install_python
)
if not defined PYEXE (
  echo [Setup] ERROR: Python is required. Please install Python 3.12 and run setup.cmd again.
  echo         https://www.python.org/downloads/
  pause
  exit /b 1
)

%PYEXE% "%~dp0setup.py" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo   [Setup] finished OK.
) else (
  echo   [Setup] FAILED with code %RC% - the reason is in the messages above
  echo           and in install.log next to this file.
)
echo   Press any key to close this window.
pause >nul
exit /b %RC%

:install_python
set "PYVER=3.12.10"
set "PYINST=%TEMP%\python-%PYVER%-amd64.exe"
if exist "%PYINST%" goto :run_pyinst
for %%U in (https://mirrors.huaweicloud.com/python/%PYVER%/python-%PYVER%-amd64.exe https://registry.npmmirror.com/-/binary/python/%PYVER%/python-%PYVER%-amd64.exe https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe) do (
  if not exist "%PYINST%" (
    echo [Setup] downloading %%U
    powershell -NoProfile -Command "try{Invoke-WebRequest -UseBasicParsing '%%U' -OutFile '%PYINST%' -TimeoutSec 900}catch{exit 1}"
  )
)
if not exist "%PYINST%" (
  echo [Setup] ERROR: cannot download Python installer.
  goto :eof
)
:run_pyinst
echo [Setup] installing Python 3.12 silently ...
"%PYINST%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_pip=1 SimpleInstall=1 TargetDir="%LOCALAPPDATA%\Programs\Python\Python312"
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
goto :eof
