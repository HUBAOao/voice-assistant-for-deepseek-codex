@echo off
rem ASCII ONLY content (cmd.exe parses .cmd in the ANSI code page).
rem Re-installs the Python packages this program needs (Pillow / pystray / ...).
rem Use this when the floating window or the tray icon refuses to appear.
setlocal EnableExtensions
title Voice Assistant - repair dependencies
chcp 65001 >nul
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
cd /d "%APP%"

echo.
echo    Voice Assistant - repair dependencies
echo    ------------------------------------------------
echo.

set "PY=%APP%\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo   [!] .venv not found - please run the installer first
  echo       ^(1-Install... cmd or setup.cmd^).
  echo.
  pause
  exit /b 1
)

echo   [1/2] checking what is missing ...
"%PY%" -c "import PIL, pystray, numpy, sounddevice, faster_whisper; print('   all good')"
if errorlevel 1 (
  echo   [i] something is missing - installing now
) else (
  echo   [i] nothing is missing; installing anyway to be sure
)

echo   [2/2] pip install -r requirements.txt ...
"%PY%" -m pip install -r "%APP%\requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple
if errorlevel 1 (
  echo   [i] mirror failed, trying the default index ...
  "%PY%" -m pip install -r "%APP%\requirements.txt"
)

echo.
echo   [check] verifying again ...
"%PY%" -c "import PIL, pystray; print('   OK: Pillow', PIL.__version__, '/ pystray ready')"
if errorlevel 1 (
  echo   [!] still missing - please send the text above to the developer.
) else (
  echo   Done. Now double-click the desktop shortcut:  YuYinZhuShou
)
echo.
pause
