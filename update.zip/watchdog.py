#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""看门狗：主程序要是挂了，就把它拉起来。

怎么判断"挂了"：status.json 里有两个字段——pid（主程序进程号）和 ts（最后更新时间）。
只要 pid 那个进程不在了、或者 ts 超过 40 秒没动，就当它挂了，重启一次。

它自己也是单实例（互斥锁），而且启动前会等一下——因为主程序可能正在启动中。
"""

from __future__ import annotations

import ctypes
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
STATUS = HERE / "status.json"
LOG = HERE / "watchdog.log"
MANUAL_EXIT = HERE / "manual-exit.json"
HEARTBEAT = HERE / "heartbeat.json"
CONFIG = HERE / "config.json"
PYTHONW = HERE / ".venv" / "Scripts" / "pythonw.exe"
MUTEX = "VoiceAssistantWatchdog_v1"


def auto_restart_on() -> bool:
    """设置里的「崩溃自动重启」（默认开）。关掉之后看门狗自己退出。"""
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
        return bool(cfg.get("auto_restart", True))
    except Exception:
        return True


def log(text: str) -> None:
    try:
        with LOG.open("a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {text}\n")
    except Exception:
        pass
    print(text, flush=True)


def already_running() -> bool:
    k = ctypes.windll.kernel32
    k.CreateMutexW.restype = ctypes.c_void_p
    handle = k.CreateMutexW(None, False, MUTEX)
    if not handle:
        return False
    if k.GetLastError() == 183:          # ERROR_ALREADY_EXISTS
        return True
    globals()["_HANDLE"] = handle        # 保住句柄，进程活着它就活着
    return False


def alive(pid: int) -> bool:
    if pid <= 0:
        return False
    k = ctypes.windll.kernel32
    k.OpenProcess.restype = ctypes.c_void_p
    h = k.OpenProcess(0x1000, False, pid)   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    code = ctypes.c_ulong()
    ok = k.GetExitCodeProcess(ctypes.c_void_p(h), ctypes.byref(code))
    k.CloseHandle(ctypes.c_void_p(h))
    return bool(ok) and code.value == 259   # STILL_ACTIVE


def healthy() -> bool:
    # 优先看心跳文件：主程序在录长句/训练时状态文件会几十秒不动，但那不代表它死了
    try:
        hb = json.loads(HEARTBEAT.read_text(encoding="utf-8"))
        hb_ts = float(hb.get("ts") or 0)
        hb_pid = int(hb.get("pid") or 0)
        if alive(hb_pid):
            if time.time() - hb_ts <= 90:      # 90 秒内有心跳就算活着（留足余量）
                # 但心跳还在、主流程 5 分钟没动过 → 那是卡死不是忙，也该重启
                try:
                    st = json.loads(STATUS.read_text(encoding="utf-8"))
                    if time.time() - float(st.get("ts") or 0) > 300:
                        return False
                except Exception:
                    pass
                return True
        # 心跳太久没动、或者那个进程真没了，再往下用状态文件兜一次
    except Exception:
        pass
    try:
        data = json.loads(STATUS.read_text(encoding="utf-8"))
    except Exception:
        return False
    ts = float(data.get("ts") or 0)
    pid = int(data.get("pid") or 0)
    # 你主动点了"退出语音程序"就别再拉起来；等你下次自己启动，这个记号就过期了
    try:
        manual = float(json.loads(MANUAL_EXIT.read_text(encoding="utf-8")).get("ts") or 0)
        if manual > ts:
            return True          # 当作"健康的已退出"，不重启
    except Exception:
        pass
    if time.time() - ts > 90:               # 90 秒没更新，而且心跳也没有 = 真没了
        return False
    return alive(pid)


def start_main() -> None:
    runner = PYTHONW if PYTHONW.exists() else Path(sys.executable)
    flags = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([str(runner), str(HERE / "stt.py"), "--mode", "talk"],
                         cwd=str(HERE), creationflags=flags)
        log("主程序不在，已经重新拉起来")
    except Exception as exc:  # noqa: BLE001
        log(f"重启失败：{exc}")


def main() -> int:
    if already_running():
        return 0
    log("看门狗启动（每 15 秒看一眼主程序在不在）")
    time.sleep(20)                          # 给主程序一点启动时间
    misses = 0
    while True:
        if not auto_restart_on():
            log("设置里关掉了「崩溃自动重启」，看门狗退出")
            return 0
        if healthy():
            misses = 0
        else:
            misses += 1
            if misses >= 3:                 # 连续三次都不健康才动手，避免误判
                log(f"连续 {misses} 次没看到主程序的心跳，重启它")
                start_main()
                misses = 0
                time.sleep(25)
        time.sleep(15)


if __name__ == "__main__":
    raise SystemExit(main())
