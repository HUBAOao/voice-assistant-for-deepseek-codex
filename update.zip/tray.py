#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""托盘图标：任务栏右下角点一下就能开关悬浮窗、暂停、退出。

浮窗关了以后它还在，所以不会出现"没地方找它"的情况。
所有动作都跟浮窗一样，往 control.json 里写一条命令，主程序那边收。
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONTROL = HERE / "control.json"
ICON = HERE / "voice.ico"
STATUS = HERE / "status.json"
MUTEX = "VoiceAssistantTray_v1"


def send(action: str) -> None:
    try:
        CONTROL.write_text(json.dumps({"action": action, "ts": time.time()}),
                           encoding="utf-8")
    except Exception:
        pass


def single_instance() -> bool:
    import ctypes

    k = ctypes.windll.kernel32
    k.CreateMutexW.restype = ctypes.c_void_p
    handle = k.CreateMutexW(None, False, MUTEX)
    if not handle or k.GetLastError() == 183:
        return False
    globals()["_HANDLE"] = handle
    return True


def state_text() -> str:
    try:
        data = json.loads(STATUS.read_text(encoding="utf-8"))
    except Exception:
        return "不在跑"
    if time.time() - float(data.get("ts") or 0) > 40:
        return "不在跑"
    return {"idle": "等你说唤醒词", "listening": "在听你说", "hearing": "听到声音了",
            "thinking": "识别中", "sent": "刚发出去", "paused": "已暂停",
            "offline": "不在跑", "focus": "专注中"}.get(str(data.get("state")), "在跑")


def main() -> int:
    if os.name != "nt":
        return 0
    if not single_instance():
        return 0
    try:
        import pystray
        from PIL import Image
    except Exception as exc:  # noqa: BLE001
        (HERE / "tray-error.log").write_text(f"缺依赖：{exc}\n", encoding="utf-8")
        return 1
    try:
        image = Image.open(ICON) if ICON.exists() else Image.new("RGB", (64, 64), (61, 220, 132))
    except Exception:
        image = Image.new("RGB", (64, 64), (61, 220, 132))

    def on_show(_i=None, _it=None) -> None:
        # 不用 control.json 了：浮窗要是没在跑，那条命令根本没人收。
        # show_overlay.py 自己会判断"已经在显示 / 只关掉了 / 连语音都没跑"，三样都能处理。
        import subprocess
        import sys

        runner = Path(sys.executable).with_name("pythonw.exe")
        if not runner.exists():
            runner = Path(sys.executable)
        script = HERE / "show_overlay.py"
        if script.exists():
            subprocess.Popen([str(runner), str(script)], cwd=str(HERE),
                             creationflags=0x08000000)

    def on_toggle(_i=None, _it=None) -> None:
        send("toggle")

    def on_restart(_i=None, _it=None) -> None:
        send("restart")

    def on_quit(_i=None, _it=None) -> None:
        send("quit")

    def on_close(_i=None, _it=None) -> None:
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem(lambda _i: "语音助手：" + state_text(), None, enabled=False),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("打开悬浮窗设置", on_show, default=True),
        pystray.MenuItem("暂停 / 继续", on_toggle),
        pystray.MenuItem("重启语音程序", on_restart),
        pystray.MenuItem("退出语音程序", on_quit),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("只关掉这个托盘图标", on_close),
    )
    icon = pystray.Icon("语音助手", image, "语音助手", menu)
    icon.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
