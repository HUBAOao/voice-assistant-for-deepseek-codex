@echo off
setlocal
set "APP=%~dp0"
set "APP=%APP:~0,-1%"
set "ACTION=%~1"
if "%ACTION%"=="" set "ACTION=status"
set "MODE=%~2"
if "%MODE%"=="" set "MODE=talk"
powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%\autostart.ps1" -AppDir "%APP%" -Action "%ACTION%" -Mode "%MODE%"
pause
