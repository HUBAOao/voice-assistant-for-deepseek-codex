# -*- coding: utf-8 -*-
"""Phone token, device trust, access log, and login rate limiting."""
from __future__ import annotations

import hashlib
import json
import secrets
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
TOKEN_FILE = HERE / "phone-token.txt"


def load_token() -> str:
    """Load the persistent phone token, rotating legacy short tokens."""
    try:
        tok = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if len(tok) >= TOKEN_MIN_CHARS:
            return tok
    except Exception:
        pass
    return rotate_token()


def rotate_token() -> str:
    """Create and persist a new URL-safe phone token."""
    tok = secrets.token_urlsafe(30)
    try:
        TOKEN_FILE.write_text(tok, encoding="utf-8")
    except Exception:
        pass
    return tok


_tok_cache = {"mtime": -1.0, "value": ""}


def current_token() -> str:
    """当前令牌（每次看一眼文件变没变）。

    为什么要这样：设置里点「换一条令牌」之后，**不用重启程序**就生效 ——
    不然换令牌得重启 28 秒，用户嫌慢。
    """
    try:
        m = TOKEN_FILE.stat().st_mtime
    except OSError:
        m = -1.0
    if m != _tok_cache["mtime"]:
        _tok_cache["mtime"] = m
        _tok_cache["value"] = load_token()
    return _tok_cache["value"]


# ------------------------------------------------- 新设备要"配对"（防令牌泄漏）
# 公网地址一开，只要那串令牌漏出去（截图、转发、浏览器记录），谁拿到都能指挥这台电脑。
# 所以再加一道门：**每台设备第一次来，电脑上会弹一句"要不要让它连"**，你点了允许它才进得来。
# 允许过之后它带一个 cookie（va_dev），以后就不用再确认。你自己手机第一次扫完码也会弹一次，
# 点一下就行。
DEV_FILE = HERE / "phone-devices.json"
DEV_COOKIE = "va_dev"
DEV_CODE_TTL = 900.0            # 等你确认的设备，15 分钟没人理就作废
DEV_DENY_TTL = 1800.0           # 你拒绝过的设备，半小时内不再为它弹窗（也别再登记新条目）
_dev_lock = threading.Lock()


def _dev_load() -> dict:
    try:
        data = json.loads(DEV_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _dev_save(data: dict) -> None:
    """写进去（先写临时文件再替换，别让两边同时读写写坏）。"""
    try:
        tmp = DEV_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(DEV_FILE)
    except Exception:
        pass


def devices() -> dict:
    """登记过的设备：等你确认的 + 已经允许的（顺手清掉等太久的）。"""
    with _dev_lock:
        data = _dev_load()
        now = time.time()
        changed = False
        for k in list(data.keys()):
            rec = data.get(k) or {}
            if not rec.get("ok") and now - float(rec.get("first") or 0) > DEV_CODE_TTL:
                if now - float(rec.get("denied") or 0) < DEV_DENY_TTL:
                    rec["first"] = now            # 拒绝过的先留着（免得它换个马甲又来刷屏）
                    data[k] = rec
                else:
                    data.pop(k, None)
                    changed = True
        if changed:
            _dev_save(data)
        return data


def pending_devices() -> list:
    """还在等你点"允许"的设备（刚被你拒绝的那批先不问，免得一直弹）。"""
    now = time.time()
    out = []
    for k, v in devices().items():
        if v.get("ok"):
            continue
        if now - float(v.get("denied") or 0) < DEV_DENY_TTL:
            continue
        out.append(dict(v, id=k))
    return out


def known_devices() -> list:
    """已经允许过的设备。"""
    return [dict(v, id=k) for k, v in devices().items() if v.get("ok")]


def _dev_id_new() -> str:
    return secrets.token_urlsafe(12)


def device_name(ua: str, ip: str = "") -> str:
    """给人看的名字。

    为什么需要它：**同一台手机在名单里会占好几条** —— 页面（WebView）、APP 后台轮询、
    传文件各用一个客户端，UA 不一样；再加上手机换网时来源地址也会变（IPv6/IPv4 各一条）。
    列表上光看 UA 只会让人一头雾水（用户就问了"为什么有三个设备"）。
    """
    u = str(ua or "").lower()
    if not u:
        return "（不说自己是谁）"
    if "okhttp" in u:
        return "语音助手 APP·接口"
    if u.startswith("dalvik"):
        return "语音助手 APP·后台"
    if "mozilla" in u and "android" in u and "wv" in u:
        return "语音助手 APP·页面"
    if "mozilla" in u and ("iphone" in u or "ipad" in u):
        return "iPhone / iPad 浏览器"
    if "mozilla" in u and "android" in u:
        return "安卓浏览器"
    if "mozilla" in u:
        return "电脑浏览器"
    if "python" in u or "urllib" in u or "curl" in u:
        return "程序脚本"
    return str(ua or "")[:26]


def _dev_fp(ua: str, ip: str) -> str:
    """没有 cookie 的设备怎么"认脸"：UA + 来源地址。

    为什么必须有这一手：手机 APP 里那个后台轮询用的是 Java 的 HTTP 客户端，
    **它不带 cookie** —— 只认 cookie 的话，它每轮询一次就算一台新设备，
    几分钟就能攒出几十个"待确认"，还会一直弹窗。
    """
    raw = ("%s|%s" % (ua or "", ip or "")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]


def _dev_find(ua: str, ip: str) -> str:
    """按"认脸"找已经登记过的设备（找到就复用它的 id，别新建）。"""
    fp = _dev_fp(ua, ip)
    for k, v in devices().items():
        if str((v or {}).get("fp") or "") == fp:
            return k
    return ""


def _dev_touch(dev_id: str, ua: str = "", ip: str = "", fp: str = "") -> dict:
    """登记/更新一台设备，返回它的记录（里面有配对码和 ok）。"""
    with _dev_lock:
        data = _dev_load()
        now = time.time()
        rec = data.get(dev_id) or {}
        is_new = not rec
        if not rec:
            rec = {"code": "%06d" % secrets.randbelow(1000000),
                   "ok": False, "first": now}
        rec["last"] = now
        if ua:
            rec["ua"] = str(ua)[:120]
        if ip:
            rec["ip"] = str(ip)[:60]
        if fp:
            rec["fp"] = str(fp)[:40]
        data[dev_id] = rec
        _dev_save(data)
        return dict(rec, id=dev_id, is_new=is_new)


def device_trusted(dev_id: str) -> bool:
    rec = devices().get(dev_id) or {}
    return bool(rec.get("ok"))


def device_allow(dev_id: str) -> tuple[bool, str]:
    """电脑上点"允许"：这台设备以后就能直接进了。"""
    with _dev_lock:
        data = _dev_load()
        rec = data.get(dev_id)
        if not rec:
            return False, "没这台设备（可能已经过期了）"
        rec["ok"] = True
        rec["allowed"] = time.time()
        data[dev_id] = rec
        _dev_save(data)
        access_log("允许", dev_id, str(rec.get("ip") or ""), str(rec.get("ua") or ""),
                   "配对码 %s" % (rec.get("code") or ""))
        return True, "已允许"


def device_deny(dev_id: str) -> tuple[bool, str]:
    """电脑上点"拒绝"：这台设备进不来；半小时内不再为它弹窗（免得被一直骚扰）。"""
    with _dev_lock:
        data = _dev_load()
        rec = data.get(dev_id)
        if not rec:
            return False, "没这台设备"
        rec["ok"] = False
        rec["denied"] = time.time()
        data[dev_id] = rec
        _dev_save(data)
        access_log("拒绝", dev_id, str(rec.get("ip") or ""), str(rec.get("ua") or ""),
                   "配对码 %s" % (rec.get("code") or ""))
        return True, "已拒绝"


def device_allow_by_code(code: str) -> tuple[bool, str]:
    want = str(code or "").strip()
    for rec in pending_devices():
        if str(rec.get("code")) == want:
            return device_allow(rec["id"])
    return False, "没找到这个配对码"


def device_forget_all() -> int:
    """把设备名单清空（下次谁来都得重新确认）。"""
    with _dev_lock:
        data = _dev_load()
        n = len(data)
        _dev_save({})
        return n


def _ip_group(ip: str) -> str:
    """同一个 /64 里的 IPv6 地址算一个地方（手机换地址不会跳出这个网段）。"""
    ip = str(ip or "").strip()
    if ":" in ip:
        return ":".join(ip.split(":")[:4])
    return "v4:" + (ip or "?")


def device_groups() -> list:
    """把"同一台手机"的几条记录合成一组。

    一台手机在名单里常常是 2~3 条：APP 的页面（WebView）、APP 的后台轮询、
    还有换网时走 IPv4 的那条。它们属于同一台手机，所以这里按
    「IPv6 的 /64 + 时间上对得上的 IPv4」归堆，界面上就显示成一台。
    """
    recs = [dict(v, id=k) for k, v in devices().items()]
    groups: list[dict] = []
    by_v6: dict[str, dict] = {}
    v4_items = []
    for it in recs:
        ip = str(it.get("ip") or "")
        if ":" in ip:
            key = _ip_group(ip)
            g = by_v6.get(key)
            if g is None:
                g = {"key": key, "items": []}
                by_v6[key] = g
                groups.append(g)
            g["items"].append(it)
        else:
            v4_items.append(it)
    for it in v4_items:                       # IPv4 那条：并进时间上对得上的那一组
        last = float(it.get("last") or 0)
        target = None
        for g in groups:
            if any(abs(last - float(x.get("last") or 0)) < 1200 for x in g["items"]):
                target = g
                break
        if target is not None:
            target["items"].append(it)
        else:
            groups.append({"key": "v4:" + (it.get("ip") or "?"), "items": [it]})
    out = []
    for g in groups:
        def face_key(x: dict) -> tuple:
            """挑哪条当这张卡片的"脸"：优先已经允许的、优先"页面"那条（最像人）。"""
            u = str(x.get("ua") or "").lower()
            nice = 0 if ("mozilla" in u and "wv" in u) else (1 if "mozilla" in u else 2)
            return (0 if x.get("ok") else 1, nice, -float(x.get("last") or 0))

        items = sorted(g["items"], key=face_key)
        out.append({
            "key": g["key"],
            "ids": [x["id"] for x in items],
            "items": items,
            "name": device_name(items[0].get("ua"), items[0].get("ip")),
            "ip": items[0].get("ip") or "",
            "last": max(float(x.get("last") or 0) for x in items),
            "ok": all(bool(x.get("ok")) for x in items),
            "pending": [x for x in items if not x.get("ok")],
            "codes": [str(x.get("code") or "") for x in items if not x.get("ok")],
        })
    out.sort(key=lambda g: (0 if g["pending"] else 1, -g["last"]))
    return out


def group_allow(ids: list) -> int:
    """把一组（同一台手机的几个入口）一起允许。"""
    n = 0
    for i in list(ids or []):
        if device_allow(str(i))[0]:
            n += 1
    return n


def group_deny(ids: list) -> int:
    """把一组一起拒绝/移除。"""
    n = 0
    for i in list(ids or []):
        if device_deny(str(i))[0]:
            n += 1
    return n


# ------------------------------------------------------------- 连接记录（谁来过、干了啥）
ACCESS_FILE = HERE / "phone-access.jsonl"
ACCESS_MAX = 800                # 只留最近这么多条（文件也不会长起来）
_access_lock = threading.Lock()


def access_log(ev: str, dev: str = "", ip: str = "", ua: str = "", detail: str = "") -> None:
    """记一笔：谁、什么时候、连上来干了什么。给设置里的「连接记录」看。"""
    try:
        rec = {"ts": time.time(), "ev": str(ev)[:12], "dev": str(dev)[:16],
               "ip": str(ip)[:60], "ua": str(ua)[:70], "detail": str(detail)[:120]}
        with _access_lock:
            with ACCESS_FILE.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            try:
                if ACCESS_FILE.stat().st_size > 240_000:
                    lines = ACCESS_FILE.read_text(
                        encoding="utf-8", errors="replace").splitlines()
                    ACCESS_FILE.write_text("\n".join(lines[-ACCESS_MAX:]) + "\n",
                                           encoding="utf-8")
            except Exception:                                # noqa: BLE001
                pass
    except Exception:                                        # noqa: BLE001
        pass


def access_recent(limit: int = 300) -> list:
    """最近的连接记录（新的在后）。"""
    try:
        lines = ACCESS_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:                                        # noqa: BLE001
        return []
    out = []
    for ln in lines[-max(1, int(limit)):]:
        try:
            rec = json.loads(ln)
            if isinstance(rec, dict):
                out.append(rec)
        except Exception:                                    # noqa: BLE001
            pass
    return out


def access_clear() -> int:
    """清空连接记录。"""
    with _access_lock:
        n = len(access_recent(10 ** 6))
        try:
            ACCESS_FILE.write_text("", encoding="utf-8")
        except Exception:                                    # noqa: BLE001
            pass
        return n


# ------------------------------------------------------- 令牌错了就限速、拉黑
# 公网地址（Funnel）一开，全世界都能敲这个端口 —— 而且 ts.net 的域名会进
# 证书透明度日志，扫描机器人天天来。以前令牌错了只是回一个 401，不痛不痒；
# 现在同一个人连错几次就关门外一段时间。自家手机令牌是对的，不受影响。
TOKEN_MIN_CHARS = 32          # 短于这个的旧令牌直接作废
GUARD_FAILS = 8               # 同一个来源错这么多次 → 拉黑
GUARD_WINDOW = 600.0          # 只数最近 10 分钟里的错
GUARD_BLOCK = 1800.0          # 拉黑 30 分钟
_guard = {"by": {}, "blocked": {}, "fails": 0, "blocks": 0, "last": 0.0}
_guard_lock = threading.Lock()


def guard_blocked(ip: str) -> float:
    """这个来源现在被封着吗？被封就返回还剩几秒。"""
    now = time.time()
    with _guard_lock:
        until = _guard["blocked"].get(ip, 0.0)
        if until and until <= now:
            _guard["blocked"].pop(ip, None)
            return 0.0
        return max(0.0, until - now)


def guard_note(ip: str, ok: bool) -> None:
    """记一次访问结果。令牌对了就把这人的失败记录清干净（别误封自家人）。"""
    now = time.time()
    with _guard_lock:
        _guard["last"] = now
        if ok:
            _guard["by"].pop(ip, None)
            return
        _guard["fails"] += 1
        hits = [t for t in _guard["by"].get(ip, []) if now - t < GUARD_WINDOW]
        hits.append(now)
        if len(hits) >= GUARD_FAILS:
            _guard["blocked"][ip] = now + GUARD_BLOCK
            _guard["by"].pop(ip, None)
            _guard["blocks"] += 1
            access_log("封了", "", ip, "",
                       "令牌连错 %d 次，关门外 %d 分钟" % (GUARD_FAILS, int(GUARD_BLOCK // 60)))
        else:
            _guard["by"][ip] = hits


def guard_stats() -> dict:
    """给设置面板看：总共错了几次、封了几个、现在还封着谁。"""
    now = time.time()
    with _guard_lock:
        alive = {k: int(v - now) for k, v in _guard["blocked"].items() if v > now}
        return {"fails": _guard["fails"], "blocks": _guard["blocks"],
                "blocked": alive, "last": _guard["last"]}


def guard_reset() -> None:
    """把限速记录清空（自己把自己关门外时用，比如测试之后）。"""
    with _guard_lock:
        _guard["by"].clear()
        _guard["blocked"].clear()
