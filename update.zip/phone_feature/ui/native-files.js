// File and folder evidence stays separate from the broader management page.
window.onAndroidDocumentResult = function(raw) {
  const out = document.getElementById("acceptNative");
  try {
    const d = JSON.parse(raw || "{}");
    const folderResult = String(d.operation || "").startsWith("folder-");
    if (d.cancelled) {
      out.textContent = folderResult
        ? "已取消系统文件夹选择，没有读取文件或保留授权。"
        : d.operation === "save"
        ? "已取消系统保存，没有写入任何文件。"
        : "已取消，没有改动文件或授权。";
      return;
    }
    if (folderResult) {
      out.textContent = "真实文件夹" + (d.operation === "folder-reopen" ? "回读" : "读取")
        + "：" + (d.ok ? "通过" : "失败")
        + (d.name ? " · " + d.name : "")
        + (d.source === "persisted" ? " · 重启后授权回读" : "")
        + (d.child_count != null ? "\n当前层 " + d.child_count + " 项" : "")
        + (d.folder_count != null ? " · 子文件夹 " + d.folder_count + " 项" : "")
        + (d.truncated ? " · 超过 5000 项后停止计数" : "")
        + (d.persisted != null ? "\nURI 授权已持久化："
          + (d.persisted ? "是" : "否（仍完成本次读取）") : "")
        + (d.can_read != null ? "\n可读：" + (d.can_read ? "是" : "否") : "")
        + (d.can_write != null ? " · 可写：" + (d.can_write ? "是" : "否") : "")
        + "\n只统计当前层名称元数据，不遍历文件内容，不自动上传或发送。"
        + (d.error ? "\n错误：" + d.error : "");
      return;
    }
    const label = d.operation === "save" ? "写入"
      : d.operation === "export-diagnostics" ? "诊断快照导出"
      : d.operation === "verify-saved" ? "另存回读" : "读取";
    out.textContent = "真实文件" + label
      + "：" + (d.ok ? "通过" : "失败")
      + (d.name ? " · " + d.name : "")
      + (d.source === "persisted" ? " · 重启后授权回读" : "")
      + (d.source === "persisted-save" ? " · 重启后另存文件回读" : "")
      + (d.size != null ? " · " + d.size + " 字节" : "")
      + (d.sha256 ? "\nSHA-256：" + d.sha256 : "")
      + (d.match != null ? "\n与另存时记录一致：" + (d.match ? "是" : "否") : "")
      + (d.persisted != null ? "\nURI 读取授权已持久化："
        + (d.persisted ? "是" : "否（仍完成本次读取）") : "")
      + (d.preview ? "\n开头：" + d.preview.slice(0, 120) : "")
      + (d.error ? "\n错误：" + d.error : "");
  } catch (e) {
    out.textContent = "系统文件结果解析失败：" + e;
  }
};

document.getElementById("acceptFileOpen").onclick = () => {
  if (window.VoiceApp && VoiceApp.openRealDocument) {
    document.getElementById("acceptNative").textContent =
      "请在系统文件选择器里选一个真实文件…";
    VoiceApp.openRealDocument();
  } else {
    alert("系统文件读取只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFileSave").onclick = () => {
  if (window.VoiceApp && VoiceApp.saveRealDocument) {
    const text = "FinDeck native file check\n"
      + new Date().toISOString() + "\n"
      + "This file was written through Android Storage Access Framework.\n";
    document.getElementById("acceptNative").textContent =
      "请在系统保存页选择位置，验证结束后可由你自行删除…";
    VoiceApp.saveRealDocument("findeck-native-file-" + Date.now() + ".txt", text);
  } else {
    alert("系统文件保存只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFileReopen").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (window.VoiceApp && VoiceApp.reopenRealDocument) {
    out.textContent = "正在通过上次保留的系统授权重新读取文件…";
    VoiceApp.reopenRealDocument();
  } else {
    alert("授权文件回读只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFileVerifySaved").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (window.VoiceApp && VoiceApp.reopenSavedDocument) {
    out.textContent = "正在通过持久授权回读上次另存的文件，并核对 SHA-256…";
    VoiceApp.reopenSavedDocument();
  } else {
    alert("另存文件回读只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFolderOpen").onclick = () => {
  if (window.VoiceApp && VoiceApp.openRealFolder) {
    document.getElementById("acceptNative").textContent =
      "请在系统目录选择器里选一个文件夹；鳍舱只统计当前层项目数量…";
    VoiceApp.openRealFolder();
  } else {
    alert("系统文件夹读取只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFolderReopen").onclick = () => {
  if (window.VoiceApp && VoiceApp.reopenRealFolder) {
    document.getElementById("acceptNative").textContent =
      "正在通过上次保留的系统授权回读文件夹元数据…";
    VoiceApp.reopenRealFolder();
  } else {
    alert("授权文件夹回读只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptPhotoOpen").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (window.VoiceApp && VoiceApp.openSystemPhotoPicker) {
    out.textContent =
      "请在系统相册里选择图片；图片只放进待发送区，点发送才会发出。";
    VoiceApp.openSystemPhotoPicker();
  } else {
    alert("系统相册选择只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptFileRelease").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.releaseRealDocumentAccess) {
    alert("撤销文件授权只能在鳍舱 APK 里进行。");
    return;
  }
  if (!confirm("撤销鳍舱保留的全部文件读取/写入授权？")) return;
  try {
    const d = JSON.parse(VoiceApp.releaseRealDocumentAccess() || "{}");
    out.textContent = "文件授权清理：" + (d.ok ? "完成" : "失败")
      + " · 已撤销 " + (d.released || 0) + " 项"
      + " · 剩余 " + (d.remaining == null ? "未知" : d.remaining) + " 项"
      + (d.error ? "\n错误：" + d.error : "");
  } catch (e) {
    out.textContent = "撤销文件授权失败：" + e;
  }
};
