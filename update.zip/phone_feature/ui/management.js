function acceptanceStateText(status) {
  return status === "passed" ? "已通过"
    : status === "failed" ? "未通过" : "待真机验收";
}

async function acceptanceMark(item, status) {
  let note = item.note || "";
  if (status === "failed") {
    const entered = prompt("记录失败现象（可留空）", note);
    if (entered === null) return;
    note = entered;
  }
  let platform = {};
  try {
    if (window.VoiceApp && VoiceApp.deviceInfo) {
      platform = JSON.parse(VoiceApp.deviceInfo() || "{}");
    }
  } catch (e) {}
  const d = await securePost("/api/device-acceptance/action", {
    id: item.id, status, note, platform, confirm: true
  });
  if (!d.ok) alert(d.err || "保存失败");
  await pullAcceptance(true);
}

async function pullAcceptance(manual = false) {
  const summary = document.getElementById("acceptSummary");
  const box = document.getElementById("acceptList");
  try {
    const r = await fetch("/api/device-acceptance" + Q, {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    summary.textContent = "已通过 " + d.passed + "/" + d.total
      + (d.failed ? " · 未通过 " + d.failed : "")
      + (d.complete ? " · 真机验收完成" : " · 还不能算真机通过")
      + (d.updated_at ? " · "
        + new Date(d.updated_at * 1000).toLocaleString() : "");
    box.innerHTML = "";
    for (const item of d.checks || []) {
      const card = document.createElement("div");
      card.className = "taskCard";
      const title = document.createElement("div");
      title.className = "taskTitle";
      title.textContent = item.title + " · " + acceptanceStateText(item.status);
      const meta = document.createElement("div");
      meta.className = "taskMeta";
      meta.textContent = item.detail
        + (item.note ? "\n记录：" + item.note : "");
      const actions = document.createElement("div");
      actions.className = "taskActions three";
      for (const state of ["passed", "failed", "pending"]) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = state === "passed" ? "通过"
          : state === "failed" ? "未通过" : "重置";
        if (state === "failed") button.className = "danger";
        button.onclick = () => acceptanceMark(item, state);
        actions.appendChild(button);
      }
      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(actions);
      box.appendChild(card);
    }
  } catch (e) {
    summary.textContent = "读取失败：" + e;
  }
}

document.getElementById("acceptRefresh").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.deviceInfo) {
    out.textContent = "当前是浏览器页面，拿不到 Android 权限与通知状态；"
      + "请用鳍舱 APK 打开。";
    return;
  }
  try {
    const info = JSON.parse(VoiceApp.deviceInfo() || "{}");
    out.textContent = (info.manufacturer || "") + " " + (info.model || "")
      + " · Android " + (info.android || "?")
      + " · " + (info.app || "") + "\n"
      + "录音权限：" + (info.record_permission ? "已允许" : "未允许")
      + " · 通知权限：" + (info.notifications_enabled ? "已允许" : "未允许")
      + " · 通知完成事件："
      + (info.done_channel === "high" ? "高优先级" : (info.done_channel || "未创建"))
      + " · 悬浮窗：" + (info.overlay_allowed ? "已允许" : "未允许")
      + " · 通知服务：" + (info.notify_service ? "运行中" : "未运行")
      + "\n屏幕：" + (info.screen_on ? "亮" : "灭")
      + " · 锁屏：" + (info.keyguard_locked ? "已锁" : "未锁")
      + " · 显示：" + (info.screen_width_dp || "?") + "×"
      + (info.screen_height_dp || "?") + " dp"
      + " · 字体 " + Number(info.font_scale || 1).toFixed(2) + "×"
      + " · " + (info.density_dpi || "?") + " dpi"
      + " · " + (info.night_mode ? "深色" : "浅色")
      + " · " + (info.orientation || "?")
      + " · " + (info.locale || "未知语言")
      + " · 后台：" + (info.background_seconds || 0) + " 秒/"
      + (info.background_count || 0) + " 次"
      + " · 网络：" + (info.network_connected ? "已连" : "未连")
      + (info.network_vpn ? "（VPN）" : "")
      + (info.active_network_metered ? "（计费网络）" : "")
      + " · 流量节省：" + (info.data_saver_enabled
        ? (info.data_saver_whitelisted ? "已对本应用放行" : "限制后台")
        : "关闭")
      + " · 电量：" + (info.battery_percent || 0) + "%"
      + (info.battery_charging ? "（充电）" : "")
      + " · 电池优化：" + (info.battery_optimization_ignored
        ? "已豁免" : "可能受限")
      + " · 存储：" + (info.storage_free_mb || 0) + " MB"
      + " · 存储卷：" + (info.storage_volume_ready_count || 0) + "/"
      + (info.storage_volume_count || 0);
  } catch (e) {
    out.textContent = "读取手机状态失败：" + e;
  }
};

document.getElementById("acceptPermission").onclick = () => {
  if (window.VoiceApp && VoiceApp.requestDevicePermissions) {
    VoiceApp.requestDevicePermissions();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 900);
  } else {
    alert("权限申请只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptBattery").onclick = () => {
  if (window.VoiceApp && VoiceApp.openBatteryOptimizationSettings) {
    VoiceApp.openBatteryOptimizationSettings();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 900);
  } else {
    alert("后台电池设置只能在鳍舱 APK 里打开。");
  }
};

document.getElementById("acceptBatteryRequest").onclick = () => {
  if (window.VoiceApp && VoiceApp.requestBatteryOptimizationExemption) {
    VoiceApp.requestBatteryOptimizationExemption();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 1200);
  } else {
    alert("一键申请后台豁免只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptNotify").onclick = () => {
  if (window.VoiceApp && VoiceApp.testNotification) {
    VoiceApp.testNotification();
    alert("测试通知已发出。请锁屏后确认它可见、有声或震动，再记录结果。");
  } else {
    alert("真实通知测试只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptNotifySettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openNotificationSettings) {
    VoiceApp.openNotificationSettings();
  } else {
    alert("通知设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptNotifyChannel").onclick = () => {
  if (window.VoiceApp && VoiceApp.openDoneNotificationChannelSettings) {
    VoiceApp.openDoneNotificationChannelSettings();
  } else {
    alert("完成通道设置只能在鳍舱 APK 里打开。");
  }
};

document.getElementById("acceptDndSettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openSystemInterruptionSettings) {
    VoiceApp.openSystemInterruptionSettings();
  } else {
    alert("系统勿扰设置只能在鳍舱 APK 里打开。");
  }
};

document.getElementById("acceptNotifyDelayed").onclick = () => {
  if (window.VoiceApp && VoiceApp.testDelayedNotification) {
    VoiceApp.testDelayedNotification(15);
  } else {
    alert("后台延迟通知只能在鳍舱 APK 里测试。");
  }
};

const notifyTime = (ms) => ms > 0
  ? new Date(ms).toLocaleTimeString("zh-CN", {hour12: false})
  : "无";

document.getElementById("acceptNotifyEvidence").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.delayedNotificationProbe) {
    out.textContent = "通知送达证据只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.delayedNotificationProbe() || "{}");
    if (!d.scheduled_at) {
      out.textContent = "还没有后台通知记录。先点「15 秒后通知（可锁屏）」。";
      return;
    }
    const state = d.delivered_at
      ? "已送达"
      : d.cancelled ? "已取消"
      : d.pending ? "等待送达"
      : d.overdue ? "已超时但未收到" : "状态未知";
    out.textContent = "后台通知：" + state
      + "\n计划：" + notifyTime(d.scheduled_at)
      + " · 应到：" + notifyTime(d.due_at)
      + " · 实到：" + notifyTime(d.delivered_at)
      + (d.delivered_at
        ? "\n送达偏差：" + (Number(d.delivery_lag_ms) / 1000).toFixed(1) + " 秒"
          + " · 到时亮屏：" + (d.screen_on ? "是" : "否")
          + " · 到时锁屏：" + (d.keyguard_locked ? "是" : "否")
          + "\n系统通知栏：" + (d.notification_visible
            ? "本条通知仍可见"
            : "当前不可见（可能已点击或清除）")
        : "")
      + "\n这是原生闹钟与通知接收器的现场证据；四项声学/后台结论仍需鱼片判定。";
  } catch (e) {
    out.textContent = "通知送达证据读取失败：" + e;
  }
};

document.getElementById("acceptNotifyCancel").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.cancelDelayedNotification) {
    out.textContent = "取消待发送通知只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.cancelDelayedNotification() || "{}");
    out.textContent = d.ok
      ? (d.cancelled
        ? "待发送通知已取消，原计划时间仍保留作证据。"
        : "没有待发送的通知。")
      : "取消失败：" + (d.error || "未知错误");
  } catch (e) {
    out.textContent = "取消待发送通知失败：" + e;
  }
};

const recoveryReasonText = (reason) => reason === "boot" ? "设备重启"
  : reason === "package_replaced" ? "APK 覆盖升级"
  : reason === "manual" ? "用户手动恢复" : (reason || "未知");

document.getElementById("acceptNotifyRecover").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.recoverNotificationService) {
    out.textContent = "通知服务恢复只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.recoverNotificationService() || "{}");
    out.textContent = "通知服务恢复：" + (d.last_ok ? "已拉起" : "未拉起")
      + " · 来源：" + recoveryReasonText(d.last_reason)
      + (d.last_error ? "\n错误：" + d.last_error : "")
      + "\n前台服务当前：" + (d.service_running ? "运行中" : "尚未确认运行")
      + "\n此操作只恢复用户已开启的“忙完提醒”，不会绕过系统后台限制。";
  } catch (e) {
    out.textContent = "通知服务恢复失败：" + e;
  }
};

document.getElementById("acceptNotifyRecovery").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.notificationRecoveryProbe) {
    out.textContent = "通知服务恢复记录只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.notificationRecoveryProbe() || "{}");
    out.textContent = "忙完提醒开关：" + (d.enabled ? "开启" : "关闭")
      + " · 服务：" + (d.service_running ? "运行中" : "未运行")
      + "\n最近恢复：" + (d.last_at
        ? new Date(d.last_at).toLocaleString() : "尚无记录")
      + " · 来源：" + recoveryReasonText(d.last_reason)
      + " · 结果：" + (d.last_at ? (d.last_ok ? "成功" : "失败") : "无")
      + " · 累计 " + (d.count || 0) + " 次"
      + (d.last_error ? "\n错误：" + d.last_error : "")
      + "\n设备重启或 APK 覆盖升级后会自动恢复；这里只记录恢复动作，"
      + "不代表真实锁屏通知已通过验收。";
  } catch (e) {
    out.textContent = "通知服务恢复记录读取失败：" + e;
  }
};

document.getElementById("acceptBackgroundReadiness").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.backgroundReadinessProbe) {
    out.textContent = "后台就绪快照只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.backgroundReadinessProbe() || "{}");
    const pending = Array.isArray(d.pending) ? d.pending.join("、") : "";
    out.textContent = "锁屏后台系统条件：" + (d.background_ready ? "已就绪" : "未就绪")
      + "\n录音权限：" + (d.record_permission ? "已允许" : "未允许")
      + " · 通知权限：" + (d.notifications_enabled ? "已允许" : "未允许")
      + " · 勿扰：" + (d.do_not_disturb_active
        ? "开启（" + (d.interruption_filter_name || "未知") + "）" : "关闭")
      + " · 铃声模式：" + (d.ringer_mode_name || "未知")
      + " · 完成通道：" + (d.done_channel || "未创建")
      + " · 响铃：" + (d.done_channel_sound ? "开" : "关")
      + " · 震动：" + (d.done_channel_vibration ? "开" : "关")
      + " · 通知服务：" + (d.notify_service ? "运行中" : "未运行")
      + " · 轮询心跳：" + (d.notify_service ? (d.notify_service_stale
        ? "陈旧" : "正常") + "（成功 "
        + (d.notify_service_success_count || 0) + " 次，连败 "
        + (d.notify_service_consecutive_failures || 0) + " 次）"
        : "无")
      + ((d.notify_service_consecutive_failures || 0) > 0
        && d.notify_service_last_failure_kind
        ? "\n最近错误：" + d.notify_service_last_failure_kind
          + (d.notify_service_last_response_code
            ? " · HTTP " + d.notify_service_last_response_code : "")
          + (d.notify_service_last_failure_message
            ? " · " + d.notify_service_last_failure_message : "")
        : "")
      + "\n恢复记录：" + (d.notify_recovery_last_at
        ? recoveryReasonText(d.notify_recovery_last_reason) + " / "
          + (d.notify_recovery_last_ok ? "成功" : "失败")
          + " / 共 " + (d.notify_recovery_count || 0) + " 次"
        : "尚无")
      + "\n电池优化：" + (d.battery_optimization_ignored ? "已豁免" : "未豁免")
      + " · 悬浮窗：" + (d.overlay_allowed ? "已允许" : "未允许")
      + " · Doze 空闲：" + (d.device_idle_mode ? "是" : "否")
      + " · 省电模式：" + (d.power_save_mode ? "开" : "关")
      + " · 系统后台限制：" + (d.background_restricted ? "有" : "无")
      + " · 待机桶：" + (Number(d.app_standby_bucket) > 0
        ? d.app_standby_bucket : "未知")
      + "\n网络：" + (d.network_connected ? "已连接" : "未连接")
      + (d.active_network_metered ? "（计费网络）" : "")
      + " · 流量节省：" + (d.data_saver_enabled
        ? (d.data_saver_whitelisted ? "已对本应用放行" : "限制后台数据")
        : "关闭")
      + " · 后台数据受限：" + (d.background_data_restricted ? "是" : "否")
      + " · 屏幕：" + (d.screen_on ? "亮" : "灭")
      + " · 锁屏：" + (d.keyguard_locked ? "已锁" : "未锁")
      + "\n完成通道可提醒：" + (d.done_channel_alerting ? "是" : "否")
      + " · 勿扰拦截有声提醒：" + (d.system_alert_blocked_by_dnd ? "是" : "否")
      + " · 勿扰策略读取：" + (d.notification_policy_access ? "已允许" : "未授权")
      + (pending ? "\n还缺：" + pending : "\n系统条件齐全，仍需实际锁屏和声学验收。");
  } catch (e) {
    out.textContent = "后台就绪快照读取失败：" + e;
  }
};

document.getElementById("acceptStorageProbe").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.appStorageProbe) {
    out.textContent = "应用存储验证只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const probe = JSON.parse(VoiceApp.appStorageProbe() || "{}");
    out.textContent = "应用缓存写入/读回：" + (probe.ok ? "通过" : "失败")
      + " · " + (probe.bytes || 0) + " 字节"
      + " · 临时文件已清理：" + (probe.cleaned ? "是" : "否")
      + "\n缓存目录：" + (probe.cache_dir || "")
      + (probe.error ? "\n错误：" + probe.error : "");
  } catch (e) {
    out.textContent = "应用存储验证失败：" + e;
  }
};

document.getElementById("acceptAudioFocus").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.audioFocusProbe) {
    out.textContent = "音频焦点验证只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const probe = JSON.parse(VoiceApp.audioFocusProbe() || "{}");
    out.textContent = "系统音频焦点：" + (probe.granted ? "申请成功" : "申请失败")
      + " · 已释放：" + (probe.released ? "是" : "否")
      + " · Android " + (probe.sdk || "?")
      + " · 最近焦点事件：" + (probe.last_change || 0)
      + "\n申请 / 成功 / 失焦 / 恢复 / 释放："
      + (probe.request_count || 0) + " / " + (probe.grant_count || 0)
      + " / " + (probe.loss_count || 0) + " / " + (probe.gain_count || 0)
      + " / " + (probe.abandon_count || 0)
      + " · 事件记录：" + ((probe.events || []).length)
      + (probe.last_change_at
        ? "\n最近变化：" + new Date(probe.last_change_at).toLocaleString()
        : "")
      + "\n真实录音时会在开始前申请临时独占焦点；电话或其他语音应用抢占时会停止本次录音。"
      + " 这份计数是现场证据，仍不冒充声学或锁屏验收结果。";
  } catch (e) {
    out.textContent = "音频焦点验证失败：" + e;
  }
};

document.getElementById("acceptVoiceEcho").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.recStart || !VoiceApp.recStop) {
    out.textContent = "原生麦克风采样只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    VoiceApp.recStart();
    out.textContent = "正在采样手机麦克风 8 秒…"
      + "请保持当前声学环境，采样结束后会走原有语音命令管线。";
    setTimeout(() => {
      try {
        VoiceApp.recStop();
        out.textContent = "8 秒麦克风采样已停止并提交。"
          + "请看电脑日志是否把播报误当成新用户指令。";
      } catch (e) {
        out.textContent = "停止麦克风采样失败：" + e;
      }
    }, 8000);
  } catch (e) {
    out.textContent = "启动麦克风采样失败：" + e;
  }
};

document.getElementById("acceptAudioEnvironment").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.audioEnvironmentSnapshot) {
    out.textContent = "音频路由快照只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.audioEnvironmentSnapshot() || "{}");
    if (!d.ok) {
      out.textContent = "音频路由快照读取失败：" + (d.error || "未知错误");
      return;
    }
    out.textContent = "音频模式：" + (d.mode_name || d.mode || "未知")
      + " · 免提：" + (d.speakerphone ? "开" : "关")
      + " · 蓝牙 SCO：" + (d.bluetooth_sco ? "开" : "关")
      + " · 麦克风静音：" + (d.microphone_mute ? "是" : "否")
      + "\n输入路由 " + (d.input_count || 0) + " 个 · 输出路由 "
      + (d.output_count || 0) + " 个"
      + " · 内置麦克风：" + (d.builtin_mic ? "有" : "无")
      + " · 外放：" + (d.builtin_speaker ? "有" : "无")
      + " · 耳机/听筒：" + ((d.wired_route || d.earpiece) ? "有" : "无")
      + " · 蓝牙：" + (d.bluetooth_route ? "有" : "无")
      + "\n媒体音量：" + (d.music_volume ?? "?") + " / "
      + (d.music_volume_max ?? "?")
      + " · 采样率：" + ((d.sample_rates || []).join("、") || "未知")
      + " · 声道：" + ((d.channel_counts || []).join("、") || "未知")
      + "\n路由变化记录：" + (d.route_change_count || 0)
      + (d.route_changed_since_last_snapshot ? "（这次检测到变化）" : "（与上次相同）")
      + (d.route_last_changed_at
        ? " · 最近 " + new Date(d.route_last_changed_at).toLocaleString()
        : " · 尚未记录到变化")
      + "\n这是声学回声验收前的路由现场，不代替真实回声或误唤醒结论。";
  } catch (e) {
    out.textContent = "音频路由快照读取失败：" + e;
  }
};

document.getElementById("acceptWindowLayout").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.windowLayoutProbe) {
    out.textContent = "窗口安全区只能在鳍舱 APK 内读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.windowLayoutProbe() || "{}");
    if (!d.ok) throw new Error(d.error || "读取失败");
    out.textContent = "窗口安全区 · " + (d.schema || "unknown") + "\n"
      + "当前窗口：" + (d.window_current_width || "?") + "×"
      + (d.window_current_height || "?") + " px"
      + " · 最大：" + (d.window_maximum_width || "?") + "×"
      + (d.window_maximum_height || "?") + " px"
      + " · 刷新率：" + Number(d.refresh_rate || 0).toFixed(1) + " Hz"
      + " · 旋转：" + (d.rotation ?? "?") + "\n"
      + "状态栏：" + (d.status_bars_top || 0) + " / "
      + (d.status_bars_bottom || 0) + " · 导航栏："
      + (d.navigation_bars_left || 0) + "/" + (d.navigation_bars_top || 0)
      + "/" + (d.navigation_bars_right || 0) + "/"
      + (d.navigation_bars_bottom || 0) + " · 刘海："
      + (d.display_cutout ? "有" : "无")
      + (d.display_cutout ? "（安全区 " + (d.cutout_safe_left || 0) + "/"
        + (d.cutout_safe_top || 0) + "/" + (d.cutout_safe_right || 0)
        + "/" + (d.cutout_safe_bottom || 0) + "）" : "")
      + "\n仅用于核对窗口布局，不替代真机验收结论。";
  } catch (e) {
    out.textContent = "读取窗口安全区失败：" + e;
  }
};

document.getElementById("acceptDisplaySettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openDisplaySettings) {
    VoiceApp.openDisplaySettings();
  } else {
    alert("屏幕设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptTimeContext").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.timeContextProbe) {
    out.textContent = "系统时间现场只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.timeContextProbe() || "{}");
    if (!d.ok) throw new Error(d.error || "读取失败");
    out.textContent = "系统时间现场 · " + (d.schema || "unknown")
      + "\n本地时间：" + (d.local_time_iso || "未知")
      + " · 时区：" + (d.time_zone_id || "未知")
      + "（" + (d.time_zone_display_name || "未知") + "）"
      + "\nUTC 偏移：" + (d.utc_offset_minutes ?? "?") + " 分钟"
      + " · 夏令时：" + (d.daylight_saving_active
        ? "生效（" + (d.daylight_saving_minutes || 0) + " 分钟）" : "未生效")
      + " · 24 小时制：" + (d.clock_24_hour ? "开" : "关")
      + "\n自动时间：" + (d.automatic_time ? "开" : "关")
      + " · 自动时区：" + (d.automatic_time_zone ? "开" : "关")
      + "\n用于核对本机日程和提醒的时间基准，不替代真机验收结果。";
  } catch (e) {
    out.textContent = "系统时间现场读取失败：" + e;
  }
};

document.getElementById("acceptTimeSettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openTimeSettings) {
    VoiceApp.openTimeSettings();
  } else {
    alert("系统时间设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptDataSaverSettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openDataSaverSettings) {
    VoiceApp.openDataSaverSettings();
  } else {
    alert("流量设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptNetworkContext").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.networkContextProbe) {
    out.textContent = "网络连接现场只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.networkContextProbe() || "{}");
    if (!d.ok) throw new Error(d.error || "读取失败");
    out.textContent = "网络连接现场 · " + (d.schema || "unknown")
      + "\n已联网：" + (d.connected ? "是" : "否")
      + " · 系统已验证：" + (d.validated ? "是" : "否")
      + " · 当前通道：" + (d.transport || "unknown")
      + "\nWi-Fi：" + (d.wifi ? "是" : "否")
      + " · 移动网络：" + (d.cellular ? "是" : "否")
      + " · 以太网：" + (d.ethernet ? "是" : "否")
      + " · VPN：" + (d.vpn ? "是" : "否")
      + " · 计费网络：" + (d.metered ? "是" : "否")
      + " · 飞行模式：" + (d.airplane_mode ? "开" : "关")
      + "\n只用于连接排障，不读取地址、Wi-Fi 名称或流量内容，"
      + "也不替代真机验收结果。";
  } catch (e) {
    out.textContent = "网络连接现场读取失败：" + e;
  }
};

document.getElementById("acceptNetworkSettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openNetworkSettings) {
    VoiceApp.openNetworkSettings();
  } else {
    alert("网络设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptPowerContext").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.powerContextProbe) {
    out.textContent = "电源与散热现场只能在鳍舱 APK 里读取。";
    return;
  }
  try {
    const d = JSON.parse(VoiceApp.powerContextProbe() || "{}");
    if (!d.ok) throw new Error(d.error || "读取失败");
    const temperature = Number(d.battery_temperature_tenths_c);
    out.textContent = "电源与散热现场 · " + (d.schema || "unknown")
      + "\n散热状态：" + (d.thermal_status_name || "unknown")
      + (d.thermal_supported ? "" : "（系统不支持分级读取）")
      + " · 省电模式：" + (d.power_save_mode ? "开" : "关")
      + " · Doze：" + (d.device_idle_mode ? "是" : "否")
      + "\n屏幕：" + (d.interactive ? "亮" : "灭")
      + " · 锁屏：" + (d.keyguard_locked ? "已锁" : "未锁")
      + " · 电量：" + (d.battery_percent ?? "?") + "%"
      + " · 充电：" + (d.battery_charging ? "是" : "否")
      + " · 电池温度：" + (temperature >= 0
        ? (temperature / 10).toFixed(1) + " ℃" : "未知")
      + "\n只读取系统现场，不切换省电模式、不修改散热策略，"
      + "也不替代真实锁屏后台验收。";
  } catch (e) {
    out.textContent = "电源与散热现场读取失败：" + e;
  }
};

document.getElementById("acceptExportDiagnostics").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.exportDiagnosticSnapshot) {
    out.textContent = "诊断快照导出只能在鳍舱 APK 里进行。";
    return;
  }
  out.textContent = "正在生成设备、后台、通知、音频焦点、音频路由、窗口安全区和系统时间快照，"
    + "随后请在系统保存页选择位置…";
  VoiceApp.exportDiagnosticSnapshot();
};

document.getElementById("acceptCopyDiagnostics").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.copyDiagnosticSnapshot) {
    out.textContent = "复制诊断快照只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const ok = VoiceApp.copyDiagnosticSnapshot();
    out.textContent = ok
      ? "诊断快照已复制到系统剪贴板；内容不含手机令牌、对话正文或文件内容。"
      : "复制诊断快照失败，请改用导出。";
  } catch (e) {
    out.textContent = "复制诊断快照失败：" + e;
  }
};

document.getElementById("acceptShareDiagnostics").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.shareDiagnosticSnapshot) {
    out.textContent = "分享诊断快照只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const shared = JSON.parse(VoiceApp.shareDiagnosticSnapshot() || "{}");
    out.textContent = shared.ok
      ? "已通过系统分享面板发送真实 JSON 文件"
        + (shared.name ? "：" + shared.name : "")
        + "；不含手机令牌、对话正文或文件内容。"
      : "生成诊断分享文件失败：" + (shared.error || "未知错误");
  } catch (e) {
    out.textContent = "分享诊断快照失败：" + e;
  }
};
