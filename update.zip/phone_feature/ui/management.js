// FinDeck phone management surfaces: plugins and real-device acceptance.
// Loaded after the main page script, sharing its Q and securePost helpers.

function pluginStatusText(item) {
  if (item.last_error) return "最近失败：" + item.last_error;
  if (item.error) return item.error;
  if (item.loaded) return "已启用并运行";
  if (item.enabled) return "已启用，等待下一次加载";
  return item.sealed ? "已安装，未启用" : "未通过本机安装签名";
}

function publisherText(signature) {
  if (!signature || !signature.signed) return "发布者未签名（本机侧载）";
  const publisher = signature.publisher || {};
  if (!signature.valid) return "发布者签名无效：" + (signature.error || "");
  return "发布者 " + (publisher.name || publisher.id || "未知")
    + " · " + (publisher.key_id || "")
    + (signature.trusted ? " · 已信任" : " · 尚未信任");
}

async function pluginAction(id, action, extra = {}) {
  const d = await securePost("/api/plugins/action",
    Object.assign({action, id}, extra));
  if (!d.ok) alert(d.err || "插件操作失败");
  await pullPlugins(true);
}

async function pullPlugins(manual = false) {
  const summary = document.getElementById("pluginSummary");
  const box = document.getElementById("pluginList");
  try {
    const r = await fetch("/api/plugins" + Q, {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    const rows = Array.isArray(d.plugins) ? d.plugins : [];
    summary.textContent = rows.length
      ? rows.length + " 个已安装 · "
        + rows.filter(x => x.loaded).length + " 个运行中 · API " + d.api
      : "还没有插件。选择 ZIP 包后会先展示能力和权限，确认后才安装。";
    box.innerHTML = "";
    for (const item of rows) {
      const card = document.createElement("div");
      card.className = "taskCard";
      const title = document.createElement("div");
      title.className = "taskTitle";
      title.textContent = item.name + " · v" + item.version;
      card.appendChild(title);
      const meta = document.createElement("div");
      meta.className = "taskMeta";
      meta.textContent = (item.description || item.id)
        + "\n能力：" + ((item.capabilities || []).join(", ") || "无")
        + " · 权限：" + ((item.permissions || []).join(", ") || "无")
        + "\n" + publisherText(item.publisher_signature);
      card.appendChild(meta);
      const state = document.createElement("div");
      state.className = "taskMeta";
      state.textContent = pluginStatusText(item);
      card.appendChild(state);
      const actions = document.createElement("div");
      actions.className = "taskActions three";
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.textContent = item.enabled ? "停用" : "启用";
      toggle.disabled = !item.enabled && (!item.sealed || !!item.error);
      toggle.onclick = () => pluginAction(
        item.id, item.enabled ? "disable" : "enable");
      const reload = document.createElement("button");
      reload.type = "button"; reload.textContent = "重载";
      reload.disabled = !item.enabled;
      reload.onclick = () => pluginAction(item.id, "reload");
      const remove = document.createElement("button");
      remove.type = "button"; remove.className = "danger";
      remove.textContent = "移除";
      remove.onclick = () => {
        if (confirm("移除「" + item.name + "」？文件会移到可恢复的回收目录。")) {
          pluginAction(item.id, "remove", {confirm: true});
        }
      };
      actions.appendChild(toggle);
      actions.appendChild(reload);
      actions.appendChild(remove);
      card.appendChild(actions);
      if (item.publisher_signature && item.publisher_signature.signed
          && item.publisher_signature.valid
          && !item.publisher_signature.trusted) {
        const trust = document.createElement("div");
        trust.className = "taskActions";
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "信任此发布者";
        button.onclick = () => {
          const publisher = item.publisher_signature.publisher || {};
          if (confirm("信任发布者「" + (publisher.name || publisher.id)
              + "」\n密钥：" + (publisher.key_id || "")
              + "\n\n以后来自这把密钥的市场插件可直接通过签名校验。")) {
            pluginAction(item.id, "trust_plugin", {confirm: true});
          }
        };
        trust.appendChild(button);
        card.appendChild(trust);
      }
      box.appendChild(card);
    }
    if (!rows.length) {
      const empty = document.createElement("div");
      empty.className = "taskMeta";
      empty.textContent = "插件目录：" + (d.root || "");
      box.appendChild(empty);
    }
    renderMarket(d.market || {});
  } catch (e) {
    summary.textContent = "读取失败：" + e;
  }
}

function renderMarket(market) {
  const summary = document.getElementById("marketSummary");
  const box = document.getElementById("marketList");
  const publishers = document.getElementById("publisherList");
  const sources = Array.isArray(market.sources) ? market.sources : [];
  summary.textContent = sources.length
    ? sources.length + " 个市场源 · " + (market.plugin_count || 0)
      + " 个插件 · 市场只接受有效发布者签名"
    : "还没有市场源。添加 HTTPS 目录地址后再安装；市场包仍需信任发布者。";
  box.innerHTML = "";
  for (const source of sources) {
    const card = document.createElement("div");
    card.className = "taskCard";
    const title = document.createElement("div");
    title.className = "taskTitle";
    title.textContent = source.name + (source.error ? " · 刷新失败" : "");
    card.appendChild(title);
    const meta = document.createElement("div");
    meta.className = "taskMeta";
    meta.textContent = source.url + (source.error ? "\n" + source.error : "");
    card.appendChild(meta);
    for (const item of source.plugins || []) {
      const row = document.createElement("div");
      row.className = "taskCard";
      const name = document.createElement("div");
      name.className = "taskTitle";
      name.textContent = item.name + " · v" + item.version;
      const info = document.createElement("div");
      info.className = "taskMeta";
      info.textContent = (item.description || item.id)
        + "\n发布者：" + item.publisher
        + " · 权限：" + ((item.permissions || []).join(", ") || "无");
      const actions = document.createElement("div");
      actions.className = "taskActions";
      const install = document.createElement("button");
      install.type = "button";
      install.textContent = "检查并安装";
      install.onclick = () => marketInstall(source.id, item);
      actions.appendChild(install);
      row.appendChild(name);
      row.appendChild(info);
      row.appendChild(actions);
      card.appendChild(row);
    }
    const actions = document.createElement("div");
    actions.className = "taskActions";
    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.textContent = "刷新此源";
    refresh.onclick = () => pluginAction(
      "", "market_refresh", {source_id: source.id});
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "danger";
    remove.textContent = "移除源";
    remove.onclick = () => {
      if (confirm("移除市场源「" + source.name + "」？已安装插件不受影响。")) {
        pluginAction("", "market_remove", {
          source_id: source.id, confirm: true
        });
      }
    };
    actions.appendChild(refresh);
    actions.appendChild(remove);
    card.appendChild(actions);
    box.appendChild(card);
  }
  publishers.textContent = "";
}

async function marketInstall(sourceId, item) {
  const status = document.getElementById("pluginStatus");
  try {
    status.textContent = "正在下载并校验 " + item.name + "…";
    let out = await securePost("/api/plugins/action", {
      action: "market_install", source_id: sourceId, id: item.id, confirm: true
    });
    if (out.needs_confirmation) {
      const plugin = out.plugin || {};
      const permissions = Array.isArray(plugin.permissions)
        ? plugin.permissions : (item.permissions || []);
      if (!confirm("安装市场插件「" + (plugin.name || item.name) + "」？\n\n"
          + "发布者：" + ((plugin.publisher || {}).name || item.publisher)
          + "\n权限：" + (permissions.join(", ") || "无")
          + "\n\n下载包通过签名与 SHA-256 校验后，仍需手动启用。")) {
        status.textContent = "已取消，没有安装。";
        return;
      }
      out = await securePost("/api/plugins/action", {
        action: "market_install", source_id: sourceId, id: item.id,
        confirmed_permissions: permissions, confirm: true
      });
    }
    if (out.needs_trust) {
      const publisher = (out.plugin || {}).publisher
        || (out.publisher_signature || {}).publisher || {};
      if (!confirm("这个市场包的发布者尚未信任。\n\n"
          + "发布者：" + (publisher.name || publisher.id || item.publisher)
          + "\n密钥：" + (publisher.key_id || item.key_id || "")
          + "\n\n确认信任后再重试安装？")) {
        status.textContent = "已取消，没有安装。";
        return;
      }
      const trusted = await securePost("/api/plugins/action", {
        action: "trust_publisher", publisher, confirm: true
      });
      if (!trusted.ok) throw new Error(trusted.err || "信任发布者失败");
      out = await securePost("/api/plugins/action", {
        action: "market_install", source_id: sourceId, id: item.id,
        confirmed_permissions: item.permissions || [], confirm: true
      });
    }
    if (!out.ok || !out.installed) throw new Error(out.err || "安装失败");
    status.textContent = "已安装 " + out.name + " v" + out.version
      + "，保持关闭状态。";
    await pullPlugins(true);
  } catch (err) {
    status.textContent = "市场安装失败：" + err;
  }
}

document.getElementById("pluginRefresh").onclick = () => pullPlugins(true);
document.getElementById("marketAdd").onclick = async () => {
  const input = document.getElementById("marketSource");
  const url = (input.value || "").trim();
  if (!url) return;
  if (!confirm("添加插件市场源？\n\n" + url
      + "\n\n目录本身只负责发现；安装时仍强制校验发布者签名。")) return;
  try {
    const out = await securePost("/api/plugins/action", {
      action: "market_add", url, confirm: true
    });
    if (!out.ok) throw new Error(out.err || "添加失败");
    input.value = "";
    await pullPlugins(true);
  } catch (err) {
    document.getElementById("pluginStatus").textContent = "添加市场源失败：" + err;
  }
};
document.getElementById("marketRefresh").onclick =
  () => pluginAction("", "market_refresh_all");
document.getElementById("pluginChoose").onclick =
  () => document.getElementById("pluginFile").click();
document.getElementById("pluginFile").onchange = async e => {
  const file = e.target.files && e.target.files[0];
  e.target.value = "";
  if (!file) return;
  const status = document.getElementById("pluginStatus");
  status.textContent = "正在检查 " + file.name + "…";
  try {
    const raw = await file.arrayBuffer();
    let out = await securePostRaw("/api/plugins/install", raw);
    if (out.needs_confirmation) {
      const plugin = out.plugin || {};
      const permissions = Array.isArray(plugin.permissions)
        ? plugin.permissions : [];
      const capabilities = Array.isArray(plugin.capabilities)
        ? plugin.capabilities : [];
      const text = "安装「" + (plugin.name || plugin.id || file.name) + "」？\n\n"
        + "版本：" + (plugin.version || "未知") + "\n"
        + "能力：" + (capabilities.join(", ") || "无") + "\n"
        + "声明权限：" + (permissions.join(", ") || "无") + "\n\n"
        + "安装不会自动执行；确认权限后仍需手动启用。"
        + "权限是声明，不是安全沙箱。";
      if (!confirm(text)) {
        status.textContent = "已取消，没有写入插件。";
        return;
      }
      out = await securePostRaw("/api/plugins/install", raw, {
        "X-FinDeck-Plugin-Permissions": JSON.stringify(permissions)
      });
    }
    if (!out.ok || !out.installed) {
      throw new Error(out.err || "安装失败");
    }
    status.textContent = "已安装 " + out.name + " v" + out.version
      + "，保持关闭状态。";
    await pullPlugins(true);
  } catch (err) {
    status.textContent = "安装失败：" + err;
  }
};

function acceptanceStateText(status) {
  return status === "passed" ? "已通过"
    : status === "failed" ? "未通过" : "待真机验收";
}

async function acceptanceMark(item, status) {
  let note = item.note || "";
  if (status === "failed") {
    const entered = prompt("记录失败现象（可留空）", note);
    if (entered === null) return;
    note = entered;
  }
  let platform = {};
  try {
    if (window.VoiceApp && VoiceApp.deviceInfo) {
      platform = JSON.parse(VoiceApp.deviceInfo() || "{}");
    }
  } catch (e) {}
  const d = await securePost("/api/device-acceptance/action", {
    id: item.id, status, note, platform, confirm: true
  });
  if (!d.ok) alert(d.err || "保存失败");
  await pullAcceptance(true);
}

async function pullAcceptance(manual = false) {
  const summary = document.getElementById("acceptSummary");
  const box = document.getElementById("acceptList");
  try {
    const r = await fetch("/api/device-acceptance" + Q, {cache: "no-store"});
    const d = await r.json();
    if (!d.ok) throw new Error(d.err || "读取失败");
    summary.textContent = "已通过 " + d.passed + "/" + d.total
      + (d.failed ? " · 未通过 " + d.failed : "")
      + (d.complete ? " · 真机验收完成" : " · 还不能算真机通过")
      + (d.updated_at ? " · "
        + new Date(d.updated_at * 1000).toLocaleString() : "");
    box.innerHTML = "";
    for (const item of d.checks || []) {
      const card = document.createElement("div");
      card.className = "taskCard";
      const title = document.createElement("div");
      title.className = "taskTitle";
      title.textContent = item.title + " · " + acceptanceStateText(item.status);
      const meta = document.createElement("div");
      meta.className = "taskMeta";
      meta.textContent = item.detail
        + (item.note ? "\n记录：" + item.note : "");
      const actions = document.createElement("div");
      actions.className = "taskActions three";
      for (const state of ["passed", "failed", "pending"]) {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = state === "passed" ? "通过"
          : state === "failed" ? "未通过" : "重置";
        if (state === "failed") button.className = "danger";
        button.onclick = () => acceptanceMark(item, state);
        actions.appendChild(button);
      }
      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(actions);
      box.appendChild(card);
    }
  } catch (e) {
    summary.textContent = "读取失败：" + e;
  }
}

document.getElementById("acceptRefresh").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.deviceInfo) {
    out.textContent = "当前是浏览器页面，拿不到 Android 权限与通知状态；"
      + "请用鳍舱 APK 打开。";
    return;
  }
  try {
    const info = JSON.parse(VoiceApp.deviceInfo() || "{}");
    out.textContent = (info.manufacturer || "") + " " + (info.model || "")
      + " · Android " + (info.android || "?")
      + " · " + (info.app || "") + "\n"
      + "录音权限：" + (info.record_permission ? "已允许" : "未允许")
      + " · 通知权限：" + (info.notifications_enabled ? "已允许" : "未允许")
      + " · 通知完成事件："
      + (info.done_channel === "high" ? "高优先级" : (info.done_channel || "未创建"))
      + " · 悬浮窗：" + (info.overlay_allowed ? "已允许" : "未允许")
      + " · 通知服务：" + (info.notify_service ? "运行中" : "未运行")
      + "\n屏幕：" + (info.screen_on ? "亮" : "灭")
      + " · 锁屏：" + (info.keyguard_locked ? "已锁" : "未锁")
      + " · 后台：" + (info.background_seconds || 0) + " 秒/"
      + (info.background_count || 0) + " 次"
      + " · 网络：" + (info.network_connected ? "已连" : "未连")
      + (info.network_vpn ? "（VPN）" : "")
      + " · 电量：" + (info.battery_percent || 0) + "%"
      + (info.battery_charging ? "（充电）" : "")
      + " · 电池优化：" + (info.battery_optimization_ignored
        ? "已豁免" : "可能受限")
      + " · 存储：" + (info.storage_free_mb || 0) + " MB";
  } catch (e) {
    out.textContent = "读取手机状态失败：" + e;
  }
};

document.getElementById("acceptPermission").onclick = () => {
  if (window.VoiceApp && VoiceApp.requestDevicePermissions) {
    VoiceApp.requestDevicePermissions();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 900);
  } else {
    alert("权限申请只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptBattery").onclick = () => {
  if (window.VoiceApp && VoiceApp.openBatteryOptimizationSettings) {
    VoiceApp.openBatteryOptimizationSettings();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 900);
  } else {
    alert("后台电池设置只能在鳍舱 APK 里打开。");
  }
};

document.getElementById("acceptBatteryRequest").onclick = () => {
  if (window.VoiceApp && VoiceApp.requestBatteryOptimizationExemption) {
    VoiceApp.requestBatteryOptimizationExemption();
    setTimeout(() => document.getElementById("acceptRefresh").click(), 1200);
  } else {
    alert("一键申请后台豁免只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptNotify").onclick = () => {
  if (window.VoiceApp && VoiceApp.testNotification) {
    VoiceApp.testNotification();
    alert("测试通知已发出。请锁屏后确认它可见、有声或震动，再记录结果。");
  } else {
    alert("真实通知测试只能在鳍舱 APK 里进行。");
  }
};

document.getElementById("acceptNotifySettings").onclick = () => {
  if (window.VoiceApp && VoiceApp.openNotificationSettings) {
    VoiceApp.openNotificationSettings();
  } else {
    alert("通知设置入口只能在鳍舱 APK 里使用。");
  }
};

document.getElementById("acceptStorageProbe").onclick = () => {
  const out = document.getElementById("acceptNative");
  if (!window.VoiceApp || !VoiceApp.appStorageProbe) {
    out.textContent = "应用存储验证只能在鳍舱 APK 里进行。";
    return;
  }
  try {
    const probe = JSON.parse(VoiceApp.appStorageProbe() || "{}");
    out.textContent = "应用缓存写入/读回：" + (probe.ok ? "通过" : "失败")
      + " · " + (probe.bytes || 0) + " 字节"
      + " · 临时文件已清理：" + (probe.cleaned ? "是" : "否")
      + "\n缓存目录：" + (probe.cache_dir || "")
      + (probe.error ? "\n错误：" + probe.error : "");
  } catch (e) {
    out.textContent = "应用存储验证失败：" + e;
  }
};
