# -*- coding: utf-8 -*-
"""Remote-access settings actions leave the overlay shell without behavior drift."""
from __future__ import annotations

import ast
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_remote_actions_mixin import (  # noqa: E402
    OverlaySettingsRemoteActionsMixin,
)
from overlay_feature.settings_remote_status_mixin import (  # noqa: E402
    OverlaySettingsRemoteStatusMixin,
)


class Label:
    def __init__(self) -> None:
        self.text = ""
        self.color = ""

    def config(self, **kwargs) -> None:
        self.text = kwargs["text"]
        self.color = kwargs["fg"]


class Root:
    def __init__(self) -> None:
        self.clipboard = ""

    def clipboard_clear(self) -> None:
        self.clipboard = ""

    def clipboard_append(self, text) -> None:
        self.clipboard += text

    def after(self, _delay, callback) -> None:
        callback()


class Probe(OverlaySettingsRemoteActionsMixin):
    def __init__(self) -> None:
        self.root = Root()
        self.remote_label = Label()
        self.phone_url_label = Label()
        self.phone_url_label.text = "http://fallback.test/?k=token"
        self.cfg = {"phone_port": 8765}
        self.flash_calls = []

    def flash(self, text, seconds=1.6) -> None:
        self.flash_calls.append((text, seconds))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    probe = Probe()
    remote = types.SimpleNamespace(
        detail=lambda fresh=True: {
            "logged_in": True,
            "funnel_on": False,
            "account": "account@example.test",
            "device": "desktop",
            "url": "https://desktop.example.test/?k=secret",
            "alt_url": "",
        },
        fixed_url=lambda: "https://desktop.example.test/?k=secret",
        public_url=lambda: "",
    )
    previous_remote = sys.modules.get("remote_access")
    sys.modules["remote_access"] = remote
    try:
        probe._remote_report()
    finally:
        if previous_remote is None:
            sys.modules.pop("remote_access", None)
        else:
            sys.modules["remote_access"] = previous_remote
    probe._remote_poll()
    check("已经通了" in probe.remote_label.text
          and "?k=…" in probe.remote_label.text
          and "secret" not in probe.remote_label.text,
          "外网状态只展示脱敏地址")
    check(probe.remote_fixed_url.endswith("secret"),
          "完整地址仍保留给复制按钮")

    probe.root.clipboard = "old"
    probe.copy_remote_url()
    check(probe.root.clipboard.endswith("secret")
          and probe.flash_calls[-1][0].startswith("外网固定地址已复制"),
          "复制外网地址仍使用完整地址")

    old = types.SimpleNamespace(
        phone_url=lambda port: f"http://phone.test:{port}/?k=fresh",
    )
    previous = sys.modules.get("phone_link")
    sys.modules["phone_link"] = old
    try:
        probe.copy_phone_url()
    finally:
        if previous is None:
            sys.modules.pop("phone_link", None)
        else:
            sys.modules["phone_link"] = previous
    check(probe.root.clipboard.endswith("fresh"),
          "手机网址现读后复制")

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    tree = ast.parse(overlay)
    overlay_class = next(
        node for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "Overlay"
    )
    own_methods = {
        node.name
        for node in overlay_class.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    remote_methods = {
        "copy_phone_url",
        "phone_url_now",
        "refresh_remote",
        "_remote_report",
        "_masked_url",
        "_remote_poll",
        "remote_enable",
        "copy_remote_url",
        "remote_funnel_on",
        "remote_funnel_off",
        "copy_public_url",
    }
    check(not own_methods & remote_methods,
          "Overlay 外壳不再内联外网访问动作")
    check("OverlaySettingsRemoteActionsMixin" in overlay,
          "全部历史方法由独立 mixin 组合保留")
    check(probe.copy_phone_url.__module__
          == "overlay_feature.settings_remote_actions_mixin",
          "原按钮方法名解析到新模块")
    check(probe._remote_report.__module__
          == "overlay_feature.settings_remote_status_mixin"
          and issubclass(
              OverlaySettingsRemoteActionsMixin,
              OverlaySettingsRemoteStatusMixin,
          ),
          "状态读取与轮询独立，历史动作类仍组合全部入口")

    status_source = (
        APP / "overlay_feature" / "settings_remote_status_mixin.py"
    ).read_text(encoding="utf-8")
    action_source = (
        APP / "overlay_feature" / "settings_remote_actions_mixin.py"
    ).read_text(encoding="utf-8")
    for marker in (
        "remote_access.detail(fresh=True)",
        "def _masked_url(",
        "def _remote_poll(",
    ):
        check(marker in status_source, f"状态边界保持：{marker}")
    for marker in (
        "remote_access.enable(progress=None)",
        "remote_access.funnel_enable()",
        "remote_access.funnel_disable()",
        "_runtime.inputlog(",
    ):
        check(marker in action_source, f"动作边界保持：{marker}")
    for marker in (
        "remote_access.detail(fresh=True)",
        "remote_access.enable(progress=None)",
        "remote_access.funnel_enable()",
        "remote_access.funnel_disable()",
        "_runtime.inputlog(",
    ):
        check(marker in status_source + action_source, f"兼容语义仍存在：{marker}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
