# -*- coding: utf-8 -*-
"""验收「重复第二遍就算我说的」+「自己的声音判得严」。

样本是真的：syslog 里 23:33–23:34 那几行。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import stt  # noqa: E402

# 它刚念过的那句（真机里被当成"自己的声音"的那种）
SPOKEN = ("它在听你说话。日志里 23:33:05 就记着「能听到我说话吗」→ 已经发到 ChatGPT 窗口，"
          "并回了「好的，收到」。")

# (用户说的话, 该不该被判成"它自己在念")
SELF_VOICE = [
    # —— 真的是它自己在念（TTS 录回来）→ 该丢 ——
    (SPOKEN, SPOKEN, True),
    ("它在听你说话。日志里 23:33:05 就记着「能听到我说话吗」", SPOKEN, True),
    ("马上办。", "马上办", True),          # 应答语被录回来
    ("好的，我这就做", "好的，我这就做。", True),
    # —— 用户自己说、只是跟它念过的有重合 → 不能丢 ——
    ("设置展开的时候有大黑边", SPOKEN, False),
    ("我们看到米23.33分11秒那具设置展开的时候。", SPOKEN, False),
    ("我现在开始装VS2022 Buildtools。", SPOKEN, False),
    ("能不能把这个当成自己的声音忽略的这个判定范围改得宽松一点啊", SPOKEN, False),
    ("帮我把插件编出来", SPOKEN, False),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 「这句是不是它自己在念」判得严一点")
    for text, candidate, want_mine in SELF_VOICE:
        got = stt.sounds_like(text, candidate)
        check(got == want_mine,
              f"{'判成它自己念' if want_mine else '当成你说的'} ← 「{text[:34]}」")

    print("\n② 同一句被误丢之后，再说第二遍就算你说的")
    now = time.time()
    miss = {"text": "设置展开的时候有大黑边", "at": now}
    check(stt.repeated_after_miss("设置展开的时候有大黑边", miss, now), "同一句 → 算你说的")
    check(stt.repeated_after_miss("设置展开的时候有大黑边。", miss, now + 30),
          "隔 30 秒重复一遍 → 也算你说的（加了标点也一样）")
    check(stt.repeated_after_miss("我们现在说的是别的事情", miss, now) is False,
          "说别的 → 不算重复")
    check(stt.repeated_after_miss("设置展开的时候有大黑边", miss, now + 300) is False,
          "过了 5 分钟才说 → 不算重复（不翻旧账）")
    check(stt.repeated_after_miss("设置展开的时候有大黑边", {"text": "", "at": 0}) is False,
          "上一次没丢过 → 不算重复")

    print("\n③ 主程序真的接上这个判定")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check("repeated_after_miss(text, self_voice_miss)" in src, "闭麦那段用了它")
    check('self_voice_miss.update(text=text, at=time.time())' in src, "丢掉的那句会记下来")
    check('self_voice_miss.update(text="", at=0.0)' in src, "当成你说的之后会清掉记录")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
