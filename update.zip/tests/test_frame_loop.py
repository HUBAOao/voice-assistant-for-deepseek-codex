# -*- coding: utf-8 -*-
"""验收：动画循环每一帧都跑得通（帧数在涨、不再报 _auto_low 的错）。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "frames-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def main() -> int:
    (S / "config.json").write_text(json.dumps(
        {"name": "帧测试", "overlay_bg_image": "", "overlay_alpha": 1.0}),
        encoding="utf-8")
    (S / "pos.json").write_text('{"x": 80, "y": 80}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.5, "text": "数一下画了多少帧",
         "ts": time.time(), "pid": os.getpid(), "bands": [0.3] * 12}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    for _ in range(260):
        o.root.update()
        time.sleep(0.004)
    frames, low, cost = o._frames, o._auto_low, o._frame_cost * 1000
    o.root.destroy()
    log = S / "exit.log"
    err = log.read_text(encoding="utf-8").strip() if log.exists() else ""
    print(f"画了 {frames} 帧；自动降级 = {low}；每帧 {cost:.1f}ms")
    print("错误日志：", err[:200] or "（空）")
    ok = frames > 50 and "AttributeError" not in err
    print("动画循环：", "✓ 正常" if ok else "✗ 有问题")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
