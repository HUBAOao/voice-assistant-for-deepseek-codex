# -*- coding: utf-8 -*-
"""验收应答语：写好几条就随机挑、带上你的称呼、写一条就照旧。"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    stt = load()
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    cfg = {"ack_text": "好的我这就做|好嘞|收到|来了|马上办|好的，收到",
           "user_name": "", "name_freq": "sometimes"}
    got = [stt.ack_phrase(cfg) for _ in range(200)]
    kinds = set(got)
    print("  200 次里挑出来的：", sorted(kinds))
    check(len(kinds) >= 4, f"随机挑了 {len(kinds)} 种（不是死板一条）")
    check(all(g in cfg["ack_text"].split("|") for g in kinds), "都在你写的这几条里")
    check(len(kinds) < 6 or True, "（有些条可能没抽到，正常）")

    print("\n② 只写一条：还是那一条")
    one = {**cfg, "ack_text": "好的我这就做"}
    check({stt.ack_phrase(one) for _ in range(20)} == {"好的我这就做"}, "一条就固定一条")

    print("\n③ 换行分隔也认；空着有兜底")
    multi = {**cfg, "ack_text": "好嘞\n收到\n来了"}
    got2 = {stt.ack_phrase(multi) for _ in range(60)}
    check(got2 <= {"好嘞", "收到", "来了"} and len(got2) >= 2, f"换行也切开了：{got2}")
    check(stt.ack_phrase({"ack_text": "  "}) == "我知道了", "空的时候有兜底")

    print("\n④ 带称呼：按频率偶尔跟上你的名字")
    named = {**cfg, "user_name": "老胡", "name_freq": "often"}
    got3 = [stt.ack_phrase(named) for _ in range(60)]
    with_name = [g for g in got3 if g.endswith("，老胡")]
    check(len(with_name) > 20, f"「经常」时 {len(with_name)}/60 次带了名字")
    off = {**cfg, "user_name": "老胡", "name_freq": "off"}
    check(all(not stt.ack_phrase(off).endswith("，老胡") for _ in range(30)),
          "「从不」时不带名字")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
