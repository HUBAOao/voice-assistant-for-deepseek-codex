# -*- coding: utf-8 -*-
"""验收：预设的导出 / 导入按钮真的能存文件、也能读回来（重名覆盖、坏文件不崩）。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "preset-io"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import tkinter.filedialog as fd  # noqa: E402

import overlay  # noqa: E402


def main() -> int:
    cfg_path = S / "config.json"
    cfg_path.write_text(json.dumps({
        "name": "预设测试", "overlay_bg_image": "",
        "presets": {"安静模式": {"volume": 20, "perf_mode": "eco"},
                    "轰炸模式": {"volume": 100, "anim_fps": 60}},
    }, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 70, "y": 70}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = cfg_path
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("基本")
    for _ in range(20):
        o.root.update()

    bad = 0
    out = S / "导出的预设.json"
    if out.exists():
        out.unlink()
    fd.asksaveasfilename = lambda **_kw: str(out)
    o.export_presets()
    for _ in range(10):
        o.root.update()
    if not out.exists():
        print("  ✗ 导出：没生成文件")
        bad += 1
    else:
        got = json.loads(out.read_text(encoding="utf-8"))
        names = sorted((got.get("presets") or {}))
        print(f"  ✓ 导出：{out.name} 里有 {names}")
        if names != ["安静模式", "轰炸模式"]:
            print("    ✗ 导出的预设名不对")
            bad += 1

    # 导入：一个覆盖同名、一个全新，外加一个坏文件
    mix = S / "别人给我的预设.json"
    mix.write_text(json.dumps({"presets": {
        "安静模式": {"volume": 5, "perf_mode": "eco"},
        "深夜模式": {"volume": 30},
    }}, ensure_ascii=False), encoding="utf-8")
    fd.askopenfilename = lambda **_kw: str(mix)
    o.import_presets()
    for _ in range(10):
        o.root.update()
    now = json.loads(cfg_path.read_text(encoding="utf-8"))["presets"]
    print(f"  ✓ 导入后共 {sorted(now)}")
    if sorted(now) != ["安静模式", "深夜模式", "轰炸模式"]:
        print("    ✗ 导入结果不对")
        bad += 1
    if now["安静模式"]["volume"] != 5:
        print("    ✗ 同名预设没有被覆盖")
        bad += 1
    if "轰炸模式" not in now:
        print("    ✗ 原有预设被弄丢了")
        bad += 1

    # 坏文件：不能崩、不能改配置
    junk = S / "不是预设.txt"
    junk.write_text("随便写点什么", encoding="utf-8")
    before = cfg_path.read_text(encoding="utf-8")
    fd.askopenfilename = lambda **_kw: str(junk)
    o.import_presets()
    for _ in range(10):
        o.root.update()
    if cfg_path.read_text(encoding="utf-8") != before:
        print("  ✗ 坏文件竟然改了配置")
        bad += 1
    else:
        print("  ✓ 坏文件：没崩，配置也没动")

    # 没有预设时点导出：只提示，不崩
    data = json.loads(cfg_path.read_text(encoding="utf-8"))
    data["presets"] = {}
    cfg_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    o.cfg = data
    fd.asksaveasfilename = lambda **_kw: (_ for _ in ()).throw(AssertionError("不该弹保存框"))
    o.export_presets()
    for _ in range(10):
        o.root.update()
    print("  ✓ 没有预设时点导出：只提示了一句")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
