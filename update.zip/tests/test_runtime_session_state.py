# -*- coding: utf-8 -*-
"""Voice-session mutable state is built outside the STT entrypoint."""
from __future__ import annotations

import ast
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_session_state import (  # noqa: E402
    create_runtime_session_state,
)
from voice_feature.talk_state import DictationState, TalkState  # noqa: E402


class Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    clock = Clock()
    config = {
        "stop_words": " 停一下, 安静 ",
        "followup_seconds": "6",
        "wave_spectrum": True,
    }
    fixed_now = datetime(2026, 10, 24, 9, 0, 0)
    state = create_runtime_session_state(
        config=config,
        mode="talk",
        wake_words=["大肥鱼"],
        wake_timeout=12,
        default_stop_words=["默认停止"],
        clock=clock,
        now=lambda: fixed_now,
    )
    check(state.stop_words == ["停一下", "安静"],
          "自定义停止词继续按原顺序解析")
    check(state.hint == "说「大肥鱼」唤醒",
          "唤醒提示保持原文案")
    check(state.sit["next"] == 4600.0,
          "久坐提醒以会话开始时刻向后一小时")
    check(state.hourly["last"] == "2026-10-24 09",
          "整点报时基线继续使用本地时间")
    check(state.music == {"on": True},
          "音浪状态继续从最新配置创建")
    check(isinstance(state.dictation, DictationState),
          "听写状态继续使用原状态机")
    check(isinstance(state.talk_state, TalkState)
          and state.talk_state.followup_seconds == 6.0,
          "连续对话窗口继续使用同一配置和类型")
    plain = create_runtime_session_state(
        config={},
        mode="plain",
        wake_words=[],
        wake_timeout=12,
        default_stop_words=["默认停止"],
        clock=clock,
        now=lambda: fixed_now,
    )
    check(plain.stop_words == ["默认停止"],
          "未配置停止词时继续使用历史默认集合")
    check(plain.hint == "",
          "非 talk 模式不显示唤醒提示")
    check(plain.self_speech is not state.self_speech
          and plain.mic_capture is not state.mic_capture,
          "每次装配持有独立的可变状态")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    main_source = ast.get_source_segment(source, main_node) or ""
    check(main_node.end_lineno - main_node.lineno + 1 < 700,
          "main() 已降到 700 行以内")
    check("create_session_state=create_runtime_session_state" in main_source
          and "entry.session_state.as_tuple()" in main_source,
          "main() 只向启动管线提交状态工厂并消费结果")
    check('dictation = _talk.DictationState()' not in main_source
          and 'talk_state = _talk.TalkState(' not in main_source,
          "听写和连续对话状态不再内联构造")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
