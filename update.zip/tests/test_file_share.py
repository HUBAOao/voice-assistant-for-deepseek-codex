# -*- coding: utf-8 -*-
"""验收「发文件」：电脑→手机（复制进分享目录、手机能下载）、手机→电脑（上传），
   以及防目录穿越、大小限制这些安全线。"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    fs = load("fs", APP / "file_share.py")
    src_file = Path.home() / "Desktop" / "语音助手测试文件.txt"
    payload = "这是测试用的文件，用来验证「发文件到手机」。" * 3
    src_file.write_text(payload, encoding="utf-8")

    print("① 电脑上的文件：按名字能找到、复制到分享目录")
    found = fs.find_file("测试文件")
    check(found is not None and found.name == src_file.name, f"找到了：{found.name if found else None}")
    dst = fs.add_file(found)
    check(dst is not None and dst.exists(), f"复制进分享目录：{dst.name if dst else None}")
    check(dst and dst.read_text(encoding="utf-8") == payload, "内容一模一样")
    check(src_file.exists(), "原文件还在（只复制、不搬走）")
    check(any(i["name"] == dst.name for i in fs.list_files()), "列表里能看到")

    print("\n② 安全线：不许用 ../ 或绝对路径偷别的文件")
    check(fs.file_path("../config.json") is None, "../config.json → 不认")
    check(fs.file_path("..\\config.json") is None, "..\\config.json → 不认")
    check(fs.file_path(str(APP / "config.json")) is None, "绝对路径 → 不认")
    check(fs.file_path(dst.name) is not None, "正常名字照样能取")

    print("\n③ 手机传上来的文件")
    up = fs.save_upload("测试上传.png", b"\x89PNG\r\n fake image")
    check(up is not None and up.exists(), f"存下来了：{up.name if up else None}")
    check(up and up.read_bytes().startswith(b"\x89PNG"), "字节没被动过")
    check(any(i["name"] == up.name for i in fs.list_uploads()), "上传列表里有")
    check(fs.save_upload("太大.bin", b"x" * 10) is not None, "小的正常存")

    print("\n④ 手机入口那几条路（都要令牌）")
    pl = load("pl", APP / "phone_link.py")
    link = pl.PhoneLink(on_command=lambda t: got.append(t) if False else None,
                        get_state=lambda: {}, get_log=lambda s: [], port=8795)
    got: list[str] = []
    link.on_command = got.append
    link.start()
    time.sleep(0.3)
    base = f"http://127.0.0.1:{link.port}"

    def req(path: str, key: str = "", data: bytes = None, headers: dict = None):
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        r = urllib.request.Request(url, data=data, headers=headers or {}, method="POST" if data else "GET")
        try:
            with urllib.request.urlopen(r, timeout=8) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    code, _ = req("/api/files")
    check(code == 401, f"没令牌列文件 → {code}")
    code, body = req("/api/files", link.token)
    data = json.loads(body)
    check(code == 200 and any(i["name"] == dst.name for i in data["items"]),
          f"有令牌能列出（{len(data.get('items', []))} 个）")
    code, blob = req("/file/" + urllib.parse.quote(dst.name), link.token)
    check(code == 200 and blob.decode("utf-8") == payload, f"能完整下载回来（{len(blob)} 字节）")
    code, _ = req("/file/..%2Fconfig.json", link.token)
    check(code == 404, f"用 ../ 下载被挡 → {code}")
    code, body = req("/api/upload?name=" + urllib.parse.quote("手机发的照片.jpg"),
                     link.token, data=b"JPEGDATA")
    ok = json.loads(body)
    check(code == 200 and ok.get("ok"), f"手机上传来能存（{ok.get('name')}）")

    print("\n⑤ 主程序里接上了「把 xxx 发到手机」")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check("import file_share" in src, "主程序引了它")
    check("file_share.find_file(want_file)" in src and "file_share.add_file(src)" in src,
          "说「把 xxx 发到手机」会找文件并复制进分享目录")
    check("发到手机" in src and "发给手机" in src, "几种说法都认")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("📁 文件" in page and "/api/upload" in page, "手机页有文件面板，也能反向传")

    link.stop()
    for p in (dst, up):
        try:
            p.unlink()
        except Exception:
            pass
    try:
        src_file.unlink()
    except Exception:
        pass
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
