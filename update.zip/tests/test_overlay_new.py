# -*- coding: utf-8 -*-
"""验收悬浮窗里新加的两样：对话日志小窗口、卸载入口；顺带看面板能不能滚。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path
from types import SimpleNamespace

import tkinter as tk
from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "overlay-new"
S.mkdir(parents=True, exist_ok=True)
SHOT_LOG = ROOT / "outputs" / "对话日志.png"
SHOT_UNINSTALL = ROOT / "outputs" / "悬浮窗内卸载.png"

sys.path.insert(0, str(APP))
import overlay  # noqa: E402

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMI(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find_window(title: str) -> int:
    found = []
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _l):
        if not u32.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(hwnd, buf, 256)
        if buf.value == title:
            found.append(hwnd)
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return found[0] if found else 0


def grab(hwnd: int, out: Path) -> tuple[int, int]:
    rect = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMI()
    hdr.biSize = ctypes.sizeof(BMI)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount = 1, 32
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB").save(out)
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return w, h


def tree(widget, out=None):
    out = [] if out is None else out
    for child in widget.winfo_children():
        out.append(child)
        tree(child, out)
    return out


def by_text(root, prefix: str, cls=tk.Label):
    for w in tree(root):
        if isinstance(w, cls):
            try:
                if str(w.cget("text")).startswith(prefix):
                    return w
            except Exception:
                pass
    return None


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    (S / "config.json").write_text(json.dumps(
        {"name": "新功能测试", "overlay_bg_image": "", "overlay_alpha": 1.0},
        ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 90, "y": 90}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    log_file = S / "syslog.md"
    rows = []
    for i in range(60):
        rows.append(f"2026-10-07 04:{i % 60:02d}:00 [声] 声纹相似度 0.5{i % 9}")
        rows.append(f"2026-10-07 04:{i % 60:02d}:01 [听] 这是我说过的第{i}句话")
        rows.append(f"2026-10-07 04:{i % 60:02d}:02 [发] ChatGPT：这是我说过的第{i}句话")
        rows.append(f"2026-10-07 04:{i % 60:02d}:03 [念] 好的我这就做")
    log_file.write_text("\n".join(rows) + "\n", encoding="utf-8")

    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.SYSLOG_FILE = log_file
    notes = []
    overlay.note = lambda t: notes.append(t)

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("功能")
    for _ in range(60):
        o.root.update()
        time.sleep(0.01)

    print("① 面板滚轮")
    bound = sum(1 for w in tree(o.stage_inner) if w.bind("<MouseWheel>"))
    check(bound > 20, f"滚轮绑到了 {bound} 个控件上")
    region = o.stage_canvas.bbox("all")
    need = (region[3] - region[1]) if region else 0
    have = o.stage_canvas.winfo_height()
    print(f"   （内容 {need}px / 可视 {have}px）")
    if need > have:
        before = o.stage_canvas.yview()[0]
        o.on_panel_wheel(SimpleNamespace(delta=-120))
        o.root.update()
        check(o.stage_canvas.yview()[0] > before, "往下滚有效")
        o.stage_canvas.yview_moveto(1.0)
        o.root.update()
        check(o.stage_canvas.yview()[1] > 0.99, "能滚到底，最后一行看得见")
        o.stage_canvas.yview_moveto(0.0)
        o.root.update()
    else:
        check(o.on_panel_wheel(SimpleNamespace(delta=-120)) is None,
              "内容装得下时不抢滚轮")

    print("② 卸载入口")
    btn = by_text(o.stage_inner, "卸载语音助手")
    check(btn is not None, "「功能」页里有卸载按钮")
    cmd_keep = o.uninstall_command(False)
    cmd_full = o.uninstall_command(True)
    check(cmd_keep[:2] == ["cmd", "/c"] and cmd_keep[-1] == "--yes",
          f"保留记录：{Path(cmd_keep[2]).name} --yes")
    check(cmd_full[-2:] == ["--yes", "--full"],
          f"彻底删除：{Path(cmd_full[2]).name} --yes --full")

    spawned = []
    real_popen = overlay.subprocess.Popen
    overlay.subprocess.Popen = lambda cmd, **kw: spawned.append((cmd, kw)) or None
    if btn is not None:
        btn.event_generate("<Button-1>", x=5, y=5)
        for _ in range(40):
            o.root.update()
            time.sleep(0.02)
        hwnd = find_window("卸载语音助手")
        check(hwnd != 0, "点按钮弹出了确认框")
        if hwnd:
            time.sleep(0.6)
            w, h = grab(hwnd, SHOT_UNINSTALL)
            print(f"   → 截图 {SHOT_UNINSTALL}（{w}x{h}）")
        dialog = next((w for w in tree(o.root) if isinstance(w, tk.Toplevel)
                       and str(w.title()) == "卸载语音助手"), None)
        check(dialog is not None, "确认框的结构对")
        if dialog is not None:
            full_btn = by_text(dialog, "②")
            keep_btn = by_text(dialog, "①")
            check(full_btn is not None and keep_btn is not None, "确认框里有 ① 和 ②")
            if full_btn is not None:
                full_btn.event_generate("<Button-1>", x=4, y=4)
                for _ in range(10):
                    o.root.update()
                check(not spawned, "第一下点「彻底删除」不动手")
                check(str(full_btn.cget("text")).startswith("真的要全删"),
                      "第一下之后按钮变成「真的要全删？再点一次」")
                full_btn.event_generate("<Button-1>", x=4, y=4)
                for _ in range(10):
                    o.root.update()
                check(len(spawned) == 1 and spawned[0][0][-1] == "--full",
                      "第二下才真去调卸载程序（带 --full）")
                check(bool(spawned) and spawned[0][1].get("creationflags") == 0x10,
                      "卸载程序另开窗口跑（CREATE_NEW_CONSOLE）")
    overlay.subprocess.Popen = real_popen

    print("③ 对话日志小窗口")
    view = by_text(o.stage_inner, "查看")
    check(view is not None, "「系统日志」那一行有「查看」按钮")
    o.open_log_window()
    for _ in range(40):
        o.root.update()
        time.sleep(0.02)
    check(getattr(o, "log_text", None) is not None, "日志窗口开出来了")
    talk_text = o.log_text.get("1.0", "end")
    check("这是我说过的第59句话" in talk_text, "看得到我说的话")
    check("声纹相似度" not in talk_text, "「只看对话」把声纹那类刷掉了")
    o.set_log_filter(False)
    for _ in range(10):
        o.root.update()
    check("声纹相似度" in o.log_text.get("1.0", "end"), "切到「全都看」就把它们放回来")
    o.set_log_filter(True)
    for _ in range(10):
        o.root.update()
    o.log_search.set("第7句话")
    for _ in range(10):
        o.root.update()
    filtered = o.log_text.get("1.0", "end")
    check("第7句话" in filtered and "第59句话" not in filtered, "搜索框能筛")
    o.log_search.set("")
    for _ in range(10):
        o.root.update()
    before_len = len(o.log_text.get("1.0", "end"))
    with log_file.open("a", encoding="utf-8") as fh:
        fh.write("2026-10-07 04:59:59 [听] 新加的一句话\n")
    o._log_mtime = None
    o._log_tick()
    for _ in range(20):
        o.root.update()
    after = o.log_text.get("1.0", "end")
    check("新加的一句话" in after, "新的一行会自己刷出来（不用手点）")
    time.sleep(0.4)
    hwnd = find_window("对话日志")
    if hwnd:
        w, h = grab(hwnd, SHOT_LOG)
        print(f"   → 截图 {SHOT_LOG}（{w}x{h}）")
    check(hwnd != 0, "日志窗口能被系统看见（是个真窗口）")
    o.close_log_window()
    for _ in range(10):
        o.root.update()
    check(find_window("对话日志") == 0, "关掉之后窗口真的没了")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
