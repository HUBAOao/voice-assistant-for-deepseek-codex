# -*- coding: utf-8 -*-
"""Gate wiring keeps callback plumbing outside the STT entrypoint."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_gate_wiring import (  # noqa: E402
    RuntimeGateWiringDependencies,
    assemble_runtime_gate_wiring,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls = []
    status = object()
    beep = object()
    extract_word = object()
    syslog = object()
    emit = object()
    sleep = lambda seconds: calls.append(("sleep", seconds))
    deps = RuntimeGateWiringDependencies(
        speaking_now=object(),
        shut_up=object(),
        stop_words=("停",),
        is_stop_word=object(),
        last_unsent={},
        pick_send_target=object(),
        send=object(),
        busy={},
        status=status,
        speak=object(),
        syslog=syslog,
        emit=emit,
        mute={},
        mute_command=object(),
        dispatch_mute=object(),
        self_speech={},
        self_voice_miss={},
        self_spoken_text=object(),
        recent_spoken=object(),
        sounds_like=object(),
        repeated_after_miss=object(),
        extract_word=extract_word,
        wake_words=["大肥鱼"],
        wake_level={"fuzzy": True, "leading": True},
        dictation=object(),
        is_standalone_command=object(),
        dispatch_dictation=object(),
        beep=beep,
        type_text=object(),
        syslog_file=ROOT / "work" / "test-syslog.md",
        cancel_words=["取消"],
        listen_timeout=12.0,
        talk_state=object(),
        looks_like_wake=object(),
        cancel_hit=object(),
        wake_voice_ok=object(),
        award=object(),
        arm_followup=lambda: calls.append("followup"),
        once=True,
        sleep=sleep,
    )
    runtime = assemble_runtime_gate_wiring(deps)
    command = runtime.command_gate.deps
    wake = runtime.wake_gate.deps
    check(command.status is status and wake.status is status,
          "命令与唤醒闸门共享同一运行时状态对象")
    check(command.beep is beep and wake.beep is beep,
          "提示音回调由两座闸门原样复用")
    check(command.extract_word is extract_word
          and wake.extract_word is extract_word,
          "唤醒词提取继续使用同一个实现")
    check(command.syslog is syslog and wake.syslog is syslog
          and command.emit is emit and wake.emit is emit,
          "日志与输出回调保持同一来源")
    check(runtime.finish_structured_action() is True,
          "结构化动作结束仍返回 --once 状态")
    check(calls == ["followup", ("sleep", 0.4)],
          "先恢复连续对话，再等待原有 0.4 秒")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    main_source = ast.get_source_segment(source, main_node) or ""
    for dependency in (
        "RuntimeCommandGateDependencies(",
        "RuntimeWakeGateDependencies(",
        "RuntimeGateAssemblyDependencies(",
    ):
        check(dependency not in main_source,
              f"main() 不再直接构造 {dependency.rstrip('(')}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
