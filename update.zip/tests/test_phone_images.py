# -*- coding: utf-8 -*-
"""验收手机图片链路：本地图片、上传回读、附件提交、附件补文字。"""
from __future__ import annotations
from pathlib import Path

import json
import os
import pathlib
import tempfile
import time
import urllib.parse
import urllib.request

import sys

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import phone_link  # noqa: E402


PNG = (
    b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
    b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\rIDATx\x9cc\xf8\xff"
    b"\xff?\x00\x05\xfe\x02\xfeA\x81\x1f\x03\x00\x00\x00\x00IEND\xaeB`\x82"
)


def request(url: str, data: bytes | None = None, headers: dict | None = None):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    return urllib.request.urlopen(req, timeout=8)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = []
    name = ""
    events = {"images": [], "submit": 0, "media": []}
    link = phone_link.PhoneLink(
        on_command=lambda _text: None,
        get_state=lambda: {"online": True},
        get_log=lambda _since=0, _kw="": [],
        port=8898,
    )
    link.on_image = events["images"].append
    link.on_submit = lambda: events.__setitem__("submit", events["submit"] + 1)
    link.on_media_command = events["media"].append
    if not link.start():
        print("服务未启动")
        return 1
    base = f"http://127.0.0.1:8898"
    q = "?k=" + urllib.parse.quote(link.token)
    try:
        fd, tmp_name = tempfile.mkstemp(suffix=".png", prefix="va-image-")
        os.close(fd)
        tmp = pathlib.Path(tmp_name)
        tmp.write_bytes(PNG)
        try:
            with request(base + "/api/image" + q + "&path=" + urllib.parse.quote(str(tmp))) as r:
                got = r.read()
            print("本地图片读取", r.status, len(got), "PASS" if got == PNG else "FAIL")
            if got != PNG:
                bad.append("local-image")
        finally:
            tmp.unlink(missing_ok=True)

        name = f"phone-test-{int(time.time())}.png"
        upload_path = "/api/upload" + q + "&name=" + urllib.parse.quote(name) + "&paste=1"
        with request(base + upload_path, data=PNG,
                     headers={"Content-Type": "application/octet-stream"}) as r:
            uploaded = json.loads(r.read())
        time.sleep(.05)
        with request(base + "/uploaded/" + urllib.parse.quote(uploaded["name"]) + q) as r:
            got = r.read()
        print("上传回读", uploaded.get("ok"), r.status, len(got),
              "PASS" if got == PNG else "FAIL")
        if got != PNG or not events["images"]:
            bad.append("upload-roundtrip")

        with request(base + "/api/submit" + q, data=b"{}",
                     headers={"Content-Type": "application/json"}) as r:
            ok_submit = json.loads(r.read()).get("ok")
        body = json.dumps({"text": "看看这张图"}, ensure_ascii=False).encode()
        with request(base + "/api/send-media" + q, data=body,
                     headers={"Content-Type": "application/json"}) as r:
            ok_media = json.loads(r.read()).get("ok")
        time.sleep(.05)
        print("附件提交", ok_submit, events["submit"], "PASS"
              if ok_submit and events["submit"] == 1 else "FAIL")
        print("附件补文字", ok_media, events["media"], "PASS"
              if ok_media and events["media"] == ["看看这张图"] else "FAIL")
        if not ok_submit or events["submit"] != 1:
            bad.append("submit")
        if not ok_media or events["media"] != ["看看这张图"]:
            bad.append("media-command")
    finally:
        link.stop()
        try:
            p = APP / "手机上传" / name
            if name and p.is_file():
                p.unlink()
        except Exception:
            pass
    print("失败项", bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
