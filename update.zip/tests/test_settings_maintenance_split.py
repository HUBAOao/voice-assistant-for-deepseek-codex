# -*- coding: utf-8 -*-
"""Backup, memory and uninstall business no longer live in overlay.py."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import settings_backup_mixin as backup  # noqa: E402
from overlay_feature import settings_memory_mixin as memory  # noqa: E402
from overlay_feature.settings_backup_mixin import (  # noqa: E402
    OverlaySettingsBackupMixin,
)
from overlay_feature.settings_maintenance_mixin import (  # noqa: E402
    OverlaySettingsMaintenanceMixin,
)
from overlay_feature.settings_data_panel_mixin import (  # noqa: E402
    OverlaySettingsDataPanelMixin,
)
from overlay_feature.settings_memory_panel_mixin import (  # noqa: E402
    OverlaySettingsMemoryPanelMixin,
)
from overlay_feature.settings_memory_mixin import (  # noqa: E402
    OverlaySettingsMemoryMixin,
)
from overlay_feature.settings_memory_viewer_mixin import (  # noqa: E402
    OverlaySettingsMemoryViewerMixin,
)
from overlay_feature.settings_uninstall_panel_mixin import (  # noqa: E402
    OverlaySettingsUninstallPanelMixin,
)


class FakeLabel:
    def __init__(self) -> None:
        self.text = ""

    def config(self, **kwargs) -> None:
        self.text = kwargs.get("text", self.text)


class FakeMaintenance(
    OverlaySettingsBackupMixin,
    OverlaySettingsMemoryMixin,
    OverlaySettingsMaintenanceMixin,
):
    def __init__(self, calls) -> None:
        self.calls = calls
        self.backup_label = FakeLabel()
        self.root = type(
            "Root",
            (),
            {"after": staticmethod(lambda delay, action: calls.append(
                ("after", delay, action)))} ,
        )()

    def flash(self, text: str, seconds: float = 0) -> None:
        self.calls.append(("flash", text, seconds))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    module = (APP / "overlay_feature" / "settings_maintenance_mixin.py").read_text(
        encoding="utf-8"
    )
    backup_methods = (
        "do_export",
        "backup_dir",
        "backup_summary",
        "do_diagnose",
        "refresh_backup_label",
        "open_backup_dir",
    )
    memory_methods = (
        "memory_summary",
        "do_memory_archive",
        "open_memory_archive",
        "load_memory_text",
    )
    backup_source = (APP / "overlay_feature" /
                     "settings_backup_mixin.py").read_text(encoding="utf-8")
    memory_source = (APP / "overlay_feature" /
                     "settings_memory_mixin.py").read_text(encoding="utf-8")
    memory_viewer_source = (
        APP / "overlay_feature" / "settings_memory_viewer_mixin.py"
    ).read_text(encoding="utf-8")
    memory_panel_source = (
        APP / "overlay_feature" / "settings_memory_panel_mixin.py"
    ).read_text(encoding="utf-8")
    data_panel_source = (
        APP / "overlay_feature" / "settings_data_panel_mixin.py"
    ).read_text(encoding="utf-8")
    uninstall_panel_source = (
        APP / "overlay_feature" / "settings_uninstall_panel_mixin.py"
    ).read_text(encoding="utf-8")
    for name in backup_methods:
        check(f"def {name}(" not in overlay, f"overlay.py 不再内联 {name}")
        check(f"def {name}(" in backup_source,
              f"备份业务模块提供 {name}")
    for name in memory_methods:
        check(f"def {name}(" not in overlay, f"overlay.py 不再内联 {name}")
    for name in ("memory_summary", "do_memory_archive"):
        check(f"def {name}(" in memory_source,
              f"记忆操作模块提供 {name}")
    for name in ("open_memory_archive", "load_memory_text"):
        check(f"def {name}(" in memory_viewer_source,
              f"记忆查看器模块提供 {name}")
    check(issubclass(OverlaySettingsMemoryMixin,
                     OverlaySettingsMemoryViewerMixin),
          "历史 OverlaySettingsMemoryMixin 保留查看器兼容入口")
    check(issubclass(OverlaySettingsMaintenanceMixin,
                     OverlaySettingsMemoryPanelMixin)
          and issubclass(OverlaySettingsMaintenanceMixin,
                         OverlaySettingsDataPanelMixin)
          and issubclass(OverlaySettingsMaintenanceMixin,
                         OverlaySettingsUninstallPanelMixin),
          "历史维护设置类保留三个面板兼容组合")
    for method, source, text in (
        ("build_memory_panel", memory_panel_source, "记忆摘要与入口"),
        ("build_data_panel", data_panel_source, "数据、诊断与日志入口"),
        ("build_uninstall_panel", uninstall_panel_source, "卸载说明入口"),
    ):
        check(f"def {method}(" in source,
              f"独立模块提供{text}")
    for name in ("build_memory_panel", "build_data_panel",
                 "build_uninstall_panel"):
        check(f"def {name}(" not in module,
              f"维护兼容类不再内联 {name}")
    check(
        module.index("self.build_memory_panel(parent)")
        < module.index("self.build_data_panel(parent)")
        < module.index("self.build_uninstall_panel(parent)"),
        "维护页继续按记忆、数据、卸载的旧顺序组装",
    )
    uninstall_source = (
        APP / "overlay_feature" / "settings_uninstall_mixin.py"
    ).read_text(encoding="utf-8")
    for name in ("uninstall_command", "ask_uninstall"):
        check(f"def {name}(" not in overlay
              and f"def {name}(" in uninstall_source,
              f"卸载入口已迁入独立模块：{name}")
    check("def ask_clear(" in overlay,
          "语音清空入口仍保留在原兼容位置")

    with tempfile.TemporaryDirectory(prefix="findeck_maintenance_") as raw:
        root = Path(raw)
        export = root / "导出"
        export.mkdir()
        (export / "语音助手诊断-20261023-1842.zip").write_bytes(b"x" * 2048)
        (export / "语音助手数据-20261023-1840.zip").write_bytes(b"x" * 1024)
        old_here = backup.HERE
        old_hide = backup._window_control.hide_path
        old_startfile = backup.os.startfile
        old_send = backup.send_command
        backup.HERE = root
        backup._window_control.hide_path = lambda _path: None
        opened = []
        backup.os.startfile = lambda path: opened.append(path)
        backup.send_command = lambda action: calls.append(("command", action))
        try:
            calls = []
            fake = FakeMaintenance(calls)
            summary = fake.backup_summary()
            check("诊断 10/23 18:42" in summary
                  and "数据 10/23 18:40" in summary,
                  "导出与诊断包仍按时间和大小汇总")
            check(fake.backup_dir() == export, "备份目录仍是原「导出」路径")

            fake.open_backup_dir()
            check(opened == [str(export)], "打开备份目录仍指向同一个导出位置")
            fake.do_export()
            check(("command", "export") in calls
                  and any(item[0] == "after" for item in calls
                          if isinstance(item, tuple)),
                  "数据导出仍发送原命令并延迟刷新摘要")
        finally:
            backup.HERE = old_here
            backup._window_control.hide_path = old_hide
            backup.os.startfile = old_startfile
            backup.send_command = old_send

        old_summary = memory.memory_archive.summary
        memory.memory_archive.summary = lambda: {
            "generated_at": "2026-10-23 18:40",
            "stats": {"threads": 7, "user_messages": 42},
        }
        try:
            fake = FakeMaintenance([])
            text = fake.memory_summary()
            check("7 个会话" in text and "42 条你的话" in text,
                  "集中记忆摘要继续使用真实归档统计")
        finally:
            memory.memory_archive.summary = old_summary

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
