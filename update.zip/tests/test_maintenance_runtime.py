# -*- coding: utf-8 -*-
"""Maintenance actions remain testable without importing the STT runtime."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.maintenance_runtime import (  # noqa: E402
    MaintenanceRuntime,
    MaintenanceRuntimeDependencies,
)


class Status:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str]] = []

    def set(self, state: str, text: str = "") -> None:
        self.calls.append((state, text))


class Transcriber:
    model = object()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck-maintenance-") as raw:
        package = Path(raw) / "update"
        package.mkdir()
        spoken: list[str] = []
        logged: list[tuple[str, str]] = []
        copied: list[str] = []
        calls: list[tuple] = []
        status = Status()
        private: dict = {}
        last_sent = {"text": "上一条", "at": 100.0}
        now = [110.0]

        deps = MaintenanceRuntimeDependencies(
            status=status,
            speak=spoken.append,
            syslog=lambda tag, text: logged.append((tag, text)),
            config={"overlay_enabled": True},
            private=private,
            last_sent=last_sent,
            transcriber=Transcriber(),
            target=None,
            overlay_running=False,
            overlay_disabled=True,
            current_target_hwnd=lambda: 0,
            query_device=lambda _device: {"max_input_channels": 1},
            device=0,
            find_window=lambda _name: (0, ""),
            clipboard_text=lambda: "保留",
            copy_to_clipboard=lambda text: copied.append(text) or True,
            paste_clipboard=lambda *args, **kwargs: calls.append(
                ("paste_clipboard", args, kwargs)
            ) or True,
            paste_into=lambda *args, **kwargs: calls.append(
                ("paste_into", args, kwargs)
            ) or True,
            focus_window=lambda hwnd: calls.append(("focus", hwnd)),
            send_ctrl_z=lambda: calls.append(("ctrl-z",)),
            export_data=lambda: Path("备份.zip"),
            import_data=lambda: (3, "导入了 3 项"),
            diag_pack=lambda: Path("诊断.zip"),
            newer_package=lambda: (package, "9.9"),
            apply_update=lambda path: calls.append(("update", path)) or 7,
            clock=lambda: now[0],
            sleep=lambda _seconds: None,
            emit=lambda text: calls.append(("emit", text)),
        )
        runtime = MaintenanceRuntime(deps)

        check(runtime.self_check() == [], "自检成功时不误报")
        check(copied == ["语音助手自检", "保留"],
              "自检写剪贴板后恢复用户原内容")
        check(logged[-1][1].startswith("自检通过"),
              "自检成功仍写入系统日志")

        deps = deps.__class__(**{**deps.__dict__,
            "overlay_disabled": False,
            "query_device": lambda _device: {"max_input_channels": 0},
        })
        runtime = MaintenanceRuntime(deps)
        problems = runtime.self_check(False)
        check("那个麦克风现在没有输入通道" in problems
              and "悬浮窗没起来" in problems,
              "输入通道和悬浮窗异常会进入自检结果")

        runtime.do_export()
        runtime.do_import()
        runtime.do_diagnose()
        runtime.do_update()
        check(private["update_pkg"] == str(package), "检查更新保留待套用目录")
        runtime.apply_update_now()
        check(("update", package) in calls and "套用了 7 个文件" in spoken[-1],
              "开始更新使用已检查的目录并报告文件数")

        last_sent.update(text="上一条", at=100.0)
        runtime.undo_last()
        paste_calls = [call for call in calls if call[0] == "paste_clipboard"]
        check(bool(paste_calls)
              and paste_calls[-1][1] == (0,)
              and paste_calls[-1][2]["press_enter"] is False
              and paste_calls[-1][2]["clear_first"] is True,
              "无目标窗口时仍把上一条放回剪贴板")
        check(status.calls == [], "撤回动作不伪造窗口输入状态")

        runtime.type_into_focused("听写内容")
        check(copied[-1] == "听写内容"
              and status.calls[-1] == ("sent", "📝 听写内容"),
              "找不到光标时听写内容退回剪贴板")

        now[0] = 500.0
        last_sent.update(at=0.0)
        before = len(spoken)
        runtime.undo_last()
        check(len(spoken) == before + 1 and spoken[-1] == "没有可以撤回的内容",
              "超过三分钟的上一句不再撤回")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
