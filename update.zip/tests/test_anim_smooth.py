# -*- coding: utf-8 -*-
"""量"展开/收起"动画的顺滑度：240ms 的动画里一共画了多少个不同的尺寸。

步数越多越顺（60 帧 ≈ 14~15 步，30 帧只有 7 步左右，肉眼就能看出台阶）。
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "anim-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def setup() -> "overlay.Overlay":
    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg["auto_tune"] = False
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 70, "y": 70}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.6, "text": "展开收起顺不顺",
         "ts": time.time(), "pid": os.getpid(), "bands": [0.6] * 12}),
        encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda _t: None
    o = overlay.Overlay()
    o.alpha_override = 1.0
    return o


def watch(o, start, seconds=0.8) -> list:
    """记录这段动画里每一帧画出来的高度（钩在 anim 上，比轮询准）。"""
    heights = []
    stamps = []
    real = o.anim

    def probe() -> None:
        real()
        heights.append(int(o.cur_h))
        stamps.append(time.perf_counter())

    o.anim = probe
    t0 = time.perf_counter()
    start()
    end = time.time() + seconds
    while time.time() < end:
        o.root.update()
        time.sleep(0.003)
    o.anim = real
    duration = 0.0                     # 从开始动到尺寸到位，一共花了多少毫秒
    for i, h in enumerate(heights):
        if h != heights[0]:
            duration = (stamps[i] - t0) * 1000
    steps = []
    # 去重：同一个高度连画两次只算一步
    for h in heights:
        if not steps or steps[-1] != h:
            steps.append(h)
    return steps, duration


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0
    o = setup()
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)

    # 先展开一次把设置面板建出来（第一次建面板要 0.6~1 秒，那是加载不是动画），
    # 不然量出来的"动画时长"里混着面板构建的时间。
    o.set_expanded(True)
    for _ in range(90):
        o.root.update()
        time.sleep(0.01)
    o.set_expanded(False)
    for _ in range(60):
        o.root.update()
        time.sleep(0.01)

    up, up_ms = watch(o, lambda: o.set_expanded(True))
    for _ in range(60):
        o.root.update()
        time.sleep(0.005)
    down, down_ms = watch(o, lambda: o.set_expanded(False))
    o.root.destroy()

    biggest = 0
    for i in range(1, len(up)):
        biggest = max(biggest, abs(up[i] - up[i - 1]))
    print(f"展开：{len(up)} 个台阶，{up_ms:.0f}ms，高度 {up[0]} → {up[-1]}，"
          f"最大一步 {biggest}px")
    print(f"收起：{len(down)} 个台阶，{down_ms:.0f}ms，高度 {down[0]} → {down[-1]}")
    # 绝对时长受机器忙不忙影响很大，这里只当参考；判定看台阶数和最大步长
    ok = 6 <= len(up) <= 10 and 6 <= len(down) <= 10 and biggest <= 140
    print("顺滑度：", "✓ 够顺（8 步均匀过渡）" if ok else "✗ 台阶数不对或步子太大")
    if not ok:
        bad += 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
