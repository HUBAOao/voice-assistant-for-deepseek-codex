# -*- coding: utf-8 -*-
"""Basic settings composition is isolated from the settings shell and actions."""
from __future__ import annotations

import sys
import json
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_basic_mixin import (  # noqa: E402
    OverlaySettingsBasicMixin,
)
from overlay_feature.settings_wake_mixin import (  # noqa: E402
    OverlaySettingsWakeMixin,
)
from overlay_feature.settings_caption_mixin import (  # noqa: E402
    OverlaySettingsCaptionMixin,
)
from overlay_feature.settings_reminders_mixin import (  # noqa: E402
    OverlaySettingsRemindersMixin,
)


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Chip:
        def __init__(self) -> None:
            self.options = None

        def config(self, **options) -> None:
            self.options = options

    class Label:
        def __init__(self) -> None:
            self.options = None

        def config(self, **options) -> None:
            self.options = options

    class Probe(
        OverlaySettingsBasicMixin,
        OverlaySettingsWakeMixin,
        OverlaySettingsCaptionMixin,
    ):
        def __init__(self) -> None:
            self.cfg = {"wake_level": "标准"}
            self.button_color = "#00aa88"
            self.level_chips = {"标准": Chip(), "宽松": Chip()}
            self.level_info = Label()

    probe = Probe()
    check(probe.custom_levels() == {},
          "唤醒档位从配置读取且返回独立字典")
    probe.refresh_level_colors()
    check(probe.level_chips["标准"].options["bg"] == "#00aa88"
          and probe.level_chips["宽松"].options["bg"] == "#24242a",
          "当前唤醒档位保留主题色高亮")
    probe.update_level_info("测试结果")
    check(probe.level_info.options == {"text": "测试结果", "fg": "#7f7f8a"},
          "唤醒自检结果仍写回同一条说明控件")

    basic = (APP / "overlay_feature" / "settings_basic_mixin.py").read_text(
        encoding="utf-8"
    )
    shell = (APP / "overlay_feature" / "settings_mixin.py").read_text(
        encoding="utf-8"
    )
    shell_builder = (
        APP / "overlay_feature" / "settings_shell_mixin.py"
    ).read_text(encoding="utf-8")
    wake = (APP / "overlay_feature" / "settings_wake_mixin.py").read_text(
        encoding="utf-8"
    )
    wake_levels_source = (
        APP / "overlay_feature" / "settings_wake_levels_mixin.py"
    ).read_text(encoding="utf-8")
    wake_test_source = (
        APP / "overlay_feature" / "settings_wake_test_mixin.py"
    ).read_text(encoding="utf-8")
    identity = (
        APP / "overlay_feature" / "settings_identity_mixin.py"
    ).read_text(encoding="utf-8")
    response = (
        APP / "overlay_feature" / "settings_response_mixin.py"
    ).read_text(encoding="utf-8")
    caption = (APP / "overlay_feature" / "settings_caption_mixin.py").read_text(
        encoding="utf-8"
    )
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("def build_basic(" in basic,
          "基本页保留历史 build_basic 组合入口")
    check("def build_identity(" in identity
          and "def build_response(" in response
          and "self.build_identity(parent)" in basic
          and "self.build_response(parent)" in basic,
          "身份、问候、预设与应答语由两个独立边界组合")
    check("self.entry_ack =" not in basic
          and "self.entry_wake =" not in basic,
          "基本页本身不再内联身份或应答控件")
    for marker in ("def build_wake_level(", "def refresh_level_chips("):
        check(marker in wake_levels_source
              and marker not in wake
              and marker not in basic
              and marker not in shell,
              f"唤醒档位业务 {marker} 已迁入独立边界")
    check("def run_wake_test(" in wake_test_source
          and "def poll_wake_test(" in wake_test_source
          and "def poll_wake_test(" not in wake_levels_source
          and "def poll_wake_test(" not in basic
          and "def poll_wake_test(" not in shell,
          "唤醒自检结果回读与档位渲染分开")
    from overlay_feature.settings_wake_levels_mixin import (  # noqa: E402
        OverlaySettingsWakeLevelsMixin,
    )
    from overlay_feature.settings_wake_test_mixin import (  # noqa: E402
        OverlaySettingsWakeTestMixin,
    )
    check(issubclass(OverlaySettingsWakeMixin, OverlaySettingsWakeLevelsMixin)
          and issubclass(OverlaySettingsWakeMixin, OverlaySettingsWakeTestMixin),
          "历史唤醒类继续组合档位与自检两个业务边界")

    import overlay_feature.settings_wake_test_mixin as wake_test_module

    class WakeProbe(OverlaySettingsWakeTestMixin):
        def __init__(self) -> None:
            self.updates = []
            self.flashes = []

        def update_level_info(self, text=None, color="#7f7f8a") -> None:
            self.updates.append((text, color))

        def flash(self, text, _seconds) -> None:
            self.flashes.append(text)

    sent = []
    original_send = wake_test_module.send_command
    original_file = wake_test_module.WAKE_TEST_FILE
    try:
        wake_test_module.send_command = sent.append
        with tempfile.TemporaryDirectory() as tmp:
            wake_file = Path(tmp) / "wake_test.json"
            wake_test_module.WAKE_TEST_FILE = wake_file
            probe = WakeProbe()
            probe.run_wake_test()
            check(sent == ["wake-test"]
                  and probe.updates[0][1] == "#c9c9d6",
                  "唤醒自检动作仍发出原悬浮窗命令并显示进行中")
            wake_file.write_text(json.dumps({
                "ts": time.time(),
                "summary": "自检通过",
            }, ensure_ascii=False), encoding="utf-8")
            probe.poll_wake_test()
            check(probe.wake_test_result == "自检通过"
                  and "自检通过" in probe.flashes,
                  "自检结果仍从原文件回读并提示")
    finally:
        wake_test_module.send_command = original_send
        wake_test_module.WAKE_TEST_FILE = original_file
    for marker in ("def make_big_caption(", "def sync_big_caption("):
        check(marker in caption and marker not in basic and marker not in shell,
              f"大字幕业务 {marker} 已迁入独立边界")
    check("OverlaySettingsBasicMixin" in overlay
          and "OverlaySettingsWakeMixin" in overlay
          and "OverlaySettingsCaptionMixin" in overlay
          and "self.build_basic(self.tab_frames[\"基本\"])" in shell_builder,
          "设置总页仍通过一次 build_basic 调用组装三类业务")
    check("def save_settings(self)" in (
        APP / "overlay_feature" / "settings_persistence_mixin.py"
    ).read_text(encoding="utf-8"),
          "配置保存交互仍留在独立动作边界")
    reminders = (APP / "overlay_feature" / "settings_reminders_mixin.py").read_text(
        encoding="utf-8"
    )
    features = (APP / "overlay_feature" / "settings_features_mixin.py").read_text(
        encoding="utf-8"
    )
    check(OverlaySettingsRemindersMixin.__name__ in overlay
          and "def build_reminders(" in reminders,
          "提醒、快捷指令从功能页迁入独立业务边界")
    check("self.build_reminders(parent)" in features
          and "self.sw_reminder =" not in features,
          "功能页只组合提醒业务，不再内联其控件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
