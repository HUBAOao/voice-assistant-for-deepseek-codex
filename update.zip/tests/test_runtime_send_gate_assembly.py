# -*- coding: utf-8 -*-
"""Target selection and the final voice gate remain outside ``main()``."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_send_gate_assembly import (  # noqa: E402
    RuntimeSendGateAssembly,
    RuntimeSendGateDependencies,
)


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state, **kwargs) -> None:
        self.calls.append((state, kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    status = Status()
    emitted = []
    logged = []
    switched = []
    phone = {"title": "手机会话", "id": "thread-9"}
    phone_calls = []
    current_name = ["旧的会话"]
    deps = RuntimeSendGateDependencies(
        pick_send_target=lambda: (11, "桌面窗口"),
        phone_window=lambda: phone_calls.append(True) or (22, "Codex 窗口"),
        phone_target=phone,
        current_thread_name=lambda: current_name[0],
        switch_thread=lambda title, thread_id: switched.append(
            (title, thread_id)
        ),
        config={"voiceprint_gate": True, "background_min_score": 0.22},
        voiceprint={"last_score": 0.8, "wake_score": 0.7},
        background_noise=lambda *_args: False,
        status=status,
        syslog=lambda tag, text: logged.append((tag, text)),
        emit=lambda text, **kwargs: emitted.append((text, kwargs)),
        sleep=lambda seconds: emitted.append((f"sleep:{seconds}", {})),
    )
    runtime = RuntimeSendGateAssembly(deps)

    desktop = runtime.prepare("桌面输入", from_phone=False)
    check(desktop.allowed and (desktop.hwnd, desktop.title)
          == (11, "桌面窗口"),
          "桌面输入沿用原目标窗口")
    check(not phone_calls, "桌面输入不读取手机选择")

    mobile = runtime.prepare("手机输入", from_phone=True)
    check(mobile.allowed and (mobile.hwnd, mobile.title)
          == (22, "Codex 窗口"),
          "手机输入优先使用手机选定的 Codex 目标")
    check(switched == [("手机会话", "thread-9")]
          and emitted[0][0] == "sleep:0.35",
          "目标不一致时才切换会话并按原顺序等待")
    check(emitted[-1][0]
          == "   ↳ 手机选的是「手机会话」，已经切过去了"
          and emitted[-1][1] == {"flush": True},
          "切换提示保留原文与刷新行为")

    switched.clear()
    current_name[0] = "手机会话"
    runtime.prepare("已在目标会话", from_phone=True)
    check(not switched, "目标会话已经打开时不再重复切换")

    blocked_deps = RuntimeSendGateDependencies(
        pick_send_target=lambda: (33, "目标"),
        phone_window=lambda: (0, ""),
        phone_target={},
        current_thread_name=lambda: "",
        switch_thread=lambda *_args: None,
        config={"voiceprint_gate": True},
        voiceprint={"last_score": 0.08, "wake_score": None},
        background_noise=lambda *_args: True,
        status=Status(),
        syslog=lambda tag, text: logged.append((tag, text)),
        emit=lambda text, **kwargs: emitted.append((text, kwargs)),
    )
    blocked = RuntimeSendGateAssembly(blocked_deps).prepare(
        "电视里的短句",
        from_phone=False,
    )
    check(not blocked.allowed and blocked.hwnd == 0,
          "最终背景音闸门拒绝时不返回可发送目标")
    check(blocked_deps.status.calls == [("idle", {"text": ""})],
          "拒绝后仍把状态恢复为空闲")
    check(logged[-1][0] == "噪" and "0.08" in logged[-1][1],
          "背景音拒绝仍写原声纹日志")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    check("send_gate.prepare(text_to_send" in source,
          "主流程消费独立发送前装配")
    check("if background_noise(text_to_send" not in source,
          "最终声纹闸门实现已经离开 main()")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
