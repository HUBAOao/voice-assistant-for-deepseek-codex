# -*- coding: utf-8 -*-
"""Calendar files enter FinDeck only through the bounded attachment tray."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)
MIMES = ("text/calendar", "application/calendar")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")
    for mime in MIMES:
        check(manifest.count(f'android:mimeType="{mime}"') == 4,
              f"{mime} 注册单张/多张分享及 content/file 打开")
        check(mime in activity and mime in media,
              f"{mime} 原生入口和网页暂存白名单一致")

    check("isCalendarDocumentMime(type)" in activity
          and "isCalendarDocumentMime(mime)" in activity,
          "日历文件复用现有附件上限与读取管线")
    check("MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "继续使用单个 16 MB、一次最多 6 个的上限")
    check("FinDeckShare" in activity and "file-staged" in activity
          and "stageFiles([new File([bytes]" in media
          and "sendButton.onclick" in media,
          "日历文件只进入待发送托盘，必须由用户点发送")
    check("ACTION_INSERT" not in activity
          and "CalendarContract" not in activity,
          "不申请日历权限，也不自动写入或导入事件")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
