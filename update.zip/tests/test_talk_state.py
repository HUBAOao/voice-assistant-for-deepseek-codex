# -*- coding: utf-8 -*-
"""Unit-test the wake, dictation and pre-send rules without loading STT models."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))

from voice_feature.talk_state import (  # noqa: E402
    DICTATION_IDLE,
    DICTATION_START,
    DICTATION_STOP,
    DICTATION_TYPE,
    DELIVERY_CLIPBOARD,
    DELIVERY_DRY_RUN,
    DELIVERY_OFFLINE,
    DELIVERY_SEND,
    WAKE_CANCEL,
    WAKE_IGNORE,
    WAKE_IGNORE_VOICE,
    WAKE_LISTEN,
    WAKE_LISTEN_AGAIN,
    DictationState,
    TalkState,
    dispatch_dictation_action,
    plan_delivery,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    state = TalkState(wake_timeout=12, followup_seconds=4)
    check(state.decide("随便说说", wake_enabled=False).action == "send",
          "免唤醒模式直接发送正文")
    check(state.decide("大肥鱼", wake_enabled=True, woke=True, now=100).action
          == WAKE_LISTEN, "只有唤醒词时进入聆听")
    check(state.decide("今天几号", wake_enabled=True, now=104).action
          == "send", "唤醒窗口内免唤醒发送")
    check(not state.is_armed(now=104), "发送后消费唤醒窗口")
    check(state.decide("今天几号", wake_enabled=True, now=105).action
          == WAKE_IGNORE, "窗口过期后忽略正文")

    check(state.decide("取消", wake_enabled=True, woke=True, cancel=True,
                       now=110).action == WAKE_CANCEL, "取消词清空唤醒窗口")
    check(not state.is_armed(now=110), "取消后不残留免唤醒窗口")
    check(state.decide("大肥鱼 查天气", wake_enabled=True, woke=True,
                       body="查天气", now=111).text == "查天气",
          "一句话里的唤醒词剥离后发送正文")
    check(state.decide("大肥鱼", wake_enabled=True, woke=True,
                       voice_ok=False, now=112).action == WAKE_IGNORE_VOICE,
          "唤醒声纹不符时忽略")

    check(state.arm_followup(now=200), "成功操作后打开连续对话窗口")
    check(state.decide("再说一句", wake_enabled=True, now=203).action == "send",
          "连续对话窗口内发送")
    state.arm_followup(now=210)
    check(state.decide("大肥鱼", wake_enabled=True, followup_echo=True,
                       now=211).action == WAKE_LISTEN_AGAIN,
          "窗口里重复唤醒只重新聆听")
    check(state.is_armed(now=222), "重复唤醒会续上唤醒超时")
    state.clear()
    check(TalkState(followup_seconds=0).arm_followup(now=1) is False,
          "关闭连续对话时不建立窗口")

    dictation = DictationState()
    check(dictation.command("开始听写") == DICTATION_START and dictation.on,
          "开始听写打开状态")
    check(dictation.command("随便一句话") == DICTATION_TYPE,
          "听写状态把正文送入光标")
    check(dictation.command("停", stop_requested=True) == DICTATION_STOP
          and not dictation.on, "停止词结束听写")
    check(dictation.command("普通聊天") == DICTATION_IDLE,
          "听写结束后回到普通发送")
    events = []

    class Status:
        def set(self, *args, **kwargs):
            events.append(("status", args, kwargs))

    handled = dispatch_dictation_action(
        DICTATION_TYPE,
        "听写正文",
        speak=lambda text: events.append(("speak", text)),
        status=Status(),
        beep=lambda _freq, _ms: events.append(("beep",)),
        type_text=lambda text: events.append(("type", text)),
        print_line=lambda *_args, **_kwargs: None,
    )
    check(handled and ("type", "听写正文") in events,
          "听写正文副作用由独立分发函数执行")
    check(dispatch_dictation_action(
        DICTATION_IDLE,
        "普通消息",
        speak=lambda _text: None,
        status=Status(),
        beep=lambda _freq, _ms: None,
        type_text=lambda _text: None,
    ) is False, "普通消息不被听写分发截走")

    check(plan_delivery(dry_run=True, has_window=False, editing_settings=True)
          == DELIVERY_DRY_RUN, "dry-run 优先且不碰窗口")
    check(plan_delivery(dry_run=False, has_window=False, editing_settings=True)
          == DELIVERY_OFFLINE, "没有目标窗口时进入离线复制")
    check(plan_delivery(dry_run=False, has_window=True, editing_settings=True)
          == DELIVERY_CLIPBOARD, "改设置时只复制")
    check(plan_delivery(dry_run=False, has_window=True, editing_settings=False,
                        confirm_allowed=False) == DELIVERY_CLIPBOARD,
          "用户未确认时只复制")
    check(plan_delivery(dry_run=False, has_window=True, editing_settings=False)
          == DELIVERY_SEND, "正常条件进入发送")

    source = (ROOT / "outputs" / "voice-to-text" / "stt.py").read_text(
        encoding="utf-8"
    )
    utterance = (
        ROOT / "outputs" / "voice-to-text" / "voice_feature" /
        "runtime_utterance_assembly.py"
    ).read_text(encoding="utf-8")
    wake_gate = (
        ROOT / "outputs" / "voice-to-text" / "voice_feature" /
        "runtime_wake_gate_assembly.py"
    ).read_text(encoding="utf-8")
    session_state = (
        ROOT / "outputs" / "voice-to-text" / "voice_feature" /
        "runtime_session_state.py"
    ).read_text(encoding="utf-8")
    check("DictationState" in session_state and "TalkState" in session_state,
          "STT 会话状态装配已使用独立状态机")
    check("armed[\"on\"]" not in source and "dictation[\"on\"]" not in source,
          "STT 不再内联唤醒/听写状态字典")
    check("deliver_text(" in utterance
          and "body, woke = text, True" in wake_gate,
          "发送前决策已收口且手机免唤醒入口保持")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
