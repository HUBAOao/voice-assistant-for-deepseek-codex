# -*- coding: utf-8 -*-
"""验收「电脑端和手机端的版本不强关联」：
电脑端做美化/小改动时手机端版本不动、也不提示更新；只有动了手机端才涨。"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    ver = load("v", APP / "version.py")
    print(f"① 两份版本各记各的：电脑端 v{ver.APP_VERSION}（{ver.UPDATES} 次），"
          f"手机端 v{ver.PHONE_VERSION}（{len(ver.PHONE_CHANGELOG)} 次）")
    check(ver.PHONE_VERSION == f"1.{len(ver.PHONE_CHANGELOG)}",
          "手机端版本 = PHONE_CHANGELOG 条数（跟电脑端那张表没关系）")
    check(ver.APP_VERSION == f"1.{len(ver.CHANGELOG)}", "电脑端还是看自己那张表")

    print("\n② 只往电脑端加一条，手机端版本不动")
    src = (APP / "version.py").read_text(encoding="utf-8")
    tmp = ROOT / "work" / "phone-split-scratch.py"
    tmp.write_text(src.replace(
        "]\n\nAPP_VERSION", '    "假装这是电脑端的一次美化改动",\n]\n\nAPP_VERSION'),
        encoding="utf-8")
    ver2 = load("v2", tmp)
    check(ver2.APP_VERSION != ver.APP_VERSION, f"电脑端涨了：{ver.APP_VERSION} → {ver2.APP_VERSION}")
    check(ver2.PHONE_VERSION == ver.PHONE_VERSION, f"手机端没动：还是 v{ver2.PHONE_VERSION}")

    print("\n③ 打包脚本用的是手机端那张表")
    build = (ROOT / "work" / "build_apk.py").read_text(encoding="utf-8")
    check('getattr(mod, "PHONE_VERSION"' in build, "build_apk 读 PHONE_VERSION")
    check("1000 +" in build, "versionCode 用 1000+次序号（覆盖安装不会被当降级）")
    man = (ROOT / "work" / "android-app" / "AndroidManifest.xml").read_text(encoding="utf-8")
    check("android:versionCode" not in man, "清单里不写死版本号（否则盖掉打包时注入的）")

    print("\n④ 手机页面只看手机端版本")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("num(d.phone) > num(appv)" in page, "提示更新比的是 d.phone，不是 d.pc")
    check('"phone": phone_app_version()' in page, "/api/version 会报手机端版本")

    print("\n⑤ 起服务实测 /api/version")
    pl = load("pl", APP / "phone_link.py")
    link = pl.PhoneLink(on_command=lambda t: None, get_state=lambda: {}, get_log=lambda s: [],
                        port=8793)
    link.start()
    time.sleep(0.3)
    url = f"http://127.0.0.1:{link.port}/api/version?k={link.token}"
    with urllib.request.urlopen(url, timeout=5) as r:
        data = json.loads(r.read().decode("utf-8"))
    print("   ->", data)
    check(data.get("phone") == ver.PHONE_VERSION, f"phone = v{ver.PHONE_VERSION}")
    check(data.get("pc") == ver.APP_VERSION, f"pc = v{ver.APP_VERSION}（只是给人看）")
    link.stop()
    try:
        tmp.unlink()
    except Exception:
        pass
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
