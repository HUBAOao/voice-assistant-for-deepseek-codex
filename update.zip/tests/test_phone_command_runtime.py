# -*- coding: utf-8 -*-
"""Phone ingress orchestration stays ordered and outside the STT entrypoint."""
from __future__ import annotations

import sys
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from phone_feature.phone_ingress import PhoneIngressQueue  # noqa: E402
from voice_feature.phone_command_runtime import (  # noqa: E402
    PhoneCommandDependencies,
    PhoneCommandRuntime,
)


class Store:
    def __init__(self) -> None:
        self.created = []
        self.updated = []
        self.tools = []

    def create(self, text, **kwargs):
        self.created.append((text, kwargs))
        return {"id": "task-%d" % len(self.created)}

    def update(self, task_id, **kwargs):
        self.updated.append((task_id, kwargs))

    def add_tool_call(self, task_id, name, **kwargs):
        self.tools.append((task_id, name, kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    ingress = PhoneIngressQueue()
    store = Store()
    events = []
    pasted = []
    watched = []
    busy = {"on": False, "at": 0.0}
    lock = threading.RLock()

    def process(text: str) -> None:
        events.append(("process", text))
        if text == "失败":
            raise RuntimeError("boom")

    deps = PhoneCommandDependencies(
        ingress=ingress,
        task_store=store,
        phone_thread_id=lambda: "phone-thread",
        phone_window=lambda: (0, ""),
        pick_target=lambda: (101, "目标"),
        focus_window=lambda hwnd: events.append(("focus", hwnd)) or True,
        press_enter=lambda: events.append(("enter",)),
        paste_into=lambda text, hwnd, **opts: (
            pasted.append((text, hwnd, opts)) or True
        ),
        paste_clipboard=lambda hwnd, **opts: events.append(
            ("clipboard", hwnd, opts)
        ),
        image_to_clipboard=lambda path: events.append(
            ("image", Path(path).name)
        ) or True,
        watch_media_reply=lambda text, hwnd, title: watched.append(
            (text, hwnd, title)
        ),
        current_thread_id=lambda: "codex-thread",
        busy=busy,
        syslog=lambda tag, text: events.append(("log", tag, text)),
        handle_lock=lock,
        process_command=process,
        clock=lambda: 12.5,
        sleep=lambda _seconds: events.append(("sleep",)),
        print_line=lambda *args, **kwargs: None,
    )
    runtime = PhoneCommandRuntime(deps)

    runtime.push("你好")
    check(store.created == [(
        "你好",
        {"thread_id": "phone-thread", "detail": "手机发来的命令"},
    )], "手机命令先建立任务并绑定当前会话")
    runtime.drain()
    check(events[-1] == ("process", "你好"), "命令仍交给原 handle 管线")
    check(store.tools == [(
        "task-1", "phone_command", {"detail": "你好"},
    )], "任务记录工具调用")
    check(store.updated[-1] == (
        "task-1",
        {"status": "succeeded", "thread_id": "codex-thread", "error": ""},
    ), "任务成功时回写真实 Codex 会话")

    ingress.push_media("图片附言")
    runtime.drain()
    check(pasted and pasted[-1][0] == "图片附言"
          and pasted[-1][2]["press_enter"] is True,
          "媒体附言继续按回车发送")
    check(watched == [("图片附言", 101, "目标")], "媒体附言继续启动回答监听")
    check(busy == {"on": True, "at": 12.5}, "媒体发送更新忙碌现场")

    runtime.got_image(Path("one.png"))
    runtime.drain()
    check(("image", "one.png") in events
          and ("clipboard", 101, {
              "press_enter": False, "clear_first": False,
          }) in events, "手机图片先复制再粘贴且不自动提交")

    ingress.request_submit()
    ingress.push_media("不应先发")
    runtime.drain()
    check(any(item[0] == "enter" for item in events)
          and ingress.take_media() == "不应先发",
          "提交请求优先于后续媒体附言")

    runtime.push("失败")
    runtime.drain()
    check(store.updated[-1][1]["status"] == "failed"
          and "boom" in store.updated[-1][1]["error"],
          "命令异常时任务标记失败并保留根因")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "phone_command_runtime.py"
    ).read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    for marker in (
        "def phone_push(",
        "def drain_phone_commands(",
        "def phone_worker(",
        "def paste_phone_images(",
    ):
        check(marker not in source, f"main() 不再内联 {marker}")
    check("PhoneCommandRuntime(" in assembly
          and "assemble_phone_runtime(" in source
          and "phone_push = phone_commands.push" in source
          and "drain_phone_commands = phone_commands.drain" in source,
          "主流程只消费手机业务装配并保留旧入口名")
    check("def drain(" in module and "def worker(" in module,
          "队列、任务和媒体处理位于独立可注入模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
