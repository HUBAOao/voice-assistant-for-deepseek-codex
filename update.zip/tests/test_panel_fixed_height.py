# -*- coding: utf-8 -*-
"""验收设置面板：展开后高度固定（切标签页不再上下抽动）+ 内容装不下时能滚轮看、右边有细滚动条。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "panel-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def make_overlay():
    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg["overlay_bg_image"] = ""
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 120, "y": 120}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None
    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    return o


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    o = make_overlay()
    print("① 每个标签页的展开高度都一样（不再上下变化）")
    heights = {}
    for tab in o.tab_names:
        o.show_tab(tab)
        for _ in range(20):
            o.root.update()
            time.sleep(0.01)
        heights[tab] = round(float(o.target_h), 1)
    sizes = set(heights.values())
    check(len(sizes) == 1, f"六个标签页高度：{heights}")
    check(sizes == {round(float(o.header_h + overlay.PANEL_H_OPEN), 1)},
          f"固定值 = 头部 {o.header_h:.0f} + 面板 {overlay.PANEL_H_OPEN}")

    print("\n② 内容装不下 → 右边显示细滚动条，而且滚轮真能滚")
    o.show_tab("外观")
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    stage, bar = o.stage_canvas, o.scroll_hint
    region = stage.bbox("all")
    content_h = region[3] - region[1]
    check(content_h > stage.winfo_height(),
          f"外观页内容 {content_h} > 可视 {stage.winfo_height()}（确实超了）")
    o._update_scroll_hint()
    o.root.update()
    check(bool(bar.place_info()), "超了 → 右边出现细滚动条")
    before = stage.yview()[0]
    stage.yview_scroll(1, "units")
    o.root.update()
    after = stage.yview()[0]
    check(after > before, f"能往下滚（{before:.2f} → {after:.2f}）")

    o.show_tab("基本")
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    o._update_scroll_hint()
    o.root.update()
    print(f"   （基本页：装了滚动条？ {bool(bar.place_info())}）")

    print("\n③ 窗口总高还是跟屏幕走（矮屏幕不会把底部按钮顶出去）")
    check(o.target_h <= o.root.winfo_screenheight() + 1,
          f"展开高度 {o.target_h:.0f} ≤ 屏高 {o.root.winfo_screenheight()}")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
