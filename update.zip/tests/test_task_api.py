# -*- coding: utf-8 -*-
"""Exercise the authenticated task endpoints through the real HTTP server."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import phone_link  # noqa: E402


def request(url: str, payload: dict | None = None) -> dict:
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        os.environ["FIN_DECK_TASKS_FILE"] = str(Path(raw) / "tasks.json")
        token = "task-api-test-token"
        link = phone_link.PhoneLink(
            lambda text: None,
            lambda: {"state": "idle"},
            lambda since=0: [],
            port=8794,
            pairing=False,
            token=token,
        )
        assert link.start()
        base = "http://127.0.0.1:8794"
        q = "?k=" + token
        try:
            created = request(base + "/api/tasks/action" + q, {
                "action": "create",
                "title": "检查 P1 控制台",
                "thread_id": "thread-p1",
            })
            assert created["ok"]
            task_id = created["task"]["id"]

            waiting = request(base + "/api/tasks/action" + q, {
                "action": "message",
                "id": task_id,
                "text": "补上测试结果",
            })
            assert waiting["task"]["messages"][0]["text"] == "补上测试结果"

            listed = request(base + "/api/tasks" + q)
            assert listed["ok"] and listed["items"][0]["id"] == task_id

            cancelled = request(base + "/api/tasks/action" + q, {
                "action": "cancel",
                "id": task_id,
            })
            assert cancelled["task"]["status"] == "cancelled"
            print("test_task_api: PASS")
        finally:
            link.stop()
            os.environ.pop("FIN_DECK_TASKS_FILE", None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
