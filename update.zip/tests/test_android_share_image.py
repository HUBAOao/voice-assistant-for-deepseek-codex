# -*- coding: utf-8 -*-
"""Shared images are staged locally and require an explicit send action."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
SOURCE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "media.js"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    source = SOURCE.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    check(manifest.count('android:mimeType="image/*"') == 2,
          "单张和多张图片分享目标都已注册")
    check("MAX_SHARED_IMAGES = 6" in source
          and "MAX_SHARED_IMAGE_BYTES = 8L * 1024L * 1024L" in source,
          "原生接收有 6 张和单张 8 MB 上限")
    check("Intent.ACTION_SEND_MULTIPLE.equals(action)" in source
          and "queueSharedImage(" in source
          and "Base64.encodeToString(bytes, Base64.NO_WRAP)" in source,
          "原生安全读取 content/file 图片并交给 WebView")
    check("window.onAndroidSharedImage" in source
          and "window.onAndroidSharedImage" in media,
          "图片通过专用页面入口进入现有附件区")
    check("stageFiles([new File([bytes], safeName" in media
          and "pendingAttachments" in media,
          "页面把图片解码成普通 File 并复用待发送附件队列")
    function = media.split("window.onAndroidSharedImage", 1)[1].split(
        "async function uploadAttachment", 1
    )[0]
    check("fetch(" not in function and "/api/" not in function,
          "接收函数不上传、不发送，只暂存")
    check("pumpSharedImage();" in source.split(
        "private void captureSharedText", 1
    )[1],
          "分享进入 Activity 后会等待页面就绪再交付")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
