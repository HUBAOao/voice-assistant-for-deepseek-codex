# -*- coding: utf-8 -*-
"""Shared images, PDFs and ZIPs are staged locally and require sending."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
SOURCE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "media.js"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    source = SOURCE.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    check(manifest.count('android:mimeType="image/*"') == 2
          and manifest.count('android:mimeType="application/pdf"') == 4
          and manifest.count('android:mimeType="application/zip"') == 4
          and manifest.count('android:mimeType="audio/*"') == 4,
          "图片、PDF、ZIP 与音频分享和打开目标都已注册")
    check("MAX_SHARED_ATTACHMENTS = 6" in source
          and "MAX_SHARED_IMAGE_BYTES = 8L * 1024L * 1024L" in source
          and "MAX_SHARED_FILE_BYTES = 16L * 1024L * 1024L" in source,
          "原生接收有 6 个附件、图片 8 MB 和文件 16 MB 上限")
    check("Intent.ACTION_SEND_MULTIPLE.equals(action)" in source
          and "queueSharedAttachment(" in source
          and "Base64.encodeToString(bytes, Base64.NO_WRAP)" in source,
          "原生安全读取 content/file 附件并交给 WebView")
    check('"application/zip".equals(' in source
          and 'isZipMime(type)' in source,
          "ZIP 只接受标准 application/zip 并沿用受限读取")
    check('startsWith("audio/")' in source
          and 'isAudioMime(type)' in source,
          "音频只接受 audio 子类型并沿用受限读取")
    view_branch = source.split("Intent.ACTION_VIEW.equals(action)", 1)[1].split(
        "} else {", 1
    )[0]
    check("isShareableAttachmentMime(type)" in view_branch
          and "queueSharedAttachment(intent.getData(), type)" in view_branch,
          "文件管理器打开 PDF/ZIP/音频时只进入现有受限附件队列")
    check("window.onAndroidSharedAttachment" in source
          and "window.onAndroidSharedImage" in media,
          "附件通过受限页面入口进入现有附件区，并保留图片兼容入口")
    check("stageFiles([new File([bytes], safeName" in media
          and "pendingAttachments" in media,
          "页面把附件解码成普通 File 并复用待发送附件队列")
    check('clean === "application/zip"' in media
          and 'clean.startsWith("audio/")' in media,
          "页面入口接受 ZIP 和音频，不再拒绝原生已交付的附件")
    function = media.split("window.onAndroidSharedAttachment", 1)[1].split(
        "async function uploadAttachment", 1
    )[0]
    check("fetch(" not in function and "/api/" not in function,
          "接收函数不上传、不发送，只暂存")
    check("pumpSharedAttachment();" in source.split(
        "private void captureSharedText", 1
    )[1],
          "分享或打开文件后会等待页面就绪再交付")
    with zipfile.ZipFile(APK) as archive:
        dex = archive.read("classes.dex")
    for marker in (
        b"onAndroidSharedAttachment",
        b"application/pdf",
        b"application/zip",
        b"audio/",
        b"file-staged",
        b"MAX_SHARED_FILE_BYTES",
    ):
        check(marker in dex, f"APK DEX 包含 {marker.decode('ascii')}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
