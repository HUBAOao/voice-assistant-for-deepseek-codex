# -*- coding: utf-8 -*-
"""RTF, EPUB and Markdown stay on the bounded attachment pipeline."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)
MIMES = {
    "RTF": "application/rtf",
    "EPUB": "application/epub+zip",
    "Markdown": "text/markdown",
}


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition, text) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    for label, mime in MIMES.items():
        check(manifest.count(f'android:mimeType="{mime}"') == 4,
              f"{label} 注册单张/多张分享及 content/file 打开")
        check(mime in activity and mime in media,
              f"{label} 原生白名单与页面入口一致")
    check("isReadingDocumentMime(type)" in activity
          and "isReadingDocumentMime(mime)" in activity,
          "三种阅读文件复用现有可分享附件判定")
    check("MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "继续使用单个 16 MB、一次最多 6 个的上限")
    check("FinDeckShare" in activity and "file-staged" in activity
          and "stageFiles([new File([bytes]" in media
          and "sendButton.onclick" in media,
          "只进入待发送托盘，必须由用户点发送")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
