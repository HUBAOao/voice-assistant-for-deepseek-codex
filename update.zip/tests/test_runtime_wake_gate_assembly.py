# -*- coding: utf-8 -*-
"""Wake admission keeps its original side effects outside ``main()``."""
from __future__ import annotations

import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_wake_gate_assembly import (  # noqa: E402
    RuntimeWakeGateAssembly,
    RuntimeWakeGateDependencies,
)


class Status:
    def __init__(self) -> None:
        self.calls = []
        self.moods = []

    def set(self, state, **kwargs) -> None:
        self.calls.append((state, kwargs))

    def set_mood(self, mood) -> None:
        self.moods.append(mood)


class TalkState:
    def __init__(self, action="send", text="正文", armed=False) -> None:
        self.action = action
        self.text = text
        self.armed = armed
        self.calls = []

    def is_armed(self) -> bool:
        return self.armed

    def decide(self, text, **kwargs):
        self.calls.append((text, kwargs))
        return type(
            "Decision",
            (),
            {"action": self.action, "text": self.text},
        )()


def make(**overrides):
    values = dict(
        wake_words=["大肥鱼"],
        wake_level={"fuzzy": True, "leading": True},
        cancel_words=["不用了"],
        listen_timeout=12,
        talk_state=TalkState(),
        extract_word=lambda text, words, fuzzy=True, leading=True: (
            "帮我查天气" if text.startswith("大肥鱼") else text,
            text.startswith("大肥鱼"),
        ),
        looks_like_wake=lambda text, words: "大肥" in text,
        cancel_hit=lambda text, words: text.strip() in words,
        wake_voice_ok=lambda audio: True,
        beep=lambda freq, ms: None,
        award=lambda kind: None,
        status=Status(),
        syslog=lambda tag, text: None,
        emit=lambda text: None,
    )
    values.update(overrides)
    return RuntimeWakeGateDependencies(**values)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition, text) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    status = Status()
    talk = TalkState(text="帮我查天气")
    outcome = RuntimeWakeGateAssembly(make(
        status=status,
        talk_state=talk,
    )).evaluate("大肥鱼帮我查天气", mood="happy")
    check(outcome.allowed and outcome.text == "帮我查天气",
          "带唤醒词时只把正文交给后续管线")
    check(talk.calls[0][1]["woke"] is True
          and status.moods == ["happy"]
          and status.calls[-1][0] == "thinking",
          "唤醒判定、语气和思考状态保持原顺序")

    status = Status()
    talk = TalkState(text="手机发来的正文")
    outcome = RuntimeWakeGateAssembly(make(
        wake_words=[],
        status=status,
        talk_state=talk,
    )).evaluate("直接聊天", mood="calm")
    check(outcome.allowed and outcome.text == "直接聊天"
          and not talk.calls and status.moods == ["calm"],
          "未启用唤醒词时普通聊天直接放行")

    status = Status()
    calls = []
    outcome = RuntimeWakeGateAssembly(make(
        status=status,
        wake_voice_ok=lambda audio: calls.append("voice") or False,
        talk_state=TalkState(action="ignore_voice"),
    )).evaluate("大肥鱼测试", audio=object())
    check(calls == ["voice"] and not outcome.allowed
          and status.moods == [""],
          "麦克风声纹拒绝时不进入发送管线")

    beeps = []
    outcome = RuntimeWakeGateAssembly(make(
        talk_state=TalkState(action="cancel"),
        beep=lambda freq, ms: beeps.append((freq, ms)),
    )).evaluate("大肥鱼不用了")
    check(not outcome.allowed and beeps == [(440, 90)],
          "取消词仍先提示再结束本轮")

    beeps.clear()
    outcome = RuntimeWakeGateAssembly(make(
        talk_state=TalkState(action="listen"),
        beep=lambda freq, ms: beeps.append((freq, ms)),
    )).evaluate("大肥鱼")
    check(not outcome.allowed and beeps == [(880, 70), (1320, 90)],
          "只喊唤醒词时保留双提示音并进入聆听")

    status = Status()
    talk = TalkState(text="手机发来的正文")
    calls = []
    outcome = RuntimeWakeGateAssembly(make(
        status=status,
        talk_state=talk,
        wake_voice_ok=lambda audio: calls.append("voice") or False,
    )).evaluate(
        "手机发来的正文",
        audio=object(),
        from_phone=True,
    )
    check(outcome.allowed and outcome.text == "手机发来的正文"
          and not calls,
          "手机文字绕过唤醒词与声纹但仍走同一发送管线")

    module = APP / "voice_feature" / "runtime_wake_gate_assembly.py"
    ast.parse(module.read_text(encoding="utf-8"))
    stt = (APP / "stt.py").read_text(encoding="utf-8")
    utterance = (
        APP / "voice_feature" / "runtime_utterance_assembly.py"
    ).read_text(encoding="utf-8")
    check(module.exists() and "assemble_runtime_gate_wiring(" in stt
          and "wake_gate.evaluate(" in utterance,
          "主流程消费独立唤醒装配")
    check("decision = talk_state.decide(" not in stt,
          "main() 不再内联唤醒分支")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
