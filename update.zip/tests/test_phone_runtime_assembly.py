# -*- coding: utf-8 -*-
"""Phone business assembly remains injectable and preserves legacy aliases."""
from __future__ import annotations

import io
import sys
import tempfile
import types
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.phone_runtime_assembly import (  # noqa: E402
    PhoneRuntimeDependencies,
    assemble_phone_runtime,
)


class Status:
    state = "idle"
    hint = ""
    _last = {"text": ""}


class Remote:
    def detail(self):
        return {}

    def fixed_url(self):
        return ""

    def alt_url(self):
        return ""

    def hint(self):
        return ""

    def phone_hint(self):
        return ""

    def public_url(self):
        return ""

    def apk_url(self):
        return ""


class Version:
    AUTHOR = "tester"
    CONTACT = ""
    COPYRIGHT = ""
    FREE_LINE = ""
    NOTICE = ""


class Server:
    def __init__(self, **kwargs) -> None:
        self.__dict__.update(kwargs)

    def start(self):
        return True

    def url(self):
        return "http://127.0.0.1:8765/?k=test"

    def stop(self):
        pass


class Lifecycle:
    def __init__(self) -> None:
        self.jobs = []

    def start_daemon(self, name, target):
        self.jobs.append((name, target))


class Watcher:
    def __init__(self) -> None:
        self.calls = []

    def start(self, **kwargs):
        self.calls.append(kwargs)


class Transcriber:
    def __init__(self) -> None:
        self.calls = 0

    def transcribe(self, _audio):
        self.calls += 1
        return "手机语音"


class Store:
    def create(self, *_args, **_kwargs):
        return {"id": "task-1"}


def wav_bytes(rate: int = 16000) -> bytes:
    output = io.BytesIO()
    with wave.open(output, "wb") as target:
        target.setnchannels(1)
        target.setsampwidth(2)
        target.setframerate(rate)
        target.writeframes(b"\0\0" * (rate // 2))
    return output.getvalue()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_phone_assembly_") as raw:
        root = Path(raw)
        config = {"phone_enabled": True, "read_reply": True}
        lifecycle = Lifecycle()
        watcher = Watcher()
        transcriber = Transcriber()
        threads = types.SimpleNamespace(
            list_threads=lambda: [{"id": "thread"}],
            list_projects=lambda: [{"id": "project"}],
        )
        phone_link = types.SimpleNamespace(PhoneLink=Server)
        deps = PhoneRuntimeDependencies(
            config=config,
            status=Status(),
            busy={"on": False, "at": 0.0},
            mute={"on": False},
            reply_busy=lambda: False,
            load_config=lambda: dict(config),
            syslog=lambda _tag, _text: None,
            handle_lock=__import__("threading").RLock(),
            process_command=lambda _text: None,
            pick_target=lambda: (0, ""),
            phone_window=lambda: (0, ""),
            focus_window=lambda _hwnd: True,
            press_enter=lambda: None,
            paste_into=lambda *_args, **_kwargs: True,
            paste_clipboard=lambda *_args, **_kwargs: True,
            image_to_clipboard=lambda _path: True,
            get_reply_reader=lambda: None,
            current_thread_id=lambda: "",
            current_thread_name=lambda: "",
            transcriber=transcriber,
            cancel_reference_echo=lambda audio, _rate: audio,
            rate=16000,
            config_file=root / "config.json",
            suppressed=False,
            phone_port=8765,
            syslog_file=root / "syslog.md",
            raw_replies_file=root / "phone-replies.jsonl",
            last_reply_file=root / "last-reply.json",
            self_who=lambda _cfg: "大肥鱼",
            ack_phrases=(),
            phone_window_title=lambda: "",
            chat_history=object(),
            phone_link_module=phone_link,
            runtime_lifecycle=lifecycle,
            on_stop=lambda: None,
            fallback_get_windows=lambda: [],
            public_update_url=lambda: "",
            pc_version=lambda: "1.264",
            phone_version=lambda: "1.83",
            version_module=Version,
            remote_access=Remote(),
            get_target=lambda: "",
            get_target_id=lambda: "",
            on_target=lambda _title, _thread_id: (True, ""),
            on_thread_action=lambda _action, _thread_id, _payload: (True, ""),
            on_new_thread=lambda _project: (True, ""),
            task_store_factory=Store,
            codex_control_factory=lambda store: {"store": store},
            threads_module=threads,
            phone_stream_module=types.SimpleNamespace(
                GLOBAL_WATCHER=watcher
            ),
            log=lambda *_args, **_kwargs: None,
        )
        runtime = assemble_phone_runtime(deps)
        server = runtime.start()
        check(isinstance(server, Server), "手机桥接启动真实服务对象")
        check(runtime.info()["pc"] == "1.264"
              and runtime.info()["phone"] == "1.83",
              "手机元数据继续回读电脑端与手机端版本")
        check(runtime.state()["paused"] is False,
              "手机状态装配保留暂停字段")
        check(lifecycle.jobs[0][0] == "phone-command-worker"
              and watcher.calls,
              "命令工作线程与全局会话流监听按原顺序启动")
        check(runtime.voice(wav_bytes()) == "手机语音"
              and transcriber.calls == 1,
              "手机原生录音仍走回声消除后转写")
        check(runtime.task_store is not None
              and runtime.live_codex["store"] is runtime.task_store,
              "任务存储和 Codex 控制由同一装配共享")
        check(runtime.schedule_do(
            "add",
            {"item": {"time": "09:00", "text": "装配验证"}},
        )[0],
              "日程写操作仍落回同一 config.json 路径")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    check("phone = assemble_phone_runtime(" in source
          and "PhoneBridgeDependencies(" not in source,
          "main() 只装配手机业务入口")
    for alias in (
        "phone_push = phone_commands.push",
        "drain_phone_commands = phone_commands.drain",
        "phone_worker = phone_commands.worker",
        "paste_phone_images = phone_commands.paste_images",
        "phone_voice = phone.voice",
    ):
        check(alias in source, f"旧手机入口保持：{alias.split(' = ')[0]}")
    check("class PhoneRuntimeAssembly" in module
          and "def assemble_phone_runtime(" in module,
          "手机队列、历史、元数据与桥接装配位于独立模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
