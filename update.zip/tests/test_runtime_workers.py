# -*- coding: utf-8 -*-
"""Background workers and shutdown cleanup stay outside main()."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_lifecycle import RuntimeLifecycle  # noqa: E402
from voice_feature.runtime_workers import (  # noqa: E402
    ForegroundTrackerWorker,
    HeartbeatWorker,
    register_shutdown_resources,
)


class StopAfterOne:
    def __init__(self) -> None:
        self.calls = []

    def wait(self, timeout: float) -> bool:
        self.calls.append(timeout)
        return len(self.calls) > 1

    def set(self) -> None:
        self.calls.append("set")


class Tracker:
    def __init__(self) -> None:
        self.polls = 0

    def poll(self) -> None:
        self.polls += 1


class Stream:
    def __init__(self, name: str, calls: list[str]) -> None:
        self.name = name
        self.calls = calls

    def stop(self) -> None:
        self.calls.append(self.name + ".stop")

    def close(self) -> None:
        self.calls.append(self.name + ".close")


class Process:
    def __init__(self, calls: list[str]) -> None:
        self.calls = calls

    def poll(self):
        return None

    def terminate(self) -> None:
        self.calls.append("overlay.terminate")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_workers_") as raw:
        path = Path(raw) / "heartbeat.json"
        heartbeat = HeartbeatWorker(
            path,
            pid=2468,
            clock=lambda: 12.5,
            stop_event_factory=StopAfterOne,
        )
        heartbeat.run()
        data = json.loads(path.read_text(encoding="utf-8"))
        check(data == {"pid": 2468, "ts": 12.5},
              "心跳立即写一次 PID 与时间戳")

    tracker = Tracker()
    tracker_worker = ForegroundTrackerWorker(
        tracker,
        interval=0.2,
        stop_event_factory=StopAfterOne,
    )
    tracker_worker.run()
    check(tracker.polls == 1, "前台追踪按停止信号运行且不无限抢占线程")

    calls: list[str] = []
    lifecycle = RuntimeLifecycle()
    current = {"stream": Stream("old", calls)}
    register_shutdown_resources(
        lifecycle,
        microphone=lambda: current["stream"],
        tracker_worker=tracker_worker,
        overlay_process=Process(calls),
    )
    current["stream"] = Stream("reconnected", calls)
    errors = lifecycle.close()
    check(not errors, "完整资源退出没有额外失败")
    check(calls == [
        "overlay.terminate",
        "reconnected.stop",
        "reconnected.close",
    ], "退出顺序固定为悬浮窗、追踪器、当前麦克风流")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    input_setup = (
        APP / "voice_feature" / "runtime_input_loop.py"
    ).read_text(encoding="utf-8")
    for marker in (
        "HeartbeatWorker(HEARTBEAT).start(lifecycle)",
    ):
        check(marker in stt, f"main 生命周期调用 {marker}")
    foreground = (
        APP / "voice_feature" / "runtime_foreground_assembly.py"
    ).read_text(encoding="utf-8")
    for marker in (
        "register_shutdown_resources(",
        "prepare_microphone_runtime(",
    ):
        check(marker in foreground, f"前台生命周期调用 {marker}")
    check("tracker_worker.start(deps.runtime_lifecycle)" in input_setup,
          "输入运行时把前台追踪器登记到同一生命周期")
    check("threading.Thread(target=beat, daemon=True)" not in stt,
          "心跳不再由 main 直接拼接守护线程")
    check("def _track() -> None:" not in stt,
          "前台追踪循环已迁出 main")
    check("def reconnect_mic()" not in stt,
          "麦克风重连循环已迁出 main")

    collect = (APP / "overlay_feature" / "settings_collect_mixin.py")
    persist = (APP / "overlay_feature" / "settings_persistence_mixin.py")
    wrapper = (APP / "overlay_feature" / "settings_actions_mixin.py")
    check(collect.exists() and "def collect(self)" in collect.read_text(
        encoding="utf-8"), "设置控件收集独立成模块")
    check(persist.exists() and "def reset_defaults(self)" in persist.read_text(
        encoding="utf-8"), "设置保存/恢复业务独立成模块")
    check(len(wrapper.read_text(encoding="utf-8").splitlines()) < 30,
          "旧 settings_actions_mixin 只保留兼容组合入口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
