# -*- coding: utf-8 -*-
"""Android evidence parsing does not turn valid system state into false alarms."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "work"))

from android_device_check import _done_channel_high, _granted_permissions


def main() -> int:
    package_dump = """
        android.permission.RECORD_AUDIO: granted=true
        android.permission.POST_NOTIFICATIONS: granted=true
        android.permission.FOREGROUND_SERVICE
        android.permission.SYSTEM_ALERT_WINDOW
    """
    appops_allow = "SYSTEM_ALERT_WINDOW: allow; time=+39m ago"
    appops_deny = "SYSTEM_ALERT_WINDOW: deny; time=+1m ago"

    allowed = _granted_permissions(package_dump, appops_allow)
    assert allowed["android.permission.SYSTEM_ALERT_WINDOW"] is True
    assert allowed["android.permission.RECORD_AUDIO"] is True
    assert allowed["android.permission.FOREGROUND_SERVICE"] is False

    denied = _granted_permissions(package_dump, appops_deny)
    assert denied["android.permission.SYSTEM_ALERT_WINDOW"] is False

    channel = """
      Notification(
        channel=voice_done_v2
        importance=default
      )
      NotificationChannel{mId='voice_done_v2', mName='done', mImportance=4}
    """
    assert _done_channel_high(channel) is True
    assert _done_channel_high(
        "NotificationChannel{mId='voice_done_v2', mImportance=2}"
    ) is False
    assert _done_channel_high(
        "Notification(channel=voice_done_v2 importance=4)"
    ) is False

    print("test_android_device_check: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
