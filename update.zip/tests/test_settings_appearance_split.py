# -*- coding: utf-8 -*-
"""Appearance preferences keep the historical mixin while actions are split."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_appearance_mixin import (  # noqa: E402
    OverlaySettingsAppearanceMixin,
)
from overlay_feature.defaults import CARD, VOICES  # noqa: E402
from overlay_feature.settings_voice_mixin import (  # noqa: E402
    OverlaySettingsVoiceMixin,
)


class Chip:
    def __init__(self) -> None:
        self.options = {}
        self.calls = []

    def config(self, **kwargs) -> None:
        self.options.update(kwargs)
        self.calls.append(kwargs)


class Slider:
    def __init__(self, value: int = 0) -> None:
        self.value = value
        self.values = []

    def set(self, value) -> None:
        self.value = value
        self.values.append(value)

    def get(self) -> int:
        return self.value


class Root:
    def __init__(self) -> None:
        self.geometry_text = ""

    def geometry(self, value: str) -> None:
        self.geometry_text = value


class Fake(OverlaySettingsAppearanceMixin, OverlaySettingsVoiceMixin):
    def __init__(self) -> None:
        self.cfg = {"voice_preset": 2}
        self.button_color = "#123456"
        self.root = Root()
        self.bg_label = Chip()
        self.voice_label = Chip()
        self.voice_index = 0
        self.perf_value = "standard"
        self.perf_chips = {"eco": Chip(), "quality": Chip()}
        self.sl_anim = Slider(60)
        self.wave_style_value = "siri"
        self.style_chips = {"bars": Chip()}
        self.name_freq_value = "low"
        self.name_freq_chips = {"high": Chip()}
        self.self_freq_value = "low"
        self.self_freq_chips = {"high": Chip()}
        self.changes = 0

    def on_change(self) -> None:
        self.changes += 1

    def flash(self, _text: str) -> None:
        pass


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    fake = Fake()
    check(fake._rate_value("+18%") == 18.0
          and fake._rate_value("坏值") == 8.0,
          "语速解析保留合法值并安全回退")
    check(fake._voice_index() == 0, "越界音色预设安全回退到第一项")
    fake.voice_index = len(VOICES) - 1
    check(fake._voice_text() == VOICES[-1][1], "音色标签仍来自同一份预设表")
    fake.set_bg("C:/tmp/背景.png")
    check(fake.bg_path.endswith("背景.png")
          and fake.bg_label.options["text"] == "背景.png",
          "背景选择仍即时写回标签")
    fake.set_perf("eco")
    check(fake.perf_value == "eco" and fake.sl_anim.values == [20],
          "节能档保留动画帧率副作用")
    check(fake.perf_chips["eco"].options["bg"] == "#123456"
          and fake.perf_chips["quality"].options["bg"] == CARD,
          "性能档仍用主题色标出当前项")
    fake.set_wave_style("bars")
    check(fake.wave_style == "bars"
          and fake.style_chips["bars"].calls[-1]["bg"] == "#123456",
          "波形样式仍更新值和高亮")
    fake.set_name_freq("high")
    fake.set_self_freq("high")
    check(fake.name_freq_value == "high"
          and fake.self_freq_value == "high",
          "名字与自称频率仍独立更新")
    check(fake.changes == 5, "每个偏好动作都调用原有变更入口")
    check(all(hasattr(fake, name) for name in (
        "_entry", "edit_text", "set_autostart", "pick_bg",
        "set_bg", "_rate_value", "apply_size",
    )), "历史外观类仍提供全部原方法")

    old = APP / "overlay_feature" / "settings_appearance_mixin.py"
    text = old.read_text(encoding="utf-8")
    check(len(text.splitlines()) <= 30, "外观兼容组合保持小体积")
    for name in (
        "settings_text_input_mixin.py",
        "settings_preference_chips_mixin.py",
        "settings_background_size_mixin.py",
    ):
        path = APP / "overlay_feature" / name
        check(path.exists() and len(path.read_text(encoding="utf-8").splitlines()) <= 110,
              f"{name} 保持独立边界")
    combined = "\n".join(
        (APP / "overlay_feature" / name).read_text(encoding="utf-8")
        for name in (
            "settings_text_input_mixin.py",
            "settings_preference_chips_mixin.py",
            "settings_background_size_mixin.py",
        )
    )
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    for marker in ("def _entry(", "def edit_text(",
                   "def set_autostart(", "def apply_size("):
        check(marker in combined and marker not in overlay,
              f"设置动作 {marker} 已迁出 overlay.py")
    voice_module = "\n".join(
        (APP / "overlay_feature" / name).read_text(encoding="utf-8")
        for name in (
            "settings_voice_drawer_mixin.py",
            "settings_voice_preview_mixin.py",
        )
    )
    check("def preview_voice(" in voice_module
          and "def cycle_voice(" in voice_module
          and "def _voice_index(" in voice_module
          and "def preview_voice(" not in combined,
          "音色解析、切换和非阻塞试听仍在独立音色模块")
    check("OverlaySettingsAppearanceMixin" in overlay,
          "悬浮窗仍通过混入组合原设置动作")
    check("def _overlay_inputlog(" in overlay,
          "迁移后的文字编辑仍走悬浮窗原输入日志入口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
