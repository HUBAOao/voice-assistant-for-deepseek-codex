# -*- coding: utf-8 -*-
"""钉住那个 bug：一发新消息就把上一条回答从头再念一遍。
场景：发完消息 → 窗口还停在"上一条回答"上（这期间不许念）→ 新回答出现（只念新的）。"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

OLD_REPLY = "收到，取消照办了 —— 而且你这句话本身帮我抓到一个真 bug。"
NEW_REPLY = "好，这一版我把念回答接上了，而且顺手把刚才那个重复念的毛病修了。"


def doc(state: dict) -> str:
    """假装窗口内容（照真窗口的排版：标记单独占一行，后面跟着输入框和操作栏）"""
    return (f"一堆界面文字\n你说：\n{state['sent']}\n20:43\n已处理 3秒\n"
            f"ChatGPT 说：\n{state['reply']}\n"
            f"最新一条回复\n随心输入\n添加文件等内容\n\ufffc\n完全访问\n"
            + "".join(f"跳转到用户消息 {i}\n" for i in range(1, 40)))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("rr", APP / "reply_reader.py")
    rr = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rr)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    spoken: list = []
    state = {"sent": "上一条我说的话", "reply": OLD_REPLY}
    rr.document_text = lambda hwnd, limit=4000, timeout=25: doc(state)
    reader = rr.ReplyReader(speak_func=spoken.append, record=lambda t: None,
                            poll_seconds=0.05)

    print("① 发完新消息：窗口还停在上一条回答上（这段不该念）")
    state["sent"] = "这是刚发的新消息"
    reader.watch(123, "这是刚发的新消息", seconds=6)
    time.sleep(0.8)
    check(spoken == [], f"一个字都没念（现在念了 {spoken[:1]}）")

    print("② 新回答出现：只念新的那条")
    state["reply"] = NEW_REPLY
    time.sleep(1.2)
    reader.stop()
    time.sleep(0.2)
    joined = "".join(spoken)
    check(NEW_REPLY[:10] in joined, f"念了新回答：{joined[:60]}")
    check("取消照办了" not in joined, "没把上一条回答再念一遍 ← 就是这次的 bug")
    check(joined.count("好，这一版") == 1, "新回答只念了一次")
    check("跳转到用户消息" not in joined, "输入框/操作栏那几个字没被念")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
