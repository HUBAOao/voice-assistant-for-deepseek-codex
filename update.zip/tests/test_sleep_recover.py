# -*- coding: utf-8 -*-
"""验收"睡一觉醒来自动恢复麦克风"。

模拟：①两次读之间隔了 3 分钟（说明睡了）②旧的音频流读不出来了（Windows 睡眠
之后经常这样）。要求：程序自己把麦克风重开，不清零、不崩，并且重新学环境噪声。
"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


class FakeStream:
    """假的音频流：可以设置成"读就报错"（模拟睡醒后设备坏了）。"""

    def __init__(self, dead: bool = False) -> None:
        self.dead = dead
        self.reads = 0

    def read(self, n):
        self.reads += 1
        if self.dead:
            raise OSError("设备睡死了（模拟）")
        return np.zeros((n, 1), dtype=np.float32), False

    def stop(self):
        pass

    def close(self):
        pass


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    stt = load_stt()
    logs: list[str] = []
    stt.syslog = lambda tag, text: logs.append(text)

    print("① 正常读的时候什么都不做")
    old = FakeStream()
    rec = stt.Recorder(old, 16000, 0.75, 30, device="USB Microphone")
    block = rec._read()
    check(block.shape[0] == rec.blocksize, "读出来一块音频")
    check(rec.stream is old, "没换流（不该乱动）")

    print("② 睡醒后流坏了：自动重开")
    dead = FakeStream(dead=True)
    fresh = FakeStream()
    rec = stt.Recorder(dead, 16000, 0.75, 30, device="USB Microphone")
    opened: list = []

    def fake_open(device=None, samplerate=16000):
        opened.append((device, samplerate))
        return fresh, 16000

    stt.open_stream = fake_open
    rec.noise_hist.extend([0.5] * 10)          # 装点旧噪声底，看看会不会被清掉
    rec._last_read = time.monotonic() - 180    # 假装刚睡了 3 分钟
    got = rec._read()
    check(rec.stream is fresh, "流换成新的了")
    check(bool(opened) and opened[0][0] == "USB Microphone",
          f"重开时用的还是原来的设备：{opened[0][0] if opened else '—'}")
    check(len(rec.noise_hist) <= 3, f"旧噪声底被清了（现在 {len(rec.noise_hist)} 条）")
    check(got.shape[0] == rec.blocksize, "重开之后能正常读到音频")
    check(any("麦克风" in s for s in logs), f"日志里记了一笔：{logs[-1] if logs else '（没记）'}")

    print("③ 睡醒但流还活着：不重开，只重学环境")
    alive = FakeStream()
    rec = stt.Recorder(alive, 16000, 0.75, 30, device="USB Microphone")
    rec.noise_hist.extend([0.5] * 10)
    rec._last_read = time.monotonic() - 180
    rec._read()
    check(rec.stream is alive, "流没被换掉")
    check(len(rec.noise_hist) <= 3, "但旧噪声底还是清了（环境变了要重新学）")

    print("④ 重开三次都不行：不会死循环，会把异常抛出来让外面处理")
    calls = {"n": 0}

    def bad_open(device=None, samplerate=16000):
        calls["n"] += 1
        raise OSError("还是打不开")

    stt.open_stream = bad_open
    rec = stt.Recorder(FakeStream(dead=True), 16000, 0.75, 30, device="X")
    raised = False
    try:
        rec._read()
    except Exception:
        raised = True
    check(raised, "抛出来了（不是死循环）")
    check(calls["n"] >= 2, f"试了 {calls['n']} 次重开")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
