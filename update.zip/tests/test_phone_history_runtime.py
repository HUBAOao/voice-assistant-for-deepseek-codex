# -*- coding: utf-8 -*-
"""Phone history filtering stays out of the STT entrypoint."""
from __future__ import annotations

import json
import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.phone_history_runtime import (
    PhoneHistoryDependencies,
    append_reply,
    build_phone_history,
    recent_replies,
)


class FakeHistory:
    def __init__(self):
        self.ingested = []

    def ingest(self, rows):
        self.ingested.extend(rows)

    def visible_records(self, rows):
        return rows


def main() -> int:
    with tempfile.TemporaryDirectory() as raw:
        root = Path(raw)
        syslog = root / "syslog.md"
        replies = root / "phone-replies.jsonl"
        last = root / "last-reply.json"
        syslog.write_text(
            "\n".join([
                "2026-10-23 20:00:00 [听] 你好",
                "2026-10-23 20:00:01 [听] 你好",
                "2026-10-23 20:00:02 [念] 收到",
                "2026-10-23 20:00:03 [复] 完整回答",
                "2026-10-23 20:00:04 [念] 完整回答",
                "2026-10-23 20:00:05 [流] 会话甲\x1f流式回答",
                "2026-10-23 20:00:06 [流终] 会话甲\x1f流式回答",
                "2026-10-23 20:00:07 [复] 流式回答",
                "2026-10-23 20:00:08 [发] 内部发送记录",
                "2026-10-23 20:00:09 [听] （手机）搜索词",
                "2026-10-23 20:00:10 [听] （没听清）",
            ]),
            encoding="utf-8",
        )
        history = FakeHistory()
        deps = PhoneHistoryDependencies(
            syslog_file=syslog,
            raw_replies_file=replies,
            last_reply_file=last,
            load_config=lambda: {
                "ack_text": "收到", "user_name": "", "name": "大肥鱼",
            },
            self_who=lambda _cfg: "",
            ack_phrases=(),
            phone_window_title=lambda: "当前会话",
            current_thread_name=lambda: "当前会话",
            chat_history=history,
            print_line=lambda *_args, **_kwargs: None,
            clock=lambda: datetime(2026, 10, 23, 20, 0, 11),
        )
        logs = []
        append_reply("会话甲", "完整回答", deps=deps, log=lambda *x: logs.append(x))
        last_record = json.loads(last.read_text(encoding="utf-8"))
        assert last_record["name"] == "会话甲"
        assert last_record["text"] == "完整回答"
        assert logs == [("复", "完整回答")]
        assert recent_replies(replies)[0]["text"] == "完整回答"

        rows = build_phone_history(0, "", deps=deps)
        texts = [row["text"] for row in rows]
        assert texts == ["你好", "完整回答", "流式回答", "搜索词"], texts
        assert [row["kind"] for row in rows] == ["me", "ai", "ai", "me"]
        assert rows[-1]["conv"] == "当前会话"
        assert history.ingested == rows

        filtered = build_phone_history(0, "搜索", deps=deps)
        assert [row["text"] for row in filtered] == ["搜索词"]

    print("test_phone_history_runtime: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
