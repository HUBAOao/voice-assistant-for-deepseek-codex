# -*- coding: utf-8 -*-
"""Foreground checks run in order and isolate individual failures."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_ticker import RuntimeTicker  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    now = [100.0]
    calls: list[str] = []
    reports: list[tuple[str, int, bool]] = []

    def broken() -> None:
        calls.append("broken")
        raise RuntimeError("temporary")

    def healthy() -> None:
        calls.append("healthy")

    ticker = RuntimeTicker(
        (("first", lambda: calls.append("first")), ("broken", broken),
         ("last", healthy)),
        clock=lambda: now[0],
        on_error=lambda failure: reports.append(
            (failure.stage, failure.count, failure.reported)
        ),
        repeat_after=30,
    )
    failures = ticker.run()
    check(calls == ["first", "broken", "healthy"],
          "一个周期检查失败后仍按顺序执行后面的任务")
    check(len(failures) == 1 and failures[0].stage == "broken",
          "失败结果带任务名和原异常")
    check(reports == [("broken", 1, True)],
          "首次失败只报告一次并保留计数")

    calls.clear()
    now[0] = 110.0
    ticker.run()
    check(ticker.failure_counts()["broken"] == 2 and len(reports) == 1,
          "短时间内重复失败继续计数，不刷日志")

    calls.clear()
    now[0] = 131.0
    ticker.run()
    check(reports[-1] == ("broken", 3, True),
          "重复失败到间隔后再次报告累计次数")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check(stt.count('("remote", remote.poll)') == 1,
          "主程序只装配一份前台周期任务")
    check(stt.count("runtime_ticker.run()") == 1
          and "def runtime_tick()" in stt,
          "hold 与 talk 共用同一个容错周期入口")
    input_loop = (APP / "voice_feature" / "runtime_input_loop.py").read_text(
        encoding="utf-8"
    )
    check("def checked_pause()" in input_loop
          and input_loop.split("def checked_pause()", 1)[1].split(
              "tracker_worker =", 1
          )[0].count("runtime_tick()") == 1
          and "runtime_tick=runtime_tick" in stt,
          "talk 暂停检查复用统一周期入口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
