# -*- coding: utf-8 -*-
"""Completion notifications expose private open and acknowledge actions."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APP = ROOT / "outputs" / "voice-to-text"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    service = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "NotifyService.java"
    ).read_text(encoding="utf-8")
    receiver = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "NotificationActionReceiver.java"
    ).read_text(encoding="utf-8")
    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")
    version_source = (APP / "version.py").read_text(encoding="utf-8")

    check("public static void dismissAlert(Context context)" in service
          and "nm.cancel(ALERT_ID)" in service
          and "stopSelf" not in service.split(
              "public static void dismissAlert", 1
          )[1].split("private Notification build", 1)[0],
          "收下提醒只清除完成通知，不停止后台监听")
    check('b.addAction(' in service
          and '"打开鳍舱"' in service
          and '"收下提醒"' in service,
          "通知栏保留打开与收下两个原生动作")
    check("openPendingIntent(context, 21)" in service
          and "PendingIntent.getBroadcast(" in service
          and "FLAG_IMMUTABLE" in service,
          "打开与收下动作使用明确的不可变 PendingIntent")
    check("ACTION_DISMISS_ALERT" in receiver
          and "NotifyService.dismissAlert(context)" in receiver,
          "收下动作只通过本应用私有接收器处理")
    check('android:name=".NotificationActionReceiver"' in manifest
          and 'android:exported="false"' in manifest,
          "通知动作接收器不向其他应用导出")
    check("PHONE_CHANGELOG" in version_source
          and "鳍舱第五十一轮通知栏快捷动作" in version_source,
          "手机端第五十一轮变更已登记")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
