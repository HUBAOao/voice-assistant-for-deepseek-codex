# -*- coding: utf-8 -*-
"""Preset persistence is separate from preset chip rendering."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.presets_mixin import OverlayPresetsMixin  # noqa: E402


class Probe(OverlayPresetsMixin):
    cfg = {}
    panel = None

    def __init__(self) -> None:
        self.data = {
            "wake_word": "大肥鱼",
            "presets": {
                "旧预设": {"wake_word": "小鱼"},
            },
        }
        self.flashes = []
        self.refreshes = 0

    def _preset_load(self):
        return dict(self.data)

    def _preset_write(self, data):
        self.data = dict(data)

    def _preset_note(self, _text):
        pass

    def collect(self):
        return {
            "wake_word": "新词",
            "presets": dict(self.data.get("presets") or {}),
        }

    def edit_text(self, _title, _initial, done):
        done("新预设")

    def refresh_presets(self):
        self.refreshes += 1

    def flash(self, text, _seconds):
        self.flashes.append(text)

def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    probe = Probe()
    probe.save_preset()
    check(probe.data["presets"]["新预设"]["wake_word"] == "新词"
          and "presets" not in probe.data["presets"]["新预设"],
          "保存预设会剔除嵌套的 presets 字段")
    probe.remove_preset("旧预设")
    check("旧预设" not in probe.data["presets"],
          "删除预设仍写回同一份配置")

    store = (
        APP / "overlay_feature" / "settings_presets_store_mixin.py"
    ).read_text(encoding="utf-8")
    actions = (
        APP / "overlay_feature" / "settings_presets_actions_mixin.py"
    ).read_text(encoding="utf-8")
    transfer = (
        APP / "overlay_feature" / "settings_presets_transfer_mixin.py"
    ).read_text(encoding="utf-8")
    ui = (APP / "overlay_feature" / "presets_mixin.py").read_text(
        encoding="utf-8"
    )
    check("class OverlayPresetsActionsMixin" in actions
          and all(
              marker in actions
              for marker in (
                  "def save_preset(",
                  "def apply_preset(",
                  "def remove_preset(",
              )
          ),
          "预设保存、套用和删除由独立动作边界承接")
    check("class OverlayPresetsTransferMixin" in transfer
          and all(
              marker in transfer
              for marker in (
                  "def export_presets(",
                  "def import_presets(",
              )
          ),
          "预设文件导入导出由独立传输边界承接")
    check("class OverlayPresetsStoreMixin(" in store
          and "OverlayPresetsActionsMixin" in store
          and "OverlayPresetsTransferMixin" in store,
          "历史预设存取类只组合两个业务边界")
    check("class OverlayPresetsMixin(OverlayPresetsStoreMixin)" in ui
          and "def refresh_presets(" in ui
          and "def save_preset(" not in ui,
          "历史 OverlayPresetsMixin 只保留组合与芯片渲染")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
