# -*- coding: utf-8 -*-
"""验收幻觉过滤：电视/音乐里编出来的"点赞 订阅 转发 歌手名"该丢，
你自己正常的短命令该留。"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
SRC = APP / "stt.py"
sys.path.insert(0, str(APP))

DROP = [
    "点赞", "转发", "订阅", "点赞订阅", "点赞 订阅 转发", "一键三连", "点个赞",
    "感谢观看", "谢谢大家", "谢谢大家的观看", "请大家点赞订阅转发打赏",
    "明镜与点点栏目", "本视频由字幕组提供", "自动生成字幕", "下期再见",
    "周杰伦 歌手", "关注我 别忘了一键三连", "更多精彩内容请关注",
    "www.bilibili.com", "https://www.baidu.com", "歌手：林俊杰",
]
KEEP = [
    "帮我查一下明天的天气", "打开计算器", "点赞了这条朋友圈", "记一下 明天买牛奶",
    "我关注的那个项目更新了", "放首歌听听", "取消", "大肥鱼", "停",
    "今天花了多少", "把那段念给我听", "订阅了一年会员", "明天早上八点提醒我开会",
    "专注二十五分钟", "周报",
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("stt_mod", SRC)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    bad = 0
    print("① 该丢的（电视/音乐里编出来的废话）")
    for text in DROP:
        if mod.is_hallucination(text):
            print(f"  ✓ 丢掉 {text!r}")
        else:
            bad += 1
            print(f"  ✗ 漏过 {text!r}")
    print("\n② 该留的（你自己的话）")
    for text in KEEP:
        if not mod.is_hallucination(text):
            print(f"  ✓ 保留 {text!r}")
        else:
            bad += 1
            print(f"  ✗ 误杀 {text!r}")
    print("\n③ 识别引擎把提示词吐回来（半截也要认出来）")
    echoes = ["以下是普通话的句子，请加标点。", "以下是普通话的句子", "以下是普通话的",
              "请加标点。", "加标点", "以下是普通话", "普通话的句子",
              "以下", "以下是", "请加"]          # 更碎的残字（今天就漏了「以下」）
    keep_after = {"取消 以下是普通话的": "取消", "打开计算器 请加标点": "打开计算器",
                  "取消 以下": "取消"}
    for text in echoes:
        got = mod.normalize_zh(text)
        if got == "":
            print(f"  ✓ 全去掉 {text!r}")
        else:
            bad += 1
            print(f"  ✗ 没去干净 {text!r} → {got!r}")
    for text, want in keep_after.items():
        got = mod.normalize_zh(text)
        if got == want:
            print(f"  ✓ 去完回声还剩你说的话 {text!r} → {got!r}")
        else:
            bad += 1
            print(f"  ✗ {text!r} → {got!r}（应该正好是「{want}」）")
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
