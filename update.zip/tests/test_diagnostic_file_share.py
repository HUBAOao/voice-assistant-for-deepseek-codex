# -*- coding: utf-8 -*-
"""Diagnostic sharing exports a real, bounded JSON file through Android."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
ANDROID = ROOT / "work" / "android-app"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    java = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "DiagnosticReport.java"
    ).read_text(encoding="utf-8")
    provider_path = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "DiagnosticShareProvider.java"
    )
    provider = provider_path.read_text(encoding="utf-8")
    activity = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "MainActivity.java"
    ).read_text(encoding="utf-8")
    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")
    management = (
        APP / "phone_feature" / "ui" / "management.js"
    ).read_text(encoding="utf-8")

    check("shareFile(Activity activity, String content)" in java,
          "诊断报告提供独立的文件分享入口")
    check("MAX_SHARED_BYTES = 2 * 1024 * 1024" in java
          and "body.length > MAX_SHARED_BYTES" in java,
          "分享文件限制在 2 MB 内")
    check('"diagnostic-share"' in java
          and "findeck-diagnostics-" in java
          and ".json" in java,
          "分享前把快照写入私有缓存中的真实 JSON 文件")
    check("Intent.ACTION_SEND" in java
          and 'send.setType("application/json")' in java
          and "Intent.EXTRA_STREAM" in java
          and "ClipData.newUri" in java
          and "FLAG_GRANT_READ_URI_PERMISSION" in java,
          "系统分享面板收到带临时读取授权的 JSON 文件")
    check("activity.runOnUiThread" in java,
          "分享面板启动切回 Android 主线程")
    check("当前文件" not in java and "token" not in java.lower(),
          "分享报告源码不包含手机令牌")

    check(provider_path.exists()
          and "extends ContentProvider" in provider
          and "com.hubao.voiceassistant.diagnostics" in provider,
          "专用只读 ContentProvider 提供诊断文件")
    check("findeck-diagnostics-[0-9]{8,}\\\\.json" in provider,
          "Provider 只接受严格命名的诊断 JSON")
    check("getCacheDir(), \"diagnostic-share\"" in provider
          and "ParcelFileDescriptor.MODE_READ_ONLY" in provider,
          "Provider 只读打开私有诊断分享目录")
    check('android:authorities="com.hubao.voiceassistant.diagnostics"' in manifest
          and 'android:name=".DiagnosticShareProvider"' in manifest
          and 'android:exported="false"' in manifest
          and 'android:grantUriPermissions="true"' in manifest,
          "清单登记内部只读分享提供器并允许临时授权")
    check("public String shareDiagnosticSnapshot()" in activity
          and "DiagnosticReport.shareFile" in activity,
          "网页桥直接拿到分享文件名和结果 JSON")
    check("JSON.parse(VoiceApp.shareDiagnosticSnapshot()" in management
          and "真实 JSON 文件" in management,
          "真机页区分真实文件分享与旧的纯文本分享")

    apk = APP / "语音助手-手机端.apk"
    check(apk.exists(), "手机安装包存在")
    if apk.exists():
        dex = b"".join(
            item
            for name in zipfile.ZipFile(apk).namelist()
            if name.endswith(".dex")
            for item in [zipfile.ZipFile(apk).read(name)]
        )
        for marker, label in (
            (b"DiagnosticShareProvider", "诊断分享 Provider"),
            (b"diagnostic-share", "私有分享目录"),
            (b"findeck-diagnostics-", "诊断文件名"),
            (b"ClipData", "URI 剪贴数据"),
            (b"newUri", "系统 URI 封装"),
            (b"createChooser", "系统分享面板"),
        ):
            check(marker in dex, f"DEX 包含{label}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
