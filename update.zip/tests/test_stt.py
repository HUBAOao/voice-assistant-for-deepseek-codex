# -*- coding: utf-8 -*-
"""用一段合成的中文语音测试识别链路（模型加载 / 显卡 / 中文输出）。"""
import sys
import time
import wave
from pathlib import Path

import numpy as np

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
sys.path.insert(0, str(ROOT / "outputs" / "voice-to-text"))
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import stt  # noqa: E402

wav = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "work" / "stt-sample.wav")
with wave.open(wav, "rb") as fh:
    sr = fh.getframerate()
    raw = fh.readframes(fh.getnframes())
audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
audio = stt.resample_to_16k(audio, sr)
print(f"音频 {len(audio)/16000:.2f}s")

t0 = time.time()
tr = stt.Transcriber("small", "auto", None, "zh")
print(f"引擎 {tr.device}/{tr.compute_type}，加载 {time.time()-t0:.1f}s")

t1 = time.time()
text = tr.transcribe(audio)
print(f"识别结果：{text}")
print(f"识别耗时 {time.time()-t1:.2f}s")

stt.append_log(ROOT / "outputs" / "voice-to-text" / "transcripts.md", text)
print("剪贴板：", stt.copy_to_clipboard(text))
