# -*- coding: utf-8 -*-
"""Keep the next refactor from silently rebuilding the giant single-file design."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"

LIMITS = {
    "stt.py": 3550,
    "overlay.py": 1500,
    "phone_link.py": 760,
    "phone_page.html": 3100,
    "voice_feature/talk_state.py": 200,
    "voice_feature/send_verification.py": 80,
    "voice_feature/delivery_pipeline.py": 110,
    "voice_feature/mute_commands.py": 70,
    "voice_feature/audio_capture.py": 60,
    "voice_feature/local_command_orchestrator.py": 60,
    "voice_feature/local_command_assembly.py": 520,
    "voice_feature/talk_capture.py": 170,
    "voice_feature/runtime_lifecycle.py": 120,
    "voice_feature/instance_guard.py": 180,
    "voice_feature/runtime_workers.py": 160,
    "voice_feature/runtime_teardown.py": 120,
    "voice_feature/runtime_startup.py": 140,
    "voice_feature/runtime_bootstrap.py": 140,
    "voice_feature/runtime_cli_modes.py": 180,
    "voice_feature/runtime_audio_setup.py": 140,
    "voice_feature/runtime_microphone_setup.py": 120,
    "voice_feature/runtime_input_loop.py": 160,
    "voice_feature/runtime_capture_setup.py": 150,
    "voice_feature/runtime_foreground_assembly.py": 260,
    "voice_feature/phone_bridge_runtime.py": 160,
    "voice_feature/phone_schedule_runtime.py": 180,
    "voice_feature/phone_history_runtime.py": 360,
    "voice_feature/phone_status_runtime.py": 150,
    "voice_feature/phone_command_runtime.py": 220,
    "voice_feature/maintenance_runtime.py": 190,
    "voice_feature/diary_tutorial_runtime.py": 160,
    "voice_feature/desktop_runtime_assembly.py": 320,
    "voice_feature/phone_runtime_assembly.py": 330,
    "voice_feature/runtime_run_assembly.py": 80,
    "voice_feature/runtime_reminder_assembly.py": 150,
    "voice_feature/runtime_config_assembly.py": 180,
    "voice_feature/runtime_control_assembly.py": 180,
    "voice_feature/runtime_interaction_assembly.py": 300,
    "voice_feature/runtime_delivery_assembly.py": 150,
    "voice_feature/runtime_reply_assembly.py": 120,
    "voice_feature/runtime_send_gate_assembly.py": 150,
    "voice_feature/runtime_periodic_assembly.py": 150,
    "voice_feature/runtime_command_gate_assembly.py": 280,
    "voice_feature/runtime_wake_gate_assembly.py": 190,
    "voice_feature/runtime_gate_assembly.py": 80,
    "voice_feature/runtime_gate_wiring.py": 170,
    "voice_feature/runtime_session_state.py": 160,
    "voice_feature/runtime_startup_callbacks.py": 150,
    "voice_feature/runtime_utterance_dispatch.py": 100,
    "voice_feature/runtime_entry_pipeline.py": 140,
    "voice_feature/runtime_main_foreground.py": 220,
    "voice_feature/ambient_features.py": 340,
    "voice_feature/daily_features.py": 140,
    "voice_feature/audio_loop.py": 130,
    "voice_feature/runtime_ticker.py": 100,
    "voice_feature/cli_options.py": 190,
    "voice_feature/microphone_recovery.py": 180,
    "voice_feature/runtime_service_assembly.py": 410,
    "voice_feature/runtime_utterance_assembly.py": 460,
    "phone_feature/phone_ingress.py": 140,
    "overlay_feature/settings_actions_mixin.py": 30,
    "overlay_feature/settings_device_actions_mixin.py": 180,
    "overlay_feature/settings_device_list_mixin.py": 210,
    "overlay_feature/settings_device_groups_mixin.py": 180,
    "overlay_feature/settings_access_log_mixin.py": 140,
    "overlay_feature/settings_remote_qr_mixin.py": 180,
    "overlay_feature/settings_device_views_mixin.py": 30,
    "overlay_feature/settings_uninstall_mixin.py": 40,
    "overlay_feature/settings_uninstall_actions_mixin.py": 80,
    "overlay_feature/settings_uninstall_dialog_mixin.py": 180,
    "overlay_feature/settings_product_actions_mixin.py": 70,
    "overlay_feature/settings_site_publish_mixin.py": 170,
    "overlay_feature/settings_qr_mixin.py": 180,
    "overlay_feature/qr_presentation.py": 60,
    "overlay_feature/qr_save_dialog.py": 70,
    "overlay_feature/settings_devices_mixin.py": 30,
    "overlay_feature/settings_collect_mixin.py": 130,
    "overlay_feature/settings_feature_collect_mixin.py": 100,
    "overlay_feature/settings_persistence_mixin.py": 120,
    "overlay_feature/settings_basic_mixin.py": 30,
    "overlay_feature/settings_identity_mixin.py": 100,
    "overlay_feature/settings_response_mixin.py": 80,
    "overlay_feature/settings_wake_mixin.py": 30,
    "overlay_feature/settings_wake_levels_mixin.py": 140,
    "overlay_feature/settings_wake_test_mixin.py": 60,
    "overlay_feature/settings_caption_mixin.py": 100,
    "overlay_feature/panel_controls.py": 260,
    "overlay_feature/settings_delivery_mixin.py": 40,
    "overlay_feature/settings_send_mixin.py": 80,
    "overlay_feature/settings_connection_mixin.py": 150,
    "overlay_feature/settings_recognition_mixin.py": 120,
    "overlay_feature/settings_features_mixin.py": 180,
    "overlay_feature/settings_reminders_mixin.py": 100,
    "overlay_feature/settings_appearance_mixin.py": 190,
    "overlay_feature/settings_text_input_mixin.py": 80,
    "overlay_feature/settings_preference_chips_mixin.py": 120,
    "overlay_feature/settings_background_size_mixin.py": 100,
    "overlay_feature/settings_update_mixin.py": 40,
    "overlay_feature/settings_update_check_mixin.py": 80,
    "overlay_feature/settings_update_dialog_mixin.py": 180,
    "overlay_feature/settings_update_dialog_actions_mixin.py": 100,
    "overlay_feature/settings_remote_actions_mixin.py": 180,
    "overlay_feature/settings_remote_clipboard_mixin.py": 90,
    "overlay_feature/settings_remote_network_mixin.py": 120,
    "overlay_feature/settings_remote_status_mixin.py": 130,
    "overlay_feature/settings_maintenance_mixin.py": 150,
    "overlay_feature/settings_memory_panel_mixin.py": 80,
    "overlay_feature/settings_data_panel_mixin.py": 120,
    "overlay_feature/settings_uninstall_panel_mixin.py": 60,
    "overlay_feature/settings_backup_mixin.py": 120,
    "overlay_feature/settings_memory_mixin.py": 80,
    "overlay_feature/settings_memory_viewer_mixin.py": 160,
    "overlay_feature/settings_navigation_mixin.py": 110,
    "overlay_feature/settings_onboarding_mixin.py": 110,
    "overlay_feature/settings_shell_mixin.py": 120,
    "overlay_feature/settings_footer_mixin.py": 120,
    "overlay_feature/settings_visuals_mixin.py": 150,
    "overlay_feature/settings_visual_palette_mixin.py": 100,
    "overlay_feature/settings_visual_geometry_mixin.py": 100,
    "overlay_feature/settings_layout_mixin.py": 170,
    "overlay_feature/settings_audio_mixin.py": 160,
    "overlay_feature/settings_voice_mixin.py": 230,
    "overlay_feature/settings_voice_drawer_mixin.py": 130,
    "overlay_feature/settings_voice_preview_mixin.py": 80,
    "overlay_feature/settings_presets_store_mixin.py": 180,
    "overlay_feature/settings_presets_actions_mixin.py": 100,
    "overlay_feature/settings_presets_transfer_mixin.py": 130,
    "phone_feature/request_auth.py": 130,
    "phone_feature/route_dispatch.py": 210,
    "features/plugin_registry.py": 900,
    "features/plugin_signing.py": 420,
    "features/plugin_market.py": 360,
    "phone_feature/ui/plugins.js": 340,
    "phone_feature/ui/management.js": 730,
    "phone_feature/ui/native-files.js": 180,
}

FORBIDDEN = {
    "voice_feature": {"stt", "overlay", "phone_link"},
    "overlay_feature": {"overlay"},
    "features": {"stt", "overlay", "phone_link"},
    "core": {"stt", "overlay", "phone_link"},
}


def imported_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            found.add(node.module.split(".", 1)[0])
    return found


def main() -> int:
    bad = []
    for relative, limit in LIMITS.items():
        path = APP / relative
        lines = len(path.read_text(encoding="utf-8").splitlines())
        ok = lines <= limit
        print(f"  {'✓' if ok else '✗'} {relative}: {lines} / {limit} 行")
        if not ok:
            bad.append(f"{relative} 超过 {limit} 行")
    for folder, forbidden in FORBIDDEN.items():
        for path in sorted((APP / folder).rglob("*.py")):
            imports = imported_modules(path)
            hit = sorted(imports & forbidden)
            relative = path.relative_to(APP).as_posix()
            ok = not hit
            print(f"  {'✓' if ok else '✗'} {relative}: 反向依赖 {hit or '无'}")
            if not ok:
                bad.append(f"{relative} 反向依赖 {hit}")
    if bad:
        print("\n模块边界失败：")
        for item in bad:
            print("  - " + item)
        return 1
    print("test_module_boundaries: PASS")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    raise SystemExit(main())
