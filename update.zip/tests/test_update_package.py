# -*- coding: utf-8 -*-
"""验收更新包：把"旧版安装目录"更新到新版，数据必须一个都不能丢。全在沙箱里跑。"""
from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
SRC = ROOT / "outputs" / "voice-to-text"
UPD_ZIPS = sorted((ROOT / "outputs").glob("语音助手-更新包-v*.zip"))
UPD_ZIP = UPD_ZIPS[-1] if UPD_ZIPS else Path("（没有更新包）")
S = ROOT / "work" / "update-test"


def make_old_install() -> Path:
    """造一个"已经装过的旧版本"：程序文件是老的，数据是用户的。"""
    d = S / "install"
    shutil.rmtree(d, ignore_errors=True)
    (d / ".venv" / "Scripts").mkdir(parents=True)
    (d / "models").mkdir(parents=True)
    (d / "导出").mkdir(parents=True)
    (d / ".venv" / "Scripts" / "pythonw.exe").write_bytes(b"MZ" + b"\0" * 200)
    (d / "models" / "large-v3-turbo.bin").write_bytes(b"\0" * 5000)
    (d / "stt.py").write_text("# 旧版的主程序\n", encoding="utf-8")
    (d / "overlay.py").write_text("# 旧版的浮窗\n", encoding="utf-8")
    (d / "version.py").write_text("APP_VERSION='1.10'\nUPDATES=10\n", encoding="utf-8")
    (d / "config.json").write_text(json.dumps(
        {"name": "大肥鱼", "wake_word": "大肥鱼", "我的私事": "别动我"},
        ensure_ascii=False), encoding="utf-8")
    (d / "transcripts.md").write_text("# 我说过的话\n- 别删我\n", encoding="utf-8")
    (d / "notes.md").write_text("- 买牛奶\n", encoding="utf-8")
    (d / "ledger.json").write_text('{"买菜": 30}', encoding="utf-8")
    (d / "导出" / "语音助手数据-20261007-0252.zip").write_bytes(b"PK\x03\x04old")
    return d


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 把更新包解压出来（模拟下载后解压）")
    up = S / "update"
    shutil.rmtree(up, ignore_errors=True)
    up.mkdir(parents=True)
    with zipfile.ZipFile(UPD_ZIP) as z:
        z.extractall(up)
    names = [p.name for p in up.iterdir()]
    check("更新.cmd" in names and "apply_update.py" in names, "更新包里有 更新.cmd 和更新器")
    check("stt.py" in names and "overlay.py" in names, "更新包里带着程序本体")

    inst = make_old_install()
    print("② 更新前旧版本 =",
          (inst / "version.py").read_text(encoding="utf-8").splitlines()[0])

    print("③ 演练（--dry-run，什么都不该动）")
    r = subprocess.run([sys.executable, str(up / "apply_update.py"), "--dry-run",
                        "--dir", str(inst)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    check("演练" in r.stdout, "说了这是演练")
    check((inst / "stt.py").read_text(encoding="utf-8").startswith("# 旧版"),
          "演练后程序文件还是旧的")

    print("④ 真的更新")
    r = subprocess.run([sys.executable, str(up / "apply_update.py"), "--yes",
                        "--no-restart", "--dir", str(inst)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    for line in r.stdout.splitlines():
        if any(k in line for k in ("更新完成", "备份", "→")):
            print("   ", line.strip())
    check((inst / "stt.py").read_bytes() == (SRC / "stt.py").read_bytes(),
          "主程序更新成新版（逐字节一致）")
    check((inst / "overlay.py").read_bytes() == (SRC / "overlay.py").read_bytes(),
          "浮窗也更新了")
    check((inst / "assets" / "default-bg.jpg").exists(), "素材也带过去了")
    check((inst / "说明书.html").exists(), "说明书也带过去了")

    print("⑤ 用户的东西一个都不能少")
    cfg = json.loads((inst / "config.json").read_text(encoding="utf-8"))
    check(cfg.get("我的私事") == "别动我", "设置没被动（自定义的键还在）")
    check((inst / "transcripts.md").read_text(encoding="utf-8").strip().endswith("别删我"),
          "聊天记录还在")
    check((inst / "notes.md").exists() and (inst / "ledger.json").exists(), "便签和记账还在")
    check((inst / ".venv" / "Scripts" / "pythonw.exe").exists(), "运行环境没被删")
    check((inst / "models" / "large-v3-turbo.bin").exists(), "语音模型还在")
    check((inst / "导出" / "语音助手数据-20261007-0252.zip").exists(), "「导出」文件夹没动")

    print("⑥ 能退回去")
    bak = inst / "更新备份-v1.10"
    check(bak.is_dir(), f"生成了备份目录 {bak.name}")
    check((bak / "stt.py").read_text(encoding="utf-8").startswith("# 旧版"),
          "备份里是旧版文件（能拷回去）")
    check((inst / "更新日志.txt").exists(), "写了更新日志")

    print("⑦ 找安装位置：认「位置纸条」")
    spec = importlib.util.spec_from_file_location("au", up / "apply_update.py")
    au = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(au)
    marker = S / "appdata" / "VoiceAssistant" / "install_path.txt"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(inst), encoding="utf-8")
    au.MARKER = marker
    check(au.from_marker() == inst, f"靠纸条找到了：{au.from_marker()}")
    marker.write_text(str(S / "不存在的目录"), encoding="utf-8")
    check(au.from_marker() is None, "纸条里的路径不对时会忽略（不会瞎更新）")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
