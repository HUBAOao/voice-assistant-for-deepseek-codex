# -*- coding: utf-8 -*-
"""验收「多个对话的回答排队念」：一个念完再念下一个，绝不重叠；
只有"同时在排队的回答不止一个"时才报对话名（多少个对话都适用）。"""
from __future__ import annotations

import importlib.util
import sys
import threading
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


class FakeSpeak:
    """假装在念：每次花 0.15 秒，同时记录有没有两条叠在一起。"""

    def __init__(self) -> None:
        self.calls = []
        self.lock = threading.Lock()
        self.busy = False
        self.overlaps = 0

    def __call__(self, text: str) -> None:
        with self.lock:
            if self.busy:
                self.overlaps += 1
            self.busy = True
        time.sleep(0.15)
        with self.lock:
            self.calls.append(text)
            self.busy = False


def make_doc(chat: str, sent: str, first: str = "") -> str:
    """照真窗口排版：侧边栏（带当前对话名）+ 聊天区 + 输入框。"""
    return (f"一堆界面字\n新聊天\n置顶\n置顶选项\n学习 UV5 蓝图知识\n取消置顶聊天\n归档聊天\n"
            f"{chat}\n取消置顶聊天\n归档聊天\n项目\n最近\n"
            f"你说：\n{sent}\n23:40\n\ufffc\nChatGPT 说：\n{first}\n"
            f"最新一条回复\n随心输入\n添加文件等内容\n完全访问\n")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("rr", APP / "reply_reader.py")
    rr = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rr)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 猜当前对话名（从真窗口的排版里）")
    name = rr.guess_chat_name(make_doc("项目甲的对话", "问一句"), "ChatGPT")
    check(name == "项目甲的对话", f"猜出来是：{name!r}")
    check(rr.guess_chat_name("", "ChatGPT") == "ChatGPT", "读不到就退回窗口标题")

    print("\n② 两个对话的回答：排队念 + 都报名字")
    states = {111: {"sent": "问题甲", "first": ""},
              222: {"sent": "问题乙", "first": ""}}
    chats = {111: "项目甲的对话", 222: "项目乙的对话"}
    rr.document_text = lambda hwnd, limit=None, timeout=None: make_doc(
        chats[hwnd], states[hwnd]["sent"], states[hwnd]["first"])
    mouth = FakeSpeak()
    reader = rr.ReplyReader(speak_func=mouth, record=lambda t: None, poll_seconds=0.05)
    reader.watch(111, "问题甲", title="ChatGPT")
    reader.watch(222, "问题乙", title="ChatGPT")
    time.sleep(0.3)
    states[111]["first"] = "甲这边的回答：插件源码写好了，下一步要编译链。"
    states[222]["first"] = "乙这边的回答：蓝图节点已经连好了，可以直接试运行。"
    for _ in range(40):
        time.sleep(0.05)
    joined = " | ".join(mouth.calls)
    print("   念了：", joined[:130])
    check(mouth.overlaps == 0, f"没有重叠（重叠次数 {mouth.overlaps}）")
    check("插件源码写好了" in joined and "蓝图节点已经连好了" in joined, "两条回答都念了")
    check("这条回答是" in joined, "报了对话名（同时有两条在排队）")

    print("\n③ 只有一条回答：不报名字（不要每次都加）")
    states2 = {333: {"sent": "问题丙", "first": ""}}
    rr.document_text = lambda hwnd, limit=None, timeout=None: make_doc(
        "项目丙的对话", states2[333]["sent"], states2[333]["first"])
    mouth2 = FakeSpeak()
    reader2 = rr.ReplyReader(speak_func=mouth2, record=lambda t: None, poll_seconds=0.05)
    reader2.watch(333, "问题丙", title="ChatGPT")
    time.sleep(0.3)
    states2[333]["first"] = "丙这边的回答：都弄好了。"
    for _ in range(30):
        time.sleep(0.05)
    joined2 = " | ".join(mouth2.calls)
    print("   念了：", joined2[:100])
    check("都弄好了" in joined2, "回答念了")
    check("这条回答是" not in joined2, "单独一条没报名字")

    reader.stop()
    reader2.stop()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
