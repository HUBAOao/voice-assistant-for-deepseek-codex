# -*- coding: utf-8 -*-
"""验收「手机上切的是我和你的会话，不是电脑窗口」。

用户澄清过：他说的"对话窗口"是 **Codex 里的会话**（语音助手相关 / 学习 UV5 蓝图 /
能否同时处理多个项目…），要自动检测、实时同步到手机，点一下就切过去。
"""
from __future__ import annotations

import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import codex_threads as ct

    print("① 能自动读出 Codex 里的会话")
    rows = ct.list_threads()
    print("     读到：", [r["name"] for r in rows])
    check(len(rows) >= 1, f"读到 {len(rows)} 个会话")
    check(all(r["name"].strip() for r in rows), "每个都有名字")
    check(all(len(r["name"]) < 120 for r in rows), "名字都是人起的那种（不是整段聊天内容）")
    opened = [r["name"] for r in rows if r["current"]]
    check(len(opened) <= 1, f"标出「电脑上正开着」的是：{opened or '（没标上）'}（最多一个）")

    print("② 找会话/切换（干跑，不真点）")
    if rows:
        target = rows[0]["name"]
        ok, msg = ct.open_thread(target, dry_run=True)
        check(ok, f"能定位到「{target}」并算出要点哪里（{msg}）")
    ok, msg = ct.open_thread("这个会话肯定不存在-ZZZ", dry_run=True)
    check(not ok, f"不存在的会话会明确说找不到（{msg[:24]}）")

    print("③ 手机上拿到的就是这些会话")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8819)
    link.get_windows = ct.list_threads
    link.get_target = lambda: ""
    link.on_target = lambda name: (True, name or "自动")
    if not link.start():
        check(False, "手机入口起不来")
        return 1
    try:
        time.sleep(0.2)
        with urllib.request.urlopen(
                f"http://127.0.0.1:8819/api/windows?k={link.token}", timeout=20) as r:
            d = json.loads(r.read().decode("utf-8"))
        titles = [w["title"] for w in d.get("windows") or []]
        print("     手机看到：", titles)
        check(len(titles) == len(rows), "数量和电脑上读到的会话一样")
        check(all(isinstance(w.get("current"), bool) for w in d.get("windows") or []),
              "每个会话都带「是不是电脑上正开着」的标记")
        check("chosen" in d, "也告诉手机我选的是哪个")
    finally:
        link.stop()

    print("④ 页面上那格子改叫「对话会话」了")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("对话会话" in page, "＋ 菜单里写的是「对话会话」")
    check("这是**我和你的会话**" in page or "我和你的会话" in page,
          "说明里写清楚了这是「和你的会话」，不是电脑窗口")
    check("实时同步" in page or "自动读出来" in page, "页面上说了会自动读、实时同步")

    print("⑤ 发送时的目标 = Codex 窗口（会话靠点侧栏切）")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check("codex_threads.open_thread(want)" in src, "手机选了会话就先切过去再发")
    check("codex_threads.list_threads" in src, "手机那边挂的就是这个会话列表")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
