# -*- coding: utf-8 -*-
"""Desktop service assembly keeps legacy order, flags and entry aliases."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.desktop_runtime_assembly import (  # noqa: E402
    DesktopRuntimeDependencies,
    assemble_desktop_runtime,
)


class Status:
    def __init__(self, hint: str) -> None:
        self.hint = hint
        self.calls = []

    def set(self, state, **kwargs):
        self.calls.append((state, kwargs))


class Diary:
    def __init__(self, status) -> None:
        self.state = {"on": False, "step": 0}
        self.status = status

    def tutorial_say(self, step):
        return step

    def say_diary(self):
        return "日记"

    def maybe_night_diary(self):
        return None


def ambient_method(*_args, **_kwargs):
    return None


class Ambient:
    focus_active = ambient_method
    focus_left = ambient_method
    focus_start = ambient_method
    focus_stop = ambient_method
    focus_tick = ambient_method
    read_ledger = ambient_method
    add_note = ambient_method
    add_ledger = ambient_method
    say_ledger = ambient_method
    say_notes = ambient_method
    game_start = ambient_method
    do_pick = ambient_method
    game_feed = ambient_method
    brief_now = ambient_method
    transform = ambient_method


class Maintenance:
    def __init__(self, status, overlay) -> None:
        self.status = status
        self.overlay = overlay

    def self_check(self, verbose=True):
        return verbose

    do_export = ambient_method
    do_import = ambient_method
    do_diagnose = ambient_method
    do_update = ambient_method
    apply_update_now = ambient_method
    undo_last = ambient_method
    type_into_focused = ambient_method


class Lifecycle:
    def __init__(self) -> None:
        self.jobs = []

    def start_daemon(self, name, target, **kwargs):
        self.jobs.append((name, target, kwargs))


class Process:
    @staticmethod
    def poll():
        return None


def dependencies(root: Path, **overrides):
    lifecycle = Lifecycle()
    events = []
    config = {
        "overlay_enabled": True,
        "pet_enabled": True,
        "tray_enabled": True,
    }
    values = dict(
        status_factory=Status,
        hint="说「大肥鱼」唤醒",
        config=config,
        wake_words=["大肥鱼"],
        speak=events.append,
        syslog=lambda tag, text: events.append((tag, text)),
        beep=lambda _frequency, _milliseconds: None,
        arm_followup=lambda: None,
        award=lambda _kind: None,
        load_config=lambda: dict(config),
        save_config=lambda data: events.append(("save", dict(data))),
        diary_summary=lambda _day: "今天你跟我说了两句话。",
        read_achievements=lambda: {"diary_day": ""},
        write_achievements=lambda data: events.append(("wins", dict(data))),
        diary_file=root / "diary.md",
        now=lambda: __import__("datetime").datetime(2026, 10, 23, 22, 0),
        notes_file=root / "notes.md",
        ledger_file=root / "ledger.json",
        weather_line=lambda city: f"{city}晴",
        private={},
        last_sent={"text": "", "at": 0.0},
        transcriber=object(),
        target=None,
        current_target_hwnd=lambda: 0,
        query_device=lambda _device: {"max_input_channels": 1},
        device=None,
        find_window=lambda _target: (0, ""),
        clipboard_text=lambda: "",
        copy_to_clipboard=lambda _text: True,
        paste_clipboard=lambda *_args, **_kwargs: True,
        paste_into=lambda *_args, **_kwargs: True,
        focus_window=lambda _hwnd: True,
        send_ctrl_z=lambda: None,
        export_data=lambda: None,
        import_data=lambda: None,
        diag_pack=lambda: None,
        newer_package=lambda: None,
        apply_update=lambda _path: 0,
        lifecycle=lifecycle,
        crash_file=root / "last-crash.txt",
        no_overlay=False,
        feed=None,
        test_paste=False,
        start_overlay=lambda: events.append("overlay") or Process(),
        start_pet=lambda: events.append("pet") or Process(),
        start_watchdog=lambda: events.append("watchdog"),
        start_tray=lambda: events.append("tray"),
        emit=lambda text: events.append(text),
    )
    values.update(overrides)
    result = DesktopRuntimeDependencies(**values)
    return result, events


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_desktop_assembly_") as raw:
        root = Path(raw)
        crash = root / "last-crash.txt"
        crash.write_text("{}", encoding="utf-8")
        deps, events = dependencies(root, crash_file=crash)
        runtime = assemble_desktop_runtime(deps)

        check(runtime.status.calls[0] == ("starting", {}),
              "先写 starting 状态再拉起悬浮窗")
        check(events[:2] == ["overlay", "pet"],
              "悬浮窗和桌宠按原顺序启动")
        check(runtime.maintenance.deps.overlay_running is True,
              "维护运行时拿到本次实际悬浮窗实例")
        check(events.count(("检", "上次异常退出，本次已恢复")) == 1
              and "上次我出了点问题，现在恢复了" in events,
              "崩溃标记只处理一次并保留恢复提示")
        check(not crash.exists(), "恢复后清除旧崩溃标记")
        check(deps.lifecycle.jobs[0][0] == "startup-self-check",
              "启动自检通过同一生命周期启动")
        check(deps.lifecycle.jobs[0][2] == {"delay": 7},
              "启动自检仍延迟 7 秒")
        check("watchdog" in events and "tray" in events,
              "看门狗和托盘保持原启停条件")
        check(callable(runtime.tutorial_say)
              and callable(runtime.say_diary),
              "旧日记教程入口由装配结果继续暴露")
        check(callable(runtime.focus_start)
              and callable(runtime.type_into_focused),
              "旧伴随与维护入口名保持")

        quiet = assemble_desktop_runtime(
            dependencies(
                root,
                crash_file=root / "missing-crash.txt",
                no_overlay=True,
            )[0]
        )
        check(quiet.overlay is None and quiet.pet_proc == {"p": None},
              "隐藏运行不上悬浮窗和桌宠")
        check(not quiet.interactive, "隐藏运行明确标记为非交互装配")

        hidden = DesktopRuntimeDependencies(
            **{
                **dependencies(
                    root,
                    crash_file=root / "missing-crash.txt",
                )[0].__dict__,
                "config": {
                    "overlay_enabled": False,
                    "pet_enabled": True,
                    "tray_enabled": False,
                },
            }
        )
        hidden_runtime = assemble_desktop_runtime(hidden)
        check(hidden_runtime.overlay is None,
              "设置关闭悬浮窗后不偷偷启动")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "desktop_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    check("desktop = assemble_desktop_runtime(" in source,
          "main() 只调用桌面运行时装配入口")
    check("runtime_lifecycle.start_daemon(\n            \"startup-self-check\""
          not in source, "main() 不再内联启动自检的装配")
    check("class DesktopRuntimeAssembly" in module
          and "def assemble_desktop_runtime(" in module,
          "桌面运行时装配在独立模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
