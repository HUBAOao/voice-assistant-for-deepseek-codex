# -*- coding: utf-8 -*-
"""Android photo selection stays user-triggered and permission-light."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APP = ROOT / "outputs" / "voice-to-text"
SOURCE = (
    ANDROID / "java" / "com" / "hubao" / "voiceassistant"
    / "MainActivity.java"
)
MANIFEST = ANDROID / "AndroidManifest.xml"
PAGE = APP / "phone_page.html"
SCRIPT = APP / "phone_feature" / "ui" / "native-files.js"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = SOURCE.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    script = SCRIPT.read_text(encoding="utf-8")

    check("MediaStore.ACTION_PICK_IMAGES" in source,
          "Android 13+ 使用系统照片选择器")
    check("MediaStore.EXTRA_PICK_IMAGES_MAX" in source
          and "MAX_SHARED_ATTACHMENTS" in source,
          "相册选择沿用一次最多 6 个附件的上限")
    check("Build.VERSION.SDK_INT >= 33" in source
          and "Intent.ACTION_OPEN_DOCUMENT" in source,
          "旧版安卓回退到仅图片的系统文件选择器")
    picker = source[
        source.index("private void openPhotoPicker()"):
        source.index("private void queuePickedPhotos(")
    ]
    check("checkSelfPermission" not in picker
          and "requestPermissions" not in picker,
          "照片选择不申请运行时媒体权限")
    check("READ_MEDIA_IMAGES" not in manifest
          and "READ_EXTERNAL_STORAGE" not in manifest,
          "清单没有引入媒体库或全盘读取权限")
    check("queueSharedAttachment(uri, mime)" in source
          and "pumpSharedAttachment()" in source,
          "选中的图片只进入现有待发送附件队列")
    queue = source[
        source.index("private void queuePickedPhotos("):
        source.index("private void saveSystemDocument(String suggestedName, String content)")
    ]
    check("send(" not in queue
          and "finish()" not in queue
          and "press_enter" not in queue,
          "原生相册选择不会自动发送或关闭页面")
    check('id="acceptPhotoOpen"' in page
          and "openSystemPhotoPicker" in script,
          "真机验收页通过明确点按调用相册选择器")
    check("点发送才会发出" in script,
          "页面明确说明图片仍需用户确认发送")

    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for symbol in (
            "openSystemPhotoPicker",
            "openPhotoPicker",
            "queuePickedPhotos",
            "android.provider.action.PICK_IMAGES",
            "android.provider.extra.PICK_IMAGES_MAX",
            "REQ_PHOTO_PICK",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
