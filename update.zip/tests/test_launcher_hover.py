# -*- coding: utf-8 -*-
"""验收启动选择框：鼠标划过每一张卡片都不能报错（历史上这里把画布图形 id 当控件用了）。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import launcher  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    errors: list[str] = []
    c = launcher.Chooser()
    c.root.report_callback_exception = lambda t, v, tb: errors.append(f"{t.__name__}: {v}")
    for _ in range(30):
        c.root.update()
        time.sleep(0.01)
    print(f"卡片：{list(c.cards)}；当前选中：{c.mode}")
    bad = 0
    for value in c.cards:
        for entering in (True, False):
            try:
                c.hover(value, entering)
            except Exception as exc:  # noqa: BLE001
                bad += 1
                print(f"  ✗ hover({value}, {entering}) 报错：{exc}")
        c.select(value)
        for _ in range(6):
            c.root.update()
        for entering in (True, False):
            try:
                c.hover(value, entering)
            except Exception as exc:  # noqa: BLE001
                bad += 1
                print(f"  ✗ 选中 {value} 之后再 hover 报错：{exc}")
    # 真·鼠标划过（事件真的走一遍 Tk 的绑定）
    for value, (card, *_rest) in c.cards.items():
        card.event_generate("<Enter>")
        card.event_generate("<Leave>")
        for _ in range(6):
            c.root.update()
    for _ in range(20):
        c.root.update()
        time.sleep(0.01)
    print("鼠标划过所有卡片：", "✓ 没报错" if not errors and not bad else f"✗ {errors[:3]}")
    c.root.destroy()
    ok = not errors and not bad
    print("\n启动选择框 hover：", "✓ 正常" if ok else "✗ 有问题")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
