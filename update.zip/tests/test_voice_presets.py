# -*- coding: utf-8 -*-
"""验收音色预设：变调（卡通高音/闷低音）和特效（机器人/回音/电台）都真的作用到音频上。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    import say

    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 变调：+34Hz（卡通高音）/ -30Hz（闷低音）都能拿到音频")
    got = {}
    for pitch in ("+0Hz", "+34Hz", "-30Hz"):
        say.PITCH[0] = pitch
        t0 = time.time()
        mp3 = say.edge_mp3("测试一二三。", "zh-CN-XiaoyiNeural", "+8%")
        audio, sr = say.decode_audio(mp3)
        got[pitch] = audio.size / sr
        check(audio.size > 0 and mp3,
              f"{pitch:6s} → {audio.size / sr:.2f} 秒音频（{time.time() - t0:.1f}s）")
    print("   三种语速对比：", {k: round(v, 2) for k, v in sorted(got.items())})

    print("\n② 特效：robot / echo / radio 都不能爆音、长度基本不变")
    say.PITCH[0] = ""
    mp3 = say.edge_mp3("测试一二三。", "zh-CN-XiaoxiaoNeural", "+8%")
    base, sr = say.decode_audio(mp3)
    for fx in ("", "robot", "echo", "radio"):
        out = say.apply_fx(base.copy(), sr, fx)
        check(out.size > 0 and float(abs(out).max()) <= 1.001,
              f"{fx or '（无特效）':10s} 峰值 {float(abs(out).max()):.2f}、"
              f"{out.size / sr:.2f} 秒")

    print("\n③ 设置里那串音色预设都在（含方言 / 变声 / 特效）")
    import overlay

    names = [v[1] for v in overlay.VOICES]
    for want in ("东北话", "陕西话", "粤语", "日语", "卡通高音", "闷低音", "机器人", "老电台", "回音"):
        check(any(want in n for n in names), f"预设里有「{want}」")
    check(len(overlay.VOICES) >= 15, f"一共 {len(overlay.VOICES)} 套音色")
    check(all(len(v) == 4 for v in overlay.VOICES), "每套都是（音色, 名字, 变调, 特效）四元组")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
