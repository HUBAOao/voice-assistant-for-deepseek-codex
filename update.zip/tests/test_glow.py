# -*- coding: utf-8 -*-
"""验收「圆点只留光晕，光晕也要夹在长条上」。

光晕必须是**顺着形状往外铺**的：
  * 没声音（小圆点）：一团圆光晕，铺到圆点外面去；
  * 有声音（长条）：一条顺着条的长光带，铺到条的上下外面去。
以前那层光是在声音条自己的小图上糊的，一出边界就被裁掉，所以条外面看不到光。
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "glow-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg.update({"overlay_bg_image": "", "overlay_alpha": 1.0, "auto_tune": False,
                "snap_edges": False, "perf_mode": "quality", "anim_fps": 60,
                "overlay_width": 344, "overlay_height": 112})
    for key in overlay.FX_KEYS:
        cfg[key] = False
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 40, "y": 40}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0.0, "text": "", "ts": time.time(),
         "pid": os.getpid()}), encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    for _ in range(20):
        o.root.update()
        time.sleep(0.005)
    o.alpha_override = 1.0
    o.show_line = True
    o.sleep_stage = 0
    o._pop = 0.0
    o.perf = "quality"
    W, H = o.W, o.H
    bg_c = overlay.rgb(o.panel_color)
    gap, band = o.layout["wave"]
    band_top = H - gap - band

    def frame(level: float) -> Image.Image:
        o.level_shown = level
        im = Image.new("RGB", (W, H), bg_c)
        o.draw_voice(im, o.accent)
        o.breath = (o.breath + 1.1) % 6.283185307179586
        return im

    def set_fx(on: tuple) -> None:
        o.fx = {k: (k in on) for k in overlay.FX_KEYS}
        o._trail_img = None

    def outside_rows(im: Image.Image) -> int:
        """声音条那条带子外面（上面），有几行被画上了东西。"""
        px = im.load()
        rows = 0
        for y in range(0, band_top - 1):
            if any(px[x, y] != bg_c for x in range(W)):
                rows += 1
        return rows

    print("① 出厂设置：那颗小圆点只留光晕")
    on = [k for k in overlay.FX_KEYS if overlay.DEFAULTS.get(k)]
    # 唤醒爆闪是"被叫醒那一瞬间"的，不参与"安静时那颗圆点长什么样"，允许它开着
    quiet_fx = [k for k in overlay.FX_DOT_KEYS if k != "fx_burst"]
    dot_on = [k for k in on if k in quiet_fx]
    check(dot_on == [], f"安静时圆点身上那几种花样默认全关（开着的：{dot_on or '无'}）")
    check("fx_glow" in on, "光晕默认是开的")

    print("② 没声音时：光晕要铺到圆点外面")
    set_fx(())
    plain = frame(0.0)
    set_fx(("fx_glow",))
    glow = frame(0.0)
    # 圆点在声音条那一行；数一下这一行之外有多少像素被照亮
    def halo_pixels(im, plain_im) -> int:
        a, b = plain_im.load(), im.load()
        n = 0
        for y in range(H):
            for x in range(W):
                if a[x, y] != b[x, y] and a[x, y] == bg_c:
                    n += 1
        return n

    n = halo_pixels(glow, plain)
    check(n > 400, f"圆点外面多了 {n} 个被柔光照到的像素（一团光晕）")
    glow.save(ROOT / "work" / "glow-dot.png")

    print("③ 有声音时：同一层光要夹在长条上（条上下外面都得有光）")
    set_fx(())
    plain_bar = frame(0.8)
    set_fx(("fx_glow",))
    glow_bar = frame(0.8)
    set_fx(())
    plain_rows = outside_rows(plain_bar)
    set_fx(("fx_glow",))
    glow_rows = outside_rows(glow_bar)
    print(f"     条上面：没有光晕 {plain_rows} 行 / 开了光晕 {glow_rows} 行")
    check(plain_rows == 0, "不加光晕时，条外面干干净净")
    check(glow_rows >= 8, f"开了光晕，条上面 {glow_rows} 行有光（光顺着条铺开了）")
    set_fx(("fx_glow",))
    glow_bar.save(ROOT / "work" / "glow-bar.png")

    print("④ 光晕是会呼吸的（亮度会变）")
    set_fx(("fx_glow",))
    vals = []
    for _ in range(12):
        im = frame(0.8)
        px = im.load()
        vals.append(sum(1 for x in range(W) for y in range(0, band_top - 1)
                        if px[x, y] != bg_c))
        o.breath = (o.breath + 0.5) % 6.283185307179586
    check(len(set(vals)) > 3, f"12 帧里看到 {len(set(vals))} 种亮度（在呼吸）")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
