# -*- coding: utf-8 -*-
"""Audio device, recognizer and recorder assembly stays deterministic."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_audio_setup import (  # noqa: E402
    AudioRuntimeDependencies,
    prepare_audio_runtime,
)


class TranscriberProbe:
    def __init__(self, device="cpu", **kwargs) -> None:
        self.device = device
        self.compute_type = "int8"
        self.hotwords = kwargs.get("hotwords") or ""
        self.beam = 5
        self.kwargs = kwargs


def args(**changes):
    values = {
        "default_input": False,
        "input": "USB Mic",
        "wake_word": "大肥鱼",
        "cancel_word": "取消",
        "model": "small",
        "device": "cpu",
        "compute_type": "int8",
        "lang": "zh",
        "out": "transcripts.md",
        "ptt": False,
        "mode": "talk",
        "immediate": False,
        "silence": None,
        "max_seconds": 18,
    }
    values.update(changes)
    return SimpleNamespace(**values)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    def dependencies(calls: list, *, exit_open: bool = False, cpu: bool = True):
        def resolve(value):
            calls.append(("resolve", value))
            return value

        def open_stream(device):
            calls.append(("open", device))
            if exit_open:
                raise SystemExit("no microphone")
            return "stream", 16000

        def recorder(*values, **keywords):
            calls.append(("recorder", values, keywords))
            return {"recorder": True}

        return AudioRuntimeDependencies(
            resolve_device=resolve,
            open_stream=open_stream,
            input_name=lambda device: f"name:{device}",
            make_transcriber=lambda *values, **keywords: TranscriberProbe(
                "cpu" if cpu else "cuda", **keywords
            ),
            wake_params=lambda cfg: (
                "标准",
                {"min_voiced": 0.3, "noise_mult": 1.2, "confirm": 2},
            ),
            wake_description=lambda level: f"confirm={level['confirm']}",
            make_recorder=recorder,
            emit=lambda text: calls.append(("emit", text)),
        )

    calls = []
    session = prepare_audio_runtime(
        args(), {}, "full", {"why": "not lite"}, dependencies(calls)
    )
    check(session.device == "USB Mic" and session.stream == "stream",
          "指定输入设备和音频流原样进入运行会话")
    check(session.input_name == "name:USB Mic" and session.rate == 16000,
          "输入名称和采样率由同一装配结果提供")
    check(session.transcriber.beam == 1,
          "CPU 识别器继续切到贪心解码")
    check(session.transcriber.hotwords == "大肥鱼 取消",
          "唤醒词和取消词同时保留为热词")
    check(session.mode == "talk" and session.silence == 1.0,
          "talk 模式使用原有静音等待时长")
    check(session.wake_words == ["大肥鱼"]
          and session.cancel_words == ["取消"],
          "唤醒词与取消词按旧规则拆分")
    recorder = next(item for item in calls if item[0] == "recorder")
    check(recorder[2]["min_voiced"] == 0.3
          and recorder[2]["noise_mult"] == 1.2
          and recorder[2]["confirm"] == 2
          and recorder[2]["device"] == "USB Mic",
          "录音器继续接收同一档位和设备")

    calls = []
    immediate = prepare_audio_runtime(
        args(immediate=True), {}, "lite", {"why": "low ram"},
        dependencies(calls, cpu=False),
    )
    check(immediate.wake_words == [] and immediate.min_voiced == 0.62,
          "立即对话清除唤醒词并启用严格人声门槛")
    check(immediate.transcriber.beam == 5,
          "CUDA 识别器不被错误改成贪心解码")
    messages = [item[1] for item in calls if item[0] == "emit"]
    check(any("低配跑：low ram" in text for text in messages),
          "低配原因仍写进启动说明")

    calls = []
    default_input = prepare_audio_runtime(
        args(default_input=True), {}, "full", {"why": ""},
        dependencies(calls),
    )
    check(default_input.device is None
          and not any(item[0] == "resolve" for item in calls),
          "默认输入模式不调用指定设备解析")

    calls = []
    try:
        prepare_audio_runtime(
            args(), {}, "full", {"why": ""},
            dependencies(calls, exit_open=True),
        )
    except SystemExit:
        pass
    else:
        check(False, "打开音频流失败仍抛出 SystemExit 给设备列表兜底")
    check(any(item[0] == "open" for item in calls),
          "打开失败发生在统一音频装配边界")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    check("audio = entry.audio" in source,
          "main() 消费启动管线准备的音频会话")
    main_block = source.split("def main() -> int:", 1)[1]
    check("stream, rate = open_stream(device)" not in main_block
          and "transcriber = Transcriber(args.model" not in main_block,
          "main() 不再内联初始音频流和识别器组装")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
