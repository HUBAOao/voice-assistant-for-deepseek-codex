# -*- coding: utf-8 -*-
"""把新功能的样子抓出来：实时字幕 / 番茄钟进度条 / 语气反应 / 打盹。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
WORK = ROOT / "work"
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

S = WORK / "fun-scratch"
S.mkdir(parents=True, exist_ok=True)

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMIH(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find(title: str) -> int:
    hit = {"h": 0}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(h, buf, 256)
        if buf.value == title:
            hit["h"] = h
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return hit["h"]


def grab(hwnd: int) -> Image.Image:
    r = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMIH()
    hdr.biSize = ctypes.sizeof(BMIH)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount, hdr.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return img


def main() -> int:
    (S / "config.json").write_text(json.dumps({
        "name": "花样", "overlay_bg_image": "", "overlay_alpha": 1.0, "anim_fps": 60,
        "overlay_color": "#141418", "overlay_accent": "#3ddc84",
        "overlay_talk_color": "#4aa3ff", "mood_enabled": True, "mood_idle": True,
        "caption_enabled": True, "overlay_show_caption": True}, ensure_ascii=False),
        encoding="utf-8")
    (S / "pos.json").write_text('{"x": 120, "y": 120}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")

    def status(**kw):
        data = {"state": "idle", "text": "", "hint": "", "level": 0.0, "mood": "",
                "focus": 0.0,
                "ts": time.time(), "pid": os.getpid()}
        data.update(kw)
        (S / "status.json").write_text(json.dumps(data, ensure_ascii=False),
                                       encoding="utf-8")

    status()
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None
    (S / "speak.json").write_text('{"active": false, "level": 0, "ts": 0}', encoding="utf-8")

    o = overlay.Overlay()
    o.alpha_override = 1.0
    for _ in range(60):
        o.root.update()
        if find("花样"):
            break
        time.sleep(0.05)
    hwnd = find("花样")
    if not hwnd:
        print("没找到窗口")
        return 1

    def hold(seconds: float, shot: str, **st) -> None:
        end = time.time() + seconds
        while time.time() < end:
            status(**st)
            o.root.update()
            time.sleep(0.02)
        grab(hwnd).save(WORK / shot)
        print(f"已保存 {shot}")

    hold(0.9, "fun-caption.png", state="hearing", level=0.62,
         text="现在把三个快捷方式合并成一个")
    hold(0.9, "fun-focus.png", state="hearing", level=0.05, text="", focus=1090.0)
    hold(0.9, "fun-mood-hurry.png", state="hearing", level=0.75,
         mood="急", text="快点帮我看看这个")
    hold(0.9, "fun-mood-soft.png", state="hearing", level=0.22,
         mood="轻", text="那个…随便看看")

    # 音浪模式：给一串频谱柱子
    o.spectrum_on = True
    import random as _rnd
    end = time.time() + 0.9
    while time.time() < end:
        status(state="hearing", level=0.6,
               bands=[round(abs(_rnd.gauss(0.5, 0.25)) % 1.0, 2) for _ in range(12)])
        o.root.update()
        time.sleep(0.02)
    grab(hwnd).save(WORK / "fun-spectrum.png")
    print("已保存 fun-spectrum.png")
    o.spectrum_on = False

    # 逐字跟读：朗读进度到 55%
    (S / "speak.json").write_text(json.dumps(
        {"active": True, "level": 0.5, "text": "这条声音条会一个字一个字亮起来",
         "progress": 0.55, "ts": time.time()}, ensure_ascii=False), encoding="utf-8")
    end = time.time() + 0.9
    while time.time() < end:
        (S / "speak.json").write_text(json.dumps(
            {"active": True, "level": 0.5, "text": "这条声音条会一个字一个字亮起来",
             "progress": 0.55, "ts": time.time()}, ensure_ascii=False), encoding="utf-8")
        status(state="hearing", level=0.4)
        o.root.update()
        time.sleep(0.02)
    grab(hwnd).save(WORK / "fun-karaoke.png")
    print("已保存 fun-karaoke.png")
    (S / "speak.json").write_text('{"active": false, "level": 0, "ts": 0}', encoding="utf-8")
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)

    # 打盹：先让它真的静下来（否则上一轮的 hearing 会不停刷新 last_active），
    # 再把"最后活跃时间"推到 5 分钟前
    for _ in range(40):
        status(state="idle", level=0.0)
        o.root.update()
        time.sleep(0.02)
    o.last_active = time.time() - 300
    for _ in range(60):
        status(state="idle", level=0.0)
        o.root.update()
        time.sleep(0.02)
    print("打盹阶段 =", o.sleep_stage)
    grab(hwnd).save(WORK / "fun-sleepy.png")
    print("已保存 fun-sleepy.png")
    o.root.destroy()
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
