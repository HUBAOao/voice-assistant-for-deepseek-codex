# -*- coding: utf-8 -*-
"""Android folder access stays metadata-only and explicitly user initiated."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
UI = ROOT / "outputs" / "voice-to-text" / "phone_page.html"
SCRIPT = ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "management.js"
NATIVE_FILE_SCRIPT = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui" / "native-files.js"
)
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = SOURCE.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    ui = UI.read_text(encoding="utf-8")
    script = SCRIPT.read_text(encoding="utf-8")
    native_file_script = NATIVE_FILE_SCRIPT.read_text(encoding="utf-8")

    check("Intent.ACTION_OPEN_DOCUMENT_TREE" in source,
          "文件夹通过系统目录选择器打开")
    check("FLAG_GRANT_PERSISTABLE_URI_PERMISSION" in source
          and "takePersistableUriPermission(uri, flags)" in source,
          "只保留系统明确授予的持久读写权限")
    check("buildChildDocumentsUriUsingTree" in source
          and "COLUMN_MIME_TYPE" in source,
          "只查询当前层直接子项的 MIME 元数据")
    check("childCount >= 5000" in source and 'out.put("truncated", truncated)' in source,
          "超大目录在 5000 项处停止计数并明确标记")
    check('out.put("child_count", childCount)' in source
          and 'out.put("folder_count", folderCount)' in source,
          "返回当前层项目数和子文件夹数")

    folder_open = source[
        source.index("private void openSystemFolder()"):
        source.index("private void saveSystemDocument(String suggestedName, String content)")
    ]
    folder_describe = source[
        source.index("private JSONObject describeFolder("):
        source.index("private void handleOpenedFolder(")
    ]
    check("openInputStream" not in folder_open
          and "openInputStream" not in folder_describe,
          "文件夹选择不会读取任何文件内容")
    check("finish()" not in folder_open and "press_enter" not in folder_open,
          "选择文件夹不会关闭页面或自动提交")
    check("KEY_FOLDER_URI" in source and "KEY_FOLDER_NAME" in source,
          "授权文件夹身份使用既有加密偏好存储")
    check("removePref(KEY_FOLDER_URI)" in source
          and "removePref(KEY_FOLDER_NAME)" in source,
          "撤销授权会清理文件夹回读记录")

    check("MANAGE_EXTERNAL_STORAGE" not in manifest
          and "READ_MEDIA_" not in manifest,
          "没有引入全盘或媒体库权限")
    check('id="acceptFolderOpen"' in ui and 'id="acceptFolderReopen"' in ui,
          "真机验收页提供选择和回读入口")
    check("VoiceApp.openRealFolder()" in native_file_script
          and "VoiceApp.reopenRealFolder()" in native_file_script,
          "页面只通过明确点按调用原生接口")
    check("不遍历文件内容，不自动上传或发送" in native_file_script,
          "页面明确说明元数据读取边界")
    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for symbol in (
            "openRealFolder",
            "reopenRealFolder",
            "describeFolder",
            "folder-reopen",
            "child_count",
            "folder_count",
            "KEY_FOLDER_URI",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
