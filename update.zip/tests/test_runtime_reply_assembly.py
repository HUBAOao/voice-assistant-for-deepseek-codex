# -*- coding: utf-8 -*-
"""Answer monitoring and page hot reload remain testable outside ``main()``."""
from __future__ import annotations

import sys
import os
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_reply_assembly import (  # noqa: E402
    RuntimeReplyAssembly,
    RuntimeReplyDependencies,
)


class Reader:
    def __init__(self, speak, record, on_raw, done, on_end, on_ready) -> None:
        self.speak = speak
        self.record = record
        self.on_raw = on_raw
        self.done = done
        self.on_end = on_end
        self.on_ready = on_ready


class Module:
    ReplyReader = Reader


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as raw:
        page = Path(raw) / "phone_link.py"
        page.write_text("PAGE = 1\n", encoding="utf-8")
        spoken = []
        log = []
        emitted = []
        busy = {"on": True}
        reloaded = []
        clock = [100.0]
        deps = RuntimeReplyDependencies(
            reply_reader_module=Module,
            speak=lambda text, **kwargs: spoken.append((text, kwargs)),
            syslog=lambda tag, text: log.append((tag, text)),
            on_raw_reply=lambda text: log.append(("raw", text)),
            busy=busy,
            page_path=lambda: page,
            reload_module=lambda: reloaded.append(True),
            emit=lambda text, **_kwargs: emitted.append(text),
            clock=lambda: clock[0],
        )
        runtime = RuntimeReplyAssembly(deps)
        runtime.reader.speak("回答")
        check(spoken == [("回答", {"wait": True})],
              "回答仍等上一句念完再念下一句")
        runtime.reader.done("会话")
        check(not busy["on"] and log[-1][0] == "完",
              "回答完成仍清忙碌状态并写日志")

        runtime.hot_reload_page()
        check(not reloaded, "首次观察只建立页面时间基线")
        baseline = page.stat().st_mtime
        page.write_text("PAGE = 2\n", encoding="utf-8")
        os.utime(page, (baseline, baseline + 5))
        runtime.hot_reload_page()
        check(not reloaded, "两秒节流窗口内不重复热重载")
        clock[0] += 3
        runtime.hot_reload_page()
        check(reloaded == [True] and log[-1] == ("检", "手机网页热重载")
              and any("热重载" in text for text in emitted),
              "页面变化后按原节流热重载并写日志")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check("def hot_reload_page(" not in stt
          and "reply_reader.ReplyReader(" not in stt,
          "回答监视和网页热重载实现已经离开 main()")
    service = (
        APP / "voice_feature" / "runtime_service_assembly.py"
    ).read_text(encoding="utf-8")
    check("reply_runtime.hot_reload_page" in service,
          "周期任务消费独立回答运行时")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
