# -*- coding: utf-8 -*-
"""The home widget is an explicit, non-messaging native surface."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APK = ROOT / "outputs" / "语音助手-手机端.apk"
NS = {"android": "http://schemas.android.com/apk/res/android"}


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = ElementTree.parse(ANDROID / "AndroidManifest.xml")
    application = manifest.getroot().find("application", NS)
    receivers = {
        item.get(f"{{{NS['android']}}}name"): item
        for item in application.findall("receiver", NS)
    }
    receiver = receivers.get(".FinDeckWidgetProvider")
    provider = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "FinDeckWidgetProvider.java"
    ).read_text(encoding="utf-8")
    metadata = (
        receiver.find("meta-data", NS)
        if receiver is not None
        else None
    )

    check(receiver is not None, "主屏幕小组件接收器已声明")
    check(
        receiver is not None
        and receiver.get(f"{{{NS['android']}}}exported") == "false",
        "小组件接收器不向其他应用导出",
    )
    check(
        metadata is not None
        and metadata.get(f"{{{NS['android']}}}resource")
        == "@xml/findeck_widget_info",
        "小组件绑定独立 provider-info 资源",
    )
    check(
        receiver is not None
        and receiver.find("intent-filter", NS) is not None,
        "小组件接收系统 APPWIDGET_UPDATE",
    )
    check("extends AppWidgetProvider" in provider,
          "原生实现使用系统 AppWidgetProvider")
    for required in (
        "PendingIntent.getActivity",
        "PendingIntent.getBroadcast",
        "FLAG_IMMUTABLE",
        "startForegroundService(service)",
        "NotifyService.isRunning()",
    ):
        check(required in provider, "小组件包含 " + required)
    for forbidden in (
        "sendMessage",
        "/api/cmd",
        "getInputStream",
        "openFileDescriptor",
        "JavascriptInterface",
        "setUrl(",
    ):
        check(forbidden not in provider,
              "小组件不包含自动操作 " + forbidden)

    info = ElementTree.parse(
        ANDROID / "res" / "xml" / "findeck_widget_info.xml"
    ).getroot()
    check(
        info.get(f"{{{NS['android']}}}initialLayout")
        == "@layout/findeck_widget",
        "小组件提供稳定的初始布局",
    )
    check(
        info.get(f"{{{NS['android']}}}updatePeriodMillis") == "0",
        "小组件不按时间自行唤醒",
    )
    layout = ElementTree.parse(
        ANDROID / "res" / "layout" / "findeck_widget.xml"
    ).getroot()
    ids = {
        item.get(f"{{{NS['android']}}}id")
        for item in layout.iter()
        if item.get(f"{{{NS['android']}}}id")
    }
    check(
        ids == {"@+id/widget_status", "@+id/widget_open", "@+id/widget_watch"},
        "小组件只包含状态、打开和开启提醒三个控件",
    )

    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = archive.read("classes.dex")
            resources = archive.read("resources.arsc")
            names = set(archive.namelist())
        for marker in (
            b"FinDeckWidgetProvider",
            b"WIDGET_WATCH",
            "鳍舱小组件".encode("utf-8"),
        ):
            check(marker in dex or marker in resources,
                  "APK 包含小组件契约 "
                  + marker.decode("utf-8", "replace"))
        check(
            "res/layout/findeck_widget.xml" in names
            or any(name.endswith("findeck_widget.xml") for name in names),
            "APK 打包小组件布局",
        )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
