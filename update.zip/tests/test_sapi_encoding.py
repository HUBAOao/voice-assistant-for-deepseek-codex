# -*- coding: utf-8 -*-
"""验收"系统音色念乱码"这个坑：老写法（走 stdin）会把中文按 GBK 解码成乱码，
新写法（写 UTF-8 文件让 PowerShell 读）才是对的。"""
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    text = "中文编码测试：一二三，天气不错。"
    f = Path(tempfile.gettempdir()) / "enc_test.txt"
    f.write_text(text, encoding="utf-8")

    def ps(cmd: str, data: bytes = None) -> str:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                           input=data.decode("utf-8") if data else None,
                           capture_output=True, encoding="utf-8",
                           errors="replace")
        return (r.stdout or "").strip()

    old = ps("[Console]::In.ReadToEnd()", text.encode("utf-8"))
    new = ps("[IO.File]::ReadAllText('%s', [Text.Encoding]::UTF8)" % f)
    print("原句  ：", text)
    print("老写法：", old, " ← 乱码（这就是你听到的「一团烂码」）")
    print("新写法：", new)

    bad = 0
    if new != text:
        print("✗ 新写法也没拿对")
        bad += 1
    else:
        print("✓ 新写法拿到的字是对的")
    if old == text:
        print("（这台机器的控制台正好是 UTF-8，老写法看不出问题）")
    else:
        print("✓ 复现了老写法的乱码")

    src = (APP / "say.py").read_text(encoding="utf-8")
    assert "ReadAllText" in src, "say.py 里应该用 ReadAllText 读文件"
    print("✓ say.py 用的是「写 utf-8 文件 + ReadAllText」这条新路")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
