# -*- coding: utf-8 -*-
"""第三批：看一眼设置页（版本号＋新开关）、试大字幕、试系统日志行。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "b3-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402
import version  # noqa: E402

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMIH(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find(title: str) -> int:
    hit = {"h": 0}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(h, buf, 256)
        if buf.value == title:
            hit["h"] = h
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return hit["h"]


def grab(hwnd: int) -> Image.Image:
    r = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMIH()
    hdr.biSize = ctypes.sizeof(BMIH)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount, hdr.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return img


def main() -> int:
    (S / "config.json").write_text(json.dumps({
        "name": "第三批", "overlay_bg_image": "", "overlay_alpha": 1.0,
        "wake_word": "大肥鱼"}, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 100, "y": 100}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")

    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.SYSLOG_FILE = APP / "syslog.md"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    print("版本行：", version.label())
    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("智能")
    for _ in range(200):
        o.root.update()
        time.sleep(0.01)
    hwnd = find("第三批")
    if hwnd:
        grab(hwnd).save(ROOT / "work" / "b3-settings.png")
        print("已保存 b3-settings.png，窗口高", o.root.winfo_height())
    print("日志行：", o.log_summary())

    # 大字幕
    o.big_on = True
    o.big_size = 30
    (S / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.4, "text": "这就是大字幕，识别的每句话浮在屏幕底下",
         "ts": time.time(), "pid": os.getpid()}, ensure_ascii=False), encoding="utf-8")
    for _ in range(160):
        o.root.update()
        time.sleep(0.01)
    print("大字幕窗口：", o.caption_win is not None,
          "文字=", repr(o.caption_label.cget("text")[:24]) if o.caption_label else None)
    hw = find("") if False else None
    # 抓大字幕窗口（没有标题，用类名找）
    found = {"h": 0}
    cls = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(h, ctypes.byref(pid))
        r = wintypes.RECT()
        u32.GetWindowRect(h, ctypes.byref(r))
        if pid.value == os.getpid() and (r.right - r.left) > 800 and (r.bottom - r.top) > 60:
            found["h"] = h
            return False
        return True

    u32.EnumWindows(cls(cb), None)
    if found["h"]:
        grab(found["h"]).save(ROOT / "work" / "b3-bigcaption.png")
        print("已保存 b3-bigcaption.png")
    o.root.destroy()
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
