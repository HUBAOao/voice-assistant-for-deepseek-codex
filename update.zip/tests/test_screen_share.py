# -*- coding: utf-8 -*-
"""验收「屏幕发手机」：真截一张、真录一小段，再从手机入口把它们拿回来。"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    ss = load("ss", APP / "screen_share.py")
    from PIL import Image

    print("① 截一张（带上悬浮窗、缩到 2560）")
    t0 = time.time()
    shot = ss.take_shot(prefix="测试截图")
    check(shot is not None and shot.exists(), f"存下来了：{shot.name if shot else None}（{time.time()-t0:.1f}s）")
    if shot:
        im = Image.open(shot)
        check(im.width <= 2560, f"宽度缩到 {im.width}（原屏 5120，不缩就是 5MB）")
        check(shot.stat().st_size < 3_000_000, f"大小 {shot.stat().st_size/1024/1024:.2f} MB")
        check(im.height > 200 and im.width > 400, f"画面尺寸看着正常：{im.size}")
        check(im.convert("L").getextrema()[1] > 30, "不是纯黑（说明真抓到画面了）")

    print("\n② 录 2 秒（动图，手机浏览器认）")
    t0 = time.time()
    clip = ss.record_screen(seconds=2.0, fps=6, width=640)
    check(clip is not None and clip.exists(), f"录好了：{clip.name if clip else None}（{time.time()-t0:.1f}s）")
    if clip:
        check(clip.suffix in (".webp", ".gif"), f"格式 {clip.suffix}（动图，不用装 ffmpeg）")
        check(clip.stat().st_size < 2_000_000, f"大小 {clip.stat().st_size/1024:.0f} KB")

    print("\n③ 列表 + 只留最近 24 个")
    items = ss.list_shots()
    check(any(i["name"] == (shot.name if shot else "") for i in items), "刚截的这张在列表里")
    check(any(i["kind"] == "video" for i in items), "录像也在列表里（kind=video）")

    print("\n④ 从手机入口拿（要令牌，别人拿不到）")
    pl = load("pl", APP / "phone_link.py")
    link = pl.PhoneLink(on_command=lambda t: None, get_state=lambda: {}, get_log=lambda s: [],
                        port=8794)
    link.start()
    time.sleep(0.3)
    base = f"http://127.0.0.1:{link.port}"

    def get(path: str, key: str = "") -> tuple[int, bytes]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        try:
            with urllib.request.urlopen(url, timeout=6) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    code, _ = get("/api/shots")
    check(code == 401, f"没令牌拿截图列表 → {code}")
    code, body = get("/api/shots", link.token)
    data = json.loads(body)
    check(code == 200 and data.get("items"), f"有令牌能列出来（{len(data.get('items', []))} 个）")
    if shot:
        code, blob = get("/shot/" + urllib.parse.quote(shot.name), link.token)
        check(code == 200 and len(blob) == shot.stat().st_size, f"能下载到整张图（{len(blob)/1024:.0f} KB）")
    code, _ = get("/shot/..%2Fconfig.json", link.token)
    check(code == 404, f"想用 ../ 偷别的文件 → {code}")
    link.stop()

    print("\n⑤ 主程序里接上了")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check("import screen_share" in src, "主程序引了它")
    check("截图发手机" in src and "screen_share.take_shot()" in src, "说「截图发手机」会截图")
    check("screen_share.record_screen(seconds=secs)" in src, "「录 N 秒」会录屏")
    ov = (APP / "overlay.py").read_text(encoding="utf-8")
    check('"屏幕发手机"' in ov, "设置里有开关")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    check("📺 电脑屏幕" in page and "正在思考" in page, "手机页有屏幕面板和思考提示")

    for p in (shot, clip):
        try:
            p.unlink()
        except Exception:
            pass
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
