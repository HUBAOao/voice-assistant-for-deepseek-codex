# -*- coding: utf-8 -*-
"""Uninstall and product-action dialogs stay outside the overlay shell."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_product_actions_mixin import (  # noqa: E402
    OverlaySettingsProductActionsMixin,
)
from overlay_feature.settings_uninstall_mixin import (  # noqa: E402
    OverlaySettingsUninstallMixin,
)
from overlay_feature.settings_uninstall_actions_mixin import (  # noqa: E402
    OverlaySettingsUninstallActionsMixin,
)
from overlay_feature.settings_uninstall_dialog_mixin import (  # noqa: E402
    OverlaySettingsUninstallDialogMixin,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    uninstall = (
        APP / "overlay_feature" / "settings_uninstall_mixin.py"
    ).read_text(encoding="utf-8")
    uninstall_actions = (
        APP / "overlay_feature" / "settings_uninstall_actions_mixin.py"
    ).read_text(encoding="utf-8")
    uninstall_dialog = (
        APP / "overlay_feature" / "settings_uninstall_dialog_mixin.py"
    ).read_text(encoding="utf-8")
    product = (
        APP / "overlay_feature" / "settings_product_actions_mixin.py"
    ).read_text(encoding="utf-8")
    qr = (
        APP / "overlay_feature" / "settings_qr_mixin.py"
    ).read_text(encoding="utf-8")
    site_publish = (
        APP / "overlay_feature" / "settings_site_publish_mixin.py"
    ).read_text(encoding="utf-8")

    check(issubclass(
        type("Probe", (OverlaySettingsUninstallMixin,), {}),
        OverlaySettingsUninstallMixin,
    ), "卸载业务可通过独立混合类复用")
    check(issubclass(
        OverlaySettingsUninstallMixin,
        OverlaySettingsUninstallActionsMixin,
    ) and issubclass(
        OverlaySettingsUninstallMixin,
        OverlaySettingsUninstallDialogMixin,
    ), "历史卸载类继续组合动作与确认视图")
    check(issubclass(
        type("Probe", (OverlaySettingsProductActionsMixin,), {}),
        OverlaySettingsProductActionsMixin,
    ), "设置产品动作可通过独立混合类复用")
    for name in (
        "uninstall_command",
        "do_uninstall",
        "ask_uninstall",
        "publish_site",
        "shortcuts_summary",
        "edit_shortcuts",
    ):
        check(f"def {name}(" not in overlay,
              f"overlay.py 不再内联 {name}")
    for name in ("uninstall_command", "do_uninstall"):
        check(f"def {name}(" in uninstall_actions,
              f"卸载动作模块提供 {name}")
    check("def ask_uninstall(" in uninstall_dialog,
          "卸载确认视图由独立模块提供")
    for name in ("uninstall_command", "do_uninstall", "ask_uninstall"):
        check(f"def {name}(" not in uninstall,
              f"卸载兼容类不再内联 {name}")
    for name in (
        "shortcuts_summary",
        "edit_shortcuts",
    ):
        check(f"def {name}(" in product,
              f"产品动作模块提供 {name}")
    check("def publish_site(" not in product
          and "def publish_site(" in site_publish,
          "网站发布对话框迁入独立设置模块")
    check("def show_qr(" not in overlay
          and "def show_qr(" not in product
          and "def show_qr(" in qr,
          "二维码展示迁入独立设置模块")
    check("OverlaySettingsUninstallMixin" in overlay
          and "OverlaySettingsProductActionsMixin" in overlay,
          "Overlay 继续组合全部历史设置入口")
    check("subprocess.Popen(" in uninstall_actions
          and "creationflags=0x00000010" in uninstall_actions,
          "卸载仍以独立可见控制台启动")
    check("if not armed[\"on\"]:" in uninstall_dialog,
          "彻底删除仍需要第二次确认")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
