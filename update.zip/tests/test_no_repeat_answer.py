# -*- coding: utf-8 -*-
"""验收「不会重复念上一条已经念过的回答」。

真机的毛病：为了让"过程话"不念，回答的提取结果会变形（早先算回答的段落后来被剔掉），
原来按字数的"接着往下念"就对不上，于是从头再念一遍。现在按句子去重。"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

OLD = "上一条回答：插件源码已经写好了。下一步要 C++ 编译链。"
NEW = "这一版我把 C++ 那个依赖装上了。现在可以直接编译插件。"


def doc(state: dict) -> str:
    """照真窗口排版：回答区在最后一条「你说：」后面，末尾是输入框。"""
    head = (f"一堆界面字\n你说：\n{state['sent']}\n23:40\n\ufffc\n"
            f"ChatGPT 说：\n{state.get('first', '')}\n")
    if state.get("tool"):
        head += "已运行 cd C:\\Users\\HuBao\\work\n"
    if state.get("second"):
        head += f"ChatGPT 说：\n{state['second']}\n"
    return head + "最新一条回复\n随心输入\n添加文件等内容\n完全访问\n"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("rr", APP / "reply_reader.py")
    rr = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rr)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    spoken: list = []
    state = {"sent": "上一条我说的话", "first": OLD}
    rr.document_text = lambda hwnd, limit=None, timeout=None: doc(state)
    reader = rr.ReplyReader(speak_func=spoken.append, record=lambda t: None,
                            poll_seconds=0.05)

    print("① 发完新消息：窗口还停在上一条回答上（这段不该念）")
    state["sent"] = "发新消息了"
    reader.watch(123, "发新消息了", seconds=8)
    time.sleep(0.6)
    check(spoken == [], f"一个字都没念（现在念了 {spoken[:1]}）")

    print("② 新回答的第一段出来 → 念新的，绝不重复上一条")
    state["first"] = NEW
    time.sleep(1.0)
    joined = "".join(spoken)
    check(NEW[:8] in joined, f"念了新回答：{joined[:50]}")
    check("上一条回答" not in joined and "编译链" not in joined,
          "上一条回答没被再念一遍 ← 就是这次的 bug")

    print("③ 提取结果「变形」（前面那段后来被当成过程话剔掉）→ 也不能重念")
    before = "".join(spoken)
    state["tool"] = True
    state["second"] = "顺手把编译沙箱也准备好了。"
    time.sleep(1.0)
    after = "".join(spoken)[len(before):]
    check(NEW[:8] not in after, f"前面念过的那段一个字都没重念：{after[:50] or '（什么都没念）'}")
    check("上一条回答" not in after, "上一条回答也没再念")

    reader.stop()
    time.sleep(0.2)
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
