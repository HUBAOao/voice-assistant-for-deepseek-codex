# -*- coding: utf-8 -*-
"""Microphone recovery owns stale-stream replacement and capture guards."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.microphone_recovery import (  # noqa: E402
    MicrophoneRecovery,
    is_disconnect_error,
)


class Stream:
    def __init__(self, name: str, calls: list[str]) -> None:
        self.name = name
        self.calls = calls

    def stop(self) -> None:
        self.calls.append(self.name + ".stop")

    def close(self) -> None:
        self.calls.append(self.name + ".close")


class Recorder:
    def __init__(self, name: str, *, calibrate_error=None, record_error=None) -> None:
        self.name = name
        self.calibrate_error = calibrate_error
        self.record_error = record_error

    def calibrate(self) -> float:
        if self.calibrate_error:
            raise self.calibrate_error
        return 0.25

    def record_utterance(self, *_args, **_kwargs):
        if self.record_error:
            raise self.record_error
        return self.name


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    check(is_disconnect_error(RuntimeError("PortAudio stream failed")),
          "识别 PortAudio/stream 设备掉线")
    check(not is_disconnect_error(ValueError("bad setting")),
          "不把普通配置错误当设备掉线")

    calls: list[str] = []
    waits: list[float] = []
    attempts: list[int] = []
    old = Stream("old", calls)
    new = Stream("new", calls)
    old_recorder = Recorder("old-rec")
    new_recorder = Recorder("new-rec")
    opened = 0

    def reopen():
        nonlocal opened
        opened += 1
        if opened == 1:
            raise RuntimeError("device still missing")
        return new, 48000, new_recorder, "USB 2"

    mic = MicrophoneRecovery(
        stream=old,
        rate=16000,
        recorder=old_recorder,
        device="USB 1",
        reopen=reopen,
        wait=waits.append,
        retry_delay=0.25,
        on_reconnected=attempts.append,
    )
    mic._mark_interrupted()
    check(mic.recover(), "后续重连尝试成功")
    check(calls == ["old.stop", "old.close"],
          "重连只关闭失效的旧音频流")
    check(mic.stream is new and mic.rate == 48000
          and mic.recorder is new_recorder and mic.device == "USB 2",
          "连接成功后整组设备状态原子替换")
    check(waits == [0.25, 0.25] and attempts == [2],
          "失败一次后等待再试，并记录成功尝试序号")
    check(mic.recover() and opened == 2,
          "已恢复时不会重复打开设备")

    good = MicrophoneRecovery(
        stream=Stream("live", []),
        rate=16000,
        recorder=Recorder("good"),
        device=None,
        reopen=lambda: (None, 16000, Recorder("unused"), None),
    )
    check(good.safe_calibrate() == 0.25 and good.safe_record() == "good",
          "在线时校准与录音保护原样返回")

    errors: list[str] = []

    def fail_exc(kind: str):
        return RuntimeError("PortAudio stream " + kind)

    disconnected = MicrophoneRecovery(
        stream=Stream("gone", []),
        rate=16000,
        recorder=Recorder(
            "gone-rec",
            calibrate_error=fail_exc("calibrate"),
            record_error=fail_exc("record"),
        ),
        device=None,
        reopen=lambda: (None, 16000, None, None),
        on_interrupted=lambda: errors.append("interrupted"),
    )
    check(disconnected.safe_calibrate(0.07) == 0.07
          and disconnected.safe_record() is None,
          "校准/录音遇到掉线时返回安全值并进入待重连")
    check(not disconnected.available and errors == ["interrupted", "interrupted"],
          "两次掉线都通知主循环，但不会直接抛给程序")

    bubble = MicrophoneRecovery(
        stream=Stream("bubble", []),
        rate=16000,
        recorder=Recorder("bubble-rec", record_error=ValueError("bad setting")),
        device=None,
        reopen=lambda: (None, 16000, None, None),
    )
    try:
        bubble.safe_record()
    except ValueError:
        bubble_error = True
    else:
        bubble_error = False
    check(bubble_error, "非设备错误继续抛出，不被重连吞掉")

    no_retry = MicrophoneRecovery(
        stream=Stream("dead", []),
        rate=16000,
        recorder=Recorder("dead-rec"),
        device=None,
        reopen=lambda: (_ for _ in ()).throw(RuntimeError("no device")),
        wait=lambda _seconds: None,
        retries=2,
        on_failed=lambda: errors.append("failed"),
    )
    no_retry._mark_interrupted()
    check(not no_retry.recover() and errors[-1] == "failed",
          "全部尝试失败时保留待重连状态并通知主循环")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    microphone_setup = (
        APP / "voice_feature" / "runtime_microphone_setup.py"
    ).read_text(encoding="utf-8")
    audio_loop = (
        APP / "voice_feature" / "audio_loop.py"
    ).read_text(encoding="utf-8")
    foreground = (
        APP / "voice_feature" / "runtime_foreground_assembly.py"
    ).read_text(encoding="utf-8")
    check("prepare_microphone_runtime(" in foreground
          and "prepare_microphone_runtime(" not in stt
          and "MicrophoneRecovery(" in microphone_setup
          and "mic.recover()" in audio_loop,
          "前台生命周期通过独立装配和控制器重连麦克风")
    check("def reconnect_mic()" not in stt and "def safe_record(*a, **kw)" not in stt,
          "main() 不再内联重连与录音保护实现")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
