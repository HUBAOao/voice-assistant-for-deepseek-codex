# -*- coding: utf-8 -*-
"""验收：点「恢复默认」之后，配置是不是就变成出厂那套（＝我现在的设置）。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "defaults-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def main() -> int:
    mine = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    scratch = S / "config.json"
    # 故意先写一份被改得乱七八糟的配置
    scratch.write_text(json.dumps({
        "name": "乱改的", "wake_word": "小黑", "overlay_color": "#ff00ff",
        "voice": "zh-CN-YunxiNeural", "overlay_alpha": 0.2, "volume": 5,
        "weather_city": "上海", "pet_enabled": True, "not_heard_reply": True,
    }, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 60, "y": 60}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = scratch
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    o.alpha_override = 0.95
    o.set_expanded(True)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    o.reset_defaults()
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    o.root.destroy()

    got = json.loads(scratch.read_text(encoding="utf-8"))
    bad = []
    for key, want in overlay.DEFAULTS.items():
        if key not in got:
            continue        # 新加的设置项，用户还没保存过就不会在文件里，不算不一致
        if got.get(key) != want:
            bad.append((key, want, got.get(key)))
    print(f"比对了 {len(overlay.DEFAULTS)} 项出厂默认值")
    for key, want, have in bad:
        print(f"  ✗ {key}: 期望 {want!r} 实际 {have!r}")
    print("恢复默认 = 出厂设置：", "✓" if not bad else f"✗ 有 {len(bad)} 项不对")
    # 再跟"我的当前设置"对一遍（日程是个人数据，不参与）
    mine.pop("schedules", None)
    diff = [k for k, v in mine.items()
            if k in overlay.DEFAULTS and overlay.DEFAULTS[k] != v]
    print("跟我的当前设置不一致的项：", diff or "无 ✓")
    return 0 if not bad and not diff else 1


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
