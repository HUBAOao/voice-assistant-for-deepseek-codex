# -*- coding: utf-8 -*-
"""DOCX system targets stay aligned with the bounded attachment pipeline."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)
MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    check(manifest.count(f'android:mimeType="{MIME}"') == 4,
          "DOCX 注册单张/多张分享及 content/file 打开四种目标")
    check(manifest.count('android:name="android.intent.action.SEND"') >= 7
          and manifest.count('android:name="android.intent.action.VIEW"') >= 12,
          "DOCX 目标没有挤掉既有系统入口")
    check('"application/vnd.openxmlformats-officedocument.'
          'wordprocessingml.document"' in activity,
          "原生 MIME 白名单包含标准 DOCX 类型")
    check("isWordDocumentMime(type)" in activity
          and "cleanMime = " in activity,
          "DOCX 只经既有可分享附件判定和 MIME 清理路径")
    check("MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "DOCX 继续使用 16 MB 与六个附件的共享上限")
    check("FinDeckShare" in activity and "file-staged" in activity,
          "DOCX 仍只走现有 file-staged 待发送入口")
    check(MIME in media,
          "手机页面入口接受同一 DOCX MIME")
    check("stageFiles([new File([bytes]" in media
          and "sendButton.onclick" in media,
          "DOCX 只进入待发送托盘并等待用户点发送")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
