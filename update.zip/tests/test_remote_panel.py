# -*- coding: utf-8 -*-
"""验收「外网访问（Tailscale）」这一栏长在设置里，而且真能读出固定地址。

用户要的是"别让我自己去装 Tailscale" —— 所以这一栏必须有：
  一键开启 / 二维码 / 复制地址 / 刷新 四个按钮，状态那行字要能自己填上。
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "remote-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay                                          # noqa: E402


def make_overlay():
    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg["overlay_bg_image"] = ""
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 120, "y": 120}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None
    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    return o


def walk(w):
    """把一棵控件树摊平（找出那几个按钮 / 那行字）。"""
    yield w
    try:
        kids = w.winfo_children()
    except Exception:
        return
    for c in kids:
        yield from walk(c)


def texts(o):
    out = []
    for w in walk(o.tab_frames["智能"]):
        try:
            t = w.cget("text")
        except Exception:
            continue
        if t:
            out.append(str(t))
    return out


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    o = make_overlay()
    print("① 智能页里有「外网访问」这一组")
    o.show_tab("智能")
    for _ in range(20):
        o.root.update()
        time.sleep(0.01)
    got = texts(o)
    joined = " ｜ ".join(got)
    check(any("外网访问" in t for t in got), "有分组标题「外网访问（在外面也能连）」")
    for label in ("一键开启", "二维码", "复制地址", "刷新"):
        check(label in got, "有「%s」按钮" % label)
    print("   （智能页上的字：%s）" % joined[:120])

    print("\n② 状态那行字能自己填上（后台线程读 Tailscale，主线程显示）")
    o.refresh_remote()
    for _ in range(160):                    # 最多等 8 秒
        o.root.update()
        time.sleep(0.05)
        if "正在看…" not in str(o.remote_label.cget("text")):
            break
    shown = str(o.remote_label.cget("text"))
    check("正在看…" not in shown, "状态行已经更新（不是「正在看…」）")
    print("   → %s" % shown.replace("\n", " / ")[:150])
    url = getattr(o, "remote_fixed_url", "")
    # 公网地址（Funnel）开着的时候，这里给的就是那条 https —— 两种都算对
    check(url.startswith("http://") or url.startswith("https://"),
          "读出了外网地址：%s" % (url or "（空）"))
    check("100." in shown or "一键开启" in shown or "公网地址" in shown,
          "这一行讲清了能用 / 该点哪")

    print("\n③ 复制按钮走的是同一条地址（不弹错）")
    clip_before = None
    try:
        clip_before = o.root.clipboard_get()
    except Exception:
        pass
    o.copy_remote_url()
    o.root.update()
    after = o.root.clipboard_get()
    check(after.startswith("http"), "剪贴板里是那条地址：%s" % after[:60])
    if clip_before:
        try:
            o.root.clipboard_clear()
            o.root.clipboard_append(clip_before)
        except Exception:
            pass

    o.root.destroy()
    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
