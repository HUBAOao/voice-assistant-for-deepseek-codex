# -*- coding: utf-8 -*-
"""验收「念回答只念有用的东西」：界面上的状态行、命令行、粘在句尾的状态词都要滤掉。

样本是真的：直接从 syslog.md 的 [答] 行里抄下来的（2026-10-07 23:27 那次念错的）。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import reply_reader as rr  # noqa: E402

# 真机念错的原句（一字不改，从 syslog 抄的）
REAL_CMD = ("已在 25s 内运行 $log = 'C:\\Users\\HuBao\\Documents\\Codex\\2026-10-07\\uv5\\work"
            "\\vsinstall.log' if (Test-Path $log) { Move-Item -LiteralPath $log "
            "-Destination ($log + '.old') -Force } $args = @( 'install','--id',"
            "'Microsoft.VisualStudio.2022.BuildTools','-e', '--accept-package-agreements',"
            "'--accept-source-agree")
REAL_GLUED = ("装在跑（VS 安装器已在后台，无待处理的 UAC 弹窗）。趁下载的时间，我把"
              "\u201c编译沙箱\u201d准备好——这样装完就能直接编译插件，不用再等你工程"
              "（路径含中文，C++ 编译容易出问题）。正在编辑文件")
REAL_MIXED = ("应答语随机挑通了（200 次里 6 种都出现过）。编辑了文件运行了命令ChatGPT 说："
              "又是那个提示词回声明。正在编辑文件最新一条回复5 个文件已更改"
              "跳转到用户消息 1跳转到用户消息 2跳转到用户消息 3")

# (原句, 该不该被整行丢掉)
LINES = [
    # —— 界面状态 / 命令行：丢掉 ——
    (REAL_CMD, True),
    (REAL_MIXED, True),
    ("正在编辑文件", True),
    ("已编辑 2 个文件", True),
    ("运行了命令", True),
    ("正在运行", True),
    ("已在 12s 内运行", True),
    ("删除文件", True),
    ("查看内容", True),
    # —— 正经回答：一个字都不能丢 ——
    ("更新了三个设置，透明度也调了", False),
    ("这几条是我要念的正常回答，一个字都不能少。", False),
    ("插件写好了，接着改编译配置。", False),
    ("你说得对，我这就改。", False),
]


def pipeline(line: str) -> str:
    """跟 extract_reply 里一行走的一样：先削尾巴上的状态词，再判整行要不要丢。"""
    s = rr._trim_tail_status(line.strip())
    return "" if rr._is_junk_line(s) else s


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 一行一行过闸")
    for text, want_drop in LINES:
        got = pipeline(text)
        check((got == "") == want_drop,
              f"{'丢掉' if want_drop else '保留'} ← 「{text[:42]}…」" if len(text) > 42
              else f"{'丢掉' if want_drop else '保留'} ← 「{text}」")

    print("\n② 粘在句尾的状态词：削掉它，正文留住")
    got = pipeline(REAL_GLUED)
    check("正在编辑文件" not in got, "句尾的「正在编辑文件」没了")
    check("编译沙箱" in got and got.endswith("）"), f"正文还在：…{got[-24:]}")

    print("\n③ 整段过一遍：命令行 / 状态行 / 界面词都不能出现")
    doc = ("你说：\n帮我把插件编出来\n23:30\n\ufffc\nChatGPT 说：\n"
           f"{REAL_CMD}\n{REAL_GLUED}\n"
           "结论：插件源码已经在 work/bp-plugin 里了，下一步需要 C++ 编译链。\n"
           "最新一条回复\n随心输入\n添加文件等内容\n完全访问\n")
    out = rr.extract_reply(doc, "帮我把插件编出来")
    check(bool(out), "整段摘出来了")
    for junk in ("C:\\", "Test-Path", "Move-Item", "正在编辑文件", "最新一条回复"):
        check(junk not in out, f"没有「{junk}」")
    check("编译链" in out, f"有用的话还在：{out[:60]}")

    print("\n④ 过程话（领起句）不念，后面那段正经回答照念")
    doc2 = ("你说：\n帮我把插件编出来\n23:30\n\ufffc\nChatGPT 说：\n让我先看看它到底念了什么：\n"
            "\ufffc\n已运行 cd C:\\Users\\HuBao\\work\n"
            "ChatGPT 说：\n结论：插件源码已经写好，下一步要 C++ 编译链。\n"
            "最新一条回复\n随心输入\n")
    out2 = rr.extract_reply(doc2, "帮我把插件编出来")
    check("让我先看看" not in out2, f"领起句没念：{out2[:40]}")
    check("下一步要 C++ 编译链" in out2, "正经回答念了")
    doc3 = ("你说：\n帮我把插件编出来\n23:30\n\ufffc\nChatGPT 说：\n"
            "都弄好了：\n最新一条回复\n随心输入\n")
    check("都弄好了" in rr.extract_reply(doc3, "帮我把插件编出来"),
          "后面没跟工具的短句照念（只压一轮，不会漏）")

    print("\n⑤ 你刚发的那句，绝不能当成回答念回来（真机 23:34 出过）")
    waiting = ("你说：\n现在展开的时候有黑边\n23:33\n\ufffc\n"
               "ChatGPT 说：\n好的，我查一下。\n"
               "你说：\n能不能把这个当成自己的声音忽略的这个判定范围改得宽松一点啊\n23:34\n\ufffc\n"
               "最新一条回复\n随心输入\n添加文件等内容\n完全访问\n")
    got5 = rr.extract_reply(waiting, "能不能把这个当成自己的声音忽略的这个判定范围改得宽松一点啊")
    check("宽松一点" not in got5, f"没把你新发的那句念回来：{got5[:40]}")
    check(got5.strip() in ("", "好的，我查一下。"), f"最多回到上一条回答：{got5[:40]}")
    got5b = rr.extract_reply(waiting, "随便别的一句",
                             ("能不能把这个当成自己的声音忽略的这个判定范围改得宽松一点啊",))
    check("宽松一点" not in got5b, "就算前一句不认识，也认得「你发过的几句」")

    print("\n⑥ 界面浮层「回复已完成：…」的前缀不念")
    doc6 = ("你说：\n帮我看看\n23:35\n\ufffc\nChatGPT 说：\n"
            "回复已完成：都弄好了，插件能编了。\n最新一条回复\n随心输入\n")
    got6 = rr.extract_reply(doc6, "帮我看看")
    check(got6.startswith("都弄好了"), f"前缀削掉了：{got6[:30]}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
