# -*- coding: utf-8 -*-
"""Quick Settings tile contract stays native, explicit and non-messaging."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    namespace = {"android": "http://schemas.android.com/apk/res/android"}
    manifest = ElementTree.parse(ANDROID / "AndroidManifest.xml")
    services = {
        item.get(f"{{{namespace['android']}}}name"): item
        for item in manifest.getroot().findall(
            "application/service",
            namespace,
        )
    }
    tile = services.get(".FinDeckTileService")
    source = (
        ANDROID
        / "java"
        / "com"
        / "hubao"
        / "voiceassistant"
        / "FinDeckTileService.java"
    ).read_text(encoding="utf-8")

    check(tile is not None, "Quick Settings 服务已声明")
    check(
        tile is not None
        and tile.get(f"{{{namespace['android']}}}permission")
        == "android.permission.BIND_QUICK_SETTINGS_TILE",
        "磁贴绑定系统专用权限",
    )
    check(
        tile is not None
        and tile.get(f"{{{namespace['android']}}}exported") == "true",
        "磁贴作为系统快捷设置入口导出",
    )
    check(
        "QS_TILE" in (ANDROID / "AndroidManifest.xml").read_text(
            encoding="utf-8"
        ),
        "声明 Quick Settings 动作",
    )
    for required in (
        "extends TileService",
        "NotifyService.isRunning()",
        "startForegroundService(service)",
        "stopService(service)",
        "KEY_NOTIFY_DONE",
    ):
        check(required in source, "磁贴实现包含 " + required)
    for forbidden in (
        "sendMessage",
        "getInputStream",
        "openFileDescriptor",
        "/api/cmd",
        "JavascriptInterface",
    ):
        check(forbidden not in source, "磁贴不包含自动操作 " + forbidden)

    with zipfile.ZipFile(APK) as archive:
        dex = archive.read("classes.dex")
        resources = archive.read("resources.arsc")
    for marker in (
        b"FinDeckTileService",
        b"onStartListening",
        "鳍舱提醒".encode("utf-8"),
    ):
        check(
            marker in dex or marker in resources,
            "APK 包含磁贴契约 " + marker.decode("utf-8", "replace"),
        )
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
