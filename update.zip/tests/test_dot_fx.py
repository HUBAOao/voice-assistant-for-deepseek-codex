# -*- coding: utf-8 -*-
"""验收：声音条收起后那颗小圆点的特效（波纹 / 极光 / 光环 / 卫星 / 星芒 / 心跳 / 爆闪）。

每开一个特效都得让画面真的变样；全开时每帧的绘制耗时还得撑得住 60 帧。
"""
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from pathlib import Path

from PIL import Image, ImageChops

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "dotfx-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

DOT_FX = ("fx_ripple", "fx_aurora", "fx_rotor", "fx_orbit",
          "fx_starflare", "fx_heartbeat", "fx_burst")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  \u2713 " if cond else "  \u2717 ") + text)
        if not cond:
            bad += 1

    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg.update({"name": "\u5706\u70b9\u7279\u6548", "overlay_bg_image": "",
                "overlay_alpha": 1.0, "perf_mode": "quality", "anim_fps": 60,
                "auto_tune": False, "snap_edges": False,
                "overlay_width": 344, "overlay_height": 112})
    for key in overlay.FX_KEYS:
        cfg[key] = False
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False),
                                   encoding="utf-8")
    (S / "pos.json").write_text('{"x": 40, "y": 40}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}',
                                  encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0.0, "text": "", "ts": time.time(),
         "pid": os.getpid()}), encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    for _ in range(30):
        o.root.update()
        time.sleep(0.005)
    o.alpha_override = 1.0
    o.show_line = True
    o.level_shown = 0.0            # \u5b8c\u5168\u6ca1\u58f0\u97f3 \u2192 \u5c31\u662f\u90a3\u9897\u5c0f\u5706\u70b9
    o.sleep_stage = 0
    o._pop = 0.0
    o.perf = "quality"

    W, H = o.W, o.H

    def frame() -> Image.Image:
        im = Image.new("RGB", (W, H), overlay.rgb(o.panel_color))
        o.draw_voice(im, o.accent)
        o.breath = (o.breath + 0.37) % 6.283185307179586
        o._sweep_pos = (getattr(o, "_sweep_pos", 0.0) + 0.11) % 1.0
        return im

    def set_fx(on: tuple) -> None:
        o.fx = {k: (k in on) for k in overlay.FX_KEYS}
        o._trail_img = None

    set_fx(())
    base = frame()
    base.save(ROOT / "work" / "dot-off.png")

    print("\u2460 \u6bcf\u4e2a\u5706\u70b9\u7279\u6548\u5355\u72ec\u770b\u90fd\u5f97\u753b\u5f97\u51fa\u6765")
    for key in DOT_FX:
        set_fx((key,))
        # \u5355\u5e27\u6709\u53ef\u80fd\u6070\u597d\u5361\u5728\u52a8\u753b\u7684"\u7a7a\u6321"\u91cc\uff08\u6bd4\u5982\u5fc3\u8df3\u4e24\u4e0b\u4e4b\u95f4\uff09\uff0c
        # \u6240\u4ee5\u591a\u91c7\u51e0\u5e27\uff0c\u53ea\u8981\u5176\u4e2d\u4e00\u5e27\u770b\u5f97\u51fa\u6765\u5c31\u7b97\u6570\u3002
        best = None
        img = None
        for _ in range(8):
            o._pop = 0.7 if key == "fx_burst" else 0.0
            img = frame()
            box = ImageChops.difference(img, base).getbbox()
            if box is not None:
                best = box
                break
        if img is not None:
            img.save(ROOT / "work" / f"dot-{key.replace('fx_', '')}.png")
        o._pop = 0.0
        check(best is not None,
              f"{key} \u6253\u5f00\u540e\u753b\u9762\u6709\u53d8\u5316\uff08{best}\uff09")

    print("\u2461 \u5c0f\u5706\u70b9\u81ea\u5df1\u4e5f\u771f\u7684\u7f29\u5230\u4e2d\u95f4\u4e86")
    a = base.load()
    row = H - o.layout["wave"][0] - o.layout["wave"][1] // 2
    bg = overlay.rgb(o.panel_color)
    xs = [x for x in range(W) if a[x, row] != bg]
    width = (max(xs) - min(xs) + 1) if xs else 0
    check(0 < width <= 40, f"\u6ca1\u58f0\u97f3\u65f6\u90a3\u4e00\u884c\u53ea\u6709 {width}px \u5bbd\uff08\u5c0f\u5706\u70b9\uff09")
    check(bool(xs) and abs((min(xs) + max(xs)) / 2 - W / 2) <= 6,
          "\u5c0f\u5706\u70b9\u5728\u6b63\u4e2d\u95f4")

    print("\u2462 \u5168\u5f00\uff1a\u4e00\u5e27\u7684\u7ed8\u5236\u8017\u65f6\u6491\u5f97\u4f4f 60 \u5e27")
    set_fx(overlay.FX_KEYS)
    o.breath = 0.0
    times = []
    for _ in range(120):
        t0 = time.perf_counter()
        frame()
        times.append((time.perf_counter() - t0) * 1000.0)
    mid = statistics.median(times)
    p95 = sorted(times)[int(len(times) * 0.95)]
    print(f"     \u7ed8\u5236\u4e2d\u4f4d\u6570 {mid:.2f}ms / P95 {p95:.2f}ms\uff0816.7ms \u662f 60 \u5e27\u7684\u9884\u7b97\uff09")
    check(mid < 8.0, f"\u4e2d\u4f4d\u6570 {mid:.2f}ms < 8ms\uff08\u7559\u7ed9\u522b\u7684\u4e8b\u60c5\u7684\u65f6\u95f4\u591f\uff09")

    print("\u2463 \u7279\u6548\u5168\u5173\u65f6\u4e0d\u8be5\u767d\u82b1\u529b\u6c14")
    set_fx(())
    t0 = time.perf_counter()
    for _ in range(120):
        frame()
    off_ms = (time.perf_counter() - t0) / 120 * 1000.0
    print(f"     \u5168\u5173\uff1a\u6bcf\u5e27 {off_ms:.2f}ms")
    check(off_ms <= mid + 1.0, "\u5168\u5173\u6bd4\u5168\u5f00\u66f4\u7701\uff08\u6216\u5dee\u4e0d\u591a\uff09")

    print("\u2464 \u88ab\u53eb\u9192\u90a3\u4e00\u4e0b\u771f\u7684\u6709\u7206\u95ea")
    set_fx(("fx_burst",))
    o._pop = 0.0
    quiet = frame()
    o._pop = 1.0
    fire = frame()
    check(ImageChops.difference(fire, quiet).getbbox() is not None,
          "\u628a _pop \u62c9\u8d77\u6765\u753b\u9762\u5c31\u70b8\u5f00\u4e86")
    o._pop = 0.0

    print("\u2465 \u8bbe\u7f6e\u9875\u91cc 12 \u4e2a\u7279\u6548\u5f00\u5173\u90fd\u5728")
    check(len(set(overlay.FX_KEYS)) == 12,
          f"\u7279\u6548\u4e00\u5171 {len(set(overlay.FX_KEYS))} \u4e2a\u5f00\u5173")
    check(all(k in overlay.DEFAULTS for k in overlay.FX_KEYS),
          "\u6bcf\u4e2a\u5f00\u5173\u90fd\u6709\u51fa\u5382\u9ed8\u8ba4\u503c")

    o.root.destroy()
    print(f"\n\u4e0d\u901a\u8fc7\u7684\u7528\u4f8b\u6570 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
