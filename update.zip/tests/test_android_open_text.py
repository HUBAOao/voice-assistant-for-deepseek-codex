# -*- coding: utf-8 -*-
"""Opening a plain-text file imports it into the editor without sending."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
SOURCE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    source = SOURCE.read_text(encoding="utf-8")

    check(manifest.count('android:name="android.intent.action.VIEW"') == 4,
          "VIEW 入口覆盖 content/file 的文本与 JSON 来源")
    check(manifest.count('android:mimeType="text/*"') == 2
          and manifest.count('android:mimeType="application/json"') == 2,
          "文本通配只覆盖 text 子类型，另显式接收 JSON")
    check("Intent.ACTION_VIEW.equals(action)" in source,
          "Activity 捕获系统打开文本文件动作")
    check("private String readOpenText(Intent intent)" in source
          and "getContentResolver().openInputStream(uri)" in source
          and 'new FileInputStream(new File(path))' in source,
          "content:// 与 file:// 都通过原生输入流读取")
    check("text.length() < 120000" in source
          and "Math.min(count, remain)" in source,
          "外部文本仍限制在 12 万字符")
    check("private static boolean isOpenableTextMime(String type)" in source
          and 'clean.startsWith("text/")' in source
          and '"application/json".equals(clean)' in source,
          "运行时只放行文本子类型和 application/json")
    check("pumpSharedText()" in source
          and "window.onAndroidSharedText" in source,
          "读取完成后仍交回现有输入框通道")
    check("press_enter" not in source.split("readOpenText", 1)[1].split(
        "appendSharedPiece", 1)[0],
          "打开文本不会自动提交")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
