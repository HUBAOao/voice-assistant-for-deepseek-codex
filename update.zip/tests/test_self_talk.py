# -*- coding: utf-8 -*-
"""验收两件事：① 出厂应答语有 20 条；②「自称」真的会被念出来（而且有三档频率）。

用户原话：「再多来点硬达鱼（应答语），来个 20 个」「我发现你从来没有用过自称」。
"""
from __future__ import annotations

import importlib.util
import re
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def load_overlay_defaults() -> dict:
    """只要默认值表，不启动窗口。"""
    import ast

    src = (APP / "overlay.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
                getattr(t, "id", "") == "DEFAULTS" for t in node.targets):
            return ast.literal_eval(node.value)
    raise RuntimeError("没找到 DEFAULTS")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    stt = load_stt()
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 出厂的应答语：要 20 条")
    defaults = load_overlay_defaults()
    raw = defaults["ack_text"]
    parts = [p.strip() for p in re.split(r"[|\n；;]+", raw) if p.strip()]
    check(len(parts) == 20, f"出厂写了 {len(parts)} 条")
    check(len(set(parts)) == len(parts), "没有重复的")
    check(all(len(p) <= 12 for p in parts), "每条都短短的（念着不烦）")
    got = {stt.ack_phrase({"ack_text": raw}) for _ in range(400)}
    check(not any("大肥鱼" in g for g in got),
          "没配自称时不乱加自称（这轮只挑那 20 条）")

    print("② 自称：三档频率都得真的起作用")
    base = {"ack_text": "收到", "self_talk": True, "self_name": "大肥鱼",
            "user_name": "", "name_freq": "off"}
    off = {stt.ack_phrase({**base, "self_freq": "off"}) for _ in range(120)}
    check(off == {"收到"}, f"「从不说」就一直是「收到」（实际：{sorted(off)[:3]}）")
    some = [stt.ack_phrase({**base, "self_freq": "sometimes"}) for _ in range(400)]
    with_self = [s for s in some if "大肥鱼" in s]
    check(0 < len(with_self) < 400, f"「有时」{len(with_self)}/400 句带自称")
    often = [stt.ack_phrase({**base, "self_freq": "often"}) for _ in range(400)]
    with_self2 = [s for s in often if "大肥鱼" in s]
    check(len(with_self2) > len(with_self), f"「经常」更多：{len(with_self2)}/400 句")
    print("     「有时」里挑出来的几句：", sorted(set(with_self))[:5])

    print("③ 自称关掉、名字空着：都不许硬说")
    check(all(stt.ack_phrase({**base, "self_talk": False, "self_freq": "often"}) == "收到"
              for _ in range(60)), "关了自称就不自称")
    check(stt.self_phrase({**base, "self_name": ""}) == "", "名字空着就不说")
    check(stt.self_phrase({**base, "self_freq": "off"}) == "", "「从不说」时这句也不说")

    print("④ 干完活的自我介绍（日程/任务那类）也要按频率来")
    often_done = [stt.self_phrase({**base, "self_freq": "often"}) for _ in range(200)]
    check(sum(1 for s in often_done if s) > 100,
          f"「经常」时 {sum(1 for s in often_done if s)}/200 次会报一句「大肥鱼完成任务啦」")
    check(all(s == "" or s.startswith("大肥鱼") for s in often_done), "报的都是自称开头")

    print("⑤ 设置里那三档开关在（悬浮窗 UI）")
    src = (APP / "overlay.py").read_text(encoding="utf-8")
    check("self_freq_value" in src and "set_self_freq" in src
          and "refresh_self_freq" in src, "面板里有「自称频率」这一行和三档按钮")
    check('"self_freq": self.self_freq_value' in src, "面板保存时会写进配置")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
