# -*- coding: utf-8 -*-
"""验收"念回答"：拿真窗口里抠出来的文字当样本，看它能不能挑出最新那条回答。"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
SAMPLE = ROOT / "work" / "uia-sample.txt"
LIVE = ROOT / "work" / "uia-live-sample.txt"      # 2026-10-07 21:07 真窗口抠出来的（新界面：输入框+操作栏+diff）
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    spec = importlib.util.spec_from_file_location("rr", APP / "reply_reader.py")
    rr = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rr)
    doc = SAMPLE.read_text(encoding="utf-8")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print(f"① 用真窗口的样本（{len(doc)} 字）挑最新回答")
    got = rr.extract_reply(doc, "能不能所有任务对话都出声")
    check(bool(got), "挑出来了")
    check("这个我得先验证一件事" in got, "开头是这回的回答，不是上一轮的")
    check("已运行" not in got and "Add-Type" not in got,
          "没把界面上那些「已运行 $code…」念进去")
    check("你说" not in got, "没把「你说：」也念出来")
    print("   摘出来的前 120 字：", got[:120].replace("\n", " "))
    check(len(got) < len(doc) // 2, f"只取了回答那一截（{len(got)} 字，原文 {len(doc)} 字）")

    print("\n② 有「XX 说：」标记的窗口：取标记后面的回答（不是把你那句也念了）")
    fake = "界面字\n你说：\n我发的那句\n12:00\nChatGPT 说：\n这是回答内容。第二句。\n\ufffc\n"
    got2 = rr.extract_reply(fake, "我发的那句")
    check("这是回答内容" in got2 and "我发的那句" not in got2, f"取到了：{got2[:40]}")
    check(rr.extract_reply("随便的界面文字 我发的那句 [回答] 这是回答内容。",
                           "我发的那句") == "", "没有标记 → 不念")

    print("\n③ 空文本 / 没有回答：不能崩、返回空")
    check(rr.extract_reply("", "x") == "", "空文本 → 空")
    check(rr.extract_reply("一堆界面字没有对话", "") == "", "只有界面字 → 空")

    print("\n④ 切句子：长回答要能一句一句念")
    parts = rr.sentences("第一句。第二句！第三句？最后没有标点")
    check(len(parts) == 4, f"切成了 {len(parts)} 句：{parts}")
    check("最后没有标点" in parts[-1], "最后那句没标点也留着了（等它蹦完）")

    print("\n⑤ 念出来的回答要顺手记进共享记忆")
    got_records = []
    reader = rr.ReplyReader(speak_func=lambda t: None,
                            record=lambda t: got_records.append(t))
    check(callable(reader.record), "阅读器带上了 record 回调（stt 那边接到 syslog）")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check('record=lambda text: syslog("答"' in src, "主程序把它记成 [答] 进系统日志")
    kinds = (APP / "overlay.py").read_text(encoding="utf-8")
    check('"答": ("AI 回答"' in kinds, "对话日志窗口里给「AI 回答」单独配色")
    check('"听", "发", "念", "答"' in kinds, "「只看对话」也包含 AI 的回答")

    print("\n⑥ 今天真念错的那些：界面文字必须拦住")
    junk1 = ("21:02正在思考最新一条回复随心输入添加文件等内容完全访问DeepSeek-Flash"
             + "".join(f"跳转到用户消息 {i}" for i in range(1, 20)) + " 405")
    check(rr.extract_reply(junk1, "") == "", "纯界面拼接（跳转到用户消息 1…405）→ 不念")
    junk2 = ("编辑了文件运行了命令\n上下文已自动压缩\nChatGPT 说：\n正常的回答在这儿。\n已运行 xxx")
    got6 = rr.extract_reply(junk2, "")
    check("正常的回答在这儿" in got6 and "跳转" not in got6
          and "编辑了文件" not in got6 and "上下文已自动压缩" not in got6,
          f"带标记的也要削干净：{got6[:40]}")
    check(rr.extract_reply("编辑了文件运行了命令ChatGPT 说：正常的回答在这儿。已运行 xxx", "") == "",
          "挤成一行的界面字（标记没单独成行）→ 不念")
    # 没有「说：」标记时，宁可不念
    check(rr.extract_reply("一堆界面字 我发的那句 后面是界面按钮", "我发的那句") == "",
          "认不出标记 → 不念（以前就是这里把界面念出来的）")

    print("\n⑦ 真窗口（21:07 抠的）：输入框 + 操作栏 + diff 面板都得拦住")
    if LIVE.exists():
        live = LIVE.read_text(encoding="utf-8")
        got7 = rr.extract_reply(live, "")
        check(bool(got7), "摘到了回答")
        # 「让我先看看它到底念了什么：」是过程话（后面跟着工具调用），现在故意不念了
        check("让我先看看它到底念了什么" not in got7, f"过程话没念：{got7[:24]}")
        check("我先接着上次的 v1.90" in got7, "正经回答在")
        check("我先接着上次的 v1.90" in got7, "后面那段回答也在（不是只念第一句）")
        check("跳转到用户消息 1 跳转到用户消息 2" not in got7, "几百条「跳转到用户消息」没被念")
        check("个文件已更改" not in got7, "「N 个文件已更改」没被念")
        check("启用自动换行" not in got7, "「启用自动换行」这种界面开关没被念")
        check("\ufffc" not in got7, "图片占位符没被念")
        check(len(got7) < len(live) // 10, f"只取了回答那一截（{len(got7)} 字，窗口 {len(live)} 字）")
        print("   摘出来：", got7[:160].replace("\n", " / "))
    else:
        check(False, f"缺样本文件 {LIVE}")

    print("\n⑧ 不能把「我自己刚发出去的那句」当回答念（真机出过）")
    waiting = ("一堆界面字\n你说：\n我在另一个窗口里识别，然后就没反应了\n22:21\n\ufffc\n"
               "\ufffc\n运行了命令\n最新一条回复\n随心输入\n添加文件等内容\n完全访问\n")
    check(rr.extract_reply(waiting, "我在另一个窗口里识别，然后就没反应了") == "",
          "窗口还没画出回答 → 一个字的回答都不给（以前会念你刚说的那句）")
    echo = ("你说：\n我在另一个窗口里识别，然后就没反应了。\n22:21\n\ufffc\n"
            "ChatGPT 说：\n我在另一个窗口里识别，然后就没反应了。它明明识别到了\n"
            "最新一条回复\n随心输入\n")
    check(rr.extract_reply(
        echo, "我在另一个窗口里识别，然后就没反应了。它明明识别到了，但是却自己取消了") == "",
        "摘出来的就是我发的那句（被截了一半）→ 也不念")
    quoted = ("你说：\n帮我查天气\n22:21\n\ufffc\nChatGPT 说：\n你说「帮我查天气」，"
              "我查了：明天晴，18 到 26 度。\n最新一条回复\n随心输入\n")
    got_q = rr.extract_reply(quoted, "帮我查天气")
    check("明天晴" in got_q, f"回答里引用了我那句 + 正文 → 照念：{got_q[:30]}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
