# -*- coding: utf-8 -*-
"""Startup restoration and small desktop callbacks stay outside ``main()``."""
from __future__ import annotations

import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_startup_callbacks import (  # noqa: E402
    DesktopCallbackDependencies,
    DesktopRuntimeCallbacks,
    SavedRuntimeTargets,
)


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state, **fields) -> None:
        self.calls.append((state, fields))


class TalkState:
    def __init__(self, armed: bool) -> None:
        self.armed = armed
        self.calls = 0

    def arm_followup(self) -> bool:
        self.calls += 1
        return self.armed


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    phone_window = {"title": "旧会话", "id": "old"}
    mute = {"on": True}
    SavedRuntimeTargets(phone_window, mute).restore({
        "phone_target": "新会话",
        "phone_target_id": "thread-new",
        "muted": 0,
    })
    check(
        phone_window == {"title": "新会话", "id": "thread-new"},
        "启动恢复保留手机目标标题和真实线程号",
    )
    check(mute == {"on": False}, "启动恢复保留原静音布尔转换")

    status = Status()
    spoken = []
    beeps = []
    logs = []
    emitted = []
    talk = TalkState(armed=True)
    spoken_flag = {"first": True}
    selected_value = ["选中的文字"]
    deps = DesktopCallbackDependencies(
        wake_words=["大肥鱼"],
        talk_state=talk,
        followup_seconds=4.5,
        status_provider=lambda: status,
        bump_achievements=lambda kind: (
            ["第一条", "第二条"] if kind == "demo" else []
        ),
        speak=spoken.append,
        beep=lambda freq, ms: beeps.append((freq, ms)),
        selected_text=lambda: selected_value[0],
        syslog=lambda tag, text: logs.append((tag, text)),
        emit=emitted.append,
        spoken_flag=spoken_flag,
    )
    callbacks = DesktopRuntimeCallbacks(deps)

    callbacks.arm_followup()
    check(talk.calls == 1 and status.calls[-1][0] == "listening",
          "连续对话仍先询问状态机再更新监听提示")
    check("4.5 秒内免唤醒" in emitted[-1],
          "连续对话提示保留原秒数格式")

    talk.armed = False
    before = len(status.calls)
    callbacks.arm_followup()
    check(len(status.calls) == before,
          "状态机拒绝续听时不覆盖当前状态")

    callbacks.award("demo")
    check(spoken == ["解锁成就：第一条", "解锁成就：第二条"],
          "多枚成就仍逐个播报")
    check(beeps == [(1320, 90), (1320, 90)],
          "成就提示音沿用原频率和时长")
    check(status.calls[-1] == ("sent", {"text": "🏆 第二条"}),
          "最后一项成就刷新原状态文案")

    callbacks.say_selected()
    check(spoken[-1] == "选中的文字", "朗读选中仍播报原文")
    check(logs[-1] == ("读", "朗读选中 5 字"),
          "朗读选中保留日志标签和字数")
    check(status.calls[-1] == ("sent", {"text": "🔊 朗读选中 5 字"}),
          "朗读选中保留状态文案")

    selected_value[0] = ""
    callbacks.say_selected()
    check(spoken[-1] == "没选中文字哦", "空选区保留原提示")

    callbacks.on_speech()
    callbacks.on_speech()
    check(spoken_flag["first"] is False,
          "首次识别提示只标记一次")
    check("听到声音" in emitted[-2] and "正在识别" in emitted[-1],
          "识别提示保留首次与后续文案")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    main_source = ast.get_source_segment(source, main_node) or ""
    for old_definition in (
        "def restore_saved_state(",
        "def arm_followup(",
        "def award(",
        "def say_selected(",
        "def on_speech(",
    ):
        check(old_definition not in main_source,
              f"main() 不再内联 {old_definition[:-1]}")
    check("saved_targets.restore" in main_source,
          "启动恢复仍由 main() 注入原目标")
    check("DesktopRuntimeCallbacks(" in main_source,
          "入口回调由一个可测试装配创建")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
