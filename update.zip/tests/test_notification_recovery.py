# -*- coding: utf-8 -*-
"""Static contract for notification recovery after reboot or APK replacement."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
AND = ROOT / "work" / "android-app"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    receiver = (
        AND / "java" / "com" / "hubao" / "voiceassistant"
        / "NotifyRecoveryReceiver.java"
    ).read_text(encoding="utf-8")
    manifest = (AND / "AndroidManifest.xml").read_text(encoding="utf-8")
    activity = (
        AND / "java" / "com" / "hubao" / "voiceassistant"
        / "MainActivity.java"
    ).read_text(encoding="utf-8")
    diagnostics = (
        AND / "java" / "com" / "hubao" / "voiceassistant"
        / "DeviceDiagnostics.java"
    ).read_text(encoding="utf-8")
    report = (
        AND / "java" / "com" / "hubao" / "voiceassistant"
        / "DiagnosticReport.java"
    ).read_text(encoding="utf-8")
    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    management = (
        APP / "phone_feature" / "ui" / "management.js"
    ).read_text(encoding="utf-8")

    check("BOOT_COMPLETED" in receiver and "MY_PACKAGE_REPLACED" in receiver,
          "恢复接收器覆盖设备重启与 APK 覆盖升级")
    check('getBoolean("notify_done", true)' in receiver,
          "恢复只遵从用户已有的忙完提醒开关")
    check("startForegroundService" in receiver
          and "startService" in receiver,
          "恢复路径兼容新旧 Android 前台服务启动方式")
    check("notify_recovery_last_at" in receiver
          and "notify_recovery_count" in receiver
          and "notify_recovery_last_error" in receiver,
          "恢复动作记录时间、次数、来源与失败原因")
    check("conversation" not in receiver.lower()
          and "token" not in receiver.lower()
          and "http" not in receiver.lower(),
          "恢复记录不含对话、令牌或服务器地址")
    check("NotifyRecoveryReceiver" in manifest
          and 'android.intent.action.BOOT_COMPLETED' in manifest
          and 'android.intent.action.MY_PACKAGE_REPLACED' in manifest,
          "清单注册系统重启与覆盖升级广播")
    check("recoverNotificationService" in activity
          and "notificationRecoveryProbe" in activity,
          "APK 原生桥支持手动恢复与记录读取")
    check("notify_recovery_last_ok" in diagnostics
          and "notify_recovery_last_reason" in diagnostics,
          "后台就绪快照包含恢复记录")
    check('"notification_recovery"' in report
          and "NotifyRecoveryReceiver.snapshot" in report,
          "隐私受限诊断导出包含独立恢复分区")
    check('id="acceptNotifyRecover"' in page
          and 'id="acceptNotifyRecovery"' in page,
          "真机验收页提供恢复动作和记录入口")
    check("recoveryReasonText" in management
          and "设备重启" in management
          and "APK 覆盖升级" in management,
          "页面区分重启、覆盖升级和手动恢复来源")
    check("notify_recovery_last_at" in management,
          "后台就绪现场展示恢复记录")

    apk = APP / "语音助手-手机端.apk"
    if not apk.exists():
        check(False, "手机 APK 不在")
    else:
        with zipfile.ZipFile(apk) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for needle, label in (
            (b"NotifyRecoveryReceiver", "恢复接收器类"),
            (b"recoverNotificationService", "手动恢复原生方法"),
            (b"notificationRecoveryProbe", "恢复记录读取方法"),
            (b"findeck-notify-recovery-v1", "恢复记录格式"),
            (b"notify_recovery_last_reason", "恢复来源字段"),
        ):
            check(needle in dex, f"DEX 包含{label}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
