# -*- coding: utf-8 -*-
"""Unit tests for the read-only FinDeck health checks."""
from __future__ import annotations

import socket
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(ROOT))

from core import health  # noqa: E402


def test_path_checks(tmp: Path) -> None:
    assert health.check_path("present", tmp).ok
    assert not health.check_path("missing", tmp / "missing").ok


def test_tcp_check() -> None:
    server = socket.socket()
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    port = server.getsockname()[1]
    try:
        assert health.check_tcp("local", "127.0.0.1", port).ok
    finally:
        server.close()


def test_report_shape(tmp: Path) -> None:
    (tmp / "stt.py").write_text("", encoding="utf-8")
    (tmp / "phone_link.py").write_text("", encoding="utf-8")
    (tmp / "phone_page.html").write_text("", encoding="utf-8")
    (tmp / "codex_threads.py").write_text("", encoding="utf-8")
    (tmp / "overlay.py").write_text("", encoding="utf-8")
    for relative in (
            "voice_feature/action_dispatch.py",
            "voice_feature/feature_commands.py",
            "voice_feature/maintenance_runtime.py",
            "voice_feature/desktop_runtime_assembly.py",
            "voice_feature/phone_runtime_assembly.py",
            "voice_feature/runtime_run_assembly.py",
            "voice_feature/runtime_interaction_assembly.py",
            "phone_feature/media_routes.py",
            "phone_feature/history_routes.py",
            "overlay_feature/settings_pages_mixin.py",
            "overlay_feature/settings_features_mixin.py",
            "overlay_feature/settings_feature_collect_mixin.py",
            "overlay_feature/settings_appearance_mixin.py",
            "overlay_feature/settings_text_input_mixin.py",
            "overlay_feature/settings_preference_chips_mixin.py",
            "overlay_feature/settings_background_size_mixin.py",
            "overlay_feature/settings_identity_mixin.py",
            "overlay_feature/settings_response_mixin.py",
            "voice_feature/microphone_recovery.py",
            "phone_feature/ui/bootstrap.js",
            "phone_feature/ui/chat.js"):
        if relative == "phone_feature/ui/chat.js":
            (tmp / "phone_feature" / "ui" / "plugins.js").write_text(
                "", encoding="utf-8")
        path = tmp / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")
    report = health.collect(tmp, include_phone=False)
    assert "checks" in report
    assert isinstance(report["ok"], bool)
    assert isinstance(report["error_count"], int)
    names = {item["name"] for item in report["checks"]}
    assert {"voice_action_dispatch", "phone_media_routes",
            "voice_feature_commands", "phone_history_routes",
            "overlay_settings_pages",
            "voice_desktop_runtime_assembly",
            "voice_phone_runtime_assembly",
            "voice_runtime_run_assembly",
            "overlay_settings_feature_collect",
            "overlay_settings_identity",
            "overlay_settings_response",
            "phone_ui_bootstrap", "phone_ui_chat",
            "voice_maintenance_runtime", "phone_ui_plugins"} <= names
    assert {
        "voice_runtime_interaction_assembly",
        "overlay_settings_appearance",
        "overlay_settings_text_input",
        "overlay_settings_preference_chips",
        "overlay_settings_background_size",
    } <= names


def test_version_compatibility_logic() -> None:
    assert health.check_codex_compat.__doc__


if __name__ == "__main__":
    import tempfile

    with tempfile.TemporaryDirectory() as raw:
        path = Path(raw)
        test_path_checks(path)
        test_tcp_check()
        test_report_shape(path)
        test_version_compatibility_logic()
    print("test_health_check: PASS")
