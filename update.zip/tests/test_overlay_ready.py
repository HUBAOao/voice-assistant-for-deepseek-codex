# -*- coding: utf-8 -*-
"""验收"悬浮窗到底有没有显示出来"这套回执：
正常的要认；崩了的要能说出原因并重试；窗口没显示出来也算失败。
"""
from __future__ import annotations

import importlib.util
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "ready-test"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    stt = load_stt()
    sandbox = S / "app"
    sandbox.mkdir(parents=True, exist_ok=True)
    stt.HERE = sandbox
    stt.OVERLAY_READY = sandbox / "overlay_ready.json"
    spoken = []
    stt.speak = lambda t: spoken.append(t)      # 别真念出来
    logged = []
    stt.syslog = lambda tag, t: logged.append((tag, t))

    print("① 悬浮窗正常：应该认它")
    (sandbox / "overlay.py").write_text(
        "import json, os, time\n"
        "from pathlib import Path\n"
        "p = Path(__file__).with_name('overlay_ready.json')\n"
        "p.write_text(json.dumps({'pid': os.getpid(), 'ts': time.time(),"
        " 'size': [344, 112], 'visible': True}), encoding='utf-8')\n"
        "time.sleep(20)\n", encoding="utf-8")
    proc = stt.start_overlay()
    check(proc is not None, "起得来（返回了进程）")
    check(stt.OVERLAY_READY.exists(), "回执文件写出来了")
    if proc:
        proc.kill()

    print("② 悬浮窗崩了：要说出原因，还要重试")
    spoken.clear()
    (sandbox / "overlay.py").write_text(
        "from pathlib import Path\n"
        "Path(__file__).with_name('overlay-error.log').write_text(\n"
        "    'Traceback (most recent call last):\\n"
        "ImportError: DLL load failed while importing _imaging\\n', encoding='utf-8')\n"
        "raise SystemExit(3)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    t0 = time.time()
    proc = stt.start_overlay()
    took = time.time() - t0
    check(proc is None, "两次都不行 → 返回 None（不再假装成功）")
    check(any("DLL load failed" in s for s in spoken)
          or any("DLL load failed" in str(x) for x in logged),
          f"把日志里的原因说出来了：{(spoken or logged)[-1]}")
    # 它一崩就立刻能看出来，不该干等到超时（超时那条路见 ④）
    check(took < 9, f"崩了立刻就看出来，没干等（花了 {took:.0f} 秒）")

    print("③ 窗口建了但没显示（visible=False）：也算失败")
    (sandbox / "overlay.py").write_text(
        "import json, os, time\n"
        "from pathlib import Path\n"
        "Path(__file__).with_name('overlay_ready.json').write_text(json.dumps(\n"
        "    {'pid': os.getpid(), 'ts': time.time(), 'size': [344, 112],"
        " 'visible': False}), encoding='utf-8')\n"
        "time.sleep(20)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    import subprocess
    runner = Path(sys.executable).with_name("pythonw.exe")
    if not runner.exists():
        runner = Path(sys.executable)
    started = time.time()
    proc3 = subprocess.Popen([str(runner), str(sandbox / "overlay.py")],
                             creationflags=0x08000000)
    reason = stt.wait_overlay_ready(started, 3.0)
    proc3.kill()
    check("没显示" in reason, f"识别为失败：{reason}")

    print("④ 没人写回执：等超时")
    (sandbox / "overlay.py").write_text("import time\ntime.sleep(30)\n", encoding="utf-8")
    try:
        stt.OVERLAY_READY.unlink()
    except OSError:
        pass
    t0 = time.time()
    reason = stt.wait_overlay_ready(time.time() - 1, 2.0)
    check("没把窗口显示出来" in reason and time.time() - t0 >= 1.8,
          f"超时后给了说法：{reason}")
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
