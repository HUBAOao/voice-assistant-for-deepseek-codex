# -*- coding: utf-8 -*-
"""端到端量一遍：同一段"大肥鱼"音频，开热词 / 不开热词，识别结果差多少。"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.path.insert(0, str(APP))

import say  # noqa: E402
from stt import Transcriber, extract_word  # noqa: E402

WAKE = ["大肥鱼"]
PHRASES = [
    "大肥鱼",
    "大肥鱼，现在把三个快捷方式合并成一个。",
    "大肥鱼把颜色切换的过渡动画做一下。",
]
NOISE_LEVELS = [0.0, 0.012, 0.022, 0.032]      # 0 是干净音频，越大越像嘈杂房间


def degrade(audio: np.ndarray, noise: float, rng: np.random.Generator) -> np.ndarray:
    """加白噪声，并且把开头结尾的静音削掉一半，模拟"说得很短促"。"""
    if noise > 0:
        audio = audio + rng.normal(0.0, noise, audio.size).astype(np.float32)
    peak = float(np.max(np.abs(audio))) or 1.0
    audio = audio / peak * 0.7
    head = int(audio.size * 0.10)
    tail = int(audio.size * 0.10)
    return audio[head:audio.size - tail]


def main() -> int:
    rng = np.random.default_rng(20261007)
    voice = "zh-CN-XiaoyiNeural"
    print("合成测试音频…")
    clips = []
    for text in PHRASES:
        mp3 = say.edge_mp3(text, voice, "+8%")
        audio, sr = say.decode_audio(mp3)
        clips.append((text, audio.astype(np.float32), sr))

    plain = Transcriber("large-v3-turbo", "cuda", None, "zh")
    hot = Transcriber("large-v3-turbo", "cuda", None, "zh", hotwords="大肥鱼 取消")
    print("热词 =", repr(hot.hotwords), "\n")

    total = {"plain": 0, "hot": 0}
    n = 0
    print("%-6s %-9s %-28s %-6s %-28s %s" % (
        "噪声", "原句", "不开热词", "命中", "开热词", "命中"))
    for text, audio, sr in clips:
        for noise in NOISE_LEVELS:
            clip = degrade(audio, noise, rng)
            if clip.size > sr * 12:
                clip = clip[: sr * 12]
            got_plain = plain.transcribe(clip)
            got_hot = hot.transcribe(clip)
            ok_plain = extract_word(got_plain, WAKE)[1]
            ok_hot = extract_word(got_hot, WAKE)[1]
            total["plain"] += int(ok_plain)
            total["hot"] += int(ok_hot)
            n += 1
            print("%-6.3f %-9s %-28s %-6s %-28s %s" % (
                noise, text[:7], got_plain[:26], "✓" if ok_plain else "✗",
                got_hot[:26], "✓" if ok_hot else "✗"))
    print(f"\n唤醒命中率：不开热词 {total['plain']}/{n}，"
          f"开热词 {total['hot']}/{n}")
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
