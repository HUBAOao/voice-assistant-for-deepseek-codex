# -*- coding: utf-8 -*-
"""Microphone recovery assembly stays deterministic and injectable."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_microphone_setup import (  # noqa: E402
    MicrophoneRuntimeDependencies,
    prepare_microphone_runtime,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    events: list[object] = []
    resolves: list[object] = []
    opens: list[object] = []
    recorders: list[dict[str, object]] = []
    replacement_stream = object()
    replacement_recorder = object()

    def resolve(value):
        resolves.append(value)
        return 7

    def open_stream(device):
        opens.append(device)
        return replacement_stream, 16000

    def make_recorder(*args, **kwargs):
        recorders.append({"args": args, "kwargs": kwargs})
        return replacement_recorder

    deps = MicrophoneRuntimeDependencies(
        resolve_device=resolve,
        open_stream=open_stream,
        make_recorder=make_recorder,
        default_input=False,
        input_value="USB Mic",
        silence=1.0,
        max_seconds=120,
        mode="talk",
        wake_enabled=False,
        level={
            "min_voiced": 0.2,
            "noise_mult": 2.5,
            "confirm": 0.7,
        },
        on_reconnecting=lambda: events.append("reconnecting"),
        on_reconnected=lambda attempt: events.append(("reconnected", attempt)),
        on_failed=lambda: events.append("failed"),
        on_interrupted=lambda: events.append("interrupted"),
    )
    session = prepare_microphone_runtime(
        stream=object(),
        rate=48000,
        recorder=object(),
        device=3,
        dependencies=deps,
    )
    check(not opens and not resolves,
          "装配阶段不会重复打开初始麦克风流")

    session.recovery.available = False
    check(session.recovery.recover(),
          "掉线后能重新打开配置的输入设备")
    check(resolves == ["USB Mic"] and opens == [7],
          "重连按原输入名称解析设备并重新开流")
    check(
        recorders
        and recorders[0]["args"]
        == (replacement_stream, 16000, 1.0, 120)
        and recorders[0]["kwargs"]
        == {
            "min_voiced": 0.62,
            "noise_mult": 2.5,
            "confirm": 0.7,
            "device": 7,
        },
        "无唤醒词的 talk 模式继续使用严格人声门槛",
    )
    check(session.recovery.stream is replacement_stream
          and session.recovery.rate == 16000
          and session.recovery.recorder is replacement_recorder
          and session.recovery.device == 7,
          "新流、采样率、录音器和设备原子替换")
    check(events == ["reconnecting", ("reconnected", 1)],
          "重连提示与成功回调保持原顺序")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
