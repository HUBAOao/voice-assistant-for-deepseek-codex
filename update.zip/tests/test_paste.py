# -*- coding: utf-8 -*-
"""验证自动粘贴 + 回车：往记事本里粘一句话，再读回来核对。"""
import ctypes
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import stt  # noqa: E402

user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
CF_UNICODETEXT = 13
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
user32.GetClipboardData.restype = ctypes.c_void_p


def read_clipboard() -> str:
    if not user32.OpenClipboard(None):
        return "<打不开剪贴板>"
    try:
        handle = user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return ""
        ptr = kernel32.GlobalLock(handle)
        text = ctypes.wstring_at(ptr)
        kernel32.GlobalUnlock(handle)
        return text
    finally:
        user32.CloseClipboard()


def key(vk, up=False):
    user32.keybd_event(vk, 0, 2 if up else 0, 0)
    time.sleep(0.03)


payload = "语音测试 ABC 123，请确认自动粘贴成功"
proc = subprocess.Popen(["notepad.exe"])


def class_of(hwnd: int) -> str:
    b = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, b, 256)
    return b.value


hwnd = 0
for _ in range(50):  # 等记事本窗口起来并抢到前台
    time.sleep(0.3)
    h = user32.GetForegroundWindow()
    if h and class_of(h).lower().startswith("notepad"):
        hwnd = h
        break
if not hwnd:
    h = user32.GetForegroundWindow()
    print(f"没等到记事本前台，当前前台是 {class_of(h)!r}，改用进程主窗口")
    time.sleep(1.0)
    # 以前这里写的是 proc.refresh()（Popen 没这个方法），记事本没抢到前台时就直接崩，
    # 其实这时候只要按记事本自己的窗口标题找一下就行。
    hwnd = int(user32.FindWindowW("Notepad", None))
    if not hwnd:
        print("（找不到记事本窗口，这次跳过粘贴测试）")
        raise SystemExit(0)
buf = ctypes.create_unicode_buffer(256)
user32.GetWindowTextW(hwnd, buf, 256)
print(f"目标窗口: {buf.value!r} class={class_of(hwnd)!r} hwnd={hwnd}")

ok = stt.paste_into(payload, hwnd, press_enter=True)
print("paste_into ->", ok)
time.sleep(1.0)

# 在记事本里全选 + 复制，读回来看内容
key(0x11); key(0x41); key(0x41, True); key(0x11, True)
time.sleep(0.3)
key(0x11); key(0x43); key(0x43, True); key(0x11, True)
time.sleep(0.6)
got = read_clipboard()
print(f"记事本内容: {got!r}")
print("MATCH:", got.strip() == payload)

proc.terminate()
