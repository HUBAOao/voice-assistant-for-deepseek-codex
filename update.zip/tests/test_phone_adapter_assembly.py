# -*- coding: utf-8 -*-
"""Phone bridge adapters are injectable and preserve silent command handling."""
from __future__ import annotations

import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.phone_adapter_assembly import (  # noqa: E402
    RuntimePhoneAdapterDependencies,
    assemble_phone_adapter,
)


class SpeechContext:
    silent = False


class Reader:
    def __init__(self, busy: bool) -> None:
        self._busy = busy

    def busy(self) -> bool:
        return self._busy


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    executed = []
    opened = []
    pieces = types.SimpleNamespace(
        raw=Path("phone-replies.jsonl"),
        last=Path("last-reply.json"),
    )
    speech = SpeechContext()
    threads = types.SimpleNamespace(
        current_thread_id=lambda: "thread-current",
        current_name=lambda: "当前会话",
        open_thread=lambda title, thread_id: opened.append(
            (title, thread_id)
        ) or (True, "已切换"),
    )
    publisher = types.SimpleNamespace(
        public_url=lambda: "https://example.test/download",
    )

    def load_module(name: str):
        if name == "codex_threads":
            return threads
        if name == "site_publish":
            return publisher
        raise ImportError(name)

    busy_reader = Reader(True)
    adapter = assemble_phone_adapter(
        RuntimePhoneAdapterDependencies(
            execute_command=lambda text: executed.append(text),
            speech_context=speech,
            thread_module="codex_threads",
            fallback_module="site_publish",
            reply_reader=lambda: busy_reader,
            raw_replies_file=pieces.raw,
            last_reply_file=pieces.last,
            import_module=load_module,
        )
    )
    adapter.process_command("手机原样输入")
    check(executed == ["手机原样输入"], "手机文字进入同一条命令管线")
    check(speech.silent is False, "处理结束后恢复念回答上下文")
    check(adapter.current_thread_id() == "thread-current",
          "当前会话 ID 仍从真实 Codex 线程读取")
    check(adapter.current_thread_name() == "当前会话",
          "当前会话名仍读取真实线程标题")
    check(adapter.switch_thread("目标", "thread-target")
          == (True, "已切换")
          and opened == [("目标", "thread-target")],
          "会话切换继续调用原 open_thread")
    check(adapter.reply_busy() is True, "回答忙碌状态原样回读")
    check(adapter.public_update_url()
          == "https://example.test/download",
          "公网更新地址继续由发布模块提供")
    check(adapter.raw_replies_file == pieces.raw
          and adapter.last_reply_file == pieces.last,
          "手机回答原话与最近回复路径保持")

    def fail(_text: str) -> None:
        raise RuntimeError("pipeline failed")

    failing = assemble_phone_adapter(
        RuntimePhoneAdapterDependencies(
            execute_command=fail,
            speech_context=speech,
            thread_module="missing_threads",
            fallback_module="missing_publish",
            reply_reader=lambda: (_ for _ in ()).throw(RuntimeError()),
            raw_replies_file=pieces.raw,
            last_reply_file=pieces.last,
            import_module=load_module,
        )
    )
    try:
        failing.process_command("会失败")
    except RuntimeError:
        pass
    check(speech.silent is False, "管线异常时也执行 finally 恢复静默开关")
    check(failing.current_thread_id() == ""
          and failing.current_thread_name() == ""
          and failing.reply_busy() is False
          and failing.public_update_url() == "",
          "可选模块或回答器异常时安全降级")

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "phone_adapter_assembly.py"
    ).read_text(encoding="utf-8")
    check("def process_phone_command(text: str)" not in source,
          "手机静默命令闭包已经离开 main()")
    check("def current_phone_thread_id()" not in source
          and "def public_update_url()" not in source,
          "会话、回答器和公网地址适配不再内联")
    check("phone_adapter.process_command" in source
          and "phone_adapter.raw_replies_file" in source,
          "主流程消费独立手机适配入口")
    check("assemble_phone_adapter" in module
          and "class RuntimePhoneAdapter" in module,
          "手机适配器可单独装配和测试")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
