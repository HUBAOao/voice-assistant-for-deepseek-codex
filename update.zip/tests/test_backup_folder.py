# -*- coding: utf-8 -*-
"""验收：导出包 / 诊断包藏进程序目录的「导出」文件夹（隐藏属性），桌面一个都不留。"""
from __future__ import annotations

import ctypes
import importlib.util
import json
import os
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "backup-test"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def desktop_packs() -> set:
    desk = Path(os.path.expanduser("~")) / "Desktop"
    if not desk.is_dir():
        desk = Path(os.path.expanduser("~")) / "桌面"
    if not desk.is_dir():
        return set()
    return {p.name for p in desk.glob("语音助手数据-*.zip")} | \
           {p.name for p in desk.glob("语音助手诊断-*.zip")}


def is_hidden(path: Path) -> bool:
    if os.name != "nt":
        return True
    attrs = ctypes.windll.kernel32.GetFileAttributesW(str(path))
    return bool(attrs & 0x02) and attrs != -1


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    before = desktop_packs()
    print(f"桌面现有的导出/诊断包：{sorted(before) or '（没有）'}")

    stt = load_stt()
    sandbox = S / "app"
    if sandbox.exists():
        shutil.rmtree(sandbox, ignore_errors=True)
    sandbox.mkdir(parents=True)
    (sandbox / "transcripts.md").write_text("# 我说过的话\n- 哈喽\n", encoding="utf-8")
    (sandbox / "notes.md").write_text("- 买牛奶\n", encoding="utf-8")
    (sandbox / "syslog.md").write_text(
        "2026-10-07 04:00:00 [听] 测试\n2026-10-07 04:00:01 [发] 测试\n", encoding="utf-8")
    (sandbox / "config.json").write_text(json.dumps({"name": "备份测试"}, ensure_ascii=False),
                                         encoding="utf-8")
    stt.HERE = sandbox
    stt.BACKUP_DIR = sandbox / "导出"
    stt.SYSLOG_FILE = sandbox / "syslog.md"
    stt.CONFIG_FILE = sandbox / "config.json"
    stt.SAID_FILE = sandbox / "said.md"
    stt.DIARY_FILE = sandbox / "diary.md"
    stt.MEM_FILE = sandbox / "memory.json"
    stt.LEDGER_FILE = sandbox / "ledger.json"
    stt.ACHV_FILE = sandbox / "achievements.json"
    stt.VP_FILE = sandbox / "voiceprint.json"

    print("① 数据导出")
    out = stt.export_data()
    check(out is not None and out.parent == sandbox / "导出",
          f"数据包落在 {out.parent.name if out else '？'} 文件夹里")
    check(bool(out) and out.name.startswith("语音助手数据-"),
          f"文件名：{out.name if out else '？'}")

    print("② 诊断包")
    got = stt.diag_pack()
    check(got is not None and got.parent == sandbox / "导出", "诊断包也在同一个文件夹")
    if got:
        import zipfile
        with zipfile.ZipFile(got) as zf:
            names = zf.namelist()
        check("环境.txt" in names and "config.json" in names, f"诊断包内容：{names}")

    print("③ 文件夹是隐藏的")
    check(is_hidden(sandbox / "导出"), "「导出」文件夹带隐藏属性（资源管理器默认看不见）")
    check(desktop_packs() == before, "桌面一个新包都没多出来")

    print("④ 导入还是能找到最新那份")
    time.sleep(0.05)
    (sandbox / "transcripts.md").write_text("被改坏了", encoding="utf-8")
    packs = sorted((sandbox / "导出").glob("语音助手数据-*.zip"))
    with __import__("zipfile").ZipFile(packs[-1], "w") as zf:
        zf.writestr("transcripts.md", "# 我说过的话\n- 恢复回来的\n")
    n, msg = stt.import_data()
    check(n > 0 and "恢复回来的" in (sandbox / "transcripts.md").read_text(encoding="utf-8"),
          f"导入成功：{msg}")
    check(len(list((sandbox / "导出").glob("语音助手数据-*.zip"))) >= 2,
          "导入前自动先备份了一份现在的")

    print("⑤ 一个包都没有时的说法")
    empty = S / "empty"
    empty.mkdir(exist_ok=True)
    stt.BACKUP_DIR = empty / "导出"
    real_os = stt.os

    class _NoHome:            # 假装这台机器连桌面都没有，走"一个包都没有"的分支
        class path:
            @staticmethod
            def expanduser(_p):
                return str(S / "nobody")

    stt.os = _NoHome
    try:
        n2, msg2 = stt.import_data()
    finally:
        stt.os = real_os
    check(n2 == 0 and "没找到导出包" in msg2, f"提示：{msg2}")

    print("⑥ 悬浮窗里那一行")
    import tkinter as tk
    import overlay
    overlay.HERE = sandbox
    cfg = S / "config.json"
    cfg.write_text(json.dumps({"name": "备份测试", "overlay_bg_image": ""},
                              ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 80, "y": 80}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = cfg
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None
    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("功能")
    for _ in range(40):
        o.root.update()
        time.sleep(0.01)
    labels = [str(w.cget("text")) for w in o.stage_inner.winfo_children()
              if isinstance(w, tk.Label)]
    allw = []

    def walk(w, out):
        for c in w.winfo_children():
            out.append(c)
            walk(c, out)
        return out

    texts = [str(w.cget("text")) for w in walk(o.stage_inner, []) if isinstance(w, tk.Label)]
    check(any(t.startswith("备份与诊断") for t in texts), "「功能」页里有「备份与诊断」一行")
    check(any(t == "打包诊断" for t in texts), "有「打包诊断」按钮")
    check(any(t == "打开文件夹" for t in texts), "有「打开文件夹」按钮")
    summary = o.backup_summary()
    check("导出" in summary, f"那一行的小字：{summary}")
    o.do_diagnose()
    for _ in range(20):
        o.root.update()
    act = json.loads((S / "control.json").read_text(encoding="utf-8"))
    check(act.get("action") == "diagnose", f"点「打包诊断」→ 给主程序发 {act.get('action')!r}")
    o.root.destroy()

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
