# -*- coding: utf-8 -*-
"""验收"机器忙时怎么降级"：先关特效保住帧率，只有关了还慢才降帧。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "degrade-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

FX = ("fx_glow", "fx_sparkles", "fx_trail", "fx_reflection", "fx_sweep")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg["auto_tune"] = True
    cfg["anim_fps"] = 60
    cfg["perf_mode"] = "quality"
    for key in FX:
        cfg[key] = True
    (S / "config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 60, "y": 60}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.7, "text": "降级策略",
         "ts": time.time(), "pid": os.getpid(), "bands": [0.7] * 12}),
        encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    notes = []
    overlay.note = lambda t: notes.append(t)

    o = overlay.Overlay()
    o.alpha_override = 1.0
    for _ in range(40):
        o.root.update()
        time.sleep(0.006)

    def pretend(o, gap: float, uptime: float = 60.0) -> None:
        """假装最近 60 帧的间隔都是 gap、程序已经跑了 uptime 秒。"""
        o._started = time.time() - uptime
        o._gaps = [gap] * 60
        o._slow_checks = 0
        o._frames = 400
        o._period = gap

    print("① 一切都好时：不许动任何东西")
    pretend(o, 0.016)
    for _ in range(4):
        o.anim()
    check(o.fps == 60 and not o._auto_low and all(o.fx[k] for k in FX),
          f"帧率还是 {o.fps}，特效都还在")

    print("② 机器忙（帧间隔 50ms）：先关特效，帧率不许动")
    pretend(o, 0.05)
    for _ in range(7):                     # 要连着五次判定为慢才动手
        o.anim()
    check(o.fps == 60, f"帧率保持 {o.fps}（没有一上来就掉到 30）")
    check(not any(o.fx[k] for k in FX), "声音条特效被关掉了")
    check(o._degrade_stage == 1, f"降级到第 {o._degrade_stage} 档")
    print("     记录：", notes[-1] if notes else "（没记）")

    print("③ 关了特效还是忙：这才降到 30 帧")
    pretend(o, 0.05)
    for _ in range(7):
        o.anim()
    check(o.frame_ms == 33, f"帧间隔改成 {o.frame_ms}ms（约 30 帧）")
    print("     记录：", notes[-1] if notes else "（没记）")

    print("③b 开机那十几秒的 CPU 尖峰：不许动")
    o2 = o
    o2._degrade_stage, o2.frame_ms = 0, 16
    o2._auto_low = False
    o2.fx = {k: True for k in FX}
    pretend(o2, 0.05, uptime=5.0)          # 才开机 5 秒，正是加载模型的时候
    for _ in range(10):
        o2.anim()
    check(all(o2.fx[k] for k in FX) and o2._degrade_stage == 0,
          "启动 20 秒内的尖峰不算数（特效没被关）")

    print("④ 关掉自动降级开关：什么都不许动")
    o2 = o
    o2.auto_tune = False
    o2.fx = {k: True for k in FX}
    o2._degrade_stage, o2._frames, o2._period = 0, 400, 0.05
    o2.anim()
    check(all(o2.fx[k] for k in FX) and o2._degrade_stage == 0,
          "开关关着的时候不插手（特效没被偷偷关掉）")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
