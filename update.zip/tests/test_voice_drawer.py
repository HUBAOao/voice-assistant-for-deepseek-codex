# -*- coding: utf-8 -*-
"""验收「音色做成抽屉、直接点着选」：不再一个一个翻。"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "voice-drawer-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg.update({"overlay_bg_image": "", "auto_tune": False, "snap_edges": False})
    scratch = S / "config.json"
    scratch.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 60, "y": 60}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0.0, "text": "", "ts": time.time(),
         "pid": os.getpid()}), encoding="utf-8")
    overlay.CONFIG = scratch
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("声音")
    for _ in range(40):
        o.root.update()
        time.sleep(0.005)

    print("① 抽屉默认是收着的，按钮在那儿")
    check(not o.voice_drawer.winfo_ismapped(), "一开始不占地方")
    check(str(o.voice_more.cget("text")).startswith("选择"), f"按钮写着「{o.voice_more.cget('text')}」")

    print("② 点一下「选择」：抽屉拉开，17 个音色一行一个")
    o.toggle_voice_drawer()
    for _ in range(20):
        o.root.update()
        time.sleep(0.005)
    check(o.voice_drawer.winfo_ismapped(), "抽屉出来了")
    check(len(o.voice_rows) == len(overlay.VOICES),
          f"里面 {len(o.voice_rows)} 行（音色一共 {len(overlay.VOICES)} 个）")
    check(str(o.voice_more.cget("text")).endswith("▴"), "按钮箭头翻成朝上")

    print("③ 想用哪个直接点哪个（不再一个一个翻）")
    pick = len(overlay.VOICES) - 1
    o.voice_rows[pick].event_generate("<Button-1>", x=2, y=2)
    for _ in range(90):                 # 存盘是"改动 120ms 后才落盘"，多等一会儿
        o.root.update()
        time.sleep(0.01)
    check(o.voice_index == pick, f"点第 {pick + 1} 行就选上第 {pick + 1} 个")
    check(str(o.voice_label.cget("text")) == overlay.VOICES[pick][1],
          f"上面那行跟着变成「{o.voice_label.cget('text')}」")
    check(o.voice_rows[pick].cget("bg") == o.button_color, "选中的那行高亮")
    got = json.loads(scratch.read_text(encoding="utf-8"))
    check(got.get("voice_preset") == pick, f"配置里也存下了（voice_preset={got.get('voice_preset')}）")
    check(got.get("voice") == overlay.VOICES[pick][0], "想的和存的是一回事")

    print("④ 再点几行：每次都立刻换，不用重启")
    for idx in (0, 3, 7):
        o.voice_rows[idx].event_generate("<Button-1>", x=2, y=2)
        for _ in range(90):
            o.root.update()
            time.sleep(0.01)
        check(o.voice_index == idx, f"点第 {idx + 1} 行 → 现在是「{o._voice_text()}」")

    print("⑤ 「收起」再点一下，抽屉缩回去")
    o.toggle_voice_drawer()
    for _ in range(20):
        o.root.update()
        time.sleep(0.005)
    check(not o.voice_drawer.winfo_ismapped(), "收起来了，不占地方")
    check(str(o.voice_more.cget("text")).endswith("▾"), "箭头又朝下")

    print("⑥ 老的「◀ ▶ 一个一个翻」已经从界面上拿掉了")
    src = (APP / "overlay.py").read_text(encoding="utf-8")
    check('("◀", -1)' not in src, "界面上不再有 ◀ ▶ 两个按钮")
    check("def select_voice" in src and "def toggle_voice_drawer" in src, "直接选的那两条路都在")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
