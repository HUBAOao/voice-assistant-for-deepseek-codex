# -*- coding: utf-8 -*-
"""验收「电脑忙完 → 手机提醒」这条链：
电脑侧记完成事件（[完]）→ 手机入口把它当 done 事件发出去 → APP 里的前台服务弹通知。
顺带钉住 WebView 的文件选择器（点头像/壁纸没反应那个 bug）。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
ANDROID = ROOT / "work" / "android-app"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    rr = (APP / "reply_reader.py").read_text(encoding="utf-8")
    reply_runtime = (
        APP / "voice_feature" / "runtime_reply_assembly.py"
    ).read_text(encoding="utf-8")
    phone_history = (
        APP / "voice_feature" / "phone_history_runtime.py"
    ).read_text(encoding="utf-8")
    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    page += "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((APP / "phone_feature" / "ui").glob("*.js"))
    )
    java = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
            / "MainActivity.java").read_text(encoding="utf-8")
    svc = (ANDROID / "java" / "com" / "hubao" / "voiceassistant" / "NotifyService.java")
    diag = (ANDROID / "java" / "com" / "hubao" / "voiceassistant"
            / "DeviceDiagnostics.java")
    man = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")

    print("① 电脑这边：一条回答念完就记一条完成事件")
    check('"完", f"' in reply_runtime,
          "回答运行时把「念完」记成 [完]")
    check("finished()" in rr and "self.done(name)" in rr, "回复阅读器念完会回调出去")
    check('"完": "done"' in phone_history,
          "手机历史运行时把这条事件标成 done")

    print("\n② 手机页把完成事件显示出来（居中一行）")
    check(".done {" in page, "完成事件有自己的样式（绿色小字）")
    check('cls === "done"' in page, "渲染时会居中显示")

    print("\n③ APP 里：前台服务盯着电脑、弹通知")
    check(svc.exists(), "NotifyService.java 在")
    if svc.exists():
        s = svc.read_text(encoding="utf-8")
        check("startForeground" in s, "起了前台服务（不然退到后台就被冻结）")
        check("/api/log?since=" in s and "NotificationManager" in s,
              "轮询 /api/log 并在有新 done 时发通知")
        check("DEFAULT_SOUND" in s and "enableVibration" in s, "通知带声音和震动")
        check("CH_SERVICE" in s and "CH_DONE" in s,
              "常驻通知与完成提醒使用独立通道")
        check("notify_since" in s and "firstPoll" in s,
              "首次启动只建立通知基线，不补弹旧事件")
        check("showTestNotification" in s, "真机验收可发测试通知")
    check(diag.exists(), "Android 原生设备诊断模块存在")
    if diag.exists():
        d = diag.read_text(encoding="utf-8")
        check("record_permission" in d and "done_channel" in d,
              "诊断包含录音权限与完成通知通道")
    check("FOREGROUND_SERVICE" in man and "POST_NOTIFICATIONS" in man,
          "清单里声明了前台服务和通知权限")
    check('android:name=".NotifyService"' in man, "服务注册了")
    check("startNotifyService()" in java, "打开 APP 时会把它拉起来")
    check("notifyOn" in java and "setNotify" in java, "网页设置里能开关")
    check('id="notifyon"' in page and 'id="notifyoff"' in page,
          "手机设置里有开/关两个按钮")

    print("\n④ 顺带钉住「点头像/壁纸没反应」那个坑")
    check("WebChromeClient" in java and "onShowFileChooser" in java,
          "WebView 有 WebChromeClient（没有的话 <input file> 静默失效）")
    check("REQ_FILE" in java and "onReceiveValue(out)" in java,
          "选完/取消都会把结果交回网页（不会卡住下次点不动）")
    management = APP / "phone_feature" / "ui" / "management.js"
    plugins = APP / "phone_feature" / "ui" / "plugins.js"
    check(management.exists(), "手机管理脚本已从巨型页面拆出")
    if management.exists() and plugins.exists():
        m = management.read_text(encoding="utf-8")
        p = plugins.read_text(encoding="utf-8")
        check("pullPlugins" in p and "pullAcceptance" in m,
              "插件与真机验收界面由独立脚本提供")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
