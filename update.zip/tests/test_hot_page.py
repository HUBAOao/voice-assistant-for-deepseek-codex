# -*- coding: utf-8 -*-
"""验收"手机网页热更"：只改 phone_page.html，跑着的服务下一刷就是新页面（不用重启）。"""
import sys
import time
import urllib.request
from pathlib import Path

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.path.insert(0, str(APP))

import phone_link  # noqa: E402

MARK = "HOT-RELOAD-MARK-12345"
page_file = APP / "phone_page.html"
backup = page_file.read_text(encoding="utf-8") if page_file.exists() else None

print("① 页面文件在不在")
print("   phone_page.html：", page_file.exists(), "（大小 %d）" % (page_file.stat().st_size
      if page_file.exists() else 0))

print("② 有文件时就用文件里的那份")
if backup is not None:
    tmp = backup.replace("<body>", '<body data-hot="%s">' % MARK, 1)
    page_file.write_text(tmp, encoding="utf-8")
    got = phone_link.current_page()
    print("   读到了标记吗：", MARK in got)
else:
    print("   （没有 phone_page.html，跳过）")

print("③ 没文件时退回源码里的 PAGE")
# 别去删真文件（正在跑的服务也在用它），把"文件路径"临时指到一个不存在的地方就行
real_file = phone_link.PAGE_FILE
phone_link.PAGE_FILE = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\work\不存在的页面.html")
phone_link._page_cache["mtime"] = 0.0
got = phone_link.current_page()
phone_link.PAGE_FILE = real_file
print("   退回源码 PAGE：", got == phone_link.PAGE)

print("④ 真机：服务发出去的页面里也有标记（说明不用重启就是新的）")
import json

link = phone_link.PhoneLink(
    on_command=lambda t: None,
    get_state=lambda: {"online": True, "state": "idle", "lines": []},
    get_log=lambda: [], port=8825)
if link.start():
    try:
        time.sleep(0.2)
        page_file.write_text(
            phone_link.PAGE.replace("<body>", '<body data-hot="%s">' % MARK, 1),
            encoding="utf-8")
        with urllib.request.urlopen(
                "http://127.0.0.1:8825/?k=%s" % link.token, timeout=10) as r:
            served = r.read().decode("utf-8", "replace")
        print("   服务发出去的页面里有标记：", MARK in served)
    finally:
        link.stop()
else:
    print("   手机入口起不来")

# 收拾干净
if backup is not None:
    page_file.write_text(backup, encoding="utf-8")
else:
    try:
        page_file.unlink()
    except Exception:
        pass
print("（已经还原）")
