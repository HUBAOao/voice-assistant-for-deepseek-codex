# -*- coding: utf-8 -*-
"""Power and thermal evidence stays read-only and package-visible."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APP = ROOT / "outputs" / "voice-to-text"
SOURCE = (
    ANDROID / "java" / "com" / "hubao" / "voiceassistant"
    / "DeviceDiagnostics.java"
)
ACTIVITY = (
    ANDROID / "java" / "com" / "hubao" / "voiceassistant"
    / "MainActivity.java"
)
REPORT = (
    ANDROID / "java" / "com" / "hubao" / "voiceassistant"
    / "DiagnosticReport.java"
)
PAGE = APP / "phone_page.html"
SCRIPT = APP / "phone_feature" / "ui" / "management.js"
MANIFEST = ANDROID / "AndroidManifest.xml"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = SOURCE.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    report = REPORT.read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    script = SCRIPT.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")

    check("public static String powerContext(Activity activity)" in source,
          "原生诊断提供独立电源/散热快照")
    check("pm.getCurrentThermalStatus()" in source
          and "thermalStatusName(" in source,
          "按 Android 29+ 标准读取粗粒度散热等级")
    for field in (
        "thermal_status",
        "thermal_status_name",
        "power_save_mode",
        "device_idle_mode",
        "interactive",
        "keyguard_locked",
        "battery_percent",
        "battery_charging",
        "battery_temperature_tenths_c",
    ):
        check(f'"{field}"' in source, f"回传只读字段 {field}")
    check("setPowerSaveMode" not in source
          and "setThermalStatus" not in source
          and "WRITE_SETTINGS" not in manifest,
          "不切换省电/散热策略，不申请系统设置写权限")
    check("power_context" in report,
          "诊断快照包含电源与散热分区")
    check('id="acceptPowerContext"' in page
          and "电源与散热现场" in page,
          "真机验收页提供明确只读入口")
    check("powerContextProbe" in activity and "@JavascriptInterface" in activity,
          "WebView 通过显式受限桥接读取")
    check("powerContextProbe" in script
          and "thermal_status_name" in script
          and "battery_temperature_tenths_c" in script,
          "状态页展示散热、电源和温度现场")
    check("powerContextProbe" in script
          and "setPowerSaveMode" not in script
          and "setThermalStatus" not in script,
          "网页侧只能读取，不提供系统策略修改")

    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for symbol in (
            "powerContextProbe",
            "powerContext",
            "findeck-power-context-v1",
            "battery_temperature_tenths_c",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
