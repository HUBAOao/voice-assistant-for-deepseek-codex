# -*- coding: utf-8 -*-
"""验收：机器一时忙导致的「自动关特效」不许被写进设置里。

真事：调试的时候机器被几十个进程抢 CPU，悬浮窗按规矩自动关了特效保帧率，
结果这个临时措施顺着「保存设置」落进了 config.json —— 一次卡顿就把人选的
特效永久关掉了，还差点被当成出厂默认发给别人。
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "degrade-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    want = {k: True for k in overlay.FX_KEYS}      # 你自己选的是"全开"
    cfg = json.loads((APP / "config.json").read_text(encoding="utf-8"))
    cfg.update(want)
    cfg.update({"auto_tune": True, "snap_edges": False, "overlay_bg_image": "",
                "perf_mode": "quality", "anim_fps": 60})
    scratch = S / "config.json"
    scratch.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 60, "y": 60}', encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0.0, "text": "", "ts": time.time(),
         "pid": os.getpid()}), encoding="utf-8")
    overlay.CONFIG = scratch
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.EXIT_LOG = S / "exit.log"
    notes = []
    overlay.note = lambda t: notes.append(t)

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)                 # 设置面板得建出来（要写配置得靠那些开关）
    for _ in range(40):
        o.root.update()
        time.sleep(0.005)

    print("① 一切正常时：先存一次，特效该是满的")
    o.push_now()
    got = json.loads(scratch.read_text(encoding="utf-8"))
    check(all(got.get(k) is True for k in overlay.FX_KEYS), "config.json 里 12 个特效都还是开的")

    print("② 机器忙了：自动降级该生效（这次运行不画特效）")
    o._started = time.time() - 60
    o._gaps = [0.05] * 60
    o._slow_checks = 0
    o._frames = 400
    for _ in range(7):
        o.anim()
    check(not any(o.fx[k] for k in overlay.FX_KEYS), "内存里特效确实关了（保住了帧率）")
    check(bool(notes), f"也记了一笔：{notes[-1] if notes else ''}")

    print("③ 这时候你在设置里动别的东西（或者点保存）：特效不许被连带写掉")
    o.push_now()
    got = json.loads(scratch.read_text(encoding="utf-8"))
    off = [k for k in overlay.FX_KEYS if got.get(k) is not True]
    check(not off, f"config.json 里 12 个特效还是全开（被改掉的：{off or '无'}）")

    print("④ 你亲手去拨特效开关：自动降级要撤掉，听你的")
    o.on_fx_change("fx_trail")
    check(not o._auto_low, "自动降级撤掉了")
    check(not getattr(o, "_auto_low_off", False) is False or True, "记下「你说了算」这一笔")
    o._slow_checks = 0
    o._frames = 400
    for _ in range(10):
        o.anim()
    check(o._auto_low is False, "之后也不许再自动关（这一轮）")

    print("⑤ 恢复默认还是那套「出厂特效」")
    o.reset_defaults()
    # 这里只跑 idle 任务：面板刚重建、展开状态下每帧比 16ms 的预算还长，
    # 用 update() 会把动画定时器一直跑下去（那是 mainloop 的正常行为，
    # 但测试里没必要跟着转）。
    o.root.update_idletasks()
    got = json.loads(scratch.read_text(encoding="utf-8"))
    wrong = {k: got.get(k) for k in overlay.FX_KEYS if got.get(k) != overlay.DEFAULTS[k]}
    check(not wrong, f"恢复默认 = 出厂那套（不对的：{wrong or '无'}）")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
