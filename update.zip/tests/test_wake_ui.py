# -*- coding: utf-8 -*-
"""验证悬浮窗这侧：档位按钮、自定义档位、改唤醒词会不会自动发自检命令。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
WORK = ROOT / "work"
sys.path.insert(0, str(APP))

import overlay  # noqa: E402
import wake_levels  # noqa: E402

SCRATCH = WORK / "wakeui-scratch"
SCRATCH.mkdir(parents=True, exist_ok=True)

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMIH(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find(title: str) -> int:
    hit = {"h": 0}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(h, buf, 256)
        if buf.value == title:
            hit["h"] = h
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return hit["h"]


def grab(hwnd: int) -> Image.Image:
    r = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMIH()
    hdr.biSize = ctypes.sizeof(BMIH)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount, hdr.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return img


def main() -> int:
    cfgfile = SCRATCH / "config.json"
    cfgfile.write_text(json.dumps({
        "name": "档位测试", "overlay_width": 344, "overlay_height": 112,
        "overlay_bg_image": "", "overlay_alpha": 1.0, "anim_fps": 60,
        "wake_word": "大肥鱼", "wake_level": "宽松"}, ensure_ascii=False),
        encoding="utf-8")
    (SCRATCH / "pos.json").write_text('{"x": 80, "y": 80}', encoding="utf-8")
    (SCRATCH / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (SCRATCH / "control.json").write_text('{"action": "", "ts": 0}', encoding="utf-8")

    overlay.CONFIG = cfgfile
    overlay.POS = SCRATCH / "pos.json"
    overlay.STATUS = SCRATCH / "status.json"
    overlay.SPEAK_STATUS = SCRATCH / "speak.json"
    overlay.CONTROL = SCRATCH / "control.json"
    overlay.WAKE_TEST_FILE = SCRATCH / "wake_test.json"
    overlay.EXIT_LOG = SCRATCH / "exit.log"
    overlay.note = lambda text: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.started = time.time() - 60          # 跳过"刚启动别抢话筒"的等待
    o.set_expanded(True)
    o.show_tab("基本")
    for _ in range(160):
        if find("档位测试"):
            break
        o.root.update()
        time.sleep(0.05)
    for _ in range(60):
        o.root.update()
        time.sleep(0.01)

    print("档位按钮：", list(o.level_chips))
    print("当前档位：", o.cfg.get("wake_level"))
    print("说明行  ：", o.level_info.cget("text"))

    # 1) 切换档位
    o.set_wake_level("极宽松")
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    print("切档后  ：", o.cfg.get("wake_level"), "|", o.level_info.cget("text"))

    # 2) 加一个自定义档位（直接走解析那一步，跳过弹窗）
    got = wake_levels.from_text("名称=夜里小声\n最小发声=0.2\n噪声倍数=4\n连续块=2\n同音字=开\n开头吞字=开\n热词=开")
    name, params = got
    data = o.cfg
    custom = dict(data.get("wake_levels") or {})
    custom[name] = params
    data["wake_levels"] = custom
    data["wake_level"] = name
    o.cfg = data
    o.refresh_level_chips()
    print("加档后  ：", list(o.level_chips), "当前 =", o.cfg.get("wake_level"))

    # 3) 改唤醒词 → 应该自动发出 wake-test 命令
    (SCRATCH / "control.json").write_text('{"action": "", "ts": 0}', encoding="utf-8")
    o.entry_wake.set("大肥鱼,喂喂")
    o.push_now()
    ctrl = json.loads((SCRATCH / "control.json").read_text(encoding="utf-8"))
    print("\n改唤醒词后写下的命令：", ctrl)
    print("说明行  ：", o.level_info.cget("text"))

    # 4) 模拟主程序回了自检结果
    (SCRATCH / "wake_test.json").write_text(json.dumps(
        {"ts": time.time(), "summary": "唤醒自检：4 项全部通过，当前档位「夜里小声」"},
        ensure_ascii=False), encoding="utf-8")
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    print("收到结果后说明行：", o.level_info.cget("text"))
    print("悬浮窗提示条：", o.toast)

    for _ in range(40):
        o.root.update()
        time.sleep(0.01)
    h = find("档位测试")
    if h:
        grab(h).save(WORK / "wake-level-ui.png")
        print("已保存 wake-level-ui.png，窗口高", o.root.winfo_height())
    o.root.destroy()
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
