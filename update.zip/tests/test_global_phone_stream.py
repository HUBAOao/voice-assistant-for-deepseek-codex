from __future__ import annotations

import sys
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import phone_stream  # noqa: E402


def message(item_id: str, text: str, phase: str = "commentary") -> dict:
    return {
        "type": "response_item",
        "payload": {
            "type": "message",
            "role": "assistant",
            "id": item_id,
            "phase": phase,
            "content": [{"text": text}],
        },
    }


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    watcher = phone_stream.GlobalStreamWatcher()
    emitted: list[tuple[str, str]] = []
    finals: list[tuple[str, str]] = []
    emit = lambda conv, sentence: emitted.append((conv, sentence))
    marker = lambda conv, preview: finals.append((conv, preview))

    watcher._handle_message(
        "thread-a", "会话甲", message("a1", "甲在回答。第二句。"), emit, marker)
    watcher._handle_message(
        "thread-b", "会话乙", message("b1", "乙也在回答。", "final_answer"),
        emit, marker)
    # 同一个 rollout 行重复出现时不能刷屏。
    watcher._handle_message(
        "thread-a", "会话甲", message("a1", "甲在回答。第二句。"), emit, marker)

    checks = [
        ("两个会话都产出", {c for c, _ in emitted} == {"会话甲", "会话乙"}),
        ("甲两句完整", ("会话甲", "甲在回答。") in emitted
         and ("会话甲", "第二句。") in emitted),
        ("乙一句完整", ("会话乙", "乙也在回答。") in emitted),
        ("重复消息已去重", len(emitted) == 3),
        ("最终标记只一次", len(finals) == 1 and finals[0][0] == "会话乙"),
        ("近期会话可读取", isinstance(
            watcher.recent_threads(0), list)),
    ]
    bad = 0
    for name, ok in checks:
        print(("  ✓ " if ok else "  ✗ ") + name)
        bad += 0 if ok else 1
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
