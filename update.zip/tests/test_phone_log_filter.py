# -*- coding: utf-8 -*-
"""验收「手机上的对话流不显示那些噪音」：
（这段没听清）/（自己的声音）/（疑似幻觉）/（背景音…）/（抢话）/（开机问候）都不该冒到手机上。"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"

# 手机上应该看到的（你说的 / 它念的 / 它发的）
KEEP = [
    "（手机）状态",
    "帮我查一下明天的天气",
    "现在状态是 thinking。最近一条是你说的：…",
    "ChatGPT：帮我查一下明天的天气",
]
# 手机上不该看到的（排查用的噪音）
DROP = [
    "（这段没听清）",
    "（自己的声音）马上办。",
    "（疑似幻觉）点赞 订阅 转发",
    "（背景音，声纹 0.16）用方案二",
    "（抢话）大肥鱼 帮我研究研究微信",
    "（开机问候）晚上好，大肥鱼已经就绪",
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    src = (APP / "stt.py").read_text(encoding="utf-8")
    m = re.search(r"noise = \(([^)]*)\)", src)
    check(m is not None, "stt.py 里能找到噪音词表")
    words = tuple(w.strip().strip('"') for w in m.group(1).split(",") if w.strip()) if m else ()

    def dropped(body: str) -> bool:
        return body.startswith("（") and any(w in body[:24] for w in words)

    print("① 噪音条目要滤掉")
    for t in DROP:
        check(dropped(t), f"滤掉 ← {t[:26]}")

    print("\n② 真正的对话一个字都不能少")
    for t in KEEP:
        check(not dropped(t), f"保留 ← {t[:26]}")

    print("\n③ 手机端拿到的就是过滤后的东西")
    check("phone_log" in src and "if body.startswith" in src, "phone_log 里真的用了这条规则")
    check("（手机）" in src, "手机发来的命令照样显示（带「（手机）」标记）")
    # 「答」和「念」是同一条回答（一个记录、一个朗读），两个都发手机上就重复了；
    # 「完」是"这条回答念完了"，手机上拿它弹完成提醒。
    check('"答": "ai"' not in src, "不发「答」（不然同一条回答在手机上显示两遍）")
    check('"完": "done"' in src, "「完」当完成事件发出去（手机拿它提醒）")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
