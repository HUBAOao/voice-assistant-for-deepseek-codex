# -*- coding: utf-8 -*-
"""The ordered local-command assembly keeps legacy behavior and side effects."""
from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.local_command_assembly import (  # noqa: E402
    LocalCommandDependencies,
    dispatch_local_commands,
)


class Status:
    def __init__(self) -> None:
        self.events = []

    def set(self, state, **kwargs) -> None:
        self.events.append((state, kwargs))


def make_deps(root: Path, command: str, *, text: str | None = None):
    spoken = []
    emitted = []
    followed = []
    notes = []
    config = {
        "wave_spectrum": True,
        "reminders_enabled": True,
        "reminder_paste": False,
    }
    music = {"on": True}
    last_sent = {"text": "上一条消息", "at": time.time()}
    deps = LocalCommandDependencies(
        config=config,
        config_file=root / "config.json",
        local_text=command,
        plain_text=command.replace(" ", ""),
        text_to_send=text if text is not None else command,
        tutorial={"on": True, "step": 2},
        tutorial_document=root / "使用教程.html",
        memory_file=root / "memory.jsonl",
        last_sent=last_sent,
        music=music,
        busy={},
        voiceprint={},
        private={},
        target=None,
        tracker=None,
        from_phone=False,
        once=False,
        speak=spoken.append,
        status=Status(),
        syslog=lambda *_args: None,
        emit=emitted.append,
        load_config=lambda: dict(config),
        arm_followup=lambda: followed.append(True),
        beep=lambda *_args: None,
        run_shortcut=lambda *_args: None,
        parse_repeat=lambda text: "再来一遍" in text,
        syslog_search=lambda *_args: [],
        weekly_report=lambda: "周报内容",
        find_window=lambda target: (0, target),
        press_key=lambda *_args, **_kwargs: None,
        open_named=lambda _name: None,
        paste_clipboard=lambda *_args, **_kwargs: None,
        grab_screen=lambda: False,
        get_reply_reader=lambda: None,
        focus_active=lambda: False,
        focus_left=lambda: 0.0,
        focus_start=lambda _minutes: None,
        focus_stop=lambda: None,
        transform=lambda: None,
        brief_now=lambda: None,
        say_diary=lambda: None,
        tutorial_say=lambda step: notes.append(step),
        game_feed=lambda _command: False,
        game_start=lambda *_args: None,
        say_ledger=lambda: None,
        say_notes=lambda: None,
        add_ledger=lambda *_args: None,
        add_note=lambda *_args: None,
        clear_all_data=lambda: 0,
        undo_last=lambda: None,
        do_export=lambda: None,
        do_import=lambda: None,
        do_update=lambda: None,
        apply_update_now=lambda: None,
        diag_pack=lambda: None,
        self_check=lambda **_kwargs: [],
        train_wake_voice=lambda: None,
        set_config=lambda *_args: None,
        schedule_restart=lambda: None,
        read_selected=lambda: None,
        start_reminder=lambda *_args: None,
    )
    return deps, spoken, emitted, followed, notes, config, music


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)

        deps, spoken, emitted, followed, _notes, _config, _music = make_deps(
            root, "再来一遍"
        )
        result = dispatch_local_commands(deps)
        check(not result.handled
              and result.text_to_send == "上一条消息"
              and spoken == ["好，再来一次"],
              "重复命令只替换待发送文本，继续原有发送流程")

        deps, _spoken, _emitted, followed, notes, _config, _music = make_deps(
            root, "使用教程"
        )
        result = dispatch_local_commands(deps)
        check(result.handled and not result.terminate
              and notes == [2] and followed,
              "教程阶段仍朗读当前课并调用原跟进逻辑")

        deps, spoken, _emitted, _followed, _notes, config, music = make_deps(
            root, "音浪关"
        )
        result = dispatch_local_commands(deps)
        check(result.handled and config["wave_spectrum"] is False
              and music["on"] is False
              and spoken == ["音浪关了"],
              "音浪命令仍同步配置、运行状态和原提示")

        deps, _spoken, _emitted, _followed, _notes, _config, _music = make_deps(
            root, "清空所有记录"
        )
        result = dispatch_local_commands(deps)
        check(result.handled and deps.private["clear_ask"] > time.time(),
              "清空仍需先进入确认窗口，不会直接删除数据")

        deps, spoken, _emitted, _followed, _notes, _config, _music = make_deps(
            root, "1+1"
        )
        result = dispatch_local_commands(deps)
        check(result.handled and any("等于" in text for text in spoken),
              "计算器命令仍由本地命令装配直接处理")

        deps, spoken, _emitted, _followed, _notes, _config, _music = make_deps(
            root, "普通聊天", text="普通聊天"
        )
        result = dispatch_local_commands(deps)
        check(not result.handled and not spoken
              and result.text_to_send == "普通聊天",
              "普通聊天原样交给发送管线")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    module = (
        APP / "voice_feature" / "local_command_assembly.py"
    ).read_text(encoding="utf-8")
    check("def shortcut_stage(" not in stt
          and "stages = [" not in stt,
          "main() 不再内联本地命令阶段构造")
    utterance = (
        APP / "voice_feature" / "runtime_utterance_assembly.py"
    ).read_text(encoding="utf-8")
    check("dispatch_local_commands(" in utterance
          and "def dispatch_local_commands(" in module,
          "单句处理运行时只调用本地命令装配入口")
    check(module.index('LocalCommandStage("shortcut"')
          < module.index('"game",')
          < module.index('LocalCommandStage("focus"')
          < module.index('"note",')
          < module.index('"reminder",'),
          "快捷、游戏、专注、笔记与提醒阶段顺序保持")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
