# -*- coding: utf-8 -*-
"""Tutorial and diary extraction keeps wording, state and write boundaries."""
from __future__ import annotations

import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.diary_tutorial_runtime import (  # noqa: E402
    TUTORIAL,
    DiaryTutorialDependencies,
    DiaryTutorialRuntime,
)


class Status:
    def __init__(self) -> None:
        self.calls = []

    def set(self, state: str, **kwargs) -> None:
        self.calls.append((state, kwargs))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory(prefix="findeck_diary_") as raw:
        root = Path(raw)
        status = Status()
        spoken = []
        logs = []
        achievements = {"diary_day": ""}
        writes = []
        now = datetime(2026, 10, 23, 22, 15, 0)
        runtime = DiaryTutorialRuntime(
            DiaryTutorialDependencies(
                status=status,
                speak=spoken.append,
                syslog=lambda tag, body: logs.append((tag, body)),
                config={"diary_enabled": True, "diary_hour": 22},
                wake_words=["大肥鱼"],
                diary_summary=lambda _day: "今天你跟我说了两句话。",
                read_achievements=lambda: achievements,
                write_achievements=writes.append,
                diary_file=root / "diary.md",
                now=lambda: now,
                emit=lambda _text: None,
            )
        )

        check(len(TUTORIAL) == 17, "教程仍为 17 课")
        check("听到两声提示音" in TUTORIAL[0][1], "教程第一课文案保持")
        runtime.tutorial_say(0)
        check(runtime.state == {"on": True, "step": 0}, "教程记录当前课次")
        check(spoken and "「大肥鱼，帮我查一下明天的天气」" in spoken[-1],
              "唤醒词仍按原位置替换")
        check(logs[-1][0] == "教" and "第 1 课" in logs[-1][1],
              "教程继续写原系统日志")
        runtime.tutorial_say(17)
        check(runtime.state["on"] is False and spoken[-1] == "教程讲完了",
              "教程结束后恢复旧收口行为")

        diary = runtime.say_diary()
        check(diary == "今天你跟我说了两句话。", "日记正文来自原摘要函数")
        saved = (root / "diary.md").read_text(encoding="utf-8")
        check("## 2026-10-23" in saved and diary in saved,
              "日记继续追加到原 diary.md 格式")
        check(status.calls[-1][1].get("text") == "📔 日记已生成",
              "日记完成状态文案保持")

        runtime.maybe_night_diary()
        check(writes and achievements["diary_day"] == "2026-10-23",
              "到点只标记并播报当天日记")
        runtime.maybe_night_diary()
        check(len(writes) == 1, "同一天不重复写日记标记")

        now = datetime(2026, 10, 23, 21, 59, 0)
        achievements["diary_day"] = ""
        runtime.maybe_night_diary()
        check(len(writes) == 1, "未到设定时间不触发日记")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    module = (APP / "voice_feature" / "diary_tutorial_runtime.py").read_text(
        encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "desktop_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    check("TUTORIAL = [" not in stt, "stt.py 不再内联教程正文")
    check("def say_diary(" not in stt, "stt.py 不再内联日记写入")
    check("DiaryTutorialRuntime(" in assembly,
          "桌面装配只创建日记教程运行时")
    check("tutorial_say = desktop.tutorial_say" in stt,
          "旧 tutorial_say 入口仍保留")
    check("say_diary = desktop.say_diary" in stt,
          "旧 say_diary 入口仍保留")
    check("maybe_night_diary = desktop.maybe_night_diary" in stt,
          "旧 maybe_night_diary 入口仍保留")
    check("class DiaryTutorialRuntime" in module,
          "日记教程业务位于独立可注入模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
