# -*- coding: utf-8 -*-
"""Late-bound utterance dispatch keeps the historical process contract."""
from __future__ import annotations

import ast
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_utterance_dispatch import UtteranceDispatch  # noqa: E402


class Runtime:
    def __init__(self) -> None:
        self.calls = []

    def process(self, audio, **kwargs):
        self.calls.append((audio, kwargs))
        return True


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    emitted = []
    dispatch = UtteranceDispatch(timeout=0.01, emit=emitted.append)
    check(dispatch.handle("audio", 16000, "手机原文", True) is False,
          "未装配时按原超时语义拒绝本句")
    check(emitted == ["（语音处理装配还没准备好，这句先跳过）"],
          "未装配时保留原中文提示")

    runtime = Runtime()
    dispatch.bind(runtime)
    check(
        dispatch.handle("audio-2", sr=8000, pre_text="文字", from_phone=True)
        is True,
        "装配完成后转发处理结果",
    )
    check(
        runtime.calls == [(
            "audio-2",
            {"sr": 8000, "pre_text": "文字", "from_phone": True},
        )],
        "位置参数与关键字参数不丢失、不改名",
    )

    source = (APP / "stt.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    main_node = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    main_source = ast.get_source_segment(source, main_node) or ""
    check("def handle(" not in main_source,
          "main() 不再内联 handle() 等待与转发业务")
    check("utterance = {\"runtime\": None}" not in main_source
          and "utterance_ready = threading.Event()" not in main_source,
          "main() 不再维护可变 holder 和就绪事件")
    check("UtteranceDispatch(" in main_source
          and "utterance_dispatch.bind(" in main_source,
          "main() 只创建并绑定独立调度对象")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
