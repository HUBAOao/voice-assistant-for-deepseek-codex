# -*- coding: utf-8 -*-
"""The main singleton uses one reusable gate and honors --allow-multiple."""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.instance_guard import SingleInstanceGuard  # noqa: E402


def main() -> int:
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as folder:
        lock = Path(folder) / "instance.lock"
        alive = {123456}

        def pid_alive(pid: int) -> bool:
            return pid in alive or pid == os.getpid()

        first = SingleInstanceGuard(
            name="FinDeck-test-main",
            lock_path=lock,
            platform_name="test",
            pid_alive=pid_alive,
        )
        second = SingleInstanceGuard(
            name="FinDeck-test-main",
            lock_path=lock,
            platform_name="test",
            pid_alive=pid_alive,
        )
        check(first.acquire() and first.owned, "首个实例取得 PID 锁")
        check(lock.read_text(encoding="utf-8").strip() == str(os.getpid()),
              "PID 锁写入当前进程号")
        lock.write_text("123456", encoding="utf-8")
        check(not second.acquire() and not second.owned,
              "存活 PID 会阻止第二个实例")
        lock.write_text(str(os.getpid()), encoding="utf-8")
        first.release()
        check(not lock.exists(), "正常退出会移除自己持有的 PID 锁")

        lock.write_text("123456", encoding="utf-8")
        stale = SingleInstanceGuard(
            name="FinDeck-test-main",
            lock_path=lock,
            platform_name="test",
            pid_alive=lambda _pid: False,
        )
        check(stale.acquire(), "上一个进程已退出时可接管陈旧 PID 锁")
        check(lock.read_text(encoding="utf-8").strip() == str(os.getpid()),
              "接管后 PID 锁更新为当前进程")
        stale.release()

        kept = lock.write_text("other-owner", encoding="utf-8")
        third = SingleInstanceGuard(
            name="FinDeck-test-main",
            lock_path=lock,
            platform_name="test",
            pid_alive=lambda _pid: False,
        )
        third.acquire()
        lock.write_text("foreign", encoding="utf-8")
        third.release()
        check(lock.exists() and lock.read_text(encoding="utf-8") == "foreign",
              "退出时不会删除已被其他持有者替换的锁文件")

        if os.name == "nt":
            process_guard = SingleInstanceGuard(
                name="FinDeck-test-process",
                lock_path=Path(folder) / "process.lock",
            )
            child = subprocess.Popen(
                [sys.executable, "-c", "pass"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            child.wait(timeout=10)
            check(process_guard._default_pid_alive(os.getpid()),
                  "Windows 当前 PID 被判为存活")
            check(not process_guard._default_pid_alive(child.pid),
                  "Windows 已退出 PID 不会被可打开句柄误判为存活")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    bootstrap = (APP / "voice_feature" / "runtime_bootstrap.py").read_text(
        encoding="utf-8"
    )
    check('"--allow-multiple" in raw_args' in bootstrap
          and "sys.argv[1:]," in stt,
          "启动装配在 argparse 前识别原始 --allow-multiple")
    check("if not allow_multiple and not guard.acquire():" in bootstrap,
          "启动装配只申请一次并遵守多实例开关")
    check(stt.count("SingleInstanceGuard(") == 2,
          "main() 与兼容入口共用一个单实例边界")
    check("globals()[\"_MAIN_MUTEX\"]" not in stt
          and "_k.CreateMutexW(None, False, \"VoiceAssistantMain_v1\")" not in stt,
          "main() 不再内联第二套命名互斥锁")
    check("if not args.allow_multiple and not acquire_single_instance():"
          not in stt,
          "参数解析后不再重复申请另一个单实例锁")
    guard_source = (
        APP / "voice_feature" / "instance_guard.py"
    ).read_text(encoding="utf-8")
    check("WaitForSingleObject(" in guard_source
          and "0x00000102" in guard_source,
          "PID 存活判断使用等待句柄状态识别退出进程")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
