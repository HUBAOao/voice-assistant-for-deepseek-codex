# -*- coding: utf-8 -*-
"""验收"发到哪个窗口"：跟着当前窗口发这个开关以前是死的（被 target 挡住了）。"""
from __future__ import annotations

import importlib.util
import sys
from types import SimpleNamespace
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def load():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    stt = load()
    bad = 0
    notes = []
    tracker = SimpleNamespace(hwnd=111, title="上一个用过的窗口")

    def check(cond, text):
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    # 桩：前台是别的对话窗口，ChatGPT 窗口也存在
    stt.foreground_hwnd = lambda: 222
    stt.foreground_title = lambda: "Claude"
    stt.is_our_window = lambda h: h == 333
    stt.find_window = lambda t: (444, "ChatGPT") if t else (0, "")

    print("① config 里 target=ChatGPT，但开了「跟着当前窗口发」")
    got = stt.pick_send_target({"follow_foreground": True, "target": "ChatGPT"},
                               "ChatGPT", tracker, log=notes.append)
    check(got == (222, "Claude"), f"发到当前窗口，不再死认 ChatGPT（结果 {got}）")

    print("② 关掉这个开关：还是发到 target 匹配的窗口")
    got = stt.pick_send_target({"follow_foreground": False}, "ChatGPT", tracker)
    check(got == (444, "ChatGPT"), f"按标题找 ChatGPT（结果 {got}）")

    print("③ 开了开关，但前台是我们自己的窗口（悬浮窗/设置面板）")
    stt.foreground_hwnd = lambda: 333
    got = stt.pick_send_target({"follow_foreground": True}, "ChatGPT", tracker,
                               log=notes.append)
    check(got == (444, "ChatGPT"), f"跳过自己，退回 target（结果 {got}）")

    print("④ 前台拿不到（全屏游戏/最小化）→ 退回上一个用过的窗口")
    stt.foreground_hwnd = lambda: 0
    stt.find_window = lambda t: (0, "")
    got = stt.pick_send_target({"follow_foreground": True}, "ChatGPT", tracker)
    check(got == (111, "上一个用过的窗口"), f"退回 tracker（结果 {got}）")

    print("⑤ 什么都没设：用 tracker")
    got = stt.pick_send_target({}, None, tracker)
    check(got == (111, "上一个用过的窗口"), f"结果 {got}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
