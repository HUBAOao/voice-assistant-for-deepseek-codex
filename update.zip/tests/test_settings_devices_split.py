# -*- coding: utf-8 -*-
"""Device trust settings leave the overlay shell with behavior intact."""
from __future__ import annotations

import ast
import sys
import types
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_devices_mixin import (  # noqa: E402
    OverlaySettingsDevicesMixin,
)


class Label:
    def __init__(self) -> None:
        self.text = ""

    def config(self, **kwargs) -> None:
        self.text = kwargs["text"]


class Probe(OverlaySettingsDevicesMixin):
    def __init__(self) -> None:
        self.tk = object()
        self.devices_label = Label()
        self._dev_asked = set()
        self.flash_calls = []
        self.refresh_calls = 0
        self.pending = []

    def ask_new_device(self, record) -> None:
        self.pending.append(record)

    def refresh_remote(self) -> None:
        self.refresh_calls += 1

    def flash(self, text, seconds=1.6) -> None:
        self.flash_calls.append((text, seconds))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls = []
    groups = [
        {
            "key": "allowed",
            "ids": ["device-a"],
            "pending": False,
            "names": ["手机 A"],
        },
        {
            "key": "pending",
            "ids": ["device-b"],
            "codes": ["123456"],
            "pending": True,
            "names": ["手机 B"],
        },
    ]
    phone = types.SimpleNamespace(
        device_groups=lambda: groups,
        device_name=lambda ua, ip: "测试手机",
        group_allow=lambda ids: calls.append(("allow", list(ids))) or 1,
        group_deny=lambda ids: calls.append(("deny", list(ids))) or 1,
        group_revoke=lambda ids: calls.append(("revoke", list(ids))) or 1,
        device_forget_all=lambda: calls.append(("forget-all", [])) or 2,
        rotate_token=lambda: calls.append(("rotate", [])),
        access_recent=lambda limit: [],
        access_clear=lambda: 0,
        ACCESS_FILE=Path("access.jsonl"),
    )
    previous = sys.modules.get("phone_link")
    sys.modules["phone_link"] = phone
    try:
        probe = Probe()
        probe.check_new_devices(force=True)
        probe.check_new_devices(force=True)
        check(len(probe.pending) == 1
              and probe.pending[0]["key"] == "pending",
              "只在首次发现待确认设备时弹一次")
        probe.refresh_devices_label()
        check(probe.devices_label.text == "1 台等你确认",
              "设备标签继续区分已允许和待确认")

        import tkinter.messagebox as messagebox
        old_ask = messagebox.askyesno
        messagebox.askyesno = lambda *_args, **_kwargs: True
        try:
            OverlaySettingsDevicesMixin.ask_new_device(
                probe,
                {
                    "ids": ["device-c"],
                    "codes": ["654321"],
                    "ua": "probe",
                    "ip": "127.0.0.1",
                },
            )
            check(("allow", ["device-c"]) in calls,
                  "确认新设备后仍按整组允许")
            check(not probe._dev_asked,
                  "允许后清空本轮待确认去重状态")
            probe.rotate_phone_token()
            check(("rotate", []) in calls
                  and ("forget-all", []) in calls,
                  "换令牌继续同时作废旧令牌并要求设备重新确认")
        finally:
            messagebox.askyesno = old_ask
    finally:
        if previous is None:
            sys.modules.pop("phone_link", None)
        else:
            sys.modules["phone_link"] = previous

    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    tree = ast.parse(overlay)
    overlay_class = next(
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "Overlay"
    )
    own_methods = {
        node.name
        for node in overlay_class.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    device_methods = {
        "check_new_devices",
        "ask_new_device",
        "refresh_devices_label",
        "forget_devices",
        "rotate_phone_token",
        "show_device_list",
        "show_access_log",
        "show_remote_qr",
    }
    check(not own_methods & device_methods,
          "设备准入、记录和二维码不再内联在 Overlay")
    check("OverlaySettingsDevicesMixin" in overlay,
          "历史设备方法通过独立 mixin 保留")
    check(Probe.show_remote_qr.__module__
          == "overlay_feature.settings_remote_qr_mixin",
          "外网二维码解析到独立只读模块")
    check(Probe.show_device_list.__module__
          == "overlay_feature.settings_device_list_mixin",
          "设备名单解析到独立只读模块")
    check(Probe._draw_device_groups.__module__
          == "overlay_feature.settings_device_groups_mixin",
          "设备名单元数据卡片解析到独立渲染模块")
    check(Probe.show_access_log.__module__
          == "overlay_feature.settings_access_log_mixin",
          "连接记录解析到独立只读模块")
    check(Probe.rotate_phone_token.__module__
          == "overlay_feature.settings_device_actions_mixin",
          "设备准入与令牌动作解析到独立动作模块")
    check(len((APP / "overlay_feature" /
               "settings_device_actions_mixin.py")
              .read_text(encoding="utf-8").splitlines()) < 180,
          "设备准入动作保持小模块边界")
    check(len((APP / "overlay_feature" /
               "settings_device_views_mixin.py")
              .read_text(encoding="utf-8").splitlines()) < 30,
          "历史设备查看组合保持薄兼容层")
    for filename, limit in (
        ("settings_device_list_mixin.py", 210),
        ("settings_device_groups_mixin.py", 180),
        ("settings_access_log_mixin.py", 140),
        ("settings_remote_qr_mixin.py", 180),
    ):
        check(
            len((APP / "overlay_feature" / filename)
                .read_text(encoding="utf-8").splitlines()) < limit,
            f"{filename} 保持独立小模块边界",
        )
    check(len(overlay.splitlines()) < 1800,
          f"overlay.py 行数降至 {len(overlay.splitlines())}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
