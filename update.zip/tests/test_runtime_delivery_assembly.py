# -*- coding: utf-8 -*-
"""Post-send tracking keeps the same order without living inside ``main()``."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_delivery_assembly import (  # noqa: E402
    RuntimeDeliveryAssembly,
    RuntimeDeliveryDependencies,
)


class Reader:
    def __init__(self) -> None:
        self.calls = []

    def watch(self, *args, **kwargs) -> None:
        self.calls.append((args, kwargs))


class Status:
    pass


class Thread:
    instances = []

    def __init__(self, *, target, daemon) -> None:
        self.target = target
        self.daemon = daemon
        self.started = False
        self.__class__.instances.append(self)

    def start(self) -> None:
        self.started = True
        self.target()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as raw:
        tmp = Path(raw)
        reader = Reader()
        emitted = []
        verified = []
        last_sent = {}
        fatigue = {"speeds": [1.0, 2.0]}
        busy = {}
        deps = RuntimeDeliveryDependencies(
            config={"read_reply": True},
            last_sent=last_sent,
            fatigue=fatigue,
            busy=busy,
            last_unsent={"text": "", "at": 0.0},
            said_file=tmp / "said.md",
            thread_name=lambda: "真实会话",
            get_reply_reader=lambda: reader,
            chars_per_second=lambda _audio, _sr, text: float(len(text)),
            privacy_clean=lambda text: text.strip(),
            verify_delivery=lambda *args, **kwargs: verified.append(
                (args, kwargs)
            ),
            datetime_factory=lambda: __import__("datetime").datetime(
                2026, 10, 24, 3, 4, 5
            ),
            clock=lambda: 123.5,
            syslog=lambda *_args: None,
            status=Status(),
            speak=lambda *_args, **_kwargs: None,
            emit=lambda text, **_kwargs: emitted.append(text),
            thread_factory=Thread,
        )
        runtime = RuntimeDeliveryAssembly(deps)
        watched = runtime.after_sent(
            text="  发给鳍舱的原文  ",
            hwnd=42,
            title="窗口标题",
            audio=object(),
            sr=16000,
            from_phone=True,
            mood="happy",
        )

        check(watched is True, "可读回答时报告已开始监视")
        check(last_sent == {"text": "  发给鳍舱的原文  ", "at": 123.5},
              "发送后仍先更新上下文引用")
        check(reader.calls[0][0] == (42, "  发给鳍舱的原文  "),
              "回答监视保留原文和目标窗口")
        check(reader.calls[0][1]["seconds"] == 900
              and reader.calls[0][1]["max_chars"] == 20000
              and reader.calls[0][1]["title"] == "真实会话"
              and reader.calls[0][1]["speak"] is False,
              "回答监视保留长回答上限、真实会话名和手机静音")
        check(any("开始念回答" in text for text in emitted),
              "保留原来的开始念回答提示")
        check(fatigue["speeds"][:2] == [1.0, 2.0]
              and fatigue["speeds"][-1] == float(len("  发给鳍舱的原文  ")),
              "有语气结果时才记录本次语速")
        check((tmp / "said.md").read_text(encoding="utf-8")
              == "- 2026-10-24 03:04:05 发给鳍舱的原文\n",
              "日记只记清理后的实际发送原文")
        check(busy == {"on": True, "at": 123.5},
              "发送完成后仍进入忙碌状态")
        check(verified and verified[0][0] == ("  发给鳍舱的原文  ", 42)
              and verified[0][1]["silent"] is True,
              "后台发送校验仍按手机静音方式执行")
        check(Thread.instances[-1].daemon
              and Thread.instances[-1].started,
              "发送校验线程仍为已启动的守护线程")

        reader.calls.clear()
        fatigue["speeds"].clear()
        deps.config["read_reply"] = False
        watched = RuntimeDeliveryAssembly(deps).after_sent(
            text="第二句",
            hwnd=0,
            title="",
            audio=None,
            sr=16000,
            from_phone=False,
            mood="",
        )
        check(watched is False and not reader.calls,
              "关闭自动念回答后不建立监视")
        check(fatigue["speeds"] == [],
              "没有语气结果时不写猜出来的语速")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check("def after_delivery_sent(" not in stt,
          "发送后跟踪实现已经离开 main()")
    check("delivery_tracking.after_sent(" in stt,
          "主流程消费独立发送后装配")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
