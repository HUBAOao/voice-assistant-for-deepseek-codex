# -*- coding: utf-8 -*-
"""验收「取消」的严格判定：只有整句就是取消词才算，句子里夹着的、同音错字拼出来的不算。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import stt  # noqa: E402

WORDS = ["取消"]

# (识别出来的原句, 该不该当成「取消」)
CASES = [
    # —— 就是取消：整句等于取消词 ——
    ("取消", True),
    ("取消。", True),
    ("取消！", True),
    ("取消吧", True),
    ("取消掉了", True),
    ("取 消", True),
    ("取消啊", True),
    # —— 真同音（Whisper 常写错）：整句一样长、拼音全对 ——
    ("取笑", True),
    ("取销", True),
    ("去小", True),
    # —— 这些都是正经话，绝对不能当成取消 ——
    ("取笑他", False),
    ("别取笑他了", False),
    ("取消订单", False),
    ("取消明天的提醒", False),
    ("帮我取消明天的闹钟", False),
    ("去小卖部买瓶水", False),
    ("这个取消了吗", False),
    ("今天天气不错", False),
    ("我买了一条肥鱼", False),
    ("取消取消", False),
    ("", False),
]

# 用户自定义的取消词也要一样严格
CUSTOM = [
    ("算了", "算了", True),
    ("算了。", "算了", True),
    ("算了吧", "算了", True),
    ("我觉得算了", "算了", False),
    ("别算了", "算了", False),
    ("停下", "停下", True),
    ("停下脚步", "停下", False),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 默认取消词「取消」：整句就是它才算")
    for text, want in CASES:
        hit = stt.cancel_hit(text, WORDS)
        check(hit == want, f"取消={str(hit):5s} ← 「{text}」")

    print("\n② 自定义取消词（算了 / 停下）一样严格")
    for text, word, want in CUSTOM:
        hit = stt.cancel_hit(text, [word])
        check(hit == want, f"取消词={word} 取消={str(hit):5s} ← 「{text}」")

    print("\n③ 一句正经话不能被偷偷改字（canonize 不再碰「取消」）")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check('"取消")' not in src.split("_CANON = (")[1].split(")")[0],
          "_CANON 里没有「取消」")
    check(stt.canonize("别取笑他了") == "别取笑他了", "「别取笑他了」原样保留")
    check(stt.canonize("取消") == "取消", "「取消」照样还是「取消」")
    check(stt.canonize("砖住二十五分钟").startswith("专注"), "别的命令词该修的还修")

    print("\n④ 唤醒说过的话：整句是取消词才拦，长句子照发")
    wake = ["大肥鱼"]
    for text, want_body, want_cancel in [
        ("大肥鱼 取消", "", True),
        ("大肥鱼 取消吧", "", True),
        ("大肥鱼 取笑", "", True),
        ("大肥鱼 取消明天的闹钟", "取消明天的闹钟", False),
        ("大肥鱼 别取笑他了", "别取笑他了", False),
    ]:
        body, woke = stt.extract_word(text, wake, fuzzy=True, leading=True)
        hit = stt.cancel_hit(body, WORDS)
        check(hit == want_cancel and (want_cancel or body == want_body),
              f"唤醒={woke} 取消={hit} 剩下发出去的是「{body}」 ← 「{text}」")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
