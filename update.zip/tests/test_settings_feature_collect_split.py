# -*- coding: utf-8 -*-
"""Settings collection keeps basic presentation and feature state separable."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import settings_collect_mixin as collect_module  # noqa: E402
from overlay_feature.settings_collect_mixin import (  # noqa: E402
    OverlaySettingsCollectMixin,
)
from overlay_feature.settings_feature_collect_mixin import (  # noqa: E402
    OverlaySettingsFeatureCollectMixin,
)


class Value:
    def __init__(self, value=0) -> None:
        self.value = value

    def get(self):
        return self.value

    def itemcget(self, _item, _option):
        return self.value


class SwitchMap(dict):
    def __getitem__(self, key):
        return super().__getitem__(key) if key in self else Value(False)


class FeatureOwner(OverlaySettingsFeatureCollectMixin):
    pass


def feature_owner():
    owner = FeatureOwner()
    for name in (
        "sw_caption", "sw_mood", "sw_sleepy", "sw_spectrum", "sw_karaoke",
        "sw_diary", "sw_big", "sw_shot", "sw_share", "sw_phone", "sw_chime",
        "sw_sit", "sw_meeting", "sw_hotkey", "sw_voiceprint", "sw_pet",
        "sw_follow", "sw_readreply", "sw_rec", "sw_confirm", "sw_tray",
        "sw_autotune", "sw_restart", "sw_notheard", "sw_gate",
        "sw_reminder", "sw_reminder_paste", "sw_wheel", "sw_snap",
    ):
        setattr(owner, name, Value(True))
    owner.sl_followup = Value(7)
    owner.entry_city = Value(" 成都 ")
    owner.send_mode_value = "paste_enter"
    owner.model_value = "small"
    owner.lang_value = "zh"
    owner.cfg = {"wake_level": "标准"}
    owner.custom_levels = lambda: {"自定义": True}
    owner.shortcuts = [{"phrase": "工作", "text": "开始"}]
    owner.schedule_panel = SimpleNamespace(
        entries=[{"time": "08:30", "text": "晨会"}],
        modules=["工作日"],
    )
    owner.perf_value = "eco"
    owner.sl_anim = Value(30)
    owner.fx_switches = {"fx_glow": Value(True)}
    owner._auto_low = True
    owner._fx_before_low = {"fx_glow": False}
    return owner


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    owner = feature_owner()
    state = owner.collect_feature_settings({})
    check(state["followup_seconds"] == 7
          and state["weather_city"] == "成都"
          and state["schedule_modules"] == ["工作日"],
          "功能、提醒、日程和性能字段由独立收集器写入")
    check(state["wake_level"] == "标准"
          and state["wake_levels"] == {"自定义": True},
          "唤醒档位和自定义层级保持原格式")
    check(state["fx_glow"] is False,
          "低性能临时状态不会把用户特效永久写关")

    old_config, old_loader = collect_module.CONFIG, collect_module.load_config
    collect_module.CONFIG = Path("settings-test.json")
    collect_module.load_config = lambda _path: {"existing": "kept"}
    try:
        collector = OverlaySettingsCollectMixin()
        collector.entry_name = Value("鳍舱")
        collector.entry_wake = Value("大肥鱼")
        collector.entry_greeting = Value("早上好")
        collector.sw_greeting = Value(True)
        collector.entry_user = Value("鱼片")
        collector.name_freq_value = 2
        collector.entry_ack = Value("收到")
        collector.sw_ack = Value(True)
        collector.entry_self = Value("大肥鱼")
        collector.sw_self = Value(True)
        collector.self_freq_value = 1
        collector.sl_volume = Value(80)
        collector.sl_rate = Value(0)
        collector.voice_index = 0
        collector.sl_width = Value(420)
        collector.sl_height = Value(140)
        for name in (
            "sw_color", "sw_accent", "sw_button", "sw_text", "sw_talk",
        ):
            setattr(collector, name, (Value("#123456"), "item"))
        collector.bg_path = ""
        collector.sl_alpha = Value(90)
        collector.sl_dim = Value(20)
        collector.wave_style_value = "siri"
        for name in ("sp_name", "sp_status"):
            setattr(collector, name, Value({"x": 10, "y": 20, "s": 12}))
        collector.sp_switch = Value({"x": 30, "y": 40})
        collector.sp_wave = Value({"y": 50, "h": 18})
        collector.sw_show = SwitchMap({
            "name": Value(True), "status": Value(True),
            "line": Value(True), "switch": Value(True),
        })
        collector.collect_feature_settings = lambda data: {
            **data, "features": "delegated",
        }
        result = collector.collect()
        check(result["existing"] == "kept"
              and result["name"] == "鳍舱"
              and result["overlay_width"] == 420,
              "基础呈现字段仍从原控件收集")
        check(result["features"] == "delegated",
              "汇总入口继续委托功能字段收集器")
    finally:
        collect_module.CONFIG = old_config
        collect_module.load_config = old_loader

    basic = (
        APP / "overlay_feature" / "settings_collect_mixin.py"
    ).read_text(encoding="utf-8")
    features = (
        APP / "overlay_feature" / "settings_feature_collect_mixin.py"
    ).read_text(encoding="utf-8")
    check("def collect(self)" in basic
          and "settings_feature_collect_mixin" in basic,
          "旧 collect 入口和模块名保持")
    check("def collect_feature_settings(" in features
          and "schedule_modules" in features,
          "功能大块位于独立可测试模块")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
