# -*- coding: utf-8 -*-
"""Storage-volume diagnostics stay read-only and expose no paths."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "DeviceDiagnostics.java"
)
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "management.js"
)
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = SOURCE.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    check("StorageManager" in source and "StorageVolume" in source,
          "原生诊断使用系统 StorageManager/StorageVolume")
    check("getStorageVolumes()" in source,
          "实际枚举系统存储卷")
    for field in (
        "description",
        "state",
        "removable",
        "primary",
        "total_mb",
        "free_mb",
    ):
        check(f'"{field}"' in source, f"回传只读字段 {field}")
    check('"storage_volume_count"' in source
          and '"storage_volume_ready_count"' in source,
          "回传存储卷总数与已挂载数")
    check("MANAGE_EXTERNAL_STORAGE" not in manifest,
          "没有申请全盘文件访问权限")
    block = source[
        source.index("private static JSONArray storageVolumes("):
        source.index("\n    /**", source.index(
            "private static JSONArray storageVolumes("))
    ]
    check("listFiles(" not in block
          and "open(" not in block
          and "getAbsolutePath" not in block
          and 'item.put("path"' not in block,
          "不遍历文件、不打开文件流、不输出路径")
    check("storage_volume_ready_count" in media
          and "storage_volume_count" in media,
          "真机状态页显示已挂载/总存储卷")

    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for symbol in (
            "getStorageVolumes",
            "storage_volume_ready_count",
            "total_mb",
            "free_mb",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
