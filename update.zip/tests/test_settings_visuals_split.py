# -*- coding: utf-8 -*-
"""The appearance page keeps behavior while its code leaves the content module."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_content_mixin import (  # noqa: E402
    OverlaySettingsContentMixin,
)
from overlay_feature.settings_mixin import OverlaySettingsMixin  # noqa: E402
from overlay_feature.settings_visuals_mixin import (  # noqa: E402
    OverlaySettingsVisualsMixin,
)
from overlay_feature.settings_layout_mixin import (  # noqa: E402
    OverlaySettingsLayoutMixin,
)
from overlay_feature.settings_visual_geometry_mixin import (  # noqa: E402
    OverlaySettingsVisualGeometryMixin,
)
from overlay_feature.settings_visual_palette_mixin import (  # noqa: E402
    OverlaySettingsVisualPaletteMixin,
)


class Switch:
    def __init__(self, value: bool) -> None:
        self.value = value

    def get(self) -> bool:
        return self.value


class Probe(
    OverlaySettingsContentMixin,
    OverlaySettingsVisualsMixin,
    OverlaySettingsMixin,
):
    def __init__(self) -> None:
        self.fx = {"fx_trail": True, "fx_sparkles": True}
        self.fx_switches = {
            "fx_trail": Switch(False),
            "fx_sparkles": Switch(False),
        }
        self._sparks = [1, 2]
        self._trail_img = "old"
        self._auto_low = True
        self._fx_before_low = {
            "fx_trail": True,
            "fx_sparkles": True,
        }
        self.changes = 0

    def on_change(self) -> None:
        self.changes += 1


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    probe = Probe()
    probe.on_fx_change("fx_trail")
    check(probe.fx["fx_trail"] is False and probe._trail_img is None,
          "关闭视觉暂留仍立即清掉旧拖影")
    probe.on_fx_change("fx_sparkles")
    check(probe.fx["fx_sparkles"] is False and probe._sparks == [],
          "关闭星尘仍立即清掉粒子")
    check(not probe._auto_low and probe._auto_low_off,
          "用户手动改特效仍会退出自动低配状态")
    check(probe.changes == 2, "两个特效动作仍各自触发即时预览")

    content = (APP / "overlay_feature" / "settings_content_mixin.py").read_text(
        encoding="utf-8"
    )
    visuals = (APP / "overlay_feature" / "settings_visuals_mixin.py").read_text(
        encoding="utf-8"
    )
    palette = (
        APP / "overlay_feature" / "settings_visual_palette_mixin.py"
    ).read_text(encoding="utf-8")
    geometry = (
        APP / "overlay_feature" / "settings_visual_geometry_mixin.py"
    ).read_text(encoding="utf-8")
    layout = (APP / "overlay_feature" / "settings_layout_mixin.py").read_text(
        encoding="utf-8"
    )
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("def build_look(" not in content and "def on_fx_change(" not in content,
          "内容与通用控件模块不再承载外观页业务")
    check("def build_look(" in visuals and "def on_fx_change(" in visuals,
          "兼容外观模块保留页面入口和特效动作")
    for marker in ("def build_visual_palette(", "self.style_chips", "self.bg_label"):
        check(marker in palette, f"颜色与背景模块包含 {marker}")
    for marker in ("def build_visual_geometry(", "self.sl_width", "self._slider("):
        check(marker in geometry, f"尺寸与透明度模块包含 {marker}")
    for marker in ("def build_effects_and_layout(", "self.sp_name", "fx_burst"):
        check(marker in layout, f"布局模块包含 {marker}")
    check("self.build_visual_palette(parent)" in visuals
          and "self.build_visual_geometry(parent)" in visuals,
          "外观页仍按原顺序装配颜色、尺寸与元素布局")
    check(issubclass(OverlaySettingsVisualsMixin, OverlaySettingsLayoutMixin),
          "历史外观类继续继承特效与布局业务")
    check(issubclass(OverlaySettingsVisualsMixin,
                     OverlaySettingsVisualPaletteMixin)
          and issubclass(OverlaySettingsVisualsMixin,
                         OverlaySettingsVisualGeometryMixin),
          "历史外观类继续组合拆分后的全部业务")
    check("OverlaySettingsVisualsMixin" in overlay
          and "OverlaySettingsContentMixin" in overlay,
          "Overlay 同时保留内容、通用控件和外观兼容入口")
    check(OverlaySettingsVisualsMixin.build_look.__module__
          == "overlay_feature.settings_visuals_mixin",
          "build_look 由独立外观模块提供")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
