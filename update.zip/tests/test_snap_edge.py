# -*- coding: utf-8 -*-
"""验收贴边吸附：拖到边上要吸住 → 缩成一条小细条 → 鼠标移上去自己放大回来 →
只有吸在边上的时候才缩；放开屏幕中间不该缩。顺带截两张图看长相。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "snap-test"
S.mkdir(parents=True, exist_ok=True)
SHOT_SIMPLE = ROOT / "outputs" / "贴边小条.png"
SHOT_HOVER = ROOT / "outputs" / "贴边放大.png"
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMI(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def grab(hwnd: int, out: Path) -> tuple:
    rect = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMI()
    hdr.biSize = ctypes.sizeof(BMI)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount = 1, 32
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB").save(out)
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return w, h


def pump(o, seconds: float) -> None:
    end = time.time() + seconds
    while time.time() < end:
        o.root.update()
        time.sleep(0.004)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    (S / "config.json").write_text(json.dumps(
        {"name": "贴边测试", "overlay_bg_image": "", "overlay_alpha": 1.0,
         "snap_edges": True, "auto_tune": False},
        ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 200, "y": 200}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "hearing", "level": 0.7, "text": "贴边吸附",
         "ts": time.time(), "pid": os.getpid(), "bands": [0.6] * 12}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")
    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    notes = []
    overlay.note = lambda t: notes.append(t)

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.watch_hover = lambda: None      # 测试里用不到真鼠标：hovered 我自己设
    pump(o, 0.6)
    vx, vy, vw, vh = overlay.virtual_screen()
    check(o.snap_edge == "", "一开始没吸在任何边上")
    check(not o.simple_on(), "没贴边时不简化（还是完整的浮窗）")

    print("① 拖到右边：应该吸住")
    o.base_x, o.base_y = vx + vw - int(o.cur_w) - 6, vy + 300
    o.root.geometry(f"{int(o.cur_w)}x{int(o.cur_h)}+{o.base_x}+{o.base_y}")
    pump(o, 0.1)
    o.try_snap()
    check(o.snap_edge == "right", f"吸到了右边（snap_edge={o.snap_edge!r}）")
    x0 = o.root.winfo_x()
    check(abs((x0 + int(o.cur_w)) - (vx + vw)) <= 40,
          f"贴着屏幕右边（右边缘={x0 + int(o.cur_w)}，屏幕右={vx + vw}）")

    print("② 鼠标不在上面：应该缩成一条小细条")
    o.hovered = False
    pump(o, 2.0)
    w_s, h_s = o.simple_size()
    check(int(o.cur_w) == w_s and int(o.cur_h) == h_s,
          f"缩成 {int(o.cur_w)}x{int(o.cur_h)}（竖条）")
    check(o.simple_on(), "当前处于「简化版」状态")
    grab(o.root.winfo_id(), SHOT_SIMPLE)

    print("③ 鼠标移上去：应该自己放大回完整的浮窗")
    o.hovered = True
    pump(o, 2.0)
    check(int(o.cur_w) == o.compact_w and int(o.cur_h) == o.header_h,
          f"放大回 {int(o.cur_w)}x{int(o.cur_h)}")
    check(not o.simple_on(), "鼠标在上面时不简化")
    grab(o.root.winfo_id(), SHOT_HOVER)

    print("④ 鼠标移开：又缩回去")
    o.hovered = False
    pump(o, 2.0)
    check(int(o.cur_w) == w_s, "又缩回了小细条")

    print("⑤ 展开设置面板：窗口要留在屏幕里")
    o.set_expanded(True)
    pump(o, 2.0)
    x1 = o.root.winfo_x()
    check(x1 >= vx - 40 and x1 + int(o.cur_w) <= vx + vw + 40,
          f"展开后面板整个在屏幕内（x={x1} 宽={int(o.cur_w)}）")
    check(not o.simple_on(), "展开设置时不简化")
    o.set_expanded(False)
    pump(o, 1.6)

    print("⑥ 拖回屏幕中间：不该再简化")
    o._drag = (0, 0)                  # 假装正在拖：这时候动画不许把它拉回边缘
    o.base_x, o.base_y = vx + 300, vy + 260
    o.root.geometry(f"{int(o.compact_w)}x{int(o.header_h)}+{o.base_x}+{o.base_y}")
    o.cur_w, o.cur_h = float(o.compact_w), float(o.header_h)
    pump(o, 0.3)
    o._drag = None
    o.try_snap()
    o.hovered = False
    pump(o, 1.6)
    check(o.snap_edge == "", "离开边缘后不再吸附")
    check(int(o.cur_w) == o.compact_w and int(o.cur_h) == o.header_h,
          f"还是完整浮窗 {int(o.cur_w)}x{int(o.cur_h)}，没被缩成小条")

    print("⑦ 关掉这个功能：贴边也不简化")
    o2 = o
    o2.snap_on = False
    o2.snap_edge = "right"
    o2.hovered = False
    pump(o2, 1.2)
    check(not o2.simple_on(), "开关关掉后，贴边也不缩")

    o.root.destroy()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
