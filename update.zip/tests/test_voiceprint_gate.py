# -*- coding: utf-8 -*-
"""验收「只认我的声音」那道背景音闸：
  别再把用户喊完唤醒词后说的短句当背景音丢掉（真机出过，连丢 5 句）。"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import stt  # noqa: E402

# (这句话, last_score, wake_score, 开关, 该不该当背景音丢掉)
CASES = [
    # —— 真机日志里的三次：唤醒声纹 0.87/0.76/0.80，却因为 last_score 被丢了 ——
    ("用方案二", 0.03, 0.87, True, False),
    ("用方案2", -0.03, 0.76, True, False),
    ("你在干啥", -0.06, 0.75, True, False),
    ("马上办", -0.00, 0.79, True, False),
    # —— 真的像背景音：两把尺子都不像 ——
    ("用方案二", 0.03, 0.20, True, True),
    ("嗯嗯嗯", 0.05, 0.31, True, True),
    # —— 没做过唤醒声纹（免唤醒的对话模式）→ 还是按老规矩拦短句 ——
    ("用方案二", 0.03, None, True, True),
    # —— 长句子不管像不像都不拦（背景音被识别成长句的概率低，误伤更贵）——
    ("我明天下午三点要去开会", 0.03, None, True, False),
    # —— 没注册过声纹 / 开关关着 → 一律放行 ——
    ("用方案二", None, None, True, False),
    ("用方案二", 0.03, None, False, False),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 背景音闸的判定")
    for text, last, wake, gate, want in CASES:
        got = stt.background_noise(text, last, wake, gate)
        check(got == want,
              f"丢掉={str(got):5s} ← 「{text}」 last={last} wake={wake} 开关={gate}")

    print("\n② 主程序真的把「唤醒声纹」接进这道闸了")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check('voiceprint["wake_score"] = score' in src, "唤醒声纹算完会记下来")
    check('voiceprint["wake_score"] = None' in src, "每句开始前先清掉上句的（不会用串）")
    check("background_noise(text_to_send" in src, "发出去之前用的是这个判定")
    check("and not (_wake_sc is not None and _wake_sc >= 0.45)" not in src,
          "老的内联写法已经收进函数里了")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
