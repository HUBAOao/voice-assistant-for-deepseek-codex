# -*- coding: utf-8 -*-
"""逐个抓图验证声音条特效，并且检查"设置收起"有没有动画。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
OUT = ROOT / "work"
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

SCRATCH = OUT / "fx-scratch"
SCRATCH.mkdir(parents=True, exist_ok=True)

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BMIH(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find(title: str) -> int:
    hit = {"h": 0}
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _l):
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(h, buf, 256)
        if buf.value == title:
            hit["h"] = h
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return hit["h"]


def grab(hwnd: int) -> Image.Image:
    rect = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BMIH()
    hdr.biSize = ctypes.sizeof(BMIH)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount, hdr.biCompression = 1, 32, 0
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return img


EFFECTS = ("fx_trail", "fx_glow", "fx_sparkles", "fx_reflection", "fx_sweep")


def main() -> int:
    (SCRATCH / "config.json").write_text(json.dumps({
        "name": "特效测试", "overlay_width": 344, "overlay_height": 112,
        "overlay_accent": "#3ddc84", "overlay_talk_color": "#4aa3ff",
        "overlay_bg_image": "", "overlay_alpha": 1.0, "overlay_color": "#101014",
        "anim_fps": 60, "perf_mode": "quality", "overlay_wave_style": "siri",
    }, ensure_ascii=False), encoding="utf-8")
    (SCRATCH / "pos.json").write_text('{"x": 60, "y": 60}', encoding="utf-8")
    pid = os.getpid()          # 不能写 0：悬浮窗会以为主程序死了然后自己退出
    status = {"state": "hearing", "level": 0.72, "text": "", "hint": "",
              "ts": time.time(), "pid": pid}
    (SCRATCH / "status.json").write_text(json.dumps(status), encoding="utf-8")
    (SCRATCH / "speak.json").write_text(json.dumps({"active": True, "level": 0.72,
                                                    "text": "", "ts": time.time()}),
                                        encoding="utf-8")

    overlay.CONFIG = SCRATCH / "config.json"
    overlay.POS = SCRATCH / "pos.json"
    overlay.STATUS = SCRATCH / "status.json"
    overlay.SPEAK_STATUS = SCRATCH / "speak.json"
    overlay.EXIT_LOG = SCRATCH / "exit.log"
    overlay.note = lambda text: None

    o = overlay.Overlay()
    o.alpha_override = 1.0

    def pump(seconds: float) -> None:
        end = time.time() + seconds
        while time.time() < end:
            (SCRATCH / "status.json").write_text(
                json.dumps({"state": "hearing", "level": 0.72, "ts": time.time(),
                            "pid": pid}), encoding="utf-8")
            (SCRATCH / "speak.json").write_text(
                json.dumps({"active": True, "level": 0.72, "ts": time.time()}),
                encoding="utf-8")
            o.root.update()
            time.sleep(0.004)

    def shot(name: str) -> Image.Image | None:
        """重新找窗口再抓图（窗口句柄偶尔会变），抓不到空的才罢休。"""
        for _ in range(6):
            h = find("特效测试")
            if h:
                img = grab(h)
                if img.size[0] > 10 and img.size[1] > 10:
                    img.save(OUT / name)
                    return img
            time.sleep(0.1)
        print("抓不到窗口:", name)
        return None

    hwnd = 0
    for _ in range(60):
        o.root.update()
        hwnd = find("特效测试")
        if hwnd:
            break
        time.sleep(0.05)
    if not hwnd:
        print("没找到特效测试窗口")
        return 1

    # 1) 每个特效单独开一次，抓图对比
    o.fx = {k: False for k in EFFECTS}
    pump(1.2)
    shot("fx-none.png")
    print("已保存 fx-none.png（全关）")
    for key in EFFECTS:
        o.fx = {k: (k == key) for k in EFFECTS}
        o._trail_img = None
        o._sparks.clear()
        pump(1.4)
        shot(f"{key.replace('fx_', 'fx-')}.png")
        print(f"已保存 {key.replace('fx_', 'fx-')}.png（只开 {key}）")

    # 2) 全开
    o.fx = {k: True for k in EFFECTS}
    pump(1.4)
    shot("fx-all.png")
    print("已保存 fx-all.png（全开）")

    # 3) 收起动画：展开后收起，逐帧抓图
    o.fx = {k: k in ("fx_trail", "fx_glow") for k in EFFECTS}
    o.set_expanded(True)
    pump(1.0)
    print("\n展开后窗口尺寸 =", o.root.winfo_width(), "x", o.root.winfo_height())
    shot("collapse-0.png")

    o.set_expanded(False)
    sizes = []
    for i in range(12):
        o.root.update()
        sizes.append((o.root.winfo_width(), o.root.winfo_height()))
        h = find("特效测试")
        if h:
            grab(h).save(OUT / f"collapse-{i + 1}.png")
        time.sleep(0.03)
    print("收起过程中每帧尺寸：", sizes)
    # 收起后面板不再被拆掉：它留在窗口外面（窗口只剩 112 高），被自然裁掉。
    # 这样再展开就不用重新 map 七百个控件，动画才不会卡成"啪一下出现"。
    if o.panel:
        panel_y = o.panel.winfo_y()
        win_h = o.root.winfo_height()
        print(f"收起后：窗口高 {win_h}，面板起点 y={panel_y} "
              f"（面板在窗口外面 = 看不见 = {'是' if panel_y >= win_h else '否'}）")
    else:
        print("收起后：没有面板")

    # 4) 再展开一次，切到「外观」页，看看特效开关排得对不对
    o.set_expanded(True)
    pump(0.8)
    o.show_tab("外观")
    pump(0.8)
    shot("look-tab.png")
    print("已保存 look-tab.png（外观页，窗口 %d 高）" % o.root.winfo_height())
    o.root.destroy()
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
