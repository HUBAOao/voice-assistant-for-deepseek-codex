# -*- coding: utf-8 -*-
"""第二批功能的解析测试：重复、打开、纠错落地、成就、日记。"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")

import stt  # noqa: E402


def line(tag: str, got, want=None) -> int:
    ok = True if want is None else (got == want)
    print(f"  {'✓' if ok else '✗'} {tag:26s} → {got!r}")
    return 0 if ok else 1


def main() -> int:
    bad = 0
    print("=== 上下文指代 ===")
    for t, want in [("跟刚才一样", True), ("再来一次", True), ("重复一遍", True),
                    ("同上", True), ("今天天气不错", False)]:
        bad += line(t, stt.parse_repeat(t), want)

    print("\n=== 打开程序/文件 ===")
    for t, want in [("打开微信", "微信"), ("启动记事本", "记事本"),
                    ("帮我打开上周的报告", "上周的报告"), ("今天天气", None)]:
        bad += line(t, stt.parse_open(t), want)
    print("  开始菜单快捷方式数量：", len(stt._start_menu_lnks()))
    print("  桌面/文档文件数量：", len(stt._doc_files()))
    for t in ("打开计算器", "打开记事本", "打开微信"):
        target = stt.parse_open(t) or ""
        key = "".join(ch for ch in target if ch not in "的了个吧呢啊 ")
        best, score = stt._pick_best(key.lower(), stt._start_menu_lnks())
        print(f"  {t!r:12s} 最佳匹配={Path(best).stem if best else None!r} 分数={score}")

    print("\n=== 媒体键 ===")
    for t, want in [("下一首", 0xB0), ("暂停音乐", 0xB3), ("静音", 0xAD),
                    ("声音大点", 0xAF), ("暂停", None)]:
        got = stt.parse_media(t)
        bad += line(t, got[1] if got else None, want)

    print("\n=== 闭嘴词 ===")
    for t, want in [("停", True), ("别念了", True), ("你安静点", True),
                    ("停车位在哪", False), ("好的", False)]:
        bad += line(t, stt.is_stop_word(t), want)

    print("\n=== 纠错落地 ===")
    bad += line("apply_corrections",
                stt.apply_corrections("我叫胡包，住在胡包街", {"胡包": "胡宝"}),
                "我叫胡宝，住在胡宝街")

    print("\n=== 成就 ===")
    before = stt.read_achv()
    earned = stt.bump_achv("note")
    print("  便签计数 →", stt.read_achv()["counts"].get("note"), "本次解锁：", earned)
    print("  已解锁：", list(stt.read_achv()["unlocked"]))

    print("\n=== 日记 ===")
    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    print("  今天记录条数：", len(stt.diary_lines(today)))
    print("  摘要：", stt.diary_summary(today)[:80])
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
