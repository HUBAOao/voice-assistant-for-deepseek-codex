# -*- coding: utf-8 -*-
"""Periodic runtime keeps stage order, pause state, and overlay recovery."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_periodic_assembly import (  # noqa: E402
    OverlayLivenessDependencies,
    RuntimeOverlayLiveness,
    RuntimePeriodicAssembly,
    RuntimePeriodicDependencies,
)


class Process:
    def __init__(self, alive: bool) -> None:
        self.alive = alive

    def poll(self):
        return None if self.alive else 0


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    calls: list[str] = []
    logs: list[tuple[str, str]] = []
    emitted: list[str] = []
    now = [100.0]
    overlays = [Process(True), Process(True)]

    liveness = RuntimeOverlayLiveness(
        OverlayLivenessDependencies(
            config={"overlay_enabled": True},
            no_overlay=False,
            feed=False,
            test_paste=False,
            overlay_process=Process(False),
            ticker={},
            start_overlay=lambda: overlays.pop(0),
            syslog=lambda tag, text: logs.append((tag, text)),
            emit=emitted.append,
            clock=lambda: now[0],
        )
    )

    def broken() -> None:
        calls.append("broken")
        raise RuntimeError("temporary")

    runtime = RuntimePeriodicAssembly(
        RuntimePeriodicDependencies(
            remote_poll=lambda: calls.append("remote"),
            reload_config=lambda: calls.append("config"),
            hot_reload_page=lambda: calls.append("page"),
            focus_tick=lambda: calls.append("focus"),
            night_diary=lambda: calls.append("diary"),
            check_hotkey=lambda: calls.append("hotkey"),
            reminders=broken,
            overlay_liveness=liveness.keep_alive,
            paused=lambda: True,
            syslog=lambda tag, text: logs.append((tag, text)),
            emit=emitted.append,
        )
    )

    paused = runtime.tick()
    check(paused is True, "周期入口返回当前暂停状态")
    check(calls == [
        "remote", "config", "page", "focus", "diary", "hotkey", "broken"
    ], "有效任务按原顺序执行，后置悬浮窗检查仍会运行")
    check(overlays and liveness.process.alive,
          "已退出的悬浮窗在下一次检查时重新拉起")
    check(any("周期任务失败" in text for _tag, text in logs)
          and any("周期任务失败" in text for text in emitted),
          "单个任务失败写原系统日志和提示，不跳过其他任务")

    restarted = liveness.process
    now[0] = 120
    liveness.keep_alive()
    check(liveness.process is restarted,
          "三十秒内的重复检查不会反复拉起悬浮窗")

    disabled = RuntimeOverlayLiveness(
        OverlayLivenessDependencies(
            config={"overlay_enabled": False},
            no_overlay=False,
            feed=False,
            test_paste=False,
            overlay_process=None,
            ticker={},
            start_overlay=lambda: (_ for _ in ()).throw(
                AssertionError("disabled overlay must not start")
            ),
            syslog=lambda _tag, _text: None,
            emit=lambda _text: None,
            clock=lambda: 200,
        )
    )
    disabled.keep_alive()
    check(disabled.process is None, "关闭悬浮窗后不会因存活检查重新启动")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    assembly = (
        APP / "voice_feature" / "runtime_periodic_assembly.py"
    ).read_text(encoding="utf-8")
    service = (
        APP / "voice_feature" / "runtime_service_assembly.py"
    ).read_text(encoding="utf-8")
    check("RuntimePeriodicAssembly(" in service
          and "RuntimeTicker(" not in stt
          and "def keep_overlay_alive" not in stt,
          "main 只提交周期依赖，不再内联 ticker 与悬浮窗恢复")
    check('("overlay-liveness", deps.overlay_liveness)' in assembly,
          "新装配保留末尾悬浮窗存活检查")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
