# -*- coding: utf-8 -*-
"""验收「手机入口」：起一个真的 HTTP 小服务，像手机那样去调它。

   · 没令牌 → 401（别人扫到端口也发不了命令）
   · 有令牌 → 打开网页、发命令、拉对话、喊停
   · 命令真的进了主程序的队列"""
from __future__ import annotations

import importlib.util
import io
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    temp_root = Path(tempfile.mkdtemp(prefix="findeck_phone_link_"))
    os.environ["FIN_DECK_PLUGIN_ROOT"] = str(temp_root / "plugins")
    os.environ["FIN_DECK_ACCEPTANCE_FILE"] = str(temp_root / "acceptance.json")
    os.environ["FIN_DECK_SECURITY_KEY"] = str(temp_root / "security-key.bin")
    os.environ["FIN_DECK_SECURITY_POLICY"] = str(temp_root / "security-policy.json")
    os.environ["FIN_DECK_SECURITY_META"] = str(temp_root / "security-meta.json")
    spec = importlib.util.spec_from_file_location("pl", APP / "phone_link.py")
    pl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pl)
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    got: list[str] = []
    stopped: list[int] = []
    target_calls: list[tuple[str, str]] = []
    thread_calls: list[tuple[str, str]] = []
    schedule_calls: list[tuple[str, dict]] = []
    log = [{"n": 7, "kind": "ai", "text": "这是电脑上的回答"}]
    link = pl.PhoneLink(on_command=got.append,
                        get_state=lambda: {"state_text": "idle · 等你说"},
                        get_log=lambda since: [x for x in log if x["n"] > since],
                        on_stop=lambda: stopped.append(1),
                        port=8791, pairing=False)     # 设备确认那一套单独测
    link.on_target = lambda title, thread_id="": (
        target_calls.append((title, thread_id)) or (True, title or "自动")
    )
    link.get_target = lambda: target_calls[-1][0] if target_calls else ""
    link.on_thread_action = lambda action, thread_id, data: (
        thread_calls.append((action, thread_id)) or (True, "会话已管理")
    )
    link.on_new_thread = lambda project_id: (True, project_id or "新对话")
    link.on_schedule = lambda action, data: (
        schedule_calls.append((action, data)) or (True, "日程已管理")
    )
    check(link.start(), f"服务起在 {link.port} 端口")
    base = f"http://127.0.0.1:{link.port}"

    def get(path: str, key: str = "") -> tuple[int, str]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        # 刚起的服务偶尔会有一次"连接被本机掐断"（10053），重试一下 ——
        # 这是测试里的网络抖动，不是程序的问题（跑批时偶发，单独跑从来不出）
        for attempt in (1, 2, 3):
            try:
                with urllib.request.urlopen(url, timeout=5) as r:
                    return r.status, r.read().decode("utf-8", "replace")
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode("utf-8", "replace")
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(0.25)
        return 0, ""

    def post(path: str, body: dict, key: str = "") -> tuple[int, str]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST",
                                     headers={"Content-Type": "application/json"})
        for attempt in (1, 2, 3):
            try:
                with urllib.request.urlopen(req, timeout=5) as r:
                    return r.status, r.read().decode("utf-8", "replace")
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode("utf-8", "replace")
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(0.25)
        return 0, ""

    def post_raw(path: str, body: bytes, key: str = "",
                 headers: dict | None = None) -> tuple[int, str]:
        sep = "&" if "?" in path else "?"
        url = base + path + (f"{sep}k={key}" if key else "")
        req = urllib.request.Request(
            url, data=body, method="POST",
            headers={"Content-Type": "application/octet-stream", **(headers or {})},
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                return r.status, r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace")

    time.sleep(0.3)
    print("① 没令牌一律拒绝")
    code, _ = get("/")
    check(code == 401, f"打开网页没令牌 → {code}")
    code, _ = post("/api/cmd", {"text": "帮我看看"}, "wrong-token")
    check(code == 401, f"发命令用错令牌 → {code}")
    check(got == [], "拒绝的时候一条命令都没进来")

    print("\n② 带对令牌：网页能开、命令能发、对话能拉")
    code, html = get("/", link.token)
    check(code == 200 and "鳍舱" in html and 'id="send"' in html,
          f"手机网页拿得到（{len(html)} 字节，含发送按钮）")
    code, body = get("/api/security/session", link.token)
    capability = json.loads(body).get("capability") or ""
    check(code == 200 and bool(capability), "取得短时操作能力凭据")
    code, _ = post("/api/cmd", {"text": "缺少凭据"}, link.token)
    check(code == 403 and not got, "手机命令缺少能力凭据被拒绝")
    for history_path, history_body in (
        ("/api/history/clear", {}),
        ("/api/history/restore", {"name": "2099-01.jsonl"}),
    ):
        code, _ = post(history_path, history_body, link.token)
        check(code == 403, f"{history_path} 缺少能力凭据被拒绝 → {code}")
    code, body = post_raw(
        "/api/cmd", json.dumps({"text": "大肥鱼 帮我查天气"},
                               ensure_ascii=False).encode("utf-8"),
        link.token,
        {"Content-Type": "application/json",
         "X-FinDeck-Capability": capability},
    )
    check(code == 200 and got == ["大肥鱼 帮我查天气"], f"命令进了队列：{got}")
    code, body = get("/api/log?since=0", link.token)
    data = json.loads(body)
    check(data.get("lines", [{}])[0].get("text") == "这是电脑上的回答",
          f"对话能拉到：{data.get('lines')}")
    check(data.get("state") == "idle · 等你说", f"状态也在：{data.get('state')}")
    code, _ = post("/api/stop", {}, link.token)
    check(stopped == [1], "喊停能传到主程序")
    code, _ = post_raw(
        "/api/cmd", json.dumps({"text": "   "}).encode("utf-8"),
        link.token,
        {"Content-Type": "application/json",
         "X-FinDeck-Capability": capability},
    )
    check(code == 400, f"空命令被挡下 → {code}")
    code, body = get("/api/plugins", link.token)
    plugins = json.loads(body)
    check(code == 200 and plugins.get("ok") is True and "plugins" in plugins,
          "插件管理接口可读")
    code, _ = post("/api/target", {"title": "未授权会话"}, link.token)
    check(code == 403 and not target_calls, "会话切换缺少能力凭据被拒绝")
    for path, payload in (
        ("/api/target", {"title": "授权会话", "id": "t1"}),
        ("/api/threads/action",
         {"action": "rename", "id": "t1", "name": "新名字"}),
        ("/api/threads/new", {"project_id": "p1"}),
        ("/api/schedule", {"action": "add", "item": {"text": "开会"}}),
    ):
        code, body = post_raw(
            path, json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            link.token,
            {"Content-Type": "application/json",
             "X-FinDeck-Capability": capability},
        )
        check(code == 200 and json.loads(body).get("ok") is True,
              f"{path} 带能力凭据可操作")
    check(target_calls == [("授权会话", "t1")], "会话目标写操作已落到回调")
    check(thread_calls == [("rename", "t1")], "会话管理写操作已落到回调")
    check(schedule_calls and schedule_calls[0][0] == "add", "日程写操作已落到回调")
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("phone-demo/plugin.json", json.dumps({
            "id": "phone.demo", "name": "Phone Demo", "version": "1.0.0",
            "api": 1, "entrypoint": "main.py", "capabilities": [],
            "permissions": ["network"],
        }))
        z.writestr("phone-demo/main.py", "def register(context):\n    pass\n")
    payload = archive.getvalue()
    code, body = post_raw("/api/plugins/install", payload, link.token, {
        "X-FinDeck-Capability": capability,
    })
    preview = json.loads(body)
    check(code == 200 and preview.get("needs_confirmation") is True,
          "插件安装先展示权限确认")
    code, body = post_raw("/api/plugins/install", payload, link.token, {
        "X-FinDeck-Capability": capability,
        "X-FinDeck-Plugin-Permissions": json.dumps(["network"]),
    })
    installed = json.loads(body)
    check(code == 200 and installed.get("installed") is True
          and installed.get("enabled") is False,
          "插件安装完成但默认不执行")
    code, body = post("/api/plugins/action", {
        "action": "enable", "id": "phone.demo"
    }, link.token)
    # securePost is a signed-header operation; plain JSON intentionally fails.
    check(code == 403, f"插件启用缺少能力凭据被拒绝 → {code}")
    req = urllib.request.Request(
        base + "/api/plugins/action?k=" + link.token,
        data=json.dumps({"action": "enable", "id": "phone.demo"}).encode(),
        method="POST",
        headers={"Content-Type": "application/json",
                 "X-FinDeck-Capability": capability},
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        enabled = json.loads(r.read().decode("utf-8", "replace"))
    check(r.status == 200 and enabled.get("plugin", {}).get("enabled") is True,
          "带能力凭据可启用插件")
    code, body = get("/api/device-acceptance", link.token)
    acceptance = json.loads(body)
    check(code == 200 and acceptance.get("ok") is True
          and len(acceptance.get("checks") or []) == 4,
          "真机验收接口返回四个核验项")
    code, body = get("/phone-assets/management.js", link.token)
    check(code == 200 and "pullAcceptance" in body and "pullPlugins" not in body,
          "外挂真机验收脚本可读取且插件业务已独立")
    code, body = get("/phone-assets/plugins.js", link.token)
    check(code == 200 and "async function pullPlugins" in body,
          "外挂插件管理脚本可读取")
    for asset, marker in (
        ("/phone-assets/chat.js", "function displayConvName"),
        ("/phone-assets/bootstrap.js", "refreshAvatars();"),
        ("/phone-assets/conversations.js", "async function pullConvs"),
        ("/phone-assets/media.js", "async function pullShots"),
        ("/phone-assets/page_core.js", "function applyLook"),
        ("/phone-assets/page_runtime.js", "async function pull"),
        ("/phone-assets/page_tools.js", "async function pullSchedule"),
        ("/phone-assets/settings.js", "function openSheet"),
        ("/phone-assets/history.js", "async function applyHistoryFilter"),
        ("/phone-assets/tasks.js", "function renderTasks"),
    ):
        code, body = get(asset, link.token)
        check(code == 200 and marker in body, f"外挂脚本 {asset.rsplit('/', 1)[-1]} 可读取")

    print("\n③ 网址是给手机用的（内网地址 + 令牌）")
    url = link.url()
    check(url.startswith("http://") and f":{link.port}/?k={link.token}" in url,
          f"网址：{url}")

    print("\n④ 主程序里真的接上了")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    phone_assembly = (
        APP / "voice_feature" / "phone_runtime_assembly.py"
    ).read_text(encoding="utf-8")
    runtime_service = (
        APP / "voice_feature" / "runtime_service_assembly.py"
    ).read_text(encoding="utf-8")
    check("assemble_phone_runtime(" in runtime_service
          and "start_phone_bridge(" in phone_assembly,
          "启动时通过手机业务装配把入口拉起来")
    check("worker=self.commands.worker" in phone_assembly
          and "drain_phone_commands = phone_commands.drain" in src,
          "手机工作线程继续通过原 drain 入口取命令")
    adapter = (
        APP / "voice_feature" / "phone_adapter_assembly.py"
    ).read_text(encoding="utf-8")
    check("assemble_phone_adapter(" in runtime_service
          and "phone_adapter.process_command" in runtime_service
          and "execute_command=lambda text" in runtime_service
          and "pre_text=text" in src,
          "手机命令经独立适配器走同一条 handle 管线")
    wake_gate = (
        APP / "voice_feature" / "runtime_wake_gate_assembly.py"
    ).read_text(encoding="utf-8")
    dispatch = (
        APP / "voice_feature" / "runtime_utterance_dispatch.py"
    ).read_text(encoding="utf-8")
    check("from_phone=from_phone" in dispatch
          and "if from_phone:" in wake_gate
          and "body, woke = text, True" in wake_gate,
          "手机命令不要求喊唤醒词")
    check("self.deps.cancel_reference_echo(" in phone_assembly,
          "手机上传录音在转写前经过参考波形回声消除")
    ov = (APP / "overlay.py").read_text(encoding="utf-8")
    ov += "\n" + (
        APP / "overlay_feature" / "settings_pages_mixin.py"
    ).read_text(encoding="utf-8")
    ov += "\n" + (
        APP / "overlay_feature" / "settings_delivery_mixin.py"
    ).read_text(encoding="utf-8")
    ov += "\n" + (
        APP / "overlay_feature" / "settings_connection_mixin.py"
    ).read_text(encoding="utf-8")
    check('"手机入口"' in ov and "copy_phone_url" in ov, "设置里有开关和网址复制")

    link.stop()
    shutil.rmtree(temp_root, ignore_errors=True)
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
