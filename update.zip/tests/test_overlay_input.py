# -*- coding: utf-8 -*-
"""验证悬浮窗设置里的文字项：现在是一个按钮，点开弹窗能不能真的打字。"""
from __future__ import annotations

import ctypes
import json
import os
import sys
import time
from pathlib import Path

import tkinter as tk

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "input-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

u32 = ctypes.windll.user32
WM_CHAR = 0x0102


def widgets(widget, cls, out=None):
    out = [] if out is None else out
    for child in widget.winfo_children():
        if isinstance(child, cls):
            out.append(child)
        widgets(child, cls, out)
    return out


def find_value_button(panel):
    """设置面板里那些"点一下改文字"的按钮：Label + 绑了 Button-1，显示的是当前值。"""
    for lab in widgets(panel, tk.Label):
        if lab.bind("<Button-1>"):
            text = str(lab.cget("text"))
            if "大肥鱼" in text or "点这里设置" in text or "已经就绪" in text:
                return lab
    return None


def main() -> int:
    (S / "config.json").write_text(json.dumps({
        "name": "输入测试", "overlay_bg_image": "", "overlay_alpha": 1.0,
        "wake_word": "大肥鱼"}, ensure_ascii=False), encoding="utf-8")
    (S / "pos.json").write_text('{"x": 100, "y": 100}', encoding="utf-8")
    (S / "status.json").write_text(json.dumps(
        {"state": "idle", "level": 0, "ts": time.time(), "pid": os.getpid()}),
        encoding="utf-8")
    (S / "control.json").write_text('{"action":"","ts":0}', encoding="utf-8")
    (S / "speak.json").write_text('{"active":false,"level":0,"ts":0}', encoding="utf-8")

    overlay.CONFIG = S / "config.json"
    overlay.POS = S / "pos.json"
    overlay.STATUS = S / "status.json"
    overlay.SPEAK_STATUS = S / "speak.json"
    overlay.CONTROL = S / "control.json"
    overlay.WAKE_TEST_FILE = S / "wake_test.json"
    overlay.EXIT_LOG = S / "exit.log"
    overlay.note = lambda t: None

    o = overlay.Overlay()
    o.alpha_override = 1.0
    o.set_expanded(True)
    o.show_tab("基本")
    for _ in range(140):
        o.root.update()
        time.sleep(0.01)

    btn = find_value_button(o.panel)
    if btn is None:
        print("！！设置面板里没找到文字项按钮")
        o.root.destroy()
        return 1
    print(f"找到文字项按钮：{btn.cget('text')!r}")

    before_windows = len(widgets(o.root, tk.Toplevel))
    o.edit_text("唤醒词", "大肥鱼", lambda _t: None)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    toplevels = widgets(o.root, tk.Toplevel)
    print(f"弹窗：{before_windows} → {len(toplevels)}")
    if len(toplevels) <= before_windows:
        print("！！点按钮没弹出编辑窗口")
        o.root.destroy()
        return 2
    win = toplevels[-1]
    entries = widgets(win, tk.Entry)
    if not entries:
        print("！！弹窗里没有输入框")
        o.root.destroy()
        return 3
    entry = entries[0]
    print(f"  弹窗输入框：state={entry.cget('state')!r} "
          f"enabled={str(entry.cget('state')) != 'disabled'}")

    hwnd_entry = entry.winfo_id()
    before = entry.get()
    for ch in "测试":
        u32.PostMessageW(hwnd_entry, WM_CHAR, ord(ch), 0)
    for _ in range(30):
        o.root.update()
        time.sleep(0.01)
    after = entry.get()
    ok = after != before
    print(f"  投递按键：{before!r} → {after!r}  {'✓ 收得到' if ok else '✗ 收不到'}")
    o.root.destroy()
    return 0 if ok else 4


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
