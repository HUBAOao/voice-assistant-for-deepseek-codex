# -*- coding: utf-8 -*-
"""唤醒词匹配测试：拿真实日志里出现过的句子跑一遍。"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")

from stt import cancel_hit, extract_word  # noqa: E402

WAKE = ["大肥鱼"]

CASES = [
    # (识别出来的原句, 期望能不能唤醒)
    ("大肥鱼，现在把三个快捷方式合并成一个，并且选择一个。", True),
    ("大肥鱼。", True),
    ("大肥与悦把颜色切换的过渡动画做一下。", True),      # ← 日志里真出现过的漏识别
    ("大飞鱼，今天天气怎么样", True),
    ("打肥鱼把设置打开", True),
    ("达飞雨，你好", True),
    ("大肥于在吗", True),
    ("大肥渔帮我关掉", True),
    ("大鲱鱼", True),
    ("飞鱼把颜色切换的过渡动画做一下。", True),        # ← 句首"大"被吞了，日志同类
    ("大肥把设置关掉", True),
    ("肥鱼今天怎么样", True),
    ("大白鱼，你好", False),                             # 声母不同，不该触发
    ("大鲨鱼，你好", False),
    ("这条飞鱼真好看", False),                            # 句首不是它，不该触发
    ("我买了一条肥鱼", False),
    ("红烧鱼真好吃", False),
    ("今天天气不错", False),
    ("好大的肥鱼", False),
    ("", False),
]

# 取消词现在按"整句就是它"严格判定，所以这里列的是**取消判定**的结果
# （详细的在 test_cancel_strict.py 里）
CANCEL = [
    ("取消", True),
    ("取消吧", True),
    ("取 消 掉", True),
    ("取笑", True),          # 真同音，Whisper 常这么写 → 还是算取消
    ("取消订单", False),      # 这是你要发给 AI 的话，不是取消指令
    ("取笑他", False),
    ("别取笑他了", False),
]


def run(name: str, words: list[str], cases) -> int:
    bad = 0
    print(f"\n=== {name} ===")
    for text, want in cases:
        body, hit = extract_word(text, words)
        ok = (hit == want)
        bad += 0 if ok else 1
        mark = "✓" if ok else "✗"
        print(f"  {mark} 触发={str(hit):5s} 正文=「{body}」   ← 「{text}」")
    return bad


def main() -> int:
    bad = run("唤醒词 大肥鱼", WAKE, CASES)
    print("\n=== 取消词 取消（严格判定）===")
    for text, want in CANCEL:
        hit = cancel_hit(text, ["取消"])
        ok = (hit == want)
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} 取消={str(hit):5s}   ← 「{text}」")
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
