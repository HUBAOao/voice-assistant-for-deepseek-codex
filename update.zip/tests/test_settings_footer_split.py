# -*- coding: utf-8 -*-
"""Settings footer actions remain stable after leaving the window shell."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_footer_mixin import (  # noqa: E402
    OverlaySettingsFooterMixin,
)
from overlay_feature.settings_shell_mixin import (  # noqa: E402
    OverlaySettingsShellMixin,
)


class Widget:
    def __init__(self, parent, **options) -> None:
        self.parent = parent
        self.options = options
        self.packed = None
        self.bound = []

    def pack(self, **options):
        self.packed = options
        return self

    def bind(self, sequence, callback):
        self.bound.append((sequence, callback))


class Tk:
    created = []

    @staticmethod
    def Label(parent, **options):
        widget = Widget(parent, **options)
        Tk.created.append(widget)
        return widget


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Probe(OverlaySettingsFooterMixin):
        def __init__(self) -> None:
            self.tk = Tk
            self.button_color = "#2f7f5a"
            self.actions = []

        def save_settings(self):
            self.actions.append("save")

        def reset_defaults(self):
            self.actions.append("reset")

        def show_about(self):
            self.actions.append("about")

        def check_update(self):
            self.actions.append("update")

        def publish_site(self):
            self.actions.append("publish")

    foot = object()
    probe = Probe()
    Tk.created = []
    probe.build_footer(foot)
    check(probe.upd_label.parent is foot
          and probe.upd_label.options.get("text") == "",
          "更新提示标签仍绑定在设置底栏")
    labels = {
        item.options.get("text"): item
        for item in Tk.created
    }
    for text, action in (
        ("保存", "save"),
        ("恢复默认", "reset"),
        ("关于", "about"),
        ("检查更新", "update"),
        ("发布到网站", "publish"),
    ):
        widget = labels.get(text)
        probe.actions.clear()
        if widget and widget.bound:
            widget.bound[0][1](None)
        check(widget is not None and probe.actions == [action],
              f"底栏按钮「{text}」仍调用原入口")
    check(issubclass(OverlaySettingsShellMixin, OverlaySettingsFooterMixin),
          "历史设置外壳继续继承底栏业务模块")

    source = (APP / "overlay_feature" / "settings_shell_mixin.py").read_text(
        encoding="utf-8"
    )
    footer = (
        APP / "overlay_feature" / "settings_footer_mixin.py"
    ).read_text(encoding="utf-8")
    check("self.build_footer(foot)" in source,
          "外壳只组装底栏，不内联按钮实现")
    check("text=\"发布到网站\"" not in source
          and "text=\"发布到网站\"" in footer,
          "网站发布等底栏动作已迁入独立模块")
    check("def build_panel(self)" in source and "def build_footer(self, foot)" in footer,
          "旧 build_panel 与新底栏入口同时存在")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
