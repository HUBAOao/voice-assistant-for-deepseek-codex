# -*- coding: utf-8 -*-
"""验收"语音不会重叠"：两个朗读进程必须**排队**，不能同时出声。

原理：say.py 里那把 Windows 互斥锁以前只锁了"拿锁那一瞬间"（句柄一出函数就被回收），
所以两个 say.py 会真的同时在放音。现在句柄留在模块级、握到进程结束 —— 后一个必须等。
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

APP = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
PY = APP / ".venv" / "Scripts" / "python.exe"

def hold_cmd(seconds: float) -> str:
    return ("import sys, time; sys.path.insert(0, r'%s'); import say;"
            "ok = say.wait_turn(10); time.sleep(%s); print('done', ok)"
            % (APP, seconds))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    print("① 先单独跑一次，量一下拿锁并占着不放要多久")
    t0 = time.time()
    subprocess.run([str(PY), "-c", hold_cmd(1.5)], capture_output=True, timeout=60)
    one = time.time() - t0
    print(f"     一个进程用了 {one:.2f} 秒")

    print("② 同时起两个：第二个必须排队等第一个（不能重叠）")
    t0 = time.time()
    p1 = subprocess.Popen([str(PY), "-c", hold_cmd(1.5)],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(0.3)                      # 让第一个先把锁拿走
    p2 = subprocess.Popen([str(PY), "-c", hold_cmd(1.5)],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p1.wait(timeout=60)
    p2.wait(timeout=60)
    both = time.time() - t0
    print(f"     两个一起跑，总共用了 {both:.2f} 秒（如果是重叠，应该 ≈ {one:.2f} 秒）")
    check(both >= one * 1.6, f"确实排队了（{both:.2f}s ≥ 1.6×{one:.2f}s）")

    print("③ 关键的那句握着不放还在不在")
    src = (APP / "say.py").read_text(encoding="utf-8")
    check("_MUTEX_HANDLE = handle" in src, "拿了锁就存到模块级（不会提前释放）")
    check("_MUTEX_HANDLE = None" in src, "确实有个模块级变量接着它")
    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check("lambda text: speak(text, wait=True)" in stt,
          "朗读排队用的是念完再返回那个 speak")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
