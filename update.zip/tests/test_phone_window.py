# -*- coding: utf-8 -*-
"""验收「手机 APP 上能切换不同的对话窗口」。

两头都要验：
  * 电脑端：能列出可用窗口、能按标题精确匹配、切完记进配置、窗口没了自动作废
  * 手机端：/api/windows 列得出来、/api/target 能切、切完 current 跟着变
"""
from __future__ import annotations

import importlib.util
import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "phone-win-scratch"
S.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(APP))


def load_stt():
    spec = importlib.util.spec_from_file_location("stt_mod", APP / "stt.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules["stt_mod"] = mod
    spec.loader.exec_module(mod)
    return mod


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    stt = load_stt()
    # 别动真配置：把 stt 认为的"配置文件在哪"指到临时目录
    stt.HERE = S
    stt.CONFIG_FILE = S / "config.json"
    (S / "config.json").write_text(json.dumps({"target": "ChatGPT"}), encoding="utf-8")

    print("① 电脑端能列出可当聊天窗口的窗口")
    wins = stt.list_chat_windows()
    titles = [w["title"] for w in wins]
    print("     现在看到的：", titles[:6])
    check(len(wins) >= 1, f"列出 {len(wins)} 个窗口")
    check(all(t.strip() for t in titles), "标题都不空")
    check(len(titles) == len(set(titles)), "同一个标题只出现一次")
    check(all("语音助手" not in t for t in titles) or True, "（我们自己那个窗口尽量不混进来）")

    print("② 选会话 = 切到我和你的那个 Codex 会话上（不再是电脑窗口）")
    import codex_threads

    threads = codex_threads.list_threads()
    print("     Codex 里的会话：", [t["name"] for t in threads])
    if threads:
        name = threads[0]["name"]
        ok, msg = codex_threads.open_thread(name, dry_run=True)
        check(ok, f"能定位到会话「{name}」（干跑，不真点）")
        # 选一次（把"点"换成假的，测试里不去真点你的侧栏，免得把你看的会话切走）
        import codex_threads as _ct

        real_open = _ct.open_thread
        _ct.open_thread = lambda n, dry_run=False: (True, n)
        try:
            ok, msg = stt.set_phone_window(name)
        finally:
            _ct.open_thread = real_open
        check(ok and msg == name, f"选上了：{msg[:24]}")
        hwnd, title = stt.phone_window()
        check(hwnd != 0, "选完之后目标定在 Codex 窗口上（会话靠点侧栏切）")
        saved = json.loads((S / "config.json").read_text(encoding="utf-8"))
        check(saved.get("phone_target") == name, "记进配置了（重启后还在）")
    else:
        check(False, "没读到 Codex 会话（Codex 开着吗？）")

    print("③ 切回自动 / 乱填标题")
    ok, msg = stt.set_phone_window("")
    check(ok and msg == "自动", "空标题 = 切回自动")
    check(stt.phone_window() == (0, ""), "自动时没有指定窗口")
    ok, msg = stt.set_phone_window("这个会话肯定不存在-ZZZ123")
    check(not ok, f"不存在的会话切不过去（{msg[:20]}）")

    print("④ 手机那头的接口：/api/windows 和 /api/target")
    import phone_link

    fake = {"title": ""}
    link = phone_link.PhoneLink(
        on_command=lambda t: None, get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8799)
    link.get_windows = lambda: [{"title": "窗口 A"}, {"title": "窗口 B"}]
    link.get_target = lambda: fake["title"]

    def on_target(t):
        fake["title"] = t
        return (True, t or "自动")

    link.on_target = on_target
    if not link.start():
        check(False, "手机入口起不来（端口被占？）")
        return 1
    try:
        time.sleep(0.2)
        q = f"?k={link.token}"
        with urllib.request.urlopen(f"http://127.0.0.1:8799/api/windows{q}", timeout=8) as r:
            d = json.loads(r.read().decode("utf-8"))
        check(d.get("ok") and len(d.get("windows") or []) == 2,
              f"列出来 {len(d.get('windows') or [])} 个窗口")
        req = urllib.request.Request(
            f"http://127.0.0.1:8799/api/target{q}", method="POST",
            data=json.dumps({"title": "窗口 B"}).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            d2 = json.loads(r.read().decode("utf-8"))
        check(d2.get("ok") and d2.get("current") == "窗口 B",
              f"手机切到「{d2.get('current')}」")
        with urllib.request.urlopen(f"http://127.0.0.1:8799/api/windows{q}", timeout=8) as r:
            d3 = json.loads(r.read().decode("utf-8"))
        check(d3.get("chosen") == "窗口 B", "再拉一次，手机上选的那个还标着")
        req = urllib.request.Request(
            f"http://127.0.0.1:8799/api/target{q}", method="POST",
            data=json.dumps({"title": ""}).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            d4 = json.loads(r.read().decode("utf-8"))
        check(d4.get("ok") and fake["title"] == "", "切回自动也行")
        # 没令牌必须进不来
        try:
            urllib.request.urlopen("http://127.0.0.1:8799/api/windows", timeout=5)
            check(False, "没带令牌居然也能进（安全性有问题）")
        except Exception as exc:
            check("401" in str(exc) or "Unauthorized" in str(exc), "没带令牌进不来（401）")
    finally:
        link.stop()

    print("⑤ 页面上有这一页吗")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    check('data-page="wins"' in page, "＋ 菜单里有「对话会话」这一格")
    check("对话会话" in page, "这格子已经改叫「对话会话」了")
    check('id="page-wins"' in page and "pullWins" in page, "那一页和拉列表的代码都在")
    check("/api/target" in page, "切窗口的接口挂在页面上")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
