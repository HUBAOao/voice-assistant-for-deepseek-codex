# -*- coding: utf-8 -*-
"""Native phone reading remains explicit, bounded and non-sending."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APP = ROOT / "outputs" / "voice-to-text"
SOURCE = (
    ANDROID / "java" / "com" / "hubao" / "voiceassistant"
    / "MainActivity.java"
)
PAGE = APP / "phone_page.html"
SCRIPT = APP / "phone_feature" / "ui" / "settings.js"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    source = SOURCE.read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    script = SCRIPT.read_text(encoding="utf-8")
    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")

    check("import android.speech.tts.TextToSpeech" in source,
          "MainActivity 接入 Android 原生 TTS")
    check("Locale.SIMPLIFIED_CHINESE" in source
          and "TextToSpeech.LANG_NOT_SUPPORTED" in source,
          "朗读优先使用简体中文并处理缺失语音数据")
    check("text.length() > 8000" in source
          and "text.substring(0, 8000)" in source,
          "原生朗读限制最多 8000 字符")
    check('speakReply(final String text)' in source
          and '@JavascriptInterface' in source,
          "网页只能通过显式 JS 接口触发朗读")
    check("TextToSpeech.QUEUE_FLUSH" in source,
          "再次朗读会替换上一段朗读")
    check("phoneTts.stop()" in source and "phoneTts.shutdown()" in source,
          "页面销毁时停止并释放系统 TTS")
    speak_body = source[
        source.index("private void speakOnPhone("):
        source.index("private void speakPendingPhoneSpeech(")
    ]
    check("send" not in speak_body and "finish()" not in speak_body,
          "朗读原生方法不发送消息或关闭页面")
    check("READ_MEDIA" not in manifest and "READ_EXTERNAL_STORAGE" not in manifest,
          "手机朗读没有引入媒体或存储读取权限")
    check('id="tispeak"' in page and "手机朗读" in page,
          "＋ 菜单提供明确的手机朗读入口")
    check('data-kind="ai"' in script and "speakReply" in script,
          "朗读只读取当前页面最近一条 AI 回复")
    check("togglePlus(false)" in script and "8000" in script,
          "点按后收起菜单并沿用相同文字上限")
    check("send(" not in script[script.index("function speakLatestReply()"):
                                      script.index("const speakTile")],
          "网页朗读逻辑不自动发送回复")

    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = archive.read("classes.dex")
        for symbol in (
            "speakReply",
            "speakOnPhone",
            "findeck-phone-reply",
            "Landroid/speech/tts/TextToSpeech;",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
