# -*- coding: utf-8 -*-
"""验收「署名」：手机设置里有一栏、网页底部有小字。

两条都必须跟电脑端「关于」同一个来源（version.py），改一处两边都变；
而且署名信息不该能被别人改掉（之前定的规矩：写死在 version.py 里，不做成设置项）。
"""
from __future__ import annotations

import json
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    import version
    import download_page as dp

    print("① 手机设置里那一栏")
    page = (APP / "phone_link.py").read_text(encoding="utf-8")
    for key, what in (("aboutauthor", "作者"), ("aboutcontact", "邮箱"),
                      ("aboutcopy", "版权"), ("aboutfree", "自由使用说明"),
                      ("aboutnotice", "完整声明")):
        check(f'id="{key}"' in page, f"设置里有「{what}」那一行（id={key}）")
    check("关于 / 署名" in page, "标题写着「关于 / 署名」")
    check('set("aboutauthor"' in page or "set('aboutauthor'" in page,
          "这些字是拉 /api/info 填进去的（跟电脑端同源）")

    print("② 电脑端把署名发给手机")
    src = (APP / "stt.py").read_text(encoding="utf-8")
    check('"author": version.AUTHOR' in src and '"contact": version.CONTACT' in src,
          "phone_info 里带上了作者和联系方式")
    check('"copyright": version.COPYRIGHT' in src
          and '"free": version.FREE_LINE' in src
          and '"notice": version.NOTICE' in src,
          "版权 / 自由使用 / 完整声明也一起发")
    check("\nimport version" in src or "import version " in src,
          "stt.py 里真的 import 了 version（不然那几行会抛异常）")

    print("③ 网页底部的小字署名")
    html = dp.build_html()
    foot = html.split("<footer>")[-1].split("</footer>")[0]
    check('class="sig"' in foot, "页脚有专门的小字样式（不是正文大小）")
    for text, what in ((version.AUTHOR, "作者"), (version.CONTACT, "联系方式"),
                       (version.COPYRIGHT, "版权"), (version.FREE_LINE, "自由使用")):
        check(text in foot, f"页脚里有{what}：{text[:22]}")
    check("font-size:11.5px" in html, "小字真的是小字（11.5px）")

    print("④ 署名不能被改掉（写死在 version.py）")
    ov = (APP / "overlay.py").read_text(encoding="utf-8")
    check("version.AUTHOR" in ov and "version.CONTACT" in ov
          and "version.COPYRIGHT" in ov, "电脑端「关于」也读同一份")
    check('"author"' not in json.dumps(
        json.loads((APP / "config.json").read_text(encoding="utf-8"))),
        "署名不在 config.json 里（别人改配置也抹不掉）")

    print("⑤ 真机接口：手机拉得到署名")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8813)
    link.get_info = lambda: {"name": "大肥鱼", "pc": version.APP_VERSION,
                            "phone": version.PHONE_VERSION,
                            "author": version.AUTHOR, "contact": version.CONTACT,
                            "copyright": version.COPYRIGHT, "free": version.FREE_LINE,
                            "notice": version.NOTICE}
    if link.start():
        try:
            time.sleep(0.2)
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8813/api/info?k={link.token}", timeout=8) as r:
                d = json.loads(r.read().decode("utf-8"))
            check(d.get("author") == version.AUTHOR, f"/api/info 里有作者：{d.get('author')}")
            check(d.get("contact") == version.CONTACT, f"有联系方式：{d.get('contact')}")
            check(d.get("copyright", "").startswith("©"), f"有版权：{d.get('copyright')}")
            # 本地那页拆掉了，署名现在在 GitHub 那个下载站上
            with urllib.request.urlopen(
                    "https://hubaoao.github.io/voice-assistant-for-deepseek-codex/",
                    timeout=20) as r:
                dl = r.read().decode("utf-8", "replace")
            check(version.AUTHOR in dl and version.CONTACT in dl,
                  "公网下载站底部也有署名")
        finally:
            link.stop()
    else:
        check(False, "手机入口起不来")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
