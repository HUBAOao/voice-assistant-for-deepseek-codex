"""ASCII shark chat theme, vendored from stackedlol/ascii-sharks."""
from __future__ import annotations

import importlib.util
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / "work" / "android-app" / "java" / "com" / "hubao" / "voiceassistant"
ASSETS = ROOT / "work" / "android-app" / "assets" / "ascii-sharks"
LICENSE = ROOT / "work" / "android-app" / "assets" / "ascii-sharks-LICENSE.txt"
WHALE_LICENSE = ROOT / "work" / "android-app" / "assets" / "ascii-whales-LICENSE.txt"
WHALE_NOTICES = (
    ROOT / "work" / "android-app" / "assets"
    / "ascii-whales-THIRD_PARTY_NOTICES.md"
)
MANTA_HTML = ROOT / "work" / "android-app" / "assets" / "ascii-mantas" / "index.html"
MANTA_LICENSE = ROOT / "work" / "android-app" / "assets" / "ascii-mantas-LICENSE.txt"
SHARK_RENDERER = (
    ROOT / "work" / "reference" / "ascii-sharks-src"
    / "ascii-sharks-main" / "src" / "renderer.ts"
)
SHARK_SPECIES = (
    ROOT / "work" / "reference" / "ascii-sharks-src"
    / "ascii-sharks-main" / "src" / "species.ts"
)
SHARK_WORLD = (
    ROOT / "work" / "reference" / "ascii-sharks-src"
    / "ascii-sharks-main" / "src" / "world.ts"
)
DRAWABLE = ROOT / "work" / "android-app" / "res" / "drawable"
VERSION = ROOT / "outputs" / "voice-to-text" / "version.py"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    activity = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    theme = (JAVA / "NativeTheme.java").read_text(encoding="utf-8")
    html = (ASSETS / "index.html").read_text(encoding="utf-8")
    engine = (ASSETS / "engine.js").read_text(encoding="utf-8")
    license_text = LICENSE.read_text(encoding="utf-8")
    whale_license_text = WHALE_LICENSE.read_text(encoding="utf-8")
    whale_notices_text = WHALE_NOTICES.read_text(encoding="utf-8")
    manta_html = MANTA_HTML.read_text(encoding="utf-8")
    manta_license = MANTA_LICENSE.read_text(encoding="utf-8")
    shark_renderer = SHARK_RENDERER.read_text(encoding="utf-8")
    shark_species = SHARK_SPECIES.read_text(encoding="utf-8")
    shark_world = SHARK_WORLD.read_text(encoding="utf-8")
    sun_icon = (DRAWABLE / "ic_findeck_sun.xml").read_text(encoding="utf-8")
    moon_icon = (DRAWABLE / "ic_findeck_moon.xml").read_text(encoding="utf-8")

    print("① 原项目直接作为主题")
    check("file:///android_asset/ascii-sharks/index.html" in activity
          and "?sharks=hammerhead:1.58,hammerhead:1.24,hammerhead:0.64"
          in activity
          and "&v=1.230" in activity
          and "pixelSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);"
          in activity
          and "pixelThemeView.clearCache(true);" in activity
          and '<script src="./engine.js?v=1.230"></script>' in html
          and 'new WebView(this)' in activity,
          "原画布三档锤头鲨、思考鱼桥接和缓存刷新已就绪")
    check("<canvas" in html
          and "what's on your mind?" not in html
          and "Ask anything" not in html,
          "不额外绘制输入框、标题或提示字")
    check("new OceanEngine(document.querySelector(\"canvas\")" in engine,
          "运行原项目编译后的海洋引擎")
    check("AsciiOceanView" not in activity
          and "showPixelSharkEffect" not in activity
          and 'addTileRow(panel, "状态", "停", "头像", "")' in activity,
          "移除独立页面和单独特效入口")

    print("\n② 主题与文字")
    check('"pixelSharkTheme"' in theme
          and "PIXEL_SHARK_THEME" in theme
          and "PIXEL_SHARK_DAY" in theme
          and "AI_BUBBLE = Color.TRANSPARENT;" in theme
          and "ME_BUBBLE = Color.TRANSPARENT;" in theme,
          "主题开启后所有消息气泡透明")
    check('String[] pixelModes = {"off", "dark", "light"};' in activity
          and '"关闭", "黑夜", "白天"' in activity
          and "applyPixelThemeChoice(look, mode);" in activity,
          "外观设置提供关闭、黑夜和白天")
    check("pixelThemeToggle" in activity
          and "new ImageView(this)" in activity
          and "R.drawable.ic_findeck_sun" in activity
          and "R.drawable.ic_findeck_moon" in activity
          and "rotationBy(180f)" in activity
          and "切换像素鲨鱼主题昼夜" in activity,
          "聊天页右上角使用简洁日月图形并带旋转过渡")
    check("M12,7.8" in sun_icon and "M19.6,15.8" in moon_icon,
          "太阳和月亮图标均为简洁线条图形")
    check("document.documentElement.classList.toggle(" in activity
          and "'pixel-day'," in activity
          and "setInterval" not in html
          and "setTimeout" not in html,
          "昼夜只由按钮切换，不自动循环")
    check("refreshMessageTextStyles(" in activity
          and "messageBodyTextColor(" in activity
          and "pixelTextColor()" in theme
          and "pixelDimColor()" in theme,
          "消息正文按当前背景自动切换深浅文字")
    check("refreshPixelSharkTheme();" in activity
          and "rootScrim.setBackgroundColor(enabled" in activity
          and "wallpaperView.setVisibility(enabled" in activity,
          "主题启用时让聊天背景直接露出鲨鱼画布")
    check("BG = PIXEL_SHARK_DAY" in theme
          and "PANEL = PIXEL_SHARK_DAY" in theme
          and "TEXT = PIXEL_SHARK_DAY" in theme
          and "DIM = PIXEL_SHARK_DAY" in theme
          and "overlaySurfaceColor(" in theme
          and "recolorThemeText(root, oldText, oldDim);" in activity
          and "showSettings(\"外观\");" in activity,
          "白天模式同步切换全部原生面板、文字和抽屉配色")
    check("id=\"topGlass\"" in html
          and "id=\"bottomGlass\"" in html
          and "context.filter = 'blur(13px) saturate(145%)'" in html
          and "requestAnimationFrame(syncGlass)" in html
          and "syncPixelGlassRegions();" in activity
          and "headerFrostedBackdrop.setAlpha(enabled ? 0f : 1f);"
          in activity
          and "plusFrostedBackdrop.setAlpha(0f);" in activity,
          "顶底栏和抽屉毛玻璃逐帧取样鲨鱼并保持联动")
    check('name: "trevally"' not in shark_species
          and 'name: "bonito"' not in shark_species
          and "MEDIUM_SPECIES_START" not in shark_species
          and "MEDIUM_SPECIES_START" not in shark_world
          and "drawMediumSchools" not in shark_renderer
          and "new World(sharks2)" in engine
          and "ctx.fillRect(Math.round(x - 1), Math.round(y), 2, 1);"
          in shark_renderer
          and "clamp(Math.round((W * H) / 3200), 120, 480)"
          in shark_world
          and "window.setFinDeckThinking" in engine
          and "dataset.finDeckThinking" in engine
          and "setThinking(active: boolean)" in shark_renderer
          and "ensureThinkingShark(world)" in shark_renderer
          and "sharkIdGrid[i] === this.thinkingSharkId" in shark_renderer
          and "candidates[Math.floor(Math.random() * candidates.length)].id"
          in shark_renderer
          and 'ctx.shadowColor = "#4aa3ff";' in shark_renderer
          and "const tone = clamp(level / 206, 0, 1);" in shark_renderer
          and "filter: invert(1) hue-rotate(180deg) saturate(.72);"
          in html
          and "window.setFinDeckThinking && window.setFinDeckThinking("
          in activity
          and 'id="mediumFish"' not in html
          and "copyBlurred(" in html,
          "恢复原版鱼群，并加入思考时单条蓝色鲨鱼")
    check("!NativeTheme.PIXEL_SHARK_THEME || !chatDrawerOpen"
          in activity
          and "headerGlassVeil" in activity
          and "footerGlassVeil" in activity
          and "headerContentBasePaddingTop + top" in activity
          and "footerContentBasePaddingBottom + bottom" in activity
          and "setDecorFitsSystemWindows(false)" in activity
          and "installSystemBarInsets();" in activity
          and "topChrome.setPadding(0, 0, 0, 0);" in activity
          and "bottomChrome.setPadding(0, 0, 0, 0);" in activity,
          "毛玻璃随聊天抽屉收合且背景贯穿状态栏与导航栏")
    whale_html = (
        ROOT / "work" / "android-app" / "assets" / "ascii-whales"
        / "index.html"
    ).read_text(encoding="utf-8")
    whale_engine = (
        ROOT / "work" / "android-app" / "assets" / "ascii-whales"
        / "engine.js"
    ).read_text(encoding="utf-8")
    whale_shape = (
        ROOT / "work" / "reference" / "dsh-ascii-whales-src"
        / "dsh-ascii-whales-main" / "vendor" / "ascii-sharks"
        / "whales.ts"
    ).read_text(encoding="utf-8")
    manta_scene = manta_html.split("manta: {", 1)[-1].split("jelly: {", 1)[0]
    check("ascii-whales/index.html" in activity
          and "this.sharks = [whale]" in whale_engine
          and "new OceanEngine(" in whale_engine
          and '"#4d6bfe"' in whale_engine
          and "startWhaleVisit" in whale_engine
          and "bridge.finished()" in whale_engine
          and "ensureWhaleEngine" in whale_engine
          and "bridge.started()" in whale_engine
          and "whale.length * 0.45" in whale_engine
          and "startWhaleVisitor(edgeIndex)" in whale_engine
          and "visitorProgress" in whale_engine
          and "glyphs.edgeHeavy" in whale_engine
          and "sh.kind !== 'whale' && sc < cols" in (
              ROOT / "work" / "reference" / "dsh-ascii-whales-src"
              / "dsh-ascii-whales-main" / "vendor" / "ascii-sharks"
              / "renderer.ts"
          ).read_text(encoding="utf-8")
          and "Math.random() < .30d" in activity
          and "ui.postDelayed(" in activity
          and "whaleVisitHideRunnable, 105_000L" in activity
          and "new PixelWhaleBridge()" in activity
          and "public void started()" in activity
          and "createGiantWhaleView();" in activity
          and "destroyGiantWhaleView();" in activity
          and "WebSettings.LOAD_NO_CACHE" in activity
          and "id=\"topGlass\"" in whale_html
          and "id=\"bottomGlass\"" in whale_html,
          "低概率蓝色巨鲸超过屏幕宽度，并参与顶底玻璃")
    check("0.105 + 0.015 * Math.sin" in whale_shape
          and "across / .18" in whale_shape
          and "0.68 + 0.18 *" in (
              ROOT / "work" / "reference" / "dsh-ascii-whales-src"
              / "dsh-ascii-whales-main" / "vendor" / "ascii-sharks"
              / "renderer.ts"
          ).read_text(encoding="utf-8"),
          "巨鲸按真实航拍头身比例重塑并保留蓝色鳍面层次")
    check("ascii-mantas/index.html?scene=manta" in activity
          and "pixelMantaView" in activity
          and "new Manta(" in manta_html
          and "clamp(Math.round((W * H) / 260000), 3, 5)"
          in manta_html
          and "this.pod = {" in manta_html
          and "this.span = 1 - 0.30" in manta_html
          and "if (edge < 0.045) sh -= 0.24;" in manta_html
          and "background:transparent" in manta_html
          and "waterBackground(this.base" not in manta_scene,
          "蝠鲼与鳐鱼代码保留")
    check("pixelMantaView.setVisibility(View.GONE);" in activity,
          "蝠鲼层暂时不在界面显示")
    check("pixelTapCount >= 7" in activity
          and "trackSevenTapWhale(event);" in activity
          and "now - pixelTapDownAt > 450L" in activity
          and "now - pixelTapLastAt <= 1600L" in activity
          and "Math.random() < .30d" in activity
          and "50_000L + Math.round(Math.random() * 40_000L)"
          in activity,
          "七连点强制召唤巨鲸且保留自然随机概率")

    print("\n③ 来源与安装包")
    check("stackedlol/ascii-sharks" in license_text
          or "Copyright (c) 2026 drewdi" in license_text,
          "保留原项目MIT许可证")
    check("Copyright (c) 2026 Chael-Chael" in whale_license_text
          and "stackedlol/ascii-sharks" in whale_notices_text,
          "保留鲸鱼主题及上游项目的许可与署名")
    check("Copyright" in manta_license,
          "保留蝠鲼项目许可")
    spec = importlib.util.spec_from_file_location(
        "pixel_shark_version", VERSION
    )
    version = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(version)
    check(version.PHONE_VERSION == "1.230", "手机端版本为v1.230")
    check(any("像素鲨鱼主题" in item and "原版" in item
              for item in version.PHONE_CHANGELOG),
          "版本记录说明使用原项目和主题效果")
    check(APK.is_file(), "APK已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            names = set(archive.namelist())
        check("assets/ascii-sharks/index.html" in names
              and "assets/ascii-sharks/engine.js" in names,
              "APK包含原项目画布与编译产物")
        check("assets/ascii-whales/index.html" in names
              and "assets/ascii-whales/engine.js" in names,
              "APK包含蓝色巨鲸画布")
        check("assets/ascii-mantas/index.html" in names,
              "APK包含蝠鲼与鳐鱼画布")
        check("assets/ascii-sharks-LICENSE.txt" in names,
              "APK包含原项目许可证")
        check("assets/ascii-whales-LICENSE.txt" in names
              and "assets/ascii-whales-THIRD_PARTY_NOTICES.md" in names,
              "APK包含鲸鱼项目与上游许可")
        check("assets/ascii-mantas-LICENSE.txt" in names,
              "APK包含蝠鲼项目许可")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
