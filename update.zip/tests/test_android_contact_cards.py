# -*- coding: utf-8 -*-
"""Contact-card shares enter the draft tray without contacts permission."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    for mime in ("text/x-vcard", "text/directory"):
        check(manifest.count(f'android:mimeType="{mime}"') == 2,
              f"{mime} 同时支持单张和多张系统分享")
        check(mime in media,
              f"{mime} 在网页附件接收白名单中")
    check("READ_CONTACTS" not in manifest
          and "WRITE_CONTACTS" not in manifest,
          "没有申请通讯录读写权限")
    check("isContactDocumentMime(type)" in activity
          and "VCARD_DOCUMENT_MIME" in activity
          and "DIRECTORY_DOCUMENT_MIME" in activity,
          "原生只按 MIME 登记联系人卡片附件")
    check("isContactDocumentMime(mime)" in activity,
          "联系人卡片保持原始 MIME 进入既有附件队列")
    contact_block = activity[
        activity.index("private static boolean isContactDocumentMime("):
        activity.index("private static boolean isSharedAttachmentMime(")
    ]
    check("ContactsContract" not in contact_block
          and "query(" not in contact_block
          and "parse" not in contact_block,
          "不读取通讯录、不解析联系人、不导入联系人")
    check("queueSharedAttachment(attachment, type)" in activity
          and "MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "沿用单个 16 MB、一次最多 6 个的附件上限")
    check("sendButton.onclick" in media
          and "stageFiles([new File([bytes]" in media,
          "分享内容只进入待发送区，仍需用户点发送")

    check(APK.is_file(), "交付 APK 已生成")
    if APK.is_file():
        with zipfile.ZipFile(APK) as archive:
            dex = b"".join(
                archive.read(name)
                for name in archive.namelist()
                if name.endswith(".dex")
            )
        for symbol in (
            "text/x-vcard",
            "text/directory",
            "isContactDocumentMime",
        ):
            check(symbol.encode() in dex, f"APK/DEX 包含 {symbol}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
