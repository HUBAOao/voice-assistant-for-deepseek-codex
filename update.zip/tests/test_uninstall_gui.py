# -*- coding: utf-8 -*-
"""验收卸载程序的窗口：能弹出来、标题对、截个图，然后关掉。"""
from __future__ import annotations

import ctypes
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

from PIL import Image

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "uninstall-gui"
S.mkdir(parents=True, exist_ok=True)
OUT = ROOT / "outputs" / "卸载程序.png"
TITLE = "卸载语音助手"

u32, g32 = ctypes.windll.user32, ctypes.windll.gdi32
u32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


def find_window(title: str) -> int:
    found = []
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _l):
        if not u32.IsWindowVisible(hwnd):
            return True
        buf = ctypes.create_unicode_buffer(256)
        u32.GetWindowTextW(hwnd, buf, 256)
        if buf.value == title:
            found.append(hwnd)
            return False
        return True

    u32.EnumWindows(proc(cb), None)
    return found[0] if found else 0


def grab(hwnd: int, out: Path) -> tuple[int, int]:
    rect = wintypes.RECT()
    u32.GetWindowRect(hwnd, ctypes.byref(rect))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    hdc = u32.GetWindowDC(hwnd)
    memdc = g32.CreateCompatibleDC(hdc)
    bmp = g32.CreateCompatibleBitmap(hdc, w, h)
    g32.SelectObject(memdc, bmp)
    u32.PrintWindow(hwnd, memdc, 2)
    hdr = BITMAPINFOHEADER()
    hdr.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    hdr.biWidth, hdr.biHeight = w, -h
    hdr.biPlanes, hdr.biBitCount = 1, 32
    buf = ctypes.create_string_buffer(w * h * 4)
    g32.GetDIBits(memdc, bmp, 0, h, buf, ctypes.byref(hdr), 0)
    Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB").save(out)
    g32.DeleteObject(bmp)
    g32.DeleteDC(memdc)
    u32.ReleaseDC(hwnd, hdc)
    return w, h


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sandbox = S / "app"
    (sandbox / ".venv" / "Scripts").mkdir(parents=True, exist_ok=True)
    (sandbox / "stt.py").write_text("x", encoding="utf-8")
    (sandbox / "overlay.py").write_text("y", encoding="utf-8")
    (sandbox / "version.py").write_text("z", encoding="utf-8")

    py = APP / ".venv" / "Scripts" / "pythonw.exe"
    proc = subprocess.Popen([str(py), str(APP / "uninstall.py"),
                             "--appdir", str(sandbox)], cwd=str(S))
    hwnd = 0
    for _ in range(40):
        time.sleep(0.5)
        hwnd = find_window(TITLE)
        if hwnd:
            break
    if not hwnd:
        proc.kill()
        print("  ✗ 卸载窗口没弹出来")
        return 1
    print(f"  ✓ 窗口弹出来了：标题「{TITLE}」 hwnd={hwnd}")
    time.sleep(1.0)
    w, h = grab(hwnd, OUT)
    print(f"  ✓ 截图存到 {OUT}（{w}x{h}）")
    proc.kill()
    time.sleep(0.5)
    print("  ✓ 窗口已关掉（这次没真卸，只是看界面）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
