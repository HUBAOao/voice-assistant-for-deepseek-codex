# -*- coding: utf-8 -*-
"""Live configuration and foreground controls keep historical behavior."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from voice_feature.runtime_config_assembly import (  # noqa: E402
    ConfigRuntime,
    ConfigRuntimeDependencies,
)
from voice_feature.runtime_control_assembly import (  # noqa: E402
    ControlRuntime,
    ControlRuntimeDependencies,
)


class Status:
    def __init__(self) -> None:
        self.values = []

    def set(self, state, **kwargs) -> None:
        self.values.append((state, kwargs))


class Levels:
    def params(self, _config):
        return "标准", {
            "min_voiced": 3,
            "noise_mult": 1.4,
            "confirm": 2,
            "hotwords": True,
        }

    def describe(self, _params):
        return "反应稳定"


class Recorder:
    sr = 16000
    blocksize = 1600
    min_voiced_blocks = 0
    noise_mult = 0
    confirm = 0


class Lifecycle:
    def __init__(self) -> None:
        self.jobs = []

    def start_daemon(self, name, target):
        self.jobs.append((name, target))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        config_file = root / "config.json"
        config_file.write_text("{}", encoding="utf-8")
        config = {}
        wake_words = ["旧词"]
        cancel_words = []
        music = {"on": False}
        pet_proc = {"p": None}
        status = Status()
        lifecycle = Lifecycle()
        spoke = []
        emitted = []
        started_pet = []

        def fake_pet():
            proc = SimpleNamespace(poll=lambda: None)
            started_pet.append(proc)
            return proc

        config_runtime = ConfigRuntime(
            ConfigRuntimeDependencies(
                args=SimpleNamespace(
                    immediate=False,
                    no_overlay=False,
                    feed=None,
                    test_paste=False,
                ),
                config=config,
                config_file=config_file,
                load_config=lambda: {
                    "wake_word": "新词,备用词",
                    "cancel_word": "取消",
                    "wave_spectrum": True,
                    "pet_enabled": True,
                },
                mode="talk",
                wake_words=wake_words,
                cancel_words=cancel_words,
                wake_levels=Levels(),
                level={
                    "min_voiced": 1,
                    "noise_mult": 1,
                    "confirm": 1,
                    "hotwords": False,
                },
                recorder=Recorder(),
                music=music,
                pet_proc=pet_proc,
                start_pet=fake_pet,
                transcriber=SimpleNamespace(hotwords=""),
                status=status,
                wake_test_file=root / "wake_test.json",
                wake_selftest=lambda _t, _c: {
                    "summary": "自检通过",
                    "cases": [
                        {
                            "wake": "新词",
                            "noise": 0.1,
                            "gain": 1.0,
                            "text": "新词",
                            "hit": True,
                        }
                    ],
                },
                speak=spoke.append,
                runtime_lifecycle=lifecycle,
                emit=emitted.append,
            )
        )
        config_runtime.reload_wake_settings()
        check(wake_words == ["新词", "备用词"]
              and cancel_words == ["取消"],
              "唤醒词与取消词热加载保持原顺序")
        check(config["wake_word"] == "新词,备用词"
              and music["on"] is True,
              "同一份配置对象被更新且音浪开关立即生效")
        check(pet_proc["p"] is not None and len(started_pet) == 1,
              "桌宠配置开启时只拉起一个进程")
        config_runtime.start_wake_test()
        config_runtime.start_wake_test()
        check(len(lifecycle.jobs) == 1
              and lifecycle.jobs[0][0] == "wake-self-test",
              "唤醒自检在运行中不会重复排队")
        lifecycle.jobs[0][1]()
        check((root / "wake_test.json").exists()
              and spoke == ["自检通过"],
              "自检结果落盘、朗读并恢复空闲状态")

        pause = {"paused": False}
        mute = {"on": False}
        editing = {"on": False}
        hotkey = {"prev": False}
        beeps = []
        reads = []
        config_file.write_text('{"muted": false}', encoding="utf-8")

        def load_control_config():
            return __import__("json").loads(
                config_file.read_text(encoding="utf-8")
            )

        def write_config_file(data):
            config_file.write_text(__import__("json").dumps(data),
                                   encoding="utf-8")

        control = ControlRuntime(
            ControlRuntimeDependencies(
                args=SimpleNamespace(pause_key="-"),
                config={"read_hotkey": True},
                config_file=config_file,
                load_config=load_control_config,
                wake_words=wake_words,
                pause=pause,
                mute=mute,
                status=status,
                editing=editing,
                hotkey=hotkey,
                syslog=lambda *_args: None,
                beep=lambda freq, ms: beeps.append((freq, ms)),
                shut_up=lambda: None,
                runtime_lifecycle=lifecycle,
                do_export=lambda: None,
                do_import=lambda: None,
                do_diagnose=lambda: None,
                restart_program=lambda: None,
                start_wake_test=lambda _why="": None,
                read_selected=lambda: reads.append("read"),
                manual_exit=root / "manual-exit.json",
                emit=lambda _text: None,
                key_down=lambda _key: True,
            )
        )
        status.values.clear()
        control.set_paused(True, "测试")
        control.set_paused(False)
        check(not pause["paused"]
              and beeps == [(520, 90), (880, 90)]
              and status.values[0][0] == "paused",
              "暂停、恢复和提示音保持原顺序")
        control.check_hotkey()
        control.check_hotkey()
        check(reads == ["read"] and hotkey["prev"] is True,
              "Ctrl+Alt+R 只在按下边沿触发一次")
        control.remote_action("toggle-mute")
        saved = __import__("json").loads(
            config_file.read_text(encoding="utf-8")
        )
        check(mute["on"] is True and saved["muted"] is True,
              "悬浮窗静音同时更新配置")
        control.remote_action("editing-on")
        control.remote_action("editing-off")
        check(editing["on"] is False,
              "设置编辑闸门仍可正常进入和退出")

    stt = (APP / "stt.py").read_text(encoding="utf-8")
    check("def set_paused(" not in stt
          and "def reload_wake_settings(" not in stt
          and "def remote_action(" not in stt,
          "主流程不再内联暂停、热加载和悬浮窗控制业务")
    check("config_runtime = ConfigRuntime(" in stt
          and "services = assemble_runtime_services(" in stt
          and "control_runtime = services.control_runtime" in stt,
          "main() 只消费两份准备完成的前台运行时")
    check(
        stt.index("pause = phone.pause")
        < stt.index("control_runtime = services.control_runtime"),
        "手机暂停状态先初始化，再从统一装配取得前台控制运行时",
    )

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
