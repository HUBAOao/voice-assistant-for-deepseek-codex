# -*- coding: utf-8 -*-
"""试跑唤醒档位定义 + 唤醒词自检，看几档的差别和结论对不对。"""
from __future__ import annotations

import sys

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")

import wake_levels  # noqa: E402
from stt import Transcriber, wake_selftest  # noqa: E402


def test_levels() -> None:
    print("=== 档位解析 ===")
    cfg = {"wake_level": "宽松"}
    name, p = wake_levels.params(cfg)
    print(f"默认档：{name} → {wake_levels.describe(p)}")
    text = wake_levels.to_text(name, p)
    print("编辑框内容：\n" + text)
    got = wake_levels.from_text(text.replace("名称=宽松", "名称=我的档"))
    print("解析回来：", got)
    cfg2 = {"wake_level": "我的档", "wake_levels": dict([got])}
    n2, p2 = wake_levels.params(cfg2)
    print(f"自定义档：{n2} → {wake_levels.describe(p2)}")
    print("档位列表：", list(wake_levels.merged(cfg2["wake_levels"])))
    print("错误格式：", wake_levels.from_text("乱写的") , wake_levels.from_text("最小发声=0.3"))


def main() -> int:
    test_levels()
    print("\n=== 唤醒词自检（档位 宽松）===")
    tr = Transcriber("large-v3-turbo", "cuda", None, "zh", hotwords="大肥鱼")
    cfg = {"wake_word": "大肥鱼,喂喂", "cancel_word": "取消",
           "voice": "zh-CN-XiaoyiNeural", "rate": "+8%", "wake_level": "宽松"}
    result = wake_selftest(tr, cfg)
    print("\n结论：", result["summary"])
    print("通过：", result["passed"], "/", result["total"])
    for c in result["cases"]:
        print(f"  · {c['wake']} 噪声{c['noise']:g} 音量{c['gain']:g} "
              f"接住={c['captured']} 识别={c['text']!r} 命中={c['hit']}")
    return 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
