# -*- coding: utf-8 -*-
"""Settings window shell is constructible without showing a real window."""
from __future__ import annotations

import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_mixin import OverlaySettingsMixin  # noqa: E402
from overlay_feature.settings_navigation_mixin import (  # noqa: E402
    OverlaySettingsNavigationMixin,
)
from overlay_feature.settings_shell_mixin import (  # noqa: E402
    OverlaySettingsShellMixin,
)


class Widget:
    def __init__(self, _parent=None, **options) -> None:
        self.options = options
        self.children: list[Widget] = []
        self.binds: list[str] = []

    def pack(self, **_options) -> None:
        pass

    def bind(self, event: str, _callback) -> None:
        self.binds.append(event)

    def create_window(self, *_args, **_options) -> str:
        return "inner"

    def configure(self, **_options) -> None:
        pass

    def attributes(self, *_args) -> None:
        pass

    def overrideredirect(self, _value) -> None:
        pass

    def withdraw(self) -> None:
        pass


class Canvas(Widget):
    pass


class Toplevel(Widget):
    pass


class Probe(OverlaySettingsShellMixin):
    def __init__(self) -> None:
        self.panel_win = None
        self.root = object()
        self.button_color = "#3ddc84"
        self.built: list[tuple[str, object]] = []
        self.tabs: list[str] = []
        self.labels: list[str] = []

    def show_tab(self, name: str) -> None:
        self.tabs.append(name)

    def _on_stage_resize(self, _event) -> None:
        pass

    def _on_stage_inner(self) -> None:
        pass

    def build_basic(self, parent) -> None:
        self.built.append(("basic", parent))

    def build_sound(self, parent) -> None:
        self.built.append(("sound", parent))

    def build_look(self, parent) -> None:
        self.built.append(("look", parent))

    def build_smart(self, parent, more) -> None:
        self.built.append(("smart", parent))
        self.built.append(("features", more))

    def build_schedule(self, parent) -> None:
        self.built.append(("schedule", parent))

    def save_settings(self) -> None:
        pass

    def reset_defaults(self) -> None:
        pass

    def show_about(self) -> None:
        pass

    def check_update(self) -> None:
        pass

    def publish_site(self) -> None:
        pass

    def _bind_wheel_tree(self, _inner) -> None:
        pass


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    fake_tk = types.SimpleNamespace(
        Toplevel=Toplevel,
        Frame=Widget,
        Label=Widget,
        Canvas=Canvas,
    )
    original = sys.modules.get("tkinter")
    sys.modules["tkinter"] = fake_tk
    try:
        probe = Probe()
        probe.tk = fake_tk
        probe.build_panel()
    finally:
        if original is None:
            sys.modules.pop("tkinter", None)
        else:
            sys.modules["tkinter"] = original

    check(isinstance(probe.panel_win, Toplevel),
          "外壳仍创建独立设置窗口，不改主悬浮窗尺寸")
    check(probe.tab_names == ["基本", "声音", "外观", "智能", "功能", "日程"],
          "六个原有页签和顺序保持不变")
    check(sorted(probe.tab_frames) == sorted(probe.tab_names),
          "每个页签仍有独立业务帧")
    check([name for name, _parent in probe.built]
          == ["basic", "sound", "look", "smart", "features", "schedule"],
          "业务页按原有顺序装配，功能页仍与智能页组合")
    check(probe.tabs == ["基本"],
          "外壳构建结束时默认打开基本页")
    check(hasattr(probe, "upd_label") and hasattr(probe, "scroll_hint"),
          "更新状态和细滚动条入口保持兼容")
    check(issubclass(OverlaySettingsMixin, OverlaySettingsShellMixin)
          and issubclass(OverlaySettingsMixin, OverlaySettingsNavigationMixin),
          "历史 OverlaySettingsMixin 同时保留外壳与导航入口")

    shell = (APP / "overlay_feature" / "settings_mixin.py").read_text(
        encoding="utf-8"
    )
    installer = (
        APP / "overlay_feature" / "settings_shell_mixin.py"
    ).read_text(encoding="utf-8")
    check("def build_panel(" not in shell and "def build_panel(" in installer,
          "设置窗口构造已迁出业务组合入口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
