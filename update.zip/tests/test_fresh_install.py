# -*- coding: utf-8 -*-
"""模拟「别人下下来装」：把 zip 解到空目录，看每个自家模块在不在。

这是冲着真事故来的 —— 另一台电脑装了以后「有声音，但没窗口没悬浮窗」。
根因：stt.py 模块级别 import 的 remote_access / screen_share / file_share
压根没被打进 zip，一启动就 ModuleNotFoundError；pythonw 没控制台，用户什么都看不到。

这里不解压后真去 import stt（那会加载 torch，很慢），而是用 find_spec：
只问「这个模块找得到吗」，不执行它，够判定包里有没有。
"""
from __future__ import annotations

import importlib.util
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
SRC = ROOT / "outputs" / "voice-to-text"
ZIP = ROOT / "outputs" / "语音助手-安装包.zip"
DEST = ROOT / "work" / "fresh-install"

# 只在本机用的（语音克隆），本来就故意不进包
MAYBE = {"clone_voice"}


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    if DEST.exists():
        shutil.rmtree(DEST, ignore_errors=True)
    DEST.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ZIP) as z:
        z.extractall(DEST)
    print("① 解压到空目录（模拟全新一台电脑）")
    check((DEST / "stt.py").exists(), "zip 解出来的目录里有 stt.py")
    check((DEST / "1-安装语音助手.cmd").exists(), "有安装入口 1-安装语音助手.cmd")
    check((DEST / "setup.py").exists(), "有 setup.py")

    print("② 自家模块全都找得到（find_spec，不执行模块本身）")
    mine = sorted({p.stem for p in SRC.glob("*.py")} - MAYBE)
    sys.path.insert(0, str(DEST))
    missing = []
    for name in mine:
        try:
            spec = importlib.util.find_spec(name)
        except Exception:                            # noqa: BLE001
            spec = None
        if spec is None:
            missing.append(name)
    check(not missing, "自家模块 %d 个全都在包里" % len(mine)
          if not missing else "找不到：%s" % ", ".join(missing))

    print("③ 一启动就要用的那几个导入，一个都不能少")
    for name in ("remote_access", "screen_share", "file_share", "phone_link",
                 "version", "reply_reader", "wake_levels", "ui_widgets",
                 "schedule_panel", "self_update", "site_publish", "download_page",
                 "qr_tools", "codex_threads", "pet", "tray"):
        check((DEST / (name + ".py")).exists(), "包里有 %s.py" % name)

    print("④ 个人 / 本机的东西别混进去")
    for junk in ("clone_voice.py", ".venv", "models", "download-stats.json"):
        check(not list(DEST.rglob(junk)), "解出来的目录里没有 %s" % junk)

    sys.path.remove(str(DEST))
    print("\n不通过的用例数 = %d" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
