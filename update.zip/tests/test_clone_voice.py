# -*- coding: utf-8 -*-
"""验收语音克隆：拿 edge-tts 念一句 → RVC 转成高松灯的声音。

跑这个之前得先有：
  * F:\voice-clone\env（torch cu124 + transformers + librosa + faiss + rmvpe…）
  * F:\voice-clone\rvc-src（RVC 官方仓库，assets 下摆好 hubert/rmvpe/tomori）
"""
from __future__ import annotations

import subprocess
import sys
import time
import os
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
CLONE = Path(r"F:\voice-clone")
OUT = ROOT / "work" / "clone-test"
PY = CLONE / "env" / "Scripts" / "python.exe"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    OUT.mkdir(parents=True, exist_ok=True)
    src = OUT / "in.mp3"
    dst = OUT / "out.wav"

    print("① 先合成一句普通话当素材（edge-tts）")
    if not src.exists():
        code = subprocess.run(
            [str(APP / ".venv" / "Scripts" / "python.exe"), "-c",
             "import sys; sys.path.insert(0, r'%s'); import say;"
             "open(r'%s','wb').write(say.edge_mp3("
             "'你好呀，我是大肥鱼，以后就用这个声音跟你说话。','zh-CN-XiaoyiNeural','+8%%'))"
             % (APP, src)],
            capture_output=True, text=True, timeout=180)
        if code.returncode != 0:
            print(code.stdout[-800:], code.stderr[-800:])
    check(src.exists() and src.stat().st_size > 2000,
          f"素材好了 {src.stat().st_size / 1024:.0f} KB" if src.exists() else "素材没出来")

    print("② 用 RVC 把它转成 tomori（高松灯）的声音")
    t0 = time.time()
    env = dict(os.environ)
    env["PYTHONPATH"] = str(CLONE / "rvc-src")      # cli.py 要能 import infer.*
    run = subprocess.run(
        [str(PY), str(CLONE / "rvc-src" / "infer" / "cli.py"),
         "--model", "tomori.pth", "--input", str(src), "--output", str(dst),
         "--f0-method", "rmvpe", "--index-rate", "0.75", "--overwrite"],
        cwd=str(CLONE / "rvc-src"), capture_output=True, text=True,
        encoding="utf-8", errors="replace", timeout=1800, env=env)
    took = time.time() - t0
    tail = (run.stdout or "")[-1500:]
    print("     耗时 %.1f 秒，返回码 %s" % (took, run.returncode))
    if run.returncode != 0:
        print(tail)
        print((run.stderr or "")[-1500:])
    check(run.returncode == 0, "转换跑通了")
    check(dst.exists() and dst.stat().st_size > 10000,
          f"出音了 {dst.stat().st_size / 1024:.0f} KB" if dst.exists() else "没有输出文件")

    print("③ 听一下像不像人声（看频谱，不看嘴）")
    if dst.exists():
        import wave
        import struct
        import math

        with wave.open(str(dst), "rb") as w:
            sr, n = w.getframerate(), w.getnframes()
            raw = w.readframes(n)
        data = struct.unpack("<%dh" % (len(raw) // 2), raw)
        rms = math.sqrt(sum(v * v for v in data) / max(1, len(data))) / 32768
        peak = max(abs(v) for v in data) / 32768 if data else 0
        print(f"     {sr} Hz，{n / sr:.1f} 秒，RMS {rms:.3f}，峰值 {peak:.3f}")
        check(0.01 < rms < 0.6, "音量像正常说话（不是静音也不是爆音）")
        check(n / sr > 0.8, "长度跟原句对得上")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
