# -*- coding: utf-8 -*-
"""Settings navigation is testable without constructing a Tk window."""
from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.settings_mixin import OverlaySettingsMixin  # noqa: E402
from overlay_feature.settings_navigation_mixin import (  # noqa: E402
    OverlaySettingsNavigationMixin,
)


class LabelProbe:
    def __init__(self) -> None:
        self.options = {}

    def config(self, **options) -> None:
        self.options.update(options)


class FrameProbe:
    def __init__(self) -> None:
        self.packed = False

    def pack(self, **_options) -> None:
        self.packed = True

    def pack_forget(self) -> None:
        self.packed = False


class BarProbe:
    def __init__(self) -> None:
        self.shown = False
        self.rect = None

    def place_forget(self) -> None:
        self.shown = False

    def delete(self, _tag) -> None:
        self.rect = None

    def create_rectangle(self, *values, **options) -> None:
        self.rect = (values, options)

    def place(self, **_options) -> None:
        self.shown = True


class StageProbe:
    def __init__(self, content_height=500, view_height=200) -> None:
        self.content_height = content_height
        self.view_height = view_height
        self.scrolls = []
        self.moves = []
        self.region_set = None
        self.width = None

    def bbox(self, _tag):
        return (0, 0, 300, self.content_height)

    def winfo_height(self):
        return self.view_height

    def yview(self):
        return (0.0, 0.25)

    def yview_scroll(self, amount, unit):
        self.scrolls.append((amount, unit))

    def yview_moveto(self, value):
        self.moves.append(value)

    def winfo_y(self):
        return 30

    def configure(self, **options):
        self.region_set = options

    def itemconfig(self, _item, **options):
        self.width = options.get("width")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Probe(OverlaySettingsNavigationMixin):
        def __init__(self) -> None:
            self.stage = self.stage_canvas = StageProbe()
            self.scroll_hint = BarProbe()
            self._stage_win = "inner"
            self.button_color = "#3ddc84"
            self.root = SimpleNamespace(after=lambda _ms, fn: fn())
            self.expanded = True
            self.placed = []
            self.remote_refresh = 0
            self.remote_label = object()
            self.tab_frames = {"基本": FrameProbe(), "智能": FrameProbe()}
            self.tab_labels = {"基本": LabelProbe(), "智能": LabelProbe()}

        def _place_panel(self, height):
            self.placed.append(height)

        def _expanded_h(self):
            return 640

        def refresh_remote(self):
            self.remote_refresh += 1

    probe = Probe()
    probe._on_stage_resize(SimpleNamespace(width=390))
    probe._on_stage_inner()
    check(probe.stage.width == 390, "画布宽度随视口变化")
    check(probe.stage.region_set == {
        "scrollregion": (0, 0, 300, 500)
    }, "内容高度写入滚动区域")
    check(probe.scroll_hint.shown, "内容超过视口时显示细滚动条")

    event = SimpleNamespace(delta=-120)
    result = probe.on_panel_wheel(event)
    check(result == "break" and probe.stage.scrolls == [(1, "units")],
          "向下滚轮只滚动设置内容")
    probe.stage.view_height = 600
    check(probe.on_panel_wheel(SimpleNamespace(delta=120)) is None,
          "内容装得下时不抢浮窗透明度滚轮")

    probe.tab_frames["基本"].packed = True
    probe.show_tab("智能")
    check(not probe.tab_frames["基本"].packed
          and probe.tab_frames["智能"].packed,
          "切换页签只显示目标业务页")
    check(probe.stage.moves == [0.0], "切换页签回到内容顶部")
    check(probe.tab_labels["智能"].options["fg"] == "#ffffff"
          and probe.tab_labels["基本"].options["fg"] == "#9a9aa5",
          "当前页签高亮和旧样式一致")
    check(probe.placed == [640], "展开状态切页仍保持固定高度")
    check(probe.remote_refresh == 1, "进入智能页仍触发后台外网刷新")

    shell = (APP / "overlay_feature" / "settings_mixin.py").read_text(
        encoding="utf-8"
    )
    navigation = (
        APP / "overlay_feature" / "settings_navigation_mixin.py"
    ).read_text(encoding="utf-8")
    check(issubclass(OverlaySettingsMixin, OverlaySettingsNavigationMixin),
          "历史 OverlaySettingsMixin 入口保持兼容")
    check("def show_tab(" not in shell and "def show_tab(" in navigation,
          "页签与滚屏业务已迁出设置构造外壳")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
