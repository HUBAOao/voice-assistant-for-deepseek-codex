# -*- coding: utf-8 -*-
"""QR presentation helpers keep popup rendering out of the settings mixin."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature.qr_presentation import (  # noqa: E402
    display_qr_image,
    save_qr_image,
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    url = "http://192.168.1.4:8765/?k=presentation-test"
    image = display_qr_image(url, max_pixels=264)
    check(image.width >= 180 and image.height >= 180,
          f"展示图至少 180 像素（{image.width}x{image.height}）")
    check(image.width == image.height,
          "展示图保持正方形")
    with tempfile.TemporaryDirectory() as raw:
        target = Path(raw) / "qr.png"
        saved = save_qr_image(url, target)
        check(saved == target and target.is_file() and target.stat().st_size > 800,
              "高分辨率另存文件真实落盘")

    mixin = (
        APP / "overlay_feature" / "settings_qr_mixin.py"
    ).read_text(encoding="utf-8")
    helper = (
        APP / "overlay_feature" / "qr_presentation.py"
    ).read_text(encoding="utf-8")
    save_dialog = (
        APP / "overlay_feature" / "qr_save_dialog.py"
    ).read_text(encoding="utf-8")
    check("display_qr_image(url)" in mixin
          and "save_qr_with_dialog(win, url, self.flash)" in mixin,
          "设置窗口只调用独立展示与保存接口")
    check("Image.NEAREST" not in mixin
          and "qr_tools.qr_image(" not in mixin,
          "缩放和画码细节已移出设置窗口")
    check("qr_tools.qr_image(" in helper and "Image.NEAREST" in helper,
          "画码细节集中在新表现模块")
    check("filedialog.asksaveasfilename(" in save_dialog
          and "save_qr_image(url, path)" in save_dialog,
          "另存对话框和文件写入迁出设置窗口")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
