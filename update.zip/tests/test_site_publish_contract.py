# -*- coding: utf-8 -*-
"""Every publish() exit reports (ok, reason, pushed)."""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"


def main() -> int:
    tree = ast.parse(
        (APP / "site_publish.py").read_text(encoding="utf-8")
    )
    publish = next(
        node for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "publish"
    )
    returns = [
        node for node in ast.walk(publish) if isinstance(node, ast.Return)
    ]
    shapes = []
    for node in returns:
        value = node.value
        size = len(value.elts) if isinstance(value, ast.Tuple) else -1
        shapes.append((node.lineno, size))
    assert returns
    assert all(size == 3 for _line, size in shapes), shapes
    print("test_site_publish_contract: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
