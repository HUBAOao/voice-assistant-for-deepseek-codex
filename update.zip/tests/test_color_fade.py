# -*- coding: utf-8 -*-
"""验证悬浮窗声音条的颜色切换过渡：说话/不说话之间是渐变而不是硬切。

做法：真的把 Overlay 建出来跑帧循环，用脚本化的「说话状态」驱动，
逐帧打印 _wave_rgb，量出过渡需要多少帧、多少毫秒、中途是不是混合色。
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import overlay  # noqa: E402

SCRATCH = ROOT / "work" / "color-fade-scratch"
SCRATCH.mkdir(parents=True, exist_ok=True)
(SCRATCH / "config.json").write_text(
    json.dumps({"name": "颜色测试", "overlay_width": 344, "overlay_height": 112,
                "overlay_accent": "#3ddc84", "overlay_talk_color": "#4aa3ff",
                "overlay_bg_image": "", "overlay_alpha": 0.99,
                "anim_fps": 60, "perf_mode": "quality"}, ensure_ascii=False),
    encoding="utf-8")
(SCRATCH / "pos.json").write_text('{"x": 120, "y": 120}', encoding="utf-8")

overlay.CONFIG = SCRATCH / "config.json"
overlay.POS = SCRATCH / "pos.json"
overlay.EXIT_LOG = SCRATCH / "exit.log"
overlay.note = lambda text: None


def run() -> int:
    state = {"active": False, "level": 0.0}
    o = overlay.Overlay()
    # read_speaking 现在返回 (在念吗, 音量, 正在念的句子, 念到哪了)
    o.read_speaking = lambda: (state["active"], state["level"], "", 0.0)

    frames: list[tuple[bool, tuple]] = []
    okay_anim = o.anim

    def anim_probe() -> None:
        okay_anim()
        if getattr(o, "_wave_rgb", None) is not None:
            frames.append((state["active"], tuple(o._wave_rgb)))

    o.anim = anim_probe

    def pump(seconds: float) -> None:
        end = time.time() + seconds
        while time.time() < end:
            o.root.update()
            time.sleep(0.004)

    pump(0.6)                       # 冷启动，颜色稳定在"不说话"色
    base = frames[-1][1]
    print("静默稳定色 :", tuple(round(c) for c in base))

    frames.clear()
    state["active"] = True          # ← 开始"说话"，蓝色
    state["level"] = 0.62
    pump(0.6)
    up = [c for _a, c in frames]
    print("\n[静默→说话] 逐帧颜色：")
    for i, c in enumerate(up[:26]):
        print(f"  第{i + 1:2d}帧  rgb({c[0]:6.1f},{c[1]:6.1f},{c[2]:6.1f})")
    target = tuple(overlay.rgb("#4aa3ff"))
    reach = next((i for i, c in enumerate(up)
                  if max(abs(c[k] - target[k]) for k in range(3)) <= 2.0), None)
    span = (reach + 1) * 16 if reach is not None else None
    print(f"  目标色 rgb{target}；第 {reach + 1 if reach is not None else '-'} 帧进入 ±2 范围"
          f"（约 {span} ms）")

    frames.clear()
    state["active"] = False
    state["level"] = 0.0
    pump(0.6)
    down = [c for _a, c in frames]
    print("\n[说话→静默] 逐帧颜色（前 12 帧）：")
    for i, c in enumerate(down[:12]):
        print(f"  第{i + 1:2d}帧  rgb({c[0]:6.1f},{c[1]:6.1f},{c[2]:6.1f})")
    back = tuple(overlay.rgb("#3ddc84"))
    reach2 = next((i for i, c in enumerate(down)
                   if max(abs(c[k] - back[k]) for k in range(3)) <= 2.0), None)
    print(f"  目标色 rgb{back}；第 {reach2 + 1 if reach2 is not None else '-'} 帧回到 ±2 范围")

    biggest = max((max(abs(up[i][k] - up[i - 1][k]) for k in range(3))
                   for i in range(1, min(len(up), 30))), default=0.0)
    print(f"\n相邻帧最大跳变 = {biggest:.1f} / 255 （越小越顺滑；硬切会是 ~150+）")
    o.root.destroy()
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
