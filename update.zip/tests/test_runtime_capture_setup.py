# -*- coding: utf-8 -*-
"""Capture and input assembly stay deterministic outside ``main()``."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

import voice_feature.runtime_capture_setup as capture_setup  # noqa: E402
from voice_feature.runtime_capture_setup import (  # noqa: E402
    CaptureRuntimeDependencies,
    prepare_capture_runtime,
)


class Args:
    key = "*"
    pause_key = "-"
    target = ""


class Microphone:
    recorder = "primary-recorder"
    rate = 16000

    def safe_calibrate(self):
        return "calibrated"

    def safe_record(self):
        return "recorded"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    captured: dict[str, object] = {}
    microphone = Microphone()

    def fake_capture(deps):
        captured["talk"] = deps
        return "captured-audio"

    class FakeInputResult:
        audio_loop = "audio-loop"
        checked_pause = "checked-pause"
        tracker_worker = "tracker-worker"

    def fake_prepare_input(deps):
        captured["input"] = deps
        return FakeInputResult()

    original_capture = capture_setup.capture_talk_utterance
    original_input = capture_setup.prepare_input_runtime
    try:
        capture_setup.capture_talk_utterance = fake_capture
        capture_setup.prepare_input_runtime = fake_prepare_input
        deps = CaptureRuntimeDependencies(
            mode="talk",
            args=Args(),
            tracker=object(),
            wake_words=["大肥鱼"],
            cancel_words=["取消"],
            silence=1.2,
            runtime_lifecycle=object(),
            pause={"paused": False, "prev": False},
            set_paused=lambda value, why: None,
            runtime_tick=lambda: False,
            remote=object(),
            handle_lock=object(),
            handle_audio=lambda *args, **kwargs: False,
            status=object(),
            microphone=microphone,
            key_watcher_factory=lambda key: key,
            tracker_worker_factory=lambda tracker: tracker,
            find_window=lambda target: (0, ""),
            record_ptt=lambda recorder: recorder,
            has_utterance=lambda audio, rate: True,
            on_level=lambda value: None,
            on_hold_start=lambda: None,
            on_hold_stop=lambda: None,
            on_speech=lambda: None,
            before_fallback_capture=lambda: None,
            cfg={"name": "鳍舱"},
            self_speech={"until": 2.0},
            music={"until": 3.0},
            spoken_flag={"first": False},
            syslog=lambda tag, text: None,
            shut_up=lambda: None,
            speaking_now=lambda: False,
            duplex={"on": True},
            cancel_reference_echo=lambda audio, rate: audio,
            spectrum_bands=lambda *args, **kwargs: [1.0],
            transcriber=object(),
            hint="说「大肥鱼」唤醒",
        )
        result = prepare_capture_runtime(deps)
        input_deps = captured["input"]
        capture_talk = input_deps.capture_talk_factory(input_deps.pause)
        check(capture_talk() == "captured-audio",
              "输入运行时的采集闭包仍接到 talk 主链路")
        talk_deps = captured["talk"]
        check(talk_deps.recorder == "primary-recorder"
              and talk_deps.rate == 16000,
              "talk 采集读取当前麦克风录音器与采样率")
        check(talk_deps.wake_enabled is True
              and talk_deps.checked_pause is input_deps.pause,
              "唤醒词门槛与暂停检查原样传递")
        check(talk_deps.safe_calibrate() == "calibrated"
              and talk_deps.safe_record() == "recorded",
              "掉线恢复后的安全校准与录音入口保持")
        check(result.audio_loop == "audio-loop"
              and result.checked_pause == "checked-pause"
              and result.tracker_worker == "tracker-worker"
              and result.microphone is microphone,
              "结果对象返回录音循环、暂停判定、追踪器和当前麦克风")
    finally:
        capture_setup.capture_talk_utterance = original_capture
        capture_setup.prepare_input_runtime = original_input

    source = (APP / "stt.py").read_text(encoding="utf-8")
    module = (APP / "voice_feature" / "runtime_capture_setup.py").read_text(
        encoding="utf-8"
    )
    check("prepare_capture_runtime(" in source
          and "TalkCaptureDependencies(" not in source
          and "InputRuntimeDependencies(" not in source,
          "main() 不再内联 talk 与输入运行时装配")
    check("TalkCaptureDependencies(" in module
          and "InputRuntimeDependencies(" in module,
          "两个依赖图由同一采集会话边界组装")
    check(source.index("capture_runtime = prepare_capture_runtime(")
          < source.index("register_shutdown_resources("),
          "退出资源仍在输入运行时提供追踪器之后登记")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
