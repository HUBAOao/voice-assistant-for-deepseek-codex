# -*- coding: utf-8 -*-
"""First-run onboarding is testable without opening the real settings panel."""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
sys.path.insert(0, str(APP))

from overlay_feature import settings_onboarding_mixin as onboarding  # noqa: E402
from overlay_feature.settings_onboarding_mixin import (  # noqa: E402
    OverlaySettingsOnboardingMixin,
)


class Widget:
    def __init__(self, events: list[str], name: str) -> None:
        self.events = events
        self.name = name

    def title(self, _text: str) -> None:
        self.events.append("title")

    def configure(self, **_options) -> None:
        self.events.append("configure")

    def attributes(self, *_args) -> None:
        self.events.append("attributes")

    def geometry(self, _value: str) -> None:
        self.events.append("geometry")

    def pack(self, **_options) -> None:
        self.events.append("label")

    def bind(self, _event: str, _callback) -> None:
        self.events.append("bind")

    def winfo_children(self):
        if self.name == "window":
            return [object(), self]
        return []

    def destroy(self) -> None:
        self.events.append("destroy")


class Tk:
    def __init__(self, events: list[str]) -> None:
        self.events = events

    def Toplevel(self, _root):
        return Widget(self.events, "window")

    def Label(self, _parent, **_options):
        return Widget(self.events, "label")


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    class Probe(OverlaySettingsOnboardingMixin):
        def __init__(self, events: list[str], rec_win=None) -> None:
            self.tk = Tk(events)
            self.root = object()
            self.cfg = {"wake_word": "大肥鱼"}
            self.button_color = "#3ddc84"
            self.rec_win = rec_win

    with tempfile.TemporaryDirectory(prefix="findeck_onboarding_") as raw:
        original = onboarding.HERE
        onboarding.HERE = Path(raw)
        try:
            events: list[str] = []
            probe = Probe(events, Widget(events, "rec"))
            probe.sync_rec_dot()
            check(probe.rec_win is None and "destroy" in events,
                  "已退役录音提示窗口仍会被兼容入口关闭")

            events.clear()
            probe.maybe_first_run()
            mark = Path(raw) / "first-run.done"
            check(mark.exists() and mark.read_text(encoding="utf-8") == "ok",
                  "首次引导只写一次完成标记")
            check(events.count("label") >= 7
                  and events.count("bind") == 1
                  and "geometry" in events,
                  "首次引导仍创建三步说明和唯一的关闭按钮")

            events.clear()
            probe.maybe_first_run()
            check(not events,
                  "看过首次引导后不会重复弹窗")
        finally:
            onboarding.HERE = original

    shell = (APP / "overlay_feature" / "settings_mixin.py").read_text(
        encoding="utf-8"
    )
    overlay = (APP / "overlay.py").read_text(encoding="utf-8")
    check("def maybe_first_run(" not in shell
          and "def sync_rec_dot(" not in shell,
          "首次引导和旧提示灯业务已迁出设置构造外壳")
    check("OverlaySettingsOnboardingMixin" in overlay
          and "self.root.after(1500, self.maybe_first_run)" in overlay,
          "浮窗仍通过原调用入口触发首次引导")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
