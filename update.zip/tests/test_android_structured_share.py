# -*- coding: utf-8 -*-
"""CSV/JSON shares enter the bounded draft tray, while VIEW stays text."""
from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "work" / "android-app" / "AndroidManifest.xml"
ACTIVITY = (
    ROOT / "work" / "android-app" / "java" / "com" / "hubao"
    / "voiceassistant" / "MainActivity.java"
)
MEDIA = (
    ROOT / "outputs" / "voice-to-text" / "phone_feature" / "ui"
    / "media.js"
)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = MANIFEST.read_text(encoding="utf-8")
    activity = ACTIVITY.read_text(encoding="utf-8")
    media = MEDIA.read_text(encoding="utf-8")

    for mime in ("text/csv", "application/json"):
        expected = 2 if mime == "text/csv" else 4
        check(manifest.count(f'android:mimeType="{mime}"') == expected,
              f"{mime} 新增分享并保留既有打开入口")
        check(mime in media, f"{mime} 页面入口与原生白名单一致")
    check(manifest.count('android:scheme="content" android:mimeType="text/*"') == 1
          and manifest.count('android:scheme="file" android:mimeType="text/*"') == 1,
          "CSV 的 content/file 打开继续由 text/* 通配入口覆盖")

    send_block = activity.split("if (Intent.ACTION_SEND.equals(action))", 1)[1]
    send_block = send_block.split("} else if (Intent.ACTION_PROCESS_TEXT", 1)[0]
    check(send_block.count("isSharedAttachmentMime(type)") == 2,
          "单张和多张分享都只使用扩展后的分享附件判定")
    check("isShareableAttachmentMime(type)" in activity
          and "isStructuredTextMime(type)" in activity
          and "CSV_DOCUMENT_MIME.equals(clean)" in activity
          and "JSON_DOCUMENT_MIME.equals(clean)" in activity,
          "CSV/JSON 只在分享入口扩展为文件，不改变普通附件白名单")
    check("} else if (isStructuredTextMime(mime)) {" in activity
          and "cleanMime = mime.trim().toLowerCase" in activity,
          "CSV/JSON MIME 原样进入附件队列")
    check("MAX_SHARED_FILE_BYTES" in activity
          and "MAX_SHARED_ATTACHMENTS" in activity,
          "沿用单个 16 MB、一次最多 6 个的附件上限")
    check("stageFiles([new File([bytes]" in media
          and "sendButton.onclick" in media,
          "CSV/JSON 只进入待发送托盘，等待用户点发送")
    check('Log.i("FinDeckShare",' in activity
          and '"native-read "' in activity
          and '"native-read-rejected "' in activity,
          "原生读取成功或拒绝都留下不含内容的回执")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
