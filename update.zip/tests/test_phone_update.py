# -*- coding: utf-8 -*-
"""验收「手机 APP 一键更新」：设置里那个常驻入口 + 真能装上的那条路。

以前用不了的原因有三条，这个测试就盯着这三条：
  ① 网页给的是**相对地址**（Uri.parse 打不开）→ 现在必须给绝对地址
  ② 以前只是把浏览器叫起来 → 现在是 APP 自己下载 + 拉起系统安装器
  ③ 安卓 8+ 要先允许「安装未知应用」→ 现在没权限会带用户去开，回来接着下
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
AND = ROOT / "work" / "android-app"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    page += "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((APP / "phone_feature" / "ui").glob("*.js"))
    )
    settings_js = (APP / "phone_feature" / "ui" / "settings.js").read_text(encoding="utf-8")
    management_js = (APP / "phone_feature" / "ui" / "management.js").read_text(
        encoding="utf-8")
    java = (AND / "java" / "com" / "hubao" / "voiceassistant"
            / "MainActivity.java").read_text(encoding="utf-8")
    diagnostics = (AND / "java" / "com" / "hubao" / "voiceassistant"
                   / "DeviceDiagnostics.java").read_text(encoding="utf-8")
    diagnostic_report = (AND / "java" / "com" / "hubao" / "voiceassistant"
                         / "DiagnosticReport.java").read_text(encoding="utf-8")
    device_diagnostics = (AND / "java" / "com" / "hubao" / "voiceassistant"
                          / "DeviceDiagnostics.java").read_text(encoding="utf-8")
    provider = (AND / "java" / "com" / "hubao" / "voiceassistant"
                / "UpdateProvider.java")
    man = (AND / "AndroidManifest.xml").read_text(encoding="utf-8")
    notify_service = (
        AND / "java" / "com" / "hubao" / "voiceassistant" / "NotifyService.java"
    ).read_text(encoding="utf-8")

    print("① 设置里那个常驻入口")
    check('id="updbtn"' in page and 'id="updnow"' in page,
          "设置面板里有「更新」那一行（状态文字 + 按钮）")
    check("function refreshUpdRow" in page, "有刷新那一行的函数")
    check("refreshUpdRow();" in page.split("async function checkUpdate")[-1],
          "页面一进来就会顺便把这一行刷新（不用你自己去找）")
    check('btn.textContent = "一键更新"' in page, "有新版时按钮变成「一键更新」")
    check("已经是最新" in page, "没新版时明说「已经是最新」")

    print("② 地址必须是绝对的（以前就是栽在这）")
    check("location.origin + \"/app.apk" in page,
          "下载地址用 location.origin 拼成绝对地址")
    check("absoluteUrl" in java, "Java 那边也会兜底把相对地址补全")
    check('Uri.parse(url)' not in java.split("openUpdate")[1][:400],
          "openUpdate 不再直接把地址丢给浏览器")

    print("③ APP 自己下载 + 拉起安装器")
    check("downloadAndInstall" in java, "有下载函数")
    check("HttpURLConnection" in java and "update.apk" in java,
          "自己把新版下到本机 update.apk")
    check("application/vnd.android.package-archive" in java,
          "下载完按 APK 类型交给系统")
    check("content://" in java and "UpdateProvider.AUTHORITY" in java,
          "用 content:// 递文件（安卓 7 以后不许用 file://）")
    check(provider.exists() and "extends ContentProvider" in
          (provider.read_text(encoding="utf-8") if provider.exists() else ""),
          "自带的迷你 FileProvider（UpdateProvider）在")
    check("canRequestPackageInstalls" in java
          and "ACTION_MANAGE_UNKNOWN_APP_SOURCES" in java,
          "安卓 8+ 会先检查/带你去开「安装未知应用」")
    check("protected void onResume" in java and "pendingUpdateUrl" in java,
          "开完权限回来会自动接着下")
    check("mainPageReady" in java
          and "onPageCommitVisible" in java
          and "if (!mainPageReady)" in java,
          "网络挂住时按主页面真实可见状态触发 12 秒连不上页")
    check("onPageFinished" in java
          and "mainPageReady && url != null" in java,
          "加载失败产生的 onPageFinished 不会误记最佳地址")
    check("chooseWorkingUrl" in notify_service
          and "routeReachable" in notify_service
          and '"url", "best_url", "lan_url", "remote_url"'
          in notify_service
          and "/api/version" in notify_service,
          "后台轮询不依赖页面事件，独立选择可达地址")
    check('SecurePrefs.getString(sp, key, "")' in notify_service
          and 'SecurePrefs.getString(sp, "va_dev_id", "")' in notify_service
          and "SecurePrefs.putString(sp, \"va_dev_id\", v)" in notify_service
          and 'sp.getString("url"' not in notify_service
          and 'putString("url"' not in notify_service,
          "后台地址和设备号使用与页面相同的 Keystore 加密存储")
    check("ByteArrayOutputStream received" in notify_service
          and "while ((n = is.read(buf)) > 0)" in notify_service
          and "4 * 1024 * 1024" in notify_service,
          "后台日志响应分段读完并限制 4 MB")
    check("onPageCommitVisible" in java
          and "setUrl(url);" in java.split("onPageCommitVisible", 1)[1][:900],
          "主页面连通后后台轮询同步使用实际成功地址")
    check("view.getTitle()" in java
          and "!title.contains(\"连不上电脑\")" in java
          and java.count("setUrl(url);") >= 2,
          "不回调页面可见事件时仍通过有效标题同步实际地址")
    timer_start = java.index("splashTimer = new Runnable()")
    timer_block = java[timer_start:].split(
        "final java.util.List<String> cands", 1
    )[0]
    check("web.getUrl()" in timer_block
          and "web.getTitle()" in timer_block
          and "setUrl(now);" in timer_block,
          "12 秒检查点直接校准已显示页面的实际地址")

    print("④ 清单里该有的东西")
    check("REQUEST_INSTALL_PACKAGES" in man, "有 REQUEST_INSTALL_PACKAGES 权限")
    check("android.permission.VIBRATE" in man, "有 VIBRATE 权限（震动失败不会崩）")
    check("com.hubao.voiceassistant.updates" in man and "<provider" in man,
          "provider 声明和代码里的 authority 对得上")

    print("⑤ 原生分享与系统能力")
    check('id="tishare"' in page and "shareCurrentConversation" in settings_js,
          "＋ 菜单有「分享对话」入口")
    for method in ("shareText", "copyText", "openExternal", "keepScreenOn", "haptic"):
        check(method in java, f"原生桥有 {method}()")
    check("ACTION_SEND" in java and "EXTRA_TEXT" in java,
          "分享走 Android 系统分享面板")
    check("android.intent.action.SEND" in man
          and 'android:mimeType="text/plain"' in man
          and 'android:launchMode="singleTop"' in man,
          "清单注册了文字分享目标并复用现有鳍舱窗口")
    check("onNewIntent" in java
          and "pendingSharedText" in java
          and "window.onAndroidSharedText" in java
          and "pendingSharedText = \"\"" in java,
          "其他应用分享的文字会等待页面就绪后填入编辑框")
    check("android.intent.action.PROCESS_TEXT" in man
          and "Intent.ACTION_PROCESS_TEXT" in java
          and "Intent.EXTRA_PROCESS_TEXT" in java,
          "系统选中文字菜单可把文字交给鳍舱")
    check("android.intent.action.SEND_MULTIPLE" in man
          and "Intent.ACTION_SEND_MULTIPLE" in java
          and "appendSharedPiece" in java
          and "coerceToText(this)" in java,
          "系统可一次分享多个文字片段，并按顺序合并")
    check('android:mimeType="text/plain"' in man
          and "String action = intent.getAction()" in java
          and "Intent.ACTION_SEND.equals(action)" in java,
          "分享与选中文字共用同一条受控文本接收路径")
    check("window.onAndroidSharedText" in settings_js
          and 'document.getElementById("box")' in settings_js
          and "box.dispatchEvent(new Event(\"input\"" in settings_js
          and "/api/cmd" not in settings_js.split(
              "window.onAndroidSharedText", 1)[1].split("function nativeShareText", 1)[0],
          "分享文字只插入编辑框并触发输入状态，不自动发送")
    check("ClipboardManager" in java and "ClipData" in java,
          "网页在 http 下也能通过原生剪贴板复制")
    check('id="tipaste"' in page and "粘贴文字" in page
          and "readClipboardText" in page,
          "＋ 菜单可显式从系统剪贴板粘贴到输入框")
    check("readClipboardText" in java
          and "coerceToText" in java and "120000" in java,
          "原生剪贴板只读用户点按后的文字并限制长度")
    paste_handler = page.split(
        'document.getElementById("tipaste").onclick', 1
    )[1].split("// 「＋」菜单里", 1)[0]
    check('id="tipaste"' in page
          and "box.setRangeText(text" in paste_handler
          and "/api/cmd" not in paste_handler,
          "原生粘贴只插入编辑区，不会自动发送")
    check("FLAG_KEEP_SCREEN_ON" in java, "按需保持亮屏")
    check('id="acceptBattery"' in page
          and "openBatteryOptimizationSettings" in management_js,
          "真机验收页有后台电池设置入口")
    check('id="acceptBatteryRequest"' in page
          and "requestBatteryOptimizationExemption" in management_js,
          "真机验收页有一键申请后台豁免入口")
    check("isIgnoringBatteryOptimizations" in java,
          "原生状态能读出电池优化是否已豁免")
    check("isDeviceIdleMode" in diagnostics
          and "isPowerSaveMode" in diagnostics
          and "getAppStandbyBucket" in diagnostics
          and "isBackgroundRestricted" in diagnostics
          and "background_restricted" in diagnostics
          and "!backgroundRestricted" in diagnostics,
          "后台快照带 Doze、省电模式、应用待机桶和系统后台限制")
    check("app_standby_bucket" in management_js
          and "power_save_mode" in management_js
          and "device_idle_mode" in management_js
          and "background_restricted" in management_js,
          "真机验收页展示后台压力现场")
    notify_service = (
        AND / "java" / "com" / "hubao" / "voiceassistant" / "NotifyService.java"
    ).read_text(encoding="utf-8")
    check("serviceSnapshot" in notify_service
          and "last_success_at" in notify_service
          and "consecutive_failures" in notify_service
          and "STALE_AFTER_MS" in notify_service
          and "last_failure_kind" in notify_service
          and "last_response_code" in notify_service,
          "通知前台服务记录最近轮询成功、失败原因、连败和心跳陈旧")
    check("notify_service_stale" in diagnostics
          and "notify_service_consecutive_failures" in diagnostics
          and "notify_service_last_failure_kind" in diagnostics
          and "通知服务心跳陈旧" in diagnostics
          and "notify_service_stale" in management_js,
          "后台快照与真机页展示通知服务心跳现场")
    check("notify_recovery_last_at" in diagnostics
          and "notify_recovery_last_ok" in diagnostics
          and "notify_recovery_last_at" in management_js,
          "后台快照与真机页展示重启/升级后的通知服务恢复记录")
    check("done_channel_sound" in diagnostics
          and "done_channel_vibration" in diagnostics
          and "done_channel_alerting" in diagnostics,
          "后台快照区分高优先级与真正响铃/震动")
    check('id="acceptNotifyChannel"' in page
          and "openDoneNotificationChannelSettings" in management_js
          and "ACTION_CHANNEL_NOTIFICATION_SETTINGS" in java,
          "真机验收页可直达完成通知通道设置")
    check("ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" in java
          and "requestBatteryOptimizationExemption" in java,
          "原生桥可弹出系统后台豁免申请")
    check("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" in man,
          "清单声明了后台豁免申请权限")
    check("ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS" in java
          and "ACTION_APPLICATION_DETAILS_SETTINGS" in java,
          "能打开电池优化页，并有应用详情兜底")
    check('id="acceptNotifySettings"' in page
          and "openNotificationSettings" in management_js,
          "真机验收页可直达本应用通知设置")
    check("ACTION_APP_NOTIFICATION_SETTINGS" in java
          and "EXTRA_APP_PACKAGE" in java,
          "通知设置按本应用包名打开")
    check('id="acceptDndSettings"' in page
          and "openSystemInterruptionSettings" in management_js,
          "真机验收页可直达系统勿扰设置")
    check("getCurrentInterruptionFilter" in diagnostics
          and "isNotificationPolicyAccessGranted" in diagnostics
          and "system_alert_blocked_by_dnd" in diagnostics
          and "getRingerMode" in diagnostics,
          "后台快照读取勿扰、通知策略和铃声现场")
    check("system_alert_blocked_by_dnd" in management_js
          and "interruption_filter_name" in management_js
          and "ringer_mode_name" in management_js,
          "真机验收页展示勿扰可能压掉完成提醒的原因")
    check('id="acceptStorageProbe"' in page
          and "appStorageProbe" in management_js,
          "真机验收页可验证应用缓存读写")
    check("FileOutputStream" in java and "FileInputStream" in java
          and "findeck-storage-probe.txt" in java,
          "存储验证会写入、读回并删除临时文件")
    check("font_scale" in diagnostics
          and "density_dpi" in diagnostics
          and "screen_width_dp" in diagnostics
          and "screen_height_dp" in diagnostics
          and "smallest_width_dp" in diagnostics
          and "night_mode" in diagnostics
          and "orientation" in diagnostics
          and "getLocales" in diagnostics,
          "设备状态读取字体缩放、dp 尺寸、密度、深浅色、方向和语言")
    check("font_scale" in management_js
          and "screen_width_dp" in management_js
          and "density_dpi" in management_js
          and "night_mode" in management_js,
          "真机验收页展示系统显示环境，便于核对折叠屏布局")
    window_diagnostics = (
        AND / "java" / "com" / "hubao" / "voiceassistant"
        / "DeviceDiagnostics.java"
    ).read_text(encoding="utf-8")
    check('id="acceptWindowLayout"' in page
          and "windowLayoutProbe" in management_js,
          "真机验收页可读取原生窗口安全区")
    check("getCurrentWindowMetrics" in window_diagnostics
          and "getMaximumWindowMetrics" in window_diagnostics
          and "getRootWindowInsets" in window_diagnostics
          and "getDisplayCutout" in window_diagnostics
          and "findeck-window-layout-v1" in window_diagnostics,
          "窗口现场读取当前/最大边界、系统栏与刘海安全区")
    check("window_layout_baseline_only; result_not_recorded"
          in window_diagnostics,
          "窗口安全区明确不冒充真机验收结果")
    check('id="acceptTimeContext"' in page
          and "timeContextProbe" in management_js,
          "真机验收页可读取系统时区、时钟与时间格式")
    check("findeck-time-context-v1" in device_diagnostics
          and "TimeZone.getDefault" in device_diagnostics
          and "is24HourFormat" in device_diagnostics
          and "AUTO_TIME_ZONE" in device_diagnostics,
          "时间现场读取时区、24 小时制和自动校时状态")
    check("schedule_context_only; result_not_recorded"
          in device_diagnostics,
          "系统时间现场明确只作日程排障，不冒充验收")
    check('id="acceptTimeSettings"' in page
          and "openTimeSettings" in management_js
          and "ACTION_DATE_SETTINGS" in java
          and "ACTION_SETTINGS" in java,
          "真机验收页可由用户点按打开系统时间设置并有回退")
    check('"time_context"' in diagnostic_report,
          "诊断导出包含独立的系统时间分区")
    check('id="acceptNetworkContext"' in page
          and "networkContextProbe" in management_js,
          "真机验收页可读取网络连接现场")
    check("findeck-network-context-v1" in device_diagnostics
          and "NET_CAPABILITY_VALIDATED" in device_diagnostics
          and "TRANSPORT_CELLULAR" in device_diagnostics
          and "AIRPLANE_MODE_ON" in device_diagnostics,
          "网络现场读取验证状态、连接通道和飞行模式")
    check("connection_context_only; result_not_recorded"
          in device_diagnostics,
          "网络连接现场明确不冒充真机验收")
    check('id="acceptNetworkSettings"' in page
          and "openNetworkSettings" in management_js
          and "ACTION_INTERNET_CONNECTIVITY" in java
          and "ACTION_WIRELESS_SETTINGS" in java,
          "真机验收页可打开网络面板并有无线设置回退")
    check('"network_context"' in diagnostic_report,
          "诊断导出包含独立的网络连接分区")
    check('id="acceptDisplaySettings"' in page
          and "openDisplaySettings" in management_js
          and "ACTION_DISPLAY_SETTINGS" in java,
          "真机验收页可由用户点按打开系统屏幕设置")
    check('id="acceptDataSaverSettings"' in page
          and "openDataSaverSettings" in management_js
          and "ACTION_DATA_USAGE_SETTINGS" in java
          and "ACTION_WIRELESS_SETTINGS" in java,
          "真机验收页可打开流量节省设置并有无线设置回退")
    check("getRestrictBackgroundStatus" in device_diagnostics
          and "isActiveNetworkMetered" in device_diagnostics
          and "background_data_restricted" in device_diagnostics
          and "流量节省限制后台数据" in device_diagnostics,
          "后台快照读取 Data Saver、计费网络并列出后台数据受限原因")
    check("data_saver_enabled" in management_js
          and "data_saver_whitelisted" in management_js
          and "active_network_metered" in management_js
          and "background_data_restricted" in management_js,
          "真机验收页展示流量限制与应用放行现场")
    check('id="acceptAudioFocus"' in page
          and "audioFocusProbe" in management_js,
          "真机验收页可验证系统音频焦点")
    check('id="acceptVoiceEcho"' in page
          and "VoiceApp.recStart" in management_js
          and "VoiceApp.recStop" in management_js
          and "8000" in management_js,
          "真机验收页可做 8 秒原生麦克风声学采样")
    audio_focus = (AND / "java" / "com" / "hubao" / "voiceassistant"
                   / "AudioFocusController.java")
    focus_src = audio_focus.read_text(encoding="utf-8") if audio_focus.exists() else ""
    check("AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE" in focus_src
          and "requestAudioFocus" in focus_src
          and "abandonAudioFocus" in focus_src,
          "录音申请临时独占焦点并主动释放")
    check("audioFocus.request" in java and "audioFocus.abandon" in java,
          "原生录音开始与结束已接入焦点控制器")
    check("request_count" in focus_src and "loss_count" in focus_src
          and "gain_count" in focus_src and "abandon_count" in focus_src,
          "音频焦点快照记录申请、失焦、恢复与释放计数")
    check("last_change_at" in focus_src and "events" in focus_src
          and "HISTORY_LIMIT" in focus_src,
          "音频焦点快照保留最近变化时间和限量事件时间线")
    check("probe.request_count" in management_js
          and "probe.loss_count" in management_js
          and "probe.gain_count" in management_js,
          "真机验收页展示音频焦点前后现场")
    check('id="acceptExportDiagnostics"' in page
          and "exportDiagnosticSnapshot" in management_js,
          "真机验收页可导出完整诊断快照")
    check('id="acceptCopyDiagnostics"' in page
          and "copyDiagnosticSnapshot" in management_js,
          "真机验收页可把诊断快照复制到原生剪贴板")
    check('id="acceptShareDiagnostics"' in page
          and "shareDiagnosticSnapshot" in management_js,
          "真机验收页可通过 Android 系统分享诊断快照")
    check("DiagnosticReport.snapshot" in java
          and "findeck-android-diagnostics-v2" in diagnostic_report
          and '"background"' in diagnostic_report
          and '"notification"' in diagnostic_report
          and '"notification_recovery"' in diagnostic_report
          and '"audio_focus"' in diagnostic_report
          and '"audio_environment"' in diagnostic_report
          and '"window_layout"' in diagnostic_report,
          "导出内容包含设备、后台、通知、焦点、音频环境与窗口状态")
    check('id="acceptAudioEnvironment"' in page
          and "audioEnvironmentSnapshot" in management_js,
          "真机验收页可读取原生音频路由快照")
    device_diagnostics = (AND / "java" / "com" / "hubao" / "voiceassistant" /
                          "DeviceDiagnostics.java").read_text(encoding="utf-8")
    check("DeviceDiagnostics.audioEnvironment" in java
          and "GET_DEVICES_INPUTS" in device_diagnostics
          and "GET_DEVICES_OUTPUTS" in device_diagnostics
          and "getSampleRates" in device_diagnostics
          and "getChannelCounts" in device_diagnostics
          and "findeck-audio-environment-v1" in device_diagnostics,
          "音频快照读取真实输入输出路由、采样率与声道")
    check("acoustic_echo_baseline_only; result_not_recorded" in
          device_diagnostics,
          "音频路由现场不冒充声学验收结果")
    check("route_signature" in device_diagnostics
          and "audio_route_last_signature" in device_diagnostics
          and "audio_route_change_count" in device_diagnostics
          and "route_changed_since_last_snapshot" in device_diagnostics,
          "音频快照记录前后路由差异、变化次数和最近变化时间")
    check("route_change_count" in management_js
          and "route_changed_since_last_snapshot" in management_js,
          "真机验收页展示路由变化证据")
    check('"sections"' in diagnostic_report
          and '"complete"' in diagnostic_report
          and '"acceptance_results"' in diagnostic_report,
          "诊断快照自带分区状态且明确不冒充真机验收结果")
    check("phone-token" not in diagnostic_report
          and "conversation" not in diagnostic_report.lower()
          and "对话正文" in diagnostic_report,
          "诊断快照不含手机令牌或对话正文")
    build_apk = (ROOT / "work" / "build_apk.py").read_text(encoding="utf-8")
    check('"verify", "--print-certs", apk_update' in build_apk
          and build_apk.index('"--print-certs", apk_update')
          < build_apk.index("shutil.copy2(apk_update, apk)"),
          "APK 构建验证的是刚签名的新包，不是上一次的旧包")
    check('id="acceptFileOpen"' in page and "ACTION_OPEN_DOCUMENT" in java,
          "真机验收页可打开系统真实文件")
    check('id="acceptFileSave"' in page and "ACTION_CREATE_DOCUMENT" in java,
          "真机验收页可通过系统另存真实文件")
    check("takePersistableUriPermission" in java
          and "FLAG_GRANT_PERSISTABLE_URI_PERMISSION" in java,
          "读取真实文件时申请可持久化的 URI 授权")
    check("onAndroidDocumentResult" in management_js
          and "MessageDigest" in java,
          "真实文件结果回传名称、大小和 SHA-256")
    check('id="acceptFileReopen"' in page
          and "reopenRealDocument" in management_js,
          "真机验收页可回读上次持久授权的文件")
    check('id="acceptFileVerifySaved"' in page
          and "reopenSavedDocument" in management_js,
          "真机验收页可回读另存文件并核对哈希")
    check('id="acceptFileRelease"' in page
          and "releaseRealDocumentAccess" in management_js,
          "真机验收页可撤销保留的文件授权")
    check("getPersistedUriPermissions" in java
          and "releasePersistableUriPermission" in java,
          "原生文件授权可查询并主动释放")
    check("MAX_DOCUMENT_BYTES" in java and "64L * 1024L * 1024L" in java,
          "真实文件哈希读取有 64 MB 上限")
    check("KEY_SAVED_DOC_SHA" in java and "expected_sha256" in java
          and "equalsIgnoreCase(actual)" in java,
          "另存文件跨重启回读会与保存时 SHA-256 对照")
    check("ACTION_CREATE_DOCUMENT" in java
          and "FLAG_GRANT_READ_URI_PERMISSION" in java
          and "persisted = hasPersistedRead(uri)" in java,
          "系统另存后保留可读持久授权")

    print("⑥ 打出来的 APK 里真的有这些")
    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    check(apk.exists(), f"APK 在（{apk.stat().st_size / 1024:.0f} KB）" if apk.exists() else "APK 不在")
    if apk.exists():
        z = zipfile.ZipFile(apk)
        dex = b"".join(z.read(n) for n in z.namelist() if n.endswith(".dex"))
        for needle, what in ((b"UpdateProvider", "UpdateProvider 类"),
                             (b"canRequestPackageInstalls", "权限检查"),
                             (b"com.hubao.voiceassistant.updates", "authority"),
                             (b"shareText", "原生分享方法"),
                             (b"onAndroidSharedText", "系统分享文字接收入口"),
                             (b"android.intent.action.SEND_MULTIPLE",
                              "多段文字分享目标"),
                             (b"copyText", "原生剪贴板方法"),
                             (b"readClipboardText", "原生剪贴板读取方法"),
                             (b"coerceToText", "系统剪贴板文本转换"),
                             (b"keepScreenOn", "亮屏控制方法"),
                             (b"openBatteryOptimizationSettings", "后台电池设置方法"),
                             (b"requestBatteryOptimizationExemption",
                              "后台豁免申请方法"),
                             (b"isIgnoringBatteryOptimizations", "电池优化状态"),
                             (b"openNotificationSettings", "通知设置直达方法"),
                             (b"openSystemInterruptionSettings", "系统勿扰设置方法"),
                             (b"system_alert_blocked_by_dnd",
                              "勿扰压掉完成提醒判定"),
                             (b"interruption_filter_name", "勿扰级别名称"),
                             (b"ringer_mode_name", "铃声模式名称"),
                             (b"appStorageProbe", "应用存储验证方法"),
                             (b"audioFocusProbe", "音频焦点验证方法"),
                             (b"last_change_at", "音频焦点最近变化时间"),
                             (b"grant_count", "音频焦点成功计数"),
                             (b"loss_count", "音频焦点失焦计数"),
                             (b"gain_count", "音频焦点恢复计数"),
                             (b"abandon_count", "音频焦点释放计数"),
                             (b"openRealDocument", "真实文件打开方法"),
                             (b"saveRealDocument", "真实文件保存方法"),
                             (b"reopenRealDocument", "持久授权回读方法"),
                             (b"reopenSavedDocument", "另存文件回读方法"),
                             (b"expected_sha256", "另存文件预期哈希字段"),
                             (b"releaseRealDocumentAccess", "文件授权撤销方法"),
                             (b"exportDiagnosticSnapshot", "诊断快照导出方法"),
                             (b"copyDiagnosticSnapshot", "诊断快照复制方法"),
                             (b"shareDiagnosticSnapshot", "诊断快照分享方法"),
                             (b"acceptance_results", "快照验收结果边界字段"),
                             (b"findeck-android-diagnostics-v2", "诊断快照格式"),
                             (b"audioEnvironmentSnapshot", "音频路由快照方法"),
                             (b"findeck-audio-environment-v1", "音频路由快照格式"),
                             (b"bluetooth_sco", "蓝牙通话路由字段"),
                             (b"route_change_count", "音频路由变化次数"),
                             (b"route_changed_since_last_snapshot",
                              "音频路由前后对比标记"),
                             (b"windowLayoutProbe", "窗口安全区读取方法"),
                             (b"findeck-window-layout-v1", "窗口安全区格式"),
                             (b"getCurrentWindowMetrics", "当前窗口边界读取"),
                             (b"getMaximumWindowMetrics", "最大窗口边界读取"),
                             (b"getDisplayCutout", "刘海安全区读取"),
                             (b"timeContextProbe", "系统时间现场读取方法"),
                             (b"findeck-time-context-v1", "系统时间现场格式"),
                             (b"clock_24_hour", "24 小时制字段"),
                             (b"automatic_time_zone", "自动时区字段"),
                             (b"networkContextProbe", "网络连接现场读取方法"),
                             (b"findeck-network-context-v1", "网络连接现场格式"),
                             (b"validated", "网络验证状态字段"),
                             (b"airplane_mode", "飞行模式字段"),
                             (b"openNetworkSettings", "系统网络设置入口"),
                             (b"network_context", "网络连接诊断分区"),
                             (b"openTimeSettings", "系统时间设置入口"),
                             (b"openDisplaySettings", "屏幕设置入口"),
                             (b"openDataSaverSettings", "流量设置入口"),
                             (b"getRestrictBackgroundStatus",
                              "Data Saver 限制状态读取"),
                             (b"isActiveNetworkMetered", "计费网络读取"),
                             (b"background_data_restricted",
                              "后台数据受限字段"),
                             (b"audio_route_last_signature",
                              "音频路由基线持久状态"),
                             (b"isBackgroundRestricted",
                              "系统后台运行限制读取"),
                             (b"background_restricted",
                              "系统后台运行限制字段"),
                             (b"serviceSnapshot",
                              "通知服务心跳快照方法"),
                             (b"NotifyRecoveryReceiver",
                              "通知服务恢复接收器"),
                             (b"recoverNotificationService",
                              "通知服务手动恢复方法"),
                             (b"notificationRecoveryProbe",
                              "通知服务恢复记录读取方法"),
                             (b"notify_service_stale",
                              "通知服务心跳陈旧字段"),
                             (b"consecutive_failures",
                              "通知轮询连续失败计数"),
                             (b"isAlertActive", "完成通知可见性回读"),
                             (b"notification_visible", "通知当前可见字段")):
            if needle == b"notification_visible":
                for extra, extra_name in (
                        (b"done_channel_alerting", "完成通道可提醒判定"),
                        (b"done_channel_sound", "完成通道响铃字段"),
                        (b"openDoneNotificationChannelSettings",
                         "完成通道设置方法")):
                    check(extra in dex, f"dex 里有 {extra_name}")
            check(needle in dex, f"dex 里有 {what}")
        print("     phone-version.txt =",
              (APP / "phone-version.txt").read_text(encoding="utf-8").strip())
        import version as _v

        check(_v.PHONE_VERSION in (APP / "phone-version.txt").read_text(encoding="utf-8"),
              f"手机端版本已经是 {_v.PHONE_VERSION}（有新版手机才会提示更新）")
    # 手机页面下载到的必须就是这一个 APK（不然"一键更新"装了个旧包）
    same = (APP / "语音助手-手机端.apk")
    check(same.exists() and same.stat().st_size == apk.stat().st_size,
          "手机入口发出去的那个 APK 和刚打的是同一个")

    print("⑦ 电脑那边报的版本号")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8801)
    if link.start():
        try:
            time.sleep(0.2)
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/api/version?k={link.token}", timeout=8) as r:
                d = json.loads(r.read().decode("utf-8"))
            check(str(d.get("phone")) == _v.PHONE_VERSION,
                  f"/api/version 报手机端 {d.get('phone')}")
            check(int(d.get("apk_kb") or 0) > 400, f"APK 大小报的是 {d.get('apk_kb')} KB")
            check(d.get("apk") == "语音助手-手机端.apk", f"APK 名字：{d.get('apk')}")
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/app.apk?k={link.token}", timeout=20) as r:
                body = r.read()
            check(body[:2] == b"PK" and len(body) > 400 * 1024,
                  f"/app.apk 真能下到一个完整 APK（{len(body) / 1024:.0f} KB）")
        finally:
            link.stop()
    else:
        check(False, "手机入口起不来，跳过")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
