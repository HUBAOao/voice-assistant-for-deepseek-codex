# -*- coding: utf-8 -*-
"""验收「手机 APP 一键更新」：设置里那个常驻入口 + 真能装上的那条路。

以前用不了的原因有三条，这个测试就盯着这三条：
  ① 网页给的是**相对地址**（Uri.parse 打不开）→ 现在必须给绝对地址
  ② 以前只是把浏览器叫起来 → 现在是 APP 自己下载 + 拉起系统安装器
  ③ 安卓 8+ 要先允许「安装未知应用」→ 现在没权限会带用户去开，回来接着下
"""
from __future__ import annotations

import json
import re
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "outputs" / "voice-to-text"
AND = ROOT / "work" / "android-app"
sys.path.insert(0, str(APP))


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(cond: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if cond else "  ✗ ") + text)
        if not cond:
            bad += 1

    page = (APP / "phone_page.html").read_text(encoding="utf-8")
    page += "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((APP / "phone_feature" / "ui").glob("*.js"))
    )
    settings_js = (APP / "phone_feature" / "ui" / "settings.js").read_text(encoding="utf-8")
    management_js = (APP / "phone_feature" / "ui" / "management.js").read_text(
        encoding="utf-8")
    java = (AND / "java" / "com" / "hubao" / "voiceassistant"
            / "MainActivity.java").read_text(encoding="utf-8")
    diagnostics = (AND / "java" / "com" / "hubao" / "voiceassistant"
                   / "DeviceDiagnostics.java").read_text(encoding="utf-8")
    diagnostic_report = (AND / "java" / "com" / "hubao" / "voiceassistant"
                         / "DiagnosticReport.java").read_text(encoding="utf-8")
    provider = (AND / "java" / "com" / "hubao" / "voiceassistant"
                / "UpdateProvider.java")
    man = (AND / "AndroidManifest.xml").read_text(encoding="utf-8")

    print("① 设置里那个常驻入口")
    check('id="updbtn"' in page and 'id="updnow"' in page,
          "设置面板里有「更新」那一行（状态文字 + 按钮）")
    check("function refreshUpdRow" in page, "有刷新那一行的函数")
    check("refreshUpdRow();" in page.split("async function checkUpdate")[-1],
          "页面一进来就会顺便把这一行刷新（不用你自己去找）")
    check('btn.textContent = "一键更新"' in page, "有新版时按钮变成「一键更新」")
    check("已经是最新" in page, "没新版时明说「已经是最新」")

    print("② 地址必须是绝对的（以前就是栽在这）")
    check("location.origin + \"/app.apk" in page,
          "下载地址用 location.origin 拼成绝对地址")
    check("absoluteUrl" in java, "Java 那边也会兜底把相对地址补全")
    check('Uri.parse(url)' not in java.split("openUpdate")[1][:400],
          "openUpdate 不再直接把地址丢给浏览器")

    print("③ APP 自己下载 + 拉起安装器")
    check("downloadAndInstall" in java, "有下载函数")
    check("HttpURLConnection" in java and "update.apk" in java,
          "自己把新版下到本机 update.apk")
    check("application/vnd.android.package-archive" in java,
          "下载完按 APK 类型交给系统")
    check("content://" in java and "UpdateProvider.AUTHORITY" in java,
          "用 content:// 递文件（安卓 7 以后不许用 file://）")
    check(provider.exists() and "extends ContentProvider" in
          (provider.read_text(encoding="utf-8") if provider.exists() else ""),
          "自带的迷你 FileProvider（UpdateProvider）在")
    check("canRequestPackageInstalls" in java
          and "ACTION_MANAGE_UNKNOWN_APP_SOURCES" in java,
          "安卓 8+ 会先检查/带你去开「安装未知应用」")
    check("protected void onResume" in java and "pendingUpdateUrl" in java,
          "开完权限回来会自动接着下")

    print("④ 清单里该有的东西")
    check("REQUEST_INSTALL_PACKAGES" in man, "有 REQUEST_INSTALL_PACKAGES 权限")
    check("android.permission.VIBRATE" in man, "有 VIBRATE 权限（震动失败不会崩）")
    check("com.hubao.voiceassistant.updates" in man and "<provider" in man,
          "provider 声明和代码里的 authority 对得上")

    print("⑤ 原生分享与系统能力")
    check('id="tishare"' in page and "shareCurrentConversation" in settings_js,
          "＋ 菜单有「分享对话」入口")
    for method in ("shareText", "copyText", "openExternal", "keepScreenOn", "haptic"):
        check(method in java, f"原生桥有 {method}()")
    check("ACTION_SEND" in java and "EXTRA_TEXT" in java,
          "分享走 Android 系统分享面板")
    check("ClipboardManager" in java and "ClipData" in java,
          "网页在 http 下也能通过原生剪贴板复制")
    check("FLAG_KEEP_SCREEN_ON" in java, "按需保持亮屏")
    check('id="acceptBattery"' in page
          and "openBatteryOptimizationSettings" in management_js,
          "真机验收页有后台电池设置入口")
    check('id="acceptBatteryRequest"' in page
          and "requestBatteryOptimizationExemption" in management_js,
          "真机验收页有一键申请后台豁免入口")
    check("isIgnoringBatteryOptimizations" in java,
          "原生状态能读出电池优化是否已豁免")
    check("isDeviceIdleMode" in diagnostics
          and "isPowerSaveMode" in diagnostics
          and "getAppStandbyBucket" in diagnostics,
          "后台快照带 Doze、省电模式和应用待机桶")
    check("app_standby_bucket" in management_js
          and "power_save_mode" in management_js
          and "device_idle_mode" in management_js,
          "真机验收页展示后台压力现场")
    check("done_channel_sound" in diagnostics
          and "done_channel_vibration" in diagnostics
          and "done_channel_alerting" in diagnostics,
          "后台快照区分高优先级与真正响铃/震动")
    check('id="acceptNotifyChannel"' in page
          and "openDoneNotificationChannelSettings" in management_js
          and "ACTION_CHANNEL_NOTIFICATION_SETTINGS" in java,
          "真机验收页可直达完成通知通道设置")
    check("ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" in java
          and "requestBatteryOptimizationExemption" in java,
          "原生桥可弹出系统后台豁免申请")
    check("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" in man,
          "清单声明了后台豁免申请权限")
    check("ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS" in java
          and "ACTION_APPLICATION_DETAILS_SETTINGS" in java,
          "能打开电池优化页，并有应用详情兜底")
    check('id="acceptNotifySettings"' in page
          and "openNotificationSettings" in management_js,
          "真机验收页可直达本应用通知设置")
    check("ACTION_APP_NOTIFICATION_SETTINGS" in java
          and "EXTRA_APP_PACKAGE" in java,
          "通知设置按本应用包名打开")
    check('id="acceptStorageProbe"' in page
          and "appStorageProbe" in management_js,
          "真机验收页可验证应用缓存读写")
    check("FileOutputStream" in java and "FileInputStream" in java
          and "findeck-storage-probe.txt" in java,
          "存储验证会写入、读回并删除临时文件")
    check('id="acceptAudioFocus"' in page
          and "audioFocusProbe" in management_js,
          "真机验收页可验证系统音频焦点")
    audio_focus = (AND / "java" / "com" / "hubao" / "voiceassistant"
                   / "AudioFocusController.java")
    focus_src = audio_focus.read_text(encoding="utf-8") if audio_focus.exists() else ""
    check("AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE" in focus_src
          and "requestAudioFocus" in focus_src
          and "abandonAudioFocus" in focus_src,
          "录音申请临时独占焦点并主动释放")
    check("audioFocus.request" in java and "audioFocus.abandon" in java,
          "原生录音开始与结束已接入焦点控制器")
    check('id="acceptExportDiagnostics"' in page
          and "exportDiagnosticSnapshot" in management_js,
          "真机验收页可导出完整诊断快照")
    check('id="acceptCopyDiagnostics"' in page
          and "copyDiagnosticSnapshot" in management_js,
          "真机验收页可把诊断快照复制到原生剪贴板")
    check('id="acceptShareDiagnostics"' in page
          and "shareDiagnosticSnapshot" in management_js,
          "真机验收页可通过 Android 系统分享诊断快照")
    check("DiagnosticReport.snapshot" in java
          and "findeck-android-diagnostics-v1" in diagnostic_report
          and '"background"' in diagnostic_report
          and '"notification"' in diagnostic_report
          and '"audio_focus"' in diagnostic_report,
          "导出内容包含设备、后台、通知与音频焦点状态")
    check('"sections"' in diagnostic_report
          and '"complete"' in diagnostic_report
          and '"acceptance_results"' in diagnostic_report,
          "诊断快照自带分区状态且明确不冒充真机验收结果")
    check("phone-token" not in diagnostic_report
          and "conversation" not in diagnostic_report.lower()
          and "对话正文" in diagnostic_report,
          "诊断快照不含手机令牌或对话正文")
    build_apk = (ROOT / "work" / "build_apk.py").read_text(encoding="utf-8")
    check('"verify", "--print-certs", apk_update' in build_apk
          and build_apk.index('"--print-certs", apk_update')
          < build_apk.index("shutil.copy2(apk_update, apk)"),
          "APK 构建验证的是刚签名的新包，不是上一次的旧包")
    check('id="acceptFileOpen"' in page and "ACTION_OPEN_DOCUMENT" in java,
          "真机验收页可打开系统真实文件")
    check('id="acceptFileSave"' in page and "ACTION_CREATE_DOCUMENT" in java,
          "真机验收页可通过系统另存真实文件")
    check("takePersistableUriPermission" in java
          and "FLAG_GRANT_PERSISTABLE_URI_PERMISSION" in java,
          "读取真实文件时申请可持久化的 URI 授权")
    check("onAndroidDocumentResult" in management_js
          and "MessageDigest" in java,
          "真实文件结果回传名称、大小和 SHA-256")
    check('id="acceptFileReopen"' in page
          and "reopenRealDocument" in management_js,
          "真机验收页可回读上次持久授权的文件")
    check('id="acceptFileVerifySaved"' in page
          and "reopenSavedDocument" in management_js,
          "真机验收页可回读另存文件并核对哈希")
    check('id="acceptFileRelease"' in page
          and "releaseRealDocumentAccess" in management_js,
          "真机验收页可撤销保留的文件授权")
    check("getPersistedUriPermissions" in java
          and "releasePersistableUriPermission" in java,
          "原生文件授权可查询并主动释放")
    check("MAX_DOCUMENT_BYTES" in java and "64L * 1024L * 1024L" in java,
          "真实文件哈希读取有 64 MB 上限")
    check("KEY_SAVED_DOC_SHA" in java and "expected_sha256" in java
          and "equalsIgnoreCase(actual)" in java,
          "另存文件跨重启回读会与保存时 SHA-256 对照")
    check("ACTION_CREATE_DOCUMENT" in java
          and "FLAG_GRANT_READ_URI_PERMISSION" in java
          and "persisted = hasPersistedRead(uri)" in java,
          "系统另存后保留可读持久授权")

    print("⑥ 打出来的 APK 里真的有这些")
    apk = ROOT / "outputs" / "语音助手-手机端.apk"
    check(apk.exists(), f"APK 在（{apk.stat().st_size / 1024:.0f} KB）" if apk.exists() else "APK 不在")
    if apk.exists():
        z = zipfile.ZipFile(apk)
        dex = b"".join(z.read(n) for n in z.namelist() if n.endswith(".dex"))
        for needle, what in ((b"UpdateProvider", "UpdateProvider 类"),
                             (b"canRequestPackageInstalls", "权限检查"),
                             (b"com.hubao.voiceassistant.updates", "authority"),
                             (b"shareText", "原生分享方法"),
                             (b"copyText", "原生剪贴板方法"),
                             (b"keepScreenOn", "亮屏控制方法"),
                             (b"openBatteryOptimizationSettings", "后台电池设置方法"),
                             (b"requestBatteryOptimizationExemption",
                              "后台豁免申请方法"),
                             (b"isIgnoringBatteryOptimizations", "电池优化状态"),
                             (b"openNotificationSettings", "通知设置直达方法"),
                             (b"appStorageProbe", "应用存储验证方法"),
                             (b"audioFocusProbe", "音频焦点验证方法"),
                             (b"openRealDocument", "真实文件打开方法"),
                             (b"saveRealDocument", "真实文件保存方法"),
                             (b"reopenRealDocument", "持久授权回读方法"),
                             (b"reopenSavedDocument", "另存文件回读方法"),
                             (b"expected_sha256", "另存文件预期哈希字段"),
                             (b"releaseRealDocumentAccess", "文件授权撤销方法"),
                             (b"exportDiagnosticSnapshot", "诊断快照导出方法"),
                             (b"copyDiagnosticSnapshot", "诊断快照复制方法"),
                             (b"shareDiagnosticSnapshot", "诊断快照分享方法"),
                             (b"acceptance_results", "快照验收结果边界字段"),
                             (b"findeck-android-diagnostics-v1", "诊断快照格式"),
                             (b"isAlertActive", "完成通知可见性回读"),
                             (b"notification_visible", "通知当前可见字段")):
            if needle == b"notification_visible":
                for extra, extra_name in (
                        (b"done_channel_alerting", "完成通道可提醒判定"),
                        (b"done_channel_sound", "完成通道响铃字段"),
                        (b"openDoneNotificationChannelSettings",
                         "完成通道设置方法")):
                    check(extra in dex, f"dex 里有 {extra_name}")
            check(needle in dex, f"dex 里有 {what}")
        print("     phone-version.txt =",
              (APP / "phone-version.txt").read_text(encoding="utf-8").strip())
        import version as _v

        check(_v.PHONE_VERSION in (APP / "phone-version.txt").read_text(encoding="utf-8"),
              f"手机端版本已经是 {_v.PHONE_VERSION}（有新版手机才会提示更新）")
    # 手机页面下载到的必须就是这一个 APK（不然"一键更新"装了个旧包）
    same = (APP / "语音助手-手机端.apk")
    check(same.exists() and same.stat().st_size == apk.stat().st_size,
          "手机入口发出去的那个 APK 和刚打的是同一个")

    print("⑦ 电脑那边报的版本号")
    import phone_link

    link = phone_link.PhoneLink(
        on_command=lambda t: None,
        get_state=lambda: {"online": True, "state": "idle", "lines": []},
        get_log=lambda: [], port=8801)
    if link.start():
        try:
            time.sleep(0.2)
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/api/version?k={link.token}", timeout=8) as r:
                d = json.loads(r.read().decode("utf-8"))
            check(str(d.get("phone")) == _v.PHONE_VERSION,
                  f"/api/version 报手机端 {d.get('phone')}")
            check(int(d.get("apk_kb") or 0) > 400, f"APK 大小报的是 {d.get('apk_kb')} KB")
            check(d.get("apk") == "语音助手-手机端.apk", f"APK 名字：{d.get('apk')}")
            with urllib.request.urlopen(
                    f"http://127.0.0.1:8801/app.apk?k={link.token}", timeout=20) as r:
                body = r.read()
            check(body[:2] == b"PK" and len(body) > 400 * 1024,
                  f"/app.apk 真能下到一个完整 APK（{len(body) / 1024:.0f} KB）")
        finally:
            link.stop()
    else:
        check(False, "手机入口起不来，跳过")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
