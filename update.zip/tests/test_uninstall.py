# -*- coding: utf-8 -*-
"""验收卸载程序：保留记录 / 演练 / 彻底删除 / 认错目录要拦住。全在沙箱里跑。"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei")
APP = ROOT / "outputs" / "voice-to-text"
S = ROOT / "work" / "uninstall-test"
PY = APP / ".venv" / "Scripts" / "python.exe"
UNINSTALL = APP / "uninstall.py"


def make_fake_app(name: str) -> Path:
    d = S / name
    if d.exists():
        shutil.rmtree(d, ignore_errors=True)
    (d / ".venv" / "Scripts").mkdir(parents=True)
    (d / "models").mkdir(parents=True)
    (d / "assets").mkdir(parents=True)
    (d / "stt.py").write_text("print('x')", encoding="utf-8")
    (d / "overlay.py").write_text("print('y')", encoding="utf-8")
    (d / "version.py").write_text("APP_VERSION='1.0'", encoding="utf-8")
    (d / ".venv" / "Scripts" / "python.exe").write_bytes(b"MZ" + b"\0" * 4000)
    (d / ".venv" / "Scripts" / "pythonw.exe").write_bytes(b"MZ" + b"\0" * 4000)
    (d / "models" / "large-v3-turbo.bin").write_bytes(b"\0" * 90000)
    (d / "assets" / "default-bg.jpg").write_bytes(b"\0" * 500)
    (d / "config.json").write_text(json.dumps(
        {"name": "大肥鱼", "presets": {"安静模式": {"volume": 20}}}, ensure_ascii=False),
        encoding="utf-8")
    (d / "transcripts.md").write_text("# 我说过的话\n- 哈喽\n", encoding="utf-8")
    (d / "diary.md").write_text("# 睡前日记\n", encoding="utf-8")
    (d / "voice.log").write_text("log" * 10, encoding="utf-8")
    (d / "status.json").write_text('{"state":"idle"}', encoding="utf-8")
    (d / "last.txt").write_text("最后一句", encoding="utf-8")
    return d


def run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run([str(PY), str(UNINSTALL), "--no-gui", *args],
                          capture_output=True, text=True, encoding="utf-8",
                          errors="replace", cwd=str(S), timeout=180)


def check(cond: bool, text: str) -> int:
    print(("  ✓ " if cond else "  ✗ ") + text)
    return 0 if cond else 1


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    S.mkdir(parents=True, exist_ok=True)
    bad = 0

    print("① 卸载（保留记录）")
    keep = make_fake_app("keep")
    r = run(["--yes", "--appdir", str(keep)])
    print("   " + " / ".join(line.strip() for line in r.stdout.splitlines()
                             if "删 " in line)[:300])
    bad += check(not (keep / ".venv").exists(), "运行环境 .venv 删掉了")
    bad += check(not (keep / "models").exists(), "模型 models 删掉了")
    bad += check(not (keep / "voice.log").exists(), "日志删掉了")
    bad += check(not (keep / "status.json").exists(), "运行时状态删掉了")
    bad += check((keep / "transcripts.md").exists(), "聊天记录还在")
    bad += check((keep / "diary.md").exists(), "日记还在")
    bad += check((keep / "config.json").exists(), "设置还在")
    bad += check((keep / "presets") or (keep / "config.json").exists(), "预设还在")
    bad += check((keep / "stt.py").exists() and (keep / "overlay.py").exists(),
                 "程序文件留着（重装不用重下模型）")
    bad += check(r.returncode == 0, f"退出码 = {r.returncode}")

    print("② 演练（--dry-run，一根毛都不该动）")
    dry = make_fake_app("dry")
    before = sorted(p.relative_to(dry).as_posix() for p in dry.rglob("*"))
    r = run(["--yes", "--dry-run", "--appdir", str(dry)])
    after = sorted(p.relative_to(dry).as_posix() for p in dry.rglob("*"))
    bad += check(before == after, "演练之后目录里一个文件都没少")
    bad += check("演练" in r.stdout, "输出里写明了这只是演练")

    print("③ 彻底删除")
    full = make_fake_app("full")
    r = run(["--yes", "--full", "--appdir", str(full)])
    gone = False
    for _ in range(30):                     # 等后台那个小脚本把目录删掉
        if not full.exists():
            gone = True
            break
        time.sleep(1)
    bad += check(gone, "整个文件夹被删干净了（含记录）")
    bad += check(r.returncode == 0, f"退出码 = {r.returncode}")

    print("④ 认错目录要拦住")
    stranger = S / "stranger"
    (stranger / "我的文件").mkdir(parents=True, exist_ok=True)
    (stranger / "我的文件" / "重要.txt").write_text("别删我", encoding="utf-8")
    r = run(["--yes", "--appdir", str(stranger)])
    bad += check((stranger / "我的文件" / "重要.txt").exists(), "不相干的文件夹原封不动")
    bad += check(r.returncode == 2, f"退出码 = {r.returncode}（2 = 拒绝了）")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
