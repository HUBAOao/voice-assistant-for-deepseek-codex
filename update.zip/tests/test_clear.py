# -*- coding: utf-8 -*-
"""验证"先全选再粘贴"：输入框里的旧内容不会跟着一起发出去。"""
import ctypes
import subprocess
import sys
import time

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import stt  # noqa: E402

user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
user32.GetClipboardData.restype = ctypes.c_void_p


def read_clipboard() -> str:
    if not user32.OpenClipboard(None):
        return "<打不开剪贴板>"
    try:
        h = user32.GetClipboardData(13)
        if not h:
            return ""
        p = kernel32.GlobalLock(h)
        t = ctypes.wstring_at(p)
        kernel32.GlobalUnlock(h)
        return t
    finally:
        user32.CloseClipboard()


proc = subprocess.Popen(["notepad.exe"])
hwnd = 0
for _ in range(50):
    time.sleep(0.3)
    h = user32.GetForegroundWindow()
    b = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(h, b, 256)
    if b.value.lower().startswith("notepad"):
        hwnd = h
        break
print("记事本 hwnd =", hwnd)

# 先往里面打一行旧内容
stt.focus_window(hwnd)
time.sleep(0.3)
stt.copy_to_clipboard("这一行是之前就有的旧内容")
for vk in (0x11, 0x56):
    stt._key(vk)
for vk in (0x56, 0x11):
    stt._key(vk, up=True)
time.sleep(0.4)

# 再让语音程序粘贴新内容（带 clear_first）
stt.paste_into("这是语音发的新内容", hwnd, press_enter=False, clear_first=True)
time.sleep(0.6)

# 全选复制读回来核对
for vk in (0x11, 0x41):
    stt._key(vk)
for vk in (0x41, 0x11):
    stt._key(vk, up=True)
time.sleep(0.3)
for vk in (0x11, 0x43):
    stt._key(vk)
for vk in (0x43, 0x11):
    stt._key(vk, up=True)
time.sleep(0.6)
got = read_clipboard().strip()
print("输入框内容:", repr(got))
print("旧内容被清掉了:", "这一行是之前就有的旧内容" not in got)
print("新内容在:", "这是语音发的新内容" in got)
proc.terminate()
