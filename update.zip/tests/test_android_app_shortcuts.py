# -*- coding: utf-8 -*-
"""Static app shortcuts expose navigation and an explicit background toggle."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
APK = ROOT / "outputs" / "语音助手-手机端.apk"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    manifest = (ANDROID / "AndroidManifest.xml").read_text(encoding="utf-8")
    activity = (
        ANDROID / "java" / "com" / "hubao" / "voiceassistant"
        / "MainActivity.java"
    ).read_text(encoding="utf-8")
    tree = ElementTree.parse(ANDROID / "res" / "xml" / "shortcuts.xml")
    ns = {"android": "http://schemas.android.com/apk/res/android"}
    shortcuts = tree.getroot().findall("shortcut", ns)
    ids = [item.get(f"{{{ns['android']}}}shortcutId") for item in shortcuts]
    actions = [
        item.find("intent", ns).get(f"{{{ns['android']}}}action")
        for item in shortcuts
    ]

    check('android:name="android.app.shortcuts"' in manifest
          and 'android:resource="@xml/shortcuts"' in manifest,
          "主 Activity 注册了静态快捷方式资源")
    check(ids == ["findeck_open", "findeck_scan", "findeck_watch"],
          "提供打开、扫码和后台提醒三个稳定快捷入口")
    check(actions == [
        "com.hubao.voiceassistant.SHORTCUT_OPEN",
        "com.hubao.voiceassistant.SHORTCUT_SCAN",
        "com.hubao.voiceassistant.SHORTCUT_WATCH",
    ], "快捷方式动作使用鳍舱私有命名空间")
    check("handleShortcutIntent(getIntent())" in activity
          and "handleShortcutIntent(intent)" in activity,
          "冷启动和单实例热启动都会处理快捷动作")
    check("SHORTCUT_WATCH.equals(action)" in activity
          and 'putBoolean("notify_done", true)' in activity
          and "startNotifyService()" in activity,
          "后台提醒快捷方式只开启既有通知服务")
    check("sendMessage" not in activity.split(
        "private void handleShortcutIntent", 1
    )[1].split("@JavascriptInterface", 1)[0],
          "快捷入口不会自动发送消息")

    with zipfile.ZipFile(APK) as archive:
        dex = archive.read("classes.dex")
        resources = archive.read("resources.arsc")
    for marker in (
        b"SHORTCUT_SCAN",
        b"SHORTCUT_WATCH",
        "扫码连接电脑".encode("utf-8"),
        "开启电脑完成提醒".encode("utf-8"),
    ):
        check(marker in dex or marker in resources,
              f"APK 包含快捷方式契约 {marker.decode('utf-8')}")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
