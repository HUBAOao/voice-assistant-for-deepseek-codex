# -*- coding: utf-8 -*-
"""The native parity preview stays isolated behind the stable WebView UI."""
from __future__ import annotations

import sys
import re
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "work" / "android-app"
JAVA = ANDROID / "java" / "com" / "hubao" / "voiceassistant"
MANIFEST = ANDROID / "AndroidManifest.xml"
NS = "{http://schemas.android.com/apk/res/android}"


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    bad = 0

    def check(condition: bool, text: str) -> None:
        nonlocal bad
        print(("  ✓ " if condition else "  ✗ ") + text)
        if not condition:
            bad += 1

    tree = ET.parse(MANIFEST)
    application = tree.getroot().find("application")
    activity_map = {
        node.get(NS + "name"): node
        for node in application.findall("activity")
    }
    legacy = activity_map.get(".MainActivity")
    preview = activity_map.get(".NativeFinDeckActivity")
    check(legacy is not None and preview is not None,
          "旧 WebView 与原生预览都已声明")
    launchers = []
    for name, activity in activity_map.items():
        for intent in activity.findall("intent-filter"):
            actions = {
                node.get(NS + "name")
                for node in intent.findall("action")
            }
            if "android.intent.action.MAIN" in actions:
                launchers.append(name)
    check(launchers == [".NativeFinDeckActivity"],
          "默认 launcher 已切换到原生主界面")
    if preview is not None:
        check(preview.get(NS + "exported") == "true"
              and any(
                  "android.intent.action.MAIN"
                  in {item.get(NS + "name")
                      for item in intent.findall("action")}
                  for intent in preview.findall("intent-filter")
              ),
              "原生主界面成为唯一导出 launcher")

    activity_source = (JAVA / "NativeFinDeckActivity.java").read_text(
        encoding="utf-8"
    )
    quotes_source = (JAVA / "NativeLandingQuotes.java").read_text(
        encoding="utf-8"
    )
    quote_pairs = re.findall(
        r'\{"([^"]*)",\s*"([^"]*)"\}',
        quotes_source,
    )
    theme_source = (JAVA / "NativeTheme.java").read_text(encoding="utf-8")
    api_source = (JAVA / "NativeApiClient.java").read_text(encoding="utf-8")
    legacy_source = (JAVA / "MainActivity.java").read_text(encoding="utf-8")
    check("EXTRA_EMERGENCY_ROLLBACK" in legacy_source
          and "!source.getBooleanExtra(EXTRA_EMERGENCY_ROLLBACK, false)"
          in legacy_source
          and "target.setClass(this, NativeFinDeckActivity.class);"
          in legacy_source,
          "旧 WebView 默认入口转交原生页，只有显式紧急回滚才保留旧页")
    drawer_interpolator = (
        ANDROID / "res" / "interpolator" / "findeck_drawer.xml"
    ).read_text(encoding="utf-8")
    page_interpolator = (
        ANDROID / "res" / "interpolator" / "findeck_page.xml"
    ).read_text(encoding="utf-8")
    drawer_enter = (
        ANDROID / "res" / "anim" / "findeck_drawer_enter.xml"
    ).read_text(encoding="utf-8")
    drawer_exit = (
        ANDROID / "res" / "anim" / "findeck_drawer_exit.xml"
    ).read_text(encoding="utf-8")

    check("native_look" in activity_source
          and "chatAlpha" in theme_source
          and "bgimg" in theme_source
          and "wallAlpha" in theme_source,
          "原生预览读取旧页面同一份外观参数")
    check("rememberLook" in legacy_source
          and "native_look" in legacy_source,
          "旧页面负责持久化外观参数")
    check("X-FinDeck-Capability" in api_source
          and "/api/security/session" in api_source,
          "原生请求继续使用短时能力凭据")
    check("int port = uri.getPort();" in api_source
          and '"http".equalsIgnoreCase(scheme)' in api_source
          and '"https".equalsIgnoreCase(scheme)' in api_source
          and "port == 0" in api_source
          and '(port > 0 ? ":" + port : "")' in api_source,
          "公网 HTTPS 地址未显式写 443 端口时仍能建立原生连接")
    check("Map<String, String> mediaHeaders(String path)" in api_source
          and "HttpURLConnection openMediaConnection(" in api_source
          and "private boolean isOwnTarget(String path)" in api_source
          and 'headers.put("Cookie", cookie);' in api_source
          and 'headers.put("User-Agent", "FinDeck-Native/"'
          in api_source
          and "new URL(absoluteUrl(path)).openConnection()"
          in api_source,
          "原生媒体请求复用配对设备的 Cookie 与固定 UA")
    check("new java.net.URL(" not in activity_source
          and activity_source.count("api.openMediaConnection(") >= 5
          and "addDownloadHeaders(request, "
          in activity_source
          and "playShotVideoLocally(stage, meta, item, mediaName)"
          in activity_source
          and "player.setVideoURI(Uri.fromFile(target))" in activity_source
          and activity_source.count("api.mediaHeaders(mediaPath)") >= 2
          and "filePlayer.setDataSource(" in activity_source
          and "api.mediaHeaders(mediaPath)" in activity_source,
          "截图、图片、视频、试听、文件与更新下载都走带设备授权的媒体连接")
    check("startNativeRecording" in activity_source
          and "pickAttachments" in activity_source,
          "原生预览已有录音与附件入口")
    check("showTasks" in activity_source
          and "showHistory" in activity_source
          and "showStatus" in activity_source,
          "原生预览已有任务、历史和状态入口")
    check("/api/history/convs" in activity_source
          and "/api/history/archives" in activity_source
          and "/api/history/clear" in activity_source
          and "/api/history/restore" in activity_source
          and "highlightHistoryKeyword" in activity_source,
          "聊天历史已原生化关键词、日期、会话、归档和清除")
    check("renderConversationList" in activity_source
          and "conversationProjectNames" in activity_source
          and "/api/threads/new" in activity_source
          and "/api/threads/action" in activity_source
          and "showConversationActions" in activity_source,
          "会话抽屉已原生化搜索、分类、分组、新建和操作")
    check("ZoomImageView" in activity_source
          and "downloadShot" in activity_source
          and "recordSeconds" not in activity_source
          and '{"5s", "8s", "15s"}' in activity_source
          and 'item.optString("preview", name)' in activity_source,
          "电脑屏幕已原生化时长选择、原画预览、手机视频副本和缩放手势")
    viewer_source = activity_source.split(
        "private int prepareMediaViewer(", 1
    )[-1].split("private void showFiles(", 1)[0]
    check("dialog.setCancelable(false);" in viewer_source
          and "KeyEvent.KEYCODE_BACK" in viewer_source
          and "dismissMediaViewer(dialog, holder);" in viewer_source
          and "private void finishMediaViewer(" in viewer_source
          and ".setDuration(animationsEnabled ? 180 : 0)" in viewer_source
          and "mediaViewerGenerationIsCurrent" in activity_source
          and activity_source.count("mediaViewerGenerationIsCurrent(generation)")
          >= 2
          and "stopPlayback();" in viewer_source
          and "bitmap.recycle();" in viewer_source
          and "if (mediaViewerDialog != null) {\n"
          "            finishMediaViewer(mediaViewerDialog, mediaViewerHolder);"
          in activity_source,
          "全屏媒体查看器支持返回、关闭和下滑统一退场，并清理晚到图片与录像")
    bottom_dialog_source = activity_source.split(
        "private void showConversationDialog(", 1
    )[-1].split("private void conversationAction(", 1)[0]
    settings_source = activity_source.split(
        "private void showSettings(String initialCategory)", 1
    )[-1].split("private LinearLayout settingsAccordion(", 1)[0]
    check("SOFT_INPUT_ADJUST_RESIZE" in bottom_dialog_source
          and "SOFT_INPUT_STATE_ALWAYS_VISIBLE" in bottom_dialog_source
          and "SOFT_INPUT_STATE_ALWAYS_HIDDEN" in bottom_dialog_source
          and "if (keyCode != KeyEvent.KEYCODE_BACK) return false;" in bottom_dialog_source
          and "event.getAction() == KeyEvent.ACTION_UP" in bottom_dialog_source
          and "nativeModalDepth++;" in bottom_dialog_source
          and "nativeModalDepth == 0" in settings_source
          and "nativeModalBackGuardUntil" in activity_source
          and "SOFT_INPUT_ADJUST_RESIZE" in settings_source,
          "底部编辑对话层和设置抽屉允许输入法避让，返回键只关闭最上层")
    check("addAudioFile" in activity_source
          and "downloadRemoteMedia" in activity_source
          and "uploadFileDirect(" in activity_source
          and "filesContainer" in activity_source
          and "filesPanelHeader" in activity_source
          and "R.drawable.ic_findeck_folder" in activity_source
          and "跟电脑要文件" in activity_source,
          "文件页已原生化试听、请求、下载和直传")
    check("filesRequestGeneration" in activity_source
          and "filesMutationGeneration" in activity_source
          and "generation != filesRequestGeneration" in activity_source
          and "filesActiveList" in activity_source
          and "pendingFilesGeneration" in activity_source
          and "filePlayerButton.setText(\"▶ 试听\");" in activity_source
          and "stopFilePlayer();" in activity_source
          and "filesUi.removeCallbacksAndMessages(null);" in activity_source
          and "传好了：" in activity_source,
          "文件页刷新、上传、试听和离页清理带代际与重复提交保护")
    shots_source = activity_source.split(
        "private void renderShots(", 1
    )[-1].split("private void durationOptionsAdd(", 1)[0]
    files_source = activity_source.split(
        "private void renderFiles(", 1
    )[-1].split("private void addRemoteFile(", 1)[0]
    check("private LinearLayout nativeLoadFailure(" in activity_source
          and "屏幕列表没读出来" in shots_source
          and "loadShotsInto(list, true);" in shots_source
          and "if (!files.ok() && !audios.ok())" not in files_source
          and "audioCount < 0" in files_source
          and "fileCount < 0" in files_source
          and "? audios.json.optJSONArray(\"items\") : null" in files_source
          and "? files.json.optJSONArray(\"items\") : null" in files_source
          and files_source.index("audioCount < 0")
          < files_source.index("fileCount =")
          and "\"重试\"" in activity_source,
          "屏幕和文件断线时独立显示主题错误卡并可原地重试")
    check("日程没读出来" in activity_source
          and "扩展列表没读出来" in activity_source
          and "真机验收没读出来" in activity_source
          and "原话没读出来" in activity_source
          and "AgentPool 没读出来" in activity_source
          and "历史没读出来" in activity_source
          and "归档没读出来" in activity_source
          and "连接状态没读出来" in activity_source
          and "lastPluginsResponse" in activity_source
          and "lastAcceptanceResponse" in activity_source
          and "pluginRequestGeneration" in activity_source
          and "acceptanceRequestGeneration" in activity_source
          and "刷新失败，显示上次加载" in activity_source
          and "loadRawRepliesInto(list);" in activity_source
          and "loadStatusInto(list);" in activity_source,
          "其余数据页断线时显示错误卡并可原地重试，扩展和验收保留上次现场")
    check("renderScheduleForm" in activity_source
          and '"weekly"' in activity_source
          and '"monthly"' in activity_source
          and '"once"' in activity_source
          and "scheduleEditIndex" in activity_source
          and "private LinearLayout scheduleCard()" in activity_source
          and "NativeTheme.PANEL, 12, this" in activity_source,
          "日程页已原生化添加、编辑、启停和四种周期规则")
    schedule_source = activity_source.split(
        "private void showSchedule()", 1
    )[-1].split("private void showPlugins()", 1)[0]
    check("final int generation = ++scheduleRequestGeneration;" in schedule_source
          and schedule_source.count("generation != scheduleRequestGeneration")
          >= 1
          and "list.getParent() == null" in schedule_source
          and "scheduleRequestGeneration++;" in activity_source,
          "日程读取带请求代际，关闭、切页或重开会丢弃旧列表回写")
    check("new android.app.TimePickerDialog(" in schedule_source
          and "bindHistoryDatePicker(date);" in schedule_source
          and "scheduleTimeInput(" in schedule_source
          and "TimePickerDialog.OnTimeSetListener" in schedule_source,
          "日程时间和单次日期使用系统选择器，不再靠手输格式")
    check('toast("每月日期要在 1 到 31 号");' in schedule_source
          and 'toast("选一个星期几");' in schedule_source
          and 'toast("选一个日期");' in schedule_source
          and 'toast("写点内容吧");' in schedule_source,
          "日程保存拒绝空内容、空星期、空日期和越界月日")
    check("scheduleMutationInFlight" in schedule_source
          and "mutationGeneration != scheduleMutationGeneration"
          in schedule_source
          and "requestGeneration != scheduleRequestGeneration"
          in schedule_source
          and "result.json.optString(" in schedule_source
          and "日程保存失败" in schedule_source,
          "日程写操作防重复提交，逻辑失败保留现场并显示服务端原因")
    overlay_back = activity_source.split(
        "public void onBackPressed()", 1
    )[-1].split("protected void onDestroy()", 1)[0]
    check("if (overlayActive != null) {" in overlay_back
          and "isHistoryKeyboardVisible()" in overlay_back
          and "hideRootKeyboard();" in overlay_back
          and "private void hideRootKeyboard()" in activity_source,
          "原生子页输入法可见时第一次返回只收键盘，第二次才关闭页面")
    plugin_source = activity_source.split(
        "private void showPlugins()", 1
    )[-1].split("private void showAcceptance()", 1)[0]
    check("postPluginArchive" in api_source
          and "X-FinDeck-Plugin-Permissions" in api_source
          and "installPluginArchive" in activity_source
          and "renderPluginMarket" in activity_source
          and "trustMarketPublisher" in activity_source,
          "扩展页已原生化 ZIP 安装、签名、权限、市场和信任")
    check("pluginActionGeneration" in plugin_source
          and "pluginMutationInFlight" in plugin_source
          and "pendingPluginPageGeneration" in plugin_source
          and "pluginNotice" in plugin_source
          and "pluginPageCurrent(" in plugin_source
          and '"rollback"' in plugin_source
          and '"untrust_publisher"' in plugin_source
          and "MAX_PLUGIN_ARCHIVE" in plugin_source
          and "插件包超过 8 MB" in plugin_source
          and "if (overlayActive != null) closePageOverlay();"
          not in plugin_source,
          "扩展页补齐回滚、发布者撤销、页内结果、动作代际和 ZIP 大小边界")
    check("loadTasksInto" in activity_source
          and "addTaskReview" in activity_source
          and "message_edit" in activity_source
          and "addAgentPool" in activity_source
          and "/api/agents/action" in activity_source
          and "startTaskPolling" in activity_source
          and "taskSnapshotSignature" in activity_source
          and "taskSignature(result)" in activity_source
          and "tasks.sort" in activity_source
          and "reviewBody.setVisibility" in activity_source,
          "任务台已原生化批准、排队消息、审查和 AgentPool")
    check("taskItemsInOrder" in activity_source
          and "applyTaskResponse" in activity_source
          and "taskRequestGeneration" in activity_source
          and "&sync=1&after=" in activity_source
          and 'result.json.optBoolean("reset", false)'
          in activity_source
          and "taskItems.put(id, task);" in activity_source
          and "if (!keep.contains(id)) taskItems.remove(id);" in activity_source
          and "taskCursor = cursor;" in activity_source
          and "taskTransportOnline = transport != null" in activity_source
          and "保留当前状态；恢复后自动补齐" in activity_source
          and "taskItemsInOrder()" in activity_source,
          "任务台按旧版游标增量合并、断线保留现场并防止晚到响应覆盖")
    check("addAcceptanceTools" in activity_source
          and "buildAcceptanceSnapshot" in activity_source
          and "DelayedNotificationReceiver.schedule" in activity_source
          and "REQ_DIAGNOSTIC_EXPORT" in activity_source
          and "reportOpenedFile" in activity_source
          and "saveAcceptanceFile" in activity_source
          and "reportFolderGrant" in activity_source
          and "acceptanceMark(" in activity_source
          and "refreshAcceptancePage" in activity_source
          and 'item.optString("note", "")' in activity_source
          and "DeviceDiagnostics.audioEnvironment" not in activity_source
          and "startNativeRecording();" not in activity_source.split(
              "private void startNativeRecording()", 1)[0].split(
              "private void addAcceptanceTools(", 1)[-1],
          "真机验收已原生化非语音诊断、通知时间线和导出")
    check("showRawReplies" in activity_source
          and "addRawReplyToggle" in activity_source
          and 'item.optString("raw", "")' in activity_source
          and "showHistorySearchPage" in activity_source
          and "/api/log?since=0&q=" in activity_source
          and "shareCurrentConversation" in activity_source
          and "addMarkdownImages" in activity_source
          and "showConversationPeek" in activity_source
          and "ConversationMessageGroup" in activity_source
          and "ConversationPeekPanel" in activity_source
          and "setConversationPeekShift" in activity_source
          and "onConfigurationChanged(Configuration configuration)"
          in activity_source
          and "drawerEdge" in activity_source
          and "bubble.setGravity(mine ? Gravity.END" in activity_source
          and "body.setLineSpacing(0f, 1.65f);" in activity_source
          and "body.setTextIsSelectable(true);\n            final String copyText"
          not in activity_source
          and "messageScroll.setPadding(0," in activity_source
          and "groupParams.topMargin = messageList.getChildCount() == 0"
          in activity_source
          and "balanceParams.leftMargin" in activity_source
          and "window.setStatusBarColor(Color.TRANSPARENT)"
          in activity_source
          and "updateThinkingBandForPlus" in activity_source
          and "setSystemGestureExclusionRects" in activity_source
          and "Collections.singletonList(new Rect(" in activity_source
          and "!clean.equals(activeConversation)" not in activity_source
          and "final boolean current = conversation.trim().equals("
          in activity_source
          and "return clean.length() == 0 ? activeConversation.trim() : clean"
          in activity_source
          and "private final class ConversationMessageGroup" in activity_source
          and "public boolean dispatchTouchEvent(MotionEvent event)" in activity_source
          and "requestDisallowInterceptTouchEvent(true)" in activity_source
          and "private static final class ThinkingBandView" in activity_source
          and "GLOW_INNER_DP = 14" in activity_source
          and "GLOW_OUTER_DP = 20" in activity_source
          and "BAR_HEIGHT_DP = 18" in activity_source
          and "RadialGradient(" in activity_source
          and "Color.rgb(74, 163, 255)" in activity_source
          and "thinkingBand.setElevation(" not in activity_source
          and "stateWidthDp" in activity_source
          and "gear.setVisibility(View.GONE)" in activity_source
          and "showNativeOffline" in activity_source
          and "appendMessagesFrom" in activity_source
          and "lastRenderedGroup" in activity_source
          and "group.setTranslationY(NativeTheme.dp(this, 10))"
          in activity_source
          and "composer.setMaxHeight(NativeTheme.dp(this, 48))"
          in activity_source
          and 'composer.setHint("")' in activity_source
          and "composer.setTextCursorDrawable(null)" in activity_source
          and "Gravity.TOP | Gravity.START" in activity_source
          and "layout.getLineTop(line) + layout.getLineBottom(line)"
          in activity_source
          and "mergeLocalEcho" in activity_source
          and 'optBoolean("online", true)' in activity_source
          and "待命（说唤醒词）" in activity_source
          and 'text.contains("正在思考")' in activity_source
          and "openSystemPhotoPicker" in activity_source
          and "uploadingAttachments >= 6" in activity_source
          and 'showSettings("外观")' in activity_source
          and "phoneMuted" in activity_source
          and "refreshActiveConversation" in activity_source
          and "onRetainNonConfigurationInstance" in activity_source
          and "checkForNativeUpdate" in activity_source
          and "native_draft_selection" in activity_source
          and "native_attachment_names" in activity_source
          and "applyProcessingState" in activity_source
          and "addBareImagePaths" in activity_source
          and "nativeImageSource" in activity_source
          and "speakerState" in activity_source
          and "firstConnectionFailureAt" in activity_source
          and "12000L" in activity_source
          and "sendGlyph" in activity_source,
          "主聊天已原生补齐全菜单、图片、分享、会话侧栏和边缘手势")
    check("chatDrawer = new FrameLayout(this);" in activity_source
          and "chatDrawer.setTranslationX(10000f);" in activity_source
          and "chatDrawer.addView(shell" in activity_source
          and "chatDrawerHandle = NativeTheme.text(this, \"‹\", 30"
          in activity_source
          and "chatDrawerHandle.setBackground(null);" in activity_source
          and "chatDrawerHandle.setContentDescription(\"打开聊天\");"
          in activity_source
          and "纵一苇之所如，凌万顷之茫然。" in activity_source
          and 'Typeface.create("serif", Typeface.NORMAL)' in activity_source
          and '"苏轼 ·《赤壁赋》"' in activity_source
          and '"点击右侧箭头开始"' in activity_source
          and "NativeLandingQuotes.pickIndex(" in activity_source
          and quotes_source.count('{"') == 280
          and quotes_source.count("大肥鱼说 ·") == 140
          and "鱼饭萌系" not in quotes_source
          and "一叶小鱼船晃呀晃，万顷白饭香先靠岸。" in quotes_source
          and "今天先吃到这，明天带着小鱼干和白饭继续。" in quotes_source
          and all(
              any(token in text for token in ("鱼", "饭", "米"))
              for text, _source in quote_pairs[140:]
          )
          and "scheduleLandingQuoteRotation();" in activity_source
          and "16_000L + landingQuoteRandom.nextInt(15_000)" in activity_source
          and "android.view.PixelCopy.request(" in activity_source
          and "pixelThemeTransition" in activity_source
          and ".setDuration(340)" in activity_source
          and "setChatDrawerOpen(true, true);" in activity_source
          and "if (chatDrawerOpen) {" in activity_source
          and ".translationX(target)" in activity_source,
          "启动空背景、右侧聊天抽屉和 280 条原始及大肥鱼说短句")
    check("body.setOnLongClickListener" not in activity_source
          and 'toast("已复制");' in activity_source
          and 'time == null ? "" : time' not in activity_source
          and "messageConversationName(" not in activity_source
          and "recordTime(time);" in activity_source
          and "getGroupTimeLabel()" in activity_source
          and 'setTag("native-message-meta|time|"' in activity_source,
          "合并组只在底部显示首末时间范围并保留显式复制")
    check("canOpenConversationDrawerByGesture()" in activity_source
          and "isHorizontalGestureEntry(dx, dy, 1)" in activity_source
          and "GESTURE_ARM_DP = 42f" in activity_source
          and "GESTURE_AXIS_RATIO = 1.25f" in activity_source
          and "elapsed < 900L" in activity_source
          and "showConversationsAtProgress(1f);" in activity_source
          and "return clean.length() > 0\n                    && !\"本机\".equals(clean)"
          in activity_source,
          "主聊天任意位置右滑打开左侧会话抽屉，两侧手势互不抢占")
    check("startNativeUpdate" in activity_source
          and "installNativeApk" in activity_source
          and "UpdateProvider.AUTHORITY" in activity_source,
          "原生设置保留一键下载与系统安装流程")
    update_resolver = activity_source.split(
        "private void resolveNativeUpdate(", 1
    )[-1].split("private JSONObject readUpdateJson(", 1)[0]
    update_row = activity_source.split(
        "private void refreshNativeUpdateRow(", 1
    )[-1].split("private void resolveNativeUpdate(", 1)[0]
    update_banner = activity_source.split(
        "private void checkForNativeUpdate()", 1
    )[-1].split("private boolean nativeVersionIsNewer(", 1)[0]
    resume_update = activity_source.split(
        "protected void onResume()", 1
    )[-1].split("protected void onPause()", 1)[0]
    check('optString("update_url", "")' in update_resolver
          and 'updateBase + "/version.json"' in update_resolver
          and 'api.get("/api/version")' in update_resolver
          and 'manifest.optBoolean("ok", false)' in update_resolver,
          "设置更新状态按旧页优先读公网清单，失败回退电脑接口")
    check('state.setText("有新版 v"' in update_row
          and 'action.setText("一键更新")' in update_row
          and 'state.setText("已经是最新（v"' in update_row
          and 'action.setText("再看一眼")' in update_row
          and 'action.setText("重试")' in update_row
          and "nativeVersionIsNewer(latest)" in update_row,
          "更新按钮随有新版、已最新和检查失败切换，旧版本不会误报新版")
    check("nativeUpdateCheckGeneration" in update_row
          and "updateBannerGeneration" in update_banner
          and "updateBanner.animate().cancel();" in update_banner
          and "settleUpdateBannerAnimation();" in activity_source
          and "nativeUpdateDownloading" in activity_source,
          "更新检查和下载加入代际、重复下载保护与动态效果终点")
    check('toast("没有开启「安装未知应用」，这次更新已取消");'
          in resume_update
          and "getPackageManager().canRequestPackageInstalls()"
          in resume_update,
          "从安装未知应用设置返回时只有真正获准才继续，不会循环拉系统页")
    check("showSettings" in activity_source
          and "openCompatibility" not in activity_source
          and "MainActivity.class" not in activity_source,
          "设置入口存在，旧版 WebView 兼容入口已停用")
    check("settingsAccordion" in activity_source
          and "populateNativeAppearance" in activity_source
          and "populateNativeConnection" in activity_source
          and "loadNativeAbout" in activity_source
          and "selectChipGroup" in activity_source
          and "avatarEmoji" in activity_source
          and "notifyViews" in activity_source
          and "petViews" in activity_source
          and "公网连接（唯一方式）" in activity_source
          and "扫码公网链接" in activity_source
          and "当前公网链接" in activity_source
          and "native_public_url" in activity_source
          and "REQ_WALLPAPER" in activity_source
          and "REQ_AVATAR" in activity_source,
          "设置五类抽屉和外观、连接、通知、桌宠、关于均为原生")
    check("addNativeSecurityControls" in activity_source
          and "loadSecurityControls" in activity_source
          and "promptBackupPassphrase" in activity_source
          and "revoke-all-devices" in activity_source
          and "rotate-key" in activity_source,
          "设置页安全策略、设备吊销和密钥恢复包均为原生")
    check(activity_source.count("new WebView(this)") == 3
          and "ascii-sharks/index.html" in activity_source
          and "ascii-mantas/index.html" in activity_source
          and "ascii-whales/index.html" in activity_source,
          "原生页只允许像素主题的本地画布使用 WebView")
    check("BODY_FONT" in theme_source
          and "WALLPAPER" in theme_source
          and "ME_BUBBLE" in theme_source,
          "原生视觉层保留旧页面的字号、壁纸和气泡参数")
    check('android:controlX1="0.16"' in drawer_interpolator
          and 'android:controlY1="1"' in drawer_interpolator
          and 'android:controlX1="0.2"' in page_interpolator
          and 'android:controlY1="0.8"' in page_interpolator,
          "抽屉与子页复用旧版 cubic-bezier 曲线")
    peek_close_source = activity_source.split(
        "private void hideConversationPeek()", 1
    )[-1].split("private int conversationPeekWidth()", 1)[0]
    drawer_animation_source = activity_source.split(
        "private void animateConversationDrawer(", 1
    )[-1].split("private void closeConversationDrawer()", 1)[0]
    check("LATERAL_SURFACE_ANIM_MS = 260" in activity_source
          and peek_close_source.count("LATERAL_SURFACE_ANIM_MS") == 2
          and drawer_animation_source.count("LATERAL_SURFACE_ANIM_MS") == 2
          and "row.animate().cancel();" in peek_close_source
          and "panel.animate().cancel();" in peek_close_source
          and "scrim.animate().cancel();" in drawer_animation_source
          and 'android:duration="260"' in drawer_enter
          and 'android:duration="260"' in drawer_exit,
          "会话抽屉、换会话行与设置抽屉统一 260ms，并取消被覆盖的旧动画")
    plus_animation_source = activity_source.split(
        "private void setPlusOpen(", 1
    )[-1].split("private int tileIcon(", 1)[0]
    check("plusScroll.setAlpha(value.getAnimatedFraction())"
          not in plus_animation_source
          and plus_animation_source.count("plusScroll.setAlpha(1f)") >= 4
          and "plusPanelAnimator.cancel();" in plus_animation_source
          and "plusPanelAnimator != animator" in plus_animation_source
          and "ui.postDelayed(plusPanelScrollCue, 120);" in plus_animation_source
          and "messageScroll.fullScroll(View.FOCUS_DOWN);"
          in plus_animation_source,
          "功能面板只收放高度、取消旧动画，并在展开后滚到最新消息")
    page_close_source = activity_source.split(
        "private void closePageOverlay()", 1
    )[-1].split("private void discardClosingPageOverlay()", 1)[0]
    history_close_source = activity_source.split(
        "private void closeHistoryPanel()", 1
    )[-1].split("private void discardClosingHistoryPanel()", 1)[0]
    back_source = activity_source.split(
        "public void onBackPressed()", 1
    )[-1].split("protected void onDestroy()", 1)[0]
    check("pageOverlayClosing = overlay" in page_close_source
          and "historyPanelClosing = panel" in history_close_source
          and "conversationPeekClosing = layer" in peek_close_source
          and back_source.index("historyPanelClosing != null")
          < back_source.index("conversationPeek != null")
          and back_source.index("conversationPeekClosing != null")
          < back_source.index("offlineActive != null")
          and back_source.index("overlayActive != null")
          < back_source.index("pageOverlayClosing != null")
          and back_source.index("pageOverlayClosing != null")
          < back_source.index("plusOpen"),
          "子页、历史和换会话层退场期间继续占用返回，不让 Activity 提前退出")
    page_open_source = activity_source.split(
        "private void pageOverlay(", 1
    )[-1].split("private void closePageOverlay()", 1)[0]
    history_animation_source = activity_source.split(
        "private void animateHistoryPanel(", 1
    )[-1].split("private void settleHistoryPanelAnimation()", 1)[0]
    motion_source = activity_source.split(
        "private void setMotionEnabled(boolean enabled)", 1
    )[-1].split("private boolean motionEnabled(JSONObject look)", 1)[0]
    pause_animation_source = activity_source.split(
        "protected void onPause()", 1
    )[-1].split("public void onBackPressed()", 1)[0]
    destroy_animation_source = activity_source.split(
        "protected void onDestroy()", 1
    )[-1].split("private ", 1)[0]
    check("animationGeneration != pageOverlayAnimationGeneration"
          in page_open_source
          and "overlayActive != overlay" in page_open_source
          and "++pageOverlayAnimationGeneration" in page_close_source
          and "closingGeneration != pageOverlayAnimationGeneration"
          in page_close_source
          and "historySearchFocusCue" in activity_source
          and "historyPanelAnimationGeneration++" in activity_source
          and "settlePageOverlayAnimation();" in pause_animation_source
          and "settleHistoryPanelAnimation();" in pause_animation_source
          and "settlePageOverlayAnimation();" in destroy_animation_source
          and "settleHistoryPanelAnimation();" in destroy_animation_source
          and "settlePageOverlayAnimation();" in motion_source
          and "settleHistoryPanelAnimation();" in motion_source,
          "快速关开子页或历史面板时旧入场/聚焦回调失效，生命周期收敛终点")
    check("HISTORY_PANEL_FADE_MS = 180" in activity_source
          and history_animation_source.count("ObjectAnimator.ofFloat") == 2
          and "LATERAL_SURFACE_ANIM_MS : 0" in history_animation_source
          and "HISTORY_PANEL_FADE_MS : 0" in history_animation_source
          and ".16f, 1f, .3f, 1f" in history_animation_source
          and ".25f, .1f, .25f, 1f" in history_animation_source
          and "arrow.animate().cancel();" in activity_source,
          "历史面板位移 260ms、透明度 180ms，筛选箭头曲线与旧页一致")
    menu_icons = {
        "screen", "folder", "message", "calendar", "tasks", "plugin",
        "shield", "raw", "scan", "mute", "share", "search", "paste",
        "speak", "image", "file", "look", "link", "camera", "record",
        "status", "stop", "avatar",
    }
    icon_dir = ANDROID / "res" / "drawable"
    missing_icons = [
        name for name in menu_icons
        if not (icon_dir / f"ic_findeck_{name}.xml").is_file()
    ]
    check(not missing_icons
          and "tileIcon" in activity_source
          and "tileGlyph" not in activity_source
          and "tile.setBackgroundColor(Color.TRANSPARENT)"
          in activity_source
          and "ViewGroup.LayoutParams.MATCH_PARENT, NativeTheme.dp(this, 43)"
          in activity_source
          and "NativeTheme.dp(this, 24), NativeTheme.dp(this, 24)"
          in activity_source
          and 'showStatus();' in activity_source
          and 'addLocal("me", "截图发手机")' in activity_source
          and 'sendCommand("停")' in activity_source
          and 'addTileRow(panel, "状态", "停", "头像", "")'
          in activity_source,
          "功能菜单使用旧版 SVG 路径生成的 23 个 Android 矢量图标")
    check((icon_dir / "ic_findeck_filter.xml").is_file()
          and (icon_dir / "ic_findeck_speaker_on.xml").is_file()
          and (icon_dir / "ic_findeck_speaker_off.xml").is_file()
          and (icon_dir / "ic_findeck_send.xml").is_file(),
          "页头筛选、扬声器和发送箭头使用旧版矢量图标")
    check("ConversationDrawerSwipePanel" in activity_source
          and "showConversationsAtProgress" in activity_source
          and "setConversationDrawerProgress" in activity_source
          and "finishConversationDrawerGesture" in activity_source
          and "refreshConversationDrawerData" in activity_source
          and "generation != conversationRefreshGeneration"
          in activity_source
          and "conversationDrawerPollRunnable," in activity_source
          and "4000" in activity_source
          and "revealCurrentConversationGroup(collapsed, data);"
          in activity_source
          and "orderedGroups.add(0, currentGroup);" in activity_source
          and "if (conversationDrawerOverlay != null) {\n"
              "                refreshConversationDrawerData();"
          in activity_source
          and "collapseConversationPull" in activity_source
          and "final Runnable onSuccess" in activity_source
          and "native_drawer_collapsed" in activity_source
          and "conversationDrawerFilter" in activity_source
          and "conversationDrawerSearch" in activity_source
          and "conversationDrawerBackdropBitmap" in activity_source
          and "setRenderEffect" in activity_source,
          "会话抽屉即时同步并自动展开、置顶当前会话所在项目")
    check("panelParams.topMargin" in activity_source
          and "applyHistoryFilter" in activity_source
          and "historyFilterActive" in activity_source
          and "historyMessages" in activity_source
          and "fadeMessagesForHistory" in activity_source
          and 'headerFilter.setContentDescription("筛选聊天记录")' in activity_source
          and 'else if ("状态".equals(label)) {' in activity_source
          and "showStatus();" in activity_source
          and "public boolean onKeyPreIme(" in activity_source
          and "hideHistoryKeyboard();" in activity_source
          and "native_history_active" in activity_source
          and "native_history_messages" in activity_source
          and "historyAppliedKeyword" in activity_source
          and "historyAppliedConversations" in activity_source
          and "setHistoryFilterButtonActive" in activity_source
          and "historyKeywordSpan" in activity_source
          and "HistoryGlowSpan" in activity_source,
          "历史筛选改为顶部折叠面板并在确认后替换主聊天")
    check("IME_ACTION_SEARCH" in activity_source
          and "IME_ACTION_DONE" in activity_source
          and "keyboard.showSoftInput(search, 0);" in activity_source
          and "}, 180);" in activity_source
          and '"没有符合筛选条件的聊天记录"' in activity_source
          and '"历史筛选失败：连不上电脑"' in activity_source,
          "历史筛选恢复搜索聚焦、软键盘提交及空结果和失败系统消息")
    history_open_source = activity_source.split(
        "private void showHistory()", 1
    )[-1].split("private void closeHistoryPanel()", 1)[0]
    history_load_source = activity_source.split(
        "private void loadHistoryConversations(", 1
    )[-1].split("private void renderHistoryConversations(", 1)[0]
    history_archive_source = activity_source.split(
        "private void loadHistoryArchives(", 1
    )[-1].split("private void renderHistoryArchives(", 1)[0]
    history_operation_source = activity_source.split(
        "private void applyHistoryFilter(", 1
    )[-1].split("private void clearHistoryFilter()", 1)[0]
    history_reset_source = activity_source.split(
        "private void resetHistoryToLiveChat()", 1
    )[-1].split("private void showHistoryLegacy()", 1)[0]
    check("new SnapshotFrostedBackdrop(this)" in history_open_source
          and "historyFrostedTint = historyTint;" in history_open_source
          and "NativeTheme.drawerColor(" in history_open_source
          and "refreshHistoryDrawerFrosted(panel);" in history_open_source
          and "NativeTheme.TOP_DRAWER_BLUR" in activity_source
          and "MaxHeightScrollView" in activity_source
          and "Math.round(root.getHeight() * .34f)"
          in activity_source
          and "NativeTheme.dp(this, 48)" in activity_source,
          "顶部筛选抽屉使用独立GPU毛玻璃、两列对话筛选和48dp操作行")
    check('NativeTheme.text(this, "至", 12, NativeTheme.DIM)'
          in history_open_source,
          "历史日期之间使用旧页的“至”分隔符")
    check("final int generation = ++historyOperationGeneration"
          in history_operation_source
          and history_operation_source.count(
              "generation != historyOperationGeneration"
          ) >= 2
          and "private void settleHistoryOperationAnimation()"
          in activity_source
          and "settleHistoryOperationAnimation();" in pause_animation_source
          and "settleHistoryOperationAnimation();" in destroy_animation_source
          and "settleHistoryOperationAnimation();" in motion_source,
          "历史筛选淡出和网络回写加入代际保护，暂停、销毁和减动效收敛终点")
    check("messages.clear();" in history_reset_source
          and history_reset_source.index("messages.clear();")
          < history_reset_source.index("since = 0L;")
          and "pollGeneration++;" in history_reset_source
          and "polling = false;" in history_reset_source
          and history_reset_source.index("renderMessages();")
          < history_reset_source.index("poll();"),
          "退出筛选、清除和恢复归档后先清旧列表再从头轮询，不再重复追加聊天")
    history_failure_source = history_operation_source.split(
        "if (!result.ok())", 1
    )[-1].split("JSONArray items", 1)[0]
    check('"历史筛选失败：连不上电脑"' in history_failure_source
          and "setHistoryFilterButtonActive(false)"
          in history_failure_source
          and "closeHistoryPanel();" not in history_failure_source
          and "return;" in history_failure_source,
          "历史筛选网络失败时保留面板、提示失败且不点亮漏斗")
    check("final int sessionGeneration = ++historyPanelSessionGeneration"
          in history_open_source
          and "sessionGeneration != historyPanelSessionGeneration"
          in history_load_source
          and "历史对话没读出来" in activity_source
          and "loadHistoryConversations(" in activity_source
          and history_archive_source.count(
              "historyPanelSessionGeneration"
          ) >= 2,
          "历史会话与归档读取绑定当前面板代际，失败可原地重试且不写回已关闭页面")
    check("hideHistoryKeyboard();" in history_close_source
          and "keyboard.hideSoftInputFromWindow(root.getWindowToken(), 0);"
          in activity_source
          and "historySearchInput.clearFocus();" in activity_source
          and "WindowInsets.Type.ime()" in activity_source
          and "if (isHistoryKeyboardVisible())" in activity_source
          and "hideHistoryKeyboard();" in activity_source
          and "syncingQuickDate[0]" in activity_source
          and "selectHistoryQuickDay(quickRow[0], null);" in activity_source,
          "返回键先收历史搜索输入法再关面板，手动改日期会取消旧快捷日期选中态")
    check("closeOtherSettingsSections" in activity_source
          and '"settings-body"' in activity_source
          and '"settings-arrow"' in activity_source
          and "boolean opening = body.getVisibility() != View.VISIBLE"
          in activity_source
          and "about.addView(compatibility" not in activity_source
          and "settings.addView(compatibility" not in activity_source,
          "设置分类保持旧版单开互斥和箭头回正，兼容按钮已移除")
    settings_animation_source = activity_source.split(
        "private void toggleMeasuredHeight(", 1
    )[-1].split("private void smoothScrollSettingsSection(", 1)[0]
    check("SETTINGS_HEIGHT_ANIM_MS = 300" in activity_source
          and "SETTINGS_PADDING_ANIM_MS = 240" in activity_source
          and "SETTINGS_MOVE_ANIM_MS = 240" in activity_source
          and "SETTINGS_ALPHA_ANIM_MS = 200" in activity_source
          and settings_animation_source.count(
              "android.animation.ObjectAnimator.ofFloat"
          ) == 2
          and "android.animation.ValueAnimator.ofFloat(0f, 1f)"
          in settings_animation_source
          and "SETTINGS_ALPHA_ANIM_MS : 0" in settings_animation_source
          and "SETTINGS_HEIGHT_ANIM_MS : 0" in settings_animation_source
          and ".25f, .1f, .25f, 1f" in settings_animation_source
          and ".16f, 1f, .3f, 1f" in settings_animation_source,
          "设置分类高度 300ms、透明 200ms、位移与内边距 240ms 分线动画")
    check("state.generation" in settings_animation_source
          and "generation != activeState.generation"
          in settings_animation_source
          and "activeState.scrollCue" in settings_animation_source
          and "ui.postDelayed(activeState.scrollCue, 120)"
          in settings_animation_source
          and "smoothScrollSettingsSection(section)"
          in settings_animation_source
          and "settleSettingsAccordionAnimations();"
          in pause_animation_source
          and "settleSettingsAccordionAnimations();"
          in destroy_animation_source
          and "settleSettingsAccordionAnimations();" in motion_source,
          "设置分类快速切换、滚动提示和生命周期都会收敛到唯一终点")
    check("header.setClickable(true)" in activity_source
          and "overlay.setOnClickListener" in activity_source
          and "closePageOverlay()" in activity_source,
          "原生子页保留旧版标题和空白处返回")
    check("ConversationQuickSwipeScrollView" in activity_source
          and "isHorizontalGestureEntry(dx, dy, 1)" in activity_source
          and "conversationPeek == null" in activity_source
          and "showConversations();" in activity_source,
          "聊天区快速右滑可唤起左侧会话抽屉且不抢气泡左滑会话层")
    check("buildFrostedSurface(header, true)" in activity_source
          and "buildFrostedSurface(footer, false)" in activity_source
          and "headerFrostedBackdrop = backdrop;" in activity_source
          and "footerFrostedBackdrop = backdrop;" in activity_source
          and "new SnapshotFrostedBackdrop(this)" in activity_source
          and "headerFrostedTint = tint;" in activity_source
          and "footerFrostedTint = tint;" in activity_source
          and "private final class FrostedBarLayout extends FrameLayout"
          in activity_source
          and "content.measure(widthMeasureSpec, contentHeightSpec)"
          in activity_source
          and "content.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source
          and "messageScroll.setClipToPadding(false)" in activity_source
          and "updateChatChromeInsets" in activity_source,
          "顶底栏由内容决定高度，并用实时模糊层和独立主题 tint 透出聊天")
    check('getAssets().open("default-bg.jpg")' not in activity_source,
          "原生聊天不再铺未经选择的默认壁纸")
    check("captureRootCrop(panelWidth, root.getHeight())" in activity_source
          and "FLAG_BLUR_BEHIND" in activity_source
          and "applyFrostedCrop(blurred, backdrop)" in activity_source,
          "设置页和左侧会话抽屉使用模糊背板与半透明主题层")
    check("CHAT_BLUR" in theme_source
          and "chatBlurBackdrop" in activity_source
          and "refreshChatBlurBackdrop" in activity_source
          and "drawBlurredWallpaper" in activity_source
          and "RenderEffect.createBlurEffect" in activity_source
          and "refreshLiveAppearance();" in activity_source
          and "scheduleChatBackdropRefresh();" in activity_source,
          "聊天色块模糊使用壁纸背板绘制，滑杆调整会立即刷新")
    check("header.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source
          and "footer.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source
          and "composer.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source
          and "headerContent.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source
          and "footerContent.setBackgroundColor(Color.TRANSPARENT);"
          in activity_source,
          "顶栏底栏只保留文字图片按钮并直接透出聊天气泡")
    check("private TextView headerName;" in activity_source
          and "private View headerAvatar;" in activity_source
          and 'loadDesktopIdentity();' in activity_source
          and 'api.get("/api/info")' in activity_source
          and "headerName.setText(headerDisplayName());" in activity_source
          and 'headerName.setText(displayName.length() > 0'
          in activity_source
          and '"native-header-avatar"' in activity_source
          and '"native-message-avatar"' in activity_source
          and "refreshMessageAvatars();" in activity_source
          and "row.findViewWithTag(\"native-message-avatar\")"
          in activity_source,
          "手机名字及头像即时刷新顶部和已显示消息，与旧页一致")
    back_source = activity_source.split(
        "public void onBackPressed()", 1
    )[-1].split("super.onBackPressed()", 1)[0]
    back_order = [
        back_source.find("historyPanel != null"),
        back_source.find("pendingAttachments > 0"),
        back_source.find("overlayActive != null"),
        back_source.find("plusOpen"),
    ]
    check(all(index >= 0 for index in back_order)
          and back_order == sorted(back_order),
          "返回键按旧版顺序先清附件、再关子页和功能菜单")
    check('addConversationMetaItem(meta, "已选", NativeTheme.ACCENT)'
          in activity_source
          and 'return "昨天"' in activity_source
          and '"HH:mm", Locale.CHINA' in activity_source,
          "会话行恢复已选状态及今日、昨天和跨年时间格式")
    check("pendingConversationDiff" in activity_source
          and "conversationDiffText" in activity_source
          and 'text.append("新增：")' in activity_source
          and 'text.append("移除：")' in activity_source
          and "}, 3000);" in activity_source,
          "会话抽屉恢复新增、移除提示及三秒后收起")
    check("conversationDrawerWho" in activity_source
          and "conversationDrawerWhoText" in activity_source
          and "刷新失败，显示上次加载" in activity_source
          and "updateConversationDrawerWho(result.json, false)" in activity_source,
          "会话抽屉刷新失败时保留缓存并明确标记上次加载")
    check("MOTION_ENABLED" in theme_source
          and "if (!MOTION_ENABLED) {" in theme_source
          and "NativeTheme.MOTION_ENABLED = animationsEnabled;" in activity_source
          and "copy.setOnClickListener(new View.OnClickListener()" in activity_source
          and "setDuration(animationsEnabled ? 180 : 0)" in activity_source,
          "减少动态效果仍约束公共按压、看图与会话行动画，复制不依赖长按")
    check("private void setMotionEnabled(boolean enabled)" in activity_source
          and "thinkingAnimator.cancel();" in activity_source
          and "statusDotAnimator.cancel();" in activity_source
          and "thinkingBand.setAlpha(thinkingActive ? .72f : 0f);"
          in activity_source
          and "if (onlinePulseActive) setOnlinePulse(true);" in activity_source
          and "if (thinkingActive) setThinking(true);" in activity_source
          and "setMotionEnabled(motionEnabled(currentLook));" in activity_source
          and "setMotionEnabled(motionEnabled(look));" in activity_source,
          "运行时切换动画会立即收敛呼吸、思考循环并支持重新启用")
    check("private void refreshThemeBoundChrome()" in activity_source
          and "caretDot.setBackground(caretDotBackground());" in activity_source
          and "sendButton.setBackgroundColor(NativeTheme.ACCENT);" in activity_source
          and "sendGlyph.setColorFilter(NativeTheme.ACCENT_INK);" in activity_source
          and "statusDot.setBackground(NativeTheme.rounded(statusColor, 5, this));"
          in activity_source
          and "refreshThemeBoundChrome();" in activity_source,
          "强调色即时刷新光标、发送键、输入文字和当前状态点")
    send_arrow_source = activity_source.split(
        "private void animateSendArrow()", 1
    )[-1].split("private void resetSendArrowAnimation()", 1)[0]
    pause_source = activity_source.split(
        "protected void onPause()", 1
    )[-1].split("protected void onDestroy()", 1)[0]
    destroy_source = activity_source.split(
        "protected void onDestroy()", 1
    )[-1].split("private static final class ZoomImageView", 1)[0]
    check("SEND_ARROW_LEAVE_MS = 213" in activity_source
          and "SEND_ARROW_RETURN_MS = 347" in activity_source
          and "sendArrowGeneration" in send_arrow_source
          and send_arrow_source.count(".setInterpolator(easing)") == 2
          and send_arrow_source.count(".withEndAction(") == 2
          and "translationX(0f)" in send_arrow_source
          and "translationY(-NativeTheme.dp(this, 28))" in send_arrow_source
          and "NativeTheme.dp(this, 13)" not in send_arrow_source
          and "ui.postDelayed(" not in send_arrow_source
          and "resetSendArrowAnimation();" in pause_source
          and "resetSendArrowAnimation();" in destroy_source,
          "发送箭头垂直上移后原位淡入，快速重发和生命周期切换都会收敛终点")
    check("composer.setOnKeyListener" in activity_source
          and "KeyEvent.KEYCODE_ENTER" in activity_source
          and "KeyEvent.KEYCODE_NUMPAD_ENTER" in activity_source
          and "event.isShiftPressed()" in activity_source
          and "isComposerComposing()" in activity_source
          and "BaseInputConnection.getComposingSpanStart(text)" in activity_source
          and activity_source.count(
              "if (isComposerComposing()) return false;"
          ) >= 2
          and "IME_ACTION_SEND" in activity_source
          and "sendComposer();\n                return true;" in activity_source,
          "输入框按回车发送、Shift+回车保留换行，组合输入未结束时不提前提交")
    paste_source = activity_source.split(
        "private void pasteClipboard()", 1
    )[-1].split("private void pickAttachments()", 1)[0]
    check("Editable editable = composer.getText();" in paste_source
          and "composer.getSelectionStart()" in paste_source
          and "composer.getSelectionEnd()" in paste_source
          and "editable.replace(start, end, incoming);" in paste_source
          and "composer.setSelection(start + incoming.length());"
          in paste_source
          and "composer.setText(clip.getItemAt(0).coerceToText(this));"
          not in paste_source,
          "粘贴文字插入当前光标或选区，不再覆盖已有草稿")
    check('current ? "当前" : "切换 →"' in activity_source
          and "final boolean current = conversation.trim().equals("
          in activity_source
          and "if (current) return;" in activity_source,
          "换会话层按旧页显示当前状态且不重复切换")
    peek_panel_source = activity_source.split(
        "private final class ConversationPeekPanel extends LinearLayout {", 1
    )[-1].split("private final class ConversationDrawerSwipePanel", 1)[0]
    check("if (dragging) {" in peek_panel_source
          and "return super.onTouchEvent(event);" in peek_panel_source
          and "dragging = false;\n                    return true;"
          in peek_panel_source,
          "换会话面板仅在真实拖动时吞触摸，普通点按可触发切换")
    incoming_source = activity_source.split(
        "private void handleIncoming(Intent intent)", 1
    )[-1].split("private void stageIncomingAttachment", 1)[0]
    check("Intent.ACTION_SEND.equals(action)" in incoming_source
          and "Intent.ACTION_SEND_MULTIPLE.equals(action)" in incoming_source
          and "Intent.ACTION_PROCESS_TEXT.equals(action)" in incoming_source
          and "Intent.ACTION_VIEW.equals(action)" in incoming_source
          and "Intent.EXTRA_STREAM" in incoming_source
          and "getClipData()" in incoming_source
          and "appendIncomingText(text);" in incoming_source,
          "原生分享入口接收单段、多段、选中文字和系统打开文本")
    stage_source = activity_source.split(
        "private void stageAttachment(final Uri uri, String mimeHint)", 1
    )[-1].split("private void renderAttachTray()", 1)[0]
    check("pendingAttachmentUris.add(uri);" in stage_source
          and "pendingAttachmentMimes.add(" in stage_source
          and "MAX_IMAGE_ATTACHMENT" in stage_source
          and "点发送才会传给电脑" in stage_source
          and "api.postBytes" not in stage_source
          and "/api/upload" not in stage_source,
          "分享和选择附件只进入本地待发送区，不提前上传")
    send_source = activity_source.split(
        "private void sendComposer()", 1
    )[-1].split("private void retryOutgoing(", 1)[0]
    check('"/api/upload?name=" + Uri.encode(attachment.name)' in send_source
          and '(attachment.image ? "&paste=1" : "")' in send_source
          and '"/api/send-media"' in send_source
          and '"/api/submit"' in send_source
          and "if (attachment.uploaded) continue;" in send_source
          and 'message.put("state", "queued");' in send_source,
          "附件仅在点发送后按队列上传，图片保留 paste=1 与显式提交语义")
    check("Intent source = getIntent();" in legacy_source
          and ": new Intent(source);" in legacy_source
          and "target.setClass(this, NativeFinDeckActivity.class);"
          in legacy_source,
          "旧入口转交原生页时保留原始分享内容、URI 授权和启动标志")
    conversation_actions = activity_source.split(
        "private void showConversationActions(", 1
    )[-1].split("private LinearLayout conversationActionButton(", 1)[0]
    check("params.width = ViewGroup.LayoutParams.MATCH_PARENT;" in conversation_actions
          and "window.setDimAmount(.58f);" in conversation_actions
          and "Color.argb(245, 23, 26, 32)" in conversation_actions
          and "NativeTheme.asymmetric(" in conversation_actions
          and "setDuration(240)" in conversation_actions
          and "new PathInterpolator(.16f, 1f, .3f, 1f)"
          in conversation_actions,
          "会话操作层恢复旧页全宽底部毛玻璃、遮罩与 240ms 入场")
    conversation_modals = activity_source.split(
        "private void renameConversation(", 1
    )[-1].split("private void conversationAction(", 1)[0]
    check("conversationDialogPanel(" in conversation_modals
          and "conversationDialogActions(" in conversation_modals
          and "showConversationDialog(dialog, panel" in conversation_modals
          and "params.width = Math.max(" in conversation_modals
          and "params.gravity = Gravity.BOTTOM;" in conversation_modals
          and ".setItems(names," not in conversation_modals
          and ".setView(input)" not in conversation_modals
          and 'danger ? Color.rgb(184, 68, 68) : NativeTheme.ACCENT'
          in conversation_modals,
          "重命名、项目选择和永久删除改用旧页样式底部对话框")
    create_source = activity_source.split(
        "private void createConversation(", 1
    )[-1].split("private void showConversationActions(", 1)[0]
    check('if (!result.ok()) {' in create_source
          and 'showConversationDrawerNotice("新建失败：" +'
          in create_source
          and "if (closeDrawer != null) closeDrawer.run();"
          in create_source
          and create_source.find('if (!result.ok()) {')
          < create_source.find("if (closeDrawer != null) closeDrawer.run();"),
          "新建会话失败时保留抽屉，只有服务端确认成功后才关闭")
    conversation_action_source = activity_source.split(
        "private void conversationAction(", 1
    )[-1].split("private void targetConversation(", 1)[0]
    check("dismissNativeDialog(actionSheet, actionSheetPanel, send);"
          in conversation_action_source
          and "closeDrawer.run();" not in conversation_action_source
          and "refreshConversationDrawerData();" in conversation_action_source,
          "会话操作不再误关左侧抽屉，完成后原地刷新会话列表")
    check("conversationDrawerToast" in activity_source
          and "toastParams.bottomMargin = NativeTheme.dp(this, 78);"
          in activity_source
          and "showConversationDrawerNotice(" in activity_source
          and "ui.postDelayed(conversationDrawerToastHide, 2200);"
          in activity_source
          and "ui.removeCallbacks(" in activity_source,
          "会话操作结果在抽屉底部显示 2.2 秒主题提示")
    poll_source = activity_source.split(
        "private void poll()", 1
    )[-1].split("private void consume(", 1)[0]
    resume_source = activity_source.split(
        "protected void onResume()", 1
    )[-1].split("protected void onPause()", 1)[0]
    pause_source = activity_source.split(
        "protected void onPause()", 1
    )[-1].split("public void onBackPressed()", 1)[0]
    check("final int generation = ++pollGeneration;" in poll_source
          and "if (generation != pollGeneration) return;" in poll_source
          and "pollGeneration++;" in pause_source
          and "polling = false;" in pause_source
          and "boolean recoverForeground = wasPaused;" in resume_source
          and "messageScroll.fullScroll(View.FOCUS_DOWN);" in resume_source
          and "poll();" in resume_source,
          "回到前台会解除旧拉取锁并立即补拉、滚到最新消息")
    security_source = activity_source.split(
        "private void addNativeSecurityControls(", 1
    )[-1].split("private void loadSecurityControls(", 1)[0]
    backup_source = activity_source.split(
        "private void promptBackupPassphrase(", 1
    )[-1].split("private void performBackupPassphrase(", 1)[0]
    native_dialog_source = activity_source.split(
        "private Dialog showNativeDialog(", 1
    )[-1].split("private Dialog showDangerConfirm(", 1)[0]
    check("AlertDialog" not in activity_source
          and "showNativeDialog(" in activity_source
          and "dismissNativeDialog(" in activity_source
          and "panel.animate()" in native_dialog_source
          and ".setDuration(180)" in native_dialog_source
          and "KeyEvent.KEYCODE_BACK" in activity_source
          and ".withEndAction(new Runnable()" in native_dialog_source
          and activity_source.count("showNativeDialog(") >= 12,
          "日程、扩展、任务、历史、worktree、录音和连接设置不再使用"
          "普通系统对话框，主题确认层支持返回取消与 180ms 退出动画")
    check("showDangerConfirm(" in security_source
          and "showNativeDialog(" in activity_source
          and "boolean danger" in native_dialog_source
          and "danger ? Color.WHITE : NativeTheme.ACCENT_INK"
          in activity_source
          and "danger ? Color.rgb(184, 68, 68) : NativeTheme.ACCENT"
          in activity_source
          and 'action.put("rotate_key", true);' in security_source
          and "需要回到电脑重新配对。" in activity_source
          and 'setSecurityNotice(panel, "先把整段恢复包贴到输入框里", true);'
          in backup_source
          and "!passphrase.equals(repeated)" in backup_source
          and "securityActionInFlight" in backup_source
          and 'showDangerConfirm(\n                                    "恢复操作密钥？"'
          in backup_source
          and "void invalidateCapability()" in api_source
          and "api.invalidateCapability();" in activity_source,
          "安全危险操作使用主题危险确认，当前设备警告、全部吊销轮换密钥、"
          "恢复二次确认和动作后凭据失效与旧页一致")
    acceptance_tools = activity_source.split(
        "private void addAcceptanceTools(", 1
    )[-1].split("private String buildAcceptanceSnapshot()", 1)[0]
    activity_result = activity_source.split(
        "protected void onActivityResult(", 1
    )[-1].split("private void writeDiagnosticExport(", 1)[0]
    release_source = activity_source.split(
        "private void releaseAcceptanceFileGrants()", 1
    )[-1].split("private void reopenAcceptanceUri(", 1)[0]
    check("showDangerConfirm(" in acceptance_tools
          and "撤销文件授权？" in acceptance_tools
          and "releaseAcceptanceFileGrants();" in acceptance_tools
          and "请在系统文件选择器里选一个真实文件…" in acceptance_tools
          and "请在系统保存页选择位置" in acceptance_tools
          and "请在系统目录选择器里选一个文件夹" in acceptance_tools
          and "已取消系统文件夹选择，没有读取文件或保留授权。"
          in activity_result
          and "已取消系统保存，没有写入任何文件。" in activity_result
          and "已取消，没有改动文件或授权。" in activity_result
          and "Set<String> seen = new LinkedHashSet<>();" in release_source
          and "未释放 " in release_source
          and "剩余记录 0 项" in release_source,
          "撤销持久文件授权先确认，系统文件、保存和文件夹取消结果留在验收现场")
    acceptance_refresh = activity_source.split(
        "private void markAcceptanceSystemReturn(", 1
    )[-1].split("private String appStorageProbe()", 1)[0]
    permission_request = activity_source.split(
        "private void requestAcceptancePermissions()", 1
    )[-1].split("private String acceptanceLabel(", 1)[0]
    permission_result = activity_source.split(
        "public void onRequestPermissionsResult(", 1
    )[-1].split("protected void onConfigurationChanged(", 1)[0]
    check(acceptance_tools.count("markAcceptanceSystemReturn(") >= 2
          and "markAcceptanceSystemReturn(900);" in permission_request
          and "scheduleAcceptanceStatusRefresh(900);" in permission_request
          and "markAcceptanceSystemReturn(900);" in permission_result
          and "if (resumed) {" in permission_result
          and "scheduleAcceptanceStatusRefresh(900);" in permission_result
          and "generation != acceptanceStatusRefreshGeneration"
          in acceptance_refresh
          and "acceptanceDiagnostic != target" in acceptance_refresh
          and "overlayActive == null" in acceptance_refresh
          and "target.getParent() == null" in acceptance_refresh
          and "setAcceptanceStatus(buildAcceptanceSnapshot());"
          in acceptance_refresh
          and "if (recoverForeground) {\n            resumeAcceptanceStatusRefresh();"
          in activity_source
          and "cancelAcceptanceStatusRefreshCue();" in pause_source
          and "cancelAcceptanceStatusRefreshCue();" in destroy_source,
          "权限和电池系统页返回后按旧页自动重读手机状态，迟到刷新不会覆盖新页面")

    acceptance_async = activity_source.split(
        "private void reportOpenedFile(", 1
    )[-1].split("private void releaseAcceptanceFileGrants()", 1)[0]
    acceptance_export = activity_source.split(
        "private void writeDiagnosticExport(", 1
    )[-1].split("private void uploadFileDirect(", 1)[0]
    check("final TextView target = acceptanceDiagnostic;" in acceptance_async
          and acceptance_async.count(
              "final int pageGeneration = acceptancePageGeneration;"
          ) >= 3
          and acceptance_async.count(
              "acceptanceTargetIsCurrent(target, pageGeneration)"
          ) >= 3
          and "cursor.getParent() instanceof View"
          in activity_source
          and "target != acceptanceDiagnostic" in activity_source
          and "pageGeneration != acceptancePageGeneration" in activity_source,
          "文件读取、另存和文件夹回读完成后只写发起任务时的验收页，"
          "关闭或重开页面后旧结果不会覆盖新现场")
    check("pendingDiagnosticTarget = diagnostic;" in acceptance_tools
          and "pendingDiagnosticPageGeneration = acceptancePageGeneration;"
          in acceptance_tools
          and "已取消系统保存，诊断快照没有写入文件。" in activity_result
          and "acceptanceTargetIsCurrent(target, pageGeneration)"
          in acceptance_export
          and 'target.setText("诊断快照已保存 · "' in acceptance_export
          and 'target.setText("诊断导出失败：" + kind)' in acceptance_export
          and "acceptancePageGeneration++;" in activity_source,
          "诊断导出系统页取消、成功和失败都回到原验收现场，"
          "异步写入不会复活已关闭页面")

    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
