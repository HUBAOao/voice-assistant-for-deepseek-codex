# -*- coding: utf-8 -*-
"""测新功能的解析：番茄钟 / 便签 / 记账 / 小游戏 / 播报 / 变身 / 语气。"""
from __future__ import annotations

import sys

import numpy as np

sys.path.insert(0, r"C:\Users\HuBao\Documents\Codex\2026-10-06\gei\outputs\voice-to-text")

from stt import (guess_mood, parse_brief, parse_focus, parse_game, parse_ledger,  # noqa: E402
                 parse_note, parse_transform)

FOCUS = [
    ("大肥鱼，专注25分钟", 25),
    ("开始番茄钟", 25),
    ("番茄钟 45 分钟", 45),
    ("专注模式一小时", 60),
    ("专注1分钟", 1),
    ("大肥鱼，结束专注", -1),
    ("还有多久", None),
    ("我要专注工作了", None),          # 不能误触发
    ("今天的专注力不错", None),
]
NOTES = [
    ("记一下 明天买牛奶", "明天买牛奶"),
    ("帮我记一下 周五交报告", "周五交报告"),
    ("记下 钥匙在抽屉里", "钥匙在抽屉里"),
    ("备忘 妈妈生日 3 月 2 号", "妈妈生日 3 月 2 号"),
    ("提醒我明天买牛奶", None),
]
LEDGER = [
    ("记一笔 买菜 30", ("买菜", 30.0)),
    ("记一笔 咖啡 28块", ("咖啡", 28.0)),
    ("买咖啡花了32块", ("买咖啡", 32.0)),
    ("今天我花了多少", None),           # 这是查询，不是记账
    ("记账 打车 15.5", ("打车", 15.5)),
]
GAMES = [
    ("猜数字", ("guess", "")),
    ("帮我决定 吃面还是吃饭", ("pick", "吃面还是吃饭")),
    ("帮我选 咖啡 还是 奶茶 还是 白水", ("pick", "咖啡还是奶茶还是白水")),
    ("不玩了", ("stop", "")),
    ("今天天气不错", None),
]
MISC = [
    ("早间播报", True, False),
    ("今天有什么安排", True, False),
    ("大肥鱼，变身", False, True),
    ("换个样子", False, True),
    ("帮我查天气", False, False),
]


def check(name: str, cases, fn) -> int:
    bad = 0
    print(f"\n=== {name} ===")
    for text, want in cases:
        got = fn(text)
        ok = (got == want)
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} {got!r:28s} ← 「{text}」")
    return bad


def mood_test() -> int:
    print("\n=== 语气 ===")
    bad = 0
    sr = 16000
    cases = [
        ("", 0.12, 2.0, "今天天气怎么样"),
        ("急", 0.45, 1.2, "快点快点快点帮我看看这个"),
        ("轻", 0.03, 3.0, "嗯"),
    ]
    for want, amp, seconds, text in cases:
        n = int(sr * seconds)
        t = np.linspace(0, seconds, n, endpoint=False)
        wave = (np.sin(2 * np.pi * 220 * t) * amp).astype(np.float32)
        env = np.ones(n, dtype=np.float32)
        got = guess_mood(wave * env, sr, text)
        ok = (got == want)
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} 峰值{amp:.2f} {seconds}s {len(text)}字 → {got!r}（期望 {want!r}）")
    return bad


def main() -> int:
    bad = 0
    bad += check("番茄钟", FOCUS, parse_focus)
    bad += check("便签", NOTES, parse_note)
    bad += check("记账", LEDGER, parse_ledger)
    bad += check("小游戏", GAMES, parse_game)
    print("\n=== 播报 / 变身 ===")
    for text, want_brief, want_tf in MISC:
        gb, gt = parse_brief(text), parse_transform(text)
        ok = (gb == want_brief and gt == want_tf)
        bad += 0 if ok else 1
        print(f"  {'✓' if ok else '✗'} 播报={gb} 变身={gt} ← 「{text}」")
    bad += mood_test()
    print(f"\n不通过的用例数 = {bad}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    raise SystemExit(main())
